import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\AnnouncementInboxController::read
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
export const read = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

read.definition = {
    methods: ["post"],
    url: '/inbox/announcements/{announcement}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AnnouncementInboxController::read
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
read.url = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { announcement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { announcement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    announcement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        announcement: typeof args.announcement === 'object'
                ? args.announcement.id
                : args.announcement,
                }

    return read.definition.url
            .replace('{announcement}', parsedArgs.announcement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AnnouncementInboxController::read
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
read.post = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: read.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AnnouncementInboxController::read
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
    const readForm = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: read.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AnnouncementInboxController::read
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
        readForm.post = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: read.url(args, options),
            method: 'post',
        })
    
    read.form = readForm
/**
* @see \App\Http\Controllers\AnnouncementInboxController::readAll
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
export const readAll = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

readAll.definition = {
    methods: ["post"],
    url: '/inbox/announcements/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AnnouncementInboxController::readAll
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
readAll.url = (options?: RouteQueryOptions) => {
    return readAll.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AnnouncementInboxController::readAll
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
readAll.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: readAll.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AnnouncementInboxController::readAll
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
    const readAllForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: readAll.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AnnouncementInboxController::readAll
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
        readAllForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: readAll.url(options),
            method: 'post',
        })
    
    readAll.form = readAllForm
const announcements = {
    read: Object.assign(read, read),
readAll: Object.assign(readAll, readAll),
}

export default announcements