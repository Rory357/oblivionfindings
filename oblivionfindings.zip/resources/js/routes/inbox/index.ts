import notifications from './notifications'
import announcements from './announcements'
const inbox = {
    notifications: Object.assign(notifications, notifications),
announcements: Object.assign(announcements, announcements),
}

export default inbox