import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/incidents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\IncidentController::index
 * @see app/Http/Controllers/IncidentController.php:10
 * @route '/incidents'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
export const show = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/incidents/{incident}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
show.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return show.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
show.get = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
show.head = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
    const showForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
        showForm.get = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\IncidentController::show
 * @see app/Http/Controllers/IncidentController.php:49
 * @route '/incidents/{incident}'
 */
        showForm.head = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\IncidentController::update
 * @see app/Http/Controllers/IncidentController.php:72
 * @route '/incidents/{incident}'
 */
export const update = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/incidents/{incident}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\IncidentController::update
 * @see app/Http/Controllers/IncidentController.php:72
 * @route '/incidents/{incident}'
 */
update.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return update.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\IncidentController::update
 * @see app/Http/Controllers/IncidentController.php:72
 * @route '/incidents/{incident}'
 */
update.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\IncidentController::update
 * @see app/Http/Controllers/IncidentController.php:72
 * @route '/incidents/{incident}'
 */
    const updateForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\IncidentController::update
 * @see app/Http/Controllers/IncidentController.php:72
 * @route '/incidents/{incident}'
 */
        updateForm.put = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\IncidentController::submit
 * @see app/Http/Controllers/IncidentController.php:92
 * @route '/incidents/{incident}/submit'
 */
export const submit = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/incidents/{incident}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\IncidentController::submit
 * @see app/Http/Controllers/IncidentController.php:92
 * @route '/incidents/{incident}/submit'
 */
submit.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return submit.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\IncidentController::submit
 * @see app/Http/Controllers/IncidentController.php:92
 * @route '/incidents/{incident}/submit'
 */
submit.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\IncidentController::submit
 * @see app/Http/Controllers/IncidentController.php:92
 * @route '/incidents/{incident}/submit'
 */
    const submitForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\IncidentController::submit
 * @see app/Http/Controllers/IncidentController.php:92
 * @route '/incidents/{incident}/submit'
 */
        submitForm.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
/**
* @see \App\Http\Controllers\IncidentController::review
 * @see app/Http/Controllers/IncidentController.php:99
 * @route '/incidents/{incident}/review'
 */
export const review = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

review.definition = {
    methods: ["post"],
    url: '/incidents/{incident}/review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\IncidentController::review
 * @see app/Http/Controllers/IncidentController.php:99
 * @route '/incidents/{incident}/review'
 */
review.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return review.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\IncidentController::review
 * @see app/Http/Controllers/IncidentController.php:99
 * @route '/incidents/{incident}/review'
 */
review.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\IncidentController::review
 * @see app/Http/Controllers/IncidentController.php:99
 * @route '/incidents/{incident}/review'
 */
    const reviewForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: review.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\IncidentController::review
 * @see app/Http/Controllers/IncidentController.php:99
 * @route '/incidents/{incident}/review'
 */
        reviewForm.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: review.url(args, options),
            method: 'post',
        })
    
    review.form = reviewForm
/**
* @see \App\Http\Controllers\IncidentController::close
 * @see app/Http/Controllers/IncidentController.php:110
 * @route '/incidents/{incident}/close'
 */
export const close = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/incidents/{incident}/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\IncidentController::close
 * @see app/Http/Controllers/IncidentController.php:110
 * @route '/incidents/{incident}/close'
 */
close.url = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { incident: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { incident: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    incident: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return close.definition.url
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\IncidentController::close
 * @see app/Http/Controllers/IncidentController.php:110
 * @route '/incidents/{incident}/close'
 */
close.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\IncidentController::close
 * @see app/Http/Controllers/IncidentController.php:110
 * @route '/incidents/{incident}/close'
 */
    const closeForm = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: close.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\IncidentController::close
 * @see app/Http/Controllers/IncidentController.php:110
 * @route '/incidents/{incident}/close'
 */
        closeForm.post = (args: { incident: number | { id: number } } | [incident: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: close.url(args, options),
            method: 'post',
        })
    
    close.form = closeForm
const incidents = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
update: Object.assign(update, update),
submit: Object.assign(submit, submit),
review: Object.assign(review, review),
close: Object.assign(close, close),
}

export default incidents