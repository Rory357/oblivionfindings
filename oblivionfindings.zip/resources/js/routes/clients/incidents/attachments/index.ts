import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:98
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
export const store = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/incidents/{incident}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:98
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
store.url = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    incident: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:98
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
store.post = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:98
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
    const storeForm = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:98
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
        storeForm.post = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
export const download = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/incidents/{incident}/attachments/{attachment}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
download.url = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    incident: args[1],
                    attachment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return download.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{incident}', parsedArgs.incident.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
download.get = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
download.head = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
    const downloadForm = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
        downloadForm.get = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientIncidentController::download
 * @see app/Http/Controllers/ClientIncidentController.php:127
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
        downloadForm.head = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const attachments = {
    store: Object.assign(store, store),
download: Object.assign(download, download),
}

export default attachments