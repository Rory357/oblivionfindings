import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import administrations from './administrations'
/**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
export const show = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/mar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
show.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return show.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
show.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
show.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
    const showForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
        showForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientMarController::show
 * @see app/Http/Controllers/ClientMarController.php:15
 * @route '/clients/{client}/mar'
 */
        showForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
export const export_csv = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: export_csv.url(args, options),
    method: 'get',
})

export_csv.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/mar/export.csv',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
export_csv.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return export_csv.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
export_csv.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: export_csv.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
export_csv.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: export_csv.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
    const export_csvForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: export_csv.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
        export_csvForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: export_csv.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientMarController::export_csv
 * @see app/Http/Controllers/ClientMarController.php:71
 * @route '/clients/{client}/mar/export.csv'
 */
        export_csvForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: export_csv.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    export_csv.form = export_csvForm
const mar = {
    show: Object.assign(show, show),
export_csv: Object.assign(export_csv, export_csv),
administrations: Object.assign(administrations, administrations),
}

export default mar