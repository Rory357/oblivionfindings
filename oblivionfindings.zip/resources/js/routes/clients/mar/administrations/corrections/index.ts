import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationAdministrationCorrectionController::store
 * @see app/Http/Controllers/MedicationAdministrationCorrectionController.php:12
 * @route '/clients/{client}/mar/administrations/{administration}/corrections'
 */
export const store = (args: { client: number | { id: number }, administration: number | { id: number } } | [client: number | { id: number }, administration: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/mar/administrations/{administration}/corrections',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MedicationAdministrationCorrectionController::store
 * @see app/Http/Controllers/MedicationAdministrationCorrectionController.php:12
 * @route '/clients/{client}/mar/administrations/{administration}/corrections'
 */
store.url = (args: { client: number | { id: number }, administration: number | { id: number } } | [client: number | { id: number }, administration: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    administration: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                administration: typeof args.administration === 'object'
                ? args.administration.id
                : args.administration,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{administration}', parsedArgs.administration.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationAdministrationCorrectionController::store
 * @see app/Http/Controllers/MedicationAdministrationCorrectionController.php:12
 * @route '/clients/{client}/mar/administrations/{administration}/corrections'
 */
store.post = (args: { client: number | { id: number }, administration: number | { id: number } } | [client: number | { id: number }, administration: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MedicationAdministrationCorrectionController::store
 * @see app/Http/Controllers/MedicationAdministrationCorrectionController.php:12
 * @route '/clients/{client}/mar/administrations/{administration}/corrections'
 */
    const storeForm = (args: { client: number | { id: number }, administration: number | { id: number } } | [client: number | { id: number }, administration: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MedicationAdministrationCorrectionController::store
 * @see app/Http/Controllers/MedicationAdministrationCorrectionController.php:12
 * @route '/clients/{client}/mar/administrations/{administration}/corrections'
 */
        storeForm.post = (args: { client: number | { id: number }, administration: number | { id: number } } | [client: number | { id: number }, administration: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const corrections = {
    store: Object.assign(store, store),
}

export default corrections