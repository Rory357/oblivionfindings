import corrections from './corrections'
const administrations = {
    corrections: Object.assign(corrections, corrections),
}

export default administrations