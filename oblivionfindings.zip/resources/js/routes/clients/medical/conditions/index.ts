import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:607
 * @route '/clients/{client}/medical/conditions'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/conditions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:607
 * @route '/clients/{client}/medical/conditions'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:607
 * @route '/clients/{client}/medical/conditions'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:607
 * @route '/clients/{client}/medical/conditions'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:607
 * @route '/clients/{client}/medical/conditions'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:635
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
export const update = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/conditions/{condition}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:635
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
update.url = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    condition: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                condition: typeof args.condition === 'object'
                ? args.condition.id
                : args.condition,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{condition}', parsedArgs.condition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:635
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
update.put = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:635
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
    const updateForm = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:635
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
        updateForm.put = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:662
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
export const destroy = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/medical/conditions/{condition}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:662
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
destroy.url = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    condition: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                condition: typeof args.condition === 'object'
                ? args.condition.id
                : args.condition,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{condition}', parsedArgs.condition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:662
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
destroy.delete = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:662
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
    const destroyForm = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:662
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const conditions = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default conditions