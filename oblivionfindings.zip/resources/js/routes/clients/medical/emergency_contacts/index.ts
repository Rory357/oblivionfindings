import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/emergency-contacts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
export const update = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/emergency-contacts/{contact}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
update.url = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
update.put = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
    const updateForm = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
        updateForm.put = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
export const destroy = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/medical/emergency-contacts/{contact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
destroy.url = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
destroy.delete = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
    const destroyForm = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const emergency_contacts = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default emergency_contacts