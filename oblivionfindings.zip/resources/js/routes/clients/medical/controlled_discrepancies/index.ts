import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientMedicalController::close
 * @see app/Http/Controllers/ClientMedicalController.php:556
 * @route '/clients/{client}/medical/controlled-discrepancies/{discrepancy}/close'
 */
export const close = (args: { client: number | { id: number }, discrepancy: number | { id: number } } | [client: number | { id: number }, discrepancy: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

close.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/controlled-discrepancies/{discrepancy}/close',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::close
 * @see app/Http/Controllers/ClientMedicalController.php:556
 * @route '/clients/{client}/medical/controlled-discrepancies/{discrepancy}/close'
 */
close.url = (args: { client: number | { id: number }, discrepancy: number | { id: number } } | [client: number | { id: number }, discrepancy: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    discrepancy: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                discrepancy: typeof args.discrepancy === 'object'
                ? args.discrepancy.id
                : args.discrepancy,
                }

    return close.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{discrepancy}', parsedArgs.discrepancy.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::close
 * @see app/Http/Controllers/ClientMedicalController.php:556
 * @route '/clients/{client}/medical/controlled-discrepancies/{discrepancy}/close'
 */
close.post = (args: { client: number | { id: number }, discrepancy: number | { id: number } } | [client: number | { id: number }, discrepancy: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: close.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::close
 * @see app/Http/Controllers/ClientMedicalController.php:556
 * @route '/clients/{client}/medical/controlled-discrepancies/{discrepancy}/close'
 */
    const closeForm = (args: { client: number | { id: number }, discrepancy: number | { id: number } } | [client: number | { id: number }, discrepancy: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: close.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::close
 * @see app/Http/Controllers/ClientMedicalController.php:556
 * @route '/clients/{client}/medical/controlled-discrepancies/{discrepancy}/close'
 */
        closeForm.post = (args: { client: number | { id: number }, discrepancy: number | { id: number } } | [client: number | { id: number }, discrepancy: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: close.url(args, options),
            method: 'post',
        })
    
    close.form = closeForm
const controlled_discrepancies = {
    close: Object.assign(close, close),
}

export default controlled_discrepancies