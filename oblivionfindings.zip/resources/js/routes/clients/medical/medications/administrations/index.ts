import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
export const store = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/medications/{medication}/administrations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
store.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
store.post = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
    const storeForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
        storeForm.post = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const administrations = {
    store: Object.assign(store, store),
}

export default administrations