import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
import stock from './stock'
import administrations from './administrations'
/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/medications',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::store
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
export const update = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/medications/{medication}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
update.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
update.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
    const updateForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
        updateForm.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
export const destroy = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/medical/medications/{medication}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
destroy.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
destroy.delete = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
    const destroyForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::destroy
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const medications = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
stock: Object.assign(stock, stock),
administrations: Object.assign(administrations, administrations),
}

export default medications