import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
export const update = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/medications/{medication}/stock',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
update.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
update.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
    const updateForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::update
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
        updateForm.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const stock = {
    update: Object.assign(update, update),
}

export default stock