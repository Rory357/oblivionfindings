import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
import profile from './profile'
import medications from './medications'
import conditions from './conditions'
import emergency_contacts from './emergency_contacts'
import controlled_discrepancies from './controlled_discrepancies'
/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
export const show = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/medical',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
show.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return show.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
show.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
show.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
    const showForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
        showForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:22
 * @route '/clients/{client}/medical'
 */
        showForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const medical = {
    show: Object.assign(show, show),
profile: Object.assign(profile, profile),
medications: Object.assign(medications, medications),
conditions: Object.assign(conditions, conditions),
emergency_contacts: Object.assign(emergency_contacts, emergency_contacts),
controlled_discrepancies: Object.assign(controlled_discrepancies, controlled_discrepancies),
}

export default medical