import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
export const my = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/timeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
my.url = (options?: RouteQueryOptions) => {
    return my.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
my.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
my.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
    const myForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: my.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
        myForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineController::my
 * @see app/Http/Controllers/TimelineController.php:13
 * @route '/timeline'
 */
        myForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    my.form = myForm
/**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
export const staff = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staff.url(args, options),
    method: 'get',
})

staff.definition = {
    methods: ["get","head"],
    url: '/staff/{user}/timeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
staff.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return staff.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
staff.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staff.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
staff.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: staff.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
    const staffForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: staff.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
        staffForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staff.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineController::staff
 * @see app/Http/Controllers/TimelineController.php:21
 * @route '/staff/{user}/timeline'
 */
        staffForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staff.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    staff.form = staffForm
/**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
export const client = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(args, options),
    method: 'get',
})

client.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/timeline',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
client.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return client.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
client.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
client.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: client.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
    const clientForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: client.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
        clientForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimelineController::client
 * @see app/Http/Controllers/TimelineController.php:54
 * @route '/clients/{client}/timeline'
 */
        clientForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    client.form = clientForm
const timeline = {
    my: Object.assign(my, my),
staff: Object.assign(staff, staff),
client: Object.assign(client, client),
}

export default timeline