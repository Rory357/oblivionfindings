import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/integrations/unifi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\UnifiController::index
 * @see app/Http/Controllers/UnifiController.php:13
 * @route '/integrations/unifi'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\UnifiController::upsert
 * @see app/Http/Controllers/UnifiController.php:38
 * @route '/integrations/unifi/{site}'
 */
export const upsert = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upsert.url(args, options),
    method: 'post',
})

upsert.definition = {
    methods: ["post"],
    url: '/integrations/unifi/{site}',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UnifiController::upsert
 * @see app/Http/Controllers/UnifiController.php:38
 * @route '/integrations/unifi/{site}'
 */
upsert.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return upsert.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UnifiController::upsert
 * @see app/Http/Controllers/UnifiController.php:38
 * @route '/integrations/unifi/{site}'
 */
upsert.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: upsert.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UnifiController::upsert
 * @see app/Http/Controllers/UnifiController.php:38
 * @route '/integrations/unifi/{site}'
 */
    const upsertForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: upsert.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UnifiController::upsert
 * @see app/Http/Controllers/UnifiController.php:38
 * @route '/integrations/unifi/{site}'
 */
        upsertForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: upsert.url(args, options),
            method: 'post',
        })
    
    upsert.form = upsertForm
/**
* @see \App\Http\Controllers\UnifiController::sync
 * @see app/Http/Controllers/UnifiController.php:69
 * @route '/integrations/unifi/{site}/sync'
 */
export const sync = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

sync.definition = {
    methods: ["post"],
    url: '/integrations/unifi/{site}/sync',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\UnifiController::sync
 * @see app/Http/Controllers/UnifiController.php:69
 * @route '/integrations/unifi/{site}/sync'
 */
sync.url = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { site: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { site: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    site: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        site: typeof args.site === 'object'
                ? args.site.id
                : args.site,
                }

    return sync.definition.url
            .replace('{site}', parsedArgs.site.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\UnifiController::sync
 * @see app/Http/Controllers/UnifiController.php:69
 * @route '/integrations/unifi/{site}/sync'
 */
sync.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: sync.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\UnifiController::sync
 * @see app/Http/Controllers/UnifiController.php:69
 * @route '/integrations/unifi/{site}/sync'
 */
    const syncForm = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: sync.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\UnifiController::sync
 * @see app/Http/Controllers/UnifiController.php:69
 * @route '/integrations/unifi/{site}/sync'
 */
        syncForm.post = (args: { site: number | { id: number } } | [site: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: sync.url(args, options),
            method: 'post',
        })
    
    sync.form = syncForm
const unifi = {
    index: Object.assign(index, index),
upsert: Object.assign(upsert, upsert),
sync: Object.assign(sync, sync),
}

export default unifi