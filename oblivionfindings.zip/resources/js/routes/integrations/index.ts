import unifi from './unifi'
const integrations = {
    unifi: Object.assign(unifi, unifi),
}

export default integrations