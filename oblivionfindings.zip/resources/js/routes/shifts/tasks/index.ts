import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\ShiftTaskController::update
 * @see app/Http/Controllers/ShiftTaskController.php:11
 * @route '/shifts/{shift}/tasks/{task}'
 */
export const update = (args: { shift: number | { id: number }, task: number | { id: number } } | [shift: number | { id: number }, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/shifts/{shift}/tasks/{task}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\ShiftTaskController::update
 * @see app/Http/Controllers/ShiftTaskController.php:11
 * @route '/shifts/{shift}/tasks/{task}'
 */
update.url = (args: { shift: number | { id: number }, task: number | { id: number } } | [shift: number | { id: number }, task: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    shift: args[0],
                    task: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shift: typeof args.shift === 'object'
                ? args.shift.id
                : args.shift,
                                task: typeof args.task === 'object'
                ? args.task.id
                : args.task,
                }

    return update.definition.url
            .replace('{shift}', parsedArgs.shift.toString())
            .replace('{task}', parsedArgs.task.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftTaskController::update
 * @see app/Http/Controllers/ShiftTaskController.php:11
 * @route '/shifts/{shift}/tasks/{task}'
 */
update.patch = (args: { shift: number | { id: number }, task: number | { id: number } } | [shift: number | { id: number }, task: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ShiftTaskController::update
 * @see app/Http/Controllers/ShiftTaskController.php:11
 * @route '/shifts/{shift}/tasks/{task}'
 */
    const updateForm = (args: { shift: number | { id: number }, task: number | { id: number } } | [shift: number | { id: number }, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftTaskController::update
 * @see app/Http/Controllers/ShiftTaskController.php:11
 * @route '/shifts/{shift}/tasks/{task}'
 */
        updateForm.patch = (args: { shift: number | { id: number }, task: number | { id: number } } | [shift: number | { id: number }, task: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const tasks = {
    update: Object.assign(update, update),
}

export default tasks