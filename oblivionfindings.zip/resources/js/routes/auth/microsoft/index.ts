import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
export const redirect = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})

redirect.definition = {
    methods: ["get","head"],
    url: '/auth/microsoft/redirect',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
redirect.url = (options?: RouteQueryOptions) => {
    return redirect.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
redirect.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: redirect.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
redirect.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: redirect.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
    const redirectForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: redirect.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
        redirectForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirect.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\MicrosoftController::redirect
 * @see app/Http/Controllers/Auth/MicrosoftController.php:14
 * @route '/auth/microsoft/redirect'
 */
        redirectForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: redirect.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    redirect.form = redirectForm
/**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
export const callback = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})

callback.definition = {
    methods: ["get","head"],
    url: '/auth/microsoft/callback',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
callback.url = (options?: RouteQueryOptions) => {
    return callback.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
callback.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: callback.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
callback.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: callback.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
    const callbackForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: callback.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
        callbackForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: callback.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Auth\MicrosoftController::callback
 * @see app/Http/Controllers/Auth/MicrosoftController.php:21
 * @route '/auth/microsoft/callback'
 */
        callbackForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: callback.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    callback.form = callbackForm
const microsoft = {
    redirect: Object.assign(redirect, redirect),
callback: Object.assign(callback, callback),
}

export default microsoft