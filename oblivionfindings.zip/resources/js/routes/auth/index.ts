import google from './google'
import microsoft from './microsoft'
const auth = {
    google: Object.assign(google, google),
microsoft: Object.assign(microsoft, microsoft),
}

export default auth