import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
export const index = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/staff/{user}/availability',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
index.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return index.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
index.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
index.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
    const indexForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
        indexForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StaffAvailabilityController::index
 * @see app/Http/Controllers/StaffAvailabilityController.php:25
 * @route '/staff/{user}/availability'
 */
        indexForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StaffAvailabilityController::store
 * @see app/Http/Controllers/StaffAvailabilityController.php:48
 * @route '/staff/{user}/availability'
 */
export const store = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/staff/{user}/availability',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StaffAvailabilityController::store
 * @see app/Http/Controllers/StaffAvailabilityController.php:48
 * @route '/staff/{user}/availability'
 */
store.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return store.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffAvailabilityController::store
 * @see app/Http/Controllers/StaffAvailabilityController.php:48
 * @route '/staff/{user}/availability'
 */
store.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StaffAvailabilityController::store
 * @see app/Http/Controllers/StaffAvailabilityController.php:48
 * @route '/staff/{user}/availability'
 */
    const storeForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StaffAvailabilityController::store
 * @see app/Http/Controllers/StaffAvailabilityController.php:48
 * @route '/staff/{user}/availability'
 */
        storeForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\StaffAvailabilityController::destroy
 * @see app/Http/Controllers/StaffAvailabilityController.php:63
 * @route '/staff/{user}/availability/{availability}'
 */
export const destroy = (args: { user: number | { id: number }, availability: number | { id: number } } | [user: number | { id: number }, availability: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/staff/{user}/availability/{availability}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\StaffAvailabilityController::destroy
 * @see app/Http/Controllers/StaffAvailabilityController.php:63
 * @route '/staff/{user}/availability/{availability}'
 */
destroy.url = (args: { user: number | { id: number }, availability: number | { id: number } } | [user: number | { id: number }, availability: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                    availability: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                availability: typeof args.availability === 'object'
                ? args.availability.id
                : args.availability,
                }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace('{availability}', parsedArgs.availability.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffAvailabilityController::destroy
 * @see app/Http/Controllers/StaffAvailabilityController.php:63
 * @route '/staff/{user}/availability/{availability}'
 */
destroy.delete = (args: { user: number | { id: number }, availability: number | { id: number } } | [user: number | { id: number }, availability: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\StaffAvailabilityController::destroy
 * @see app/Http/Controllers/StaffAvailabilityController.php:63
 * @route '/staff/{user}/availability/{availability}'
 */
    const destroyForm = (args: { user: number | { id: number }, availability: number | { id: number } } | [user: number | { id: number }, availability: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StaffAvailabilityController::destroy
 * @see app/Http/Controllers/StaffAvailabilityController.php:63
 * @route '/staff/{user}/availability/{availability}'
 */
        destroyForm.delete = (args: { user: number | { id: number }, availability: number | { id: number } } | [user: number | { id: number }, availability: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const availability = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default availability