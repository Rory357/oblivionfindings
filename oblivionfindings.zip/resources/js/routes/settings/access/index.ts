import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\AccessController::update
 * @see app/Http/Controllers/Settings/AccessController.php:45
 * @route '/settings/access/{target}'
 */
export const update = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/access/{target}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\AccessController::update
 * @see app/Http/Controllers/Settings/AccessController.php:45
 * @route '/settings/access/{target}'
 */
update.url = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { target: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { target: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    target: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        target: typeof args.target === 'object'
                ? args.target.id
                : args.target,
                }

    return update.definition.url
            .replace('{target}', parsedArgs.target.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\AccessController::update
 * @see app/Http/Controllers/Settings/AccessController.php:45
 * @route '/settings/access/{target}'
 */
update.put = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Settings\AccessController::update
 * @see app/Http/Controllers/Settings/AccessController.php:45
 * @route '/settings/access/{target}'
 */
    const updateForm = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\AccessController::update
 * @see app/Http/Controllers/Settings/AccessController.php:45
 * @route '/settings/access/{target}'
 */
        updateForm.put = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Settings\AccessController::approve
 * @see app/Http/Controllers/Settings/AccessController.php:92
 * @route '/settings/access/{target}/approve'
 */
export const approve = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/settings/access/{target}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\AccessController::approve
 * @see app/Http/Controllers/Settings/AccessController.php:92
 * @route '/settings/access/{target}/approve'
 */
approve.url = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { target: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { target: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    target: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        target: typeof args.target === 'object'
                ? args.target.id
                : args.target,
                }

    return approve.definition.url
            .replace('{target}', parsedArgs.target.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\AccessController::approve
 * @see app/Http/Controllers/Settings/AccessController.php:92
 * @route '/settings/access/{target}/approve'
 */
approve.post = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\AccessController::approve
 * @see app/Http/Controllers/Settings/AccessController.php:92
 * @route '/settings/access/{target}/approve'
 */
    const approveForm = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\AccessController::approve
 * @see app/Http/Controllers/Settings/AccessController.php:92
 * @route '/settings/access/{target}/approve'
 */
        approveForm.post = (args: { target: number | { id: number } } | [target: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
const access = {
    update: Object.assign(update, update),
approve: Object.assign(approve, approve),
}

export default access