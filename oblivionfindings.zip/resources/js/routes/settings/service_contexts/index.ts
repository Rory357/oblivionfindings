import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\ServiceContextController::store
 * @see app/Http/Controllers/Settings/ServiceContextController.php:52
 * @route '/settings/service-contexts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/settings/service-contexts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::store
 * @see app/Http/Controllers/Settings/ServiceContextController.php:52
 * @route '/settings/service-contexts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::store
 * @see app/Http/Controllers/Settings/ServiceContextController.php:52
 * @route '/settings/service-contexts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\ServiceContextController::store
 * @see app/Http/Controllers/Settings/ServiceContextController.php:52
 * @route '/settings/service-contexts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\ServiceContextController::store
 * @see app/Http/Controllers/Settings/ServiceContextController.php:52
 * @route '/settings/service-contexts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Settings\ServiceContextController::defaultMethod
 * @see app/Http/Controllers/Settings/ServiceContextController.php:71
 * @route '/settings/service-contexts/default'
 */
export const defaultMethod = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: defaultMethod.url(options),
    method: 'post',
})

defaultMethod.definition = {
    methods: ["post"],
    url: '/settings/service-contexts/default',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::defaultMethod
 * @see app/Http/Controllers/Settings/ServiceContextController.php:71
 * @route '/settings/service-contexts/default'
 */
defaultMethod.url = (options?: RouteQueryOptions) => {
    return defaultMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::defaultMethod
 * @see app/Http/Controllers/Settings/ServiceContextController.php:71
 * @route '/settings/service-contexts/default'
 */
defaultMethod.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: defaultMethod.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\ServiceContextController::defaultMethod
 * @see app/Http/Controllers/Settings/ServiceContextController.php:71
 * @route '/settings/service-contexts/default'
 */
    const defaultMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: defaultMethod.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\ServiceContextController::defaultMethod
 * @see app/Http/Controllers/Settings/ServiceContextController.php:71
 * @route '/settings/service-contexts/default'
 */
        defaultMethodForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: defaultMethod.url(options),
            method: 'post',
        })
    
    defaultMethod.form = defaultMethodForm
/**
* @see \App\Http\Controllers\Settings\ServiceContextController::update
 * @see app/Http/Controllers/Settings/ServiceContextController.php:97
 * @route '/settings/service-contexts/{serviceContext}'
 */
export const update = (args: { serviceContext: number | { id: number } } | [serviceContext: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/service-contexts/{serviceContext}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::update
 * @see app/Http/Controllers/Settings/ServiceContextController.php:97
 * @route '/settings/service-contexts/{serviceContext}'
 */
update.url = (args: { serviceContext: number | { id: number } } | [serviceContext: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { serviceContext: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { serviceContext: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    serviceContext: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        serviceContext: typeof args.serviceContext === 'object'
                ? args.serviceContext.id
                : args.serviceContext,
                }

    return update.definition.url
            .replace('{serviceContext}', parsedArgs.serviceContext.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::update
 * @see app/Http/Controllers/Settings/ServiceContextController.php:97
 * @route '/settings/service-contexts/{serviceContext}'
 */
update.put = (args: { serviceContext: number | { id: number } } | [serviceContext: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Settings\ServiceContextController::update
 * @see app/Http/Controllers/Settings/ServiceContextController.php:97
 * @route '/settings/service-contexts/{serviceContext}'
 */
    const updateForm = (args: { serviceContext: number | { id: number } } | [serviceContext: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\ServiceContextController::update
 * @see app/Http/Controllers/Settings/ServiceContextController.php:97
 * @route '/settings/service-contexts/{serviceContext}'
 */
        updateForm.put = (args: { serviceContext: number | { id: number } } | [serviceContext: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const service_contexts = {
    store: Object.assign(store, store),
default: Object.assign(defaultMethod, defaultMethod),
update: Object.assign(update, update),
}

export default service_contexts