import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import accessCf53c1 from './access'
import terminologyCe50a9 from './terminology'
import branding3fced6 from './branding'
import service_contexts3a7e4c from './service_contexts'
/**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
export const access = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: access.url(options),
    method: 'get',
})

access.definition = {
    methods: ["get","head"],
    url: '/settings/access',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
access.url = (options?: RouteQueryOptions) => {
    return access.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
access.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: access.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
access.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: access.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
    const accessForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: access.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
        accessForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: access.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\AccessController::access
 * @see app/Http/Controllers/Settings/AccessController.php:13
 * @route '/settings/access'
 */
        accessForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: access.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    access.form = accessForm
/**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
export const terminology = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terminology.url(options),
    method: 'get',
})

terminology.definition = {
    methods: ["get","head"],
    url: '/settings/terminology',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
terminology.url = (options?: RouteQueryOptions) => {
    return terminology.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
terminology.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: terminology.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
terminology.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: terminology.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
    const terminologyForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: terminology.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
        terminologyForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: terminology.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\TerminologyController::terminology
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
        terminologyForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: terminology.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    terminology.form = terminologyForm
/**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
export const branding = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: branding.url(options),
    method: 'get',
})

branding.definition = {
    methods: ["get","head"],
    url: '/settings/branding',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
branding.url = (options?: RouteQueryOptions) => {
    return branding.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
branding.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: branding.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
branding.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: branding.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
    const brandingForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: branding.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
        brandingForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: branding.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\BrandingController::branding
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
        brandingForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: branding.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    branding.form = brandingForm
/**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
export const service_contexts = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: service_contexts.url(options),
    method: 'get',
})

service_contexts.definition = {
    methods: ["get","head"],
    url: '/settings/service-contexts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
service_contexts.url = (options?: RouteQueryOptions) => {
    return service_contexts.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
service_contexts.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: service_contexts.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
service_contexts.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: service_contexts.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
    const service_contextsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: service_contexts.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
        service_contextsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: service_contexts.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\ServiceContextController::service_contexts
 * @see app/Http/Controllers/Settings/ServiceContextController.php:14
 * @route '/settings/service-contexts'
 */
        service_contextsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: service_contexts.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    service_contexts.form = service_contextsForm
const settings = {
    access: Object.assign(access, accessCf53c1),
terminology: Object.assign(terminology, terminologyCe50a9),
branding: Object.assign(branding, branding3fced6),
service_contexts: Object.assign(service_contexts, service_contexts3a7e4c),
}

export default settings