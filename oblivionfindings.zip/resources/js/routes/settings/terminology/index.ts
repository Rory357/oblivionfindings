import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/terminology',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const terminology = {
    update: Object.assign(update, update),
}

export default terminology