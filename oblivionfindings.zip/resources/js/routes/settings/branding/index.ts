import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/settings/branding',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const branding = {
    update: Object.assign(update, update),
}

export default branding