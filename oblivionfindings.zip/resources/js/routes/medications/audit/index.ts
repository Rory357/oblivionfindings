import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/medications/audit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/medications/audit/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationAuditController::exportMethod
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const audit = {
    index: Object.assign(index, index),
export: Object.assign(exportMethod, exportMethod),
}

export default audit