import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/emergency-access',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\EmergencyAccessController::index
 * @see app/Http/Controllers/EmergencyAccessController.php:17
 * @route '/emergency-access'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const emergency_access = {
    index: Object.assign(index, index),
}

export default emergency_access