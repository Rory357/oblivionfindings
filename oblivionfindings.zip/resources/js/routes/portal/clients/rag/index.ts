import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
export const ask = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask.url(args, options),
    method: 'post',
})

ask.definition = {
    methods: ["post"],
    url: '/portal/clients/{client}/rag/ask',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
ask.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return ask.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
ask.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
    const askForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ask.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
        askForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ask.url(args, options),
            method: 'post',
        })
    
    ask.form = askForm
const rag = {
    ask: Object.assign(ask, ask),
}

export default rag