import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
export const download = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})

download.definition = {
    methods: ["get","head"],
    url: '/portal/clients/{client}/documents/{document}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
download.url = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    document: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return download.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
download.get = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: download.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
download.head = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: download.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
    const downloadForm = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: download.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
        downloadForm.get = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:146
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
        downloadForm.head = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: download.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    download.form = downloadForm
const documents = {
    download: Object.assign(download, download),
}

export default documents