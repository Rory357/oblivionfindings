import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/portal/summaries/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
const summaries = {
    generate: Object.assign(generate, generate),
}

export default summaries