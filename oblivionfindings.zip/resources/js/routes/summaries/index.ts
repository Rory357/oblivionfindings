import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
 * @see routes/web.php:99
 * @route '/summaries'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/summaries',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:99
 * @route '/summaries'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:99
 * @route '/summaries'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:99
 * @route '/summaries'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:99
 * @route '/summaries'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:99
 * @route '/summaries'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:99
 * @route '/summaries'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
export const me = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

me.definition = {
    methods: ["get","head"],
    url: '/summaries/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
me.url = (options?: RouteQueryOptions) => {
    return me.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
me.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
me.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
    const meForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: me.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
        meForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SummaryController::me
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
        meForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    me.form = meForm
/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
export const staff = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staff.url(args, options),
    method: 'get',
})

staff.definition = {
    methods: ["get","head"],
    url: '/summaries/staff/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
staff.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return staff.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
staff.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staff.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
staff.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: staff.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
    const staffForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: staff.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
        staffForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staff.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
        staffForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staff.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    staff.form = staffForm
/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
export const client = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(args, options),
    method: 'get',
})

client.definition = {
    methods: ["get","head"],
    url: '/summaries/clients/{client}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
client.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return client.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
client.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
client.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: client.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
    const clientForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: client.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
        clientForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
        clientForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    client.form = clientForm
/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
export const generate = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

generate.definition = {
    methods: ["post"],
    url: '/summaries/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
generate.url = (options?: RouteQueryOptions) => {
    return generate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
generate.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
    const generateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
        generateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate.url(options),
            method: 'post',
        })
    
    generate.form = generateForm
const summaries = {
    home: Object.assign(home, home),
me: Object.assign(me, me),
staff: Object.assign(staff, staff),
client: Object.assign(client, client),
generate: Object.assign(generate, generate),
}

export default summaries