import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import medications63c483 from './medications'
/**
 * @see routes/web.php:161
 * @route '/reports'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reports',
} satisfies RouteDefinition<["get","head"]>

/**
 * @see routes/web.php:161
 * @route '/reports'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
 * @see routes/web.php:161
 * @route '/reports'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
 * @see routes/web.php:161
 * @route '/reports'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
 * @see routes/web.php:161
 * @route '/reports'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
 * @see routes/web.php:161
 * @route '/reports'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
 * @see routes/web.php:161
 * @route '/reports'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
export const medications = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: medications.url(options),
    method: 'get',
})

medications.definition = {
    methods: ["get","head"],
    url: '/reports/medications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
medications.url = (options?: RouteQueryOptions) => {
    return medications.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
medications.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: medications.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
medications.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: medications.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
    const medicationsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: medications.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
        medicationsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: medications.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsReportController::medications
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
        medicationsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: medications.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    medications.form = medicationsForm
const reports = {
    index: Object.assign(index, index),
medications: Object.assign(medications, medications63c483),
}

export default reports