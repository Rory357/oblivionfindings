import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
export const export_mar = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: export_mar.url(options),
    method: 'get',
})

export_mar.definition = {
    methods: ["get","head"],
    url: '/reports/medications/export-mar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
export_mar.url = (options?: RouteQueryOptions) => {
    return export_mar.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
export_mar.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: export_mar.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
export_mar.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: export_mar.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
    const export_marForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: export_mar.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
        export_marForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: export_mar.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsReportController::export_mar
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
        export_marForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: export_mar.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    export_mar.form = export_marForm
/**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
export const export_discrepancies = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: export_discrepancies.url(options),
    method: 'get',
})

export_discrepancies.definition = {
    methods: ["get","head"],
    url: '/reports/medications/export-controlled-discrepancies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
export_discrepancies.url = (options?: RouteQueryOptions) => {
    return export_discrepancies.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
export_discrepancies.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: export_discrepancies.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
export_discrepancies.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: export_discrepancies.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
    const export_discrepanciesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: export_discrepancies.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
        export_discrepanciesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: export_discrepancies.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsReportController::export_discrepancies
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
        export_discrepanciesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: export_discrepancies.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    export_discrepancies.form = export_discrepanciesForm
const medications = {
    export_mar: Object.assign(export_mar, export_mar),
export_discrepancies: Object.assign(export_discrepancies, export_discrepancies),
}

export default medications