import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CalendarController::store
 * @see app/Http/Controllers/CalendarController.php:107
 * @route '/calendar/shifts'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/calendar/shifts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CalendarController::store
 * @see app/Http/Controllers/CalendarController.php:107
 * @route '/calendar/shifts'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CalendarController::store
 * @see app/Http/Controllers/CalendarController.php:107
 * @route '/calendar/shifts'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CalendarController::store
 * @see app/Http/Controllers/CalendarController.php:107
 * @route '/calendar/shifts'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CalendarController::store
 * @see app/Http/Controllers/CalendarController.php:107
 * @route '/calendar/shifts'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CalendarController::update
 * @see app/Http/Controllers/CalendarController.php:165
 * @route '/calendar/shifts/{shift}'
 */
export const update = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

update.definition = {
    methods: ["patch"],
    url: '/calendar/shifts/{shift}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CalendarController::update
 * @see app/Http/Controllers/CalendarController.php:165
 * @route '/calendar/shifts/{shift}'
 */
update.url = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shift: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { shift: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    shift: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shift: typeof args.shift === 'object'
                ? args.shift.id
                : args.shift,
                }

    return update.definition.url
            .replace('{shift}', parsedArgs.shift.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CalendarController::update
 * @see app/Http/Controllers/CalendarController.php:165
 * @route '/calendar/shifts/{shift}'
 */
update.patch = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CalendarController::update
 * @see app/Http/Controllers/CalendarController.php:165
 * @route '/calendar/shifts/{shift}'
 */
    const updateForm = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CalendarController::update
 * @see app/Http/Controllers/CalendarController.php:165
 * @route '/calendar/shifts/{shift}'
 */
        updateForm.patch = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const shifts = {
    store: Object.assign(store, store),
update: Object.assign(update, update),
}

export default shifts