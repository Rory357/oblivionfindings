import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
export const index = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/staff/{user}/credentials',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
index.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return index.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
index.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
index.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
    const indexForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
        indexForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\StaffCredentialController::index
 * @see app/Http/Controllers/StaffCredentialController.php:28
 * @route '/staff/{user}/credentials'
 */
        indexForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\StaffCredentialController::store
 * @see app/Http/Controllers/StaffCredentialController.php:51
 * @route '/staff/{user}/credentials'
 */
export const store = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/staff/{user}/credentials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\StaffCredentialController::store
 * @see app/Http/Controllers/StaffCredentialController.php:51
 * @route '/staff/{user}/credentials'
 */
store.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return store.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffCredentialController::store
 * @see app/Http/Controllers/StaffCredentialController.php:51
 * @route '/staff/{user}/credentials'
 */
store.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\StaffCredentialController::store
 * @see app/Http/Controllers/StaffCredentialController.php:51
 * @route '/staff/{user}/credentials'
 */
    const storeForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StaffCredentialController::store
 * @see app/Http/Controllers/StaffCredentialController.php:51
 * @route '/staff/{user}/credentials'
 */
        storeForm.post = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\StaffCredentialController::update
 * @see app/Http/Controllers/StaffCredentialController.php:75
 * @route '/staff/{user}/credentials/{credential}'
 */
export const update = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/staff/{user}/credentials/{credential}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\StaffCredentialController::update
 * @see app/Http/Controllers/StaffCredentialController.php:75
 * @route '/staff/{user}/credentials/{credential}'
 */
update.url = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                    credential: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                credential: typeof args.credential === 'object'
                ? args.credential.id
                : args.credential,
                }

    return update.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace('{credential}', parsedArgs.credential.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffCredentialController::update
 * @see app/Http/Controllers/StaffCredentialController.php:75
 * @route '/staff/{user}/credentials/{credential}'
 */
update.put = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\StaffCredentialController::update
 * @see app/Http/Controllers/StaffCredentialController.php:75
 * @route '/staff/{user}/credentials/{credential}'
 */
    const updateForm = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StaffCredentialController::update
 * @see app/Http/Controllers/StaffCredentialController.php:75
 * @route '/staff/{user}/credentials/{credential}'
 */
        updateForm.put = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\StaffCredentialController::destroy
 * @see app/Http/Controllers/StaffCredentialController.php:100
 * @route '/staff/{user}/credentials/{credential}'
 */
export const destroy = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/staff/{user}/credentials/{credential}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\StaffCredentialController::destroy
 * @see app/Http/Controllers/StaffCredentialController.php:100
 * @route '/staff/{user}/credentials/{credential}'
 */
destroy.url = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                    credential: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                                credential: typeof args.credential === 'object'
                ? args.credential.id
                : args.credential,
                }

    return destroy.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace('{credential}', parsedArgs.credential.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\StaffCredentialController::destroy
 * @see app/Http/Controllers/StaffCredentialController.php:100
 * @route '/staff/{user}/credentials/{credential}'
 */
destroy.delete = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\StaffCredentialController::destroy
 * @see app/Http/Controllers/StaffCredentialController.php:100
 * @route '/staff/{user}/credentials/{credential}'
 */
    const destroyForm = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\StaffCredentialController::destroy
 * @see app/Http/Controllers/StaffCredentialController.php:100
 * @route '/staff/{user}/credentials/{credential}'
 */
        destroyForm.delete = (args: { user: number | { id: number }, credential: number | { id: number } } | [user: number | { id: number }, credential: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const StaffCredentialController = { index, store, update, destroy }

export default StaffCredentialController