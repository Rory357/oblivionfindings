import GoogleController from './GoogleController'
import MicrosoftController from './MicrosoftController'
const Auth = {
    GoogleController: Object.assign(GoogleController, GoogleController),
MicrosoftController: Object.assign(MicrosoftController, MicrosoftController),
}

export default Auth