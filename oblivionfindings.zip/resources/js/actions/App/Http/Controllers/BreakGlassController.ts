import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\BreakGlassController::store
 * @see app/Http/Controllers/BreakGlassController.php:12
 * @route '/clients/{client}/break-glass'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/break-glass',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\BreakGlassController::store
 * @see app/Http/Controllers/BreakGlassController.php:12
 * @route '/clients/{client}/break-glass'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BreakGlassController::store
 * @see app/Http/Controllers/BreakGlassController.php:12
 * @route '/clients/{client}/break-glass'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\BreakGlassController::store
 * @see app/Http/Controllers/BreakGlassController.php:12
 * @route '/clients/{client}/break-glass'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BreakGlassController::store
 * @see app/Http/Controllers/BreakGlassController.php:12
 * @route '/clients/{client}/break-glass'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\BreakGlassController::destroy
 * @see app/Http/Controllers/BreakGlassController.php:41
 * @route '/clients/{client}/break-glass/{access}'
 */
export const destroy = (args: { client: number | { id: number }, access: number | { id: number } } | [client: number | { id: number }, access: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/break-glass/{access}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\BreakGlassController::destroy
 * @see app/Http/Controllers/BreakGlassController.php:41
 * @route '/clients/{client}/break-glass/{access}'
 */
destroy.url = (args: { client: number | { id: number }, access: number | { id: number } } | [client: number | { id: number }, access: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    access: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                access: typeof args.access === 'object'
                ? args.access.id
                : args.access,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{access}', parsedArgs.access.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\BreakGlassController::destroy
 * @see app/Http/Controllers/BreakGlassController.php:41
 * @route '/clients/{client}/break-glass/{access}'
 */
destroy.delete = (args: { client: number | { id: number }, access: number | { id: number } } | [client: number | { id: number }, access: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\BreakGlassController::destroy
 * @see app/Http/Controllers/BreakGlassController.php:41
 * @route '/clients/{client}/break-glass/{access}'
 */
    const destroyForm = (args: { client: number | { id: number }, access: number | { id: number } } | [client: number | { id: number }, access: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\BreakGlassController::destroy
 * @see app/Http/Controllers/BreakGlassController.php:41
 * @route '/clients/{client}/break-glass/{access}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, access: number | { id: number } } | [client: number | { id: number }, access: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const BreakGlassController = { store, destroy }

export default BreakGlassController