import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/calendar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CalendarController::index
 * @see app/Http/Controllers/CalendarController.php:15
 * @route '/calendar'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
export const events = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})

events.definition = {
    methods: ["get","head"],
    url: '/calendar/events',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
events.url = (options?: RouteQueryOptions) => {
    return events.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
events.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: events.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
events.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: events.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
    const eventsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: events.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
        eventsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: events.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CalendarController::events
 * @see app/Http/Controllers/CalendarController.php:45
 * @route '/calendar/events'
 */
        eventsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: events.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    events.form = eventsForm
/**
* @see \App\Http\Controllers\CalendarController::storeShift
 * @see app/Http/Controllers/CalendarController.php:102
 * @route '/calendar/shifts'
 */
export const storeShift = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeShift.url(options),
    method: 'post',
})

storeShift.definition = {
    methods: ["post"],
    url: '/calendar/shifts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CalendarController::storeShift
 * @see app/Http/Controllers/CalendarController.php:102
 * @route '/calendar/shifts'
 */
storeShift.url = (options?: RouteQueryOptions) => {
    return storeShift.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CalendarController::storeShift
 * @see app/Http/Controllers/CalendarController.php:102
 * @route '/calendar/shifts'
 */
storeShift.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeShift.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CalendarController::storeShift
 * @see app/Http/Controllers/CalendarController.php:102
 * @route '/calendar/shifts'
 */
    const storeShiftForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeShift.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CalendarController::storeShift
 * @see app/Http/Controllers/CalendarController.php:102
 * @route '/calendar/shifts'
 */
        storeShiftForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeShift.url(options),
            method: 'post',
        })
    
    storeShift.form = storeShiftForm
/**
* @see \App\Http\Controllers\CalendarController::updateShift
 * @see app/Http/Controllers/CalendarController.php:160
 * @route '/calendar/shifts/{shift}'
 */
export const updateShift = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateShift.url(args, options),
    method: 'patch',
})

updateShift.definition = {
    methods: ["patch"],
    url: '/calendar/shifts/{shift}',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\CalendarController::updateShift
 * @see app/Http/Controllers/CalendarController.php:160
 * @route '/calendar/shifts/{shift}'
 */
updateShift.url = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { shift: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { shift: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    shift: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        shift: typeof args.shift === 'object'
                ? args.shift.id
                : args.shift,
                }

    return updateShift.definition.url
            .replace('{shift}', parsedArgs.shift.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CalendarController::updateShift
 * @see app/Http/Controllers/CalendarController.php:160
 * @route '/calendar/shifts/{shift}'
 */
updateShift.patch = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: updateShift.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\CalendarController::updateShift
 * @see app/Http/Controllers/CalendarController.php:160
 * @route '/calendar/shifts/{shift}'
 */
    const updateShiftForm = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateShift.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CalendarController::updateShift
 * @see app/Http/Controllers/CalendarController.php:160
 * @route '/calendar/shifts/{shift}'
 */
        updateShiftForm.patch = (args: { shift: number | { id: number } } | [shift: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateShift.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateShift.form = updateShiftForm
const CalendarController = { index, events, storeShift, updateShift }

export default CalendarController