import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AnnouncementInboxController::markRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
export const markRead = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markRead.url(args, options),
    method: 'post',
})

markRead.definition = {
    methods: ["post"],
    url: '/inbox/announcements/{announcement}/read',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AnnouncementInboxController::markRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
markRead.url = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { announcement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { announcement: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    announcement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        announcement: typeof args.announcement === 'object'
                ? args.announcement.id
                : args.announcement,
                }

    return markRead.definition.url
            .replace('{announcement}', parsedArgs.announcement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\AnnouncementInboxController::markRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
markRead.post = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markRead.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AnnouncementInboxController::markRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
    const markReadForm = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markRead.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AnnouncementInboxController::markRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:10
 * @route '/inbox/announcements/{announcement}/read'
 */
        markReadForm.post = (args: { announcement: number | { id: number } } | [announcement: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markRead.url(args, options),
            method: 'post',
        })
    
    markRead.form = markReadForm
/**
* @see \App\Http\Controllers\AnnouncementInboxController::markAllRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
export const markAllRead = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

markAllRead.definition = {
    methods: ["post"],
    url: '/inbox/announcements/read-all',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AnnouncementInboxController::markAllRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
markAllRead.url = (options?: RouteQueryOptions) => {
    return markAllRead.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AnnouncementInboxController::markAllRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
markAllRead.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: markAllRead.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AnnouncementInboxController::markAllRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
    const markAllReadForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: markAllRead.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AnnouncementInboxController::markAllRead
 * @see app/Http/Controllers/AnnouncementInboxController.php:26
 * @route '/inbox/announcements/read-all'
 */
        markAllReadForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: markAllRead.url(options),
            method: 'post',
        })
    
    markAllRead.form = markAllReadForm
const AnnouncementInboxController = { markRead, markAllRead }

export default AnnouncementInboxController