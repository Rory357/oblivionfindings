import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/timesheets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimesheetController::index
 * @see app/Http/Controllers/TimesheetController.php:12
 * @route '/timesheets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/timesheets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimesheetController::create
 * @see app/Http/Controllers/TimesheetController.php:49
 * @route '/timesheets/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\TimesheetController::store
 * @see app/Http/Controllers/TimesheetController.php:73
 * @route '/timesheets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/timesheets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TimesheetController::store
 * @see app/Http/Controllers/TimesheetController.php:73
 * @route '/timesheets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimesheetController::store
 * @see app/Http/Controllers/TimesheetController.php:73
 * @route '/timesheets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TimesheetController::store
 * @see app/Http/Controllers/TimesheetController.php:73
 * @route '/timesheets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimesheetController::store
 * @see app/Http/Controllers/TimesheetController.php:73
 * @route '/timesheets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
export const edit = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/timesheets/{timesheet}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
edit.url = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timesheet: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timesheet: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timesheet: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timesheet: typeof args.timesheet === 'object'
                ? args.timesheet.id
                : args.timesheet,
                }

    return edit.definition.url
            .replace('{timesheet}', parsedArgs.timesheet.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
edit.get = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
edit.head = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
    const editForm = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
        editForm.get = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TimesheetController::edit
 * @see app/Http/Controllers/TimesheetController.php:116
 * @route '/timesheets/{timesheet}/edit'
 */
        editForm.head = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\TimesheetController::update
 * @see app/Http/Controllers/TimesheetController.php:135
 * @route '/timesheets/{timesheet}'
 */
export const update = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/timesheets/{timesheet}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TimesheetController::update
 * @see app/Http/Controllers/TimesheetController.php:135
 * @route '/timesheets/{timesheet}'
 */
update.url = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { timesheet: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { timesheet: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    timesheet: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        timesheet: typeof args.timesheet === 'object'
                ? args.timesheet.id
                : args.timesheet,
                }

    return update.definition.url
            .replace('{timesheet}', parsedArgs.timesheet.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TimesheetController::update
 * @see app/Http/Controllers/TimesheetController.php:135
 * @route '/timesheets/{timesheet}'
 */
update.put = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TimesheetController::update
 * @see app/Http/Controllers/TimesheetController.php:135
 * @route '/timesheets/{timesheet}'
 */
    const updateForm = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TimesheetController::update
 * @see app/Http/Controllers/TimesheetController.php:135
 * @route '/timesheets/{timesheet}'
 */
        updateForm.put = (args: { timesheet: number | { id: number } } | [timesheet: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const TimesheetController = { index, create, store, edit, update }

export default TimesheetController