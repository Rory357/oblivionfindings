import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/medications/audit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationAuditController::index
 * @see app/Http/Controllers/MedicationAuditController.php:25
 * @route '/medications/audit'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/medications/audit/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
    const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
        exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationAuditController::exportCsv
 * @see app/Http/Controllers/MedicationAuditController.php:73
 * @route '/medications/audit/export'
 */
        exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportCsv.form = exportCsvForm
const MedicationAuditController = { index, exportCsv }

export default MedicationAuditController