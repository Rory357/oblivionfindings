import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
const downloadec5f06f68600e41724813ea23282f47b = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadec5f06f68600e41724813ea23282f47b.url(args, options),
    method: 'get',
})

downloadec5f06f68600e41724813ea23282f47b.definition = {
    methods: ["get","head"],
    url: '/portal/clients/{client}/documents/{document}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
downloadec5f06f68600e41724813ea23282f47b.url = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    document: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return downloadec5f06f68600e41724813ea23282f47b.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
downloadec5f06f68600e41724813ea23282f47b.get = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadec5f06f68600e41724813ea23282f47b.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
downloadec5f06f68600e41724813ea23282f47b.head = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadec5f06f68600e41724813ea23282f47b.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
    const downloadec5f06f68600e41724813ea23282f47bForm = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadec5f06f68600e41724813ea23282f47b.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
        downloadec5f06f68600e41724813ea23282f47bForm.get = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadec5f06f68600e41724813ea23282f47b.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/portal/clients/{client}/documents/{document}/download'
 */
        downloadec5f06f68600e41724813ea23282f47bForm.head = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadec5f06f68600e41724813ea23282f47b.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadec5f06f68600e41724813ea23282f47b.form = downloadec5f06f68600e41724813ea23282f47bForm
    /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
const downloada1dfea9b6abafd14cb80b46b3a53f1af = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloada1dfea9b6abafd14cb80b46b3a53f1af.url(args, options),
    method: 'get',
})

downloada1dfea9b6abafd14cb80b46b3a53f1af.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/documents/{document}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
downloada1dfea9b6abafd14cb80b46b3a53f1af.url = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    document: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return downloada1dfea9b6abafd14cb80b46b3a53f1af.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
downloada1dfea9b6abafd14cb80b46b3a53f1af.get = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloada1dfea9b6abafd14cb80b46b3a53f1af.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
downloada1dfea9b6abafd14cb80b46b3a53f1af.head = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloada1dfea9b6abafd14cb80b46b3a53f1af.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
    const downloada1dfea9b6abafd14cb80b46b3a53f1afForm = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloada1dfea9b6abafd14cb80b46b3a53f1af.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
        downloada1dfea9b6abafd14cb80b46b3a53f1afForm.get = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloada1dfea9b6abafd14cb80b46b3a53f1af.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientDocumentController::download
 * @see app/Http/Controllers/ClientDocumentController.php:134
 * @route '/clients/{client}/documents/{document}/download'
 */
        downloada1dfea9b6abafd14cb80b46b3a53f1afForm.head = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloada1dfea9b6abafd14cb80b46b3a53f1af.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloada1dfea9b6abafd14cb80b46b3a53f1af.form = downloada1dfea9b6abafd14cb80b46b3a53f1afForm

export const download = {
    '/portal/clients/{client}/documents/{document}/download': downloadec5f06f68600e41724813ea23282f47b,
    '/clients/{client}/documents/{document}/download': downloada1dfea9b6abafd14cb80b46b3a53f1af,
}

/**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
export const index = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/documents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
index.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return index.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
index.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
index.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
    const indexForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
        indexForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientDocumentController::index
 * @see app/Http/Controllers/ClientDocumentController.php:14
 * @route '/clients/{client}/documents'
 */
        indexForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ClientDocumentController::store
 * @see app/Http/Controllers/ClientDocumentController.php:51
 * @route '/clients/{client}/documents'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/documents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::store
 * @see app/Http/Controllers/ClientDocumentController.php:51
 * @route '/clients/{client}/documents'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::store
 * @see app/Http/Controllers/ClientDocumentController.php:51
 * @route '/clients/{client}/documents'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::store
 * @see app/Http/Controllers/ClientDocumentController.php:51
 * @route '/clients/{client}/documents'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::store
 * @see app/Http/Controllers/ClientDocumentController.php:51
 * @route '/clients/{client}/documents'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientDocumentController::update
 * @see app/Http/Controllers/ClientDocumentController.php:109
 * @route '/clients/{client}/documents/{document}'
 */
export const update = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/documents/{document}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::update
 * @see app/Http/Controllers/ClientDocumentController.php:109
 * @route '/clients/{client}/documents/{document}'
 */
update.url = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    document: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::update
 * @see app/Http/Controllers/ClientDocumentController.php:109
 * @route '/clients/{client}/documents/{document}'
 */
update.put = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::update
 * @see app/Http/Controllers/ClientDocumentController.php:109
 * @route '/clients/{client}/documents/{document}'
 */
    const updateForm = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::update
 * @see app/Http/Controllers/ClientDocumentController.php:109
 * @route '/clients/{client}/documents/{document}'
 */
        updateForm.put = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClientDocumentController::destroy
 * @see app/Http/Controllers/ClientDocumentController.php:156
 * @route '/clients/{client}/documents/{document}'
 */
export const destroy = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/documents/{document}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientDocumentController::destroy
 * @see app/Http/Controllers/ClientDocumentController.php:156
 * @route '/clients/{client}/documents/{document}'
 */
destroy.url = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    document: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                document: typeof args.document === 'object'
                ? args.document.id
                : args.document,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{document}', parsedArgs.document.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientDocumentController::destroy
 * @see app/Http/Controllers/ClientDocumentController.php:156
 * @route '/clients/{client}/documents/{document}'
 */
destroy.delete = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientDocumentController::destroy
 * @see app/Http/Controllers/ClientDocumentController.php:156
 * @route '/clients/{client}/documents/{document}'
 */
    const destroyForm = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientDocumentController::destroy
 * @see app/Http/Controllers/ClientDocumentController.php:156
 * @route '/clients/{client}/documents/{document}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, document: number | { id: number } } | [client: number | { id: number }, document: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClientDocumentController = { download, index, store, update, destroy }

export default ClientDocumentController