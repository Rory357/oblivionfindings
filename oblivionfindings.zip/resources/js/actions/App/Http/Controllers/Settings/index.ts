import ProfileController from './ProfileController'
import PasswordController from './PasswordController'
import TwoFactorAuthenticationController from './TwoFactorAuthenticationController'
import AccessController from './AccessController'
import TerminologyController from './TerminologyController'
import BrandingController from './BrandingController'
const Settings = {
    ProfileController: Object.assign(ProfileController, ProfileController),
PasswordController: Object.assign(PasswordController, PasswordController),
TwoFactorAuthenticationController: Object.assign(TwoFactorAuthenticationController, TwoFactorAuthenticationController),
AccessController: Object.assign(AccessController, AccessController),
TerminologyController: Object.assign(TerminologyController, TerminologyController),
BrandingController: Object.assign(BrandingController, BrandingController),
}

export default Settings