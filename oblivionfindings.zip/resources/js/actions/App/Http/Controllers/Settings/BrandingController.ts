import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/branding',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\BrandingController::edit
 * @see app/Http/Controllers/Settings/BrandingController.php:30
 * @route '/settings/branding'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/settings/branding',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\BrandingController::update
 * @see app/Http/Controllers/Settings/BrandingController.php:53
 * @route '/settings/branding'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const BrandingController = { edit, update }

export default BrandingController