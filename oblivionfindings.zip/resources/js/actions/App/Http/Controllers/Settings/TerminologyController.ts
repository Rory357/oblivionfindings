import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
export const edit = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/settings/terminology',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
edit.url = (options?: RouteQueryOptions) => {
    return edit.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
edit.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
edit.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
    const editForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
        editForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Settings\TerminologyController::edit
 * @see app/Http/Controllers/Settings/TerminologyController.php:11
 * @route '/settings/terminology'
 */
        editForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/settings/terminology',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
update.put = (options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url({
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Settings\TerminologyController::update
 * @see app/Http/Controllers/Settings/TerminologyController.php:29
 * @route '/settings/terminology'
 */
        updateForm.put = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const TerminologyController = { edit, update }

export default TerminologyController