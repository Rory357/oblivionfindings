import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/reports/medications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsReportController::index
 * @see app/Http/Controllers/MedicationsReportController.php:13
 * @route '/reports/medications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
export const exportMarCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMarCsv.url(options),
    method: 'get',
})

exportMarCsv.definition = {
    methods: ["get","head"],
    url: '/reports/medications/export-mar',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
exportMarCsv.url = (options?: RouteQueryOptions) => {
    return exportMarCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
exportMarCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMarCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
exportMarCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMarCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
    const exportMarCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMarCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
        exportMarCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMarCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsReportController::exportMarCsv
 * @see app/Http/Controllers/MedicationsReportController.php:168
 * @route '/reports/medications/export-mar'
 */
        exportMarCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMarCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMarCsv.form = exportMarCsvForm
/**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
export const exportDiscrepanciesCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportDiscrepanciesCsv.url(options),
    method: 'get',
})

exportDiscrepanciesCsv.definition = {
    methods: ["get","head"],
    url: '/reports/medications/export-controlled-discrepancies',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
exportDiscrepanciesCsv.url = (options?: RouteQueryOptions) => {
    return exportDiscrepanciesCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
exportDiscrepanciesCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportDiscrepanciesCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
exportDiscrepanciesCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportDiscrepanciesCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
    const exportDiscrepanciesCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportDiscrepanciesCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
        exportDiscrepanciesCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportDiscrepanciesCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsReportController::exportDiscrepanciesCsv
 * @see app/Http/Controllers/MedicationsReportController.php:245
 * @route '/reports/medications/export-controlled-discrepancies'
 */
        exportDiscrepanciesCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportDiscrepanciesCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportDiscrepanciesCsv.form = exportDiscrepanciesCsvForm
const MedicationsReportController = { index, exportMarCsv, exportDiscrepanciesCsv }

export default MedicationsReportController