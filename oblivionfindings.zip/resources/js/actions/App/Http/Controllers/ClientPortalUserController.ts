import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
export const edit = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/portal-users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
edit.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return edit.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
edit.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
edit.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
    const editForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
        editForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientPortalUserController::edit
 * @see app/Http/Controllers/ClientPortalUserController.php:11
 * @route '/clients/{client}/portal-users'
 */
        editForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ClientPortalUserController::store
 * @see app/Http/Controllers/ClientPortalUserController.php:28
 * @route '/clients/{client}/portal-users'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/portal-users',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientPortalUserController::store
 * @see app/Http/Controllers/ClientPortalUserController.php:28
 * @route '/clients/{client}/portal-users'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientPortalUserController::store
 * @see app/Http/Controllers/ClientPortalUserController.php:28
 * @route '/clients/{client}/portal-users'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientPortalUserController::store
 * @see app/Http/Controllers/ClientPortalUserController.php:28
 * @route '/clients/{client}/portal-users'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientPortalUserController::store
 * @see app/Http/Controllers/ClientPortalUserController.php:28
 * @route '/clients/{client}/portal-users'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientPortalUserController::destroy
 * @see app/Http/Controllers/ClientPortalUserController.php:59
 * @route '/clients/{client}/portal-users/{user}'
 */
export const destroy = (args: { client: number | { id: number }, user: number | { id: number } } | [client: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/portal-users/{user}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientPortalUserController::destroy
 * @see app/Http/Controllers/ClientPortalUserController.php:59
 * @route '/clients/{client}/portal-users/{user}'
 */
destroy.url = (args: { client: number | { id: number }, user: number | { id: number } } | [client: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    user: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientPortalUserController::destroy
 * @see app/Http/Controllers/ClientPortalUserController.php:59
 * @route '/clients/{client}/portal-users/{user}'
 */
destroy.delete = (args: { client: number | { id: number }, user: number | { id: number } } | [client: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientPortalUserController::destroy
 * @see app/Http/Controllers/ClientPortalUserController.php:59
 * @route '/clients/{client}/portal-users/{user}'
 */
    const destroyForm = (args: { client: number | { id: number }, user: number | { id: number } } | [client: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientPortalUserController::destroy
 * @see app/Http/Controllers/ClientPortalUserController.php:59
 * @route '/clients/{client}/portal-users/{user}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, user: number | { id: number } } | [client: number | { id: number }, user: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClientPortalUserController = { edit, store, destroy }

export default ClientPortalUserController