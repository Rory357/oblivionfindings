import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
const ask06d4910b65fa6a84351a112b6a2a4311 = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask06d4910b65fa6a84351a112b6a2a4311.url(args, options),
    method: 'post',
})

ask06d4910b65fa6a84351a112b6a2a4311.definition = {
    methods: ["post"],
    url: '/portal/clients/{client}/rag/ask',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
ask06d4910b65fa6a84351a112b6a2a4311.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return ask06d4910b65fa6a84351a112b6a2a4311.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
ask06d4910b65fa6a84351a112b6a2a4311.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask06d4910b65fa6a84351a112b6a2a4311.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
    const ask06d4910b65fa6a84351a112b6a2a4311Form = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ask06d4910b65fa6a84351a112b6a2a4311.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/portal/clients/{client}/rag/ask'
 */
        ask06d4910b65fa6a84351a112b6a2a4311Form.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ask06d4910b65fa6a84351a112b6a2a4311.url(args, options),
            method: 'post',
        })
    
    ask06d4910b65fa6a84351a112b6a2a4311.form = ask06d4910b65fa6a84351a112b6a2a4311Form
    /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/clients/{client}/rag/ask'
 */
const ask12e2995c401f80ed4ca7c89d9dfc8b1f = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask12e2995c401f80ed4ca7c89d9dfc8b1f.url(args, options),
    method: 'post',
})

ask12e2995c401f80ed4ca7c89d9dfc8b1f.definition = {
    methods: ["post"],
    url: '/clients/{client}/rag/ask',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/clients/{client}/rag/ask'
 */
ask12e2995c401f80ed4ca7c89d9dfc8b1f.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return ask12e2995c401f80ed4ca7c89d9dfc8b1f.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/clients/{client}/rag/ask'
 */
ask12e2995c401f80ed4ca7c89d9dfc8b1f.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask12e2995c401f80ed4ca7c89d9dfc8b1f.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/clients/{client}/rag/ask'
 */
    const ask12e2995c401f80ed4ca7c89d9dfc8b1fForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ask12e2995c401f80ed4ca7c89d9dfc8b1f.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientRagController::ask
 * @see app/Http/Controllers/ClientRagController.php:13
 * @route '/clients/{client}/rag/ask'
 */
        ask12e2995c401f80ed4ca7c89d9dfc8b1fForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ask12e2995c401f80ed4ca7c89d9dfc8b1f.url(args, options),
            method: 'post',
        })
    
    ask12e2995c401f80ed4ca7c89d9dfc8b1f.form = ask12e2995c401f80ed4ca7c89d9dfc8b1fForm

export const ask = {
    '/portal/clients/{client}/rag/ask': ask06d4910b65fa6a84351a112b6a2a4311,
    '/clients/{client}/rag/ask': ask12e2995c401f80ed4ca7c89d9dfc8b1f,
}

const ClientRagController = { ask }

export default ClientRagController