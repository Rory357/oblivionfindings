import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
export const index = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/incidents',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
index.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return index.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
index.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
index.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
    const indexForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
        indexForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientIncidentController::index
 * @see app/Http/Controllers/ClientIncidentController.php:15
 * @route '/clients/{client}/incidents'
 */
        indexForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:59
 * @route '/clients/{client}/incidents'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/incidents',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:59
 * @route '/clients/{client}/incidents'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:59
 * @route '/clients/{client}/incidents'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:59
 * @route '/clients/{client}/incidents'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientIncidentController::store
 * @see app/Http/Controllers/ClientIncidentController.php:59
 * @route '/clients/{client}/incidents'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientIncidentController::uploadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:112
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
export const uploadAttachment = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadAttachment.url(args, options),
    method: 'post',
})

uploadAttachment.definition = {
    methods: ["post"],
    url: '/clients/{client}/incidents/{incident}/attachments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientIncidentController::uploadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:112
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
uploadAttachment.url = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    incident: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                }

    return uploadAttachment.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{incident}', parsedArgs.incident.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientIncidentController::uploadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:112
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
uploadAttachment.post = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: uploadAttachment.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientIncidentController::uploadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:112
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
    const uploadAttachmentForm = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: uploadAttachment.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientIncidentController::uploadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:112
 * @route '/clients/{client}/incidents/{incident}/attachments'
 */
        uploadAttachmentForm.post = (args: { client: number | { id: number }, incident: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: uploadAttachment.url(args, options),
            method: 'post',
        })
    
    uploadAttachment.form = uploadAttachmentForm
/**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
export const downloadAttachment = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})

downloadAttachment.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/incidents/{incident}/attachments/{attachment}/download',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
downloadAttachment.url = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    incident: args[1],
                    attachment: args[2],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                incident: typeof args.incident === 'object'
                ? args.incident.id
                : args.incident,
                                attachment: typeof args.attachment === 'object'
                ? args.attachment.id
                : args.attachment,
                }

    return downloadAttachment.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{incident}', parsedArgs.incident.toString())
            .replace('{attachment}', parsedArgs.attachment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
downloadAttachment.get = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: downloadAttachment.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
downloadAttachment.head = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: downloadAttachment.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
    const downloadAttachmentForm = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: downloadAttachment.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
        downloadAttachmentForm.get = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientIncidentController::downloadAttachment
 * @see app/Http/Controllers/ClientIncidentController.php:152
 * @route '/clients/{client}/incidents/{incident}/attachments/{attachment}/download'
 */
        downloadAttachmentForm.head = (args: { client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } } | [client: number | { id: number }, incident: number | { id: number }, attachment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: downloadAttachment.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    downloadAttachment.form = downloadAttachmentForm
const ClientIncidentController = { index, store, uploadAttachment, downloadAttachment }

export default ClientIncidentController