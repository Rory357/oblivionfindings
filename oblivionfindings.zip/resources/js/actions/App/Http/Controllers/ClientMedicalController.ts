import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
export const show = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/medical',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
show.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return show.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
show.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
show.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
    const showForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
        showForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientMedicalController::show
 * @see app/Http/Controllers/ClientMedicalController.php:16
 * @route '/clients/{client}/medical'
 */
        showForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ClientMedicalController::updateProfile
 * @see app/Http/Controllers/ClientMedicalController.php:56
 * @route '/clients/{client}/medical/profile'
 */
export const updateProfile = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile.url(args, options),
    method: 'put',
})

updateProfile.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/profile',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::updateProfile
 * @see app/Http/Controllers/ClientMedicalController.php:56
 * @route '/clients/{client}/medical/profile'
 */
updateProfile.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return updateProfile.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::updateProfile
 * @see app/Http/Controllers/ClientMedicalController.php:56
 * @route '/clients/{client}/medical/profile'
 */
updateProfile.put = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateProfile.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::updateProfile
 * @see app/Http/Controllers/ClientMedicalController.php:56
 * @route '/clients/{client}/medical/profile'
 */
    const updateProfileForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProfile.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::updateProfile
 * @see app/Http/Controllers/ClientMedicalController.php:56
 * @route '/clients/{client}/medical/profile'
 */
        updateProfileForm.put = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProfile.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateProfile.form = updateProfileForm
/**
* @see \App\Http\Controllers\ClientMedicalController::storeMedication
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
export const storeMedication = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMedication.url(args, options),
    method: 'post',
})

storeMedication.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/medications',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::storeMedication
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
storeMedication.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return storeMedication.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::storeMedication
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
storeMedication.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeMedication.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::storeMedication
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
    const storeMedicationForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeMedication.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::storeMedication
 * @see app/Http/Controllers/ClientMedicalController.php:75
 * @route '/clients/{client}/medical/medications'
 */
        storeMedicationForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeMedication.url(args, options),
            method: 'post',
        })
    
    storeMedication.form = storeMedicationForm
/**
* @see \App\Http\Controllers\ClientMedicalController::updateMedication
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
export const updateMedication = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMedication.url(args, options),
    method: 'put',
})

updateMedication.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/medications/{medication}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::updateMedication
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
updateMedication.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return updateMedication.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::updateMedication
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
updateMedication.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMedication.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::updateMedication
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
    const updateMedicationForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMedication.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::updateMedication
 * @see app/Http/Controllers/ClientMedicalController.php:102
 * @route '/clients/{client}/medical/medications/{medication}'
 */
        updateMedicationForm.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMedication.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateMedication.form = updateMedicationForm
/**
* @see \App\Http\Controllers\ClientMedicalController::destroyMedication
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
export const destroyMedication = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMedication.url(args, options),
    method: 'delete',
})

destroyMedication.definition = {
    methods: ["delete"],
    url: '/clients/{client}/medical/medications/{medication}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::destroyMedication
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
destroyMedication.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return destroyMedication.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::destroyMedication
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
destroyMedication.delete = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyMedication.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::destroyMedication
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
    const destroyMedicationForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyMedication.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::destroyMedication
 * @see app/Http/Controllers/ClientMedicalController.php:187
 * @route '/clients/{client}/medical/medications/{medication}'
 */
        destroyMedicationForm.delete = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyMedication.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyMedication.form = destroyMedicationForm
/**
* @see \App\Http\Controllers\ClientMedicalController::storeCondition
 * @see app/Http/Controllers/ClientMedicalController.php:197
 * @route '/clients/{client}/medical/conditions'
 */
export const storeCondition = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCondition.url(args, options),
    method: 'post',
})

storeCondition.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/conditions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::storeCondition
 * @see app/Http/Controllers/ClientMedicalController.php:197
 * @route '/clients/{client}/medical/conditions'
 */
storeCondition.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return storeCondition.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::storeCondition
 * @see app/Http/Controllers/ClientMedicalController.php:197
 * @route '/clients/{client}/medical/conditions'
 */
storeCondition.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCondition.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::storeCondition
 * @see app/Http/Controllers/ClientMedicalController.php:197
 * @route '/clients/{client}/medical/conditions'
 */
    const storeConditionForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCondition.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::storeCondition
 * @see app/Http/Controllers/ClientMedicalController.php:197
 * @route '/clients/{client}/medical/conditions'
 */
        storeConditionForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCondition.url(args, options),
            method: 'post',
        })
    
    storeCondition.form = storeConditionForm
/**
* @see \App\Http\Controllers\ClientMedicalController::updateCondition
 * @see app/Http/Controllers/ClientMedicalController.php:215
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
export const updateCondition = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCondition.url(args, options),
    method: 'put',
})

updateCondition.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/conditions/{condition}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::updateCondition
 * @see app/Http/Controllers/ClientMedicalController.php:215
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
updateCondition.url = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    condition: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                condition: typeof args.condition === 'object'
                ? args.condition.id
                : args.condition,
                }

    return updateCondition.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{condition}', parsedArgs.condition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::updateCondition
 * @see app/Http/Controllers/ClientMedicalController.php:215
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
updateCondition.put = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCondition.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::updateCondition
 * @see app/Http/Controllers/ClientMedicalController.php:215
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
    const updateConditionForm = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCondition.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::updateCondition
 * @see app/Http/Controllers/ClientMedicalController.php:215
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
        updateConditionForm.put = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCondition.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCondition.form = updateConditionForm
/**
* @see \App\Http\Controllers\ClientMedicalController::destroyCondition
 * @see app/Http/Controllers/ClientMedicalController.php:232
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
export const destroyCondition = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCondition.url(args, options),
    method: 'delete',
})

destroyCondition.definition = {
    methods: ["delete"],
    url: '/clients/{client}/medical/conditions/{condition}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::destroyCondition
 * @see app/Http/Controllers/ClientMedicalController.php:232
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
destroyCondition.url = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    condition: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                condition: typeof args.condition === 'object'
                ? args.condition.id
                : args.condition,
                }

    return destroyCondition.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{condition}', parsedArgs.condition.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::destroyCondition
 * @see app/Http/Controllers/ClientMedicalController.php:232
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
destroyCondition.delete = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCondition.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::destroyCondition
 * @see app/Http/Controllers/ClientMedicalController.php:232
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
    const destroyConditionForm = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyCondition.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::destroyCondition
 * @see app/Http/Controllers/ClientMedicalController.php:232
 * @route '/clients/{client}/medical/conditions/{condition}'
 */
        destroyConditionForm.delete = (args: { client: number | { id: number }, condition: number | { id: number } } | [client: number | { id: number }, condition: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyCondition.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyCondition.form = destroyConditionForm
/**
* @see \App\Http\Controllers\ClientMedicalController::storeEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
export const storeEmergencyContact = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeEmergencyContact.url(args, options),
    method: 'post',
})

storeEmergencyContact.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/emergency-contacts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::storeEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
storeEmergencyContact.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return storeEmergencyContact.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::storeEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
storeEmergencyContact.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeEmergencyContact.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::storeEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
    const storeEmergencyContactForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeEmergencyContact.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::storeEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:242
 * @route '/clients/{client}/medical/emergency-contacts'
 */
        storeEmergencyContactForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeEmergencyContact.url(args, options),
            method: 'post',
        })
    
    storeEmergencyContact.form = storeEmergencyContactForm
/**
* @see \App\Http\Controllers\ClientMedicalController::updateEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
export const updateEmergencyContact = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateEmergencyContact.url(args, options),
    method: 'put',
})

updateEmergencyContact.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/emergency-contacts/{contact}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::updateEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
updateEmergencyContact.url = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return updateEmergencyContact.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::updateEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
updateEmergencyContact.put = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateEmergencyContact.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::updateEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
    const updateEmergencyContactForm = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateEmergencyContact.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::updateEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:262
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
        updateEmergencyContactForm.put = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateEmergencyContact.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateEmergencyContact.form = updateEmergencyContactForm
/**
* @see \App\Http\Controllers\ClientMedicalController::destroyEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
export const destroyEmergencyContact = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyEmergencyContact.url(args, options),
    method: 'delete',
})

destroyEmergencyContact.definition = {
    methods: ["delete"],
    url: '/clients/{client}/medical/emergency-contacts/{contact}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::destroyEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
destroyEmergencyContact.url = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    contact: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                contact: typeof args.contact === 'object'
                ? args.contact.id
                : args.contact,
                }

    return destroyEmergencyContact.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{contact}', parsedArgs.contact.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::destroyEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
destroyEmergencyContact.delete = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyEmergencyContact.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::destroyEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
    const destroyEmergencyContactForm = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyEmergencyContact.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::destroyEmergencyContact
 * @see app/Http/Controllers/ClientMedicalController.php:281
 * @route '/clients/{client}/medical/emergency-contacts/{contact}'
 */
        destroyEmergencyContactForm.delete = (args: { client: number | { id: number }, contact: number | { id: number } } | [client: number | { id: number }, contact: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyEmergencyContact.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyEmergencyContact.form = destroyEmergencyContactForm
/**
* @see \App\Http\Controllers\ClientMedicalController::updateMedicationStock
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
export const updateMedicationStock = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMedicationStock.url(args, options),
    method: 'put',
})

updateMedicationStock.definition = {
    methods: ["put"],
    url: '/clients/{client}/medical/medications/{medication}/stock',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::updateMedicationStock
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
updateMedicationStock.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return updateMedicationStock.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::updateMedicationStock
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
updateMedicationStock.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMedicationStock.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::updateMedicationStock
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
    const updateMedicationStockForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMedicationStock.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::updateMedicationStock
 * @see app/Http/Controllers/ClientMedicalController.php:128
 * @route '/clients/{client}/medical/medications/{medication}/stock'
 */
        updateMedicationStockForm.put = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMedicationStock.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateMedicationStock.form = updateMedicationStockForm
/**
* @see \App\Http\Controllers\ClientMedicalController::storeAdministration
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
export const storeAdministration = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAdministration.url(args, options),
    method: 'post',
})

storeAdministration.definition = {
    methods: ["post"],
    url: '/clients/{client}/medical/medications/{medication}/administrations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientMedicalController::storeAdministration
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
storeAdministration.url = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    medication: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                medication: typeof args.medication === 'object'
                ? args.medication.id
                : args.medication,
                }

    return storeAdministration.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{medication}', parsedArgs.medication.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientMedicalController::storeAdministration
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
storeAdministration.post = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAdministration.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientMedicalController::storeAdministration
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
    const storeAdministrationForm = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAdministration.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientMedicalController::storeAdministration
 * @see app/Http/Controllers/ClientMedicalController.php:155
 * @route '/clients/{client}/medical/medications/{medication}/administrations'
 */
        storeAdministrationForm.post = (args: { client: number | { id: number }, medication: number | { id: number } } | [client: number | { id: number }, medication: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAdministration.url(args, options),
            method: 'post',
        })
    
    storeAdministration.form = storeAdministrationForm
const ClientMedicalController = { show, updateProfile, storeMedication, updateMedication, destroyMedication, storeCondition, updateCondition, destroyCondition, storeEmergencyContact, updateEmergencyContact, destroyEmergencyContact, updateMedicationStock, storeAdministration }

export default ClientMedicalController