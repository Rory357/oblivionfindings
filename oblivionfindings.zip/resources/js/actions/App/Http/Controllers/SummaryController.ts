import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
const generate08b2469585b8007e19ba6bf5f68fca84 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate08b2469585b8007e19ba6bf5f68fca84.url(options),
    method: 'post',
})

generate08b2469585b8007e19ba6bf5f68fca84.definition = {
    methods: ["post"],
    url: '/portal/summaries/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
generate08b2469585b8007e19ba6bf5f68fca84.url = (options?: RouteQueryOptions) => {
    return generate08b2469585b8007e19ba6bf5f68fca84.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
generate08b2469585b8007e19ba6bf5f68fca84.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate08b2469585b8007e19ba6bf5f68fca84.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
    const generate08b2469585b8007e19ba6bf5f68fca84Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate08b2469585b8007e19ba6bf5f68fca84.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/portal/summaries/generate'
 */
        generate08b2469585b8007e19ba6bf5f68fca84Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate08b2469585b8007e19ba6bf5f68fca84.url(options),
            method: 'post',
        })
    
    generate08b2469585b8007e19ba6bf5f68fca84.form = generate08b2469585b8007e19ba6bf5f68fca84Form
    /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
const generate09e88f449b5dfb9fc683ddc0150005c0 = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate09e88f449b5dfb9fc683ddc0150005c0.url(options),
    method: 'post',
})

generate09e88f449b5dfb9fc683ddc0150005c0.definition = {
    methods: ["post"],
    url: '/summaries/generate',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
generate09e88f449b5dfb9fc683ddc0150005c0.url = (options?: RouteQueryOptions) => {
    return generate09e88f449b5dfb9fc683ddc0150005c0.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
generate09e88f449b5dfb9fc683ddc0150005c0.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: generate09e88f449b5dfb9fc683ddc0150005c0.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
    const generate09e88f449b5dfb9fc683ddc0150005c0Form = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: generate09e88f449b5dfb9fc683ddc0150005c0.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SummaryController::generate
 * @see app/Http/Controllers/SummaryController.php:68
 * @route '/summaries/generate'
 */
        generate09e88f449b5dfb9fc683ddc0150005c0Form.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: generate09e88f449b5dfb9fc683ddc0150005c0.url(options),
            method: 'post',
        })
    
    generate09e88f449b5dfb9fc683ddc0150005c0.form = generate09e88f449b5dfb9fc683ddc0150005c0Form

export const generate = {
    '/portal/summaries/generate': generate08b2469585b8007e19ba6bf5f68fca84,
    '/summaries/generate': generate09e88f449b5dfb9fc683ddc0150005c0,
}

/**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
export const my = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})

my.definition = {
    methods: ["get","head"],
    url: '/summaries/me',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
my.url = (options?: RouteQueryOptions) => {
    return my.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
my.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: my.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
my.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: my.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
    const myForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: my.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
        myForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SummaryController::my
 * @see app/Http/Controllers/SummaryController.php:14
 * @route '/summaries/me'
 */
        myForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: my.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    my.form = myForm
/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
export const staff = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staff.url(args, options),
    method: 'get',
})

staff.definition = {
    methods: ["get","head"],
    url: '/summaries/staff/{user}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
staff.url = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { user: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.id
                : args.user,
                }

    return staff.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
staff.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: staff.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
staff.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: staff.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
    const staffForm = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: staff.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
        staffForm.get = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staff.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SummaryController::staff
 * @see app/Http/Controllers/SummaryController.php:21
 * @route '/summaries/staff/{user}'
 */
        staffForm.head = (args: { user: number | { id: number } } | [user: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: staff.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    staff.form = staffForm
/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
export const client = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(args, options),
    method: 'get',
})

client.definition = {
    methods: ["get","head"],
    url: '/summaries/clients/{client}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
client.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return client.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
client.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: client.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
client.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: client.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
    const clientForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: client.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
        clientForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SummaryController::client
 * @see app/Http/Controllers/SummaryController.php:46
 * @route '/summaries/clients/{client}'
 */
        clientForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: client.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    client.form = clientForm
const SummaryController = { generate, my, staff, client }

export default SummaryController