import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
export const clients = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})

clients.definition = {
    methods: ["get","head"],
    url: '/rag/clients',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
clients.url = (options?: RouteQueryOptions) => {
    return clients.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
clients.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: clients.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
clients.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: clients.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
    const clientsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: clients.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
        clientsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\RagController::clients
 * @see app/Http/Controllers/RagController.php:13
 * @route '/rag/clients'
 */
        clientsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: clients.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    clients.form = clientsForm
/**
* @see \App\Http\Controllers\RagController::ask
 * @see app/Http/Controllers/RagController.php:48
 * @route '/rag/ask'
 */
export const ask = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask.url(options),
    method: 'post',
})

ask.definition = {
    methods: ["post"],
    url: '/rag/ask',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\RagController::ask
 * @see app/Http/Controllers/RagController.php:48
 * @route '/rag/ask'
 */
ask.url = (options?: RouteQueryOptions) => {
    return ask.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\RagController::ask
 * @see app/Http/Controllers/RagController.php:48
 * @route '/rag/ask'
 */
ask.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: ask.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\RagController::ask
 * @see app/Http/Controllers/RagController.php:48
 * @route '/rag/ask'
 */
    const askForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: ask.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\RagController::ask
 * @see app/Http/Controllers/RagController.php:48
 * @route '/rag/ask'
 */
        askForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: ask.url(options),
            method: 'post',
        })
    
    ask.form = askForm
const RagController = { clients, ask }

export default RagController