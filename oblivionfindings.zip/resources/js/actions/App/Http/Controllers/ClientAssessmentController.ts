import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientAssessmentController::store
 * @see app/Http/Controllers/ClientAssessmentController.php:11
 * @route '/clients/{client}/assessments'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/assessments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientAssessmentController::store
 * @see app/Http/Controllers/ClientAssessmentController.php:11
 * @route '/clients/{client}/assessments'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientAssessmentController::store
 * @see app/Http/Controllers/ClientAssessmentController.php:11
 * @route '/clients/{client}/assessments'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientAssessmentController::store
 * @see app/Http/Controllers/ClientAssessmentController.php:11
 * @route '/clients/{client}/assessments'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientAssessmentController::store
 * @see app/Http/Controllers/ClientAssessmentController.php:11
 * @route '/clients/{client}/assessments'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientAssessmentController::update
 * @see app/Http/Controllers/ClientAssessmentController.php:31
 * @route '/clients/{client}/assessments/{assessment}'
 */
export const update = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/assessments/{assessment}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientAssessmentController::update
 * @see app/Http/Controllers/ClientAssessmentController.php:31
 * @route '/clients/{client}/assessments/{assessment}'
 */
update.url = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    assessment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                assessment: typeof args.assessment === 'object'
                ? args.assessment.id
                : args.assessment,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{assessment}', parsedArgs.assessment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientAssessmentController::update
 * @see app/Http/Controllers/ClientAssessmentController.php:31
 * @route '/clients/{client}/assessments/{assessment}'
 */
update.put = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientAssessmentController::update
 * @see app/Http/Controllers/ClientAssessmentController.php:31
 * @route '/clients/{client}/assessments/{assessment}'
 */
    const updateForm = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientAssessmentController::update
 * @see app/Http/Controllers/ClientAssessmentController.php:31
 * @route '/clients/{client}/assessments/{assessment}'
 */
        updateForm.put = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClientAssessmentController::destroy
 * @see app/Http/Controllers/ClientAssessmentController.php:49
 * @route '/clients/{client}/assessments/{assessment}'
 */
export const destroy = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/assessments/{assessment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientAssessmentController::destroy
 * @see app/Http/Controllers/ClientAssessmentController.php:49
 * @route '/clients/{client}/assessments/{assessment}'
 */
destroy.url = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    assessment: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                assessment: typeof args.assessment === 'object'
                ? args.assessment.id
                : args.assessment,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{assessment}', parsedArgs.assessment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientAssessmentController::destroy
 * @see app/Http/Controllers/ClientAssessmentController.php:49
 * @route '/clients/{client}/assessments/{assessment}'
 */
destroy.delete = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientAssessmentController::destroy
 * @see app/Http/Controllers/ClientAssessmentController.php:49
 * @route '/clients/{client}/assessments/{assessment}'
 */
    const destroyForm = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientAssessmentController::destroy
 * @see app/Http/Controllers/ClientAssessmentController.php:49
 * @route '/clients/{client}/assessments/{assessment}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, assessment: number | { id: number } } | [client: number | { id: number }, assessment: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClientAssessmentController = { store, update, destroy }

export default ClientAssessmentController