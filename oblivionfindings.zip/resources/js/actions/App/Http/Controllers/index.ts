import DashboardController from './DashboardController'
import Auth from './Auth'
import RagController from './RagController'
import PortalController from './PortalController'
import PortalClientController from './PortalClientController'
import ClientRagController from './ClientRagController'
import ClientDocumentController from './ClientDocumentController'
import SummaryController from './SummaryController'
import TimelineController from './TimelineController'
import ClientNoteController from './ClientNoteController'
import UnifiController from './UnifiController'
import SiteController from './SiteController'
import ClientController from './ClientController'
import StaffController from './StaffController'
import StaffAssignmentController from './StaffAssignmentController'
import StaffCredentialController from './StaffCredentialController'
import StaffAvailabilityController from './StaffAvailabilityController'
import AuditLogController from './AuditLogController'
import CalendarController from './CalendarController'
import ClientMedicalController from './ClientMedicalController'
import ClientIncidentController from './ClientIncidentController'
import IncidentController from './IncidentController'
import ClientRiskController from './ClientRiskController'
import ClientPortalUserController from './ClientPortalUserController'
import ClientSupportPlanController from './ClientSupportPlanController'
import ClientAssessmentController from './ClientAssessmentController'
import ClientAssignmentController from './ClientAssignmentController'
import ShiftController from './ShiftController'
import ShiftSeriesController from './ShiftSeriesController'
import ShiftTaskController from './ShiftTaskController'
import TimesheetController from './TimesheetController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
Auth: Object.assign(Auth, Auth),
RagController: Object.assign(RagController, RagController),
PortalController: Object.assign(PortalController, PortalController),
PortalClientController: Object.assign(PortalClientController, PortalClientController),
ClientRagController: Object.assign(ClientRagController, ClientRagController),
ClientDocumentController: Object.assign(ClientDocumentController, ClientDocumentController),
SummaryController: Object.assign(SummaryController, SummaryController),
TimelineController: Object.assign(TimelineController, TimelineController),
ClientNoteController: Object.assign(ClientNoteController, ClientNoteController),
UnifiController: Object.assign(UnifiController, UnifiController),
SiteController: Object.assign(SiteController, SiteController),
ClientController: Object.assign(ClientController, ClientController),
StaffController: Object.assign(StaffController, StaffController),
StaffAssignmentController: Object.assign(StaffAssignmentController, StaffAssignmentController),
StaffCredentialController: Object.assign(StaffCredentialController, StaffCredentialController),
StaffAvailabilityController: Object.assign(StaffAvailabilityController, StaffAvailabilityController),
AuditLogController: Object.assign(AuditLogController, AuditLogController),
CalendarController: Object.assign(CalendarController, CalendarController),
ClientMedicalController: Object.assign(ClientMedicalController, ClientMedicalController),
ClientIncidentController: Object.assign(ClientIncidentController, ClientIncidentController),
IncidentController: Object.assign(IncidentController, IncidentController),
ClientRiskController: Object.assign(ClientRiskController, ClientRiskController),
ClientPortalUserController: Object.assign(ClientPortalUserController, ClientPortalUserController),
ClientSupportPlanController: Object.assign(ClientSupportPlanController, ClientSupportPlanController),
ClientAssessmentController: Object.assign(ClientAssessmentController, ClientAssessmentController),
ClientAssignmentController: Object.assign(ClientAssignmentController, ClientAssignmentController),
ShiftController: Object.assign(ShiftController, ShiftController),
ShiftSeriesController: Object.assign(ShiftSeriesController, ShiftSeriesController),
ShiftTaskController: Object.assign(ShiftTaskController, ShiftTaskController),
TimesheetController: Object.assign(TimesheetController, TimesheetController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers