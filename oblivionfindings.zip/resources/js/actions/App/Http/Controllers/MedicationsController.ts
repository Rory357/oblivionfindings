import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/medications',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MedicationsController::index
 * @see app/Http/Controllers/MedicationsController.php:11
 * @route '/medications'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const MedicationsController = { index }

export default MedicationsController