import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ShiftSeriesController::store
 * @see app/Http/Controllers/ShiftSeriesController.php:15
 * @route '/shifts/series'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/shifts/series',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ShiftSeriesController::store
 * @see app/Http/Controllers/ShiftSeriesController.php:15
 * @route '/shifts/series'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ShiftSeriesController::store
 * @see app/Http/Controllers/ShiftSeriesController.php:15
 * @route '/shifts/series'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ShiftSeriesController::store
 * @see app/Http/Controllers/ShiftSeriesController.php:15
 * @route '/shifts/series'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ShiftSeriesController::store
 * @see app/Http/Controllers/ShiftSeriesController.php:15
 * @route '/shifts/series'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const ShiftSeriesController = { store }

export default ShiftSeriesController