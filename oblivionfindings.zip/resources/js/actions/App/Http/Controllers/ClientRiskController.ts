import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
export const index = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/clients/{client}/risks',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
index.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return index.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
index.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
index.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
    const indexForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
        indexForm.get = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ClientRiskController::index
 * @see app/Http/Controllers/ClientRiskController.php:11
 * @route '/clients/{client}/risks'
 */
        indexForm.head = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ClientRiskController::store
 * @see app/Http/Controllers/ClientRiskController.php:32
 * @route '/clients/{client}/risks'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/risks',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientRiskController::store
 * @see app/Http/Controllers/ClientRiskController.php:32
 * @route '/clients/{client}/risks'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRiskController::store
 * @see app/Http/Controllers/ClientRiskController.php:32
 * @route '/clients/{client}/risks'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientRiskController::store
 * @see app/Http/Controllers/ClientRiskController.php:32
 * @route '/clients/{client}/risks'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientRiskController::store
 * @see app/Http/Controllers/ClientRiskController.php:32
 * @route '/clients/{client}/risks'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientRiskController::update
 * @see app/Http/Controllers/ClientRiskController.php:54
 * @route '/clients/{client}/risks/{risk}'
 */
export const update = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/clients/{client}/risks/{risk}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\ClientRiskController::update
 * @see app/Http/Controllers/ClientRiskController.php:54
 * @route '/clients/{client}/risks/{risk}'
 */
update.url = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    risk: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                risk: typeof args.risk === 'object'
                ? args.risk.id
                : args.risk,
                }

    return update.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{risk}', parsedArgs.risk.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRiskController::update
 * @see app/Http/Controllers/ClientRiskController.php:54
 * @route '/clients/{client}/risks/{risk}'
 */
update.put = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\ClientRiskController::update
 * @see app/Http/Controllers/ClientRiskController.php:54
 * @route '/clients/{client}/risks/{risk}'
 */
    const updateForm = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientRiskController::update
 * @see app/Http/Controllers/ClientRiskController.php:54
 * @route '/clients/{client}/risks/{risk}'
 */
        updateForm.put = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ClientRiskController::destroy
 * @see app/Http/Controllers/ClientRiskController.php:76
 * @route '/clients/{client}/risks/{risk}'
 */
export const destroy = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/clients/{client}/risks/{risk}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ClientRiskController::destroy
 * @see app/Http/Controllers/ClientRiskController.php:76
 * @route '/clients/{client}/risks/{risk}'
 */
destroy.url = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    risk: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                risk: typeof args.risk === 'object'
                ? args.risk.id
                : args.risk,
                }

    return destroy.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{risk}', parsedArgs.risk.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientRiskController::destroy
 * @see app/Http/Controllers/ClientRiskController.php:76
 * @route '/clients/{client}/risks/{risk}'
 */
destroy.delete = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ClientRiskController::destroy
 * @see app/Http/Controllers/ClientRiskController.php:76
 * @route '/clients/{client}/risks/{risk}'
 */
    const destroyForm = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientRiskController::destroy
 * @see app/Http/Controllers/ClientRiskController.php:76
 * @route '/clients/{client}/risks/{risk}'
 */
        destroyForm.delete = (args: { client: number | { id: number }, risk: number | { id: number } } | [client: number | { id: number }, risk: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ClientRiskController = { index, store, update, destroy }

export default ClientRiskController