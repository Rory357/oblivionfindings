import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ClientNoteController::store
 * @see app/Http/Controllers/ClientNoteController.php:12
 * @route '/clients/{client}/notes'
 */
export const store = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/clients/{client}/notes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientNoteController::store
 * @see app/Http/Controllers/ClientNoteController.php:12
 * @route '/clients/{client}/notes'
 */
store.url = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { client: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { client: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                }

    return store.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientNoteController::store
 * @see app/Http/Controllers/ClientNoteController.php:12
 * @route '/clients/{client}/notes'
 */
store.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientNoteController::store
 * @see app/Http/Controllers/ClientNoteController.php:12
 * @route '/clients/{client}/notes'
 */
    const storeForm = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientNoteController::store
 * @see app/Http/Controllers/ClientNoteController.php:12
 * @route '/clients/{client}/notes'
 */
        storeForm.post = (args: { client: number | { id: number } } | [client: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ClientNoteController::togglePin
 * @see app/Http/Controllers/ClientNoteController.php:71
 * @route '/clients/{client}/notes/{note}/pin'
 */
export const togglePin = (args: { client: number | { id: number }, note: number | { id: number } } | [client: number | { id: number }, note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: togglePin.url(args, options),
    method: 'post',
})

togglePin.definition = {
    methods: ["post"],
    url: '/clients/{client}/notes/{note}/pin',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ClientNoteController::togglePin
 * @see app/Http/Controllers/ClientNoteController.php:71
 * @route '/clients/{client}/notes/{note}/pin'
 */
togglePin.url = (args: { client: number | { id: number }, note: number | { id: number } } | [client: number | { id: number }, note: number | { id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    client: args[0],
                    note: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        client: typeof args.client === 'object'
                ? args.client.id
                : args.client,
                                note: typeof args.note === 'object'
                ? args.note.id
                : args.note,
                }

    return togglePin.definition.url
            .replace('{client}', parsedArgs.client.toString())
            .replace('{note}', parsedArgs.note.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ClientNoteController::togglePin
 * @see app/Http/Controllers/ClientNoteController.php:71
 * @route '/clients/{client}/notes/{note}/pin'
 */
togglePin.post = (args: { client: number | { id: number }, note: number | { id: number } } | [client: number | { id: number }, note: number | { id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: togglePin.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ClientNoteController::togglePin
 * @see app/Http/Controllers/ClientNoteController.php:71
 * @route '/clients/{client}/notes/{note}/pin'
 */
    const togglePinForm = (args: { client: number | { id: number }, note: number | { id: number } } | [client: number | { id: number }, note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: togglePin.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ClientNoteController::togglePin
 * @see app/Http/Controllers/ClientNoteController.php:71
 * @route '/clients/{client}/notes/{note}/pin'
 */
        togglePinForm.post = (args: { client: number | { id: number }, note: number | { id: number } } | [client: number | { id: number }, note: number | { id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: togglePin.url(args, options),
            method: 'post',
        })
    
    togglePin.form = togglePinForm
const ClientNoteController = { store, togglePin }

export default ClientNoteController