# Client Knowledge: Rosie Bailey
Client ID: 9
Site: This site
Generated at: 2026-01-19 06:57:00

## Medical Profile
- Medical history: docters visit
- Disabilities: Restricted movement of right arm
- Allergies: Penicillin
- Notes: N/A

## Medications
- name=Antibiotics | dosage=5ml | frequency=2 x Daily | prescriber=DR Anne Hataway | start=2026-01-01
  - instructions: asdfsdfsadfasdfasdf

## Timeline events (last 120 days)
- [event_id=8] 2026-01-19 05:34:27 | type=note | actor=Demo Admin | site=This site | subject=Note for Rosie Bailey
  - body: asdfasdfasdf
- [event_id=7] 2026-01-19 05:34:26 | type=note | actor=Demo Admin | site=This site | subject=Note for Rosie Bailey
  - body: asdfasdfasdfasdf
- [event_id=6] 2026-01-19 05:34:23 | type=note | actor=Demo Admin | site=This site | subject=Note for Rosie Bailey
  - body: asdfasdf
- [event_id=5] 2026-01-19 05:34:22 | type=note | actor=Demo Admin | site=This site | subject=Note for Rosie Bailey
  - body: sadfasdf