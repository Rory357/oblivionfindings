<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['dark'=> ($appearance ?? 'system') == 'dark']); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    
    <script>
        (function() {
            const appearance = '<?php echo e($appearance ?? "system"); ?>';

            if (appearance === 'system') {
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

                if (prefersDark) {
                    document.documentElement.classList.add('dark');
                }
            }
        })();
    </script>

    
    <style>
        html {
            background-color: oklch(var(--background));
        }

        html.dark {
            background-color: oklch(var(--background));
        }
    </style>

    
    <?php
    $theme = $page['props']['theme'] ?? ['light' => [], 'dark' => []];
    $light = is_array($theme['light'] ?? null) ? $theme['light'] : [];
    $dark = is_array($theme['dark'] ?? null) ? $theme['dark'] : [];

    $allowedVars = [
    '--primary', '--primary-foreground',
    '--secondary', '--secondary-foreground',
    '--accent', '--accent-foreground',
    '--background', '--foreground',
    '--card', '--card-foreground',
    '--popover', '--popover-foreground',
    '--border', '--input', '--ring',
    '--sidebar', '--sidebar-foreground',
    '--sidebar-primary', '--sidebar-primary-foreground',
    '--sidebar-accent', '--sidebar-accent-foreground',
    '--sidebar-border', '--sidebar-ring',
    '--radius',
    ];

    $toCss = function (array $vars) use ($allowedVars) {
    $out = '';
    foreach ($vars as $k => $v) {
    if (!is_string($k) || !in_array($k, $allowedVars, true)) {
    continue;
    }
    if (!is_string($v)) {
    continue;
    }
    $val = trim($v);
    if ($val === '') {
    continue;
    }
    // Keep it simple: rely on allowed var names and basic trimming.
    $out .= $k . ': ' . e($val) . ';';
    }
    return $out;
    };

    $lightCss = $toCss($light);
    $darkCss = $toCss($dark);
    ?>

    <?php if($lightCss || $darkCss): ?>
    <style>
        <?php if($lightCss): ?> :root {
                {
                ! ! $lightCss ! !
            }
        }

        <?php endif; ?> <?php if($darkCss): ?> .dark {
                {
                ! ! $darkCss ! !
            }
        }

        <?php endif; ?>
    </style>
    <?php endif; ?>

    <title inertia><?php echo e(config('app.name', 'Laravel')); ?></title>

    <link rel="icon" href="/favicon.ico" sizes="any">
    <link rel="icon" href="/favicon.svg" type="image/svg+xml">
    <link rel="apple-touch-icon" href="/apple-touch-icon.png">

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx', "resources/js/pages/{$page['component']}.tsx"]); ?>
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
</head>

<body class="font-sans antialiased">
    <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
</body>

</html><?php /**PATH C:\Users\chane\Herd\oblivionfindings\resources\views/app.blade.php ENDPATH**/ ?>