Inactive Calendar r2: resolved mixed-zone range order and exact per-Shift Show capability.

See contract-final-r2.md and revision.patch. Original writers/constructor and all original24 source test cases remain byte-exact; two methods/two providers add14 cases. Parent must independently review and compose the sibling before any parser/list/runtime. No approvals or actual counts.
