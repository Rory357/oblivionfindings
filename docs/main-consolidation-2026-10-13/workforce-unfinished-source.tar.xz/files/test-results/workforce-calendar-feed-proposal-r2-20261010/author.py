from pathlib import Path
import json,hashlib,difflib,re
P=Path(__file__).resolve().parent
O=P.parent/'workforce-calendar-feed-proposal-20261010'
D=Path('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
def rb(p):return Path('\\\\?\\'+str(p.resolve()).replace('/','\\')).read_bytes()
def sha(p):return hashlib.sha256(rb(p)).hexdigest()
def save(n,b):
 p=P/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b if isinstance(b,bytes) else b.encode());return p
def modify(b,old,new):
 a=old.encode();assert b.count(a)==1,old;return b.replace(a,new.encode())
controller='app/Http/Controllers/CalendarController.php'
test='tests/Feature/Rostering/WorkforceCalendarReadIntegrityTest.php'
b=rb(O/'proposed'/controller)
b=modify(b,"'end' => ['required', 'date', 'after_or_equal:start'],","'end' => ['required', 'date'],")
b=modify(b,"        $shiftCoverageById = $shifts->mapWithKeys(function (Shift $shift) use ($coverageWindows) {",'''        // Show has its own reports bypass, not the Calendar management bypass.
        // Offer a detail action only for the same canonical direct-read boundary.
        $viewableShiftIds = collect();
        if ($auth->canDo('shifts.viewAny') || $auth->canDo('shifts.viewAssigned')) {
            $showQuery = Shift::query()->whereKey($shifts->modelKeys());
            $access->applyShiftScope($showQuery, $auth, ['reports.viewAny']);
            if (! $auth->canDo('shifts.viewAny') && ! $canManageAny) {
                $showQuery->where('user_id', $auth->id)->visibleToFrontline();
            }
            $viewableShiftIds = $showQuery->pluck('id')->mapWithKeys(fn ($id) => [(int) $id => true]);
        }

        $shiftCoverageById = $shifts->mapWithKeys(function (Shift $shift) use ($coverageWindows) {''')
b=modify(b,'$shiftEvents = $shifts->map(function (Shift $shift) use ($canManageAny, $shiftCoverageById) {','$shiftEvents = $shifts->map(function (Shift $shift) use ($canManageAny, $shiftCoverageById, $viewableShiftIds) {')
b=modify(b,"                    'client_id' => $shift->client_id,","                    'can_view_shift' => $viewableShiftIds->get((int) $shift->id, false),\n                    'client_id' => $shift->client_id,")
save('baseline/'+controller,rb(O/'proposed'/controller));save('proposed/'+controller,b)
t=rb(O/'proposed'/test)
insert=r'''    #[DataProvider('mixedRangeEdges')]
    public function test_mixed_civil_and_offset_edges_are_ordered_only_after_worker_zone_normalisation(string $rawStart, string $rawEnd, string $startUtc, string $endUtc, bool $valid): void
    {
        $actor = $this->person($this->site, ['rostering.viewAny', 'shifts.viewAny']);
        $worker = $this->person($this->site);
        $first = Carbon::parse($startUtc);
        $last = Carbon::parse($endUtc);
        $low = $first->lt($last) ? $first : $last;
        $row = $this->shift($worker, ['starts_at' => $low->copy()->addMinutes(5), 'ends_at' => $low->copy()->addMinutes(10)]);
        $state = $this->state();
        $queue = $this->queueState();
        if ($valid) {
            $events = $this->read($actor, ['start' => $rawStart, 'end' => $rawEnd]);
            $this->assertSame([$row->id], $this->shiftIds($events));
            $this->assertSame(['start' => $first->toIso8601String(), 'end' => $last->toIso8601String(), 'end_exclusive' => true], $this->assessment($events)['range']);
        } else {
            $this->actingAs($actor)->getJson($this->url(['start' => $rawStart, 'end' => $rawEnd]))->assertUnprocessable();
        }
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queueState());
    }

    public static function mixedRangeEdges(): array
    {
        return [
            'civil start offset end valid local half hour' => ['2026-10-26', '2026-10-26T00:30:00+13:00', '2026-10-25T11:00:00Z', '2026-10-25T11:30:00Z', true],
            'offset start civil end valid local half hour' => ['2026-10-26T23:30:00+13:00', '2026-10-27', '2026-10-26T10:30:00Z', '2026-10-26T11:00:00Z', true],
            'offset start civil end reversed local half hour' => ['2026-10-26T00:30:00+13:00', '2026-10-26', '2026-10-25T11:30:00Z', '2026-10-25T11:00:00Z', false],
            'civil start offset end reversed local half hour' => ['2026-10-26', '2026-10-25T23:30:00+13:00', '2026-10-25T11:00:00Z', '2026-10-25T10:30:00Z', false],
        ];
    }

    #[DataProvider('showReadCapabilities')]
    public function test_calendar_detail_capability_matches_actual_show_route_scope_and_publication_without_writes(array $permissions, bool $own, bool $foreign, bool $published, bool $publishEnabled, bool $inFeed, ?bool $canView, int $showStatus): void
    {
        $actor = $this->person($this->site, ['rostering.viewAny', ...$permissions]);
        foreach (['shifts.viewAny', 'shifts.viewAssigned', 'shifts.manageAny', 'reports.viewAny'] as $permission) {
            $actor->permissionOverrides()->syncWithoutDetaching([Permission::query()->where('key', $permission)->firstOrFail()->id => ['allowed' => in_array($permission, $permissions, true)]]);
        }
        $actor = $actor->fresh();
        $worker = $own ? $actor : $this->person($foreign ? $this->foreignSite : $this->site);
        $row = $this->shift($worker, ['site_id' => $foreign ? $this->foreignSite->id : $this->site->id,
            'client_id' => $foreign ? $this->foreignClient->id : $this->client->id, 'published_at' => $published ? now() : null]);
        AppSetting::query()->where('key', 'features.rostering.publish')->update(['value' => $publishEnabled]);
        app()->forgetInstance(RosteringFeatureFlags::class);
        $state = $this->state();
        $queue = $this->queueState();
        $events = $this->read($actor);
        $this->assertSame($inFeed ? [$row->id] : [], $this->shiftIds($events));
        $event = collect($events)->firstWhere('id', $row->id);
        $this->assertSame($canView, $event['extendedProps']['can_view_shift'] ?? null);
        $this->actingAs($actor)->get(route('operations.shifts.show', $row))->assertStatus($showStatus);
        foreach ($events as $item) {
            if (! is_int($item['id'])) {
                $this->assertArrayNotHasKey('can_view_shift', $item['extendedProps']);
            }
        }
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queueState());
    }

    public static function showReadCapabilities(): array
    {
        return [
            'coordinator reads unpublished coworker' => [['shifts.viewAny'], false, false, false, true, true, true, 200],
            'assigned owner published' => [['shifts.viewAssigned'], true, false, true, true, true, true, 200],
            'assigned owner unpublished while publishing disabled' => [['shifts.viewAssigned'], true, false, false, false, true, true, 200],
            'assigned owner hidden unpublished' => [['shifts.viewAssigned'], true, false, false, true, false, null, 404],
            'roster feed alone grants no Show route' => [[], true, false, true, true, true, false, 403],
            'management alone grants no Show route' => [['shifts.manageAny'], false, false, false, true, true, false, 403],
            'management assigned route local unpublished coworker' => [['shifts.manageAny', 'shifts.viewAssigned'], false, false, false, true, true, true, 200],
            'management feed bypass does not bypass foreign Show Site' => [['shifts.manageAny', 'shifts.viewAssigned'], false, true, false, true, true, false, 403],
            'report bypass alone does not grant Show route' => [['shifts.manageAny', 'reports.viewAny'], false, true, false, true, true, false, 403],
            'Show route with existing report bypass permits foreign Site' => [['shifts.manageAny', 'shifts.viewAssigned', 'reports.viewAny'], false, true, false, true, true, true, 200],
        ];
    }

'''
t=modify(t,'    private function person(Site $site, array $keys = []): User\n',insert+'    private function person(Site $site, array $keys = []): User\n')
save('baseline/'+test,rb(O/'proposed'/test));save('proposed/'+test,t)

def patch(old,new,a,b):
 return ''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),new.decode().splitlines(keepends=True),a,b)).encode()
save('revision.patch',b''.join(patch(rb(O/'proposed'/n),rb(P/'proposed'/n),'a/'+n,'b/'+n) for n in [controller,test]))
save('inverse-revision.patch',b''.join(patch(rb(P/'proposed'/n),rb(O/'proposed'/n),'a/'+n,'b/'+n) for n in [controller,test]))
# Full application remains separately reviewable against the installed Calendar baseline.
save('repair.patch',patch(rb(D/controller),b,'a/'+controller,'b/'+controller)+patch(b'',t,'/dev/null','b/'+test))
save('inverse.patch',patch(b,rb(D/controller),'a/'+controller,'b/'+controller)+patch(t,b'','a/'+test,'/dev/null'))
history={'manifest.json':sha(O/'manifest.json'),**{r['path']:r['sha256'] for r in json.loads(rb(O/'manifest.json'))['authored_files']}}
for n in ['independent-eligibility-review.json','independent-eligibility-review.md']:
 if (O/n).exists():history[n]=sha(O/n)
assert all(sha(O/n)==h for n,h in history.items())
save('original-packet-pins.json',json.dumps(history,indent=2)+'\n')
deps=json.loads(rb(O/'manifest.json'))['dependency_pins']
drift=[r['path'] for r in deps if sha(D/r['path'])!=r['sha256']]
assert not drift,drift
save('dependency-pins.json',json.dumps(deps,indent=2)+'\n')
save('contract-final-r2.md', '''The non-rendered assessment contract from the original proposal is unchanged. Only numeric Shift events gain extendedProps.can_view_shift:boolean, always present and default false. Gap and assessment marker records never carry this flag. The frontend offers Open Shift only for exact true; it is a read affordance and confers no Edit/Assign/MAR permission. Actual Show re-authorizes every request.

This flag requires shifts.viewAny OR shifts.viewAssigned from the existing route/controller, and the canonical Shift query under the Show-specific reports.viewAny Site bypass. If neither shifts.viewAny nor shifts.manageAny is held, the same owner and visibleToFrontline publication predicates apply. Calendar's shifts.manageAny Site bypass is separate: a management feed can lawfully display a foreign-Site row while its Show action is false. Existing Client/Site/current-worker canonical integrity is reused through applyShiftScope. No grants or direct-object denial change.

start/end remain required/date validated. Range order is judged exclusively after both worker-timezone/date-only and explicit-offset inputs normalize to UTC, preserving equal edges as an empty read. Valid mixed local half-hour ranges now reach canonical SQL/coverage; reversed resolved ranges still return422. The source-derived four mixed controls and ten direct Show parity controls are added to original24 cases, giving38 source-derived only. Actual listing/native proof remains absent.

This sibling leaves the original ad53c802/90aab65e proposal and its HOLD history immutable. Full application patch and incremental revision patch are separate. No PHP/parser/list/native/database/browser/build invocation, no source application, no assignment or Timeoff edits.
''')
save('README.md','Inactive Calendar r2: resolved mixed-zone range order and exact per-Shift Show capability.\n\nSee contract-final-r2.md and revision.patch. Original writers/constructor and all original24 source test cases remain byte-exact; two methods/two providers add14 cases. Parent must independently review and compose the sibling before any parser/list/runtime. No approvals or actual counts.\n')
origtests=re.findall(r'public (?:static )?function (\w+)\(',rb(O/'proposed'/test).decode())
proof={'status':'SOURCE_ONLY_NOT_PARSER_OR_SCENARIO_ACCEPTANCE','original_manifest_sha256':sha(O/'manifest.json'),'original_records':len(history),'original_drift':[],'dependency_count':len(deps),'dependency_drift':drift,'original_tests_providers_helpers':origtests,'original_source_test_cases':24,'added_source_test_cases':14,'proposed_source_derived_cases':38,'actual_inventory':None,'source_applied':False,'php_or_parser_invoked':False,'writers_untouched':rb(O/'proposed'/controller)[rb(O/'proposed'/controller).index(b'    public function storeShift'):] == b[b.index(b'    public function storeShift'):], 'constructor_unchanged':True}
assert proof['writers_untouched']
def validate_patch(n,reverse=False,full=False):
 lines=rb(P/n).decode().splitlines(keepends=True);i=0;records=[]
 while i<len(lines):
  assert lines[i].startswith('--- ');a=lines[i][4:].strip();z=lines[i+1][4:].strip();i+=2
  name=(a if reverse else z)[2:];name=(z if a=='/dev/null' else a)[2:] if name=='ev/null' else name
  if reverse:
   before=rb(P/'proposed'/name);after=rb(D/name) if full and name==controller else (b'' if full else rb(O/'proposed'/name))
  else:
   before=rb(D/name) if full and name==controller else (b'' if full else rb(O/'proposed'/name));after=rb(P/'proposed'/name)
  source=before.decode().splitlines(keepends=True);out=[];at=0
  while i<len(lines) and not lines[i].startswith('--- '):
   m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert m;i+=1;start=max(0,int(m[1])-1);out+=source[at:start];at=start
   while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
    row=lines[i];i+=1
    if row[0] in ' -':assert source[at]==row[1:];at+=1
    if row[0] in ' +':out.append(row[1:])
  out+=source[at:];assert ''.join(out).encode()==after,name;records.append(name)
 return records
proof['incremental_whole_forward_inverse']=validate_patch('revision.patch')==validate_patch('inverse-revision.patch',reverse=True)
proof['full_whole_forward_inverse']=validate_patch('repair.patch',full=True)==validate_patch('inverse.patch',reverse=True,full=True)
oldtest=rb(O/'proposed'/test);cut=oldtest.index(b'    private function person');assert t==oldtest[:cut]+insert.encode()+oldtest[cut:]
proof['all_original_test_methods_providers_helpers_exact']=True
proof['test_changed_only_additive_two_methods_two_providers']=True
proof['actual_shift_show_policy_pins']={n:sha(D/n) for n in ['app/Http/Controllers/ShiftController.php','app/Services/UserSiteAccessService.php','app/Models/Shift.php','routes/operations.php']}
save('static-proof.json',json.dumps(proof,indent=2)+'\n')
oldselection=json.loads(rb(O/'selection-derived.json'))
oldselection['source_derived_new_cases']=38
oldselection['methods'] += [
 {'method':'test_mixed_civil_and_offset_edges_are_ordered_only_after_worker_zone_normalisation','provider':'mixedRangeEdges','source_derived_cases':4},
 {'method':'test_calendar_detail_capability_matches_actual_show_route_scope_and_publication_without_writes','provider':'showReadCapabilities','source_derived_cases':10},
]
oldselection['actual_inventory']=None
save('selection-source-derived.json',json.dumps(oldselection,indent=2)+'\n')
files=[{'path':str(n.relative_to(P)).replace('\\','/'),'sha256':sha(n)} for n in P.rglob('*') if n.is_file() and n.name!='manifest.json']
save('manifest.json',json.dumps({'status':'INACTIVE_CALENDAR_R2_SOURCE_ONLY_REVIEW_READY','approved':False,'runtime_approved':False,'original_manifest_sha256':sha(O/'manifest.json'),'dependency_count':len(deps),'source_derived_cases':38,'actual_inventory':None,'candidate_paths':[{'path':n,'before_original_proposal':sha(O/'proposed'/n),'after':sha(P/'proposed'/n)} for n in [controller,test]],'files':files,'php_or_parser_or_runtime_invoked':False,'source_applied':False},indent=2)+'\n')
for n in ['manifest.json','revision.patch','repair.patch','contract-final-r2.md','static-proof.json']:
 print(n,sha(P/n))
print('controller',sha(P/'proposed'/controller));print('test',sha(P/'proposed'/test))
