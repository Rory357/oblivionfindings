from pathlib import Path
import hashlib, json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-coordinated-callers-proposal-20261012'
WORKSPACE = ROOT / 'test-results/workforce-timesheet-correction-workspace-draft-r2-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-review-retention-proposal-20261012'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def emit(name, raw):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), name
    p.write_bytes(raw)
def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)

assert not OUT.exists()
assert sha((BASE / 'manifest.json').read_bytes()) == 'e36375f9dc7b1dbd6822b7d7004e93bb8f324e23d80fcf3574eee75113c7b26e'
assert sha((WORKSPACE / 'manifest.json').read_bytes()) == '7fad93d7cfae41494492f8b35e3c27cb114e0e7cd1634a9f2022b8d03ac060fc'
parent = json.loads((BASE / 'manifest.json').read_bytes())
workspace = json.loads((WORKSPACE / 'manifest.json').read_bytes())
for packet, manifest in [(BASE, parent), (WORKSPACE, workspace)]:
    for name, digest in manifest['files'].items(): assert sha((packet / name).read_bytes()) == digest, name
pins = dict(parent['dependencies'])
for name, digest in pins.items(): assert sha((ROOT / name).read_bytes()) == digest, name
for packet in [BASE, WORKSPACE]:
    pins[packet.relative_to(ROOT).as_posix() + '/manifest.json'] = sha((packet / 'manifest.json').read_bytes())
for name, digest in {
    'test-results/workforce-timesheet-coordinated-callers-independent-review-20261012/review.json': '07da31224d5dcacffddf6f024dbdd91a039d0eff528a57204b86719e3b11c83d',
}.items():
    assert sha((ROOT / name).read_bytes()) == digest
    assert json.loads((ROOT / name).read_bytes())['status'] == 'CLEAR_SOURCE_ONLY'
    pins[name] = digest

prefix = 'resources/js/components/timesheets/'
action_name = prefix + 'timesheet-action-dialog.tsx'
test_name = prefix + 'timesheet-action-dialog.test.tsx'
view_name = prefix + 'view-timesheet-dialog.tsx'
index_name = 'resources/js/pages/operations/timesheets/index.tsx'
index_test_name = 'resources/js/pages/operations/timesheets/index-read.test.tsx'
action = (BASE / 'proposed' / action_name).read_bytes().decode()
action = replace(action, "import { useState } from 'react';", "import { useEffect, useLayoutEffect, useRef, useState } from 'react';")
start = action.index('export function TimesheetActionDialog(props: {')
end = action.index('    const currentClientId =', start)
action = action[:start] + '''export type TimesheetActionDialogProps = {
    open: boolean;
    action: TimesheetReviewAction | null;
    record: ViewTimesheetRow | null;
    canAct: boolean;
    writeCoordination?: Parameters<typeof useTimesheetCommand>[1];
    onOpenChange: (open: boolean) => void;
};
/** Keep this component mounted in the owning page, outside transient viewers. */
export function TimesheetActionDialog(props: TimesheetActionDialogProps) {
    const requestedKey = props.record && props.action
        ? `${props.record.id}:${props.action}` : null;
    const serial = useRef(0), wasOpen = useRef(props.open);
    const protectedForm = useRef<() => boolean>(() => true);
    const [session, setSession] = useState<{
        key: string; serial: number; record: ViewTimesheetRow; action: TimesheetReviewAction;
    } | null>(() => props.open && requestedKey && props.record && props.action
        ? { key: requestedKey, serial: 0, record: props.record, action: props.action } : null);
    useLayoutEffect(() => {
        const reopening = props.open && !wasOpen.current;
        wasOpen.current = props.open;
        if (!props.open || !requestedKey || !props.record || !props.action) return;
        if (!session || (!protectedForm.current() &&
            (requestedKey !== session.key || reopening))) {
            protectedForm.current = () => true;
            serial.current += 1;
            setSession({ key: requestedKey, serial: serial.current,
                record: props.record, action: props.action });
        }
    }, [props.open, props.record, props.action, requestedKey, session]);
    if (!session) return null;
    const targetAvailable = requestedKey === session.key;
    return <TimesheetActionBody {...props} key={`${session.key}:${session.serial}`}
        action={session.action} record={targetAvailable && props.record ? props.record : session.record}
        canAct={targetAvailable && props.canAct} targetAvailable={targetAvailable}
        protectedForm={protectedForm} releaseDraft={() => setSession(null)} />;
}
function TimesheetActionBody(props: Omit<TimesheetActionDialogProps, 'action' | 'record'> & {
    action: TimesheetReviewAction; record: ViewTimesheetRow; targetAvailable: boolean;
    protectedForm: { current: () => boolean }; releaseDraft: () => void;
}) {
    const { action, record, canAct, writeCoordination, onOpenChange } = props;
    const rawActor = usePage<SharedData>().props.auth.user?.id;
    const currentActor = typeof rawActor === 'number' && Number.isSafeInteger(rawActor) && rawActor > 0
        ? rawActor : 0;
''' + action[end:]
action = replace(action, '''    const [reason, setReason] = useState(''),
        [error, setError] = useState(''),
        [discard, setDiscard] = useState(false);''', '''    const mutationPending = useRef(false);
    const [reason, setReasonState] = useState('');
    const setReason = (value: string) => {
        mutationPending.current = true;
        setReasonState(value);
    };
    useLayoutEffect(() => { mutationPending.current = false; }, [reason]);
    const [error, setError] = useState(''), [discard, setDiscard] = useState(false);''')
action = replace(action, '''        canAct &&
        currentActor === initial.actor''', '''        canAct && props.targetAvailable &&
        currentActor === initial.actor''')
insertion = '''    const close = () => {'''
extra = '''    useEffect(() => { if (!props.open) setDiscard(false); }, [props.open]);
    useLayoutEffect(() => {
        props.protectedForm.current = () => mutationPending.current || reason !== '' ||
            command.busy.current || command.held.current || command.pending ||
            command.outcome !== null || discard || currentActor !== initial.actor;
        return () => { props.protectedForm.current = () => true; };
    }, [props.protectedForm, reason, command.pending, command.outcome, discard,
        currentActor, initial.actor, command.busy, command.held]);
    useEffect(() => {
        const warn = (event: BeforeUnloadEvent) => {
            if (!confirmed && (mutationPending.current || reason !== '' || command.busy.current ||
                command.held.current || command.outcome?.status === 'unknown')) {
                event.preventDefault(); event.returnValue = '';
            }
        };
        window.addEventListener('beforeunload', warn);
        return () => window.removeEventListener('beforeunload', warn);
    }, [reason, confirmed, command.outcome, command.busy, command.held]);
    const releaseAndClose = () => { props.releaseDraft(); onOpenChange(false); };
'''
action = replace(action, insertion, extra + insertion)
action = replace(action, '        else onOpenChange(false);', '        else releaseAndClose();')
action = replace(action, '''    return (
        <>
            <Dialog open onOpenChange={(open) => !open && close()}>''', '''    if (!props.targetAvailable || currentActor !== initial.actor || initial.actor <= 0)
        return <Dialog open={props.open} onOpenChange={(open) => !open && onOpenChange(false)}>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
                <DialogHeader>
                    <DialogTitle>Timesheet review unavailable</DialogTitle>
                    <DialogDescription>This view cannot send this review. Any entries are kept in this page.</DialogDescription>
                </DialogHeader>
                <Button variant="outline" className="frontline-tap" onClick={() => onOpenChange(false)}>Close</Button>
            </DialogContent>
        </Dialog>;
    return (
        <>
            <Dialog open={props.open} onOpenChange={(open) => !open && close()}>''')
action = replace(action, '<Button onClick={() => onOpenChange(false)}>', '<Button className="frontline-tap" onClick={releaseAndClose}>')
action = replace(action, '''                                    close and refresh to check access.''', '''                                    any entries are kept in this form. Check the
                                    current record in a new tab to check access.''')
action = replace(action, '''                                </InfoCard>
                            )}''', '''                                    <Button asChild variant="outline" className="mt-3 frontline-tap">
                                        <a href={`/operations/timesheets?view=${initial.recordId}`}
                                            target="_blank" rel="noopener noreferrer">
                                            Check current timesheet <ExternalLink className="size-4" />
                                        </a>
                                    </Button>
                                </InfoCard>
                            )}''')
action = replace(action, 'className="mt-3 min-h-11"', 'className="mt-3 frontline-tap"')
action = replace(action, '                                    onClick={close}\n                                    disabled=', '                                    onClick={close}\n                                    className="frontline-tap"\n                                    disabled=')
action = replace(action, '                                    onClick={save}\n                                    disabled=', '                                    onClick={save}\n                                    className="frontline-tap"\n                                    disabled=')
action = replace(action, '''                onConfirm={() => onOpenChange(false)}''', '''                onConfirm={() => {
                    if (command.outcome?.status === 'unknown') onOpenChange(false);
                    else releaseAndClose();
                }}''')
action = replace(action, "                        ? 'Closing does not undo an action already saved. Check the record first; your typed reason will be lost.'\n                        : 'Your unsaved reason will be lost.'", "                        ? 'Closing keeps the original reason and attempt in this page. It does not undo a saved action. Reopen the same review to check it.'\n                        : 'Closing removes the reason from this form. It does not undo an action already saved.'")

index = (WORKSPACE / 'proposed' / index_name).read_bytes().decode()
index = replace(index, '    const [createOpen, setCreateOpen]', '    const [reasonOpen, setReasonOpen] = useState(false);\n    const [createOpen, setCreateOpen]')
anchor = '''    function openViewing(row: TimesheetRow) {'''
index = replace(index, anchor, '''    function openReview(row: Pick<ViewTimesheetRow, 'id'>, action: TimesheetReviewAction) {
        const current = timesheets.data.find((candidate) => candidate.id === row.id);
        if (!current) return;
        setReasonTarget({ action, row: current });
        setReasonOpen(true);
        setViewing(null);
    }
''' + anchor)
index = replace(index, '                setReasonTarget({ action: id, row });', '                openReview(row, id);')
index = replace(index, '                additionalContent={currentViewed', '                onReviewAction={openReview}\n                additionalContent={currentViewed')
index = replace(index, '''            {reasonTarget && (
                <TimesheetActionDialog
                    open
                    action={reasonTarget.action}
                    record={currentReason ?? reasonTarget.row}
                    canAct={reasonAllowed}
                    onOpenChange={(open) => !open && setReasonTarget(null)}
                />
            )}''', '''            <TimesheetActionDialog
                open={reasonOpen}
                action={reasonTarget?.action ?? null}
                record={currentReason ?? null}
                canAct={reasonAllowed}
                onOpenChange={setReasonOpen}
            />''')

# Compose the existing workspace slot and explicit coordinated-callers View deltas.
view = (BASE / 'proposed' / view_name).read_bytes().decode()
view = replace(view, '    writeCoordination,\n}: {', '    writeCoordination,\n    additionalContent,\n    onReviewAction,\n}: {')
view = replace(view, "    writeCoordination?: Parameters<typeof TimesheetActionDialog>[0]['writeCoordination'];", "    writeCoordination?: Parameters<typeof TimesheetActionDialog>[0]['writeCoordination'];\n    additionalContent?: React.ReactNode;\n    onReviewAction?: (row: ViewTimesheetRow, action: TimesheetReviewAction) => void;")
workspace_view = (WORKSPACE / 'proposed' / view_name).read_bytes().decode()
# The mounted workspace parent's only JSX slot insertion must be retained exactly.
slot = '                    {additionalContent ? <div className="border-t border-border bg-background p-4">{additionalContent}</div> : null}'
assert workspace_view.count(slot) == 1
slot_anchor = '                    </div>\n                </div>\n\n                <footer'
view = replace(view, slot_anchor, '                    </div>\n' + slot + '\n                </div>\n\n                <footer')
view = replace(view, '    const t = timesheet;', '''    const t = timesheet;
    const requestReview = (action: TimesheetReviewAction) => {
        if (onReviewAction) onReviewAction(t, action);
        else setReasonAction(action);
    };''')
for label in ['submit', 'approve', 'reject', 'return']:
    old = f"setReasonAction('{label}')"
    assert old in view, old
    view = view.replace(old, f"requestReview('{label}')")

old_test = (BASE / 'proposed' / test_name).read_bytes()
test = old_test.decode()
test = replace(test, "const { post, on } = vi.hoisted(() => ({ post: vi.fn(),", "const { post, on, actor } = vi.hoisted(() => ({ post: vi.fn(), actor: { id: 7 },")
test = replace(test, 'auth: { user: { id: 7 }, can: {} }', 'auth: { user: { id: actor.id }, can: {} }')
test = replace(test, '    vi.clearAllMocks();', '    vi.clearAllMocks();\n    actor.id = 7;')
addition = (ROOT / 'test-results/workforce-timesheet-review-retention-fixtures-20261012.txt').read_bytes()
assert sum(line.startswith(b"it('") for line in addition.splitlines()) == 8
test_raw = test.encode() + addition
index_old_test = (WORKSPACE / 'proposed' / index_test_name).read_bytes()
index_import = b"import { act } from '@testing-library/react';\n"
index_addition = (ROOT / 'test-results/workforce-timesheet-review-retention-index-fixtures-20261012.txt').read_bytes()
assert sum(line.startswith(b"it('") for line in index_addition.splitlines()) == 2
images = {action_name: action.encode(), test_name: test_raw, index_name: index.encode(), view_name: view.encode(),
          index_test_name: index_import + index_old_test + index_addition}
entries = {name: ((BASE / 'before' / name).read_bytes(), (BASE / 'proposed' / name).read_bytes()) for name in parent['sources']}
for name in workspace['sources']:
    if name not in entries:
        entries[name] = ((WORKSPACE / 'before' / name).read_bytes(), (WORKSPACE / 'proposed' / name).read_bytes())
files, sources, unchanged = {}, {}, []
for name, (before, prior) in entries.items():
    after = images.get(name, prior)
    assert ((ROOT / name).read_bytes() if (ROOT / name).exists() else b'') == before, name
    if after == prior: unchanged.append(name)
    sources[name] = {'before_exists': (ROOT / name).exists(), 'before_sha256': sha(before), 'parent_sha256': sha(prior), 'after_sha256': sha(after)}
    for sub, raw in [('before', before), ('parent', prior), ('proposed', after)]:
        target = sub + '/' + name; emit(target, raw); files[target] = sha(raw)
    transition = {'path': name, 'before_hex': before.hex(), 'parent_hex': prior.hex(), 'after_hex': after.hex()}
    for key, raw in [('before_hex', before), ('parent_hex', prior), ('after_hex', after)]: assert bytes.fromhex(transition[key]) == raw
    target = 'raw-transitions/' + name + '.json'; emit(target, encoded(transition)); files[target] = sha((OUT / target).read_bytes())
assert len(sources) == 18 and len(unchanged) == 13
inventory = {'status': 'UNRUN', 'retained_workflow_source_slots': 91, 'new_action_declarations': 8,
    'prospective_workflow_source_slots': 99, 'foundation_source_slots_separate': 16,
    'workspace_parent_controls_separate': 28, 'new_index_route_declarations_separate': 2,
    'executed': False, 'actual_inventory': None, 'actual_count': None}
readme = '''Inactive actual Action retention and owning Index route successor, not installed or executed.

Action wrapper retains actual reason/command body across open=false, nullable closed inputs and protected target/action changes. A fail-closed actual-state probe covers raw edit barrier, typed reason, pending/busy/held/outcome/discard and actor change. Safe clean owners reset only for actual target/action change or reopen. Different/missing target or actor renders only a generic shared Dialog, no private reason/record number. Current record/permission gates still determine sending; retained row is internal memory only, not a current read grant. Commit actor parsing now refuses coerced/missing/non-safe IDs. Unknown close keeps original attempt and reason in this page; explicit known discard/Done releases. Nested confirmation closes when parent closes. Beforeunload warns about typed/pending/uncertain retained state without asserting no write/durable recovery. Denied-action guidance is neutral and reads existing record in a new tab; no close/refresh instruction losing this page's draft. Canonical controls/tokens/frontline hit area only.

Actual prepared Index composes the existing mounted correction workspace, its source-bound read privacy and slot. Review target is retained while visibility is a separate boolean; Action is always mounted outside Viewer instead of conditionally destroyed. Actual View receives optional owning onReviewAction and routes its four review buttons to Index's current-row resolver. Existing independent View fallback preserved but not claimed to retain across parent destruction. Current reason row is required; no retained row fallback is rendered after current row disappearance. Existing correction hooks/control cases remain byte-exact. Explicit coordinated-callers View forwarding remains as well as the correction workspace additionalContent slot.

Eight new actual Action source declarations cover close/reopen reason, unknown close/reopen/shared hold, nullable closed retained owner, dirty retarget, actor withdrawal/return, clean retarget, pending hidden receipt and explicit known discard. Existing Action fixture bodies preserved except the mocked shared actor is now mutable/reset for the new actor test.99 prospective workflow slots UNRUN,16 foundation and28 workspace parent controls separate. Two appended actual Index callback/current-cohort declarations are UNRUN; actual Action is not mocked, only the existing View spy and layout/transport harness. Existing whole Index suite retained after one act import. No verified native union or actual owning Index routing/render result.18 full raw transitions/13 other images exact; no parser/type/React/transport/browser behavior claimed.

Still open before activation: Index/provider/direct bulk/archive/restore/read/correction/other-host shared coordination, private read-frame pairing/current whole cohort, history/Back/page remount/durable original attempt, source authority/UUID/root/witness/GET recovery, independent View/Roster/MyDay parent ownership, current foreign-busy disabled explanation and full mobile/desktop/user journeys. This concrete legacy owning route is not complete page-wide exclusion. Source only under environmental hold, no application edit/parser/types/lint/framework/native/build/browser/process/readiness/SQL/Git/deploy/probe/admission; Control Room and Claude/eMAR unchanged. RootOwner actual backend still in progress. Actual counts null, independent review required.
'''
for name, raw in [('README.md', readme.encode()), ('inventory.json', encoded(inventory)), ('source-pins.json', encoded(pins)), ('author.py', Path(__file__).read_bytes()), ('new-action-fixtures.txt', addition)]:
    emit(name, raw); files[name] = sha(raw)
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
    'raw_transitions_exact': 18, 'unchanged_parent_images': unchanged, 'application_input_drift': [],
    'applied': False, 'runtime_invoked': False, 'actual_inventory': None, 'actual_count': None}
raw = encoded(proof); emit('source-proof.json', raw)
manifest = {'status': 'UNAPPLIED_UNRUN_REVIEW_RETENTION_AND_OWNING_ROUTE_ONLY', 'sources': sources,
    'files': files, 'dependencies': pins, 'inventory': inventory,
    'parent_manifest_sha256': sha((BASE / 'manifest.json').read_bytes()),
    'workspace_manifest_sha256': sha((WORKSPACE / 'manifest.json').read_bytes()),
    'source_proof_sha256': sha(raw), 'applied': False, 'runtime_invoked': False,
    'page_wide_coordination_complete': False, 'actual_count': None}
raw = encoded(manifest); emit('manifest.json', raw)
print(json.dumps({'manifest_sha256': sha(raw), 'source_proof_sha256': manifest['source_proof_sha256'],
    'paths': 18, 'pins': len(pins), 'unchanged_images': 13, 'workflow_source_slots_unrun': 99,
    'actual_count': None, 'applied': False}))
