<?php

namespace Tests\Feature\Rostering;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Events\CoverageSupplyAdded;
use App\Models\Client;
use App\Models\CoverageReservation;
use App\Models\Permission;
use App\Models\Role;
use App\Models\ServiceContext;
use App\Models\Shift;
use App\Models\ShiftOpenPosition;
use App\Models\ShiftTask;
use App\Models\Site;
use App\Models\StaffTimeOff;
use App\Models\TimelineEvent;
use App\Models\User;
use App\Services\Eligibility\EligibilityResult;
use App\Services\NotificationService;
use App\Services\Operations\CalendarShiftMove;
use App\Services\ShiftCoverageService;
use App\Services\ShiftStaffEligibilityService;
use Illuminate\Database\Connection;
use Illuminate\Database\DatabaseTransactionsManager;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\Support\CommittedFixtureCleanup;
use Tests\Support\OwnedTestDatabase;
use Tests\TestCase;

/** Proposed source controls. Physical root proofs require the owned native MySQL lane. */
class WorkforceCalendarMoveIntegrityTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;
    private Client $client;
    private ServiceContext $context;
    private User $actor;
    private User $worker;
    private Shift $shift;
    private bool $committed = false;

    protected function setUp(): void
    {
        parent::setUp();
        config(['app.timezone' => 'UTC', 'app.worker_timezone' => 'Pacific/Auckland']);
        Carbon::setTestNow(Carbon::parse('2026-10-12 00:00:00', 'UTC'));
        $this->beforeApplicationDestroyed(CommittedFixtureCleanup::capture()->restore(...));
        Queue::fake();
        Notification::fake();
        $this->site = Site::factory()->create(['is_active' => true, 'archived' => false, 'archived_at' => null]);
        $this->context = ServiceContext::factory()->create(['site_id' => null, 'is_active' => true]);
        $this->client = Client::factory()->create(['site_id' => $this->site->id, 'service_context_id' => $this->context->id]);
        $this->actor = $this->person(['rostering.viewAny', 'shifts.update', 'shifts.manageAny', 'shifts.viewAny']);
        $this->worker = $this->person([]);
        $this->shift = $this->row($this->worker);
    }

    protected function tearDown(): void
    {
        try {
            DB::purge('calendar_move_observer');
            if ($this->committed && DB::transactionLevel() === 0 && ! DB::connection()->getPdo()->inTransaction()) {
                DB::beginTransaction();
            }
        } finally {
            Carbon::setTestNow();
            parent::tearDown();
        }
    }

    #[DataProvider('rootActors')]
    public function test_real_root_http_move_returns_independently_read_times_and_current_tuple(string $kind): void
    {
        if ($kind === 'own') {
            $this->actor = $this->person(['rostering.viewAny', 'shifts.update']);
            $this->shift = $this->row($this->actor);
            $this->assertFalse($this->actor->canDo('shifts.manageAny'));
        }
        $source = CalendarShiftMove::source($this->shift);
        $uuid = (string) Str::uuid();
        $body = $this->body(['request_id' => $uuid]);
        $this->commitFixtures();
        $this->production(function () use ($body, $uuid, $source): void {
            $response = $this->patchMove($body)->assertOk()->assertJsonPath('ok', true);
            $saved = $this->observer()->table('shifts')->where('id', $this->shift->id)->first();
            $this->assertSame('2026-10-26 20:30:00', $saved->starts_at);
            $this->assertSame('2026-10-26 22:30:00', $saved->ends_at);
            $this->assertSame($this->shift->client_id, (int) $saved->client_id);
            $this->assertSame($this->shift->user_id, (int) $saved->user_id);
            $receipt = $response->json('calendar_move_result');
            $this->assertSame('confirmed', $receipt['outcome']);
            $this->assertSame($source, $receipt['source']);
            $this->assertSame($uuid, $receipt['request_id']);
            $this->assertSame($this->actor->id, $receipt['actor_id']);
            $this->assertSame($this->shift->id, $receipt['shift_id']);
            $this->assertSame('2026-10-26T20:30:00.000Z', $receipt['saved']['starts_at']);
            $this->assertSame('2026-10-26T22:30:00.000Z', $receipt['saved']['ends_at']);
            $this->assertSame(CalendarShiftMove::source($this->shift->fresh()), $receipt['saved']['shift_source']);
            $this->assertSame($receipt['saved']['starts_at'], Carbon::parse($response->json('shift.starts_at'))->utc()->format('Y-m-d\TH:i:s.000\Z'));
            $this->assertSame(0, DB::transactionLevel());
            $this->assertFalse(DB::connection()->getPdo()->inTransaction());
        });
    }

    public static function rootActors(): array
    {
        return [
            'lawful scoped manager' => ['manager'],
            'lawful own-only worker' => ['own'],
        ];
    }

    public function test_authorised_event_hash_matches_same_source_despite_eager_count_attributes(): void
    {
        $before = $this->state();
        $queue = $this->queue();
        $events = $this->actingAs($this->actor)->getJson(route('operations.rostering.calendar.events', [
            'start' => '2026-10-26', 'end' => '2026-11-02']))->assertOk()->json();
        $event = collect($events)->firstWhere('id', $this->shift->id);
        $this->assertSame(CalendarShiftMove::source($this->shift->fresh()), $event['extendedProps']['shift_source']);
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    #[DataProvider('denials')]
    public function test_current_canonical_authority_and_source_denials_leave_all_stores_unchanged(string $case, int $status): void
    {
        $body = $this->body();
        if ($case === 'own foreign') {
            $this->actor = $this->person(['rostering.viewAny', 'shifts.update']);
        } elseif ($case === 'foreign Site') {
            $site = Site::factory()->create(['is_active' => true, 'archived' => false, 'archived_at' => null]);
            $worker = $this->person([], $site);
            $client = Client::factory()->create(['site_id' => $site->id, 'service_context_id' => $this->context->id]);
            $this->shift = $this->row($worker, ['client_id' => $client->id, 'site_id' => $site->id]);
            $body = $this->body();
        } elseif ($case === 'corrupt Client Site') {
            $site = Site::factory()->create();
            DB::table('shifts')->where('id', $this->shift->id)->update(['site_id' => $site->id]);
        } elseif ($case === 'deleted Client') {
            $this->client->delete();
        } elseif ($case === 'inactive Site') {
            DB::table('sites')->where('id', $this->site->id)->update(['is_active' => false]);
        } elseif ($case === 'inactive worker') {
            DB::table('hr_employee_profiles')->where('user_id', $this->worker->id)->update(['is_active' => false]);
        } elseif ($case === 'stale source') {
            DB::table('shifts')->where('id', $this->shift->id)->update(['starts_at' => '2026-10-26 20:05:00']);
        } elseif ($case === 'foreign task') {
            $other = $this->row($this->worker, ['starts_at' => '2026-10-28 20:00:00', 'ends_at' => '2026-10-28 22:00:00']);
            $task = $other->tasks()->create(['label' => 'PRIVATE other task']);
            $body['tasks'] = [['id' => $task->id, 'label' => 'Overwritten', 'scheduled_time' => null]];
        } elseif ($case === 'explicit unapproved assignee') {
            $bad = $this->person([]);
            DB::table('users')->where('id', $bad->id)->update(['approved_at' => null]);
            $body['user_id'] = $bad->id;
        }
        $state = $this->state();
        $queue = $this->queue();
        $this->patchMove($body)->assertStatus($status)->assertJsonMissingPath('calendar_move_result.saved');
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    public static function denials(): array
    {
        return [
            'own foreign' => ['own foreign', 403],
            'manager outside approved Site' => ['foreign Site', 403],
            'canonical Client Site mismatch' => ['corrupt Client Site', 404],
            'soft deleted Client' => ['deleted Client', 404],
            'inactive Site' => ['inactive Site', 403],
            'inactive canonical worker' => ['inactive worker', 403],
            'displayed source retimed' => ['stale source', 409],
            'task belongs to other Shift' => ['foreign task', 404],
            'explicit unapproved worker' => ['explicit unapproved assignee', 403],
        ];
    }

    #[DataProvider('lockedStatuses')]
    public function test_existing_terminal_and_in_progress_guards_stay_locked(string $status): void
    {
        $this->shift = $this->row($this->worker, ['status' => $status,
            'actual_starts_at' => $status === 'completed' || $status === 'in_progress' ? '2026-10-26 20:00:00' : null,
            'actual_ends_at' => $status === 'completed' ? '2026-10-26 22:00:00' : null]);
        $state = $this->state();
        $queue = $this->queue();
        $this->patchMove($this->body())->assertStatus(422);
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    public static function lockedStatuses(): array
    {
        return [
            'completed' => ['completed'],
            'cancelled' => ['cancelled'],
            'in progress' => ['in_progress'],
        ];
    }

    #[DataProvider('writeFaults')]
    public function test_normal_save_and_late_observer_faults_roll_back_shift_tasks_history_and_queue(string $fault): void
    {
        $task = $this->shift->tasks()->create(['label' => 'Keep before failure', 'scheduled_time' => '10:00', 'reminder_sent_at' => now()]);
        $body = $this->body(['tasks' => [['id' => $task->id, 'label' => 'Intended task', 'scheduled_time' => '11:00']]]);
        $reached = 0;
        $id = $this->shift->id;
        if ($fault === 'save veto' || $fault === 'save alteration') {
            Shift::saving(function (Shift $row) use ($fault, $id, &$reached) {
                if ($row->id === $id) {
                    $reached++;
                    if ($fault === 'save veto') {
                        return false;
                    }
                    $row->ends_at = '2026-10-26 23:00:00';
                }
            });
        } elseif ($fault === 'task veto') {
            ShiftTask::saving(function (ShiftTask $row) use ($task, &$reached) {
                if ($row->id === $task->id) {
                    $reached++;
                    return false;
                }
            });
        } else {
            TimelineEvent::saved(function (TimelineEvent $row) use ($fault, $id, $task, &$reached): void {
                if ((int) $row->shift_id !== $id || ++$reached !== 2) {
                    return;
                }
                if ($fault === 'late Shift') {
                    DB::table('shifts')->where('id', $id)->update(['notes' => 'Unexpected listener edit']);
                } elseif ($fault === 'late task') {
                    DB::table('shift_tasks')->where('id', $task->id)->update(['is_completed' => true]);
                } elseif ($fault === 'late extra task') {
                    ShiftTask::query()->create(['shift_id' => $id, 'label' => 'Unexpected extra']);
                } else {
                    DB::table('timeline_events')->where('id', $row->id)->update(['client_id' => null]);
                }
            });
        }
        $state = $this->state();
        $queue = $this->queue();
        $this->patchMove($body)->assertStatus(409)->assertJsonMissingPath('calendar_move_result.saved');
        $this->assertGreaterThan(0, $reached);
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    public static function writeFaults(): array
    {
        return [
            'saving false' => ['save veto'],
            'saving changes requested time' => ['save alteration'],
            'task save false' => ['task veto'],
            'late history callback changes Shift' => ['late Shift'],
            'late history callback completes task' => ['late task'],
            'late history callback adds task' => ['late extra task'],
            'late history callback changes history parent' => ['late history'],
        ];
    }

    #[DataProvider('lateAuthority')]
    public function test_current_authority_is_rechecked_after_normal_history_observers(string $kind): void
    {
        $reached = 0;
        TimelineEvent::saved(function (TimelineEvent $row) use ($kind, &$reached): void {
            if ((int) $row->shift_id !== $this->shift->id || ++$reached !== 2) {
                return;
            }
            if ($kind === 'grant') {
                $permission = Permission::query()->where('key', 'shifts.update')->firstOrFail();
                DB::table('permission_user')->updateOrInsert(['user_id' => $this->actor->id, 'permission_id' => $permission->id], ['allowed' => false]);
            } elseif ($kind === 'account') {
                DB::table('users')->where('id', $this->actor->id)->update(['approved_at' => null]);
            } elseif ($kind === 'actor Site') {
                DB::table('hr_employee_profiles')->where('user_id', $this->actor->id)->update(['primary_site_id' => null, 'secondary_site_ids' => '[]']);
            } elseif ($kind === 'worker') {
                DB::table('hr_employee_profiles')->where('user_id', $this->worker->id)->update(['is_active' => false]);
            } else {
                DB::table('sites')->where('id', $this->site->id)->update(['is_active' => false]);
            }
        });
        $this->assertTrue($this->actor->canDo('shifts.update'));
        $state = $this->state();
        $queue = $this->queue();
        $this->patchMove($this->body())->assertStatus(403);
        $this->assertGreaterThanOrEqual(2, $reached);
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    public static function lateAuthority(): array
    {
        return [
            'current update grant withdrawn' => ['grant'],
            'actor unapproved' => ['account'],
            'actor approved Site withdrawn' => ['actor Site'],
            'worker profile ended' => ['worker'],
            'Site deactivated' => ['Site'],
        ];
    }

    public function test_ordinary_warning_keeps_existing_no_override_acknowledgement_or_reason_behavior(): void
    {
        $this->assertFalse($this->actor->canDo('shifts.overrideEligibility'));
        $this->mock(ShiftStaffEligibilityService::class, fn ($mock) => $mock->shouldReceive('evaluate')->twice()
            ->andReturn(EligibilityResult::fromChecks([['rule' => 'turnaround', 'passed' => false, 'severity' => 'warning', 'overrideable' => false, 'message' => 'Short turnaround']])));
        $this->commitFixtures();
        $this->production(fn () => $this->patchMove($this->body())->assertOk()->assertJsonPath('calendar_move_result.outcome', 'confirmed'));
    }

    public function test_real_time_off_hard_block_prevents_the_move_without_exposing_private_notes(): void
    {
        StaffTimeOff::query()->create(['user_id' => $this->worker->id, 'starts_at' => '2026-10-26 20:00:00',
            'ends_at' => '2026-10-26 23:00:00', 'type' => 'leave', 'label' => 'PRIVATE leave label', 'notes' => 'PRIVATE leave reason', 'created_by' => $this->worker->id]);
        $state = $this->state();
        $response = $this->patchMove($this->body())->assertStatus(422);
        $this->assertStringNotContainsString('PRIVATE', $response->getContent());
        $this->assertSame($state, $this->state());
    }

    public function test_manual_task_edit_preserves_worker_source_task_and_completion_and_reminder_policy(): void
    {
        $manual = $this->shift->tasks()->create(['label' => 'Manual', 'scheduled_time' => '10:00', 'reminder_sent_at' => now()]);
        $protected = $this->shift->tasks()->create(['label' => 'Worker source', 'scheduled_time' => null, 'creation_key' => (string) Str::uuid(), 'created_by' => $this->worker->id]);
        $protectedBefore = $protected->getRawOriginal();
        $body = $this->body(['tasks' => [['id' => $manual->id, 'label' => 'Retimed manual', 'scheduled_time' => '11:00'],
            ['id' => $protected->id, 'label' => 'Must not overwrite', 'scheduled_time' => '12:00']]]);
        $this->commitFixtures();
        $this->production(function () use ($body, $manual, $protected, $protectedBefore): void {
            $this->patchMove($body)->assertOk();
            $this->assertSame($protectedBefore, $protected->fresh()->getRawOriginal());
            $task = $this->observer()->table('shift_tasks')->where('id', $manual->id)->first();
            $this->assertSame('Retimed manual', $task->label);
            $this->assertSame('11:00:00', $task->scheduled_time);
            $this->assertNull($task->reminder_sent_at);
            $this->assertSame(0, (int) $task->is_completed);
        });
    }

    #[DataProvider('holdFaults')]
    public function test_explicit_hold_fulfillment_keeps_full_intent_and_rolls_back_normal_observer_changes(string $kind): void
    {
        $hold = CoverageReservation::query()->create(['site_id' => $this->site->id, 'reserved_by_user_id' => $this->actor->id,
            'reservation_token' => (string) Str::uuid(), 'status' => 'active', 'reason' => 'calendar_update',
            'window_starts_at' => '2026-10-26 20:30:00', 'window_ends_at' => '2026-10-26 22:30:00',
            'expires_at' => now()->addMinutes(5), 'meta' => ['source' => 'calendar_update', 'slot_key' => 'kept']])->fresh();
        $reached = 0;
        if ($kind === 'late') {
            Event::listen(CoverageSupplyAdded::class, function () use ($hold, &$reached): void {
                $reached++;
                DB::table('coverage_reservations')->where('id', $hold->id)->update(['reason' => 'unexpected']);
            });
        } elseif ($kind !== 'positive') {
            CoverageReservation::updating(function (CoverageReservation $row) use ($kind, $hold, &$reached) {
                if ($row->id !== $hold->id) {
                    return;
                }
                $reached++;
                if ($kind === 'veto') {
                    return false;
                }
                if ($kind === 'owner') {
                    $row->reserved_by_user_id = $this->worker->id;
                } else {
                    $row->expires_at = now()->addHour();
                }
            });
        }
        $body = $this->body(['coverage_reservation_token' => $hold->reservation_token]);
        $before = $this->state();
        $queue = $this->queue();
        if ($kind === 'positive') {
            $this->commitFixtures();
            $this->production(function () use ($body, $hold): void {
                $this->patchMove($body)->assertOk();
                $saved = $this->observer()->table('coverage_reservations')->where('id', $hold->id)->first();
                $this->assertSame('fulfilled', $saved->status);
                $this->assertSame($this->shift->id, (int) $saved->shift_id);
                $this->assertSame($this->actor->id, (int) $saved->reserved_by_user_id);
                $this->assertSame($hold->window_starts_at->format('Y-m-d H:i:s'), $saved->window_starts_at);
                $this->assertSame('calendar_update', $saved->reason);
                $this->assertSame(now()->format('Y-m-d H:i:s'), $saved->expires_at);
            });
        } else {
            $this->patchMove($body)->assertStatus(409);
            $this->assertGreaterThan(0, $reached);
            $this->assertSame($before, $this->state());
            $this->assertSame($queue, $this->queue());
        }
    }

    public static function holdFaults(): array
    {
        return [
            'root hold fulfilled with literal owner window expiry' => ['positive'],
            'hold updating false' => ['veto'],
            'hold updating changes owner' => ['owner'],
            'hold updating extends expiry' => ['expiry'],
            'supply callback changes hold after readback' => ['late'],
        ];
    }

    public function test_automatic_hold_creation_is_checked_before_observers_and_rolls_back_veto(): void
    {
        $this->mock(ShiftCoverageService::class, function ($mock): void {
            $mock->shouldReceive('findCoverageWindow')->andReturn(['site_id' => $this->site->id, 'rule_id' => null,
                'starts_at' => '2026-10-26T20:30:00Z', 'ends_at' => '2026-10-26T22:30:00Z',
                'unfilled_after_open_shifts' => 1, 'coverage_slots' => [], 'planned_role_shortages' => [], 'role_shortages' => []]);
        });
        $reached = false;
        CoverageReservation::creating(function () use (&$reached) {
            $reached = true;
            return false;
        });
        $state = $this->state();
        $queue = $this->queue();
        $this->patchMove($this->body(['user_id' => null]))->assertStatus(409);
        $this->assertTrue($reached);
        $this->assertSame($state, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    #[DataProvider('nestedOutcomes')]
    public function test_nested_saved_change_withholds_confirmation_until_its_owning_transaction_finishes(bool $commit): void
    {
        $body = $this->body();
        $this->commitFixtures();
        $this->production(function () use ($commit, $body): void {
            DB::beginTransaction();
            $this->patchMove($body)->assertStatus(202)->assertJsonPath('ok', false)
                ->assertJsonPath('calendar_move_result.outcome', 'not_confirmed')->assertJsonMissingPath('calendar_move_result.saved');
            $this->assertSame('2026-10-26 20:00:00', $this->observer()->table('shifts')->where('id', $this->shift->id)->value('starts_at'));
            $commit ? DB::commit() : DB::rollBack();
            $this->assertSame($commit ? '2026-10-26 20:30:00' : '2026-10-26 20:00:00',
                $this->observer()->table('shifts')->where('id', $this->shift->id)->value('starts_at'));
        });
    }

    public static function nestedOutcomes(): array
    {
        return [
            'outer later commits' => [true],
            'outer later rolls back' => [false],
        ];
    }

    public function test_raw_pdo_enclosure_is_untouched_and_never_claims_a_save(): void
    {
        $body = $this->body();
        $this->commitFixtures();
        $this->production(function () use ($body): void {
            $pdo = DB::connection()->getPdo();
            $pdo->beginTransaction();
            $before = $this->state();
            try {
                $this->patchMove($body)->assertStatus(202)->assertJsonPath('calendar_move_result.outcome', 'not_confirmed');
                $this->assertSame(0, DB::transactionLevel());
                $this->assertTrue($pdo->inTransaction());
                $this->assertSame($before, $this->state());
            } finally {
                $pdo->rollBack();
            }
        });
    }

    #[DataProvider('readFaults')]
    public function test_postcommit_readback_failure_is_unknown_while_independent_writer_proves_the_move(string $fault): void
    {
        app()->instance(CalendarShiftMove::class, new class($fault) extends CalendarShiftMove {
            public function __construct(private string $fault) {}
            protected function readShift(Connection $connection, int $id): ?Shift
            {
                if ($this->fault === 'exception') {
                    throw new \RuntimeException('Readback transport unavailable');
                }
                return null;
            }
        });
        $body = $this->body();
        $this->commitFixtures();
        $this->production(function () use ($body): void {
            $this->patchMove($body)->assertStatus(202)->assertJsonPath('ok', false)
                ->assertJsonPath('calendar_move_result.outcome', 'not_confirmed')->assertJsonMissingPath('shift');
            $this->assertSame('2026-10-26 20:30:00', $this->observer()->table('shifts')->where('id', $this->shift->id)->value('starts_at'));
        });
    }

    public static function readFaults(): array
    {
        return [
            'readback raises after commit' => ['exception'],
            'readback cannot find saved tuple' => ['missing'],
        ];
    }

    public function test_postcommit_notification_failure_does_not_make_saved_data_look_unsaved(): void
    {
        $body = $this->body();
        $this->commitFixtures();
        $this->mock(NotificationService::class, function ($mock): void {
            $mock->shouldReceive('notifyCrud')->once()->andReturnUsing(function (): void {
                $this->assertSame(0, DB::transactionLevel());
                $this->assertFalse(DB::connection()->getPdo()->inTransaction());
                throw new \RuntimeException('Delivery unavailable');
            });
        });
        $this->production(fn () => $this->patchMove($body)->assertOk()->assertJsonPath('calendar_move_result.outcome', 'confirmed'));
    }

    public function test_legacy_root_shape_remains_ok_with_actual_current_model_and_no_modern_receipt(): void
    {
        $body = $this->body();
        unset($body['request_id'], $body['expected_source']);
        $this->commitFixtures();
        $this->production(function () use ($body): void {
            $this->actingAs($this->actor)->patchJson(route('operations.rostering.calendar.shifts.update', $this->shift), $body)
                ->assertOk()->assertJsonPath('ok', true)->assertJsonMissingPath('calendar_move_result');
            $this->assertSame('2026-10-26 20:30:00', $this->observer()->table('shifts')->where('id', $this->shift->id)->value('starts_at'));
        });
    }

    private function person(array $keys, ?Site $site = null): User
    {
        $site ??= $this->site;
        $user = User::factory()->create(['role' => 'custom_calendar_move', 'approved_at' => now(), 'external_clinical_account' => false]);
        $role = Role::query()->create(['name' => 'calendar-move-'.$user->id, 'label' => 'Scoped Calendar proof', 'type' => 'custom', 'level' => 50]);
        foreach ($keys as $key) {
            $permission = Permission::query()->firstOrCreate(['key' => $key], ['description' => $key, 'group' => 'Operations', 'module' => 'Operations']);
            $role->permissions()->attach($permission);
        }
        $user->roles()->attach($role);
        HrEmployeeProfile::factory()->create(['user_id' => $user->id, 'primary_site_id' => $site->id, 'secondary_site_ids' => [],
            'is_active' => true, 'start_date' => '2025-01-01', 'end_date' => null, 'created_by' => $user->id, 'updated_by' => $user->id]);
        return $user->fresh();
    }

    private function row(User $worker, array $extra = []): Shift
    {
        return Shift::factory()->create(['client_id' => $this->client->id, 'site_id' => $this->site->id,
            'service_context_id' => $this->context->id, 'user_id' => $worker->id, 'created_by' => $this->actor->id,
            'starts_at' => '2026-10-26 20:00:00', 'ends_at' => '2026-10-26 22:00:00', 'status' => 'scheduled', ...$extra])->fresh();
    }

    private function body(array $extra = []): array
    {
        return ['starts_at' => '2026-10-27T09:30:00+13:00', 'ends_at' => '2026-10-27T11:30:00+13:00',
            'request_id' => (string) Str::uuid(), 'expected_source' => CalendarShiftMove::source($this->shift), ...$extra];
    }

    private function patchMove(array $body)
    {
        return $this->actingAs($this->actor)->withHeader('X-Calendar-Move-Result', 'committed-v1')
            ->patchJson(route('operations.rostering.calendar.shifts.update', $this->shift), $body);
    }

    private function state(): array
    {
        return collect(['shifts', 'shift_tasks', 'shift_series', 'shift_replacement_requests', 'shift_open_positions', 'coverage_reservations',
            'roster_periods', 'timeline_events', 'audit_logs', 'notifications', 'workforce_eligibility_rechecks', 'workforce_eligibility_observations',
            'staff_time_offs', 'hr_leave_requests', 'hr_employee_profiles', 'users', 'clients', 'sites', 'permission_user', 'role_user', 'role_permission'])
            ->mapWithKeys(fn ($table) => [$table => DB::table($table)->orderBy($table === 'permission_user' ? 'user_id' : ($table === 'role_user' ? 'user_id' : ($table === 'role_permission' ? 'role_id' : 'id')))
                ->get()->map(fn ($row) => (array) $row)->all()])->all();
    }

    private function queue(): array
    {
        return collect(Queue::pushedJobs())->map(fn ($entries) => array_map(static fn ($entry) => [
            'job' => serialize($entry['job']), 'queue' => $entry['queue'], 'data' => $entry['data'] ?? null], $entries))->all();
    }

    #[DataProvider('freshHoldLinks')]
    public function test_new_automatic_hold_cannot_acquire_observer_injected_links(string $field): void
    {
        $other = $this->row($this->worker, ['user_id' => null, 'status' => 'draft',
            'starts_at' => '2026-10-28 20:00:00', 'ends_at' => '2026-10-28 22:00:00']);
        $position = ShiftOpenPosition::create(['shift_id' => $other->id, 'status' => 'open']);
        $this->mock(ShiftCoverageService::class, function ($mock): void {
            $mock->shouldReceive('findCoverageWindow')->andReturn(['site_id' => $this->site->id, 'rule_id' => null,
                'starts_at' => '2026-10-26T20:30:00Z', 'ends_at' => '2026-10-26T22:30:00Z',
                'unfilled_after_open_shifts' => 1, 'coverage_slots' => [], 'planned_role_shortages' => [], 'role_shortages' => []]);
        });
        $reached = false;
        CoverageReservation::creating(function (CoverageReservation $row) use ($field, $other, $position, &$reached): void {
            $reached = true;
            $row->{$field} = $field === 'shift_id' ? $other->id : $position->id;
        });
        $before = $this->state();
        $queue = $this->queue();
        $this->patchMove($this->body(['user_id' => null]))->assertStatus(409)->assertJsonMissingPath('calendar_move_result.saved');
        $this->assertTrue($reached);
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    public static function freshHoldLinks(): array
    {
        return [
            'fresh hold observer attaches other Shift' => ['shift_id'],
            'fresh hold observer attaches other open position' => ['shift_open_position_id'],
        ];
    }

    #[DataProvider('destinationKinds')]
    public function test_persisted_destination_site_is_strict_after_first_normal_history_observer(string $kind): void
    {
        $otherSite = Site::factory()->create(['is_active' => true, 'archived' => false, 'archived_at' => null]);
        foreach ([$this->actor, $this->worker] as $person) {
            DB::table('hr_employee_profiles')->where('user_id', $person->id)->update(['secondary_site_ids' => json_encode([$otherSite->id], JSON_THROW_ON_ERROR)]);
        }
        $destination = Client::factory()->create(['site_id' => $this->site->id, 'service_context_id' => $this->context->id]);
        $body = $this->body(['client_id' => $destination->id]);
        if ($kind === 'unassigned') {
            $body['user_id'] = null;
        }
        $reached = false;
        if ($kind !== 'positive') {
            TimelineEvent::saved(function (TimelineEvent $row) use ($destination, $otherSite, &$reached): void {
                if ((int) $row->shift_id !== (int) $this->shift->id || $reached) {
                    return;
                }
                $reached = true;
                DB::table('clients')->where('id', $destination->id)->update(['site_id' => $otherSite->id]);
            });
        }
        $this->commitFixtures();
        $before = $this->state();
        $queue = $this->queue();
        $this->production(function () use ($kind, $body, $destination): void {
            $response = $this->patchMove($body)->assertStatus($kind === 'positive' ? 200 : 404);
            if ($kind === 'positive') {
                $response->assertJsonPath('calendar_move_result.saved.client_id', $destination->id)
                    ->assertJsonPath('calendar_move_result.saved.site_id', $this->site->id);
                $saved = $this->observer()->table('shifts')->where('id', $this->shift->id)->first();
                $this->assertSame($destination->id, (int) $saved->client_id);
                $this->assertSame($this->site->id, (int) $saved->site_id);
            } else {
                $response->assertJsonMissingPath('calendar_move_result.saved');
            }
        });
        if ($kind !== 'positive') {
            $this->assertTrue($reached);
            $this->assertSame($before, $this->state());
            $this->assertSame($queue, $this->queue());
        }
    }

    public static function destinationKinds(): array
    {
        return [
            'assigned worker authorised at both Sites cannot hide Client drift' => ['assigned'],
            'unassigned destination cannot hide Client drift' => ['unassigned'],
            'lawful canonical destination succeeds at physical root' => ['positive'],
        ];
    }

    #[DataProvider('firstSnapshotFaults')]
    public function test_first_normal_snapshot_cannot_be_hidden_by_the_later_checked_snapshot(string $kind): void
    {
        $other = $this->row($this->worker, ['starts_at' => '2026-10-28 20:00:00', 'ends_at' => '2026-10-28 22:00:00']);
        DB::table('timeline_events')->where('type', 'shift')->where('source_type', Shift::class)->where('source_id', $other->id)->delete();
        if ($kind === 'missing source') {
            DB::table('timeline_events')->where('type', 'shift')->where('source_type', Shift::class)->where('source_id', $this->shift->id)->delete();
        }
        $reached = false;
        if ($kind === 'veto') {
            TimelineEvent::saving(function (TimelineEvent $row) use (&$reached) {
                if ((int) $row->shift_id === (int) $this->shift->id && ! $reached) {
                    $reached = true;
                    return false;
                }
            });
        } else {
            TimelineEvent::saved(function (TimelineEvent $row) use ($kind, $other, &$reached): void {
                if ((int) $row->shift_id !== (int) $this->shift->id || $reached) {
                    return;
                }
                $reached = true;
                $values = in_array($kind, ['source', 'missing source'], true) ? ['source_id' => $other->id]
                    : ($kind === 'parent' ? ['client_id' => null] : ['body' => 'One-shot unexpected history body']);
                DB::table('timeline_events')->where('id', $row->id)->update($values);
            });
        }
        $before = $this->state();
        $queue = $this->queue();
        $this->patchMove($this->body())->assertStatus(409)->assertJsonMissingPath('calendar_move_result.saved');
        $this->assertTrue($reached);
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queue());
    }

    public static function firstSnapshotFaults(): array
    {
        return [
            'first existing snapshot is reparented only once' => ['source'],
            'first newly created snapshot is reparented only once' => ['missing source'],
            'first snapshot body changes before later overwrite' => ['body'],
            'first snapshot loses its canonical Client' => ['parent'],
            'first normal snapshot save returns false' => ['veto'],
        ];
    }

    private function commitFixtures(): void
    {
        $db = DB::connection();
        $this->assertTrue(app()->environment('testing'));
        $this->assertSame('mysql', $db->getDriverName());
        $this->assertSame(static::$isolatedMysqlDatabase, $db->getDatabaseName());
        $this->assertTrue(OwnedTestDatabase::isOwnedBy($db->getDatabaseName(), getmypid()));
        $this->assertSame($db->getDatabaseName(), $db->getPdo()->query('SELECT DATABASE()')->fetchColumn());
        $this->assertSame(1, $db->transactionLevel());
        DB::commit();
        $this->committed = true;
        $this->assertSame(0, $db->transactionLevel());
        $this->assertFalse($db->getPdo()->inTransaction());
    }

    private function observer(): Connection
    {
        $name = 'calendar_move_observer';
        config(['database.connections.'.$name => [...DB::connection()->getConfig(), 'name' => $name]]);
        $db = DB::connection($name);
        $this->assertSame(DB::connection()->getDatabaseName(), $db->getDatabaseName());
        $this->assertTrue(OwnedTestDatabase::isOwnedBy($db->getDatabaseName(), getmypid()));
        $this->assertSame($db->getDatabaseName(), $db->getPdo()->query('SELECT DATABASE()')->fetchColumn());
        $this->assertNotSame(DB::connection()->getPdo(), $db->getPdo());
        $this->assertSame(0, $db->transactionLevel());
        $this->assertFalse($db->getPdo()->inTransaction());
        return $db;
    }

    private function production(callable $proof): void
    {
        $db = DB::connection();
        $testing = app('db.transactions');
        $manager = new DatabaseTransactionsManager;
        $this->assertSame(0, $db->transactionLevel());
        $this->assertFalse($db->getPdo()->inTransaction());
        app()->instance('db.transactions', $manager);
        $db->setTransactionManager($manager);
        try {
            $proof();
        } finally {
            while ($db->transactionLevel() > 0) {
                $db->rollBack();
            }
            $this->assertFalse($db->getPdo()->inTransaction());
            app()->instance('db.transactions', $testing);
            $db->setTransactionManager($testing);
        }
    }
}
