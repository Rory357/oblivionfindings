from pathlib import Path
import hashlib, json, re, difflib

ROOT = Path('C:/Users/steph/Herd/oblivionfindings')
PACKET = ROOT / 'test-results/workforce-calendar-main-move-proposal-r2-20261012'
BASE = ROOT / 'test-results/workforce-calendar-main-move-proposal-20261012'
QUAL = ROOT / 'test-results/workforce-calendar-qualification-ack-proposal-20261012'
READER = ROOT / 'test-results/workforce-calendar-main-reader-proposal-20261011'
sha = lambda b: hashlib.sha256(b).hexdigest()
utilities = (READER / 'author.py').read_text(encoding='utf-8-sig')
exec(utilities[utilities.index('def block('):utilities.index('before = (ROOT / CONTROLLER)')])

def save(name, value):
    path = PACKET / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == value, name
    else:
        path.write_bytes(value)

def dump(name, value):
    save(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))

assert sha((BASE / 'manifest.json').read_bytes()) == '315898f2f8e622f2cd169fe1d9c8d316a4a11fd6e83293d320abde79129c0a5b'
assert sha((BASE / 'independent-hr-review.json').read_bytes()) == '3f00bd82d79a884a2435ee8bcddf749564ea426d8472f5d1a91616a43945a0f5'
assert sha((QUAL / 'manifest.json').read_bytes()) == '458b017ec3da2777a844a156a754490b2ad2abd5f858fb41442fc6140e44f118'

def revise_command(before):
    result = before.replace(b'use App\\Models\\User;\n', b'use App\\Models\\User;\nuse App\\Models\\TimelineEvent;\n')
    old = b'            $stored = $this->write($shift, $values, $proofs);\n'
    new = b'''            $snapshot = TimelineEvent::query()->where('type', ShiftTimelineService::SNAPSHOT_EVENT_TYPE)
                ->where('source_type', Shift::class)->where('source_id', $shift->id)->lockForUpdate()->first();
            $snapshotExpected = $snapshot ? clone $snapshot : new TimelineEvent;
            if (! $snapshot) {
                $snapshotExpected->is_pinned = false;
            }
            $snapshotExpected->forceFill(app(ShiftTimelineService::class)->snapshotIntent($intent));
            $changed = $intent->isDirty();
            $stored = $this->write($shift, $values, $proofs);
            // The ordinary Shift observer writes before our explicit checked
            // snapshot. Prove that first write before a later write can hide it.
            if ($changed) {
                $observed = TimelineEvent::query()->where('type', ShiftTimelineService::SNAPSHOT_EVENT_TYPE)
                    ->where('source_type', Shift::class)->where('source_id', $stored->id)->lockForUpdate()->first();
                $expected = self::row($snapshotExpected);
                abort_unless($observed && (! $snapshot || (int) $observed->id === (int) $snapshot->id)
                    && array_intersect_key(self::row($observed), $expected) === $expected,
                    409, 'The observed calendar history does not match the intended change.');
                $proofs[$observed::class.':'.$observed->id] = [$observed::class, (int) $observed->id, self::row($observed)];
            }
'''
    assert result.count(old) == 1
    result = result.replace(old, new, 1)
    old = b'$actor = $this->authority($actor, $origin, $stored, $data);'
    new = b"$actor = $this->authority($actor, $origin, $stored, Arr::except($data, ['client_id']));"
    assert result.count(old) == 1
    result = result.replace(old, new, 1)
    old = b'        $expected = clone $row;\n'
    new = b'''        if ($row instanceof CoverageReservation && ! $row->exists) {
            // Capture the complete fresh link intent before creating observers.
            $values = ['shift_id' => null, 'shift_open_position_id' => null, ...$values];
        }
        $expected = clone $row;
'''
    assert result.count(old) == 1
    return result.replace(old, new, 1)

cmd_path = 'app/Services/Operations/CalendarShiftMove.php'
old_command = (BASE / 'proposed' / cmd_path).read_bytes()
new_command = revise_command(old_command)
timeline_path = 'app/Services/ShiftTimelineService.php'
old_timeline = (BASE / 'proposed' / timeline_path).read_bytes()
old_sync = block(old_timeline, 'syncSnapshot')
start = old_sync.index(b'        $values = ')
end = old_sync.index(b';\n        if ($checkedWrite)', start)
values = old_sync[start+len(b'        $values = '):end]
new_sync = b'''    public function syncSnapshot(Shift $shift, ?\\Closure $checkedWrite = null): TimelineEvent
    {
        $values = $this->snapshotIntent($shift);
        $keys = ['type' => $values['type'], 'source_type' => $values['source_type'], 'source_id' => $values['source_id']];
        if ($checkedWrite) {
            $row = TimelineEvent::query()->where($keys)->lockForUpdate()->first() ?? new TimelineEvent;

            return $checkedWrite($row, $values);
        }

        return TimelineEvent::query()->updateOrCreate($keys, $values);
    }

    /** Read-only literal snapshot intent, shared with the normal observer writer. */
    public function snapshotIntent(Shift $shift): array
    {
        $shift = $this->loadShiftContext($shift);

        return ['type' => self::SNAPSHOT_EVENT_TYPE, ...''' + values.strip() + b'''];
    }'''
new_timeline = old_timeline.replace(old_sync, new_sync, 1)
# The formatter expressions are reused literally; no extra timeline save/event.
assert values.strip() in block(new_timeline, 'snapshotIntent')
test_path = 'tests/Feature/Rostering/WorkforceCalendarMoveIntegrityTest.php'
old_test = (BASE / 'proposed' / test_path).read_bytes()
additions = (PACKET / 'test-additions.txt').read_bytes()

def revise_test(before):
    result = before.replace(b'use App\\Models\\Shift;\n', b'use App\\Models\\Shift;\nuse App\\Models\\ShiftOpenPosition;\n')
    assert result.count(b'    private function commitFixtures(): void') == 1
    return result.replace(b'    private function commitFixtures(): void', additions + b'    private function commitFixtures(): void', 1)

new_test = revise_test(old_test)
changes = [(cmd_path, old_command, new_command), (timeline_path, old_timeline, new_timeline), (test_path, old_test, new_test)]
preserved = {}
for path, before, after in changes:
    save('before/' + path, before)
    save('proposed/' + path, after)
    for name in re.findall(rb'^    (?:public|protected|private)(?: static)? function (\w+)\(', before, re.M):
        name = name.decode()
        if (path == cmd_path and name in ['move', 'write']) or (path == timeline_path and name == 'syncSnapshot'):
            continue
        assert block(before, name) == block(after, name)
        preserved[path + '::' + name] = sha(block(before, name))
    assert reconstruct(before, patch([(path, before, after)])) == after
    assert reconstruct(after, patch([(path, before, after)], reverse=True)) == before
save('repair.patch', patch(changes))
save('inverse.patch', patch(changes, reverse=True))

# Exact disjoint character edits from both frozen baselines are composed only
# when their changed byte ranges do not overlap, including insertion points.
def edits(before, after):
    return [(a, b, after[c:d]) for kind, a, b, c, d in difflib.SequenceMatcher(None, before, after, autojunk=False).get_opcodes() if kind != 'equal']

def apply_edits(before, rows):
    result, cursor = b'', 0
    for a, b, value in sorted(rows, key=lambda row: (row[0], row[1])):
        assert a >= cursor
        result += before[cursor:a] + value
        cursor = b
    return result + before[cursor:]

composed = []
composition = []
for path in ['app/Http/Controllers/CalendarController.php', cmd_path, test_path]:
    original = (BASE / 'proposed' / path).read_bytes()
    qualified = (QUAL / 'proposed' / path).read_bytes()
    revised = new_command if path == cmd_path else (new_test if path == test_path else original)
    r2_rows, q_rows = edits(original, revised), edits(original, qualified)
    for a, b, _ in r2_rows:
        for c, d, _ in q_rows:
            assert not (max(a, c) < min(b, d) or (a == b and c <= a <= d) or (c == d and a <= c <= b)), (path, a, b, c, d)
    combined = apply_edits(original, r2_rows + q_rows)
    if path == cmd_path:
        assert combined == revise_command(qualified)
    if path == test_path:
        assert combined == revise_test(qualified)
    save('qualification-composed/' + path, combined)
    assert reconstruct(revised, patch([(path, revised, combined)])) == combined
    assert reconstruct(combined, patch([(path, revised, combined)], reverse=True)) == revised
    composed.append((path, revised, combined))
    composition.append({'path': path, 'original_writer_sha256': sha(original), 'r2_sha256': sha(revised),
                        'qualification_sha256': sha(qualified), 'composed_sha256': sha(combined),
                        'byte_edit_ranges_disjoint': True, 'r2_edits': len(r2_rows), 'qualification_edits': len(q_rows)})
save('qualification-composed.patch', patch(composed))
save('qualification-composed-inverse.patch', patch(composed, reverse=True))
dump('composition-proof.json', composition)

history = {}
for packet in [BASE, QUAL]:
    manifest = json.loads((packet / 'manifest.json').read_text(encoding='utf-8-sig'))
    paths = ['manifest.json', *manifest['files']]
    if packet == BASE:
        paths += ['independent-hr-review.json', 'independent-hr-review.md']
    for relative in paths:
        p = packet / relative
        expected = manifest['files'].get(relative)
        if expected:
            assert sha(p.read_bytes()) == expected
        history[str(p.relative_to(ROOT)).replace('\\', '/')] = sha(p.read_bytes())
dump('prerequisite-history.json', history)
dependencies = json.loads((BASE / 'dependency-pins.json').read_text(encoding='utf-8-sig'))
dependencies['app/Models/ShiftOpenPosition.php'] = sha((ROOT / 'app/Models/ShiftOpenPosition.php').read_bytes())
dependencies['app/Models/TimelineEvent.php'] = sha((ROOT / 'app/Models/TimelineEvent.php').read_bytes())
dump('dependency-pins.json', dependencies)
drift = [{'path': path, 'expected': expected, 'actual': sha((ROOT / path).read_bytes())}
         for path, expected in dependencies.items() if sha((ROOT / path).read_bytes()) != expected]
rows = [{'path': path, 'before_sha256': sha(before), 'after_sha256': sha(after), 'raw_forward_exact': True,
         'raw_inverse_exact': True} for path, before, after in changes]
dump('source-proof.json', {'source_only': True, 'whole_transitions': rows, 'preserved_methods': preserved,
    'original_43_case_bodies_providers_helpers_exact': True, 'qualification_14_case_bodies_exact': True,
    'current_dependency_drift': drift, 'history_drift': [], 'extra_snapshot_writes': False,
    'default_unchecked_service_callers_algorithm_preserved': True, 'no_parser_or_runtime': True})
declarations = []
for name, provider, count in [
    ('test_new_automatic_hold_cannot_acquire_observer_injected_links', 'freshHoldLinks', 2),
    ('test_persisted_destination_site_is_strict_after_first_normal_history_observer', 'destinationKinds', 3),
    ('test_first_normal_snapshot_cannot_be_hidden_by_the_later_checked_snapshot', 'firstSnapshotFaults', 5)]:
    labels = re.findall(rb"'([^']+)'\s*=>", block(new_test, provider))
    assert len(labels) == count
    declarations.append({'method': name, 'provider': provider, 'source_derived_cases': count,
                         'source_dataset_labels': [x.decode() for x in labels], 'body_sha256': sha(block(new_test, name))})
dump('selection.json', {'source_derived_only': True, 'new_cases': 10, 'preserved_writer_cases': 43,
    'writer_declared_cases': 53, 'preserved_qualification_cases': 14, 'qualified_writer_declared_cases': 67,
    'actual_cases': None, 'actual_inventory': None, 'framework_enumerated': False, 'approved': False,
    'runtime_approved': False, 'new_methods': declarations})
dump('manifest.json', {'state': 'INACTIVE_SOURCE_ONLY_WRITER_SUCCESSOR_WITH_EXPLICIT_QUALIFICATION_COMPOSITION',
    'approved': False, 'runtime_approved': False, 'framework_enumerated': False, 'actual_cases': None,
    'head': None, 'paths': rows, 'writer_prerequisite_sha256': sha((BASE / 'manifest.json').read_bytes()),
    'original_hold_sha256': sha((BASE / 'independent-hr-review.json').read_bytes()),
    'qualification_prerequisite_sha256': sha((QUAL / 'manifest.json').read_bytes()),
    'new_source_derived_cases': 10, 'writer_declared_cases': 53, 'qualified_declared_cases': 67,
    'files': {str(p.relative_to(PACKET)).replace('\\', '/'): sha(p.read_bytes()) for p in sorted(PACKET.rglob('*'))
              if p.is_file() and p.name != 'manifest.json'}})
print(json.dumps({'manifest': sha((PACKET / 'manifest.json').read_bytes()), 'repair': sha((PACKET / 'repair.patch').read_bytes()),
                  'composition': sha((PACKET / 'qualification-composed.patch').read_bytes()), 'dependency_drift': drift}))
