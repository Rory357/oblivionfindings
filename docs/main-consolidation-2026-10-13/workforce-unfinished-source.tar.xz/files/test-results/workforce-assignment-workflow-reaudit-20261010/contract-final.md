# Single Shift assignment contract — inactive

This supersedes only the wire names in the preserved draft `contract.md`; its source findings and compatibility boundaries remain. No application or runtime acceptance is claimed.

Use existing candidates GET and assign/unassign POST routes. Modern POST opts in with `X-Shift-Assignment-Result: committed-v1`. Each explicit submission supplies a fresh UUID `request_id`; it is correlation, not a durable replay key. Legacy requests keep their response shape.

Candidates retains `candidates`, `current_user_id`, and `locked`, and adds `actor_id:number` and `shift_source:{shift_id:number,revision:string}`. Revision is an opaque server-issued 64-character lowercase hexadecimal digest of the canonical Shift source; the frontend must copy it, never compute it. Both assign and unassign fetch this response first. A direct Open Shift action opens the shared candidate dialog with the suggested worker preselected.

Each candidate retains `is_eligible`, `blocked_reasons:string[]`, and `warning_reasons:string[]`, and adds exactly `assessment_status:'assessed'|'unknown'`, `acknowledgement_required:boolean`, `reason_required:boolean`, and `can_override_eligibility:boolean`. Assessed pass/warning candidates are eligible; blocked and unknown candidates are not selectable. Unknown has false acknowledgement/reason/override flags and only the safe warning `Eligibility could not be assessed. Review before assigning.` Current flags are advisory; the locked writer rechecks. Every actual warning needs acknowledgement. Only a nonempty actual `overrideable_warnings` set needs a reason and the current exact `shifts.overrideEligibility` permission. Ordinary warnings can be acknowledged without that grant or a reason. No raw checks, private HR evidence, or related Client names appear in these arrays.

Modern POST requires `expected_source:{shift_id:number,revision:string}` copied exactly from `shift_source`. Its identity must equal the route Shift. Compare the digest after canonical/current authority locks, before any command write. Assign retains `user_id`, optional reservation token, acknowledgement and trimmed reason (max 2000). Unassign retains optional trimmed reason. These values never convey authority.

Separate lazy requester-bound `flash.shift_assignment_result`:

```ts
type ShiftAssignmentResult = {
  version: 1;
  scope: 'single';
  action: 'assign' | 'unassign';
  request_id: string;
  actor_id: number;
  shift_id: number;
  requested_user_id: number | null;
  expected_source: { shift_id: number; revision: string };
  outcome: 'saved' | 'not_saved';
  changed: boolean;
  source: { shift_id: number; revision: string };
  user_id: number | null;
  status: string;
  reason: null | 'eligibility_warning' | 'override_reason_required' | 'locked' | 'in_progress' | 'source_changed';
  review: null | {
    assessment_status: 'assessed' | 'unknown';
    acknowledgement_required: boolean;
    reason_required: boolean;
    can_override_eligibility: boolean;
    warning_reasons: string[];
    blocked_reasons: string[];
  };
};
```

Confirmation requires exact actor/action/UUID/Shift/requested worker/displayed source match. Saved means physical commit and persisted readback, not an Inertia callback. Assign requires returned `user_id===requested_user_id`; draft becomes scheduled, other legal statuses remain. Unassign requires `user_id===null` and `status==='draft'`. `changed` describes only user/status, never an assertion that all observer/hold/audit work was a no-op. Source returns the persisted revision. Receipt contains no private reason or raw exception.

Known `not_saved` is limited to the listed current source/status/warning decisions with proven command rollback, physical root/PDO boundary, and the captured original source unchanged by this command. A stale displayed source may differ from the current captured original; `source_changed` reports that current source. Hard blocks 422, authority 403/direct-object 404, unavailable 503 and ordinary validation remain errors, with no saved result. Nested/raw-PDO entry, connection swap, ambiguous commit, after-commit or presentation failure has no confirmation. Preserve the draft and selection; never automatically retry a POST.

Current action permission remains `shifts.manageAny`; manual Site bypass remains only `reports.viewAny`. Current account/profile, canonical Client/Site, staff Site access, workload, Leave, capacity and overrides retain their rules. A modern physical-root transaction encloses the lifecycle inner mutation and its timeline/replacement suffix. Exact required write/readback and final suffix checks must fail atomically on veto or altered intent. Default callers keep their public Shift return API and algorithms.

Return navigation accepts relative exact roster, Conflict Queue, or this Shift Show only. Roster retains canonical Monday `week`, installed `tab`, positive `staff_id`/`client_id`, and finite flat positive `site_id` values. Conflict Queue retains only its current week context. Shift Show retains its installed tab and independently validated week-only Conflict Queue return context. Reject external/control/backslash/fragment/duplicate/nested paths or unknown keys; reconstruct an allowed relative URL. Filters confer no access. Existing MedicationJourney and Show access lines remain byte-exact.

Parent callers: roster direct Open Shift/suggestion, grid/calendar/conflict reassign and unassign all use one candidate/source/receipt flow. Show clean and override callbacks are a frontend follow-up using the same POST contract; the backend Show method is outside this proposal. Editor `shift_result` remains separate. Missing optional frontend booleans default false.
