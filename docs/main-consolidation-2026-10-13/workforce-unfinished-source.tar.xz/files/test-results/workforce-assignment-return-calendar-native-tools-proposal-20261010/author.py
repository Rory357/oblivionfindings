"""Pure file authoring only. Does not invoke PHP, Git, framework, gate, process or database."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import re

PRIMARY = Path(r'C:/Users/steph/Herd/oblivionfindings')
DELIVERY = Path(r'C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
PACKET = Path(__file__).parent
RESULTS = PRIMARY / 'test-results'
OLD = RESULTS / 'workforce-assignment-native-tools-proposal-r3-20261010'
ASSIGNMENT = RESULTS / 'workforce-assignment-workflow-proposal-r3-20261010'
RETURN = RESULTS / 'workforce-calendar-return-composition-proposal-20261010'
DESIGN = RESULTS / 'workforce-assignment-return-calendar-native-design-20261010'
FORMAT = RESULTS / 'workforce-calendar-format-proposal-20261010'
OLD_NAMESPACE = 'test-results/delivery-shift-assignment-r3-20261010'
NEW_NAMESPACE = 'test-results/delivery-assignment-calendar-20261010'
OLD_BASE = 'oblivion_workforce_dlvassign_r3_20261010'
NEW_BASE = 'oblivion_workforce_dlvac_20261010'
TOOLS = OLD / 'proposed' / OLD_NAMESPACE
TARGET = PACKET / 'proposed' / NEW_NAMESPACE

def sha(b):
    return hashlib.sha256(b).hexdigest()

def read_json(p):
    return json.loads(p.read_bytes().decode('utf-8-sig'))

def write(p, b):
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_bytes() == b, f'No overwrite of different bytes: {p}'
        return
    p.write_bytes(b)

def write_json(p, d):
    write(p, (json.dumps(d, indent=2, ensure_ascii=False) + '\n').encode())

def diff(before, after, name, reverse=False):
    left = f'a/{OLD_NAMESPACE}/{name}'
    right = f'b/{NEW_NAMESPACE}/{name}'
    if reverse:
        before, after = after, before
        left, right = right, left
    return ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), after.decode().splitlines(keepends=True), fromfile=left, tofile=right)).encode()

# Reuse only the independently reviewed pure patch definitions; no authoring side effects.
definition = (RESULTS / 'workforce-leave-review-read-integration-plan-20261010/independent-eligibility-review.py').read_text()
pure = {'re': re}
exec(definition[definition.index('def patch_sections('):definition.index('\nforward = ')], pure)
patch_sections, apply_section = pure['patch_sections'], pure['apply_section']

assert not (DELIVERY / NEW_NAMESPACE).exists(), 'Future runtime namespace must be fresh.'
design = read_json(DESIGN / 'selector-design.json')
assert sha((DESIGN / 'selector-design.json').read_bytes()) == '1626ce94c6cc479f4f2523516c3b9a11bcaf00b8712d340cfe789aaf5dcbbd6a'
assert sha((DESIGN / 'design.md').read_bytes()) == 'd4eef3e3913330e0132f85528a980b48a0c29f9c368feb3083d7aa0144da6846'
assert len(design['selection']) == 13 and design['declared_method_slots'] == 106
assert all(len(row['raw_methods']) == len(row['methods']) for row in design['selection'])
profile = read_json(TOOLS / 'profile.json')
assert len(profile['source_pins']) == 117
assert profile['approved'] is False and profile['expected_cases'] is None
assert len(profile['source_derived_required_candidate_cases']) == 53
assert len(profile['historical_return_cases']) == 60
old_manifest = read_json(OLD / 'manifest.json')
assert sha((OLD / 'manifest.json').read_bytes()) == 'ba38b7e0880b8c093c4888b632fba0396c9b21e00f45fb48c1bae6c4d12967eb'
for name, h in profile['tools'].items():
    assert sha((TOOLS / name).read_bytes()) == h

calendar_profile_path = DELIVERY / 'test-results/delivery-calendar-r2-20261010/profile.json'
calendar = read_json(calendar_profile_path)
assert len(calendar['source_pins']) == 168 and calendar['expected_cases'] == 58
assert calendar['framework_enumerated'] is True and calendar['approved'] is False
calendar_map = calendar['source_pins']
formatted = {
    'app/Http/Controllers/CalendarController.php': '0539fe22a28c93a04b51b356fdb5def00380c6157a56a8bdf126e45329d65de1',
    'tests/Feature/Rostering/WorkforceCalendarReadIntegrityTest.php': '76587f52d28cfb5d2925ad61b2733a2003d698bdc06f1f16056101bf8cd80ce4',
}
for path, h in calendar_map.items():
    assert sha((DELIVERY / path).read_bytes()) == h, f'Current Calendar source drift: {path}'
for path, h in formatted.items():
    assert calendar_map[path] == h
write(PACKET / 'reference/calendar-listed-profile.json', calendar_profile_path.read_bytes())
write(PACKET / 'reference/calendar-listed-inventory.json', (calendar_profile_path.parent / 'inventory.json').read_bytes())
write(PACKET / 'reference/selector-design.json', (DESIGN / 'selector-design.json').read_bytes())
write(PACKET / 'reference/design.md', (DESIGN / 'design.md').read_bytes())
write(PACKET / 'reference/original-r3-source-transition.json', (OLD / 'reference/source-transition.json').read_bytes())

assignment_manifest = read_json(ASSIGNMENT / 'manifest.json')
assert sha((ASSIGNMENT / 'manifest.json').read_bytes()) == '6017380a03925eadf03a10e40b9736504e7033caff98880a1983a38b8b28caed'
return_manifest = read_json(RETURN / 'manifest.json')
assert sha((RETURN / 'manifest.json').read_bytes()) == '1024f577e24f16153c2ee941c3967ac47f5db979a43da3467003afb1e8f12d22'
assert len(assignment_manifest['files']) == 14 and len(return_manifest['files']) == 3

# Current snapshots, then exact reviewed R3 overlay, then exact reviewed Return overlay.
after = dict(calendar_map)
after.update(profile['source_pins'])
virtual = {}
current = {}
absent = []
for path in after:
    actual = DELIVERY / path
    if actual.exists():
        current[path] = sha(actual.read_bytes())
        virtual[path] = actual.read_bytes()
    else:
        absent.append(path)
        virtual[path] = b''

stages = []
for packet, manifest, label in [(ASSIGNMENT, assignment_manifest, 'reviewed_assignment_r3'), (RETURN, return_manifest, 'reviewed_calendar_return_composition')]:
    sections = patch_sections((packet / 'repair.patch').read_bytes())
    records = {}
    for path, pins in manifest['files'].items():
        before = virtual.get(path, b'')
        before_h = sha(before) if before else None
        assert before_h == pins['before'], f'Exact stage baseline mismatch {label}: {path}'
        intended = (packet / 'proposed' / path).read_bytes()
        assert sha(intended) == pins['after']
        section = [s for s in sections if s.splitlines()[0].removeprefix('--- ') in ('a/' + path, '/dev/null') and s.splitlines()[1].removeprefix('+++ ') == 'b/' + path]
        assert len(section) == 1, f'Unique source patch section {path}'
        assert apply_section(before, section[0]) == intended
        assert apply_section(intended, section[0], True) == before
        virtual[path] = intended
        after[path] = pins['after']
        records[path] = {'before': before_h, 'after': pins['after'], 'full_forward_inverse': True}
    stages.append({'stage': label, 'manifest_sha256': sha((packet / 'manifest.json').read_bytes()), 'repair_sha256': sha((packet / 'repair.patch').read_bytes()), 'records': records})

assert len(after) == 217 and len(current) == 208
for path, h in after.items():
    assert sha(virtual[path]) == h, f'After map lacks exact bytes: {path}'
assert set(absent) | {'tests/Feature/Operations/WorkforceCalendarShiftReturnContextTest.php'} == set(after) - set(current)
assert len(set(after) - set(current)) == 9
assert set(profile['source_pins']).issubset(after)
old117_changes = {p: {'original_r3': h, 'combined_after': after[p]} for p, h in profile['source_pins'].items() if after[p] != h}
assert set(old117_changes) == {'app/Domain/Shifts/Assignment/ShiftAssignmentReturn.php', 'app/Http/Controllers/ShiftController.php'}
changed = {p: {'before': current.get(p), 'after': h} for p, h in after.items() if current.get(p) != h}
assert len(changed) == 15
write_json(PACKET / 'reference/current-source208.json', current)
write_json(PACKET / 'reference/expected-after-source217.json', after)
write_json(PACKET / 'reference/source-transition.json', {
    'status': 'EXPECTED_AFTER_ONLY_NOT_APPLIED', 'root': str(DELIVERY),
    'snapshot_head': calendar['expected_head'], 'final_target_head': None,
    'baseline_present_files': 208, 'current_calendar_files': 168, 'original_r3_files': 117,
    'expected_after_files': 217, 'new_absent_paths': sorted(set(after) - set(current)),
    'unique_source_transitions': changed, 'reviewed_forward_inverse_stages': stages,
    'original117_removed_inputs': [], 'original117_later_composition_changes': old117_changes,
    'formatted_calendar_unchanged': formatted, 'current_leave_middleware_matches_reviewed_baseline': True,
    'current_calendar_assignment_dependencies_changed': [p for p, h in calendar_map.items() if after[p] != h],
    'calendar_and_leave_native_proofs_become_historical_after_application': True,
    'current_snapshot_is_not_product_application': True,
})

selected = copy.deepcopy(design['selection'])
test_files = [r['file'] for r in selected]
assert len(test_files) == len(set(test_files)) == 13 and all(p in after for p in test_files)
filter_parts = []
for row in selected:
    short = row['class'].split('\\')[-1]
    if row['whole_file']:
        filter_parts.append(short + '::')
    else:
        assert row['kind'] == 'phpunit_snake'
        filter_parts.append(short + '::(?:' + '|'.join(row['methods']) + r')(?:\x20with\x20data\x20set|$)')
filter_value = '(?:' + '|'.join(filter_parts) + ')'
assert ' ' not in filter_value
write_json(PACKET / 'selection.json', {
    'status': 'DECLARED_SOURCE_SELECTORS_NOT_FRAMEWORK_INVENTORY', 'selection': selected,
    'test_files': test_files, 'filter': filter_value, 'declared_method_slots': 106,
    'source_derived_by_packet': {'assignment_r3': 53, 'calendar_return': 33, 'calendar_r2': 38},
    'historical_return_mapping_cases': 60, 'actual_inventory': None, 'expected_cases': None,
    'framework_enumerated': False, 'calendar_current58_list_is_separate_not_combined_inventory': True,
})

# Pin originals without editing or interpreting legitimate runtime approval fields as proposal hashes.
history = {}
for packet in [OLD, ASSIGNMENT, RETURN, FORMAT, DESIGN]:
    for file in sorted(packet.rglob('*')):
        if file.is_file():
            history[str(file)] = sha(file.read_bytes())
for relative in ['test-results/delivery-leave-review-r4-20261010/profile.json', 'test-results/delivery-leave-review-r4-20261010/result.json', 'test-results/delivery-leave-review-r4-20261010/junit.xml', 'test-results/delivery-leave-review-r4-20261010/schema-cleanup.json', 'test-results/delivery-leave-review-r4-20261010/inventory.json', 'test-results/delivery-leave-review-r4-20261010/stdout.log', 'test-results/delivery-leave-review-r4-20261010/stderr.log', 'test-results/delivery-leave-review-r4-20261010/autoload-proof.json']:
    f = DELIVERY / relative
    history[str(f)] = sha(f.read_bytes())
assert history[str(DELIVERY / 'test-results/delivery-leave-review-r4-20261010/result.json')] == '02283cd4c511250238d12146d7c49eb029ba8a56cf023c318535440c4e7b6331'
assert history[str(DELIVERY / 'test-results/delivery-leave-review-r4-20261010/junit.xml')] == 'b6dae1d16c78f040126e15cf5e6867ed07b2aa368b64ee9b4af4f6cc80395a76'
write_json(PACKET / 'reference/immutable-input-history-pins.json', history)

tool_changes = {}
all_names = list(profile['tools']) + ['profile.json']
for name in all_names:
    before = (TOOLS / name).read_bytes()
    write(PACKET / 'baseline/original-r3' / name, before)
    if name == 'profile.json':
        continue
    b = before.replace(OLD_NAMESPACE.encode(), NEW_NAMESPACE.encode()).replace(OLD_NAMESPACE.replace('/', '\\').encode(), NEW_NAMESPACE.replace('/', '\\').encode()).replace(OLD_BASE.encode(), NEW_BASE.encode())
    if name in ('enumerate.ps1', 'run.ps1'):
        b = b.replace(b'@($profile.test_files).Count -ne 8', b'@($profile.test_files).Count -ne 13')
        b = b.replace(b'@($profile.source_pins.PSObject.Properties).Count -ne 117', b'@($profile.source_pins.PSObject.Properties).Count -ne 217')
        b = b.replace(b'@($profile.selection).Count -ne 8', b'@($profile.selection).Count -ne 13')
        b = b.replace(b'eight-file selection', b'thirteen-file selection')
    if name in ('phpunit.xml', 'phpunit-list.xml'):
        text = b.decode()
        lines = ''.join('      <file>' + str(DELIVERY / f).replace('/', '\\') + '</file>\n' for f in test_files)
        text, n = re.subn(r'(?:      <file>[^\n]+</file>\n)+', lambda _: lines, text)
        assert n == 1
        text = text.replace('Delivery assignment R3 and canonical regression union', 'Delivery assignment R3, Calendar return and current Calendar union')
        b = text.encode()
    if name in ('bootstrap.php', 'list-bootstrap.php'):
        old = b'App\\Http\\Controllers\\ShiftController::class, '
        new = old + b'App\\Http\\Controllers\\CalendarController::class, App\\Http\\Controllers\\RosteringController::class, '
        assert b.count(old) == 1
        b = b.replace(old, new)
    write(TARGET / name, b)
    tool_changes[name] = {'before': sha(before), 'after': sha(b)}

profile = copy.deepcopy(profile)
profile.update({
    'approved': False, 'inventory_authorized': False, 'syntax_authorized': False,
    'syntax_verified': False, 'syntax_sha256': None, 'expected_head': None,
    'snapshot_head': calendar['expected_head'], 'expected_cases': None,
    'framework_enumerated': False, 'inventory_sha256': None,
    'expected_source_class_counts': {}, 'expected_junit_class_counts': {},
    'test_files': test_files, 'selection': selected, 'filter': filter_value,
    'database_base': NEW_BASE, 'source_pins': after,
    'tools': {name: sha((TARGET / name).read_bytes()) for name in profile['tools']},
    'integration_plan_manifest_sha256': sha((PACKET / 'reference/source-transition.json').read_bytes()),
    'integration_patch_sha256': sha((ASSIGNMENT / 'repair.patch').read_bytes()),
    'integration_patch_stages': stages,
    'declared_method_slots': 106,
    'source_derived_cases_by_packet': {'assignment_r3': 53, 'calendar_return': 33, 'calendar_r2': 38},
    'application_approval': False, 'runtime_approval': False,
    'calendar_prerequisite_native_result_sha256': None,
    'limitations': [
        'Inactive expected-after map only; exact parent application/target HEAD and final source closure remain required.',
        'Current listed Calendar58 native/owned cleanup is pending at authoring; its actual future result remains separate.',
        '106 declared methods are not cases. All combined provider/class/count/JUnit inventory remains null until fresh actual listing.',
        'Original Assignment53, Return33 and Calendar38 are source-derived component labels, not actual combined cases or acceptance.',
        'Historical Return60 and accepted LeaveR4 237/7441 do not certify the changed source map. No composite result is claimed.',
        'No main/eMAR whole-controller import, new permissions, schema policy, durable idempotence or browser/full-project acceptance.',
    ],
})
write_json(TARGET / 'profile.json', profile)
tool_changes['profile.json'] = {'before': sha((TOOLS / 'profile.json').read_bytes()), 'after': sha((TARGET / 'profile.json').read_bytes())}

forward, inverse = b'', b''
for name in all_names:
    before, after_b = (TOOLS / name).read_bytes(), (TARGET / name).read_bytes()
    forward += diff(before, after_b, name)
    inverse += diff(before, after_b, name, True)
write(PACKET / 'repair.patch', forward)
write(PACKET / 'inverse.patch', inverse)
sections, reverse_sections = patch_sections(forward), patch_sections(inverse)
for name in all_names:
    before, after_b = (TOOLS / name).read_bytes(), (TARGET / name).read_bytes()
    fs = [s for s in sections if s.splitlines()[1] == '+++ b/' + NEW_NAMESPACE + '/' + name]
    rs = [s for s in reverse_sections if s.splitlines()[0] == '--- b/' + NEW_NAMESPACE + '/' + name]
    if before == after_b:
        assert not fs and not rs
    else:
        assert len(fs) == len(rs) == 1
        assert apply_section(before, fs[0]) == after_b
        assert apply_section(after_b, fs[0], True) == before
        assert apply_section(after_b, rs[0]) == before
    tool_changes[name]['full_forward_and_both_inverse_exact'] = True

# Native admission and retained Process/no-DROP/owned schema tail is identical after namespace normalization.
old_run = (TOOLS / 'run.ps1').read_bytes()
new_run = (TARGET / 'run.ps1').read_bytes().replace(NEW_NAMESPACE.encode(), OLD_NAMESPACE.encode())
assert new_run[new_run.index(b'function Assert-Pins'): ] == old_run[old_run.index(b'function Assert-Pins'): ]
enum_before = (TOOLS / 'enumerate.ps1').read_bytes()
enum_after = (TARGET / 'enumerate.ps1').read_bytes()
assert enum_after[enum_after.index(b'$evidence=@()'): ].replace(b'thirteen-file selection', b'eight-file selection') == enum_before[enum_before.index(b'$evidence=@()'): ]
assert (TARGET / 'pest-entry.php').read_bytes() == (TOOLS / 'pest-entry.php').read_bytes()
assert (TARGET / 'cleanup-schema.php').read_bytes().replace(NEW_BASE.encode(), OLD_BASE.encode()) == (TOOLS / 'cleanup-schema.php').read_bytes()
assert (TARGET / 'syntax.ps1').read_bytes() == (TOOLS / 'syntax.ps1').read_bytes()
for name in profile['tools']:
    assert OLD_NAMESPACE.encode() not in (TARGET / name).read_bytes()
    assert OLD_NAMESPACE.replace('/', '\\').encode() not in (TARGET / name).read_bytes()
assert b'memory_limit" value="1024M"' in (TARGET / 'phpunit.xml').read_bytes()
assert b'Count -ne 217' in (TARGET / 'run.ps1').read_bytes() and b'Count -ne 217' in (TARGET / 'enumerate.ps1').read_bytes()
assert len(NEW_BASE + '_4294967295') <= 64
for path, h in current.items():
    assert sha((DELIVERY / path).read_bytes()) == h, f'Current live drift at final proof {path}'
for path, h in history.items():
    assert sha(Path(path).read_bytes()) == h, f'Immutable history changed {path}'
write_json(PACKET / 'source-only-proof.json', {
    'status': 'SOURCE_ONLY_INACTIVE_NO_PARSER_FRAMEWORK_APPLICATION_OR_RUNTIME',
    'tools': tool_changes, 'full_tool_files': 10, 'changed_tool_patch_sections': len(sections),
    'source_stages_forward_inverse': stages, 'current_live_files': 208, 'expected_after_files': 217,
    'current_calendar_map168_live_exact': True, 'original_r3_map117_no_removed_input': True,
    'selected_files': 13, 'declared_method_slots': 106, 'actual_count': None,
    'actual_inventory': None, 'target_head': None, 'parser_invoked': False,
    'framework_invoked': False, 'runtime_invoked': False, 'product_edits': False,
    'application_approval': False, 'runtime_approval': False,
    'native_full_safety_suffix_exact_after_namespace': True,
    'raw_pest_junit_provider_mapping_suffix_byte_exact': True,
    'retained_handle_birth_no_drop_and_finally_preserved': True,
    'pest_entry_and_syntax_byte_exact': True, 'cleanup_only_database_base_literal': True,
    'heavy_zero_peer_gate_resource_and_deadline_unchanged': True,
    'no_current_calendar_or_leave_profile_rebinding': True,
    'history_pins_checked': len(history), 'live_map_drift': [], 'history_drift': [],
    'database_base_max_pid_length': len(NEW_BASE + '_4294967295'),
})
print(json.dumps({'status': 'AUTHOR_ONLY_READY', 'packet': str(PACKET), 'tool_files': 10, 'current_files': 208, 'expected_after_files': 217, 'selectors': 13, 'target_head': None, 'actual_count': None, 'history_pins': len(history)}))
