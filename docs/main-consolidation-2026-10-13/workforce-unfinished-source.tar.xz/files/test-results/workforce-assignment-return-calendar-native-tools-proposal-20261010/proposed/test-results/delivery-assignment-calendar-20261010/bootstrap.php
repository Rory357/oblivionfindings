<?php
// Executed only by the approved focused runner, never by static review.
$root = 'C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings';
$norm = static fn (string $path): string => str_replace('\\', '/', $path);
$demand = static function (bool $ok, string $why): void { if (! $ok) { throw new RuntimeException($why); } };
$demand($norm(realpath(dirname(__DIR__, 2)) ?: '') === $root && ! is_file($root.'/.env') && ! is_file($root.'/.env.testing'), 'Exact dotenv-free integration required.');
$loader = require $root.'/vendor/autoload.php';
foreach (['App\\' => '/app', 'Tests\\' => '/tests', 'Database\\Seeders\\' => '/database/seeders', 'Database\\Factories\\' => '/database/factories'] as $prefix => $folder) { $loader->addPsr4($prefix, $root.$folder, true); }
$expected = ['APP_ENV' => 'testing', 'DB_CONNECTION' => 'mysql', 'DB_DATABASE' => 'oblivion_workforce_dlvac_20261010', 'DB_HOST' => '127.0.0.1', 'DB_PORT' => '3306', 'DB_URL' => '', 'DB_SOCKET' => '', 'CACHE_STORE' => 'array', 'QUEUE_CONNECTION' => 'sync', 'SESSION_DRIVER' => 'array', 'MAIL_MAILER' => 'array', 'BROADCAST_CONNECTION' => 'null'];
foreach ($expected as $key => $value) {
    foreach ([getenv($key), $_ENV[$key] ?? $value, $_SERVER[$key] ?? $value] as $observed) {
        // Windows removes process variables set to empty; no URL/socket remains the same isolated state.
        if (in_array($key, ['DB_URL', 'DB_SOCKET'], true) && $observed === false) { $observed = ''; }
        $demand($observed === $value, 'Isolated environment mismatch: '.$key);
    }
}
$demand($norm(Pest\TestSuite::getInstance()->rootPath) === $root, 'Foreign Pest root.');
$classes = [Tests\TestCase::class, Tests\Support\OwnedTestDatabase::class, Tests\Support\CommittedFixtureCleanup::class, App\Domain\Shifts\Assignment\ShiftAssignmentCommand::class, App\Domain\Shifts\Assignment\ShiftAssignmentEvidence::class, App\Domain\Shifts\Assignment\ShiftAssignmentReceipt::class, App\Domain\Shifts\Assignment\ShiftAssignmentRefusal::class, App\Domain\Shifts\Assignment\ShiftAssignmentReturn::class, App\Domain\Shifts\Assignment\ShiftAssignmentReview::class, App\Domain\Shifts\Assignment\ShiftAssignmentSource::class, App\Domain\Shifts\Lifecycle\ShiftLifecycleService::class, App\Http\Controllers\ShiftController::class, App\Http\Controllers\CalendarController::class, App\Http\Controllers\RosteringController::class, App\Http\Middleware\HandleInertiaRequests::class, App\Domain\Hr\Services\LeaveReviewReceipt::class, App\Services\ShiftStaffEligibilityService::class, App\Services\Eligibility\AssignmentEligibilityGateway::class, App\Services\Eligibility\ProposedShiftWorkloadService::class, App\Services\AuthorizationEvidenceLockService::class, App\Services\UserSiteAccessService::class, App\Services\CoverageReservationService::class, App\Services\ShiftReplacementService::class, App\Services\ShiftTimelineService::class, App\Models\Shift::class, App\Models\CoverageReservation::class, App\Models\TimelineEvent::class, App\Models\ShiftReplacementRequest::class, App\Models\ShiftOpenPosition::class, App\Models\User::class, App\Models\Client::class, App\Models\Site::class, App\Models\ServiceContext::class, Database\Seeders\RbacSeeder::class];
$files = [];
foreach ($classes as $class) { $file = $norm((new ReflectionClass($class))->getFileName()); $demand(str_starts_with($file, $root.'/'), 'Foreign actual class: '.$class); $files[$class] = $file; }
$app = require $root.'/bootstrap/app.php';
$demand($norm($app->basePath()) === $root && $norm($app->storagePath()) === $norm(__DIR__.'/storage'), 'Actual base/storage mismatch.');
$cache = [];
foreach (['Config', 'Routes', 'Services', 'Packages'] as $kind) { $method = 'getCached'.$kind.'Path'; $path = $norm($app->$method()); $demand($path === $norm(__DIR__.'/cache/'.strtolower($kind).'.php') && ! is_file($path), 'Fresh contained cache getter mismatch.'); $cache[] = $path; }
file_put_contents(__DIR__.'/autoload-proof.json', json_encode(['pid' => getmypid(), 'root' => $root, 'storage' => $app->storagePath(), 'class_files' => $files, 'cache_paths' => $cache, 'configured_database_base' => $expected['DB_DATABASE'], 'transports' => array_intersect_key($expected, array_flip(['CACHE_STORE', 'QUEUE_CONNECTION', 'SESSION_DRIVER', 'MAIL_MAILER', 'BROADCAST_CONNECTION']))], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR));
