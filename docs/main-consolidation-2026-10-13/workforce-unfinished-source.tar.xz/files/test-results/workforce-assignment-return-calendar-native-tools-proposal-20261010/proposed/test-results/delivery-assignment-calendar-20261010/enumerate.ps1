# Inactive until exact source application and parent list approval; no native launch here.
param([switch]$List)
$ErrorActionPreference = 'Stop'
$packet = $PSScriptRoot
$profilePath = Join-Path $packet 'profile.json'
$profile = Get-Content -LiteralPath $profilePath -Raw | ConvertFrom-Json
$root = [IO.Path]::GetFullPath([string]$profile.root)
if (!$List -or $profile.inventory_authorized -ne $true -or $profile.approved -ne $false) { throw 'Explicit parent list approval required; no native launch from inventory.' }
foreach ($item in $profile.tools.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $packet $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw 'Reviewed list/native tool changed.' } }
if ($root -ne [IO.Path]::GetFullPath('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings') -or (Get-Location).Path -ne $root -or !$profile.expected_head -or (git rev-parse HEAD).Trim() -ne $profile.expected_head) { throw 'Parent-applied exact source checkpoint required before list.' }
if (@($profile.test_files).Count -ne 13 -or @($profile.source_pins.PSObject.Properties).Count -ne 217 -or @($profile.selection).Count -ne 13) { throw 'Exact assignment selection/source map required.' }
if ($profile.syntax_verified -ne $true -or !$profile.syntax_sha256 -or !(Test-Path -LiteralPath (Join-Path $packet 'syntax.json')) -or (Get-FileHash -LiteralPath (Join-Path $packet 'syntax.json') -Algorithm SHA256).Hash -ne $profile.syntax_sha256) { throw 'Exact parent syntax proof is required before listing or native execution.' }
$syntax = Get-Content -LiteralPath (Join-Path $packet 'syntax.json') -Raw | ConvertFrom-Json
if ($syntax.php_syntax_exit -ne 0 -or $syntax.powershell_ast_errors -ne 0 -or $syntax.application_bootstrap -ne $false -or $syntax.database_or_scenario_execution -ne $false -or $syntax.head -ne $profile.expected_head -or (ConvertTo-Json $syntax.source_pins -Compress -Depth 5) -ne (ConvertTo-Json $profile.source_pins -Compress -Depth 5)) { throw 'Syntax proof does not bind the current exact candidate.' }
foreach ($item in $profile.source_pins.PSObject.Properties) { if (!(Test-Path -LiteralPath (Join-Path $root $item.Name)) -or (Get-FileHash -LiteralPath (Join-Path $root $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw ('List source differs: '+$item.Name) } }
foreach ($decl in $profile.selection) { $mapped=@($decl.raw_methods.PSObject.Properties); if ($mapped.Count -ne @($decl.methods).Count -or (@($mapped.Value | Sort-Object) -join "`n") -cne (@($decl.methods | Sort-Object) -join "`n")) { throw 'Exact reviewed raw-method-to-declared mapping required.' } }
foreach ($name in @('list.stdout.log','list.stderr.log','inventory.json')) { if (Test-Path -LiteralPath (Join-Path $packet $name)) { throw 'Prior listing exists; preserve it.' } }
[xml]$config = Get-Content -LiteralPath (Join-Path $packet 'phpunit-list.xml') -Raw
if ((@($config.phpunit.testsuites.testsuite.file | ForEach-Object { [IO.Path]::GetFullPath([string]$_) } | Sort-Object) -join '|') -ne (@($profile.test_files | ForEach-Object { [IO.Path]::GetFullPath((Join-Path $root $_)) } | Sort-Object) -join '|')) { throw 'List config and reviewed files differ.' }
$php = 'C:/Users/steph/.config/herd/bin/php84/php.exe'
$arguments = @((Join-Path $packet 'pest-entry.php')) + @($profile.test_files) + @(('--configuration='+(Join-Path $packet 'phpunit-list.xml')),('--filter='+$profile.filter),'--list-tests','--colors=never')
& $php @arguments 1> (Join-Path $packet 'list.stdout.log') 2> (Join-Path $packet 'list.stderr.log')
$exitCode = $LASTEXITCODE
if ($exitCode -ne 0 -or (Get-Item -LiteralPath (Join-Path $packet 'list.stderr.log')).Length -ne 0) { throw 'Actual framework list failed; no native admission.' }
$cases = @(Get-Content -LiteralPath (Join-Path $packet 'list.stdout.log') | ForEach-Object { if ($_ -match '^\s*-\s+((?:P\\)?Tests\\.+)$') { $Matches[1] } })
if ($cases.Count -eq 0 -or @($cases | Select-Object -Unique).Count -ne $cases.Count) { throw 'No unique actual list inventory.' }
$evidence=@(); $sourceCounts=[ordered]@{}; $junitCounts=[ordered]@{}
for ($i=0; $i -lt $cases.Count; $i++) {
    $raw=[string]$cases[$i]; $normal=$raw -creplace '^P\\',''
    if ($normal -notmatch '^(Tests\\[^:]+)::(.+)$') { throw 'Unsupported actual case format; stop for review.' }
    $class=$Matches[1]; $tail=$Matches[2]
    # Installed text renderer terminal punctuation; raw output remains in the inventory.
    if ($i -eq $cases.Count-1 -and $tail.EndsWith('.')) { $tail=$tail.Substring(0,$tail.Length-1) }
    $decl=@($profile.selection | Where-Object { $_.class -ceq $class })
    if ($decl.Count -ne 1) { throw 'Actual class outside the thirteen-file selection.' }
    # Pest lists generated methods; its filter and JUnit use the declared TestDox description.
    $members=@($decl[0].raw_methods.PSObject.Properties | Where-Object { $tail -ceq $_.Name -or $tail.StartsWith(([string]$_.Name+'"'),[StringComparison]::Ordinal) -or $tail.StartsWith(([string]$_.Name+'#'),[StringComparison]::Ordinal) -or $tail.StartsWith(([string]$_.Name+' with data set '),[StringComparison]::Ordinal) })
    if ($members.Count -ne 1) { throw ('Actual method missing/ambiguous/outside selection: '+$raw) }
    $rawMethod=[string]$members[0].Name; $method=[string]$members[0].Value; $suffix=$tail.Substring($rawMethod.Length)
    if ($suffix.StartsWith(' with data set ',[StringComparison]::Ordinal)) { $suffix=$suffix.Substring(15) }
    if ($suffix -ne '' -and $suffix -notmatch '^("[^\r\n]*"|#[0-9]+)$') { throw 'Unsupported actual dataset format; stop for review.' }
    $pretty=$method
    if ($decl[0].kind -ceq 'phpunit_snake') {
        if ($method -cnotmatch '^test_[a-z_]+$') { throw 'Nonstandard PHPUnit name needs reviewed mapping.' }
        $pretty=$method.Substring(5).Replace('_',' '); $pretty=$pretty.Substring(0,1).ToUpperInvariant()+$pretty.Substring(1)
    } elseif ($decl[0].kind -cne 'pest_description') { throw 'Unsupported declared naming contract.' }
    if ($suffix -ne '') { $pretty+=' with data set '+$suffix }
    $canonical=$class+'::'+$rawMethod+$suffix; $jclass=$class.Replace('\','.'); $jid=$jclass+'::'+$pretty
    if ($decl[0].kind -ceq 'pest_description') { $pinned=@($profile.pest_case_names.PSObject.Properties | Where-Object { $_.Name -ceq $canonical }); if ($pinned.Count -ne 1 -or [string]$pinned[0].Value -cne $jid) { throw 'Actual Pest provider/JUnit name differs from the reviewed exact mapping.' } }
    $evidence += [ordered]@{raw_identity=$raw;identity=$canonical;raw_method=$rawMethod;declared_method=$method;selector=($class+'::'+$method);junit_identity=$jid;junit_class=$jclass}
    if (!$sourceCounts.Contains($class)) { $sourceCounts[$class]=0 }; $sourceCounts[$class]++
    if (!$junitCounts.Contains($jclass)) { $junitCounts[$jclass]=0 }; $junitCounts[$jclass]++
}
if (@($evidence.identity | Select-Object -Unique).Count -ne $cases.Count -or @($evidence.junit_identity | Select-Object -Unique).Count -ne $cases.Count) { throw 'Duplicate canonical/list-to-JUnit identity; stop.' }
foreach ($decl in $profile.selection) { foreach ($method in $decl.methods) { if (@($evidence | Where-Object { $_.selector -ceq ($decl.class+'::'+$method) }).Count -eq 0) { throw ('Missing required method/provider listing: '+$decl.class+'::'+$method) } } }
foreach ($pinned in $profile.pest_case_names.PSObject.Properties) { $actual=@($evidence | Where-Object { $_.identity -ceq $pinned.Name }); if ($actual.Count -ne 1 -or $actual[0].junit_identity -cne [string]$pinned.Value) { throw 'Reviewed Pest method/provider mapping missing from actual list.' } }
foreach ($required in $profile.source_derived_required_candidate_cases) { $current=@($evidence | Where-Object { $_.identity -ceq $required.identity }); if ($current.Count -ne 1 -or $current[0].junit_identity -cne $required.junit_identity) { throw 'Reviewed source-derived assignment method/provider identity missing or changed; stop.' } }
foreach ($old in $profile.historical_return_cases) { $current=@($evidence | Where-Object { $_.identity -ceq $old.identity }); if ($current.Count -ne 1 -or $current[0].junit_identity -cne $old.junit_identity) { throw 'Historical Return identity/mapping absent or changed; stop.' } }
foreach ($item in $profile.source_pins.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw 'Source changed during list.' } }
$inventory = [ordered]@{head=$profile.expected_head;source_pins=$profile.source_pins;filter=$profile.filter;count=$cases.Count;cases=$cases;case_evidence=$evidence;junit_identities=@($evidence.junit_identity);framework_exit=$exitCode;application_bootstrap=$false;database_or_scenario_execution=$false;stdout_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'list.stdout.log') -Algorithm SHA256).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'list.stderr.log') -Algorithm SHA256).Hash.ToLowerInvariant()}
$inventory | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $packet 'inventory.json') -Encoding utf8
$profile.inventory_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'inventory.json') -Algorithm SHA256).Hash.ToLowerInvariant(); $profile.expected_cases=$cases.Count; $profile.expected_source_class_counts=$sourceCounts; $profile.expected_junit_class_counts=$junitCounts; $profile.framework_enumerated=$true; $profile.approved=$false
$profile | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $profilePath -Encoding utf8
$inventory | ConvertTo-Json -Depth 3
