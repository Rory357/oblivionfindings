from pathlib import Path
import hashlib, json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-coordinated-command-hook-proposal-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-coordinated-command-hook-proposal-r2-20261012'
REVIEW = 'test-results/workforce-timesheet-coordinated-command-hook-independent-review-20261012/review.json'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def emit(name, raw):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), name
    p.write_bytes(raw)
def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)

assert not OUT.exists()
assert sha((BASE / 'manifest.json').read_bytes()) == 'ff3afd6247e51ff97aaf183af968fcc50ca8f92b22c2533fe972f155fd6c79ab'
parent = json.loads((BASE / 'manifest.json').read_bytes())
for name, digest in parent['files'].items(): assert sha((BASE / name).read_bytes()) == digest, name
assert sha((ROOT / REVIEW).read_bytes()) == '3595d22d963726c87462d371b10f342febc1c35e8150a3728955257369e6724e'
assert json.loads((ROOT / REVIEW).read_bytes())['status'] == 'HOLD_SOURCE_ONLY'
pins = dict(parent['dependencies'])
for name, digest in pins.items(): assert sha((ROOT / name).read_bytes()) == digest, name
for name in [BASE.relative_to(ROOT).as_posix() + '/manifest.json',
             BASE.relative_to(ROOT).as_posix() + '/source-proof.json', REVIEW]:
    pins[name] = sha((ROOT / name).read_bytes())

hook_name = 'resources/js/components/timesheets/use-timesheet-command.ts'
test_name = 'resources/js/components/timesheets/use-timesheet-command.test.tsx'
wizard_name = 'resources/js/components/timesheets/timesheet-wizard.tsx'
action_name = 'resources/js/components/timesheets/timesheet-action-dialog.tsx'
hook = (BASE / 'proposed' / hook_name).read_bytes().decode()
start = hook.index('        const requestedCoordination = currentCoordination.current;')
end = hook.index('        let result: TimesheetOutcome | null = null,', start)
hook = hook[:start] + '''        // Capture before tryPrepare's synchronous subscriber notifications.
        const sentContext = context, sentGeneration = generation.current;
        const requestedCoordination = currentCoordination.current;
        let lease: LocalLease | null = null;
        // A reentrant acquisition listener cannot submit through this same hook.
        busy.current = true;
''' + hook[end:]
hook = replace(hook, '''            if (knownNotSent) attempted.current = false;
            let next: TimesheetOutcome =''', '''            let noSendProven = knownNotSent;
            let next: TimesheetOutcome =''')
hook = replace(hook, '''                } else {
                    // Ordinary field errors do not certify that no write committed.''', '''                } else {
                    noSendProven = false;
                    // Ordinary field errors do not certify that no write committed.''')
hook = replace(hook, '''            held.current = next.status !== 'rejected';
            busy.current = false;''', '''            // A release/hold notification can itself commit a different context.
            // Never overwrite that new frame with a cached confirmed outcome.
            const sameContextAfterNotification = mounted.current &&
                sentContext === identity.current && sentGeneration === generation.current &&
                (lease === null || currentCoordination.current?.scope === lease.scope);
            if (!sameContextAfterNotification) {
                next = noSendProven
                    ? { status: 'rejected', message:
                        'No request was sent. This view changed; return to the original form before another action.' }
                    : { status: 'unknown', message:
                        'The record or signed-in user has changed. Check the original record before another action.',
                        ...(next.status !== 'confirmed' ? { errors: next.errors } : {}) };
            }
            if (noSendProven) attempted.current = false;
            held.current = next.status !== 'rejected';
            busy.current = false;''')
hook = replace(hook, '''        let hash: string, unchangedHash: string | undefined;''', '''        if (requestedCoordination !== undefined) {
            const scope = requestedCoordination.scope;
            const token = scope?.tryPrepare(expected.actorId) ?? null;
            if (!scope || !token) {
                busy.current = false;
                if (mounted.current && sentContext === identity.current &&
                    sentGeneration === generation.current)
                    setOutcome({ status: 'rejected', message:
                        'Saving is unavailable in this view. Keep your entries and check any earlier timesheet action.' });
                return;
            }
            lease = { scope, token, invoked: false, retiredNoSend: false };
            activeLease.current = lease;
        }
        if (!mounted.current || sentContext !== identity.current ||
            sentGeneration !== generation.current ||
            (lease !== null && (currentCoordination.current?.scope !== lease.scope ||
                !lease.scope.canDispatch(lease.token)))) {
            result = { status: 'rejected', message:
                'No request was sent because this view changed while preparing the action. Your entries are kept.' };
            finish(true);
            return;
        }
        attempted.current = true;
        setPending(true);
        setOutcome(null);
        let hash: string, unchangedHash: string | undefined;''')
wizard = (BASE / 'proposed' / wizard_name).read_bytes().decode()
wizard = replace(wizard, '''        ...(command.outcome?.status === 'rejected'
            ? command.outcome.errors''', '''        ...(command.outcome && command.outcome.status !== 'confirmed'
            ? command.outcome.errors''')
action = (BASE / 'proposed' / action_name).read_bytes().decode()
action = replace(action, '''(command.outcome?.status === 'rejected'
                                            ? Object.values(''', '''(command.outcome && command.outcome.status !== 'confirmed'
                                            ? Object.values(''')
old_test = (BASE / 'proposed' / test_name).read_bytes()
addition = (ROOT / 'test-results/workforce-timesheet-coordinated-hook-r2-fixtures-20261012.txt').read_bytes()
assert sum(line.startswith(b"it('") for line in addition.splitlines()) == 6
test = old_test + addition
assert test.startswith(old_test)
images = {hook_name: hook.encode(), test_name: test, wizard_name: wizard.encode(), action_name: action.encode()}
files, sources, unchanged = {}, {}, []
for name in parent['sources']:
    before = (BASE / 'before' / name).read_bytes()
    prior = (BASE / 'proposed' / name).read_bytes()
    after = images.get(name, prior)
    assert ((ROOT / name).read_bytes() if (ROOT / name).exists() else b'') == before, name
    if after == prior: unchanged.append(name)
    sources[name] = {'before_exists': (ROOT / name).exists(), 'before_sha256': sha(before),
        'parent_sha256': sha(prior), 'after_sha256': sha(after)}
    for prefix, image in [('before', before), ('parent', prior), ('proposed', after)]:
        target = prefix + '/' + name; emit(target, image); files[target] = sha(image)
    transition = {'path': name, 'before_hex': before.hex(), 'parent_hex': prior.hex(), 'after_hex': after.hex()}
    for key, image in [('before_hex', before), ('parent_hex', prior), ('after_hex', after)]:
        assert bytes.fromhex(transition[key]) == image
    target = 'raw-transitions/' + name + '.json'; emit(target, encoded(transition)); files[target] = sha((OUT / target).read_bytes())
assert len(sources) == 13 and len(unchanged) == 9
inventory = {'status': 'UNRUN', 'retained_workflow_source_slots': 80,
    'new_hook_declarations': 6, 'prospective_workflow_source_slots': 86,
    'foundation_source_slots_separate': 16, 'foundation_retained_unchanged': True,
    'executed': False, 'actual_inventory': None, 'actual_count': None,
    'new_actual_child_error_render_cases': None}
readme = '''Inactive R2 concrete hook/order/error-projection successor. R1 and its independent HOLD remain immutable.

Capture committed context/generation/coordination before scope acquisition notifications; same-hook raw busy barrier is raised first. Only after the returned lease is validated against mounted/current frame do attempted/pending/hash begin. Reentrant context change/restoration or unmount during acquisition immediately retires the returned uninvoked original lease without hashing/sending. Denied acquisition does not overwrite a changed frame. This owns the real returned token, not a fabricated preparation result.

Finish retains busy through scope notifications and rechecks committed context afterward. A cached matching result cannot replace a new frame's unknown state. Proved no-send stays no-send with source-change wording, not an invented uncertain request. Failed no-send release cannot be described as proved; original token operations cannot poison a new owner's token. Existing optional/explicitnull/no-callback/exact veto/unmount/original receipt boundaries remain; no extra replay or server proof.

Actual Wizard and Action error projection now accepts optional errors on either non-confirmed outcome. Generic field errors retained with unknown state can remain visible when these callers are eventually connected; no safe retry/permission/receipt is inferred. No child-render test is invented: this is a static projection repair, not actual whole UI acceptance. Unknown held buttons/recovery copy remain unchanged. Existing independent legacy calls are not yet passed the new coordination option.

All80 parent workflow source slots retained (whole hook suite exact prefix), six new actual hook declarations cover acquisition context ABA, acquisition unmount, same-hook acquisition reentry, confirmed release context change, no-send release context change and same-hook release reentry.86 prospective workflow slots UNRUN; separate16 foundation slots remain byte-exact.13 complete before/parent/after transitions and9 other images match. No exclusive scheduler timing/type/React/native/browser result is claimed.

Actual Index/provider mount, direct/bulk/archive/restore/read/correction and all other host/lifetime/context/privacy/partial-write/durable recovery integrations remain unfinished. Scope cannot grant source/Site/role authority or authenticate a saved transaction. Matching legacy receipt is existing correlation only, not a server UUID/AFTER/root/witness. Optional absent coordinator must not grant admission in the planned owning coordinated host. Do not activate this subset as full page exclusion; paired producer/root/current GET and stable host/Back/refresh remain open. No app-source/parser/type/lint/framework/native/build/browser/process/readiness/SQL/Git/deploy/probe/admission; Claude/eMAR and independent Control Room unchanged. Independent source review required; actual inventory/count null.
'''
for name, raw in [('README.md', readme.encode()), ('inventory.json', encoded(inventory)),
                  ('source-pins.json', encoded(pins)), ('author.py', Path(__file__).read_bytes()),
                  ('new-hook-fixtures.txt', addition)]:
    emit(name, raw); files[name] = sha(raw)
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
    'raw_transitions_exact': 13, 'unchanged_parent_images': unchanged,
    'parent_hook_test_bytes_exact_prefix': True, 'application_input_drift': [],
    'applied': False, 'runtime_invoked': False, 'actual_inventory': None, 'actual_count': None}
raw = encoded(proof); emit('source-proof.json', raw)
manifest = {'status': 'UNAPPLIED_UNRUN_COORDINATED_HOOK_REENTRANT_BOUNDARY_R2_ONLY',
    'sources': sources, 'files': files, 'dependencies': pins, 'inventory': inventory,
    'parent_manifest_sha256': sha((BASE / 'manifest.json').read_bytes()),
    'parent_hold_review_sha256': pins[REVIEW], 'source_proof_sha256': sha(raw),
    'applied': False, 'runtime_invoked': False, 'owning_page_integration_implemented': False, 'actual_count': None}
raw = encoded(manifest); emit('manifest.json', raw)
print(json.dumps({'manifest_sha256': sha(raw), 'source_proof_sha256': manifest['source_proof_sha256'],
    'paths': 13, 'pins': len(pins), 'unchanged_images': len(unchanged),
    'prospective_workflow_slots_unrun': 86, 'foundation_slots_unrun_separate': 16,
    'actual_inventory': None, 'applied': False}))
