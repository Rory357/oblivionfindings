from pathlib import Path
import hashlib, json
from datetime import datetime, timezone

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
OUT = ROOT / 'test-results/workforce-approved-timesheet-correction-policy-contract-20261012'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save(name, value):
    path = OUT / name
    if path.exists():
        raise RuntimeError('Refuse overwrite: ' + name)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

amend = 'test-results/workforce-timesheet-amendment-writer-mechanics-proposal-r3-20261011'
attend = 'test-results/workforce-attendance-paid-cascade-repair-proposal-r2-20261011'
expected = {
    amend + '/manifest.json': 'c5171375ed06a0cb44600764f23cfae8a567a3d9a85d2dd17c5e42581f9973d4',
    attend + '/manifest.json': 'a3f1671c3cf410d3697bc12400618de0affcaca1db86789875748ac9fd93d6a5',
}
for path, digest in expected.items():
    assert sha(ROOT / path) == digest, path

paths = [
    'AGENTS.md', 'app/Models/Timesheet.php', 'app/Models/TimesheetAmendment.php',
    'app/Models/TimesheetClientAllocation.php', 'app/Models/AppSetting.php', 'app/Models/AuditLog.php', 'app/Models/User.php',
    'app/Domain/Hr/Models/HrAttendanceSession.php', 'app/Domain/Hr/Models/HrAttendanceBreakEvent.php',
    'app/Domain/Hr/Models/HrTimeEntry.php', 'app/Domain/Hr/Models/HrTimeEntryAmendment.php',
    'app/Domain/Hr/Models/HrPayrollRun.php', 'app/Domain/Hr/Models/HrPayrollSourceUse.php',
    'app/Services/Operations/TimesheetAmendmentService.php',
    'app/Domain/Hr/Services/AttendanceService.php', 'app/Domain/Hr/Services/AttendanceTimeEntryProjector.php',
    'app/Domain/Hr/Services/PayrollExportService.php', 'app/Services/Operations/DraftTimesheetService.php',
    'app/Domain/Shifts/Timesheets/TimesheetCommandEvidence.php',
    'app/Domain/Shifts/Timesheets/TimesheetCommandReceipt.php',
    'app/Domain/Shifts/Timesheets/TimesheetPayrollAdjustmentService.php',
    'app/Domain/Shifts/Timesheets/TimesheetPayrollAdjustmentReceipt.php',
    'app/Domain/Shifts/Timesheets/TimesheetAllocationService.php',
    'app/Domain/Hr/Services/HrEligibilityRuleSettings.php',
    'app/Http/Controllers/Operations/WorkforceSettingsController.php',
    'app/Http/Controllers/TimesheetController.php', 'app/Http/Controllers/AttendanceController.php',
    'app/Http/Middleware/HandleInertiaRequests.php',
    'app/Services/Operations/WorkforceMutationGuard.php', 'app/Services/UserSiteAccessService.php',
    'app/Services/AuthorizationEvidenceLockService.php', 'app/Services/CurrentAuthorizationReads.php',
    'app/Services/ShiftSafetyInvariantService.php', 'app/Services/AuditLogger.php',
    'routes/operations.php', 'routes/hr.php', 'routes/shifts.php',
    'database/migrations/2026_04_07_080000_create_timesheet_amendments_table.php',
    'tests/Support/CommittedDatabaseTestCase.php', 'tests/Support/OwnedTestDatabase.php',
    'tests/Feature/TimesheetAmendmentWorkflowTest.php',
    'tests/Feature/Rostering/WorkforceSettingsCommandReceiptTest.php',
    'tests/Feature/Timesheets/TimesheetPayrollAdjustmentIntegrityTest.php',
    'tests/Feature/MyDayTimesheetAllocationTest.php', 'tests/Feature/TimesheetReconciliationTest.php',
    'tests/Feature/AttendanceCorrectSessionTest.php', 'tests/Feature/AttendanceAdminEndSessionTest.php',
    'tests/Feature/AttendanceBreakTest.php', 'tests/Feature/Hr/PayrollRunIntegrityTest.php',
    'tests/Feature/Finance/PayrollJournalPostingTest.php', 'tests/Feature/WorkforceAttendanceCommandReceiptTest.php',
]
# Locate rather than invent a moved prerequisite path.
paths = [p for p in paths if p != 'app/Services/Operations/DraftTimesheetService.php']
drafts = list((ROOT / 'app').rglob('DraftTimesheetService.php'))
assert len(drafts) == 1
paths.append(drafts[0].relative_to(ROOT).as_posix())
current = {p: sha(ROOT / p) for p in paths}
histories = {}
for packet in [amend, attend]:
    for name in ['manifest.json', 'independent-roster-review.json', 'contract.md']:
        path = ROOT / packet / name
        if path.exists(): histories[packet + '/' + name] = sha(path)
    manifest = json.loads((ROOT / packet / 'manifest.json').read_text(encoding='utf-8-sig'))
    for path, record in manifest.get('transitions', manifest.get('paths')).items():
        proposed = ROOT / packet / 'proposed' / path
        assert sha(proposed) == record.get('after_sha256', record.get('after'))
        histories[packet + '/proposed/' + path] = sha(proposed)

old = json.loads((ROOT / amend / 'source-pins.json').read_text(encoding='utf-8-sig'))['files']
observed = [{'path': p, 'old_sha256': old[p], 'current_sha256': h,
             'status': 'OBSERVED_CURRENT_DEPENDENCY_NOT_HISTORICAL_REPIN'}
            for p, h in current.items() if p in old and old[p] != h]
api = {
    'status': 'FROZEN_SOURCE_CONTRACT_IMPLEMENTATION_PENDING',
    'read': {'route': 'operations.workforce.settings', 'method': 'GET', 'path': '/operations/workforce-settings',
             'prop': 'timesheetCorrectionRules', 'scope': 'organisation',
             'values': {'requester_scope': ['staff_own', 'managers_only']},
             'defaults': {'requester_scope': 'staff_own'}, 'revision': '64 lowercase hexadecimal characters',
             'source': ['deployment_defaults', 'saved_override'],
             'flags': ['can_edit', 'can_view_history'], 'urls': ['update|null', 'history|null']},
    'write': {'method': 'PATCH', 'path': '/operations/workforce-settings/timesheet-correction-rules',
              'route': 'operations.workforce.settings.timesheet-correction-rules.update',
              'body': ['values.requester_scope', 'expected_revision', 'reason'],
              'authority_all': ['current approved actor', 'rostering.viewAny', 'hr.settings.manage'],
              'setting_key': 'hr.timesheet_correction_rules',
              'audit_action': 'hr.settings.timesheet_correction_rules.updated'},
    'history': {'method': 'GET', 'route': 'operations.workforce.settings.history',
                'path': '/operations/workforce-settings/history?action=timesheet_correction_rules',
                'authority_all': ['current approved actor', 'rostering.viewAny', 'hr.settings.manage']},
    'receipt': {'flash_key': 'workforce_settings_result', 'action': 'timesheet_correction_rules',
                'fields': ['action', 'actor_id', 'expected_revision', 'prior_revision', 'revision', 'changed', 'values'],
                'refresh': 'omitted; no eligibility recheck is staged',
                'physical_root_and_committed_readback_required': True,
                'automatic_retry_or_replay': False},
    'request_policy': {'default': 'staff_own', 'staff': 'own approved Timesheet; existing lawful read and canonical writable Site only',
                       'staff_proposed_fields': ['starts_at', 'ends_at', 'break_minutes'],
                       'manager_grants_any': ['timesheets.approve', 'timesheets.manageAny'],
                       'manager_direct_service_fields': 'existing AMENDABLE_FIELDS unchanged',
                       'review': 'another currently authorised manager, requested_by differs from actor',
                       'setting_change': 'new requests only; does not revoke an existing lawful pending request'},
    'linked_projection': {'source_snapshot': 'proposed nullable durable amendment JSON; no fabricated legacy backfill',
                          'effective_rows': ['Timesheet', 'closed HrAttendanceSession', 'optional existing canonical HrTimeEntry'],
                          'history_immutable': ['source snapshot', 'break events', 'Shift clocks/history'],
                          'allocation_mismatch': 'refuse application; no inferred split',
                          'payroll_protection': 'preserve exported/paid/active claims/locked periods'},
    'commands_http': 'new request/approve/reject route and matched-result DTO implementation still required; not claimed installed',
    'actual_inventory': None, 'actual_count': None, 'product_applied': False,
    'runtime_approved': False, 'source_implementation_complete': False,
}
save('api-contract.json', api)
cases = [
 ('default_staff_own', 'Absent setting; owner with viewAssigned+approved Site requests break_minutes=30', 'one pending request; no parent/Attendance mutation'),
 ('configured_manager_only', 'Saved managers_only; same lawful worker/record', '403 and complete rows/queue unchanged'),
 ('manager_request', 'Current approve or manage grant; different worker in approved Site', 'manager may request; existing wage direct-service allowlist retained'),
 ('not_other_worker', 'Ordinary staff submits another worker Timesheet under staff_own', '403 with no source/private response or writes'),
 ('not_wage_grant', 'Owner staff proposes pay_rate/pay_type/mileage/flags rather than hours/breaks', 'refuse; no broadened field authority'),
 ('read_intersection', 'Owner/current manager lacks both existing Timesheet read grants at HTTP boundary', '403 before command/private payload'),
 ('canonical_site_denial', 'Retargeted/soft-deleted Client, mismatched Shift or worker, foreign or archived Site', 'current canonical denial, report/HR grant cannot bypass'),
 ('paid_nonapproved', 'Draft/returned/submitted/paid parent', 'existing status denial; no amendment or projection writes'),
 ('different_reviewer', 'Staff pending request reviewed by distinct authorised manager', 'approved linked effective pair and exact audit'),
 ('self_review', 'Manager requests then attempts own review', 'refuse; no self-approval/review or projection change'),
 ('request_policy_late_change', 'Normal request audit callback changes setting revision to managers_only', 'full transaction rollback; initial staff-own intent cannot survive silently'),
 ('pending_policy_change', 'Lawful pending request exists; setting later changes manager-only', 'another authorised manager can still review; pending request not automatically revoked'),
 ('settings_revision', 'Two sessions capture same revision; first changes value', 'second stale write refused, exact saved value/audit preserved'),
 ('settings_veto', 'Normal AppSetting saving veto or value/version/key observer alteration', 'no receipt; exact row/audit state rollback'),
 ('settings_late_authority', 'Audit-created callback withdraws account approval/settings grant', 'rollback row+audit; no success result'),
 ('settings_noop', 'Saved/requested requester scope identical', 'changed=false and unchanged current revision; no roster refresh'),
 ('settings_nested_or_raw', 'Framework outer or unmanaged raw-PDO transaction', 'no committed settings receipt; transaction ownership remains truthful'),
 ('linked_times_positive', 'Closed canonical session+approved Timesheet+existing HR ledger; alter start/end/break', 'independent PDO observes exact three effective tuples, original snapshot/audit/history preserved'),
 ('linked_optional_ledger_absent', 'Closed canonical session/Timesheet with no HR entry/reference', 'update pair only; no silent HR ledger creation'),
 ('linked_legacy_snapshot_absent', 'Old linked pending amendment has no durable original evidence', 'local application refused; no invented snapshot/backfill'),
 ('linked_stale_attendance', 'Session/entry clocks or link changes after displayed/captured revision', '409 and full state/queue unchanged'),
 ('linked_ambiguous_cohort', 'Referenced HR entry absent/trashed/voided or conflicting entry/Timesheet', 'refuse entire approval before partial projection'),
 ('linked_history', 'Original break events and Shift actual clocks/tasks/handover exist', 'byte-exact original history remains; correction appends original/effective evidence'),
 ('linked_repeat_history', 'A second lawful correction after first applied correction', 'first original snapshot/history unchanged; second records its own before/after'),
 ('linked_open_or_break', 'Session open or break still active', 'refuse approved correction; ordinary clock workflow untouched'),
 ('linked_overlap_dst', 'Corrected worker interval touches versus overlaps another session/HR entry; DST boundary', 'half-open contact allowed, overlap refused; UTC elapsed and local work date agree'),
 ('linked_cross_date_payroll', 'Corrected start changes worker-local work date into locked/exported period', 'lock/check both old and new dates; no paid/exported reset'),
 ('linked_allocation', 'Saved split totals/bounds conflict with corrected paid hours', 'refuse application rather than prorate; saved allocations unchanged'),
 ('linked_veto_fields', 'Normal session/ledger/history or quiet Timesheet save veto or literal-field mutation', 'all parent/amendment/session/ledger/history/audit writes roll back'),
 ('linked_late_source', 'Final audit callback withdraws actor/worker/Client/Site authority or alters linked history/cohort', 'final current authority+intent/cohort detects and rolls back'),
 ('payroll_pending', 'Exported or active payroll claim on otherwise approved parent', 'record pending_external_payroll; all effective time/pay/clock rows unchanged'),
 ('external_marker', 'Existing authorised mark-processed route', 'external marker only; no claim that Attendance/Timesheet/pay amounts were applied'),
 ('root_receipt', 'Exact UUID/source/intended values; physical root with independent PDO stored tuple', 'matched requested/applied/rejected/pending_external_payroll receipt only'),
 ('nested_receipt', 'Framework or raw-PDO outer transaction', 'withhold committed receipt, no false confirmation'),
 ('postcommit_unknown', 'After-commit callback or response/receipt-read failure', 'no false rollback/no replay; explicit fresh read of correlated audit/state retains uncertainty if unproved'),
]
save('scenario-plan.json', {'status': 'FUTURE_SCENARIO_INPUTS_NOT_AUTHORED_TESTS',
                           'scenarios': [{'id': i, 'input': v, 'expected': o} for i,v,o in cases],
                           'actual_inventory': None, 'actual_count': None,
                           'existing_preservation': [
                               'tests/Feature/TimesheetAmendmentWorkflowTest.php',
                               'tests/Feature/Timesheets/TimesheetAmendmentWriterIntegrityTest.php (R3 candidate)',
                               'tests/Feature/AttendanceBreakTest.php (Attendance/pay R2 candidate)',
                               'tests/Feature/Hr/PayrollRunIntegrityTest.php (Attendance/pay R2 candidate)',
                               'tests/Feature/Finance/PayrollJournalPostingTest.php (Attendance/pay R2 candidate)',
                               'tests/Feature/AttendanceCorrectSessionTest.php',
                               'tests/Feature/AttendanceAdminEndSessionTest.php',
                               'tests/Feature/WorkforceAttendanceCommandReceiptTest.php',
                               'tests/Feature/Timesheets/TimesheetPayrollAdjustmentIntegrityTest.php',
                               'tests/Feature/MyDayTimesheetAllocationTest.php',
                               'tests/Feature/TimesheetReconciliationTest.php',
                               'tests/Feature/Rostering/WorkforceSettingsCommandReceiptTest.php'],
                           'preservation_counts': 'unset until exact candidate selection and real framework enumeration'})
evidence = {
 'status': 'SOURCE_CONTRACT_FROZEN_IMPLEMENTATION_PENDING', 'root': str(ROOT),
 'created_at_utc': datetime.now(timezone.utc).isoformat(),
 'current_sources': current, 'historical_prerequisites': histories,
 'old_dependency_observations': observed,
 'evidence': {
   'request_mechanical_gap': amend + '/proposed/app/Services/Operations/TimesheetAmendmentService.php:168 currentActor(false) has approval/Site but no own/request manager policy',
   'projection_gap': amend + '/proposed/app/Services/Operations/TimesheetAmendmentService.php:110 only Timesheet quiet save; no Attendance propagation',
   'ordinary_protection': 'app/Domain/Hr/Services/AttendanceTimeEntryProjector.php:102 assertMutableProjection explicitly rejects approved linked Timesheet; AttendanceService.php:751 calls it',
   'allocation_boundary': 'app/Domain/Shifts/Timesheets/TimesheetAllocationService.php:121/128 exact paid-hours total and valid saved split',
   'existing_payroll_branch': 'app/Domain/Shifts/Timesheets/TimesheetPayrollAdjustmentService.php:33 marker-only process; no projection writes',
   'lazy_settings_actor': 'app/Http/Middleware/HandleInertiaRequests.php:316 existing actor-filtered workforce_settings_result',
   'missing_http_surface': 'routes/operations.php:1079 only mark-processed amendment route; no current request/approve/reject amendment routes',
   'old_fixture_policy_mismatch': amend + '/proposed/tests/Feature/Timesheets/TimesheetAmendmentWriterIntegrityTest.php:48 non-owner requester has [] grants',
 },
 'no_product_patch_claimed': True, 'no_existing_packet_edited': True,
 'parser_or_framework_or_database_or_process_invoked': False,
 'actual_inventory': None, 'actual_count': None, 'implementation_or_runtime_accepted': False,
}
assert all(sha(ROOT / p) == h for p,h in current.items()), 'Source changed during capture'
assert all(sha(ROOT / p) == h for p,h in histories.items()), 'History changed during capture'
save('source-evidence.json', evidence)
authored = {p.name: sha(p) for p in OUT.iterdir() if p.is_file()}
save('manifest.json', {'status': evidence['status'], 'root': str(ROOT),
                      'authored': authored, 'source_count': len(current), 'history_count': len(histories),
                      'current_sources_sha256': sha(OUT / 'source-evidence.json'),
                      'policy_default': 'staff_own', 'product_applied': False,
                      'actual_inventory': None, 'actual_count': None, 'runtime_approved': False,
                      'next': 'source implementation and independent review; no execution approval'})
print(json.dumps({'manifest': sha(OUT/'manifest.json'), 'contract': sha(OUT/'contract.md'),
                  'api': sha(OUT/'api-contract.json'), 'evidence': sha(OUT/'source-evidence.json'),
                  'sources': len(current), 'histories': len(histories), 'old_dependency_observations': observed}))
