# Approved timesheet correction contract

Status: source plan only. No product changes, parsers, framework inventory, database activity or runtime acceptance. The human answers authorise configurable staff-own requests (the default), manager-only selection, and approved linked corrections to both effective attendance and the timesheet while retaining original clock history. They do not authorise self-approval or bypass payroll protection.

## Workforce settings API to implement

Existing page: `GET /operations/workforce-settings`, route `operations.workforce.settings`. Add the following prop; existing staffing, qualification, House and personal preference contracts remain separate.

```ts
timesheetCorrectionRules: {
    values: { requester_scope: 'staff_own' | 'managers_only' };
    defaults: { requester_scope: 'staff_own' };
    revision: string; // exactly 64 lowercase hexadecimal characters
    source: 'deployment_defaults' | 'saved_override';
    can_edit: boolean;
    can_view_history: boolean;
    scope: 'organisation';
    urls: { update: string | null; history: string | null };
}
```

The absent setting means `staff_own`; malformed saved data is unavailable and must not become a default. Store a versioned payload `{version: integer, values: {requester_scope}}` under the new AppSetting key `hr.timesheet_correction_rules`. A saved version advances only when values change; the opaque revision follows the existing settings record/version/values digest convention. No migration, new grant, tenant context, roster recheck or notification is required for this setting.

Proposed write: `PATCH /operations/workforce-settings/timesheet-correction-rules`, route `operations.workforce.settings.timesheet-correction-rules.update`. Request:

```json
{"values":{"requester_scope":"staff_own"},"expected_revision":"<current 64-hex revision>","reason":"Why the correction request policy is changing"}
```

Read the existing page under `rostering.viewAny`. `can_edit`, write and history require a currently approved actor with BOTH `rostering.viewAny` and `hr.settings.manage`. All settings write decisions occur after the existing application payroll mutex; lock current account/RBAC/profile and the exact AppSetting key. Compare expected revision; check normal save result, the exact original record ID/key, intended version/values and the required audit after normal observers. Recheck current authority and the final row/audit before returning. No global Site or reports exception is introduced by this organisation-wide setting.

History reuses `GET /operations/workforce-settings/history?action=timesheet_correction_rules`, with the same approval/grant intersection. Proposed audit action `hr.settings.timesheet_correction_rules.updated` records source key, before/after values, reason and revisions; the existing history scalar DTO remains sufficient. `urls.update/history` are null unless the corresponding authority is available.

Reuse actor-filtered lazy `flash.workforce_settings_result`. Exact committed shape:

```ts
{
    action: 'timesheet_correction_rules';
    actor_id: number;
    expected_revision: string;
    prior_revision: string;
    revision: string;
    changed: boolean;
    values: { requester_scope: 'staff_own' | 'managers_only' };
}
```

There is no `refresh` member. A no-op has `changed:false` and the same prior/current revision. Emit the result only when entry and exit are physical root (framework transaction level zero AND raw PDO outside a transaction), after the committed saved row matches the intended revision/values. Nested, raw-PDO, delivery failure or failed readback withholds confirmation. Existing redirects/toasts cannot prove this receipt. The frontend matches actor/action/expected revision/values and preserves its draft on absent, malformed, stale or uncertain result; it reloads current values deliberately, without automatic replay.

## Request and review authority

Enforce policy in the existing amendment service, not only in a hidden button. A current manager is an approved actor with the installed `timesheets.approve` OR `timesheets.manageAny` grant, including their existing HR aliases. Staff-own mode additionally admits an approved worker requesting their own approved Timesheet. Staff-own requests are limited to `starts_at`, `ends_at`, `break_minutes` plus the separate nonblank reason; this is the authorised hours/breaks path. It grants no wage, payroll, other-worker, Site, update or review authority. Manager requests retain the existing direct-service AMENDABLE_FIELDS allowlist and signatures, subject to current canonical source checks.

The public owning read requires the existing `timesheets.viewAny|timesheets.viewAssigned` intersection with canonical ownership/manager read semantics. Report-only read bypass does not confer mutation permission. Every request/review must use the current canonical Timesheet/Client/Shift/worker/Site predicate and actor's approved writable Site set, with no HR/report Site bypass. A read failure produces no source/capability DTO. A missing parent, conflicting Site or retargeted worker fails closed.

In manager-only mode a worker without a current manager grant cannot request, even their own record. Changing the setting controls NEW requests; it neither automatically rejects nor invalidates an already lawfully submitted pending request. A request must recheck the exact locked policy revision after its model/audit observers. Review requires another currently authorised manager (actor differs from `requested_by`); preserve the existing self-approval denial and do not provide a self-review route as an implicit withdrawal. Paid/non-approved records still cannot enter this request path. Exactly one pending amendment per Timesheet remains the installed invariant.

The existing R3 integrity fixture uses a non-owner requester with no grants. Once request authority is enforced, that fixture is no longer lawful. A separate successor must prepare that existing mechanical requester with an actual manager grant before capture, keeping its test IDs, body assertions and providers intact; the original R3 file remains immutable history. New own-worker controls must use the real owner and ordinary current Site membership, never a policy bypass.

## Linked approved correction projection

The current R3 service quiet-saves only the Timesheet. Ordinary `AttendanceService::correctSession` cannot be called here: its projector deliberately rejects an approved Timesheet and may return drafts or complete a Shift. Preserve that ordinary API and the reviewed Attendance/pay R2 service bodies. Implement an amendment-only linked projection within the same existing governing transaction and application mutex.

Required durable new evidence: a nullable amendment `source_snapshot` JSON column and model cast, with a versioned snapshot captured before request observers. It holds the canonical original Timesheet time/identity tuple, linked closed Attendance identity/effective clock/break tuple, optional existing HR time-entry tuple, exact original break-event/Shift clock history identity/digests, request policy revision, and canonical source revision. It contains scalar identifiers, clocks, break values and hashes, not copied clinical narrative, account email, arbitrary session metadata or qualification evidence. Existing `original_values`/`proposed_values` retain their field-level meanings and the direct-service allowlist. New requests carry proof; an old linked pending request without that proof cannot silently certify or apply unchanged attendance. Keep historical payload bytes; do not fabricate a backfill.

Use the installed lock order: application mutex; canonical parent/participant account/RBAC/profile/Site/session evidence; payroll periods for BOTH original and proposed worker-local dates; then Timesheet/amendment/optional HR ledger and ordered break/allocation/history cohorts. Identity hints only select locks. Repeat parent/worker/Site/review authority and literal intended evidence after all normal callbacks. UTC timestamps are stored; worker-local dates use `app.worker_timezone`, then `app.timezone`, then UTC. Explicit offset/UTC input at the new HTTP boundary avoids silently interpreting a browser wall time. Preserve direct-service legacy input semantics separately.

For a closed, unexported, unclaimed, approved linked Timesheet, prepare corrected starts/ends/break values once. Check positive payable duration, no current Attendance/HR worker overlap, current approved Site/worker membership and canonical link equality. Do not retarget or manufacture a parent. Require original Timesheet, session and existing HR ledger clocks/breaks to agree before applying; an unrelated prior mismatch is a reconciliation failure, not something this writer should hide. Open sessions, active breaks, voided/trashed/missing referenced ledger rows, duplicate linked Timesheets/entries and protected payroll evidence are refused.

Apply the effective Timesheet and Attendance clock/break tuple atomically. Preserve approved Timesheet status/stamps and closed Attendance status/closure/source/location/history, except explicitly intended effective clocks/breaks and correction metadata. Derive Timesheet `work_date` and existing HR `entry_date` from the corrected worker-local start after locking both date boundaries. Keep Shift planned/actual clocks, task/handover/completion rows, break event timestamps/durations/count/history, payroll/source-use/bank/journal rows and approvals untouched. An effective break total may differ from original recorded break events; the original records remain the evidence, while amendment history explains the corrected effective total.

If an HR attendance ledger already exists, update its effective clock/break/derived hours/date consistently, preserve its identity/status/approval and pay/allocation fields, and append checked per-field HrTimeEntryAmendment history plus the original Timesheet amendment snapshot. Do not silently create an HR ledger or infer a missing relationship. A non-null Timesheet HR-entry link must resolve to the same canonical entry. Normal checked saves remain enabled for session, ledger, amendment and history; retain the narrow approved-Timesheet quiet seam with explicit safety/intent/readback checks.

Capture literal complete intended persisted tuples BEFORE each normal/quiet save. Veto, observer mutation, orphan/reparented history, changed cohort membership, failed required audit or final authority withdrawal rolls back EVERY write. Reread the full intended cohort at the final suffix; never learn a mutated refreshed row as the new accepted baseline. Preserve immutable original snapshot/history records across later approved corrections; later corrections have their own original/effective pair.

Saved client allocations remain governed by `TimesheetAllocationService::assertSavedSplitComplete/assertTotal`: hours must equal the corrected paid total, segmented bounds must stay valid and permitted Client cohort must remain current. Do not auto-prorate, overwrite or silently ignore a saved split. An incompatible saved split blocks local application for explicit manager allocation review; this is an existing data requirement, not an unanswered policy choice. A later allocation review UI is separate from this bounded proposal.

## Outcomes and recovery

The current direct amendment service returns models, not an HTTP/physical commit receipt. There are currently NO HTTP request/approve/reject amendment routes. The subsequent source proposal must add a small owning surface rather than pretend those APIs exist. A future source read should expose safe canonical effective/original time values and explicit `can_request/can_review`, not loaded models/private HR evidence.

Future command correlation must include exact action, actor, displayed Timesheet/amendment identity, opaque expected source revision, request UUID and intended values. Persist request/review correlation in the required action audit (and durable request snapshot), then verify actual committed parent/amendment/Attendance/optional HR/history tuples at physical root. A matching receipt distinguishes `requested`, `applied`, `rejected`, and `pending_external_payroll`; it does not imply payment, payroll export or notification delivery. Root/nested/raw-PDO/after-commit callback/transport/readback-failure controls are required. Missing confirmation stays unknown; it cannot trigger replay or overwrite a captured display revision. Exact new command route/receipt fields are NOT yet frozen by this settings contract.

Preserve the installed exported/actively claimed branch: review may record an approved amendment with `payroll_adjustment_required:true`, `applied_at:null`, without changing Timesheet/Attendance/HR/pay amounts. Paid requests remain denied. A locked payroll period cannot be reset by this proposal. Explain “Approved; requires external payroll handling”, not “Hours updated”.

Existing next action (unchanged): `GET /operations/timesheets/payroll-adjustments`, route `operations.timesheets.payrollAdjustments`, selects approved + payroll-adjustment-required + applied_at null in permitted Sites. `POST /operations/timesheets/amendments/{amendment}/mark-processed`, route `operations.timesheets.markPayrollProcessed`, requires the installed approve/manage intersection and canonical writable Site authority. It records externally completed processing ONLY; it does not apply Timesheet/Attendance values, pay amounts or paid status. Existing receipt:

```ts
{
    action: 'process_payroll_adjustment'; actor_id: number;
    amendment_id: number; timesheet_id: number; changed: boolean;
    outcome: 'recorded_external_processing' | 'already_recorded';
    processing_method: 'external'; applied_at: string;
}
```

That existing `applied_at` marker has external-processing semantics. An eventual UI must not equate it to the local `applied` correction outcome. The exact external workflow remains protected; this packet authorises no reset or implied external payroll integration.

## Next bounded source work and validation

Implement settings service + additive existing settings controller/routes/history/receipt branch first, with current role/Site/request authority tests. Implement durable source evidence and linked projection in a separate amendment successor, explicitly composed over R3 and the disjoint Attendance/pay R2 after-images. Keep both frozen originals and old source-only reviews. Candidate public direct-service signatures and wage allowlist should stay compatible; any new request context must be an explicit enumerated transition.

Proposed test inputs are pinned in `scenario-plan.json`; these are scenario requirements, not authored PHPUnit cases or an actual inventory. Select the complete original amendment workflow and writer classes, Attendance/pay R2 preservation suites, current Timesheet allocation/reconciliation/payroll-adjustment controls, and new focused settings/policy/link/receipt classes once authored. Framework enumeration, exact isolated owned-schema prerequisites, syntax/style, native runs and browser owning-page acceptance remain future separate steps. No existing Leave/Calendar/Assignment/HS17 evidence certifies this new policy/projection.

Unanswered WF33/clinical capability/House/date-hour restriction policies are unchanged. No new human policy question is needed for this bounded requester and linked-history work; missing source proof, payroll protection and incompatible saved allocations are implementation/readiness constraints to report honestly.
