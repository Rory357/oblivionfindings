import type { RosterCalendarEvent } from './calendar-feed-contract';

export type CalendarMoveIntent = {
    actorId: number;
    shiftId: number;
    requestId: string;
    source: string;
    clientId: number;
    siteId: number;
    workerId: number | null;
    serviceContextId: number | null;
    status: string;
    startsAt: string;
    endsAt: string;
};

export type CalendarQualificationReview = {
    canProceed: boolean;
    ruleCodes: string[];
    warningReasons: string[];
};

export type CalendarMoveResponse =
    | { kind: 'confirmed'; savedSource: string }
    | { kind: 'review'; review: CalendarQualificationReview }
    | { kind: 'rejected'; message: string }
    | { kind: 'unconfirmed' };

function object(value: unknown): value is Record<string, unknown> {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function id(value: unknown): value is number {
    return Number.isSafeInteger(value) && (value as number) > 0;
}
function nullableId(value: unknown): value is number | null {
    return value === null || id(value);
}
function hash(value: unknown): value is string {
    return typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);
}
function uuid(value: unknown): value is string {
    return typeof value === 'string' && /^[a-f0-9]{8}-[a-f0-9]{4}-[1-8][a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(value);
}
function utc(value: unknown): value is string {
    if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.000Z$/.test(value)) return false;
    const instant = Date.parse(value);
    return Number.isFinite(instant) && new Date(instant).toISOString() === value;
}
function uniqueStrings(value: unknown): value is string[] {
    return Array.isArray(value) && value.length > 0 &&
        value.every(item => typeof item === 'string' && item.trim().length > 0) &&
        new Set(value).size === value.length;
}

/** Freeze the displayed canonical row; a missing source never becomes a legacy save. */
export function calendarMoveIntent(
    event: RosterCalendarEvent,
    actorId: number | null,
    requestId: string,
    times: { starts_at: string; ends_at: string },
): CalendarMoveIntent | null {
    const extra = event.extendedProps;
    const shiftId = typeof event.id === 'number' ? event.id :
        /^[1-9]\d*$/.test(event.id) ? Number(event.id) : NaN;
    if (!id(actorId) || !id(shiftId) || !uuid(requestId) || !object(extra) ||
        !hash(extra.shift_source) || !id(extra.client_id) || !id(extra.site_id) ||
        !nullableId(extra.user_id) || !nullableId(extra.service_context_id) ||
        typeof extra.status !== 'string' || !['scheduled', 'draft'].includes(extra.status) ||
        !utc(times.starts_at) || !utc(times.ends_at) ||
        Date.parse(times.ends_at) <= Date.parse(times.starts_at)) return null;
    return {
        actorId, shiftId, requestId, source: extra.shift_source,
        clientId: extra.client_id, siteId: extra.site_id, workerId: extra.user_id,
        serviceContextId: extra.service_context_id, status: extra.status,
        startsAt: times.starts_at, endsAt: times.ends_at,
    };
}

/** Only the matching physical-root receipt confirms this exact requested move. */
export function decodeCalendarMoveResponse(
    status: number,
    body: unknown,
    intent: CalendarMoveIntent,
): CalendarMoveResponse {
    if (!object(body)) return { kind: 'unconfirmed' };
    const receipt = body.calendar_move_result;
    if (status === 200 && body.ok === true && object(receipt) &&
        receipt.version === 1 && receipt.scope === 'calendar_move' && receipt.action === 'update' &&
        receipt.actor_id === intent.actorId && receipt.shift_id === intent.shiftId &&
        receipt.request_id === intent.requestId && receipt.source === intent.source &&
        receipt.outcome === 'confirmed' && utc(receipt.verified_at) && object(receipt.saved)) {
        const saved = receipt.saved;
        if (saved.id === intent.shiftId && saved.client_id === intent.clientId &&
            saved.site_id === intent.siteId && saved.user_id === intent.workerId &&
            saved.service_context_id === intent.serviceContextId && saved.status === intent.status &&
            saved.starts_at === intent.startsAt && saved.ends_at === intent.endsAt &&
            hash(saved.shift_source)) return { kind: 'confirmed', savedSource: saved.shift_source };
    }
    const review = body.eligibility_review;
    if (status === 422 && object(review) && review.scope === 'calendar_qualification' &&
        review.actor_id === intent.actorId && review.shift_id === intent.shiftId &&
        id(intent.workerId) && review.user_id === intent.workerId &&
        review.request_id === intent.requestId && review.source === intent.source &&
        review.acknowledgement_required === true && review.reason_required === true &&
        typeof review.can_override_eligibility === 'boolean' &&
        uniqueStrings(review.rule_codes) && review.rule_codes.every(rule =>
            rule === 'client_qualification' || /^house_qualification(?:_[1-9]\d*)?$/.test(rule)) &&
        uniqueStrings(review.warning_reasons)) {
        return { kind: 'review', review: {
            canProceed: review.can_override_eligibility,
            ruleCodes: [...review.rule_codes], warningReasons: [...review.warning_reasons],
        } };
    }
    // Foreign/malformed qualification details must not be rendered or acknowledged.
    if (review !== undefined) return { kind: 'unconfirmed' };
    const messages: Record<number, string> = {
        400: 'The move could not be accepted. Refresh the shift before trying again.',
        403: 'You no longer have permission to move this shift.',
        404: 'This shift is no longer available to you.',
        409: 'The shift changed. Refresh its current record before moving it again.',
        419: 'Your session expired. Sign in again before moving the shift.',
        422: 'The move did not pass the current checks. Review the shift before trying again.',
    };
    return messages[status] ? { kind: 'rejected', message: messages[status] } : { kind: 'unconfirmed' };
}
