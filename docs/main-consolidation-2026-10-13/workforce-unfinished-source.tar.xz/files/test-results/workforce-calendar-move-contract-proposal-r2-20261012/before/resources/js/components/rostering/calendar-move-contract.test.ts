import { expect, it } from 'vitest';

import { calendarMoveIntent, decodeCalendarMoveResponse } from './calendar-move-contract';

const event = {
    id: 11, start: '2026-10-10T21:00:00Z', end: '2026-10-11T05:00:00Z',
    extendedProps: {
        shift_source: 'a'.repeat(64), status: 'scheduled', client_id: 3,
        site_id: 2, user_id: 5, service_context_id: null,
    },
};
const requestId = '7339947c-8d32-44f4-bf94-7d44cfda7e38';
const times = { starts_at: '2026-10-11T21:00:00.000Z', ends_at: '2026-10-12T05:00:00.000Z' };
const intent = calendarMoveIntent(event, 5, requestId, times)!;
function confirmed() {
    return { ok: true, calendar_move_result: {
        version: 1, scope: 'calendar_move', action: 'update', actor_id: 5, shift_id: 11,
        request_id: requestId, source: 'a'.repeat(64), outcome: 'confirmed',
        saved: { id: 11, client_id: 3, site_id: 2, user_id: 5, service_context_id: null,
            status: 'scheduled', starts_at: times.starts_at, ends_at: times.ends_at, shift_source: 'b'.repeat(64) },
        verified_at: '2026-10-11T12:30:00.000Z',
    } };
}
function review() {
    return { eligibility_review: {
        scope: 'calendar_qualification', actor_id: 5, shift_id: 11, user_id: 5,
        request_id: requestId, source: 'a'.repeat(64), acknowledgement_required: true,
        reason_required: true, can_override_eligibility: true,
        rule_codes: ['house_qualification_7'], warning_reasons: ['The House qualification cannot be matched.'],
    } };
}

it('freezes the displayed source and expected unchanged ownership for the exact new time pair', () => {
    expect(intent).toEqual({ actorId: 5, shiftId: 11, requestId, source: 'a'.repeat(64),
        clientId: 3, siteId: 2, workerId: 5, serviceContextId: null, status: 'scheduled',
        startsAt: times.starts_at, endsAt: times.ends_at });
    expect(calendarMoveIntent({ ...event, id: '11' }, 5, requestId, times)).toEqual(intent);
});
it.each([
    { shift_source: undefined }, { shift_source: 'A'.repeat(64) },
    { client_id: null }, { site_id: 0 }, { user_id: '5' },
    { service_context_id: undefined }, { status: 'completed' },
])('withholds a modern move when a displayed source field is missing or unsafe: %j', (extra) => {
    expect(calendarMoveIntent({ ...event, extendedProps: { ...event.extendedProps, ...extra } }, 5, requestId, times)).toBeNull();
});
it.each([null, 0, 1.5])('withholds the move for invalid actor %s', actor => {
    expect(calendarMoveIntent(event, actor, requestId, times)).toBeNull();
});
it('rejects normalized-invalid UTC dates and non-positive durations before sending', () => {
    expect(calendarMoveIntent(event, 5, requestId, { ...times, starts_at: '2026-02-30T21:00:00.000Z' })).toBeNull();
    expect(calendarMoveIntent(event, 5, requestId, { ...times, ends_at: times.starts_at })).toBeNull();
});
it('accepts only a matching confirmed physical-root receipt, without consuming the returned model', () => {
    expect(decodeCalendarMoveResponse(200, { ...confirmed(), shift: { id: 999 } }, intent))
        .toEqual({ kind: 'confirmed', savedSource: 'b'.repeat(64) });
});
it.each([
    ['actor_id', 6], ['shift_id', 12], ['request_id', 'wrong'], ['source', 'c'.repeat(64)],
    ['scope', 'assignment'], ['action', 'delete'], ['version', 2],
    ['outcome', 'not_confirmed'], ['verified_at', '2026-02-30T12:30:00.000Z'],
])('does not confirm another/stale/malformed receipt %s', (key, value) => {
    const body = confirmed();
    Object.assign(body.calendar_move_result, { [key]: value });
    expect(decodeCalendarMoveResponse(200, body, intent)).toEqual({ kind: 'unconfirmed' });
});
it.each([
    ['id', 12], ['client_id', 4], ['site_id', 7], ['user_id', null], ['service_context_id', 9],
    ['status', 'cancelled'], ['starts_at', event.start], ['ends_at', event.end], ['shift_source', ''],
])('does not confirm a saved tuple that differs from the displayed intent: %s', (key, value) => {
    const body = confirmed();
    Object.assign(body.calendar_move_result.saved, { [key]: value });
    expect(decodeCalendarMoveResponse(200, body, intent)).toEqual({ kind: 'unconfirmed' });
});
it.each([202, 500])('a successful-looking body on HTTP%s remains uncertain', status => {
    expect(decodeCalendarMoveResponse(status, confirmed(), intent)).toEqual({ kind: 'unconfirmed' });
});
it('generic HTTP200, malformed JSON and legacy success flags never confirm a move', () => {
    for (const body of [null, 'Saved', { success: true }, { ok: true }, { ...confirmed(), ok: false }])
        expect(decodeCalendarMoveResponse(200, body, intent)).toEqual({ kind: 'unconfirmed' });
});
it('returns current qualification warnings only for the matching worker, source and attempt', () => {
    expect(decodeCalendarMoveResponse(422, review(), intent)).toEqual({ kind: 'review', review: {
        canProceed: true, ruleCodes: ['house_qualification_7'],
        warningReasons: ['The House qualification cannot be matched.'],
    } });
    const denied = review(); denied.eligibility_review.can_override_eligibility = false;
    expect(decodeCalendarMoveResponse(422, denied, intent)).toMatchObject({ kind: 'review', review: { canProceed: false } });
});
it.each([
    ['actor_id', 6], ['shift_id', 12], ['user_id', 7], ['source', 'c'.repeat(64)],
    ['request_id', null], ['scope', 'assignment'], ['reason_required', false],
    ['acknowledgement_required', false], ['can_override_eligibility', 1],
    ['rule_codes', ['visa']], ['warning_reasons', []],
])('never displays or acknowledges a foreign or invalid review: %s', (key, value) => {
    const body = review(); Object.assign(body.eligibility_review, { [key]: value });
    expect(decodeCalendarMoveResponse(422, body, intent)).toEqual({ kind: 'unconfirmed' });
});
it.each([403, 404, 409, 419, 422])('retains a definite HTTP%s rejection without rendering arbitrary private server details', status => {
    const result = decodeCalendarMoveResponse(status, { message: 'Private client detail' }, intent);
    expect(result.kind).toBe('rejected');
    expect(JSON.stringify(result)).not.toContain('Private client detail');
});
