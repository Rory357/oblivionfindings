import path from 'node:path';
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
const root = path.resolve(import.meta.dirname, '..');
export default defineConfig({
    root,
    cacheDir: path.join(root, 'test-results/timesheet-post-lint-batch-a-cache-20261012'),
    plugins: [react()],
    resolve: { alias: { '@': path.join(root, 'resources/js') } },
    test: {
        environment: 'jsdom', globals: true,
        include: [
            "resources/js/components/timesheets/view-timesheet-permissions.test.tsx",
            "resources/js/components/timesheets/timesheet-wizard.test.tsx",
            "resources/js/components/timesheets/timesheet-write-scope.test.ts",
            "resources/js/components/timesheets/timesheet-write-context.test.tsx"
],
        setupFiles: [path.join(root, 'resources/js/test/setup.ts')],
        maxWorkers: 1, fileParallelism: false, pool: 'threads',
        testTimeout: 10000, hookTimeout: 10000,
    },
});
