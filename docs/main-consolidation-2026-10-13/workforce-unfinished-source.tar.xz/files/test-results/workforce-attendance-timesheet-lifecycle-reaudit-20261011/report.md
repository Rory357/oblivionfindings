# Attendance / Timesheet lifecycle source re-audit

Three concrete source gaps remain:

1. **Break pair writes can half-commit.** `AttendanceService` ignores session/event false saves at start, end and active-break clock-out. Current actor/Site locks are present. Add checked writes and persisted intent checks inside the existing transaction, with normal observers and rollback controls.
2. **Amendment recovery is not reachable.** Approved attendance corrections refer to a Timesheet amendment, but only the payroll mark-processed route exists. Direct-service tests do not establish a production request/review journey. This is the documented outstanding workflow. Do not expose the existing stale/unchecked review writer or invent a paid-sheet policy.
3. **Paid bookkeeping can diverge from settlement.** `markRunTimesheetsPaid` counts unchecked writes. A false save can leave an approved Timesheet after settlement commits; verified settlement replay does not revisit the cascade. Check persisted paid rows/cohort and fail the enclosing transaction. This is bookkeeping consistency, not a claim that funds were not paid.

Existing tests and exact owning lines/pins are in `review.json`. Normal breaks, current scope, clock-out receipts, canonical approval, paid replay/legacy rows and thrown settlement-audit rollback are already covered in source. False-break/paid-write controls and the amendment HTTP journey are not.

No product changes, PHP/framework/tests, database or process actions were performed. The prior documented receipts and all broader care/pay/UI work remain intact. Actual current acceptance is pending.
