import { act, cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import { CalendarPane } from './calendar-pane';
import type { CalendarShift } from './calendar-shared';
import { DayDetailDialog } from './day-detail-dialog';
import { descriptor, duty, feedContext } from './calendar-feed-test-data';
import { buildShiftActions, type GridShiftStatus } from './week-grid-pane';

const page = vi.hoisted(() => ({
    props: {
        workerTimezone: 'Pacific/Auckland', rosteringFeatures: { publish: true },
        auth: { user: { id: 5 }, can: { shifts: { manageAny: true, viewAny: true, update: false, create: false } } },
    },
}));
vi.mock('@inertiajs/react', () => ({
    usePage: () => page,
    Link: ({ children }: { children: React.ReactNode }) => <>{children}</>,
    router: { on: () => () => {} },
}));
vi.mock('@/pages/operations/shifts/components/use-create-shift-launcher', () => ({
    useCreateShiftLauncher: () => ({ openWith: vi.fn(), dialog: null }),
}));

const row: CalendarShift = {
    id: 11, status: 'scheduled', starts_at: duty.start, ends_at: duty.end,
    client: 'Calendar duty', staff: 'Worker', dateKey: '2026-10-11', start: '10:00', end: '18:00',
    durationH: 8, clientId: 3, siteId: 2, siteName: 'House', context: null, shiftType: 'standard',
    staffId: 5, recurring: false, replacement: false, tasksTotal: 0, tasksDone: 0, incidents: 0, isRespite: false,
};
const reads: { url: string; resolve: (response: Response) => void }[] = [];
beforeEach(() => {
    reads.length = 0;
    vi.useFakeTimers({ toFake: ['Date'] });
    vi.setSystemTime(new Date('2026-10-11T00:00:00Z'));
    vi.stubGlobal('fetch', vi.fn((url: string) => new Promise<Response>((resolve) => reads.push({ url, resolve }))));
});
afterEach(() => { cleanup(); vi.unstubAllGlobals(); vi.useRealTimers(); });

it.each<GridShiftStatus>(['open', 'in_progress', 'completed', 'cancelled', 'draft', 'scheduled', 'leave'])(
    'removes every Show fallback for %s while retaining existing non-Calendar defaults', (status) => {
        const shift = { ...row, status };
        const labels = (items: ReturnType<typeof buildShiftActions>) => items.flatMap((item) => item.sep ? [] : [item.label]);
        expect(labels(buildShiftActions(shift, {}, { canOpenDetails: false })).filter((label) => /^(Open |Edit |Request replacement|View timesheet)/.test(label))).toEqual([]);
        expect(labels(buildShiftActions(shift, {}))).toEqual(labels(buildShiftActions(shift, {}, { canOpenDetails: true })));
        expect(labels(buildShiftActions(shift, {})).some((label) => /^(Open |Edit )/.test(label))).toBe(true);
    },
);
it('retains admitted edit/replacement/linked-timesheet callbacks without substituting a denied Show action', () => {
    const edit = vi.fn(); const replacement = vi.fn(); const timesheet = vi.fn();
    const invoke = (items: ReturnType<typeof buildShiftActions>, label: string) => {
        const item = items.find((item) => !item.sep && item.label === label);
        if (item && !item.sep) item.onClick?.();
    };
    const planning = buildShiftActions(row, { onEditShift: edit, onRequestReplacement: replacement }, { canOpenDetails: false });
    invoke(planning, 'Edit shift'); invoke(planning, 'Request replacement…');
    const completed = { ...row, status: 'completed' as const, timesheet_id: 89 };
    invoke(buildShiftActions(completed, { onViewTimesheet: timesheet }, { canOpenDetails: false }), 'View timesheet');
    expect(edit).toHaveBeenCalledWith(row); expect(replacement).toHaveBeenCalledWith(row); expect(timesheet).toHaveBeenCalledWith(completed);
});
it.each([true, false, undefined])('real Day Detail offers Open only for exact Show capability %s and retains the admitted inline peek', (capability) => {
    const peek = vi.fn();
    const view = render(<DayDetailDialog open dayKey="2026-10-11" todayKey="2026-10-11" shifts={[{ ...row, staff: null, canViewDetails: capability }]} gaps={[]} popoverOpen={false}
        canManage={false} canCreate={false} onClose={vi.fn()} onNav={vi.fn()} onJumpToday={vi.fn()} onPeek={peek} onCtx={vi.fn()}
        onNewShift={vi.fn()} onFillGap={vi.fn()} />);
    expect(screen.queryByRole('button', { name: 'Open' }) !== null).toBe(capability === true);
    fireEvent.click(screen.getByRole('button', { name: /Calendar duty 10:00 to 18:00/ }));
    expect(peek).toHaveBeenCalledOnce();
    expect(screen.getByText('Assignments').parentElement).toHaveTextContent('1/1');
    expect(screen.queryByText('Fully covered')).not.toBeInTheDocument();
    expect(screen.getByText('Assigned staff')).toBeInTheDocument();
    view.rerender(<DayDetailDialog open dayKey="2026-10-11" todayKey="2026-10-11" shifts={[{ ...row, staffId: null }]} gaps={[]} popoverOpen={false}
        canManage={false} canCreate={false} onClose={vi.fn()} onNav={vi.fn()} onJumpToday={vi.fn()} onPeek={peek} onCtx={vi.fn()} onNewShift={vi.fn()} onFillGap={vi.fn()} />);
    expect(screen.getByText('Assignments').parentElement).toHaveTextContent('0/1');
    expect(screen.getByText('Unassigned')).toBeInTheDocument();
    expect(screen.queryByText('Worker')).not.toBeInTheDocument();
    view.rerender(<DayDetailDialog open dayKey="2026-10-11" todayKey="2026-10-11" shifts={[]} gaps={[]} popoverOpen={false}
        canManage={false} canCreate={false} onClose={vi.fn()} onNav={vi.fn()} onJumpToday={vi.fn()} onPeek={peek} onCtx={vi.fn()} onNewShift={vi.fn()} onFillGap={vi.fn()} />);
    expect(screen.getByText('Assignments').parentElement).toHaveTextContent('—');
    expect(screen.getByText('No shifts shown')).toBeInTheDocument();
});
it('real Pane sends sorted Sites, maps the worker day/time, and keeps partial coverage unknown with loaded duties', async () => {
    render(<CalendarPane canManageAny filters={{ site_ids: [7, 2, 2] }} />);
    expect(new URL(reads[0].url, 'http://localhost').searchParams.getAll('site_id[]')).toEqual(['2', '7']);
    const marker = descriptor(reads[0].url, feedContext) as any;
    marker.extendedProps.coverage = { status: 'partially_assessed', reason: 'unsafe_source', finding_count: null };
    const event = { ...duty, extendedProps: { ...duty.extendedProps, client: 'Calendar duty', staff: 'Worker', can_view_shift: false } };
    await act(async () => reads[0].resolve({ ok: true, json: async () => [event, marker] } as Response));
    expect(screen.getByText('Coverage is incomplete. Some staffing windows could not be checked.')).toBeInTheDocument();
    expect(screen.getByText('Gaps in calendar').parentElement).toHaveTextContent('—');
    const chip = screen.getByText('Calendar duty').closest('button')!;
    expect(chip).toHaveTextContent('10:00');
    const day = chip.closest('[title="View day"]')!;
    expect(within(day as HTMLElement).getByText('11')).toBeInTheDocument();
    fireEvent.click(chip);
    expect(screen.queryByRole('button', { name: 'Open shift' })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'More' }));
    expect(screen.queryByText('Edit shift')).not.toBeInTheDocument();
    expect(screen.queryByText('Request replacement…')).not.toBeInTheDocument();
});
it('real Pane shows permission-not-assessed separately from known zero while retaining read-only coworker filters', async () => {
    page.props.auth.can.shifts.manageAny = false;
    try {
        render(<CalendarPane canManageAny={false} filters={{ staff_id: 5, client_id: 3, site_ids: [2, 7] }} />);
        const params = new URL(reads[0].url, 'http://localhost').searchParams;
        expect(params.get('staff_id')).toBe('5'); expect(params.get('client_id')).toBe('3');
        const context = { ...feedContext, canAssessCoverage: false, filters: { staff_id: 5, client_id: 3, site_ids: [2, 7] } };
        await act(async () => reads[0].resolve({ ok: true, json: async () => [descriptor(reads[0].url, context)] } as Response));
        expect(screen.getByText('Coverage has not been assessed for your access. Your loaded shifts are shown below.')).toBeInTheDocument();
        expect(screen.getByText('Gaps in calendar').parentElement).toHaveTextContent('—');
        expect(screen.queryByText("You're seeing only your own shifts.")).not.toBeInTheDocument();
    } finally { page.props.auth.can.shifts.manageAny = true; }
});


it('counts a safe leading-month gap across the full visible calendar rather than declaring the displayed month gap-free', async () => {
    render(<CalendarPane canManageAny />);
    const context = { ...feedContext, filters: { staff_id: null, client_id: null, site_ids: null } };
    const marker = descriptor(reads[0].url, context, 1);
    const finding = {
        id: 'coverage-gap-7-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', title: 'Coverage gap',
        start: '2026-09-30T08:00:00Z', end: '2026-09-30T12:00:00Z',
        extendedProps: { event_type: 'coverage_gap', site_id: 2, coverage_rule_id: 7 },
    };
    await act(async () => reads[0].resolve({ ok: true, json: async () => [finding, marker] } as Response));
    expect(screen.getByText('Gaps in calendar').parentElement).toHaveTextContent('1');
    expect(screen.getByText('Coverage totals, when available, cover all displayed dates, including neighbouring month days. Staff and client filters narrow shifts.')).toBeInTheDocument();
});
