import { describe, expect, it } from 'vitest';
import { calendarRequestRange, decodeCalendarFeed } from './calendar-feed-contract';
import { descriptor, duty, feedContext, feedUrl, gap } from './calendar-feed-test-data';

describe('Calendar reader evidence and event boundaries', () => {
    it('requires one descriptor even for known zero and removes it from rendered duties', () => {
        expect(decodeCalendarFeed([], feedUrl, feedContext)).toBeNull();
        const result = decodeCalendarFeed([duty, descriptor()], feedUrl, feedContext)!;
        expect(result.events).toEqual([duty]);
        expect(result.coverage.finding_count).toBe(0);
        expect(decodeCalendarFeed([descriptor()], feedUrl, feedContext)?.events).toEqual([]);
        expect(decodeCalendarFeed([descriptor(), descriptor()], feedUrl, feedContext)).toBeNull();
    });
    it.each([
        ['actor', (d: any) => { d.extendedProps.actor_id = 9; }],
        ['zone', (d: any) => { d.extendedProps.worker_timezone = 'UTC'; }],
        ['version', (d: any) => { d.extendedProps.schema_version = 2; }],
        ['range', (d: any) => { d.extendedProps.range.start = '2026-10-01T00:00:00Z'; }],
        ['exclusive end', (d: any) => { d.extendedProps.range.end_exclusive = false; }],
        ['staff echo', (d: any) => { d.extendedProps.filters.staff_id = 9; }],
        ['site echo', (d: any) => { d.extendedProps.filters.site_ids = [7, 2]; }],
        ['scope kind', (d: any) => { d.extendedProps.scope.kind = 'own'; }],
        ['effective staff', (d: any) => { d.extendedProps.scope.staff_id = 9; }],
        ['effective client', (d: any) => { d.extendedProps.scope.client_id = 9; }],
        ['publication', (d: any) => { d.extendedProps.scope.published_only = true; }],
        ['site expansion', (d: any) => { d.extendedProps.scope.site_ids = [2, 7, 9]; }],
        ['duplicate sites', (d: any) => { d.extendedProps.scope.site_ids = [2, 2]; }],
        ['unsorted sites', (d: any) => { d.extendedProps.scope.site_ids = [7, 2]; }],
        ['unknown count', (d: any) => { d.extendedProps.coverage.finding_count = null; }],
        ['negative count', (d: any) => { d.extendedProps.coverage.finding_count = -1; }],
        ['inconsistent gap count', (d: any) => { d.extendedProps.coverage.finding_count = 1; }],
    ])('withholds a mismatched %s descriptor', (_name, mutate) => {
        const marker = descriptor(); mutate(marker);
        expect(decodeCalendarFeed([duty, marker], feedUrl, feedContext)).toBeNull();
    });
    it('keeps partial coverage unknown even when safe findings remain', () => {
        const marker = descriptor() as any;
        marker.extendedProps.coverage = { status: 'partially_assessed', reason: 'unsafe_source', finding_count: null };
        const result = decodeCalendarFeed([gap, marker], feedUrl, feedContext)!;
        expect(result.events).toHaveLength(1);
        expect(result.coverage.finding_count).toBeNull();
        marker.extendedProps.coverage.finding_count = 0;
        expect(decodeCalendarFeed([gap, marker], feedUrl, feedContext)).toBeNull();
    });
    it('binds own scope and the actual publication flag without treating coverage permission as assessed zero', () => {
        const own = { ...feedContext, canReadAny: false, canAssessCoverage: false };
        const marker = descriptor(feedUrl, own);
        expect(decodeCalendarFeed([duty, marker], feedUrl, own)?.coverage.finding_count).toBeNull();
        expect(decodeCalendarFeed([{ ...duty, extendedProps: { ...duty.extendedProps, user_id: 9 } }, marker], feedUrl, own)).toBeNull();
        expect(decodeCalendarFeed([gap, marker], feedUrl, own)).toBeNull();
        own.publicationEnabled = false;
        expect(decodeCalendarFeed([duty, descriptor(feedUrl, own)], feedUrl, own)?.scope.published_only).toBe(false);
    });
    it('retains Site-wide gaps while display staff/client filters narrow only duties', () => {
        const context = { ...feedContext, filters: { ...feedContext.filters, staff_id: 5, client_id: 3 } };
        const url = feedUrl + '&staff_id=5&client_id=3';
        const marker = descriptor(url, context, 1);
        const broadGap = { ...gap, extendedProps: { ...gap.extendedProps, coverage_preferred_client_id: 81 } };
        expect(decodeCalendarFeed([duty, broadGap, marker], url, context)?.events).toHaveLength(2);
        expect(decodeCalendarFeed([{ ...duty, extendedProps: { ...duty.extendedProps, client_id: 81 } }, broadGap, marker], url, context)).toBeNull();
    });
    it.each([
        { ...duty, id: '0011' }, { ...duty, id: -1 },
        { ...duty, start: '2026-10-10T09:00:00' },
        { ...duty, end: duty.start }, { ...duty, end: '2026-10-10T20:00:00Z' },
        { ...duty, start: '2026-12-01T00:00:00Z', end: '2026-12-02T00:00:00Z' },
        { ...duty, extendedProps: { ...duty.extendedProps, site_id: 9 } },
        { ...duty, extendedProps: { ...duty.extendedProps, event_type: 'unrecognised' } },
    ])('withholds malformed, foreign or out-of-range event %j', (event) => {
        expect(decodeCalendarFeed([event, descriptor()], feedUrl, feedContext)).toBeNull();
    });
    it('rejects duplicate numeric identities and defaults Show to false unless exactly true', () => {
        expect(decodeCalendarFeed([duty, { ...duty, id: '11' }, descriptor()], feedUrl, feedContext)).toBeNull();
        for (const capability of [undefined, false, 'true', 1, null]) {
            const event = { ...duty, extendedProps: { ...duty.extendedProps, can_view_shift: capability } };
            expect(decodeCalendarFeed([event, descriptor()], feedUrl, feedContext)?.events[0].extendedProps?.can_view_shift).toBe(false);
        }
    });
    it('accepts a lawful carry-in interval and an empty permitted cohort without inventing approval from the picker', () => {
        const carry = { ...duty, start: '2026-09-30T10:00:00Z', end: '2026-09-30T12:00:00Z' };
        expect(decodeCalendarFeed([carry, descriptor()], feedUrl, feedContext)?.events).toHaveLength(1);
        const marker = descriptor() as any;
        marker.extendedProps.scope.site_ids = [];
        marker.extendedProps.coverage = { status: 'not_assessed', reason: 'no_sites', finding_count: null };
        expect(decodeCalendarFeed([marker], feedUrl, feedContext)?.coverage.reason).toBe('no_sites');
    });
    it('normalises worker civil dates across DST and preserves explicit offset instants', () => {
        const context = { ...feedContext, filters: { ...feedContext.filters, site_ids: null } };
        const range = calendarRequestRange('/operations/rostering/calendar/events?start=2026-09-27&end=2026-09-28', context)!;
        expect(new Date(range.start).toISOString()).toBe('2026-09-26T12:00:00.000Z');
        expect(new Date(range.end).toISOString()).toBe('2026-09-27T11:00:00.000Z');
        expect(range.end - range.start).toBe(23 * 3600000);
        const offset = calendarRequestRange('/operations/rostering/calendar/events?start=2026-10-01T00:00:00%2B13:00&end=2026-10-02T00:00:00Z', context)!;
        expect(new Date(offset.start).toISOString()).toBe('2026-09-30T11:00:00.000Z');
        expect(new Date(offset.end).toISOString()).toBe('2026-10-02T00:00:00.000Z');
    });
    it('refuses a missing actor/zone/publication or mismatched request context before fetching', () => {
        expect(calendarRequestRange(feedUrl, { ...feedContext, actorId: null })).toBeNull();
        expect(calendarRequestRange(feedUrl, { ...feedContext, workerTimezone: 'unknown' })).toBeNull();
        expect(calendarRequestRange(feedUrl, { ...feedContext, publicationEnabled: undefined })).toBeNull();
        expect(calendarRequestRange(feedUrl + '&staff_id=9', feedContext)).toBeNull();
    });
});
