import { useCallback, useLayoutEffect, useRef, useState } from 'react';

import type { RosterCalendarEvent } from './calendar-feed-contract';
import {
    decodeCalendarMoveResponse,
    type CalendarMoveIntent,
    type CalendarMoveResponse,
    type CalendarQualificationReview,
} from './calendar-move-contract';

type MoveState = {
    key: string;
    phase: 'idle' | 'saving' | 'review' | 'unconfirmed' | 'rejected';
    intent: CalendarMoveIntent | null;
    review: CalendarQualificationReview | null;
    reason: string;
    error: string | null;
    readKeyAtAttempt: string | null;
};
type Options = {
    actorId: number | null;
    /** Actor, approved scope, worker zone and filters; exclude the read refresh counter. */
    contextKey: string;
    canMove: boolean;
    canOverride: boolean;
    assessed: boolean;
    /** Exact assessed feed generation, changed by an explicit refresh. */
    readKey: string;
    refresh: () => void;
    confirmed: (intent: CalendarMoveIntent) => void;
};
const idle = (key: string): MoveState => ({
    key, phase: 'idle', intent: null, review: null, reason: '', error: null, readKeyAtAttempt: null,
});
function sameSource(event: RosterCalendarEvent | null, intent: CalendarMoveIntent) {
    return event !== null && Number(event.id) === intent.shiftId &&
        event.extendedProps?.shift_source === intent.source;
}

/** Serialised moves; uncertain transport is retained and never replayed automatically. */
export function useCalendarMove(options: Options) {
    const key = JSON.stringify([options.contextKey, options.actorId, options.canMove, options.canOverride]);
    const live = useRef({ ...options, key });
    live.current = { ...options, key };
    const mounted = useRef(true);
    const pending = useRef(false);
    const [busy, setBusy] = useState(false);
    const [stored, setStored] = useState<MoveState>(() => idle(key));
    const state = stored.key === key ? stored : idle(key);
    const stateRef = useRef(state);
    stateRef.current = state;
    useLayoutEffect(() => {
        mounted.current = true;
        setStored(idle(key));
        return () => { mounted.current = false; };
    }, [key]);

    const send = useCallback(async (intent: CalendarMoveIntent, reason?: string) => {
        const current = live.current;
        if (!mounted.current || pending.current || !current.canMove || !current.assessed ||
            intent.actorId !== current.actorId) return false;
        const previous = stateRef.current;
        pending.current = true;
        setBusy(true);
        setStored({ ...previous, key: current.key, intent, phase: 'saving',
            error: null, reason: reason ?? '', readKeyAtAttempt: current.readKey });
        let result: CalendarMoveResponse;
        try {
            const csrf = document.querySelector<HTMLMetaElement>('meta[name="csrf-token"]')?.content;
            const response = await fetch(`/operations/rostering/calendar/shifts/${intent.shiftId}`, {
                method: 'PATCH', credentials: 'same-origin',
                headers: {
                    Accept: 'application/json', 'Content-Type': 'application/json',
                    'X-Calendar-Move-Result': 'committed-v1',
                    ...(csrf ? { 'X-CSRF-TOKEN': csrf } : {}),
                },
                body: JSON.stringify({
                    starts_at: intent.startsAt, ends_at: intent.endsAt,
                    request_id: intent.requestId, expected_source: intent.source,
                    ...(reason !== undefined ? { override_acknowledged: true, override_reason: reason } : {}),
                }),
            });
            result = decodeCalendarMoveResponse(response.status, await response.json(), intent);
        } catch {
            result = { kind: 'unconfirmed' };
        }
        pending.current = false;
        if (mounted.current) setBusy(false);
        if (!mounted.current || live.current.key !== current.key) return false;
        if (result.kind === 'confirmed') {
            setStored(idle(current.key));
            try { live.current.confirmed(intent); }
            finally { live.current.refresh(); }
        } else if (result.kind === 'review') {
            setStored({ ...previous, key: current.key, intent, phase: 'review',
                review: result.review, reason: reason ?? '', error: null,
                readKeyAtAttempt: current.readKey });
        } else {
            setStored({ ...previous, key: current.key, intent,
                phase: result.kind === 'rejected' ? 'rejected' : 'unconfirmed',
                review: null, reason: reason ?? '', readKeyAtAttempt: current.readKey,
                error: result.kind === 'rejected' ? result.message :
                    'The move could not be confirmed. Refresh the calendar and check the current shift before deciding what to do next.',
            });
            live.current.refresh();
        }
        return result.kind === 'confirmed';
    }, []);

    const move = useCallback((intent: CalendarMoveIntent) => {
        if (stateRef.current.phase !== 'idle') return Promise.resolve(false);
        return send(intent);
    }, [send]);
    const setReason = useCallback((reason: string) => {
        if (pending.current || stateRef.current.phase !== 'review') return;
        setStored(current => current.key === live.current.key ? { ...current, reason } : current);
    }, []);
    const confirmReview = useCallback((event: RosterCalendarEvent | null) => {
        const current = stateRef.current;
        const reason = current.reason.trim();
        if (current.phase !== 'review' || !current.review?.canProceed || !live.current.canOverride || !current.intent ||
            !sameSource(event, current.intent) || reason.length === 0 || reason.length > 2000)
            return Promise.resolve(false);
        return send(current.intent, reason);
    }, [send]);
    const cancelReview = useCallback(() => {
        if (!pending.current && stateRef.current.phase === 'review') setStored(idle(live.current.key));
    }, []);
    const useCurrentRecord = useCallback((event: RosterCalendarEvent | null) => {
        const current = stateRef.current;
        if (pending.current || !live.current.assessed || !current.intent ||
            !['unconfirmed', 'rejected'].includes(current.phase) ||
            live.current.readKey === current.readKeyAtAttempt ||
            (event !== null && Number(event.id) !== current.intent.shiftId)) return false;
        // A fresh read shows the current position; it does not prove this command committed.
        setStored(idle(live.current.key));
        return true;
    }, []);
    return { state, busy, move, setReason, confirmReview, cancelReview, useCurrentRecord };
}
