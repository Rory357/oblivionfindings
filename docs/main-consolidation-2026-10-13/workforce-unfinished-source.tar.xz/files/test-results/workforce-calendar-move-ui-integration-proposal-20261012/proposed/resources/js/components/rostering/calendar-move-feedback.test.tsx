import { act, cleanup, fireEvent, render, screen } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

import { CalendarMoveFeedback } from './calendar-move-feedback';
import { calendarMoveIntent } from './calendar-move-contract';
import { useCalendarMove } from './use-calendar-move';

const event = { id: 11, start: '2026-10-10T21:00:00Z', end: '2026-10-11T05:00:00Z',
    extendedProps: { shift_source: 'a'.repeat(64), client_id: 3, site_id: 2, user_id: 5, service_context_id: null, status: 'scheduled' } };
const intent = calendarMoveIntent(event, 5, '7339947c-8d32-44f4-bf94-7d44cfda7e38', {
    starts_at: '2026-10-11T21:00:00.000Z', ends_at: '2026-10-12T05:00:00.000Z',
})!;
const requests: { resolve: (response: Response) => void; options: RequestInit }[] = [];
const refresh = vi.fn();
let move: ReturnType<typeof useCalendarMove>;
function Harness({ assessed = true, readKey = 'read-a', canOverride = true, loading = false }) {
    move = useCalendarMove({ actorId: 5, contextKey: 'scope-a', canMove: true, canOverride, assessed, readKey, refresh, confirmed: vi.fn() });
    return <CalendarMoveFeedback move={move} event={event} assessed={assessed} loading={loading} readKey={readKey} refresh={refresh} timezone="Pacific/Auckland" canOverride={canOverride} />;
}
async function qualificationReview(canProceed = true) {
    act(() => { void move.move(intent); });
    await act(async () => requests[0].resolve({ status: 422, json: async () => ({ eligibility_review: {
        scope: 'calendar_qualification', actor_id: 5, shift_id: 11, user_id: 5, source: intent.source, request_id: intent.requestId,
        acknowledgement_required: true, reason_required: true, can_override_eligibility: canProceed,
        rule_codes: ['house_qualification_7'], warning_reasons: ['House qualification cannot be matched.'],
    } }) } as Response));
}
beforeEach(() => {
    requests.length = 0; refresh.mockReset();
    vi.stubGlobal('fetch', vi.fn((_url: string, options: RequestInit) => new Promise<Response>(resolve => requests.push({ resolve, options }))));
});
afterEach(() => { cleanup(); vi.unstubAllGlobals(); });

it('shows the exact warning, explicit work-zone times and required controlled manager reason', async () => {
    render(<Harness />); await qualificationReview();
    expect(screen.getByRole('dialog')).toHaveAccessibleName('Review qualifications before moving');
    expect(screen.getByText('House qualification cannot be matched.')).toBeInTheDocument();
    expect(screen.getByText(/Requested time:/)).toHaveTextContent('12 Oct 2026');
    expect(screen.getByRole('button', { name: 'Proceed and move shift' })).toBeDisabled();
    fireEvent.change(screen.getByRole('textbox', { name: 'Reason to proceed' }), { target: { value: 'Reviewed with qualified lead' } });
    expect(screen.getByRole('textbox', { name: 'Reason to proceed' })).toHaveValue('Reviewed with qualified lead');
    expect(screen.getByRole('button', { name: 'Proceed and move shift' })).toBeEnabled();
    fireEvent.click(screen.getByRole('button', { name: 'Proceed and move shift' }));
    expect(requests).toHaveLength(2);
    expect(screen.getByRole('button', { name: 'Cancel move' })).toBeDisabled();
    expect(screen.getByRole('textbox', { name: 'Reason to proceed' })).toBeDisabled();
});
it('a denied override shows the next step and cannot submit a reason', async () => {
    render(<Harness />); await qualificationReview(false);
    expect(screen.getByText(/Ask an authorised manager/)).toBeInTheDocument();
    expect(screen.queryByRole('textbox', { name: 'Reason to proceed' })).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Proceed and move shift' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: 'Cancel move' }));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument(); expect(requests).toHaveLength(1);
});
it('an uncertain reviewed move preserves the reason and recovery never sends it again', async () => {
    const view = render(<Harness />); await qualificationReview();
    fireEvent.change(screen.getByRole('textbox', { name: 'Reason to proceed' }), { target: { value: 'Reviewed with lead' } });
    fireEvent.click(screen.getByRole('button', { name: 'Proceed and move shift' }));
    await act(async () => requests[1].resolve({ status: 202, json: async () => ({ ok: false }) } as Response));
    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
    expect(screen.getByRole('textbox', { name: 'Your reason is kept here' })).toHaveValue('Reviewed with lead');
    expect(screen.getByRole('button', { name: 'Continue with loaded calendar' })).toBeDisabled();
    view.rerender(<Harness readKey="read-b" />);
    expect(screen.getByRole('button', { name: 'Continue with loaded calendar' })).toBeEnabled();
    fireEvent.click(screen.getByRole('button', { name: 'Continue with loaded calendar' }));
    expect(screen.queryByRole('alert')).not.toBeInTheDocument(); expect(requests).toHaveLength(2);
});
it('a failed calendar reload keeps a usable refresh action while new moves remain withheld', async () => {
    const view = render(<Harness />);
    act(() => { void move.move(intent); });
    await act(async () => requests[0].resolve({ status: 500, json: async () => ({}) } as Response));
    view.rerender(<Harness assessed={false} readKey="read-b" loading={false} />);
    expect(screen.getByRole('button', { name: 'Refresh calendar' })).toBeEnabled();
    expect(screen.getByRole('button', { name: 'Continue with loaded calendar' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: 'Refresh calendar' }));
    expect(refresh).toHaveBeenCalledTimes(2); expect(requests).toHaveLength(1);
});
