import { rosterInstant } from '@/lib/roster-time';

export type CalendarFeedContext = {
    actorId: number | null;
    workerTimezone: string | undefined;
    canReadAny: boolean;
    canAssessCoverage: boolean;
    publicationEnabled: boolean | undefined;
    filters: {
        staff_id: number | null;
        client_id: number | null;
        site_ids: number[] | null;
    };
};

export type RosterCalendarEvent = {
    id: number | string;
    title?: string;
    start: string;
    end: string;
    extendedProps?: Record<string, unknown>;
};

export type CalendarCoverageAssessment = {
    status: 'assessed' | 'partially_assessed' | 'not_assessed';
    reason: null | 'unsafe_source' | 'permission' | 'no_sites';
    finding_count: number | null;
};

export type CalendarFeedScope = {
    kind: 'approved_sites' | 'own';
    site_ids: number[];
    published_only: boolean;
    staff_id: number | null;
    client_id: number | null;
};

function object(value: unknown): value is Record<string, unknown> {
    return value !== null && typeof value === 'object' && !Array.isArray(value);
}
function id(value: unknown): value is number {
    return Number.isSafeInteger(value) && (value as number) > 0;
}
function nullableId(value: unknown): value is number | null {
    return value === null || id(value);
}
function ids(value: unknown): value is number[] {
    return Array.isArray(value) && value.every((item, index) =>
        id(item) && (index === 0 || item > value[index - 1]));
}
function sameIds(left: unknown, right: number[] | null): boolean {
    return right === null ? left === null : ids(left) &&
        left.length === right.length && left.every((value, index) => value === right[index]);
}
function instant(value: unknown): value is string {
    return typeof value === 'string' &&
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value) &&
        Number.isFinite(Date.parse(value));
}

/** Bind the request's civil edges to the configured worker zone, never the browser zone. */
export function calendarRequestRange(url: string, context: CalendarFeedContext) {
    if (!id(context.actorId) || typeof context.workerTimezone !== 'string' ||
        typeof context.publicationEnabled !== 'boolean' ||
        !nullableId(context.filters.staff_id) || !nullableId(context.filters.client_id) ||
        (context.filters.site_ids !== null &&
            (!ids(context.filters.site_ids) || context.filters.site_ids.length > 50))) return null;
    try {
        new Intl.DateTimeFormat('en-NZ', { timeZone: context.workerTimezone });
        const params = new URL(url, 'http://calendar.local').searchParams;
        const edge = (key: string) => {
            const raw = params.get(key);
            if (raw && /^\d{4}-\d{2}-\d{2}$/.test(raw))
                return rosterInstant(`${raw}T00:00:00`, context.workerTimezone).getTime();
            return instant(raw) ? Date.parse(raw) : NaN;
        };
        const start = edge('start');
        const end = edge('end');
        const requestId = (key: string) => {
            const raw = params.get(key);
            if (raw === null) return null;
            return /^[1-9]\d*$/.test(raw) && id(Number(raw)) ? Number(raw) : NaN;
        };
        const requestedSites = params.getAll('site_id[]');
        if (params.has('site_id') ||
            requestId('staff_id') !== context.filters.staff_id ||
            requestId('client_id') !== context.filters.client_id ||
            !sameIds(requestedSites.length ? requestedSites.map(Number) : null, context.filters.site_ids) ||
            !Number.isFinite(start) || !Number.isFinite(end) || end < start) return null;
        return { start, end };
    } catch {
        return null;
    }
}

/** The descriptor is authoritative read evidence, not a Shift or a care event. */
export function decodeCalendarFeed(value: unknown, url: string, context: CalendarFeedContext): {
    events: RosterCalendarEvent[];
    coverage: CalendarCoverageAssessment;
    scope: CalendarFeedScope;
} | null {
    const requestRange = calendarRequestRange(url, context);
    if (!requestRange || !Array.isArray(value)) return null;
    const descriptors = value.filter((row) => object(row) &&
        (row.id === 'roster-calendar-assessment' ||
            (object(row.extendedProps) && row.extendedProps.event_type === 'calendar_assessment')));
    if (descriptors.length !== 1) return null;
    const marker = descriptors[0];
    if (!object(marker) || marker.id !== 'roster-calendar-assessment' ||
        marker.title !== '' || marker.start !== null || marker.end !== null ||
        !object(marker.extendedProps)) return null;
    const extra = marker.extendedProps;
    const range = extra.range;
    const filters = extra.filters;
    const scope = extra.scope;
    const coverage = extra.coverage;
    if (extra.event_type !== 'calendar_assessment' || extra.schema_version !== 1 ||
        extra.actor_id !== context.actorId || extra.worker_timezone !== context.workerTimezone ||
        !object(range) || range.end_exclusive !== true ||
        !instant(range.start) || !instant(range.end) ||
        Date.parse(range.start) !== requestRange.start || Date.parse(range.end) !== requestRange.end ||
        !object(filters) || filters.staff_id !== context.filters.staff_id ||
        filters.client_id !== context.filters.client_id || !sameIds(filters.site_ids, context.filters.site_ids) ||
        !object(scope) || !ids(scope.site_ids) ||
        scope.kind !== (context.canReadAny ? 'approved_sites' : 'own') ||
        scope.published_only !== (!context.canReadAny && context.publicationEnabled) ||
        scope.staff_id !== (context.canReadAny ? context.filters.staff_id : context.actorId) ||
        scope.client_id !== (context.canReadAny ? context.filters.client_id : null) ||
        (context.filters.site_ids !== null && scope.site_ids.some((site) => !context.filters.site_ids!.includes(site))) ||
        !object(coverage)) return null;
    const status = coverage.status;
    const count = coverage.finding_count;
    const canAssess = context.canAssessCoverage && scope.site_ids.length > 0;
    if (status === 'assessed') {
        if (!canAssess || coverage.reason !== null || !Number.isSafeInteger(count) || (count as number) < 0) return null;
    } else if (status === 'partially_assessed') {
        if (!canAssess || coverage.reason !== 'unsafe_source' || count !== null) return null;
    } else if (status === 'not_assessed') {
        if (canAssess || count !== null || coverage.reason !== (context.canAssessCoverage ? 'no_sites' : 'permission')) return null;
    } else return null;
    const events: RosterCalendarEvent[] = [];
    const eventIds = new Set<string>();
    let gaps = 0;
    for (const row of value) {
        if (row === marker) continue;
        if (!object(row) || !object(row.extendedProps) ||
            !instant(row.start) || !instant(row.end) ||
            !(Date.parse(row.end) > Date.parse(row.start)) ||
            !(Date.parse(row.start) < requestRange.end && Date.parse(row.end) > requestRange.start) ||
            (row.title !== undefined && typeof row.title !== 'string')) return null;
        const props = row.extendedProps;
        if (!id(props.site_id) || !scope.site_ids.includes(props.site_id)) return null;
        const isGap = props.event_type === 'coverage_gap';
        if (isGap) {
            if (!canAssess || !id(props.coverage_rule_id) || typeof row.id !== 'string' ||
                !new RegExp(`^coverage-gap-${props.coverage_rule_id}-[a-f0-9]{32}$`).test(row.id)) return null;
            gaps++;
        } else {
            const shiftId = typeof row.id === 'number' ? row.id :
                typeof row.id === 'string' && /^[1-9]\d*$/.test(row.id) ? Number(row.id) : NaN;
            if (!id(shiftId) || (props.event_type !== undefined && props.event_type !== 'shift') ||
                !nullableId(props.user_id) || !nullableId(props.client_id) ||
                (scope.staff_id !== null && props.user_id !== scope.staff_id) ||
                (scope.client_id !== null && props.client_id !== scope.client_id)) return null;
        }
        const identity = `${isGap ? 'gap' : 'shift'}:${row.id}`;
        if (eventIds.has(identity)) return null;
        eventIds.add(identity);
        events.push({ ...row, extendedProps: { ...props, can_view_shift: props.can_view_shift === true } } as RosterCalendarEvent);
    }
    if (status === 'assessed' && count !== gaps) return null;
    const validatedCoverage: CalendarCoverageAssessment = status === 'assessed'
        ? { status, reason: null, finding_count: count as number }
        : status === 'partially_assessed'
          ? { status, reason: 'unsafe_source', finding_count: null }
          : { status, reason: context.canAssessCoverage ? 'no_sites' : 'permission', finding_count: null };
    const validatedScope: CalendarFeedScope = {
        kind: context.canReadAny ? 'approved_sites' : 'own', site_ids: scope.site_ids,
        published_only: !context.canReadAny && context.publicationEnabled!,
        staff_id: context.canReadAny ? context.filters.staff_id : context.actorId,
        client_id: context.canReadAny ? context.filters.client_id : null,
    };
    return { events, coverage: validatedCoverage, scope: validatedScope };
}
