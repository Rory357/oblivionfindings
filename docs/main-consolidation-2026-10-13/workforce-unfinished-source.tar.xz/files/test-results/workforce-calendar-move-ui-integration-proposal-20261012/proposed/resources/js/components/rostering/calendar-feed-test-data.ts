import type { CalendarFeedContext } from './calendar-feed-contract';

export const feedContext: CalendarFeedContext = {
    actorId: 5, workerTimezone: 'Pacific/Auckland', canReadAny: true,
    canAssessCoverage: true, publicationEnabled: true,
    filters: { staff_id: null, client_id: null, site_ids: [2, 7] },
};
export const feedUrl = '/operations/rostering/calendar/events?start=2026-10-01&end=2026-11-12&site_id[]=2&site_id[]=7';
export const duty = {
    id: 11, title: 'Duty', start: '2026-10-10T21:00:00Z', end: '2026-10-11T05:00:00Z',
    extendedProps: { status: 'scheduled', site_id: 2, user_id: 5, client_id: 3, can_view_shift: true },
};
export const gap = {
    id: 'coverage-gap-7-aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', title: 'Coverage gap',
    start: '2026-10-10T21:00:00Z', end: '2026-10-11T05:00:00Z',
    extendedProps: { event_type: 'coverage_gap', site_id: 2, coverage_rule_id: 7 },
};
/** October–December fixtures deliberately use NZ daylight time, independent of the decoder. */
export function descriptor(url = feedUrl, context = feedContext, findingCount = 0) {
    const params = new URL(url, 'http://calendar.local').searchParams;
    const edge = (key: string) => {
        const raw = params.get(key)!;
        return new Date(raw.includes('T') ? raw : `${raw}T00:00:00+13:00`).toISOString();
    };
    return {
        id: 'roster-calendar-assessment', title: '', start: null, end: null,
        extendedProps: {
            event_type: 'calendar_assessment', schema_version: 1, actor_id: context.actorId,
            worker_timezone: context.workerTimezone,
            range: { start: edge('start'), end: edge('end'), end_exclusive: true },
            filters: structuredClone(context.filters),
            scope: {
                kind: context.canReadAny ? 'approved_sites' : 'own', site_ids: context.filters.site_ids ?? [2, 7],
                published_only: !context.canReadAny && !!context.publicationEnabled,
                staff_id: context.canReadAny ? context.filters.staff_id : context.actorId,
                client_id: context.canReadAny ? context.filters.client_id : null,
            },
            coverage: context.canAssessCoverage
                ? { status: 'assessed', reason: null, finding_count: findingCount }
                : { status: 'not_assessed', reason: 'permission', finding_count: null },
        },
    };
}
