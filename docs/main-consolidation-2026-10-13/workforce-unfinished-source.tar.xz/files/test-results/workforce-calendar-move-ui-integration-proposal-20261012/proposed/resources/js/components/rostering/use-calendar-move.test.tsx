import { act, renderHook } from '@testing-library/react';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';

import { calendarMoveIntent } from './calendar-move-contract';
import { useCalendarMove } from './use-calendar-move';

const event = {
    id: 11, start: '2026-10-10T21:00:00Z', end: '2026-10-11T05:00:00Z',
    extendedProps: { shift_source: 'a'.repeat(64), client_id: 3, site_id: 2, user_id: 5, service_context_id: null, status: 'scheduled' },
};
const intent = calendarMoveIntent(event, 5, '7339947c-8d32-44f4-bf94-7d44cfda7e38', {
    starts_at: '2026-10-11T21:00:00.000Z', ends_at: '2026-10-12T05:00:00.000Z',
})!;
const requests: { options: RequestInit; resolve: (response: Response) => void; reject: (error: Error) => void }[] = [];
const confirmed = () => ({ ok: true, calendar_move_result: {
    version: 1, scope: 'calendar_move', action: 'update', actor_id: 5, shift_id: 11,
    request_id: intent.requestId, source: intent.source, outcome: 'confirmed',
    saved: { id: 11, client_id: 3, site_id: 2, user_id: 5, service_context_id: null, status: 'scheduled', starts_at: intent.startsAt, ends_at: intent.endsAt, shift_source: 'b'.repeat(64) },
    verified_at: '2026-10-11T12:30:00.000Z',
} });
const review = (canProceed = true) => ({ eligibility_review: {
    scope: 'calendar_qualification', actor_id: 5, shift_id: 11, user_id: 5,
    request_id: intent.requestId, source: intent.source, acknowledgement_required: true, reason_required: true,
    can_override_eligibility: canProceed, rule_codes: ['house_qualification_7'], warning_reasons: ['House qualification cannot be matched.'],
} });
function harness() {
    const options = { actorId: 5, contextKey: 'scope-a', canMove: true, canOverride: true,
        assessed: true, readKey: 'read-a', refresh: vi.fn(), confirmed: vi.fn() };
    return { options, view: renderHook(props => useCalendarMove(props), { initialProps: options }) };
}
async function complete(index: number, status: number, body: unknown) {
    await act(async () => requests[index].resolve({ status, json: async () => body } as Response));
}
beforeEach(() => {
    requests.length = 0;
    vi.stubGlobal('fetch', vi.fn((_url: string, options: RequestInit) =>
        new Promise<Response>((resolve, reject) => requests.push({ options, resolve, reject }))));
});
afterEach(() => vi.unstubAllGlobals());

it('serialises rapid repeated moves and sends only the exact modern intent', async () => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); void view.result.current.move(intent); });
    expect(requests).toHaveLength(1); expect(view.result.current.busy).toBe(true);
    expect(requests[0].options.headers).toMatchObject({ 'X-Calendar-Move-Result': 'committed-v1' });
    expect(JSON.parse(requests[0].options.body as string)).toEqual({ starts_at: intent.startsAt, ends_at: intent.endsAt, request_id: intent.requestId, expected_source: intent.source });
    expect(options.confirmed).not.toHaveBeenCalled();
    await complete(0, 200, confirmed());
    expect(options.confirmed).toHaveBeenCalledWith(intent); expect(options.refresh).toHaveBeenCalledOnce();
    expect(view.result.current.busy).toBe(false); expect(view.result.current.state.phase).toBe('idle');
});
it.each([202, 500])('never confirms or replays an uncertain HTTP%s result', async status => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, status, confirmed());
    expect(view.result.current.state.phase).toBe('unconfirmed'); expect(options.confirmed).not.toHaveBeenCalled();
    act(() => { void view.result.current.move(intent); }); expect(requests).toHaveLength(1);
    expect(options.refresh).toHaveBeenCalledOnce();
});
it('retains transport uncertainty and requires a fresh assessed read before continuing', async () => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); });
    await act(async () => requests[0].reject(new Error('Network lost')));
    expect(view.result.current.state.phase).toBe('unconfirmed');
    act(() => expect(view.result.current.useCurrentRecord(event)).toBe(false));
    view.rerender({ ...options, readKey: 'read-b', assessed: false });
    act(() => expect(view.result.current.useCurrentRecord(event)).toBe(false));
    view.rerender({ ...options, readKey: 'read-b' });
    act(() => expect(view.result.current.useCurrentRecord(event)).toBe(true));
    expect(view.result.current.state.phase).toBe('idle'); expect(requests).toHaveLength(1);
    expect(options.confirmed).not.toHaveBeenCalled();
});
it('a fresh assessed absence can release recovery without claiming the command saved', async () => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, 404, {});
    view.rerender({ ...options, readKey: 'read-b' });
    act(() => expect(view.result.current.useCurrentRecord(null)).toBe(true));
    expect(view.result.current.state.phase).toBe('idle'); expect(options.confirmed).not.toHaveBeenCalled();
});
it('requires the current source, current manager authority and a nonempty bounded reason to proceed', async () => {
    const { view } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, 422, review());
    expect(view.result.current.state.phase).toBe('review');
    act(() => { void view.result.current.confirmReview(event); }); expect(requests).toHaveLength(1);
    act(() => view.result.current.setReason('   reviewed requirement   '));
    act(() => { void view.result.current.confirmReview({ ...event, extendedProps: { ...event.extendedProps, shift_source: 'b'.repeat(64) } }); });
    expect(requests).toHaveLength(1);
    act(() => view.result.current.setReason('x'.repeat(2001)));
    act(() => { void view.result.current.confirmReview(event); }); expect(requests).toHaveLength(1);
    act(() => view.result.current.setReason('   reviewed requirement   '));
    act(() => { void view.result.current.confirmReview(event); }); expect(requests).toHaveLength(2);
    expect(JSON.parse(requests[1].options.body as string)).toMatchObject({ request_id: intent.requestId, expected_source: intent.source, override_acknowledged: true, override_reason: 'reviewed requirement' });
});
it('keeps the manager reason after uncertainty and never silently resends the acknowledgement', async () => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, 422, review());
    act(() => view.result.current.setReason('Reviewed with qualified lead'));
    act(() => { void view.result.current.confirmReview(event); });
    await act(async () => requests[1].reject(new Error('Lost response')));
    expect(view.result.current.state).toMatchObject({ phase: 'unconfirmed', reason: 'Reviewed with qualified lead', review: null });
    act(() => { void view.result.current.confirmReview(event); void view.result.current.move(intent); });
    expect(requests).toHaveLength(2); expect(options.confirmed).not.toHaveBeenCalled();
});
it('denied override permission never sends an acknowledgement', async () => {
    const { view } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, 422, review(false));
    act(() => view.result.current.setReason('A reason'));
    act(() => { void view.result.current.confirmReview(event); }); expect(requests).toHaveLength(1);
});
it('revocation clears old warnings and blocks another acknowledgement', async () => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, 422, review());
    act(() => view.result.current.setReason('A reason'));
    view.rerender({ ...options, canOverride: false });
    expect(view.result.current.state.review).toBeNull();
    act(() => { void view.result.current.confirmReview(event); }); expect(requests).toHaveLength(1);
});
it.each(['actor', 'scope', 'permission'])('late completion after %s change has no stale success and releases the serial lock', async change => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); });
    const next = { ...options, ...(change === 'actor' ? { actorId: 6 } : change === 'scope' ? { contextKey: 'scope-b' } : { canMove: false }) };
    view.rerender(next);
    expect(view.result.current.state.intent).toBeNull(); expect(view.result.current.busy).toBe(true);
    await complete(0, 200, confirmed());
    expect(view.result.current.busy).toBe(false); expect(options.confirmed).not.toHaveBeenCalled();
    expect(options.refresh).not.toHaveBeenCalled();
});
it('cancel is unavailable while a reviewed move is in flight', async () => {
    const { view } = harness();
    act(() => { void view.result.current.move(intent); }); await complete(0, 422, review());
    act(() => view.result.current.setReason('A reason'));
    act(() => { void view.result.current.confirmReview(event); });
    act(() => view.result.current.cancelReview()); expect(view.result.current.state.phase).toBe('saving');
    await complete(1, 403, {}); expect(view.result.current.state.phase).toBe('rejected');
});
it('unmount ignores a late result without replay, success or refresh callbacks', async () => {
    const { view, options } = harness();
    act(() => { void view.result.current.move(intent); }); view.unmount();
    await complete(0, 200, confirmed());
    expect(options.confirmed).not.toHaveBeenCalled(); expect(options.refresh).not.toHaveBeenCalled();
});
