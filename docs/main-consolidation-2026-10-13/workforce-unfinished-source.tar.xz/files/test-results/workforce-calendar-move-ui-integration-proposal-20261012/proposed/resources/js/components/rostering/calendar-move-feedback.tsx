import { AlertTriangle, LoaderCircle } from 'lucide-react';
import { useId } from 'react';

import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { formatDateTimeInZone } from '@/lib/datetime';

import type { RosterCalendarEvent } from './calendar-feed-contract';
import type { useCalendarMove } from './use-calendar-move';

type Props = {
    move: ReturnType<typeof useCalendarMove>;
    event: RosterCalendarEvent | null;
    assessed: boolean;
    loading: boolean;
    readKey: string;
    refresh: () => void;
    timezone: string | undefined;
    canOverride: boolean;
};

/** Keep the review controlled by this exact move and preserve its reason on uncertainty. */
export function CalendarMoveFeedback({ move, event, assessed, loading, readKey, refresh, timezone, canOverride }: Props) {
    const reasonId = useId();
    const { state, busy } = move;
    const currentSource = assessed && event !== null && state.intent !== null &&
        Number(event.id) === state.intent.shiftId && event.extendedProps?.shift_source === state.intent.source;
    const canProceed = state.phase === 'review' && currentSource && canOverride &&
        state.review?.canProceed === true && !busy;
    const recovering = state.phase === 'unconfirmed' || state.phase === 'rejected';
    const freshRead = assessed && readKey !== state.readKeyAtAttempt && !busy;
    const reviewOpen = state.review !== null && (state.phase === 'review' || state.phase === 'saving');

    return <>
        {busy && !reviewOpen ? (
            <p role="status" className="mx-4 mt-4 flex items-center gap-2 text-sm text-muted-foreground">
                <LoaderCircle className="size-4 animate-spin" aria-hidden="true" /> Checking the saved shift move…
            </p>
        ) : null}
        {recovering ? (
            <div role="alert" className="mx-4 mt-4 space-y-3 rounded-lg border border-status-warning/30 bg-status-warning-bg p-4 text-status-warning [overflow-wrap:anywhere]">
                <p className="flex items-start gap-2 font-medium">
                    <AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />
                    {state.phase === 'unconfirmed' ? 'Check this shift before making another move' : 'The shift was not moved'}
                </p>
                <p className="text-sm">{state.error}</p>
                {state.reason ? (
                    <div className="space-y-1.5">
                        <Label htmlFor={reasonId}>Your reason is kept here</Label>
                        <Textarea id={reasonId} value={state.reason} readOnly rows={3} />
                    </div>
                ) : null}
                {freshRead ? (
                    <p className="text-sm">{event ? 'The calendar has loaded the current shift position.' : 'This shift is no longer in the loaded calendar.'} This does not confirm whether the earlier request was saved.</p>
                ) : <p className="text-sm">Load the current calendar before continuing. The earlier request will not be sent again.</p>}
                <div className="flex flex-wrap gap-2">
                    <Button className="frontline-tap" variant="outline" onClick={refresh} disabled={loading || busy}>Refresh calendar</Button>
                    <Button className="frontline-tap" disabled={!freshRead} onClick={() => move.useCurrentRecord(event)}>Continue with loaded calendar</Button>
                </div>
            </div>
        ) : null}
        <Dialog open={reviewOpen} onOpenChange={open => { if (!open) move.cancelReview(); }}>
            <DialogContent className="frontline-dialog flex max-h-[88dvh] min-w-0 flex-col overflow-hidden p-0 sm:max-w-lg"
                showCloseButton={!busy} onEscapeKeyDown={event => { if (busy) event.preventDefault(); }}
                onPointerDownOutside={event => { if (busy) event.preventDefault(); }}>
                <DialogHeader className="shrink-0 border-b p-5 pr-12 text-left">
                    <DialogTitle className="flex items-center gap-2"><AlertTriangle className="size-5 shrink-0 text-status-warning" aria-hidden="true" /> Review qualifications before moving</DialogTitle>
                    <DialogDescription>This move needs an authorised manager to review the warnings and give a reason. Nothing has been moved yet.</DialogDescription>
                </DialogHeader>
                <div className="min-h-0 space-y-4 overflow-y-auto p-5 [overflow-wrap:anywhere]">
                    {state.intent ? <p className="text-sm">Requested time: {formatDateTimeInZone(state.intent.startsAt, timezone)} to {formatDateTimeInZone(state.intent.endsAt, timezone)}.</p> : null}
                    <ul className="space-y-2 rounded-lg border border-status-warning/30 bg-status-warning-bg p-3 text-sm text-status-warning">
                        {state.review?.warningReasons.map(warning => <li key={warning} className="flex items-start gap-2"><AlertTriangle className="mt-0.5 size-4 shrink-0" aria-hidden="true" />{warning}</li>)}
                    </ul>
                    {canOverride && state.review?.canProceed ? (
                        <div className="space-y-1.5">
                            <Label htmlFor={reasonId}>Reason to proceed</Label>
                            <Textarea id={reasonId} value={state.reason} onChange={event => move.setReason(event.target.value)} disabled={busy} aria-required="true" maxLength={2000} rows={3} />
                            <p className="text-caption text-muted-foreground">A reason is required. This decision is recorded with the move.</p>
                        </div>
                    ) : <p role="status" className="text-sm">You cannot override these warnings. Ask an authorised manager to review the shift.</p>}
                    {!currentSource && !busy ? <p role="status" className="text-sm">The current shift needs checking again. Cancel this review and refresh the calendar before moving it.</p> : null}
                    {busy ? <p role="status" className="flex items-center gap-2 text-sm"><LoaderCircle className="size-4 animate-spin" aria-hidden="true" /> Checking the saved shift move…</p> : null}
                </div>
                <DialogFooter className="shrink-0 flex-wrap border-t bg-muted/30 p-4">
                    <Button className="frontline-tap max-w-full whitespace-normal" variant="outline" disabled={busy} onClick={move.cancelReview}>Cancel move</Button>
                    <Button className="frontline-tap max-w-full whitespace-normal" disabled={!canProceed || !state.reason.trim() || state.reason.trim().length > 2000} onClick={() => void move.confirmReview(event)}>{busy ? 'Checking move…' : 'Proceed and move shift'}</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
    </>;
}
