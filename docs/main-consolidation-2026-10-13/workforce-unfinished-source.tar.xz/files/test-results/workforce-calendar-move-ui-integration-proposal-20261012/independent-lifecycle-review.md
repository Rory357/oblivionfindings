HOLD for manifest d702805814c1b646bc03273dff32f37dc7a903d107e67cf6120d764b244df675.

1. Equal key text permits A -> B -> A late result admission; use a monotonic attempt epoch.
2. Requested filters omit actual assessed Site cohort, so narrowed authority can leave old qualification warnings/reason visible. Retain last assessed scope through loading and clear private details on a real transition.
3. Documentary patches require newline normalization:17 whole normalized forwards/inverses match; raw-byte inversion is not certified.

All32 declared artifacts,19 current path states,20 dependencies/seven lineage references match. Actual Pane mounting, modern wire and strict decoder are coherent. Seven suites remain unrun; actual acceptance null. Canonical SiteCalendar migration remains open.
