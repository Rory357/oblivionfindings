R1 is HOLD_SOURCE_ONLY against manifest7c6e0d10. All three complete forward/inverse transitions match exact source bytes; the current pane baseline is unchanged. The hook is connected to the actual CalendarPane, with render-time old-range withholding and latest cancelled-response protection.

Three fixes are required in a preserved successor:

- The pane still calls removed setEvents before its move request. Bind a ready-only range/retry updater or deliberately remove that optimistic block; keep existing write/recovery semantics separate from acceptance.
- A numeric event with null dates is accepted as ready and then silently dropped by mapShift, producing an assessed zero. Reject unrenderable known event rows, with lawful gap controls.
- The hidden Day dialog retains its day across failure; Today can load another month and then reopen the old out-of-range day as empty. Invalidate or exact-range-bind that selection, with an actual pane sequence control.

The eight proposed hook cases are source-derived and unrun. They do not exercise the two owning-pane integration failures. No parser, type/lint/unit test, PHP/framework/native/browser or database/process action was performed. Existing role/timezone/date/URL/link/drag-save findings remain outside this increment and unaccepted.
