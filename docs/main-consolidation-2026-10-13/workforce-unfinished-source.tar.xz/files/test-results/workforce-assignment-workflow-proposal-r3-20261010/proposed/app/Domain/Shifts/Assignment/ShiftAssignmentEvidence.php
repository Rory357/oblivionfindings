<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\CoverageReservation;
use App\Models\Shift;
use App\Models\ShiftOpenPosition;
use App\Models\ShiftReplacementRequest;
use App\Models\TimelineEvent;
use App\Models\User;
use App\Services\CoverageReservationService;
use App\Services\Eligibility\AssignmentEligibilityDecision;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/** Short-lived evidence belonging to one lifecycle invocation, never a cross-request token. */
final class ShiftAssignmentEvidence
{
    public ?Shift $before = null;
    public ?User $actor = null;
    public ?array $review = null;
    private array $proofs = [];
    private Collection $positions;
    private ?ShiftReplacementRequest $replacement = null;
    private Collection $holds;
    private ?\Carbon\CarbonImmutable $releaseFloor = null;
    private mixed $connection;
    private mixed $pdo;

    public function __construct(public readonly string $action, public readonly array $expectedSource,
        public readonly ?int $requestedUserId, private readonly array $override)
    {
        $this->positions = collect();
        $this->holds = collect();
        $this->connection = DB::connection();
        $this->pdo = $this->connection->getPdo();
    }

    private function assertTransaction(): void
    {
        if (DB::connection() !== $this->connection || $this->connection->getPdo() !== $this->pdo
            || $this->connection->transactionLevel() < 1 || ! $this->pdo->inTransaction()) {
            throw new \LogicException('Assignment evidence left its governing transaction.');
        }
    }

    public function current(Shift $shift, User $actor): void
    {
        $this->assertTransaction();
        if (DB::transactionLevel() < 1 || $this->before !== null || (int) $shift->id !== $this->expectedSource['shift_id']) {
            throw new \LogicException('Assignment evidence must belong to this locked command.');
        }
        $this->before = clone $shift;
        $this->actor = $actor;
        if (ShiftAssignmentSource::describe($shift) !== $this->expectedSource) {
            throw new ShiftAssignmentRefusal('source_changed');
        }
        if (in_array($shift->status, ['completed', 'cancelled'], true)) {
            throw new ShiftAssignmentRefusal('locked');
        }
        if ($this->action === 'unassign' && $shift->status === 'in_progress') {
            throw new ShiftAssignmentRefusal('in_progress');
        }
        if ($this->action === 'unassign') {
            $this->releaseFloor = \Carbon\CarbonImmutable::now()->startOfSecond();
            // Exact existing releaseForShift predicate; do not redefine hold ownership/window policy.
            $this->holds = CoverageReservation::query()->where('status', CoverageReservationService::STATUS_ACTIVE)
                ->where(function ($query) use ($shift) {
                    $query->where('shift_id', $shift->id)->orWhere(function ($window) use ($shift) {
                        if (! $shift->site_id || ! $shift->starts_at || ! $shift->ends_at) {
                            $window->whereRaw('1=0');
                            return;
                        }
                        $window->where('site_id', $shift->site_id)
                            ->where('window_starts_at', $shift->starts_at->copy()->utc())
                            ->where('window_ends_at', $shift->ends_at->copy()->utc());
                    });
                })->orderBy('id')->lockForUpdate()->get();
        } elseif ($shift->user_id && (int) $shift->user_id !== $this->requestedUserId) {
            $access = app(UserSiteAccessService::class);
            $this->positions = ShiftOpenPosition::query()->tap(fn ($query) => $access->applyShiftOpenPositionIntegrityScope($query))
                ->where('shift_id', $shift->id)->orderBy('id')->lockForUpdate()->get();
            $this->replacement = ShiftReplacementRequest::query()->tap(fn ($query) => $access->applyShiftReplacementIntegrityScope($query))
                ->where('shift_id', $shift->id)->active()->latest('requested_at')->lockForUpdate()->first();
            if ($this->replacement) {
                $this->replacement->setRelation('openPosition', $this->positions->firstWhere('replacement_request_id', $this->replacement->id));
                $this->replacement->setRelation('shift', $shift);
            }
        }
    }

    public function decision(AssignmentEligibilityDecision $decision): void
    {
        if (! $this->actor || ! $decision->result) {
            return; // Real unavailable/hard-block path remains the installed error contract.
        }
        $this->review = ShiftAssignmentReview::fromResult($decision->result, $this->actor);
        if ($decision->result->hasBlocks()) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'user_id' => $this->review['blocked_reasons'][0],
            ])->status(422);
        }
        if (! $decision->isWarning()) {
            return;
        }
        if (! ($this->override['override_acknowledged'] ?? false)) {
            throw new ShiftAssignmentRefusal('eligibility_warning');
        }
        if ($this->review['reason_required']) {
            abort_unless($this->actor->canDo('shifts.overrideEligibility'), 403);
            if (trim((string) ($this->override['override_reason'] ?? '')) === '') {
                throw new ShiftAssignmentRefusal('override_reason_required');
            }
        }
    }

    public function remember(Model $model, ?array $fields = null): void
    {
        $this->assertTransaction();
        $fields ??= $model->getFillable();
        if (! $model->exists || ! $model->getKey()) {
            throw new \LogicException('An assignment write has no persisted identity.');
        }
        $this->proofs[$model::class.':'.$model->getKey()] = [$model::class, $model->getKey(), $fields,
            ShiftAssignmentSource::values($model, $fields)];
    }

    /** Captures intended values before observers; default service paths never call this writer. */
    public function checkedUpdate(Model $model, array $values): bool
    {
        $this->assertTransaction();
        $identity = $model->getKey();
        $intent = clone $model;
        $intent->fill($values);
        // Round date values through the actual model's storage format before observers.
        $intent->setRawAttributes($intent->getAttributes());
        $fields = $model->getFillable();
        $expected = ShiftAssignmentSource::values($intent, $fields);
        if ($model->update($values) !== true || $model->getKey() !== $identity) {
            throw new \LogicException('An assignment side effect was not saved.');
        }
        $stored = $model->newQuery()->whereKey($identity)->lockForUpdate()->first();
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('An assignment side effect did not match its intent.');
        }
        // The existing current replacement reader compares these stored datetime values.
        $model->setRawAttributes($stored->getAttributes(), true);
        $this->remember($stored, $fields);

        return true;
    }

    public function createHold(array $values): CoverageReservation
    {
        $this->assertTransaction();
        $hold = new CoverageReservation($values);
        $intent = clone $hold;
        $intent->setRawAttributes($intent->getAttributes());
        $fields = $hold->getFillable();
        $expected = ShiftAssignmentSource::values($intent, $fields);
        if ($hold->save() !== true || ! $hold->exists || ! $hold->id) {
            throw new \LogicException('The assignment hold was not created.');
        }
        $stored = CoverageReservation::query()->whereKey($hold->id)->lockForUpdate()->first();
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('The created assignment hold did not match its intent.');
        }
        $hold->setRawAttributes($stored->getAttributes(), true);
        $this->remember($stored, $fields);

        return $hold;
    }

    public function timeline(array $keys, array $values): TimelineEvent
    {
        $this->assertTransaction();
        $event = TimelineEvent::query()->where($keys)->lockForUpdate()->first() ?? new TimelineEvent($keys);
        $intent = clone $event;
        $intent->fill($values);
        $intent->setRawAttributes($intent->getAttributes());
        $fields = array_values(array_unique(array_merge(array_keys($keys), array_keys($values))));
        $expected = ShiftAssignmentSource::values($intent, $fields);
        $identity = $event->getKey();
        $event->fill($values);
        if ($event->save() !== true || ! $event->id || ($identity !== null && $event->getKey() !== $identity)) {
            throw new \LogicException('Assignment history was not saved.');
        }
        $stored = TimelineEvent::query()->whereKey($event->id)->lockForUpdate()->first();
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('Assignment history did not match its intent.');
        }
        $this->remember($stored, $fields);

        return $stored;
    }

    public function recordTimeline(array $values): TimelineEvent
    {
        $this->assertTransaction();
        $intent = new TimelineEvent($values);
        $intent->setRawAttributes($intent->getAttributes());
        $fields = array_keys($values);
        $expected = ShiftAssignmentSource::values($intent, $fields);
        $event = app(\App\Services\Timeline\TimelineEmitter::class)->record($values);
        $stored = $event->id ? TimelineEvent::query()->whereKey($event->id)->lockForUpdate()->first() : null;
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('Replacement history did not match its intent.');
        }
        $this->remember($stored, $fields);

        return $stored;
    }

    public function replacementContext(Shift $shift, User $actor, User $staff): array
    {
        return ['shift' => $shift, 'actor' => $actor, 'staff' => $staff,
            'replacement' => $this->replacement, 'positions' => $this->positions];
    }

    public function releasedHolds(): void
    {
        $this->assertTransaction();
        $ceiling = \Carbon\CarbonImmutable::now()->startOfSecond();
        foreach ($this->holds as $hold) {
            $stored = CoverageReservation::query()->whereKey($hold->id)->lockForUpdate()->first();
            $fields = array_diff($hold->getFillable(), ['status', 'expires_at']);
            if (! $stored || $stored->status !== CoverageReservationService::STATUS_RELEASED || ! $stored->expires_at
                || ! $this->releaseFloor || $stored->expires_at->lt($this->releaseFloor) || $stored->expires_at->gt($ceiling)
                || ShiftAssignmentSource::values($stored, $fields) !== ShiftAssignmentSource::values($hold, $fields)) {
                throw new \LogicException('The released assignment hold did not match its intent.');
            }
            $this->remember($stored);
        }
    }

    public function finish(Shift $shift): Shift
    {
        $this->assertTransaction();
        if (! $this->before || ! $this->actor || DB::transactionLevel() < 1) {
            throw new \LogicException('Assignment proof is incomplete.');
        }
        $stored = Shift::query()->whereKey($this->before->id)->lockForUpdate()->firstOrFail();
        $targetStatus = $this->action === 'unassign' ? 'draft' : ($this->before->status === 'draft' ? 'scheduled' : $this->before->status);
        $intent = clone $this->before;
        $intent->user_id = $this->requestedUserId;
        $intent->status = $targetStatus;
        if ((int) $shift->id !== (int) $stored->id || ShiftAssignmentSource::values($stored, $stored->getFillable())
            !== ShiftAssignmentSource::values($intent, $intent->getFillable())) {
            throw new \LogicException('The final assignment does not match this command.');
        }
        foreach ($this->holds as $hold) {
            $fresh = CoverageReservation::query()->whereKey($hold->id)->lockForUpdate()->first();
            if (! $fresh || $fresh->status !== CoverageReservationService::STATUS_RELEASED || ! $fresh->expires_at) {
                throw new \LogicException('The assignment hold was not released.');
            }
            $fields = array_diff($hold->getFillable(), ['status', 'expires_at']);
            if (ShiftAssignmentSource::values($fresh, $fields) !== ShiftAssignmentSource::values($hold, $fields)) {
                throw new \LogicException('An unrelated hold field changed.');
            }
        }
        if ($this->replacement) {
            foreach ($this->positions as $position) {
                if (in_array($position->status, ['open', 'claimed'], true)
                    && (int) $position->id !== (int) $this->replacement->openPosition?->id) {
                    $fresh = ShiftOpenPosition::query()->whereKey($position->id)->lockForUpdate()->first();
                    $intent = clone $position;
                    $intent->status = 'cancelled';
                    if (! $fresh || ShiftAssignmentSource::values($fresh, $fresh->getFillable()) !== ShiftAssignmentSource::values($intent, $intent->getFillable())) {
                        throw new \LogicException('Replacement positions did not match the cancellation intent.');
                    }
                }
            }
        }
        foreach ($this->proofs as [$class, $id, $fields, $expected]) {
            $fresh = $class::query()->whereKey($id)->lockForUpdate()->first();
            if (! $fresh || ShiftAssignmentSource::values($fresh, $fields) !== $expected) {
                throw new \LogicException('An assignment side effect changed after its proof.');
            }
        }

        return $stored;
    }
}
