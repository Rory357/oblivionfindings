from pathlib import Path
import json, hashlib, difflib

P=Path(__file__).parent
R2=P.parent/'workforce-assignment-workflow-proposal-r2-20261010'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((P/'r2-baseline-pins.json').read_bytes())
for path,digest in pins['files'].items():assert sha(R2/path)==digest,path
source=json.loads((P/'manifest.json').read_bytes())
delta=[]; changed={}; unchanged=[]
for path in source['files']:
    previous=R2/'proposed'/path
    if not previous.exists():previous=P/'baseline'/path
    before=previous.read_bytes();after=(P/'proposed'/path).read_bytes()
    if before==after:unchanged.append(path);continue
    changed[path]={'before':hashlib.sha256(before).hexdigest(),'after':hashlib.sha256(after).hexdigest()}
    delta.extend(difflib.unified_diff(before.decode('utf-8').splitlines(keepends=True),after.decode('utf-8').splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path,n=3))
assert set(changed)=={'app/Domain/Shifts/Assignment/ShiftAssignmentEvidence.php','app/Domain/Shifts/Lifecycle/ShiftLifecycleService.php',
                     'app/Services/CoverageReservationService.php','tests/Feature/Rostering/WorkforceShiftAssignmentCommandIntegrityTest.php'}
(P/'revision.patch').write_bytes(''.join(delta).encode('utf-8'))
# Use only the previously audited pure lexical span function; no PHP parser or application.
scope={'__file__':str(P/'proof.py')}
exec((P/'proof.py').read_text(encoding='utf-8').split('\npaths=')[0],scope)
methods=scope['methods']
test='tests/Feature/Rostering/WorkforceShiftAssignmentCommandIntegrityTest.php'
old=methods((R2/'proposed'/test).read_bytes());new=methods((P/'proposed'/test).read_bytes())
for name,body in old.items():assert new[name]==body,name
result={'status':'PURE_R2_HOLD_PROOF_DELTA','r2_manifest_sha256':sha(R2/'manifest.json'),'r2_full_pinned_files_unchanged':len(pins['files']),
        'changed_product_paths':changed,'unchanged_product_paths':unchanged,'all_r2_test_and_provider_and_helper_bodies_exact':len(old),
        'added_methods':sorted(set(new)-set(old)),'revision_patch_sha256':sha(P/'revision.patch'),
        'source_derived_added_cases':7,'actual_inventory':None,'runtime_or_parser_invoked':False}
(P/'delta-proof.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'delta':sha(P/'delta-proof.json'),'patch':sha(P/'revision.patch'),'unchanged_paths':len(unchanged),'preserved_test_bodies':len(old)},indent=2))
