from pathlib import Path
import json, hashlib, difflib, re

ROOT = Path('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
PACKET = Path(__file__).parent
BASE = PACKET/'baseline'
OUT = PACKET/'proposed'

def read(p):
    return Path('\\\\?\\'+str(p).replace('/','\\')).read_bytes()

def save(p, body):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(body.encode() if isinstance(body, str) else body)

def sha(b): return hashlib.sha256(b).hexdigest()

def new(path, body): save(OUT/path, body)

def existing(path):
    body=read(ROOT/path); save(BASE/path,body)
    return body

def swap(body, old, replacement, count=1):
    old=old.encode(); replacement=replacement.encode()
    assert body.count(old)==count, (old[:100],body.count(old),count)
    return body.replace(old,replacement)

NS='app/Domain/Shifts/Assignment/'

new(NS+'ShiftAssignmentSource.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\Shift;
use App\Models\Site;
use App\Models\User;
use App\Services\CurrentAuthorizationReads;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;

/** Fixed semantic projection, independent of raw SQL column order and scalar driver types. */
final class ShiftAssignmentSource
{
    public static function describe(Shift $shift): array
    {
        $fields = array_merge(['id'], $shift->getFillable(), ['version', 'roster_period_id', 'published_at', 'publish_dirty_at']);

        return ['shift_id' => (int) $shift->id,
            'revision' => hash('sha256', json_encode(self::values($shift, $fields), JSON_THROW_ON_ERROR))];
    }

    /** Called only after the current command authority prefix, while this Shift/Client remain locked. */
    public static function display(Shift $shift): array
    {
        return CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($shift): array {
            // These are only the already-authorised canonical Shift's Site and assigned owner.
            // NOWAIT current scalar reads cannot wait on an inverse User/Site writer chain.
            $site = $reads->query(Site::query())->whereKey($shift->site_id)->first(['id', 'name']);
            $staff = $shift->user_id
                ? $reads->query(User::query())->whereKey($shift->user_id)->first(['id', 'name'])
                : null;
            $client = $shift->relationLoaded('client') ? $shift->getRelation('client') : null;
            if (! $client || (int) $client->id !== (int) $shift->client_id || (int) $client->site_id !== (int) $shift->site_id
                || ! $site || (int) $site->id !== (int) $shift->site_id) {
                throw new \LogicException('The assignment display has no canonical source.');
            }

            return ['id' => (int) $shift->id,
                'starts_at' => $shift->starts_at?->copy()->utc()->toIso8601String(),
                'ends_at' => $shift->ends_at?->copy()->utc()->toIso8601String(),
                'client' => trim($client->first_name.' '.$client->last_name) ?: null,
                'site' => $site->name ?: null, 'staff' => $staff?->name ?: null,
                'isOpen' => $shift->user_id === null];
        });
    }

    public static function values(Model $model, array $fields): array
    {
        $values = [];
        foreach ($fields as $field) {
            $value = $model->getAttribute($field);
            if ($value instanceof DateTimeInterface) {
                $value = \Carbon\CarbonImmutable::instance($value)->utc()->format('Y-m-d\TH:i:s.u\Z');
            } elseif ($value !== null && ($field === 'version' || $field === 'id' || str_ends_with($field, '_id')
                || in_array($field, ['source_id', 'created_by', 'approved_by', 'claimed_by', 'requested_by', 'overridden_by', 'started_by', 'completed_by', 'handover_waived_by'], true))) {
                $value = (int) $value;
            }
            $values[$field] = self::json($value);
        }

        return $values;
    }

    private static function json(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value, SORT_STRING);
        }

        return array_map(self::json(...), $value);
    }
}
''')

new(NS+'ShiftAssignmentReview.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\User;
use App\Services\Eligibility\EligibilityResult;

/** Never forwards raw rule/evidence messages, which can contain a different Client's name. */
final class ShiftAssignmentReview
{
    public static function unknown(): array
    {
        return ['assessment_status' => 'unknown', 'acknowledgement_required' => false,
            'reason_required' => false, 'can_override_eligibility' => false,
            'warning_reasons' => ['Eligibility could not be assessed. Review before assigning.'], 'blocked_reasons' => []];
    }

    public static function fromResult(EligibilityResult $result, User $actor): array
    {
        $blocked = [];
        $warnings = [];
        foreach ($result->checked_rules as $check) {
            if (! is_array($check) || ! is_string($check['rule'] ?? null) || ! is_bool($check['passed'] ?? null)
                || ! in_array($check['severity'] ?? null, ['block', 'warning', 'info'], true)) {
                throw new \UnexpectedValueException('Eligibility assessment was incomplete.');
            }
            if ($check['passed'] || $check['severity'] === 'info') {
                continue;
            }
            $message = self::message($check['rule']);
            if ($check['severity'] === 'block') {
                $blocked[] = $message;
            } else {
                $warnings[] = $message;
            }
        }
        // Do not turn a malformed aggregate with absent rule rows into a pass.
        if ($result->hasBlocks() && $blocked === []) {
            $blocked[] = 'This worker cannot be assigned. Review the current eligibility checks.';
        }
        if ($result->hasWarnings() && $warnings === []) {
            $warnings[] = 'Review the current eligibility warnings before assigning.';
        }

        return ['assessment_status' => 'assessed', 'acknowledgement_required' => $result->hasWarnings(),
            'reason_required' => $result->hasWarnings() && $result->overrideable_warnings !== [],
            'can_override_eligibility' => $actor->canDo('shifts.overrideEligibility'),
            'warning_reasons' => array_values(array_unique($warnings)), 'blocked_reasons' => array_values(array_unique($blocked))];
    }

    private static function message(string $rule): string
    {
        return match (true) {
            $rule === 'conflict' => 'This worker has an overlapping duty.',
            in_array($rule, ['time_off', 'availability_leave'], true) => 'This worker has time off during this duty.',
            $rule === 'availability' => 'This duty is outside the worker’s availability.',
            $rule === 'availability_employment' => 'Review the worker’s employment dates for this duty.',
            $rule === 'turnaround' => 'Review the turnaround time between duties.',
            str_starts_with($rule, 'fatigue') => 'Review the worker’s hours and rest between duties.',
            $rule === 'client_qualification' => 'Review the required Client qualifications for this duty.',
            str_starts_with($rule, 'house_qualification') => 'Review the required House qualifications for this duty.',
            in_array($rule, ['compliance', 'onboarding', 'hs_training', 'driver_licence', 'medication_competency'], true) => 'Review the worker’s required eligibility evidence for this duty.',
            in_array($rule, ['coverage_roles', 'overfill'], true) => 'Review the current staffing coverage for this duty.',
            default => 'Review the current eligibility checks for this duty.',
        };
    }
}
''')

new(NS+'ShiftAssignmentRefusal.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

/** Only deliberately classified pre-write command decisions use this exception. */
final class ShiftAssignmentRefusal extends \RuntimeException
{
    public function __construct(public readonly string $reason)
    {
        parent::__construct('No assignment changes were applied.');
    }
}
''')

new(NS+'ShiftAssignmentEvidence.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\CoverageReservation;
use App\Models\Shift;
use App\Models\ShiftOpenPosition;
use App\Models\ShiftReplacementRequest;
use App\Models\TimelineEvent;
use App\Models\User;
use App\Services\CoverageReservationService;
use App\Services\Eligibility\AssignmentEligibilityDecision;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/** Short-lived evidence belonging to one lifecycle invocation, never a cross-request token. */
final class ShiftAssignmentEvidence
{
    public ?Shift $before = null;
    public ?User $actor = null;
    public ?array $review = null;
    private array $proofs = [];
    private Collection $positions;
    private ?ShiftReplacementRequest $replacement = null;
    private Collection $holds;
    private ?\Carbon\CarbonImmutable $releaseFloor = null;
    private mixed $connection;
    private mixed $pdo;

    public function __construct(public readonly string $action, public readonly array $expectedSource,
        public readonly ?int $requestedUserId, private readonly array $override)
    {
        $this->positions = collect();
        $this->holds = collect();
        $this->connection = DB::connection();
        $this->pdo = $this->connection->getPdo();
    }

    private function assertTransaction(): void
    {
        if (DB::connection() !== $this->connection || $this->connection->getPdo() !== $this->pdo
            || $this->connection->transactionLevel() < 1 || ! $this->pdo->inTransaction()) {
            throw new \LogicException('Assignment evidence left its governing transaction.');
        }
    }

    public function current(Shift $shift, User $actor): void
    {
        $this->assertTransaction();
        if (DB::transactionLevel() < 1 || $this->before !== null || (int) $shift->id !== $this->expectedSource['shift_id']) {
            throw new \LogicException('Assignment evidence must belong to this locked command.');
        }
        $this->before = clone $shift;
        $this->actor = $actor;
        if (ShiftAssignmentSource::describe($shift) !== $this->expectedSource) {
            throw new ShiftAssignmentRefusal('source_changed');
        }
        if (in_array($shift->status, ['completed', 'cancelled'], true)) {
            throw new ShiftAssignmentRefusal('locked');
        }
        if ($this->action === 'unassign' && $shift->status === 'in_progress') {
            throw new ShiftAssignmentRefusal('in_progress');
        }
        if ($this->action === 'unassign') {
            $this->releaseFloor = \Carbon\CarbonImmutable::now()->startOfSecond();
            // Exact existing releaseForShift predicate; do not redefine hold ownership/window policy.
            $this->holds = CoverageReservation::query()->where('status', CoverageReservationService::STATUS_ACTIVE)
                ->where(function ($query) use ($shift) {
                    $query->where('shift_id', $shift->id)->orWhere(function ($window) use ($shift) {
                        if (! $shift->site_id || ! $shift->starts_at || ! $shift->ends_at) {
                            $window->whereRaw('1=0');
                            return;
                        }
                        $window->where('site_id', $shift->site_id)
                            ->where('window_starts_at', $shift->starts_at->copy()->utc())
                            ->where('window_ends_at', $shift->ends_at->copy()->utc());
                    });
                })->orderBy('id')->lockForUpdate()->get();
        } elseif ($shift->user_id && (int) $shift->user_id !== $this->requestedUserId) {
            $access = app(UserSiteAccessService::class);
            $this->positions = ShiftOpenPosition::query()->tap(fn ($query) => $access->applyShiftOpenPositionIntegrityScope($query))
                ->where('shift_id', $shift->id)->orderBy('id')->lockForUpdate()->get();
            $this->replacement = ShiftReplacementRequest::query()->tap(fn ($query) => $access->applyShiftReplacementIntegrityScope($query))
                ->where('shift_id', $shift->id)->active()->latest('requested_at')->lockForUpdate()->first();
            if ($this->replacement) {
                $this->replacement->setRelation('openPosition', $this->positions->firstWhere('replacement_request_id', $this->replacement->id));
                $this->replacement->setRelation('shift', $shift);
            }
        }
    }

    public function decision(AssignmentEligibilityDecision $decision): void
    {
        if (! $this->actor || ! $decision->result) {
            return; // Real unavailable/hard-block path remains the installed error contract.
        }
        $this->review = ShiftAssignmentReview::fromResult($decision->result, $this->actor);
        if ($decision->result->hasBlocks()) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                'user_id' => $this->review['blocked_reasons'][0],
            ])->status(422);
        }
        if (! $decision->isWarning()) {
            return;
        }
        if (! ($this->override['override_acknowledged'] ?? false)) {
            throw new ShiftAssignmentRefusal('eligibility_warning');
        }
        if ($this->review['reason_required']) {
            abort_unless($this->actor->canDo('shifts.overrideEligibility'), 403);
            if (trim((string) ($this->override['override_reason'] ?? '')) === '') {
                throw new ShiftAssignmentRefusal('override_reason_required');
            }
        }
    }

    public function remember(Model $model, ?array $fields = null): void
    {
        $this->assertTransaction();
        $fields ??= $model->getFillable();
        if (! $model->exists || ! $model->getKey()) {
            throw new \LogicException('An assignment write has no persisted identity.');
        }
        $this->proofs[$model::class.':'.$model->getKey()] = [$model::class, $model->getKey(), $fields,
            ShiftAssignmentSource::values($model, $fields)];
    }

    /** Captures intended values before observers; default service paths never call this writer. */
    public function checkedUpdate(Model $model, array $values): bool
    {
        $this->assertTransaction();
        $identity = $model->getKey();
        $intent = clone $model;
        $intent->fill($values);
        // Round date values through the actual model's storage format before observers.
        $intent->setRawAttributes($intent->getAttributes());
        $fields = $model->getFillable();
        $expected = ShiftAssignmentSource::values($intent, $fields);
        if ($model->update($values) !== true || $model->getKey() !== $identity) {
            throw new \LogicException('An assignment side effect was not saved.');
        }
        $stored = $model->newQuery()->whereKey($identity)->lockForUpdate()->first();
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('An assignment side effect did not match its intent.');
        }
        // The existing current replacement reader compares these stored datetime values.
        $model->setRawAttributes($stored->getAttributes(), true);
        $this->remember($stored, $fields);

        return true;
    }

    public function createHold(array $values): CoverageReservation
    {
        $this->assertTransaction();
        $hold = new CoverageReservation($values);
        $intent = clone $hold;
        $intent->setRawAttributes($intent->getAttributes());
        $fields = $hold->getFillable();
        $expected = ShiftAssignmentSource::values($intent, $fields);
        if ($hold->save() !== true || ! $hold->exists || ! $hold->id) {
            throw new \LogicException('The assignment hold was not created.');
        }
        $stored = CoverageReservation::query()->whereKey($hold->id)->lockForUpdate()->first();
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('The created assignment hold did not match its intent.');
        }
        $hold->setRawAttributes($stored->getAttributes(), true);
        $this->remember($stored, $fields);

        return $hold;
    }

    public function timeline(array $keys, array $values): TimelineEvent
    {
        $this->assertTransaction();
        $event = TimelineEvent::query()->where($keys)->lockForUpdate()->first() ?? new TimelineEvent($keys);
        $intent = clone $event;
        $intent->fill($values);
        $intent->setRawAttributes($intent->getAttributes());
        $fields = array_values(array_unique(array_merge(array_keys($keys), array_keys($values))));
        $expected = ShiftAssignmentSource::values($intent, $fields);
        $identity = $event->getKey();
        $event->fill($values);
        if ($event->save() !== true || ! $event->id || ($identity !== null && $event->getKey() !== $identity)) {
            throw new \LogicException('Assignment history was not saved.');
        }
        $stored = TimelineEvent::query()->whereKey($event->id)->lockForUpdate()->first();
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('Assignment history did not match its intent.');
        }
        $this->remember($stored, $fields);

        return $stored;
    }

    public function recordTimeline(array $values): TimelineEvent
    {
        $this->assertTransaction();
        $intent = new TimelineEvent($values);
        $intent->setRawAttributes($intent->getAttributes());
        $fields = array_keys($values);
        $expected = ShiftAssignmentSource::values($intent, $fields);
        $event = app(\App\Services\Timeline\TimelineEmitter::class)->record($values);
        $stored = $event->id ? TimelineEvent::query()->whereKey($event->id)->lockForUpdate()->first() : null;
        if (! $stored || ShiftAssignmentSource::values($stored, $fields) !== $expected) {
            throw new \LogicException('Replacement history did not match its intent.');
        }
        $this->remember($stored, $fields);

        return $stored;
    }

    public function replacementContext(Shift $shift, User $actor, User $staff): array
    {
        return ['shift' => $shift, 'actor' => $actor, 'staff' => $staff,
            'replacement' => $this->replacement, 'positions' => $this->positions];
    }

    public function releasedHolds(): void
    {
        $this->assertTransaction();
        $ceiling = \Carbon\CarbonImmutable::now()->startOfSecond();
        foreach ($this->holds as $hold) {
            $stored = CoverageReservation::query()->whereKey($hold->id)->lockForUpdate()->first();
            $fields = array_diff($hold->getFillable(), ['status', 'expires_at']);
            if (! $stored || $stored->status !== CoverageReservationService::STATUS_RELEASED || ! $stored->expires_at
                || ! $this->releaseFloor || $stored->expires_at->lt($this->releaseFloor) || $stored->expires_at->gt($ceiling)
                || ShiftAssignmentSource::values($stored, $fields) !== ShiftAssignmentSource::values($hold, $fields)) {
                throw new \LogicException('The released assignment hold did not match its intent.');
            }
            $this->remember($stored);
        }
    }

    public function finish(Shift $shift): Shift
    {
        $this->assertTransaction();
        if (! $this->before || ! $this->actor || DB::transactionLevel() < 1) {
            throw new \LogicException('Assignment proof is incomplete.');
        }
        $stored = Shift::query()->whereKey($this->before->id)->lockForUpdate()->firstOrFail();
        $targetStatus = $this->action === 'unassign' ? 'draft' : ($this->before->status === 'draft' ? 'scheduled' : $this->before->status);
        $intent = clone $this->before;
        $intent->user_id = $this->requestedUserId;
        $intent->status = $targetStatus;
        if ((int) $shift->id !== (int) $stored->id || ShiftAssignmentSource::values($stored, $stored->getFillable())
            !== ShiftAssignmentSource::values($intent, $intent->getFillable())) {
            throw new \LogicException('The final assignment does not match this command.');
        }
        foreach ($this->holds as $hold) {
            $fresh = CoverageReservation::query()->whereKey($hold->id)->lockForUpdate()->first();
            if (! $fresh || $fresh->status !== CoverageReservationService::STATUS_RELEASED || ! $fresh->expires_at) {
                throw new \LogicException('The assignment hold was not released.');
            }
            $fields = array_diff($hold->getFillable(), ['status', 'expires_at']);
            if (ShiftAssignmentSource::values($fresh, $fields) !== ShiftAssignmentSource::values($hold, $fields)) {
                throw new \LogicException('An unrelated hold field changed.');
            }
        }
        if ($this->replacement) {
            foreach ($this->positions as $position) {
                if (in_array($position->status, ['open', 'claimed'], true)
                    && (int) $position->id !== (int) $this->replacement->openPosition?->id) {
                    $fresh = ShiftOpenPosition::query()->whereKey($position->id)->lockForUpdate()->first();
                    $intent = clone $position;
                    $intent->status = 'cancelled';
                    if (! $fresh || ShiftAssignmentSource::values($fresh, $fresh->getFillable()) !== ShiftAssignmentSource::values($intent, $intent->getFillable())) {
                        throw new \LogicException('Replacement positions did not match the cancellation intent.');
                    }
                }
            }
        }
        foreach ($this->proofs as [$class, $id, $fields, $expected]) {
            $fresh = $class::query()->whereKey($id)->lockForUpdate()->first();
            if (! $fresh || ShiftAssignmentSource::values($fresh, $fields) !== $expected) {
                throw new \LogicException('An assignment side effect changed after its proof.');
            }
        }

        return $stored;
    }
}
''')

new(NS+'ShiftAssignmentCommand.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

use App\Domain\Shifts\Lifecycle\ShiftLifecycleService;
use App\Models\Shift;
use App\Models\User;
use Illuminate\Support\Facades\DB;

final class ShiftAssignmentCommand
{
    public function __construct(private readonly ShiftLifecycleService $lifecycle) {}

    public function execute(string $action, Shift $shift, User $actor, array $data): array
    {
        $userId = $action === 'assign' ? (int) $data['user_id'] : null;
        $evidence = new ShiftAssignmentEvidence($action, $data['expected_source'], $userId, $data);
        try {
            $stored = DB::transaction(function () use ($action, $shift, $actor, $data, $evidence) {
                if ($action === 'assign') {
                    $stored = $this->lifecycle->assign($shift, $actor, User::staff()->findOrFail($data['user_id']),
                        ['override_acknowledged' => (bool) ($data['override_acknowledged'] ?? false),
                            'override_reason' => trim((string) ($data['override_reason'] ?? ''))],
                        reservationReason: 'assignment', commandEvidence: $evidence);
                } else {
                    $reason = trim((string) ($data['reason'] ?? ''));
                    $stored = $this->lifecycle->unassign($shift, $actor, $reason === '' ? null : $reason, $evidence);
                }

                return $evidence->finish($stored);
            });
            $reason = null;
        } catch (ShiftAssignmentRefusal $refusal) {
            // The only refusal sites precede all command writes. Re-authorise and prove rollback source;
            // a subsequent external change or permission loss withholds confirmation instead of guessing.
            $stored = $this->lifecycle->assignmentReadContext($shift, $actor,
                function (Shift $current, User $currentActor) use ($evidence) {
                    if (! $evidence->before || ! $evidence->actor || (int) $currentActor->id !== (int) $evidence->actor->id
                        || ShiftAssignmentSource::describe($current) !== ShiftAssignmentSource::describe($evidence->before)) {
                        throw new \LogicException('The original assignment source could not be confirmed.');
                    }

                    return $current;
                });
            $reason = $refusal->reason;
        }

        return ['version' => 1, 'scope' => 'single', 'action' => $action, 'request_id' => $data['request_id'],
            'actor_id' => (int) $evidence->actor->id, 'shift_id' => (int) $stored->id, 'requested_user_id' => $userId,
            'expected_source' => $data['expected_source'], 'outcome' => $reason === null ? 'saved' : 'not_saved',
            'changed' => $reason === null && (($evidence->before->user_id === null ? null : (int) $evidence->before->user_id) !== ($stored->user_id === null ? null : (int) $stored->user_id) || $evidence->before->status !== $stored->status),
            'source' => ShiftAssignmentSource::describe($stored), 'user_id' => $stored->user_id === null ? null : (int) $stored->user_id,
            'status' => $stored->status, 'reason' => $reason, 'review' => $evidence->review];
    }
}
''')

new(NS+'ShiftAssignmentReceipt.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\Shift;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

/** Correlation only. No durable replay or generic success inference. */
final class ShiftAssignmentReceipt
{
    private mixed $connection = null;
    private mixed $pdo = null;
    private bool $root = false;

    public function begin(Request $request): void
    {
        $request->session()->forget('shift_assignment_result');
        try {
            $this->connection = DB::connection();
            $this->pdo = $this->connection->getPdo();
            $this->root = $this->connection->transactionLevel() === 0 && ! $this->pdo->inTransaction();
        } catch (Throwable) {
            $this->root = false;
        }
    }

    public function present(Request $request, array $result): void
    {
        try {
            if (! $this->root || DB::connection() !== $this->connection || $this->connection->getPdo() !== $this->pdo
                || $this->connection->transactionLevel() !== 0 || $this->pdo->inTransaction()) {
                return;
            }
            $row = Shift::query()->whereKey($result['shift_id'])->first();
            if (! $row || ShiftAssignmentSource::describe($row) !== $result['source']) {
                return;
            }
            $request->session()->flash('shift_assignment_result', $result);
        } catch (Throwable) {
            $request->session()->forget('shift_assignment_result');
        }
    }

    public static function forRequester(Request $request): ?array
    {
        $result = $request->session()->get('shift_assignment_result');
        if (! is_array($result) || ($result['version'] ?? null) !== 1 || ($result['scope'] ?? null) !== 'single'
            || ($result['actor_id'] ?? null) !== $request->user()?->id || ! in_array($result['action'] ?? null, ['assign', 'unassign'], true)
            || ! in_array($result['outcome'] ?? null, ['saved', 'not_saved'], true)
            || ! is_string($result['request_id'] ?? null) || ! \Illuminate\Support\Str::isUuid($result['request_id'])) {
            return null;
        }

        return $result;
    }
}
''')

new(NS+'ShiftAssignmentReturn.php', r'''<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\User;
use Carbon\CarbonImmutable;

/** Navigation filters never grant access. Destination handlers still re-authorise their records. */
final class ShiftAssignmentReturn
{
    public static function location(mixed $input, int $shiftId, User $actor): string
    {
        $fallback = route('operations.rostering.index', [], false);
        if (! is_string($input) || strlen($input) > 2048 || preg_match('/[\\\\\x00-\x20\x7f]/', $input)
            || preg_match('/[\\\\\x00-\x20\x7f]/', rawurldecode($input))) {
            return $fallback;
        }
        $parts = parse_url($input);
        if ($parts === false || array_diff(array_keys($parts), ['path', 'query']) !== [] || ! str_starts_with($input, '/')) {
            return $fallback;
        }
        $path = $parts['path'] ?? '';
        if (! in_array($path, ['/operations/rostering', '/operations/rostering/conflicts', '/operations/shifts/'.$shiftId], true)) {
            return $fallback;
        }
        $values = [];
        $siteValues = [];
        $siteStyle = null;
        $seen = [];
        foreach (($parts['query'] ?? '') === '' ? [] : explode('&', $parts['query']) as $pair) {
            $pieces = explode('=', $pair, 2);
            if (count($pieces) !== 2) {
                return $fallback;
            }
            [$key, $value] = array_map('urldecode', $pieces);
            if (preg_match('/[\\\\\x00-\x1f\x7f]/', $key.$value)) {
                return $fallback;
            }
            if ($path === '/operations/rostering' && preg_match('/\Asite_id(?:\[(\d*)\])?\z/', $key, $match)) {
                $style = str_contains($key, '[') ? 'array' : 'scalar';
                if (($siteStyle !== null && $style !== $siteStyle) || ($key !== 'site_id[]' && isset($seen[$key]))
                    || (isset($match[1]) && $match[1] !== '' && (string) (int) $match[1] !== $match[1])
                    || ! preg_match('/\A[1-9]\d{0,9}\z/', $value) || count($siteValues) >= 50) {
                    return $fallback;
                }
                $seen[$key] = true;
                $siteStyle = $style;
                $siteValues[] = (int) $value;
                continue;
            }
            if (isset($seen[$key])) {
                return $fallback;
            }
            $seen[$key] = true;
            if ($key === 'week' && $path !== '/operations/shifts/'.$shiftId) {
                try {
                    $date = CarbonImmutable::createFromFormat('!Y-m-d', $value, (string) (config('app.worker_timezone') ?: config('app.timezone') ?: 'UTC'));
                    if (! $date || $date->format('Y-m-d') !== $value || ! $date->isMonday()) {
                        return $fallback;
                    }
                } catch (\Throwable) {
                    return $fallback;
                }
            } elseif ($key === 'tab') {
                $tabs = $path === '/operations/rostering'
                    ? ['shifts', 'calendar', 'open', 'coverage', 'timeoff', 'availability', 'capacity', 'analytics', 'templates', 'recurring']
                    : ['tasks', 'medications', 'coverage', 'assignment', 'transport', 'replacement', 'observations', 'forms', 'notes', 'audit', 'incidents'];
                if ($path === '/operations/rostering/conflicts' || ! in_array($value, $tabs, true)) {
                    return $fallback;
                }
            } elseif ($path === '/operations/rostering' && in_array($key, ['staff_id', 'client_id'], true) && preg_match('/\A[1-9]\d{0,9}\z/', $value)) {
                $value = (int) $value;
            } elseif ($path === '/operations/shifts/'.$shiftId && $key === 'return_to') {
                // One level only, matching the existing Show Conflict Queue contract.
                $target = self::location($value, $shiftId, $actor);
                if (! str_starts_with($target, '/operations/rostering/conflicts') || str_contains($target, 'return_to')) {
                    return $fallback;
                }
                $value = $target;
            } else {
                return $fallback;
            }
            $values[$key] = $value;
        }
        if ($path === '/operations/rostering/conflicts' && ! $actor->canDo('rostering.viewAny')) {
            return $fallback;
        }
        if ($siteValues !== []) {
            $values['site_id'] = $siteStyle === 'scalar' ? $siteValues[0] : array_values(array_unique($siteValues));
        }

        return $path.($values === [] ? '' : '?'.http_build_query($values, '', '&', PHP_QUERY_RFC3986));
    }
}
''')

# Existing methods: all replacements are guarded by exact byte substrings.
path='app/Domain/Shifts/Lifecycle/ShiftLifecycleService.php'
b=existing(path)
b=swap(b,'use App\\Domain\\Shifts\\Lifecycle\\Data\\CompleteShiftData;', 'use App\\Domain\\Shifts\\Assignment\\ShiftAssignmentEvidence;\nuse App\\Domain\\Shifts\\Lifecycle\\Data\\CompleteShiftData;')
b=swap(b,'        ?PreparedShiftWorkload $workload = null,\n    ): Shift {\n        $source =', '        ?PreparedShiftWorkload $workload = null,\n        ?ShiftAssignmentEvidence $commandEvidence = null,\n    ): Shift {\n        $source =')
b=swap(b,'            &$originalUserId,\n        ) {','            &$originalUserId,\n            $commandEvidence,\n        ) {')
b=swap(b,'            $originalUserId = $locked->user_id ? (int) $locked->user_id : null;','            $originalUserId = $locked->user_id ? (int) $locked->user_id : null;\n            $commandEvidence?->current($locked, $actor);')
b=swap(b,'            $eligibilityDecision ??= $this->assignmentEligibility->decide($locked, $assignee, $workload);','            $eligibilityDecision ??= $this->assignmentEligibility->decide($locked, $assignee, $workload);\n            $commandEvidence?->decision($eligibilityDecision);')
b=swap(b,"                    throw ValidationException::withMessages(['user_id' => 'The assignment warning acknowledgement could not be saved. No assignment changes were applied.']);\n                }", "                    throw ValidationException::withMessages(['user_id' => 'The assignment warning acknowledgement could not be saved. No assignment changes were applied.']);\n                }\n                $commandEvidence?->remember($storedOverride);")
b=swap(b,"                    throw ValidationException::withMessages(['coverage_reservation_token' => 'The coverage hold could not be fulfilled. No assignment changes were applied.']);\n                }", "                    throw ValidationException::withMessages(['coverage_reservation_token' => 'The coverage hold could not be fulfilled. No assignment changes were applied.']);\n                }\n                $commandEvidence?->remember($storedReservation);")
b=swap(b,'                $originalUserId ? (int) $originalUserId : null,\n            );','                $originalUserId ? (int) $originalUserId : null,\n                checkedWriter: $commandEvidence ? $commandEvidence->timeline(...) : null,\n            );')
b=swap(b,'                $eligibilityDecision,\n            );\n        }\n\n        return $assigned->fresh()', '                $eligibilityDecision,\n                $commandEvidence?->replacementContext($assigned, $actor, $assignee),\n                $commandEvidence ? $commandEvidence->checkedUpdate(...) : null,\n                $commandEvidence ? $commandEvidence->recordTimeline(...) : null,\n            );\n        }\n\n        return $assigned->fresh()')
b=swap(b,'    public function unassign(Shift $shift, User $actor, ?string $reason = null): Shift', '    public function unassign(Shift $shift, User $actor, ?string $reason = null, ?ShiftAssignmentEvidence $commandEvidence = null): Shift')
b=swap(b,'        $unassigned = DB::transaction(function () use ($shift, &$actor, &$previousStaff) {','        $unassigned = DB::transaction(function () use ($shift, &$actor, &$previousStaff, $commandEvidence) {')
old="""            [$actor] = $this->lockCurrentShiftAuthority(
                $locked,
                $actor,
                ['shifts.manageAny'],
            );

            if (in_array($locked->status, ['completed', 'cancelled'], true)) {"""
b=swap(b,old,old.replace("\n\n            if", "\n            $commandEvidence?->current($locked, $actor);\n\n            if"))
b=swap(b,'                $this->coverageReservationService->fulfill($reservation, $locked);',
    '                $this->coverageReservationService->fulfill($reservation, $locked,\n                    checkedUpdate: $commandEvidence ? $commandEvidence->checkedUpdate(...) : null);')
b=swap(b,"                    $reservationReason,\n                );", "                    $reservationReason,\n                    checkedCreate: $commandEvidence ? $commandEvidence->createHold(...) : null,\n                );")
b=swap(b,'                $commandEvidence?->remember($storedReservation);',
    '                // Modern fulfillment proof is captured before observers; do not replace it with a later stored baseline.')
b=swap(b,'            $this->coverageReservationService->releaseForShift($locked);', '            $this->coverageReservationService->releaseForShift($locked);\n            $commandEvidence?->releasedHolds();')
b=swap(b,"""            $locked->update([
                'user_id' => null,
                'status' => 'draft',
            ]);""", """            if ($commandEvidence) {
                $commandEvidence->checkedUpdate($locked, ['user_id' => null, 'status' => 'draft']);
            } else {
                $locked->update(['user_id' => null, 'status' => 'draft']);
            }""")
b=swap(b,'            $reason,\n        );\n\n        return $unassigned->fresh()', '            $reason,\n            checkedWriter: $commandEvidence ? $commandEvidence->timeline(...) : null,\n        );\n\n        return $unassigned->fresh()')
marker='    public function unassign('
pos=b.index(marker.encode())
method=r'''    /** Same manual command authority prefix for advisory candidate/source reads and rollback readback. */
    public function assignmentReadContext(Shift $shift, User $actor, \Closure $read): mixed
    {
        return DB::transaction(function () use ($shift, $actor, $read) {
            $this->lockApplicationShiftMutex();
            $locked = $this->lockCanonicalLifecycleShift($shift);
            [$currentActor] = $this->lockCurrentShiftAuthority($locked, $actor, ['shifts.manageAny']);

            return $read($locked, $currentActor);
        });
    }

'''
b=b[:pos]+method.encode()+b[pos:]; save(OUT/path,b)

path='app/Services/ShiftTimelineService.php'
b=existing(path)
for name,nextname in [('recordAssigned','recordUnassigned'),('recordUnassigned','recordCancelled')]:
    start=b.index(('    public function '+name+'(').encode()); end=b.index(('    public function '+nextname+'(').encode(),start)
    method=b[start:end]
    method=swap(method,'        ?CarbonInterface $occurredAt = null\n', '        ?CarbonInterface $occurredAt = null,\n        ?\\Closure $checkedWriter = null\n')
    method=swap(method,'        return TimelineEvent::query()->updateOrCreate(\n', '        $write = $checkedWriter ?? static fn (array $keys, array $values) => TimelineEvent::query()->updateOrCreate($keys, $values);\n\n        return $write(\n')
    b=b[:start]+method+b[end:]
save(OUT/path,b)

# Only modern command evidence opts into this literal pre-observer fulfillment writer.
path='app/Services/CoverageReservationService.php'
b=existing(path)
start=b.index(b'    public function fulfill(');end=b.index(b'    public function release(',start)
m=b[start:end]
m=swap(m,'?ShiftOpenPosition $position = null): void',r'?ShiftOpenPosition $position = null, ?\Closure $checkedUpdate = null): void')
m=swap(m,'        $reservation->update([','        $write = $checkedUpdate ?? static fn (CoverageReservation $model, array $values) => $model->update($values);\n        $write($reservation, [')
b=b[:start]+m+b[end:];save(OUT/path,b)
start=b.index(b'    public function reserveForAssignment(');end=b.index(b'    public function reserveForCoveragePayload(',start)
m=b[start:end]
m=swap(m,"string $reason = 'assignment'): ?CoverageReservation",r"string $reason = 'assignment', ?\Closure $checkedCreate = null): ?CoverageReservation")
m=swap(m,'use ($shift, $actor, $reason)','use ($shift, $actor, $reason, $checkedCreate)')
m=swap(m,'            return CoverageReservation::create([','            $create = $checkedCreate ?? static fn (array $values) => CoverageReservation::create($values);\n\n            return $create([')
b=b[:start]+m+b[end:];save(OUT/path,b)

path='app/Services/ShiftReplacementService.php'
b=existing(path)
start=b.index(b'    public function resolveFromManualAssignment('); end=b.index(b'    public function activeForShift(',start)
m=b[start:end]
m=swap(m,'        ?array $currentEvidence = null,\n', '        ?array $currentEvidence = null,\n        ?\\Closure $checkedUpdate = null,\n        ?\\Closure $checkedTimeline = null,\n')
m=swap(m,'        $saved = $replacement->update([','        $replacementValues = [')
m=swap(m,"            'approved_at' => now(),\n        ]);", "            'approved_at' => now(),\n        ];\n        $saved = $checkedUpdate ? $checkedUpdate($replacement, $replacementValues) : $replacement->update($replacementValues);")
m=swap(m,'            $positionSaved = $replacement->openPosition->update([','            $positionValues = [')
m=swap(m,"                'status' => 'filled',\n            ]);", "                'status' => 'filled',\n            ];\n            $positionSaved = $checkedUpdate ? $checkedUpdate($replacement->openPosition, $positionValues) : $replacement->openPosition->update($positionValues);")
m=swap(m,"                : 'The replacement request was resolved by manual assignment.'\n        );", "                : 'The replacement request was resolved by manual assignment.',\n            $checkedTimeline,\n        );")
b=b[:start]+m+b[end:]
# The private replacement emitter is opt-in only; its original payload stays exact.
start=b.index(b'    protected function logTimelineEvent(')
m=b[start:]
nl='\r\n' if b'\r\n' in m else '\n'
old='        ?string $body = null'+nl
m=swap(m,old,'        ?string $body = null,'+nl+'        ?\\Closure $checkedRecord = null'+nl)
m=swap(m,'        app(TimelineEmitter::class)->record([','        $write = $checkedRecord ?? static fn (array $values) => app(TimelineEmitter::class)->record($values);'+nl+nl+'        $write([')
b=b[:start]+m; save(OUT/path,b)

path='app/Http/Controllers/ShiftController.php'
b=existing(path)
imports=''.join('use App\\Domain\\Shifts\\Assignment\\'+x+';\n' for x in ['ShiftAssignmentCommand','ShiftAssignmentReceipt','ShiftAssignmentReturn','ShiftAssignmentReview','ShiftAssignmentSource'])
b=swap(b,'use App\\Domain\\Shifts\\Lifecycle\\Data\\CompleteShiftData;',imports+'use App\\Domain\\Shifts\\Lifecycle\\Data\\CompleteShiftData;')
start=b.index(b'    public function candidates('); end=b.index(b'    public function assign(',start)
newcandidate=r'''    public function candidates(Request $request, Shift $shift)
    {
        $auth = $request->user();
        abort_unless($auth && $auth->canDo('shifts.manageAny'), 403);
        $this->assertCanAccessShift($auth, $shift);

        return app(ShiftLifecycleService::class)->assignmentReadContext($shift, $auth, function (Shift $current, User $actor) {
            $display = ShiftAssignmentSource::display($current);
            $source = ShiftAssignmentSource::describe($current);
            $locked = in_array($current->status, ['completed', 'cancelled'], true);
            $reviews = [];
            $candidates = $locked ? [] : app(ShiftAssignmentRecommendationService::class)->forShift(
                $current, $actor, 100, $this->shiftStaffBypassPermissions(),
                eligibilityResolver: function (User $worker, \Closure $evaluate) use (&$reviews, $actor) {
                    try {
                        $result = $evaluate();
                        $reviews[(int) $worker->id] = ShiftAssignmentReview::fromResult($result, $actor);

                        return $result;
                    } catch (Throwable) {
                        $reviews[(int) $worker->id] = ShiftAssignmentReview::unknown();

                        return \App\Services\Eligibility\EligibilityResult::fromChecks([
                            ['rule' => 'assignment_unknown', 'passed' => false, 'severity' => 'block', 'overrideable' => false,
                                'message' => 'Eligibility could not be assessed. Review before assigning.'],
                        ]);
                    }
                },
            );
            foreach ($candidates as &$candidate) {
                $review = $reviews[(int) $candidate['id']] ?? ShiftAssignmentReview::unknown();
                $candidate = array_replace($candidate, $review);
                $candidate['is_eligible'] = $review['assessment_status'] === 'assessed' && $review['blocked_reasons'] === [];
            }
            unset($candidate);

            return response()->json(['candidates' => $candidates, 'current_user_id' => $current->user_id, 'locked' => $locked,
                'actor_id' => (int) $actor->id, 'shift_source' => $source, 'shift_display' => $display]);
        });
    }

'''
b=b[:start]+newcandidate.encode()+b[end:]
for name,nextname,action in [('assign','autoFill','assign'),('unassign','', 'unassign')]:
    start=b.index(('    public function '+name+'(').encode())
    needle=b'        $this->assertCanAccessShift($auth, $shift);'
    pos=b.index(needle,start)+len(needle)
    addition="\n\n        if ($request->header('X-Shift-Assignment-Result') === 'committed-v1') {\n            return $this->assignmentCommand($request, $shift, $auth, '"+action+"');\n        }"
    b=b[:pos]+addition.encode()+b[pos:]
marker=b'    public function autoFill('
pos=b.index(marker)
handler=r'''    /** Modern single assignment transport; the legacy handlers remain below their opt-in branch. */
    private function assignmentCommand(Request $request, Shift $shift, User $actor, string $action)
    {
        $receipt = new ShiftAssignmentReceipt;
        $receipt->begin($request);
        $rules = ['request_id' => ['required', 'uuid'], 'expected_source' => ['required', 'array:shift_id,revision'],
            'expected_source.shift_id' => ['required', 'integer', Rule::in([(int) $shift->id])],
            'expected_source.revision' => ['required', 'string', 'regex:/\A[a-f0-9]{64}\z/'], 'return_to' => ['nullable', 'string', 'max:2048']];
        if ($action === 'assign') {
            $rules += ['user_id' => ['required', 'integer', 'exists:users,id'], 'override_acknowledged' => ['nullable', 'boolean'],
                'override_reason' => ['nullable', 'string', 'max:2000'], 'coverage_reservation_token' => ['nullable', 'string', 'max:120']];
        } else {
            $rules['reason'] = ['nullable', 'string', 'max:2000'];
        }
        $data = $request->validate($rules);
        $data['expected_source']['shift_id'] = (int) $data['expected_source']['shift_id'];
        if ($action === 'assign') {
            $this->assertCanAssignShiftToUser($actor, (int) $data['user_id']);
        }
        $result = app(ShiftAssignmentCommand::class)->execute($action, $shift, $actor, $data);
        $receipt->present($request, $result);
        $response = redirect(ShiftAssignmentReturn::location($data['return_to'] ?? null, (int) $shift->id, $actor));
        if ($result['outcome'] === 'saved') {
            return $response->with('success', $action === 'assign' ? 'Shift assigned.' : 'Shift unassigned.');
        }

        return $response->withInput()->with('warning', 'No assignment changes were applied. Review the current shift before continuing.');
    }

'''
b=b[:pos]+handler.encode()+b[pos:]; save(OUT/path,b)

path='app/Http/Middleware/HandleInertiaRequests.php'
b=existing(path)
b=swap(b,"                'shift_note_result' => function () use ($request) {", "                'shift_assignment_result' => fn () => \\App\\Domain\\Shifts\\Assignment\\ShiftAssignmentReceipt::forRequester($request),\n                'shift_note_result' => function () use ($request) {")
save(OUT/path,b)

print('Authored inactive source files only; no PHP or application invocation.')
