R3 is source-clear for the bounded hold-intent correction. The original R2 HOLD is preserved unchanged.

The modern checked create captures the literal full hold intent before observers, verifies the saved row with the model’s storage precision, then records it. Checked fulfillment captures its literal update and all unchanged fillables before observers. The lifecycle no longer replaces that proof with a later refreshed row. The final suffix rechecks the intended fulfilled tuple, so creation, fulfillment and late history alterations cannot become the accepted baseline.

The two callback parameters are optional on the existing reservation service. Their null fallbacks keep the installed model calls and literal values. The policy for token, TTL, capacity/window, roles and approved Sites is unchanged. Ordinary caller and unowned method bodies remain preserved.

The seven new cases use the actual automatic minimum-two reservation path: one physical positive, create veto/field alteration, fulfillment veto/field alteration/expiry alteration, and late history mutation. Fault boundaries retain full related-store and whole-queue comparisons plus absent typed receipt; the positive checks the independent persisted hold tuple and physical root exit.

Independent pure comparisons verified all14 full forward/inverse sections, all4 R2 delta sections,10 unchanged R2 paths,128 unowned methods,44 prior test/provider/helper bodies,42 current dependency pins with no drift,30 R2 records and29 original draft records. The wire contract remains f904d838… . Every exact source/proof hash is recorded in the accompanying JSON.

The53 cases (21 methods,11 providers) remain source-derived, not a framework inventory or acceptance result. No product application, parser, test, framework, native, database, build or browser work was performed. Historical acceptance is retained separately.
