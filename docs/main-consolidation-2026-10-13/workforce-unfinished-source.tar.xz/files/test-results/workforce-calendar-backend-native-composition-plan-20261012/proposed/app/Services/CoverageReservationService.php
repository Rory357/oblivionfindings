<?php

namespace App\Services;

use App\Events\CoverageSupplyAdded;
use App\Models\Client;
use App\Models\CoverageReservation;
use App\Models\Shift;
use App\Models\ShiftOpenPosition;
use App\Models\SiteCoverageRequirement;
use App\Models\User;
use App\Services\Operations\WorkforceMutationGuard;
use Carbon\CarbonInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class CoverageReservationService
{
    public const STATUS_ACTIVE = 'active';
    public const STATUS_RELEASED = 'released';
    public const STATUS_FULFILLED = 'fulfilled';
    public const STATUS_EXPIRED = 'expired';

    public function __construct(
        protected ShiftCoverageService $coverage,
        protected UserSiteAccessService $siteAccess,
    ) {
    }

    public function createQuickFillReservation(
        User $actor,
        int $siteId,
        CarbonInterface $windowStartsAt,
        CarbonInterface $windowEndsAt,
        ?int $coverageRequirementId = null,
        ?string $roleKey = null,
        array $meta = [],
        int $ttlMinutes = 10,
    ): CoverageReservation {
        $windowStartsAt = $this->utcInstant($windowStartsAt);
        $windowEndsAt = $this->utcInstant($windowEndsAt);
        $this->assertActorCanReserveAtSite($actor, $siteId, $coverageRequirementId);

        return $this->currentReservationMutation(function (CurrentAuthorizationReads $reads) use ($actor, $siteId, $windowStartsAt, $windowEndsAt, $coverageRequirementId, $roleKey, $meta, $ttlMinutes) {
            $this->assertActorCanReserveAtSite($actor, $siteId, $coverageRequirementId, $reads);
            $this->expireStaleReservations();
            if ($coverageRequirementId) {
                SiteCoverageRequirement::query()->lockForUpdate()->find($coverageRequirementId);
            }
            $window = $this->findCoverageWindow($siteId, $windowStartsAt, $windowEndsAt, $coverageRequirementId, current: true);
            if (! $window) {
                throw ValidationException::withMessages([
                    'coverage' => 'That coverage gap is no longer active.',
                ]);
            }

            $active = $reads->query(CoverageReservation::query()
                ->where('status', self::STATUS_ACTIVE)
                ->where('site_id', $siteId)
                ->when(
                    $coverageRequirementId,
                    fn ($query) => $query->where('coverage_requirement_id', $coverageRequirementId),
                    fn ($query) => $query->whereNull('coverage_requirement_id'),
                )
                ->where('window_starts_at', $windowStartsAt)
                ->where('window_ends_at', $windowEndsAt)
                ->where('reserved_by_user_id', $actor->id)
                ->where('reason', 'quick_fill')
                ->when($roleKey, fn ($query) => $query->where('role_key', $roleKey), fn ($query) => $query->whereNull('role_key'))
                ->orderBy('id'))->first();

            if ($active) {
                $active->update([
                    'expires_at' => now()->addMinutes($ttlMinutes),
                    'role_key' => $roleKey,
                    'meta' => array_merge($active->meta ?? [], $meta, [
                        'slot_key' => $this->nextAvailableSlotKey($window, $roleKey),
                    ]),
                ]);

                return $reads->query(CoverageReservation::query()->whereKey($active->id))->firstOrFail();
            }

            $remainingSlots = $this->availableSlotsForWindow($window, $roleKey, $reads);
            if ($remainingSlots <= 0) {
                throw ValidationException::withMessages([
                    'coverage' => 'Another scheduler has already reserved the remaining coverage for this window.',
                ]);
            }

            return CoverageReservation::create([
                'site_id' => $siteId,
                'coverage_requirement_id' => $coverageRequirementId,
                'reserved_by_user_id' => $actor->id,
                'reservation_token' => (string) Str::uuid(),
                'status' => self::STATUS_ACTIVE,
                'reason' => 'quick_fill',
                'role_key' => $roleKey,
                'window_starts_at' => $windowStartsAt,
                'window_ends_at' => $windowEndsAt,
                'expires_at' => now()->addMinutes($ttlMinutes),
                'meta' => array_merge($meta, [
                    'slot_key' => $this->nextAvailableSlotKey($window, $roleKey),
                ]),
            ]);
        });
    }

    public function validateToken(?string $token, User $actor, array $context = []): ?CoverageReservation
    {
        if (! $token) {
            return null;
        }

        $this->expireStaleReservations();

        $reservation = CoverageReservation::query()
            ->where('reservation_token', $token)
            ->where('status', self::STATUS_ACTIVE)
            ->where('reserved_by_user_id', $actor->id)
            ->first();

        if (! $reservation || ! $reservation->expires_at || $reservation->expires_at->lte(now())) {
            throw ValidationException::withMessages([
                'coverage_reservation_token' => 'This coverage hold has expired. Re-open the gap and try again.',
            ]);
        }

        $this->siteAccess->assertCanAccessSiteId(
            $actor,
            (int) $reservation->site_id,
            ['reports.viewAny'],
        );

        foreach ($context as $key => $expected) {
            if ($expected === null || $expected === '') {
                continue;
            }

            if (in_array($key, ['site_id', 'coverage_requirement_id'], true) && (int) $reservation->{$key} !== (int) $expected) {
                throw ValidationException::withMessages([
                    'coverage_reservation_token' => 'This coverage hold no longer matches the selected shortage window.',
                ]);
            }

            if ($key === 'window_starts_at' && ! $reservation->window_starts_at?->equalTo($this->utcInstant($expected))) {
                throw ValidationException::withMessages([
                    'coverage_reservation_token' => 'This coverage hold was created for a different start time.',
                ]);
            }

            if ($key === 'window_ends_at' && ! $reservation->window_ends_at?->equalTo($this->utcInstant($expected))) {
                throw ValidationException::withMessages([
                    'coverage_reservation_token' => 'This coverage hold was created for a different end time.',
                ]);
            }
        }

        return $reservation;
    }

    public function fulfill(?CoverageReservation $reservation, ?Shift $shift = null, ?ShiftOpenPosition $position = null, ?\Closure $checkedWrite = null): void
    {
        if (! $reservation) {
            return;
        }

        $write = $checkedWrite ?? static fn (CoverageReservation $row, array $values) => $row->update($values);
        $write($reservation, [
            'status' => self::STATUS_FULFILLED,
            'shift_id' => $shift?->id ?? $reservation->shift_id,
            'shift_open_position_id' => $position?->id ?? $reservation->shift_open_position_id,
            'expires_at' => now(),
        ]);

        $reservation->refresh();

        if ($reservation->site_id && $reservation->window_starts_at && $reservation->window_ends_at) {
            $coverageWindowKey = app(ShiftSignalService::class)->buildCoverageWindowKey([
                'site_id' => $reservation->site_id,
                'rule_id' => $reservation->coverage_requirement_id,
                'starts_at' => $reservation->window_starts_at->toIso8601String(),
                'ends_at' => $reservation->window_ends_at->toIso8601String(),
            ]);

            event(new CoverageSupplyAdded(
                $coverageWindowKey,
                (int) $reservation->site_id,
                $reservation->coverage_requirement_id ? (int) $reservation->coverage_requirement_id : null,
                $reservation->window_starts_at->toIso8601String(),
                $reservation->window_ends_at->toIso8601String(),
                $shift?->id ?? $reservation->shift_id,
                $shift?->shift_series_id,
                $reservation->reserved_by_user_id ? (int) $reservation->reserved_by_user_id : null,
                $reservation->reason,
            ));
        }
    }

    public function release(?CoverageReservation $reservation): void
    {
        if (! $reservation || $reservation->status !== self::STATUS_ACTIVE) {
            return;
        }

        $reservation->update([
            'status' => self::STATUS_RELEASED,
            'expires_at' => now(),
        ]);
    }

    public function releaseForShift(Shift $shift): void
    {
        CoverageReservation::query()
            ->where('status', self::STATUS_ACTIVE)
            ->where(function ($query) use ($shift) {
                $query->where('shift_id', $shift->id)
                    ->orWhere(function ($windowQuery) use ($shift) {
                        if (! $shift->site_id || ! $shift->starts_at || ! $shift->ends_at) {
                            $windowQuery->whereRaw('1 = 0');

                            return;
                        }

                        $windowQuery->where('site_id', $shift->site_id)
                            ->where('window_starts_at', $this->utcInstant($shift->starts_at))
                            ->where('window_ends_at', $this->utcInstant($shift->ends_at));
                    });
            })
            ->update([
                'status' => self::STATUS_RELEASED,
                'expires_at' => now(),
            ]);
    }

    public function reserveForAssignment(Shift $shift, User $actor, string $reason = 'assignment'): ?CoverageReservation
    {
        return $this->currentReservationMutation(function (CurrentAuthorizationReads $reads) use ($shift, $actor, $reason): ?CoverageReservation {
            $shift = Shift::query()->lockForUpdate()->findOrFail($shift->id);
            $shift->setRelation('client', $reads->query(Client::query()->whereKey($shift->client_id))->first());
            $coverage = $this->coverage->coverageStatusForShift($shift, current: true);
            if (! $coverage || ($coverage['unfilled_after_open_shifts'] ?? 0) <= 0) {
                return null;
            }

            $siteId = $this->siteAccess->shiftSiteId($shift);
            abort_unless(
                $siteId !== null && $siteId === (int) $coverage['site_id'],
                403,
                UserSiteAccessService::DEFAULT_MESSAGE,
            );
            $this->assertActorCanReserveAtSite(
                $actor,
                $siteId,
                ! empty($coverage['rule_id']) ? (int) $coverage['rule_id'] : null,
                $reads,
            );
            $this->expireStaleReservations();

            $remaining = $this->availableSlotsForWindow($coverage, null, $reads);
            if ($remaining <= 0) {
                throw ValidationException::withMessages([
                    'coverage' => 'Another scheduler has already filled this coverage window.',
                ]);
            }

            return CoverageReservation::create([
                'site_id' => $coverage['site_id'],
                'coverage_requirement_id' => $coverage['rule_id'] ?? null,
                'shift_id' => $shift->id,
                'reserved_by_user_id' => $actor->id,
                'reservation_token' => (string) Str::uuid(),
                'status' => self::STATUS_ACTIVE,
                'reason' => $reason,
                'window_starts_at' => $this->utcInstant($coverage['starts_at']),
                'window_ends_at' => $this->utcInstant($coverage['ends_at']),
                'expires_at' => now()->addMinutes(5),
                'meta' => [
                    'shift_id' => $shift->id,
                    'slot_key' => $this->nextAvailableSlotKey($coverage, null),
                ],
            ]);
        });
    }

    public function reserveForCoveragePayload(User $actor, array $payload, string $reason = 'planning_fill', ?\Closure $checkedWrite = null): ?CoverageReservation
    {
        $siteId = isset($payload['site_id']) ? (int) $payload['site_id'] : null;
        $startsAt = $payload['starts_at'] ?? null;
        $endsAt = $payload['ends_at'] ?? null;

        if (! $siteId || ! $startsAt || ! $endsAt) {
            return null;
        }

        $windowStartsAt = $this->utcInstant($startsAt);
        $windowEndsAt = $this->utcInstant($endsAt);
        $coverageRequirementId = ! empty($payload['coverage_rule_id']) ? (int) $payload['coverage_rule_id'] : null;
        $this->assertActorCanReserveAtSite($actor, $siteId, $coverageRequirementId);
        $roleKey = ! empty($payload['role_key'])
            ? trim((string) $payload['role_key'])
            : collect($payload['coverage_roles'] ?? [])
                ->map(fn ($role) => is_string($role) ? trim($role) : null)
                ->first(fn (?string $role) => $role !== null && $role !== '');

        return $this->currentReservationMutation(function (CurrentAuthorizationReads $reads) use ($actor, $siteId, $windowStartsAt, $windowEndsAt, $coverageRequirementId, $roleKey, $reason, $checkedWrite) {
            $this->assertActorCanReserveAtSite($actor, $siteId, $coverageRequirementId, $reads);
            $this->expireStaleReservations();
            if ($coverageRequirementId) {
                SiteCoverageRequirement::query()->lockForUpdate()->find($coverageRequirementId);
            }

            $window = $this->findCoverageWindow($siteId, $windowStartsAt, $windowEndsAt, $coverageRequirementId, current: true);
            if (! $window) {
                return null;
            }

            $roleShortagePool = ($window['planned_role_shortages'] ?? []) !== []
                ? ($window['planned_role_shortages'] ?? [])
                : ($window['role_shortages'] ?? []);
            $hasRoleGap = $roleKey
                ? collect($roleShortagePool)->contains(fn (array $role) => ($role['key'] ?? null) === $roleKey && (int) ($role['missing'] ?? 0) > 0)
                : false;
            $hasHeadcountGap = (int) ($window['unfilled_after_open_shifts'] ?? $window['missing_staff'] ?? 0) > 0;

            if (! $hasHeadcountGap && ! $hasRoleGap) {
                return null;
            }

            $reservationRoleKey = $hasRoleGap ? $roleKey : null;
            $active = $reads->query(CoverageReservation::query()
                ->where('status', self::STATUS_ACTIVE)
                ->where('site_id', $siteId)
                ->when(
                    $coverageRequirementId,
                    fn ($query) => $query->where('coverage_requirement_id', $coverageRequirementId),
                    fn ($query) => $query->whereNull('coverage_requirement_id'),
                )
                ->where('window_starts_at', $windowStartsAt)
                ->where('window_ends_at', $windowEndsAt)
                ->where('reserved_by_user_id', $actor->id)
                ->where('reason', $reason)
                ->when($reservationRoleKey, fn ($query) => $query->where('role_key', $reservationRoleKey), fn ($query) => $query->whereNull('role_key'))
                ->orderBy('id'))->first();

            if ($active) {
                $write = $checkedWrite ?? static fn (CoverageReservation $row, array $values) => $row->update($values);
                $write($active, [
                    'expires_at' => now()->addMinutes(5),
                    'meta' => array_merge($active->meta ?? [], [
                        'source' => $reason,
                        'slot_key' => $this->nextAvailableSlotKey($window, $reservationRoleKey),
                    ]),
                ]);

                return $reads->query(CoverageReservation::query()->whereKey($active->id))->firstOrFail();
            }

            $remainingSlots = $this->availableSlotsForWindow($window, $reservationRoleKey, $reads);
            if ($remainingSlots <= 0) {
                throw ValidationException::withMessages([
                    'coverage' => 'Another scheduler has already filled or reserved this coverage window.',
                ]);
            }

            $values = [
                'site_id' => $siteId,
                'coverage_requirement_id' => $coverageRequirementId,
                'reserved_by_user_id' => $actor->id,
                'reservation_token' => (string) Str::uuid(),
                'status' => self::STATUS_ACTIVE,
                'reason' => $reason,
                'role_key' => $reservationRoleKey,
                'window_starts_at' => $windowStartsAt,
                'window_ends_at' => $windowEndsAt,
                'expires_at' => now()->addMinutes(5),
                'meta' => [
                    'source' => $reason,
                    'slot_key' => $this->nextAvailableSlotKey($window, $reservationRoleKey),
                ],
            ];
            if ($checkedWrite) {
                return $checkedWrite(new CoverageReservation, $values);
            }

            return CoverageReservation::create($values);
        });
    }

    public function expireStaleReservations(): void
    {
        CoverageReservation::query()
            ->where('status', self::STATUS_ACTIVE)
            ->where('expires_at', '<=', now())
            ->update([
                'status' => self::STATUS_EXPIRED,
            ]);
    }

    /**
     * @param array<string, mixed> $window
     */
    protected function availableSlotsForWindow(array $window, ?string $roleKey, ?CurrentAuthorizationReads $reads = null): int
    {
        $activeReservations = CoverageReservation::query()
            ->where('status', self::STATUS_ACTIVE)
            ->where('site_id', $window['site_id'])
            ->when(
                $window['rule_id'] ?? null,
                fn ($query, $ruleId) => $query->where('coverage_requirement_id', $ruleId),
                fn ($query) => $query->whereNull('coverage_requirement_id'),
            )
            ->where('window_starts_at', $this->utcInstant($window['starts_at']))
            ->where('window_ends_at', $this->utcInstant($window['ends_at']))
            ->when($roleKey, fn ($query) => $query->where('role_key', $roleKey));
        $activeReservations = $reads
            ? $reads->query($activeReservations->orderBy('id'))->get()->count()
            : $activeReservations->count();

        $roleShortagePool = ($window['planned_role_shortages'] ?? []) !== []
            ? ($window['planned_role_shortages'] ?? [])
            : ($window['role_shortages'] ?? []);

        if ($roleKey && ! empty($roleShortagePool)) {
            $required = collect($roleShortagePool)
                ->firstWhere('key', $roleKey);

            return max(0, (int) ($required['missing'] ?? 0) - $activeReservations);
        }

        return max(0, (int) ($window['unfilled_after_open_shifts'] ?? $window['missing_staff'] ?? 0) - $activeReservations);
    }

    protected function findCoverageWindow(
        int $siteId,
        CarbonInterface $windowStartsAt,
        CarbonInterface $windowEndsAt,
        ?int $coverageRequirementId = null,
        bool $current = false,
    ): ?array {
        return $this->coverage->findCoverageWindow($siteId, $windowStartsAt, $windowEndsAt, $coverageRequirementId, current: $current);
    }

    protected function assertActorCanReserveAtSite(
        User $actor,
        int $siteId,
        ?int $coverageRequirementId,
        ?CurrentAuthorizationReads $reads = null,
    ): void {
        if ($reads) {
            // The Site bypass must use the same current actor/RBAC evidence as its Site rows.
            $actor = app(AuthorizationEvidenceLockService::class)->lockForUserWithoutWaiting($actor, ['reports.viewAny']);
            abort_unless(in_array($siteId, $this->siteAccess->accessibleSiteIds($actor, ['reports.viewAny'], $reads), true),
                403, UserSiteAccessService::DEFAULT_MESSAGE);
        } else {
            $this->siteAccess->assertCanAccessSiteId($actor, $siteId, ['reports.viewAny']);
        }

        if (! $coverageRequirementId) {
            return;
        }

        $rule = SiteCoverageRequirement::query()->whereKey($coverageRequirementId)->where('site_id', $siteId);
        abort_unless(
            $reads ? $reads->query($rule)->first() !== null : $rule->exists(),
            403,
            UserSiteAccessService::DEFAULT_MESSAGE,
        );
    }

    /**
     * @param array<string, mixed> $window
     */
    protected function nextAvailableSlotKey(array $window, ?string $roleKey): ?string
    {
        $slots = collect($window['coverage_slots'] ?? []);

        $matchingSlot = $slots->first(function (array $slot) use ($roleKey) {
            if ($roleKey) {
                return ($slot['kind'] ?? null) === 'role'
                    && ($slot['role_key'] ?? null) === $roleKey
                    && in_array($slot['status'] ?? null, ['available', 'reserved'], true);
            }

            return ($slot['kind'] ?? null) === 'headcount'
                && in_array($slot['status'] ?? null, ['available', 'reserved'], true);
        });

        return $matchingSlot['slot_key'] ?? null;
    }

    private function currentReservationMutation(callable $mutation): mixed
    {
        return DB::transaction(function () use ($mutation): mixed {
            // Capacity writers share planning/lifecycle's governing first lock.
            app(WorkforceMutationGuard::class)->lock();

            return CurrentAuthorizationReads::within($mutation);
        });
    }

    private function utcInstant(mixed $value): CarbonInterface
    {
        return $value instanceof CarbonInterface
            ? $value->copy()->utc()
            : Carbon::parse((string) $value)->utc();
    }
}
