from pathlib import Path
import datetime, difflib, hashlib, json, re

ROOT = Path('C:/Users/steph/Herd/oblivionfindings')
PACKET = ROOT / 'test-results/workforce-calendar-backend-native-composition-plan-20261012'
sha = lambda b: hashlib.sha256(b).hexdigest()
reader = ROOT / 'test-results/workforce-calendar-main-reader-proposal-20261011'
writer = ROOT / 'test-results/workforce-calendar-main-move-proposal-20261012'
r2 = ROOT / 'test-results/workforce-calendar-main-move-proposal-r2-20261012'
qual = ROOT / 'test-results/workforce-calendar-qualification-ack-proposal-20261012'
baseline = ROOT / 'test-results/workforce-main-timeoff-leave-source-aggregate-r10-20261011'
old_root = ROOT / 'test-results/workforce-main-timeoff-leave-source-mirror-r3-20261011/root'
old_native = old_root / 'test-results/main-timeoff-leave-native-r3-20261011'
# Only pure text/byte utilities are loaded; no proposal author or application runs.
utility_source = (reader / 'author.py').read_text(encoding='utf-8-sig')
exec(utility_source[utility_source.index('def block('):utility_source.index('\nbefore = ')])

def put(name, b):
    p = PACKET / name
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_bytes() == b, name
    else:
        p.write_bytes(b)

def dump(name, value):
    put(name, (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))

def load(p):
    return json.loads(p.read_bytes())

def digest(p):
    return sha(p.read_bytes())

def manifest_check(p, expected):
    assert digest(p / 'manifest.json') == expected
    m = load(p / 'manifest.json')
    for name, expected_hash in m['files'].items():
        assert digest(p / name) == expected_hash, name

manifest_check(reader, 'eb145495fae38c1054c1d9b063ce257e08066a23e580071415a58ed475ec454e')
manifest_check(writer, '315898f2f8e622f2cd169fe1d9c8d316a4a11fd6e83293d320abde79129c0a5b')
manifest_check(r2, '10c572424e5f78f6506595ec1f45fbcbdef30f585f2be83a21da49bab7468f1b')
manifest_check(qual, '458b017ec3da2777a844a156a754490b2ad2abd5f858fb41442fc6140e44f118')
assert digest(reader / 'independent-hr-review.json') == '68fb67ac8268660ee0fa8d262bf25e8e29f00ed534484f58996123b6d4a372c7'
assert digest(writer / 'independent-hr-review.json') == '3f00bd82d79a884a2435ee8bcddf749564ea426d8472f5d1a91616a43945a0f5'
assert digest(r2 / 'independent-hr-review.json') == 'c7033456f882654f38a6f1561bc86e6eb99c4949849ee5c4b4ce3852b847a951'
assert digest(old_native / 'mirror-preparation.json') == '8ee5adbb684b162bc5622b492440b6522209e1dd5afbfd219fcb996b655aa4f9'
data = load(baseline / 'data.json')
prepared = load(old_native / 'mirror-preparation.json')
assert prepared['state'] == 'PREPARED_SOURCE_MIRROR_NOT_TEST_ACCEPTANCE'
assert prepared['framework_or_app_invoked'] is False and prepared['database_or_schema_created'] is False
assert len(data['source_pins']) == 7563 and prepared['source_pins'] == data['source_pins']

controller = 'app/Http/Controllers/CalendarController.php'
timeline = 'app/Services/ShiftTimelineService.php'
coverage = 'app/Services/CoverageReservationService.php'
command = 'app/Services/Operations/CalendarShiftMove.php'
read_test = 'tests/Feature/Rostering/WorkforceCalendarReadIntegrityTest.php'
move_test = 'tests/Feature/Rostering/WorkforceCalendarMoveIntegrityTest.php'
sources = {
    controller: r2 / 'qualification-composed' / controller,
    coverage: writer / 'proposed' / coverage,
    timeline: r2 / 'proposed' / timeline,
    command: r2 / 'qualification-composed' / command,
    read_test: reader / 'proposed' / read_test,
    move_test: r2 / 'qualification-composed' / move_test,
}
changes, source_records = [], []
for name, source in sources.items():
    before = (ROOT / name).read_bytes() if (ROOT / name).exists() else None
    after = source.read_bytes()
    if before is not None:
        assert data['source_pins'][name] == sha(before), name
        put('before/' + name, before)
    else:
        assert name not in data['source_pins'], name
    put('proposed/' + name, after)
    single = patch([(name, before, after)])
    inverse = patch([(name, before, after)], reverse=True)
    assert reconstruct(before, single) == after
    assert reconstruct(after, inverse) == (before or b'')
    changes.append((name, before, after))
    source_records.append({'path': name, 'before_exists': before is not None,
        'before_sha256': sha(before) if before is not None else None,
        'after_sha256': sha(after), 'source_reference': str(source.relative_to(ROOT)).replace('\\', '/'),
        'raw_forward_exact': True, 'raw_inverse_exact': True})
put('composition.patch', patch(changes))
put('inverse.patch', patch(changes, reverse=True))

# Exact sequential lineage, and exact reverse at every reviewed transition.
lineage = []
for name, before, after in changes:
    stages = []
    if name == controller:
        stages = [before, (reader / 'proposed' / name).read_bytes(), (writer / 'proposed' / name).read_bytes(), after]
    elif name == timeline:
        stages = [before, (writer / 'proposed' / name).read_bytes(), after]
    elif name in (command, move_test):
        stages = [None, (writer / 'proposed' / name).read_bytes(), (r2 / 'proposed' / name).read_bytes(), after]
    else:
        stages = [before, after]
    for left, right in zip(stages, stages[1:]):
        assert reconstruct(left, patch([(name, left, right)])) == right
        assert reconstruct(right, patch([(name, left, right)], reverse=True)) == (left or b'')
    lineage.append({'path': name, 'stage_hashes': [sha(b) if b is not None else None for b in stages],
        'every_raw_stage_forward_inverse_exact': True})

test_files = [read_test, move_test,
    'tests/Feature/Rostering/WorkforceRosteringReadPermissionIntegrityTest.php',
    'tests/Feature/Respite/RespiteReadinessTest.php',
    'tests/Feature/Rostering/WorkforceClientQualificationIntegrityTest.php',
    'tests/Feature/Rostering/WorkforceHouseQualificationIntegrityTest.php',
    'tests/Feature/Rostering/WorkforceShiftSaveCommandIntegrityTest.php']
reasons = [
    'Complete new reader privacy/range/Show/canonical coverage controls; 38 source-derived declarations.',
    'Complete composed saved-MOVE controls, all original43 + R2 ten + qualification14; 67 source-derived declarations.',
    'Whole current owning roster read/week/filter/privacy contracts survive the Calendar reader composition.',
    'Whole six-method current Respite readiness preserves real linked Shift Calendar/Show and lifecycle callers of Timeline.',
    'Whole Client qualification rule/default/configured-block/current-grant/immutable evidence preservation.',
    'Whole House qualification applicability/per-requirement default/coverage/publication preservation.',
    'Whole canonical planning-save authority/warnings/holds/tasks/rollback/root receipts, because optional shared Coverage/Timeline service seams change.']
suite_records, imported = [], set()
for name, reason in zip(test_files, reasons):
    b = sources[name].read_bytes() if name in sources else (ROOT / name).read_bytes()
    namespace = re.search(rb'namespace ([^;]+);', b).group(1).decode()
    klass = re.search(rb'^class ([A-Za-z0-9_]+) ', b, re.M).group(1).decode()
    methods = re.findall(rb'^    public function (test_[A-Za-z0-9_]+)\(', b, re.M)
    rows = [{'method': n.decode(), 'body_sha256': sha(block(b, n.decode()))} for n in methods]
    suite_records.append({'path': name, 'class': namespace + '\\' + klass, 'sha256': sha(b),
        'scope': 'whole_class', 'test_methods': rows, 'reason': reason,
        'framework_cases': None, 'actual_junit_identities': None})
    for n in re.findall(rb'^use ((?:App|Tests)\\[^;]+);', b, re.M):
        imported.add(n.decode().split(' as ')[0])
for source in sources.values():
    for n in re.findall(rb'^use ((?:App|Tests)\\[^;]+);', source.read_bytes(), re.M):
        imported.add(n.decode().split(' as ')[0])
imported.add('App\\Services\\Operations\\CalendarShiftMove')
imported.update(s['class'] for s in suite_records)

dependency_pins = {}
for packet in [reader, writer, r2, qual]:
    pins = load(packet / 'dependency-pins.json')
    pins = pins.get('pins', pins)
    for name, expected in pins.items():
        if name in dependency_pins: assert dependency_pins[name] == expected, name
        dependency_pins[name] = expected
for name in test_files:
    if name not in sources: dependency_pins[name] = digest(ROOT / name)
reflection_additions = {}
future = dict(data['source_pins'])
for record in source_records: future[record['path']] = record['after_sha256']
for klass in sorted(imported):
    prefix = 'app' if klass.startswith('App\\') else 'tests'
    name = prefix + '/' + klass.split('\\', 1)[1].replace('\\', '/') + '.php'
    p = sources.get(name, ROOT / name)
    assert p.is_file(), klass
    candidate_hash = digest(p)
    if name not in sources: dependency_pins[name] = candidate_hash
    assert future[name] == candidate_hash, name
    old = data['reflection_pins'].get(klass)
    if old is None or old['candidate_sha256'] != candidate_hash:
        reflection_additions[klass] = {'mirror_relative': name, 'candidate_sha256': candidate_hash}

additional_pages = ['resources/js/pages/sites/index.tsx',
    'resources/js/pages/operations/shifts/index.tsx', 'resources/js/pages/my-day/index.tsx']
page_additions = {}
for name in additional_pages:
    assert name not in future and name not in data['page_pins']
    page_additions[name] = digest(ROOT / name)
    future[name] = page_additions[name]
    dependency_pins[name] = page_additions[name]
assert len(future) == 7569
live_drift = []
for name, expected in data['source_pins'].items():
    p = ROOT / name
    observed = digest(p) if p.is_file() else None
    if observed != expected: live_drift.append({'path': name, 'expected': expected, 'observed': observed})
dependency_drift = []
for name, expected in dependency_pins.items():
    p = ROOT / name
    observed = digest(p) if p.is_file() else None
    if observed != expected: dependency_drift.append({'path': name, 'expected': expected, 'observed': observed})
metadata_drift = []
for name, expected in data['metadata_pins'].items():
    if digest(ROOT / name) != expected: metadata_drift.append(name)

helper_refs = {}
for name, expected in prepared['tool_pins'].items():
    assert digest(old_native / name) == expected
    helper_refs[str((old_native / name).relative_to(ROOT)).replace('\\', '/')] = expected
for name in ['phase-common.ps1', 'prepare-mirror.ps1', 'check-prerequisites.ps1', 'phase-command.php', 'execute-list.ps1', 'execute-native.ps1']:
    helper_refs[str((baseline / 'proposed' / name).relative_to(ROOT)).replace('\\', '/')] = digest(baseline / 'proposed' / name)
assert digest(Path(data['schema_source'])) == data['schema']['sha256']
required_tables = ['shifts', 'clients', 'sites', 'users', 'hr_employee_profiles', 'shift_tasks',
    'timeline_events', 'coverage_reservations', 'shift_eligibility_overrides', 'shift_open_positions',
    'site_coverage_requirements', 'staff_qualification_requirements', 'site_staff_requirements',
    'app_settings', 'audit_logs', 'roster_periods', 'timesheets', 'respite_bookings',
    'workforce_eligibility_rechecks', 'workforce_eligibility_refreshes']
sql = Path(data['schema_source']).read_bytes()
schema_presence = {name: bool(re.search(rb'CREATE TABLE `'+name.encode()+rb'`', sql)) for name in required_tables}

history = {}
for packet, names in [
    (reader, ['manifest.json', 'repair.patch', 'inverse.patch', 'independent-hr-review.json']),
    (writer, ['manifest.json', 'repair.patch', 'inverse.patch', 'independent-hr-review.json']),
    (r2, ['manifest.json', 'repair.patch', 'inverse.patch', 'qualification-composed.patch', 'qualification-composed-inverse.patch', 'composition-proof.json', 'independent-hr-review.json']),
    (qual, ['manifest.json', 'repair.patch', 'inverse.patch', 'contract.md']),
    (baseline, ['manifest.json', 'data.json', 'finite-execution-pins.json', 'independent-hr-review.json', 'source-adoption.json', 'materialisation.json']),
    (old_native, ['mirror-preparation.json', 'profile.prepared.json'])]:
    for name in names: history[str((packet/name).relative_to(ROOT)).replace('\\', '/')] = digest(packet/name)

dump('sources.json', source_records)
dump('lineage.json', lineage)
dump('dependencies.json', {'source_only': True, 'pins': dependency_pins, 'current_drift': dependency_drift})
dump('history-references.json', history)
dump('suite-selection.json', {'source_derived_only': True, 'selected_files': suite_records,
    'new_reader_declared_cases': 38, 'composed_move_declared_cases': 67,
    'preservation_case_counts': None, 'actual_union_count': None, 'actual_inventory': None,
    'actual_junit_identities': None, 'filter_class_union': '(?:'+'|'.join(s['class'].split('\\')[-1]+'::' for s in suite_records)+')',
    'declared_case_references': {str((p/n).relative_to(ROOT)).replace('\\','/'): digest(p/n)
        for p,n in [(reader,'selection.json'),(writer,'selection.json'),(r2,'selection.json'),(qual,'selection.json')]},
    'all_named_tests_and_all_provider_rows_required': True})
dump('future-runtime-requirements.json', {
    'plan_only_no_executable_tools_authored': True,
    'fresh_source_mirror': str(ROOT / 'test-results/workforce-calendar-source-mirror-20261012/root').replace('\\','/'),
    'fresh_runtime_relative': 'test-results/main-calendar-native-20261012',
    'fresh_database_base': 'oblivion_workforce_maincal_20261012',
    'original_prepared_leave_mirror_must_remain_immutable': str(old_root).replace('\\','/'),
    'baseline_preparation_sha256': digest(old_native/'mirror-preparation.json'),
    'baseline_source_map_reference': str((old_native/'profile.prepared.json').relative_to(ROOT)).replace('\\','/'),
    'baseline_source_count': 7563, 'future_candidate_source_count': 7569,
    'source_overlays': source_records, 'additional_real_page_pins': page_additions,
    'unchanged_existing_pages': data['page_pins'], 'unchanged_static_pins': data['static_pins'],
    'reflection_overlays': reflection_additions,
    'metadata_reference': str((baseline/'data.json').relative_to(ROOT)).replace('\\','/'),
    'metadata_count': len(data['metadata_pins']), 'package_mappings_count': len(data['package_mappings']),
    'finite_vendor_count': len(data['finite_vendor_pins']),
    'reused_helper_source_pins': helper_refs,
    'schema': data['schema'], 'sealed_schema_source': data['schema_source'],
    'schema_static_data_allowlist_unchanged': data['schema_data_allowlist'],
    'required_table_dump_presence_source_only': schema_presence,
    'pending_installed_migrations_must_run_only_in_future_owned_schema': True,
    'guard_contract': {'minimum_free_mib': 4096, 'maximum_cpu_percent': 85,
        'php_memory_limit_mib': 1024, 'deadline_seconds': 1800, 'zero_peer_php_pest_imports': True,
        'shared_gate': 'Local\\OblivionWorkforceMainIntegrationNativeGate',
        'exact_protected_preview_and_herd_executable_command_birth_parent_chain': True,
        'retained_native_handle_plus_first_cim_identity_required': True,
        'owned_child_tracking_and_absence_before_exact_schema_cleanup': True,
        'refuse_drop_if_owner_or_descendant_absence_uncertain': True,
        'fresh_namespace_absence_no_overwrite_no_automatic_retry': True},
    'literal_adaptations_only_before_independent_tool_review': [
        'Fresh mirror/runtime/database literals in all phase/native/XML/bootstrap/storage/cache references.',
        'Exact7563 to7569 source union +6 reviewed source overlays +3 required page additions; preserve remaining7560 baseline source hashes.',
        'Seven whole selected classes and actual framework provider/JUnit identities; keep actual union null until list.',
        'Exact consumed reflection overlays; keep finite local Composer metadata/package mappings and external read-only vendor bounds.',
        'New source application and mirror preparation lineage; never reuse the Leave preparation as proof of changed Calendar sources.',
        'Current parent-provided HEAD and protected process cohort must be freshly bound/reviewed; do not treat old ce50/Herd observations as fresh admission.'],
    'expected_head': None, 'framework_enumerated': False, 'actual_cases': None,
    'application_authorized': False, 'inventory_authorized': False, 'native_authorized': False})
dump('source-proof.json', {'source_only': True, 'every_six_path_full_forward_inverse_exact': True,
    'every_reviewed_lineage_stage_raw_forward_inverse_exact': True,
    'final_sources_equal_exact_reviewed_composed_after_images': True,
    'all_prerequisite_authored_hashes_and_source_reviews_exact': True,
    'baseline_source_count': 7563, 'baseline_current_drift': live_drift,
    'finite_dependency_current_drift': dependency_drift, 'metadata_current_drift': metadata_drift,
    'old_preparation_and_native8_source_pins_exact': True,
    'original_mirror_not_written_or_bootstrapped': True,
    'fresh_source_mirror_exists': (ROOT/'test-results/workforce-calendar-source-mirror-20261012').exists(),
    'future_source_count_arithmetic': '7563 + new command + two new tests + three real Inertia pages = 7569',
    'no_parser_framework_database_process_or_git_invoked': True})

files = {str(p.relative_to(PACKET)).replace('\\','/'): digest(p) for p in sorted(PACKET.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
manifest = {'state': 'INACTIVE_CURRENT_SOURCE_COMPOSITION_AND_FRESH_NATIVE_PLAN_ONLY',
    'approved': False, 'application_authorized': False, 'inventory_authorized': False, 'native_authorized': False,
    'expected_head': None, 'framework_enumerated': False, 'actual_union_cases': None,
    'source_paths': source_records, 'selected_whole_classes': len(test_files),
    'new_reader_declared_cases': 38, 'composed_move_declared_cases': 67,
    'preservation_counts_unset': True, 'baseline_source_count': 7563, 'future_candidate_source_count': 7569,
    'current_baseline_drift_count': len(live_drift), 'current_dependency_drift_count': len(dependency_drift),
    'metadata_drift_count': len(metadata_drift), 'files': files}
dump('manifest.json', manifest)
print(json.dumps({'manifest': digest(PACKET/'manifest.json'), 'composition': digest(PACKET/'composition.patch'),
    'inverse': digest(PACKET/'inverse.patch'), 'current_baseline_drift': live_drift,
    'dependency_drift': dependency_drift, 'source_count': len(future), 'actual_inventory': None}))
