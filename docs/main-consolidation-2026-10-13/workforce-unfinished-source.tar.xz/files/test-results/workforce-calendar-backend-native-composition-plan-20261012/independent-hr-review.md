# Calendar composition/native plan — source review

HOLD_SOURCE_ONLY against final manifest `b29c41c2c0bb07f786399c9a231931b955213e01b1a3b0368a25ebf6ef7146a8`.

**H1:** `future-runtime-requirements-final.json` omits the inherited `App\Http\Controllers\CalendarController` reflection override. Baseline reflection still requires `69616a2f…`; final composed source is `4c4d1b24…`. All other merged178 declarations match. Add that one explicit final-hash overlay and preserve `actual_reflection_required_before_acceptance=true`; otherwise literal native preparation rejects the controller or loses an existing ownership assertion. No product repair is needed.

The six raw forward/inverse sections, all23 authored hashes, four prerequisite manifests,27 histories and exact composed source references pass. Current7563 source,107 dependency and13 metadata bytes show no drift. The prospective7569 union preserves7560 baseline inputs, replaces3 existing PHP files, adds3 PHP files and3 real Inertia pages. Eight original pages, two navigation inputs,158 readonly package targets and29 finite vendor pins remain required. Both whole new test files equal the reviewed38-reader/67-qualified-MOVE after-images, retaining original identities. Existing shared optional callbacks/defaults and unowned writers carry forward unchanged.

The final schema plan correctly identifies absent eligibility recheck/observation tables and installed migration `93167a4d…`. TestCase applies **all pending installed migrations** after import, so fresh runnable tools must review that boundary rather than imply a one-migration run. The sealed schema and old Leave preparation/native sources are immutable history.

Actual HEAD/inventory/union remain null and every application/list/native approval is false. Fresh executable adaptation, reflection correction, source application/mirror receipts, parser/Pint, actual listing, owned native/cleanup and frontend/build/browser journeys remain unaccepted. No runtime or product action occurred.
