CLEAR_SOURCE_ONLY — same eight whole suites, disjoint4+4.

Same eight complete applied suites partition disjoint four/four; Wizard and Index separated. Runner bodies match donor3be5 after config/output binding substitution only. Setup/workers/timeouts/admission/mutex/retained-own-child/60-second/cleanup/final-pin safeguards stay exact. Current16 match receipt; runtime179 map unchanged.

No reviewer runtime. Fullc deadline and prior155 remain historical. Both sequential fresh-admitted batches must actually pass with complete closure/final pins; unique(file+fullname) union must match all current complete test identities before a combined155 claim.
