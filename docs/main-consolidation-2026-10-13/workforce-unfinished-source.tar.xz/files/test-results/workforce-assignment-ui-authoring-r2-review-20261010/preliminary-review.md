Both original P2 findings are corrected in the observed current authoring source. This is preliminary source clearance only; the revised files are unformatted, unfrozen and have no fresh scoped check result.

Returned warning review is now bound to its selected worker. Changing to another worker clears only definitive prior review, while pending and unknown attempts stay held. The authored A-warning → B-clean test exercises the owning hook and dialog rather than only a matcher.

Both dialogs now display the canonical snapshot returned with the opaque digest on open or explicit Refresh. Unassign Confirm sends that captured source directly; no GET can silently substitute another revision at confirmation. Explicit refresh preserves the reason while replacing display/source together; missing display blocks confirmation.

No additional concrete blocker was found in the targeted actor/permission, committed-result, unknown-recovery, warning policy, pending/dirty-dialog, privacy or return-context read. The observed19-path map is in the JSON; only7 paths differ from the preserved frozen R1. Those7 observed authoring copies are retained here for exact review identity, not repinned as accepted source.

The old170-case proof and original HOLD remain immutable. Fresh formatting, a frozen final patch and fresh scoped tests/types/lint proof are still required. Backend/native/full-project/browser acceptance and durable retry are not certified. No source, framework, process, database, test, build, gate or browser action was performed by this review.
