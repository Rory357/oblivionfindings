The uncertain-state “Open shift” links have a concrete draft-loss gap. Both are plain same-tab anchors, outside the dialog close/discard handlers. The installed shared Button/Slot and Dialog/focus wrappers do not intercept page navigation, and the owning roster page/hook has no assignment-specific unload/navigation guard.

A normal click leaves the document, discarding the entered reason, selected worker, reviewed snapshot and in-memory held attempt. This does not establish a duplicate POST or backend commit failure; it breaks the intended recovery preservation.

The smallest repair is to keep the scoped Shift URL and use `target="_blank" rel="noopener noreferrer"`, visibly labelled “Open shift in a new tab”. Preserve the original dialog, note and unknown hold. No durable retry/storage redesign is required. Add a focused link-attribute/state-preservation control; later browser evidence can confirm the original tab remains intact.

The preliminary review and original170 proof remain unchanged. This additive finding uses their exact observed authoring hashes and installed shared-source pins. No product/runtime action was taken.
