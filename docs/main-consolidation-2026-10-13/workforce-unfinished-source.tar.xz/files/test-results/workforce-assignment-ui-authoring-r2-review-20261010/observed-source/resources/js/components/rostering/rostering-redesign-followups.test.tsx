import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import type React from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

import AnalyticsPane from './analytics-pane';
import AvailabilityPane from './availability-pane';
import CapacityHeatmapPane from './capacity-heatmap-pane';
import CoveragePane from './coverage-pane';
import OpenShiftsPane from './open-shifts-pane';
import ReassignDialog from './reassign-dialog';
import RequestReplacementDialog from './request-replacement-dialog';
import ResolveConflictDialog from './resolve-conflict-dialog';
import TabStrip from './tab-strip';
import TimeOffPane from './time-off-pane';
import UnassignMakeOpenDialog from './unassign-make-open-dialog';
import WeekGridPane from './week-grid-pane';

vi.mock('@inertiajs/react', () => ({
    Link: ({
        href,
        children,
        ...props
    }: {
        href: string;
        children: React.ReactNode;
    }) => (
        <a href={href} {...props}>
            {children}
        </a>
    ),
}));

const weekDays = Array.from({ length: 7 }, (_, i) => {
    const d = new Date('2026-05-04T00:00:00');
    d.setDate(d.getDate() + i);
    return d;
});
beforeEach(() => {
    vi.stubGlobal('fetch', vi.fn(async (url: string) => {
        const id = Number(/shifts\/(\d+)\/candidates/.exec(url)?.[1]);
        return { ok: true, json: async () => ({ actor_id: 5, shift_source: { shift_id: id, revision: 'a'.repeat(64) }, current_user_id: 7, locked: false, candidates: [], shift_display: { id, starts_at: id === 45 ? '2026-05-05T13:00:00+12:00' : '2026-05-04T09:00:00+12:00', ends_at: null, client: id === 45 ? 'Mere Rata' : 'Ari Kauri', site: 'Matai House', staff: id === 45 ? 'Wiremu Tait' : 'Aroha King', isOpen: false } }) };
    }));
});
afterEach(() => vi.unstubAllGlobals());

describe('rostering redesign follow-up wiring', () => {
    it('surfaces active replacement requests separately from open shifts', () => {
        const onFindCover = vi.fn();

        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[]}
                canManage
                onAssign={vi.fn()}
                replacementRequests={[
                    {
                        id: 91,
                        shift_id: 42,
                        requested_by: 'Mere Ana',
                        current_staff: 'Tama Rangi',
                        reason: 'Sick leave',
                        starts_at: '2026-05-04T21:00:00+12:00',
                        ends_at: '2026-05-05T07:00:00+12:00',
                        client: 'Ari Kauri',
                        location: 'Matai House',
                    },
                ]}
                onFindReplacement={onFindCover}
            />,
        );

        expect(screen.getByText('Replacement requests')).toBeVisible();
        expect(screen.getByText('Mere Ana')).toBeVisible();
        expect(screen.getByText(/Tama Rangi/)).toBeVisible();

        fireEvent.click(screen.getByRole('button', { name: /Find cover/i }));

        expect(onFindCover).toHaveBeenCalledWith(
            expect.objectContaining({ id: 91, shift_id: 42 }),
        );
    });

    it('shows detailed eligibility warning and blocker reasons in open shifts', () => {
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[]}
                canManage
                onAssign={vi.fn()}
                eligibilityAlerts={{
                    blocked: [
                        {
                            id: 4,
                            user_id: 22,
                            starts_at: '2026-05-04T09:00:00+12:00',
                            staff: 'Aroha King',
                            site: 'Matai House',
                            reason: 'Expired first aid certification',
                        },
                    ],
                    warnings: [
                        {
                            id: 5,
                            user_id: 33,
                            starts_at: '2026-05-05T09:00:00+12:00',
                            staff: 'Tama Rangi',
                            site: 'Kauri House',
                            reason: 'Tight turnaround from previous shift',
                        },
                    ],
                }}
            />,
        );

        expect(screen.getByText('Eligibility watchlist')).toBeVisible();
        expect(
            screen.getByText('Expired first aid certification'),
        ).toBeVisible();
        expect(
            screen.getByText('Tight turnaround from previous shift'),
        ).toBeVisible();
        expect(
            screen.queryByRole('link', {
                name: /availability for Aroha King/i,
            }),
        ).not.toBeInTheDocument();
    });

    it('moves rostering tabs with arrow keys', () => {
        const onChange = vi.fn();

        render(
            <TabStrip
                value="shifts"
                onChange={onChange}
                items={[
                    {
                        id: 'shifts',
                        label: 'Shifts',
                        icon: (() => <span />) as React.ComponentType<{
                            className?: string;
                        }>,
                        tone: 'primary',
                    },
                    {
                        id: 'open',
                        label: 'Open',
                        icon: (() => <span />) as React.ComponentType<{
                            className?: string;
                        }>,
                        tone: 'warning',
                    },
                    {
                        id: 'availability',
                        label: 'Availability',
                        icon: (() => <span />) as React.ComponentType<{
                            className?: string;
                        }>,
                        tone: 'success',
                    },
                ]}
            />,
        );

        fireEvent.keyDown(screen.getByRole('tab', { name: /Shifts/i }), {
            key: 'ArrowRight',
        });

        expect(onChange).toHaveBeenCalledWith('open');
    });

    it('shows staff availability in a rostering pane with an inline edit button', () => {
        render(
            <AvailabilityPane
                canManage
                staff={[
                    {
                        id: 22,
                        name: 'Aroha King',
                        email: 'aroha@example.test',
                        role: 'support_worker',
                        staff_availability: [
                            {
                                id: 1,
                                day_of_week: new Date().getDay(),
                                start_time: '09:00',
                                end_time: '17:00',
                            },
                        ],
                        staff_time_off: [],
                    },
                ]}
                upcomingLeave={{
                    22: [
                        {
                            id: 10,
                            leave_type: 'annual_leave',
                            starts_at: '2026-05-06T00:00:00+12:00',
                            ends_at: '2026-05-08T23:59:00+12:00',
                            status: 'approved',
                        },
                    ],
                }}
            />,
        );

        expect(screen.getByText('1 of 1 staff shown')).toBeVisible();
        expect(screen.queryByText('Total staff')).not.toBeInTheDocument();
        expect(screen.queryByText('Declared today')).not.toBeInTheDocument();
        expect(
            screen.queryByText('Currently on leave'),
        ).not.toBeInTheDocument();
        expect(screen.queryByText('No data')).not.toBeInTheDocument();
        expect(screen.getByText('Aroha King')).toBeVisible();
        // Edit no longer navigates — it opens an in-page dialog.
        expect(
            screen.getByRole('button', { name: /Edit availability/i }),
        ).toBeVisible();
    });

    it('shows candidate capacity context on suggested staff chips', () => {
        const onAssign = vi.fn();

        render(
            <OpenShiftsPane
                stats={[]}
                canManage
                onAssign={onAssign}
                shifts={[
                    {
                        id: 44,
                        day: 'Mon 04 May',
                        start: '09:00',
                        end: '13:00',
                        hours: 4,
                        client: 'Ari Kauri',
                        site: 'Matai House',
                        reason: null,
                        eligible: 1,
                        warnings: 0,
                        suggestions: [{ id: 7, name: 'Aroha King', hours: 32 }],
                        href: '/operations/shifts/44',
                    },
                ]}
            />,
        );

        expect(screen.getByText('32h this week')).toBeVisible();

        fireEvent.click(screen.getByRole('button', { name: /Aroha King/i }));
        expect(onAssign).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44 }),
            7,
        );
    });

    it('renders a warning indicator and tooltip on suggestion chips when a candidate has soft eligibility issues', () => {
        const onAssign = vi.fn();

        render(
            <OpenShiftsPane
                stats={[]}
                canManage
                onAssign={onAssign}
                shifts={[
                    {
                        id: 44,
                        day: 'Mon 04 May',
                        start: '09:00',
                        end: '13:00',
                        hours: 4,
                        client: 'Ari Kauri',
                        site: 'Matai House',
                        reason: null,
                        eligible: 1,
                        warnings: 1,
                        suggestions: [
                            {
                                id: 7,
                                name: 'Aroha King',
                                hours: 32,
                                eligibility: {
                                    status: 'warning',
                                    reasons: ['Tight turnaround under 8h'],
                                },
                            },
                        ],
                        href: '/operations/shifts/44',
                    },
                ]}
            />,
        );

        const chip = screen.getByRole('button', { name: /Aroha King/i });
        expect(chip).toHaveAttribute('data-eligibility', 'warning');
        expect(chip).toHaveAttribute('title', 'Tight turnaround under 8h');
        expect(chip).not.toBeDisabled();

        fireEvent.click(chip);
        expect(onAssign).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44 }),
            7,
        );
    });

    it('renders a blocked chip that cannot be clicked when a candidate fails hard eligibility', () => {
        const onAssign = vi.fn();

        render(
            <OpenShiftsPane
                stats={[]}
                canManage
                onAssign={onAssign}
                shifts={[
                    {
                        id: 44,
                        day: 'Mon 04 May',
                        start: '09:00',
                        end: '13:00',
                        hours: 4,
                        client: 'Ari Kauri',
                        site: 'Matai House',
                        reason: null,
                        eligible: 0,
                        warnings: 0,
                        suggestions: [
                            {
                                id: 7,
                                name: 'Aroha King',
                                hours: 32,
                                eligibility: {
                                    status: 'blocked',
                                    reasons: [
                                        'This staff member is already marked unavailable during this time.',
                                    ],
                                },
                            },
                        ],
                        href: '/operations/shifts/44',
                    },
                ]}
            />,
        );

        const chip = screen.getByRole('button', { name: /Aroha King/i });
        expect(chip).toHaveAttribute('data-eligibility', 'blocked');
        expect(chip).toBeDisabled();

        fireEvent.click(chip);
        expect(onAssign).not.toHaveBeenCalled();
    });

    it('keeps eligible chips unstyled and clickable when no eligibility entry is provided', () => {
        const onAssign = vi.fn();

        render(
            <OpenShiftsPane
                stats={[]}
                canManage
                onAssign={onAssign}
                shifts={[
                    {
                        id: 44,
                        day: 'Mon 04 May',
                        start: '09:00',
                        end: '13:00',
                        hours: 4,
                        client: 'Ari Kauri',
                        site: 'Matai House',
                        reason: null,
                        eligible: 1,
                        warnings: 0,
                        suggestions: [{ id: 7, name: 'Aroha King', hours: 32 }],
                        href: '/operations/shifts/44',
                    },
                ]}
            />,
        );

        const chip = screen.getByRole('button', { name: /Aroha King/i });
        expect(chip).toHaveAttribute('data-eligibility', 'eligible');
        expect(chip).not.toBeDisabled();

        fireEvent.click(chip);
        expect(onAssign).toHaveBeenCalled();
    });

    it('does not show an unsupported broadcast action for open shifts', () => {
        render(
            <OpenShiftsPane
                stats={[]}
                canManage
                onAssign={vi.fn()}
                shifts={[
                    {
                        id: 44,
                        day: 'Mon 04 May',
                        start: '09:00',
                        end: '13:00',
                        hours: 4,
                        client: 'Ari Kauri',
                        site: 'Matai House',
                        reason: 'vacant',
                        eligible: 1,
                        warnings: 0,
                        suggestions: [],
                        href: '/operations/shifts/44',
                    },
                ]}
            />,
        );

        expect(
            screen.queryByRole('button', { name: /Broadcast/i }),
        ).not.toBeInTheDocument();
        expect(screen.getByRole('link', { name: 'View' })).toHaveAttribute(
            'href',
            '/operations/shifts/44',
        );
    });

    it('shows staff compliance state in the week grid and a clear empty roster state', () => {
        const { rerender } = render(
            <WeekGridPane
                days={weekDays}
                rows={[
                    {
                        id: 7,
                        name: 'Aroha King',
                        role: null,
                        initials: 'AK',
                        hue: 120,
                        complianceBadge: {
                            state: 'expired',
                            expired: 2,
                            expiring: 0,
                        },
                        shifts: {
                            '2026-05-04': [
                                {
                                    id: 44,
                                    status: 'scheduled',
                                    starts_at: '2026-05-04T09:00:00+12:00',
                                    ends_at: '2026-05-04T13:00:00+12:00',
                                    client: 'Ari Kauri',
                                },
                            ],
                        },
                    },
                ]}
                todayKey={null}
                canManage
            />,
        );

        expect(screen.getByText('Expired compliance')).toBeVisible();

        rerender(
            <WeekGridPane
                days={weekDays}
                rows={[]}
                todayKey={null}
                canManage
            />,
        );

        expect(screen.getByText(/No shifts this week/i)).toBeVisible();
    });

    it('offers a guarded reopen action for cancelled shifts in the week grid menu', () => {
        const onReopenShift = vi.fn();

        render(
            <WeekGridPane
                days={weekDays}
                rows={[
                    {
                        id: 7,
                        name: 'Aroha King',
                        role: null,
                        initials: 'AK',
                        hue: 120,
                        shifts: {
                            '2026-05-04': [
                                {
                                    id: 44,
                                    status: 'cancelled',
                                    starts_at: '2026-05-04T09:00:00+12:00',
                                    ends_at: '2026-05-04T13:00:00+12:00',
                                    client: 'Ari Kauri',
                                    href: '/operations/shifts/44',
                                },
                            ],
                        },
                    },
                ]}
                todayKey={null}
                canManage
                onReopenShift={onReopenShift}
            />,
        );

        fireEvent.contextMenu(screen.getByText('Ari Kauri'));

        expect(
            screen.getByRole('menuitem', { name: /Reopen cancelled shift/i }),
        ).toBeVisible();
        expect(
            screen.queryByRole('menuitem', { name: /Cancel shift/i }),
        ).not.toBeInTheDocument();

        fireEvent.click(
            screen.getByRole('menuitem', { name: /Reopen cancelled shift/i }),
        );
        expect(onReopenShift).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44, status: 'cancelled' }),
        );
    });

    it('offers a copy-to-day action alongside duplicate for editable shifts', () => {
        const onCopyShiftToDay = vi.fn();

        render(
            <WeekGridPane
                days={weekDays}
                rows={[
                    {
                        id: 7,
                        name: 'Aroha King',
                        role: null,
                        initials: 'AK',
                        hue: 120,
                        shifts: {
                            '2026-05-04': [
                                {
                                    id: 44,
                                    status: 'scheduled',
                                    starts_at: '2026-05-04T09:00:00+12:00',
                                    ends_at: '2026-05-04T13:00:00+12:00',
                                    client: 'Ari Kauri',
                                    href: '/operations/shifts/44',
                                },
                            ],
                        },
                    },
                ]}
                todayKey={null}
                canManage
                onCopyShiftToDay={onCopyShiftToDay}
            />,
        );

        fireEvent.contextMenu(screen.getByText('Ari Kauri'));

        fireEvent.click(
            screen.getByRole('menuitem', { name: /Copy to day…/i }),
        );
        expect(onCopyShiftToDay).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44, status: 'scheduled' }),
        );
    });

    it('offers a duplicate action for editable scheduled shifts', () => {
        const onDuplicateShift = vi.fn();

        render(
            <WeekGridPane
                days={weekDays}
                rows={[
                    {
                        id: 7,
                        name: 'Aroha King',
                        role: null,
                        initials: 'AK',
                        hue: 120,
                        shifts: {
                            '2026-05-04': [
                                {
                                    id: 44,
                                    status: 'scheduled',
                                    starts_at: '2026-05-04T09:00:00+12:00',
                                    ends_at: '2026-05-04T13:00:00+12:00',
                                    client: 'Ari Kauri',
                                    href: '/operations/shifts/44',
                                },
                            ],
                        },
                    },
                ]}
                todayKey={null}
                canManage
                onDuplicateShift={onDuplicateShift}
            />,
        );

        fireEvent.contextMenu(screen.getByText('Ari Kauri'));

        fireEvent.click(
            screen.getByRole('menuitem', { name: /Duplicate as draft/i }),
        );
        expect(onDuplicateShift).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44, status: 'scheduled' }),
        );
    });

    it('opens the inline edit dialog from week grid edit actions instead of navigating', () => {
        const onEditShift = vi.fn();
        const originalHref = window.location.href;

        render(
            <WeekGridPane
                days={weekDays}
                rows={[
                    {
                        id: 7,
                        name: 'Aroha King',
                        role: null,
                        initials: 'AK',
                        hue: 120,
                        shifts: {
                            '2026-05-04': [
                                {
                                    id: 44,
                                    status: 'scheduled',
                                    starts_at: '2026-05-04T09:00:00+12:00',
                                    ends_at: '2026-05-04T13:00:00+12:00',
                                    client: 'Ari Kauri',
                                    href: '/operations/shifts/44',
                                },
                            ],
                        },
                    },
                ]}
                todayKey={null}
                canManage
                onEditShift={onEditShift}
            />,
        );

        fireEvent.contextMenu(screen.getByText('Ari Kauri'));

        fireEvent.click(screen.getByRole('menuitem', { name: /^Edit shift/i }));

        expect(onEditShift).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44, status: 'scheduled' }),
        );
        expect(window.location.href).toBe(originalHref);
    });

    it('warns before unassigning and allows submitting without a reason', async () => {
        const onConfirm = vi.fn();

        render(
            <UnassignMakeOpenDialog
                open
                shift={{
                    id: 44,
                    starts_at: '2026-05-04T09:00:00+12:00',
                    client: 'Ari Kauri',
                    staff: 'Aroha King',
                }}
                onOpenChange={vi.fn()}
                onConfirm={onConfirm}
            />,
        );

        expect(
            screen.getByText('You are about to unassign this shift.'),
        ).toBeVisible();
        expect(screen.getByLabelText('Reason (optional)')).toBeVisible();
        expect(
            screen.getByText(/Not mandatory, but useful for audit/i),
        ).toBeVisible();
        await waitFor(() => expect(screen.getByRole('button', { name: /Unassign and make open/i })).toBeEnabled());

        fireEvent.click(
            screen.getByRole('button', { name: /Unassign and make open/i }),
        );

        expect(onConfirm).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44 }),
            null,
            expect.objectContaining({ actorId: 5, source: { shift_id: 44, revision: 'a'.repeat(64) } }),
        );
    });

    it('passes the optional unassign reason when one is entered', async () => {
        const onConfirm = vi.fn();

        render(
            <UnassignMakeOpenDialog
                open
                shift={{
                    id: 45,
                    starts_at: '2026-05-05T13:00:00+12:00',
                    client: 'Mere Rata',
                    staff: 'Wiremu Tait',
                }}
                onOpenChange={vi.fn()}
                onConfirm={onConfirm}
            />,
        );

        await waitFor(() => expect(screen.getByRole('button', { name: /Unassign and make open/i })).toBeEnabled());
        fireEvent.change(screen.getByLabelText('Reason (optional)'), {
            target: { value: '  Staff called in sick  ' },
        });
        fireEvent.click(
            screen.getByRole('button', { name: /Unassign and make open/i }),
        );

        expect(onConfirm).toHaveBeenCalledWith(
            expect.objectContaining({ id: 45 }),
            'Staff called in sick',
            expect.objectContaining({ actorId: 5, source: { shift_id: 45, revision: 'a'.repeat(64) } }),
        );
    });

    it('shows compliance state on the capacity heatmap staff rows', () => {
        render(
            <CapacityHeatmapPane
                stats={[]}
                days={weekDays}
                todayKey={null}
                rows={[
                    {
                        id: 7,
                        name: 'Aroha King',
                        role: null,
                        initials: 'AK',
                        hue: 120,
                        days: [8, 8, 8, 8, 8, 0, 0],
                        target: 40,
                        complianceBadge: {
                            state: 'warning',
                            expired: 0,
                            expiring: 1,
                        },
                    },
                ]}
            />,
        );

        expect(screen.getByText('Expiring soon')).toBeVisible();
    });

    it('keeps low completion rates and empty periods distinct from targets', () => {
        render(
            <AnalyticsPane
                stats={[]}
                completionTrend={[
                    { week: '14 Sep', completion: 20 },
                    { week: '21 Sep', completion: 0 },
                    { week: '28 Sep', completion: null },
                ]}
                shiftTypes={[]}
                fillBySite={[]}
            />,
        );
        expect(
            screen.getByText('14 Sep: 20% completed', { selector: 'li' }),
        ).toBeVisible();
        expect(
            screen.getByText('21 Sep: 0% completed', { selector: 'li' }),
        ).toBeVisible();
        expect(screen.getByText('28 Sep: No shifts')).toBeVisible();
        expect(screen.getByText('0 shifts · this week')).toBeVisible();
        expect(screen.queryByText(/target \(95%\)/)).not.toBeInTheDocument();
        expect(
            screen.queryByRole('button', { name: '8w' }),
        ).not.toBeInTheDocument();
        expect(
            screen.getByText('Recorded overtime hours are not available'),
        ).toBeVisible();
    });

    it('renders recorded shift starts returned by the controller in analytics', () => {
        render(
            <AnalyticsPane
                stats={[]}
                completionTrend={[]}
                shiftTypes={[]}
                fillBySite={[]}
                overtimeTrend={[]}
                dailyCoverage={[
                    {
                        day: 'Mon',
                        date: '2026-05-04',
                        scheduled: 5,
                        filled: 4,
                        open: 1,
                    },
                    {
                        day: 'Tue',
                        date: '2026-05-05',
                        scheduled: 3,
                        filled: 3,
                        open: 0,
                    },
                ]}
            />,
        );

        expect(screen.getByText('Recorded shift starts')).toBeVisible();
        expect(screen.getByText('4/5 assigned')).toBeVisible();
        expect(screen.getByText('1 open')).toBeVisible();
    });

    it('surfaces top-level coverage alerts returned by the controller', () => {
        render(
            <CoveragePane
                stats={[]}
                sites={[]}
                alerts={[
                    {
                        site_name: 'Matai House',
                        rule_name: 'Night cover',
                        window_label: 'Night 23-07',
                        required_staff: 2,
                        assigned_staff: 1,
                        missing_staff: 1,
                        coverage_state: 'gap',
                    },
                ]}
            />,
        );

        expect(
            screen.getByText('Coverage windows needing review'),
        ).toBeVisible();
        expect(screen.getByText('Matai House')).toBeVisible();
        expect(screen.getByText('Night cover')).toBeVisible();
        expect(screen.getByText('1 short')).toBeVisible();
        expect(screen.getByText('1/2 in roster')).toBeVisible();
    });

    it('uses view-scoped empty copy when no pending HR requests were returned', () => {
        render(
            <TimeOffPane
                stats={[]}
                requests={[]}
                weekStart={new Date('2026-05-04T00:00:00')}
                canManage
            />,
        );

        expect(
            screen.getByText('No pending HR requests returned for this view.'),
        ).toBeVisible();
        expect(
            screen.queryByRole('button', { name: /Approve|Decline/ }),
        ).not.toBeInTheDocument();
    });

    it('offers inline actions for resolving an overlapping shift', () => {
        const onUnassign = vi.fn();
        const onReassign = vi.fn();
        const onOpenQueue = vi.fn();

        render(
            <ResolveConflictDialog
                open
                shift={{
                    id: 44,
                    status: 'scheduled',
                    starts_at: '2026-05-04T09:00:00+12:00',
                    ends_at: '2026-05-04T13:00:00+12:00',
                    client: 'Ari Kauri',
                    staff: 'Aroha King',
                    href: '/operations/shifts/44',
                }}
                peers={[
                    {
                        id: 45,
                        status: 'scheduled',
                        starts_at: '2026-05-04T12:00:00+12:00',
                        ends_at: '2026-05-04T16:00:00+12:00',
                        client: 'Mere Rata',
                        staff: 'Aroha King',
                        href: '/operations/shifts/45',
                    },
                ]}
                onOpenChange={vi.fn()}
                onUnassign={onUnassign}
                onReassign={onReassign}
                onOpenQueue={onOpenQueue}
            />,
        );

        expect(screen.getByText('Resolve overlap')).toBeVisible();
        // The explanation names the double-booked staff member, not generic copy.
        expect(screen.getByText(/Aroha King is double-booked/i)).toBeVisible();
        expect(screen.getByText('Ari Kauri')).toBeVisible();
        expect(screen.getByText('Mere Rata')).toBeVisible();

        fireEvent.click(screen.getAllByRole('button', { name: 'Unassign' })[0]);
        expect(onUnassign).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44 }),
        );

        fireEvent.click(screen.getAllByRole('button', { name: 'Reassign' })[1]);
        expect(onReassign).toHaveBeenCalledWith(
            expect.objectContaining({ id: 45 }),
        );

        fireEvent.click(
            screen.getByRole('button', { name: /Open conflict queue/i }),
        );
        expect(onOpenQueue).toHaveBeenCalled();
    });

    it('switches the week grid between week, day and list layouts', () => {
        const rows = [
            {
                id: 7,
                name: 'Aroha King',
                role: null,
                initials: 'AK',
                hue: 120,
                shifts: {
                    '2026-05-04': [
                        {
                            id: 44,
                            status: 'scheduled' as const,
                            starts_at: '2026-05-04T09:00:00',
                            ends_at: '2026-05-04T13:00:00',
                            client: 'Ari Kauri',
                            href: '/operations/shifts/44',
                        },
                    ],
                },
            },
        ];

        render(
            <WeekGridPane
                days={weekDays}
                rows={rows}
                todayKey={null}
                canManage
            />,
        );

        // Default week view shows the staff-row header.
        expect(screen.getByText(/rostered/i)).toBeVisible();

        // List view collapses to a chronological stream with a per-day count.
        fireEvent.click(screen.getByRole('tab', { name: 'List' }));
        expect(screen.getByText('1 shift')).toBeVisible();

        // Day view exposes the single-day stepper controls.
        fireEvent.click(screen.getByRole('tab', { name: 'Day' }));
        expect(screen.getByRole('button', { name: /Prev day/i })).toBeVisible();
        expect(screen.getByRole('button', { name: /Next day/i })).toBeVisible();
    });

    it('regroups the week grid between staff and site rows', () => {
        const cell = [
            {
                id: 44,
                status: 'scheduled' as const,
                starts_at: '2026-05-04T09:00:00',
                ends_at: '2026-05-04T13:00:00',
                client: 'Ari Kauri',
                staff: 'Aroha King',
                href: '/operations/shifts/44',
            },
        ];
        const staffRows = [
            {
                id: 7,
                name: 'Aroha King',
                role: null,
                initials: 'AK',
                hue: 120,
                shifts: { '2026-05-04': cell },
            },
        ];
        const siteRows = [
            {
                id: 3,
                name: 'Matai House',
                role: null,
                initials: 'MH',
                hue: 200,
                shifts: { '2026-05-04': cell },
            },
        ];

        render(
            <WeekGridPane
                days={weekDays}
                rows={staffRows}
                siteRows={siteRows}
                todayKey={null}
                canManage
            />,
        );

        // Defaults to grouping by staff.
        expect(screen.getByText(/Staff ·/i)).toBeVisible();
        expect(screen.getByText('Aroha King')).toBeVisible();

        // Switching to Site regroups the same grid into site rows.
        fireEvent.click(screen.getByRole('tab', { name: 'Site' }));
        expect(screen.getByText(/Sites ·/i)).toBeVisible();
        expect(screen.getByText('Matai House')).toBeVisible();
    });

    it('reassigns from a popup of eligibility-ranked candidates, with an override step for warnings', async () => {
        const onAssign = vi.fn().mockReturnValue(false);
        const originalFetch = global.fetch;
        global.fetch = vi.fn().mockResolvedValue({
            ok: true,
            json: async () => ({
                candidates: [
                    {
                        id: 7,
                        name: 'Aroha King',
                        weekly_hours: 32,
                        is_eligible: true,
                        blocked_reasons: [],
                        warning_reasons: [],
                    },
                    {
                        id: 8,
                        name: 'Tama Rangi',
                        weekly_hours: 12,
                        is_eligible: true,
                        blocked_reasons: [],
                        warning_reasons: ['Tight turnaround under 8h'],
                    },
                    {
                        id: 9,
                        name: 'Mere Ana',
                        weekly_hours: 40,
                        is_eligible: false,
                        blocked_reasons: ['Expired first aid certification'],
                        warning_reasons: [],
                    },
                ].map((candidate) => ({
                    ...candidate,
                    assessment_status: 'assessed',
                    acknowledgement_required:
                        candidate.warning_reasons.length > 0,
                    reason_required: candidate.warning_reasons.length > 0,
                    can_override_eligibility: true,
                })),
                actor_id: 5,
                shift_source: { shift_id: 44, revision: 'a'.repeat(64) },
                shift_display: { id: 44, starts_at: '2026-05-03T21:00:00Z', ends_at: '2026-05-04T01:00:00Z', client: 'Ari Kauri', site: 'Matai House', staff: null, isOpen: true },
                locked: false,
                current_user_id: null,
            }),
        }) as unknown as typeof fetch;

        try {
            render(
                <ReassignDialog
                    open
                    canOverride
                    shift={{
                        id: 44,
                        starts_at: '2026-05-04T09:00:00',
                        ends_at: '2026-05-04T13:00:00',
                        client: 'Ari Kauri',
                        staff: null,
                        isOpen: true,
                    }}
                    onOpenChange={vi.fn()}
                    onAssign={onAssign}
                />,
            );

            // Eligible candidate assigns directly.
            const aroha = await screen.findByRole('button', {
                name: /Aroha King/i,
            });
            fireEvent.click(aroha);
            fireEvent.click(
                screen.getByRole('button', { name: 'Confirm assignment' }),
            );
            expect(onAssign).toHaveBeenCalledWith(44, 7, undefined, expect.objectContaining({
                actorId: 5,
                source: { shift_id: 44, revision: 'a'.repeat(64) },
                display: expect.objectContaining({ id: 44, site: 'Matai House', isOpen: true }),
            }));
            fireEvent.click(screen.getByRole('button', { name: 'Back' }));

            // Blocked candidate cannot be picked.
            expect(
                screen.getByRole('button', { name: /Mere Ana/i }),
            ).toBeDisabled();

            // Warning candidate requires an override reason before assigning.
            fireEvent.click(
                screen.getByRole('button', { name: /Tama Rangi/i }),
            );
            expect(screen.getByText(/has eligibility warnings/i)).toBeVisible();
            fireEvent.change(screen.getByLabelText(/Reason for overriding/i), {
                target: { value: 'Covered by senior on site' },
            });
            fireEvent.click(
                screen.getByRole('button', { name: /Assign anyway/i }),
            );
            expect(onAssign).toHaveBeenCalledWith(
                44,
                8,
                {
                    reason: 'Covered by senior on site',
                },
                expect.objectContaining({
                    actorId: 5,
                    source: { shift_id: 44, revision: 'a'.repeat(64) },
                    display: expect.objectContaining({ id: 44, site: 'Matai House', isOpen: true }),
                }),
            );
        } finally {
            global.fetch = originalFetch;
        }
    });

    it('shows a locked message in the reassign popup for completed shifts', async () => {
        const originalFetch = global.fetch;
        global.fetch = vi.fn().mockResolvedValue({
            ok: true,
            json: async () => ({
                candidates: [],
                actor_id: 5,
                shift_source: { shift_id: 99, revision: 'a'.repeat(64) },
                shift_display: { id: 99, starts_at: '2026-05-03T21:00:00Z', ends_at: '2026-05-04T01:00:00Z', client: 'Ari Kauri', site: 'Matai House', staff: null, isOpen: true },
                current_user_id: null,
                locked: true,
            }),
        }) as unknown as typeof fetch;

        try {
            render(
                <ReassignDialog
                    open
                    shift={{
                        id: 99,
                        starts_at: '2026-05-04T09:00:00',
                        ends_at: '2026-05-04T13:00:00',
                        client: 'Ari Kauri',
                        staff: 'Aroha King',
                    }}
                    onOpenChange={vi.fn()}
                    onAssign={vi.fn()}
                />,
            );

            expect(
                await screen.findByText(
                    /completed or cancelled, so it can no longer be reassigned/i,
                ),
            ).toBeVisible();
        } finally {
            global.fetch = originalFetch;
        }
    });

    it('requests a replacement inline, requiring a reason', () => {
        const onConfirm = vi.fn();

        render(
            <RequestReplacementDialog
                open
                shift={{
                    id: 44,
                    starts_at: '2026-05-04T09:00:00',
                    client: 'Ari Kauri',
                    staff: 'Aroha King',
                }}
                onOpenChange={vi.fn()}
                onConfirm={onConfirm}
            />,
        );

        // The confirm button is disabled until a reason is entered.
        const confirm = screen.getByRole('button', {
            name: /Request replacement/i,
        });
        expect(confirm).toBeDisabled();

        fireEvent.change(screen.getByLabelText(/Reason/i), {
            target: { value: 'Called in sick' },
        });
        expect(confirm).not.toBeDisabled();

        fireEvent.click(confirm);
        expect(onConfirm).toHaveBeenCalledWith(
            expect.objectContaining({ id: 44 }),
            { reason: 'Called in sick', notes: null },
        );
    });
});

describe('availability scanability and scope', () => {
    it('shows every overnight interval without a hover and respects row edit denial', () => {
        render(
            <AvailabilityPane
                canManage
                staff={[
                    {
                        id: 71,
                        name: 'Night worker',
                        email: 'night@example.test',
                        can_manage: false,
                        staff_availability: [
                            {
                                id: 1,
                                day_of_week: 0,
                                start_time: '22:00',
                                end_time: '07:00',
                                ends_next_day: true,
                            },
                            {
                                id: 2,
                                day_of_week: 1,
                                start_time: '10:00',
                                end_time: '13:00',
                                ends_next_day: false,
                            },
                        ],
                    },
                ]}
                upcomingLeave={{}}
            />,
        );
        expect(screen.getByText('22:00–24:00')).toBeVisible();
        expect(screen.getByText('00:00–07:00 (continues)')).toBeVisible();
        expect(screen.getByText('10:00–13:00')).toBeVisible();
        expect(
            screen.queryByRole('button', { name: 'Edit availability' }),
        ).not.toBeInTheDocument();
    });
    it('shows all approved leave entries in the configured worker timezone', () => {
        render(
            <AvailabilityPane
                canManage={false}
                workerTimezone="Pacific/Honolulu"
                staff={[
                    {
                        id: 71,
                        name: 'Worker',
                        email: 'worker@example.test',
                        staff_availability: [],
                    },
                ]}
                upcomingLeave={{
                    71: Array.from({ length: 5 }, (_, i) => ({
                        id: i + 1,
                        leave_type: 'annual_leave',
                        starts_at: `2026-10-${String(i + 6).padStart(2, '0')}T01:00:00Z`,
                        ends_at: `2026-10-${String(i + 6).padStart(2, '0')}T02:00:00Z`,
                        status: 'approved',
                    })),
                }}
            />,
        );
        expect(
            screen.getByText('5 Oct 2026–5 Oct 2026 · annual leave'),
        ).toBeVisible();
        expect(screen.getAllByText(/· annual leave/)).toHaveLength(5);
        expect(screen.queryByText(/more$/)).not.toBeInTheDocument();
    });
});

it('opens the saved roster layout and keeps an explicit in-session layout choice', () => {
    const view = render(
        <WeekGridPane
            days={weekDays}
            rows={[]}
            todayKey={null}
            canManage={false}
            initialView="list"
        />,
    );
    expect(screen.getByRole('tab', { name: 'List' })).toHaveAttribute(
        'aria-selected',
        'true',
    );
    fireEvent.click(screen.getByRole('tab', { name: 'Day' }));
    view.rerender(
        <WeekGridPane
            days={weekDays}
            rows={[]}
            todayKey={null}
            canManage={false}
            initialView="list"
        />,
    );
    expect(screen.getByRole('tab', { name: 'Day' })).toHaveAttribute(
        'aria-selected',
        'true',
    );
});
