import type { Page } from '@inertiajs/core';
import {
    act,
    fireEvent,
    render,
    renderHook,
    screen,
    waitFor,
} from '@testing-library/react';
import { webcrypto } from 'node:crypto';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import ReassignDialog from './reassign-dialog';
import {
    assignmentOutcome,
    type AssignmentAttempt,
} from './shift-assignment-result';
import UnassignMakeOpenDialog from './unassign-make-open-dialog';
import {
    rosterAssignmentReturnTo,
    useShiftAssignment,
} from './use-shift-assignment';

const transport = vi.hoisted(() => ({ post: vi.fn() }));
const notification = vi.hoisted(() => ({ success: vi.fn() }));
vi.mock('@inertiajs/react', () => ({ router: transport }));
vi.mock('sonner', () => ({ toast: notification }));
const source = { shift_id: 44, revision: 'a'.repeat(64) };
const display = { id: 44, starts_at: '2026-05-04T09:00:00+12:00', ends_at: '2026-05-04T13:00:00+12:00', client: 'Ari Kauri', site: 'Matai House', staff: null, isOpen: true };
const context = { actorId: 5, source, display };
const uuid = '5291ca89-c1fd-4a79-82b0-04a70d9b3064';
const expected: AssignmentAttempt = {
    action: 'assign',
    actorId: 5,
    shiftId: 44,
    userId: 7,
    requestId: uuid,
    source,
};
const review = {
    assessment_status: 'assessed',
    acknowledgement_required: true,
    reason_required: false,
    can_override_eligibility: false,
    warning_reasons: ['Review this shift pattern.'],
    blocked_reasons: [],
};
function receipt(overrides: Record<string, unknown> = {}) {
    return {
        version: 1,
        scope: 'single',
        action: 'assign',
        actor_id: 5,
        request_id: uuid,
        shift_id: 44,
        requested_user_id: 7,
        expected_source: source,
        source: { shift_id: 44, revision: 'b'.repeat(64) },
        outcome: 'saved',
        changed: true,
        user_id: 7,
        status: 'scheduled',
        reason: null,
        review: null,
        ...overrides,
    };
}
beforeEach(() => {
    transport.post.mockReset();
    notification.success.mockReset();
    vi.stubGlobal('crypto', webcrypto);
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => ({ actor_id: 5, shift_source: source, shift_display: { ...display, staff: 'Current worker', isOpen: false }, current_user_id: 7, locked: false, candidates: [] }) }));
});
afterEach(() => vi.unstubAllGlobals());
it.each([
    { actor_id: 6 },
    { request_id: 'other-request' },
    { scope: 'bulk' },
    { action: 'unassign' },
    { shift_id: 45 },
    { requested_user_id: 8 },
    { user_id: 8 },
    { expected_source: { shift_id: 44, revision: 'c'.repeat(64) } },
    { source: null },
    { changed: 'yes' },
    { status: 'completed' },
    { outcome: 'confirmed' },
])(
    'never confirms a stale, unrelated or malformed assignment result: %j',
    (changes) => {
        expect(assignmentOutcome(receipt(changes), expected)).toEqual({
            outcome: 'unknown',
        });
    },
);
it('confirms the matching committed worker and retains the legal in-progress status', () => {
    expect(assignmentOutcome(receipt(), expected)).toEqual({
        outcome: 'saved',
    });
    expect(
        assignmentOutcome(receipt({ status: 'in_progress' }), expected),
    ).toEqual({ outcome: 'saved' });
});
it('requires unassignment to confirm both the empty worker and draft status', () => {
    const unassign = { ...expected, action: 'unassign' as const, userId: null };
    const proof = receipt({
        action: 'unassign',
        requested_user_id: null,
        user_id: null,
        status: 'draft',
    });
    expect(assignmentOutcome(proof, unassign)).toEqual({ outcome: 'saved' });
    expect(
        assignmentOutcome({ ...proof, status: 'scheduled' }, unassign),
    ).toEqual({ outcome: 'unknown' });
    expect(assignmentOutcome({ ...proof, user_id: 7 }, unassign)).toEqual({
        outcome: 'unknown',
    });
});
it('requires structured current warnings before offering another attempt', () => {
    const warning = receipt({
        outcome: 'not_saved',
        changed: false,
        reason: 'eligibility_warning',
        review,
    });
    expect(assignmentOutcome(warning, expected)).toMatchObject({
        outcome: 'not_saved',
        review,
    });
    expect(
        assignmentOutcome(
            { ...warning, review: { ...review, reason_required: 'false' } },
            expected,
        ),
    ).toEqual({ outcome: 'unknown' });
    expect(assignmentOutcome({ ...warning, changed: true }, expected)).toEqual({
        outcome: 'unknown',
    });
});
function access(onSaved = vi.fn()) {
    return {
        actorId: 5,
        canManage: true,
        returnTo:
            '/operations/rostering?week=2026-10-12&tab=open&site_id%5B0%5D=3',
        onSaved,
    };
}
type Callbacks = {
    onSuccess: (page: Page) => void;
    onError: () => void;
    onCancel: () => void;
    onFinish: () => void;
};
function sent(index = 0) {
    const [url, payload, callbacks] = transport.post.mock.calls[index];
    return {
        url: url as string,
        payload: payload as {
            request_id: string;
            return_to: string;
            expected_source: typeof source;
        },
        callbacks: callbacks as Callbacks,
    };
}
function response(proof: unknown, actor = 5) {
    return {
        props: {
            canManageAny: true,
            auth: { user: { id: actor } },
            flash: { shift_assignment_result: proof },
        },
    } as unknown as Page;
}
it('posts once while pending and closes only for its exact matching saved response', () => {
    const onSaved = vi.fn(),
        props = access(onSaved);
    const { result } = renderHook(() => useShiftAssignment(props));
    act(() => {
        result.current.assign(44, 7, undefined, context);
        result.current.assign(44, 7, undefined, context);
    });
    expect(transport.post).toHaveBeenCalledTimes(1);
    expect(result.current.forShift(44).pending).toBe(true);
    const call = sent();
    expect(call.payload.return_to).toBe(props.returnTo);
    act(() => {
        const page = response(receipt({ request_id: call.payload.request_id }));
        call.callbacks.onSuccess(page);
        call.callbacks.onSuccess(page);
        call.callbacks.onFinish();
    });
    expect(onSaved).toHaveBeenCalledTimes(1);
    expect(notification.success).toHaveBeenCalledTimes(1);
    expect(result.current.forShift(44)).toMatchObject({
        pending: false,
        uncertain: false,
    });
});
it('keeps a current warning visible and permits only a fresh acknowledged attempt', () => {
    const onSaved = vi.fn(),
        { result } = renderHook(() => useShiftAssignment(access(onSaved)));
    act(() => {
        result.current.assign(44, 7, undefined, context);
    });
    const first = sent();
    act(() => {
        first.callbacks.onSuccess(
            response(
                receipt({
                    request_id: first.payload.request_id,
                    outcome: 'not_saved',
                    changed: false,
                    reason: 'eligibility_warning',
                    review,
                }),
            ),
        );
        first.callbacks.onFinish();
    });
    expect(onSaved).not.toHaveBeenCalled();
    expect(result.current.forShift(44)).toMatchObject({
        pending: false,
        uncertain: false,
        review,
    });
    act(() => {
        result.current.assign(44, 7, { reason: '' }, context);
    });
    expect(transport.post).toHaveBeenCalledTimes(2);
    expect(sent(1).payload.request_id).not.toBe(first.payload.request_id);
});
it.each(['missing', 'network', 'cancel'] as const)(
    'holds an unconfirmed %s result across assign and unassign without replay',
    (kind) => {
        const onSaved = vi.fn(),
            { result } = renderHook(() => useShiftAssignment(access(onSaved)));
        act(() => {
            result.current.assign(44, 7, undefined, context);
        });
        const call = sent();
        act(() => {
            if (kind === 'missing') call.callbacks.onSuccess(response(null));
            else if (kind === 'network') call.callbacks.onError();
            else call.callbacks.onCancel();
            call.callbacks.onFinish();
        });
        expect(onSaved).not.toHaveBeenCalled();
        expect(notification.success).not.toHaveBeenCalled();
        expect(result.current.forShift(44).uncertain).toBe(true);
        act(() => {
            result.current.assign(44, 8, undefined, context);
            result.current.unassign(44, null, context);
        });
        expect(transport.post).toHaveBeenCalledTimes(1);
    },
);
it('ignores a response from a different signed-in actor', () => {
    const onSaved = vi.fn(),
        { result } = renderHook(() => useShiftAssignment(access(onSaved)));
    act(() => {
        result.current.assign(44, 7, undefined, context);
    });
    const call = sent();
    act(() => {
        call.callbacks.onSuccess(
            response(receipt({ request_id: call.payload.request_id }), 6),
        );
        call.callbacks.onFinish();
    });
    expect(onSaved).not.toHaveBeenCalled();
    expect(result.current.forShift(44).uncertain).toBe(true);
});
it('denies missing capability and retains uncertainty when permission is revoked mid-save', () => {
    const onSaved = vi.fn(),
        props = access(onSaved);
    const { result, rerender } = renderHook(
        (input) => useShiftAssignment(input),
        { initialProps: props },
    );
    act(() => {
        result.current.assign(44, 7, undefined, context);
    });
    const call = sent();
    rerender({ ...props, canManage: false });
    act(() => {
        call.callbacks.onSuccess(
            response(receipt({ request_id: call.payload.request_id })),
        );
        call.callbacks.onFinish();
        result.current.assign(44, 7, undefined, context);
    });
    expect(onSaved).not.toHaveBeenCalled();
    expect(transport.post).toHaveBeenCalledTimes(1);
    rerender(props);
    expect(result.current.forShift(44).uncertain).toBe(true);
    act(() => {
        result.current.assign(44, 7, undefined, context);
    });
    expect(transport.post).toHaveBeenCalledTimes(1);
});
it('makes no unassign POST when the current shift source cannot be acquired', async () => {
    vi.stubGlobal(
        'fetch',
        vi.fn().mockResolvedValue({
            ok: true,
            json: async () => ({
                actor_id: 5,
                shift_source: { shift_id: 45, revision: 'a'.repeat(64) },
            }),
        }),
    );
    const { result } = renderHook(() => useShiftAssignment(access()));
    act(() => {
        result.current.unassign(44, 'Worker called in sick', undefined);
    });
    await waitFor(() =>
        expect(result.current.forShift(44).pending).toBe(false),
    );
    expect(transport.post).not.toHaveBeenCalled();
    expect(result.current.forShift(44).uncertain).toBe(false);
});
it('ignores a previous actor save and retains the unresolved attempt when that actor returns', () => {
    const props = access();
    const { result, rerender } = renderHook(
        (input) => useShiftAssignment(input),
        { initialProps: props },
    );
    act(() => {
        result.current.assign(44, 7, undefined, context);
    });
    const call = sent();
    rerender({ ...props, actorId: 6 });
    act(() => {
        call.callbacks.onSuccess(
            response(receipt({ request_id: call.payload.request_id })),
        );
        call.callbacks.onFinish();
    });
    expect(props.onSaved).not.toHaveBeenCalled();
    expect(result.current.forShift(44).uncertain).toBe(false);
    rerender(props);
    expect(result.current.forShift(44).uncertain).toBe(true);
    act(() => {
        result.current.assign(44, 7, undefined, context);
    });
    expect(transport.post).toHaveBeenCalledTimes(1);
});
it('normalises repeated Site filters and excludes mixed or duplicate indexed selections', () => {
    expect(
        rosterAssignmentReturnTo(
            '/operations/rostering?week=2026-10-12&site_id[]=3&site_id[]=4&site_id[]=3',
        ),
    ).toBe(
        '/operations/rostering?week=2026-10-12&site_id%5B0%5D=3&site_id%5B1%5D=4',
    );
    expect(
        rosterAssignmentReturnTo(
            '/operations/rostering?site_id[]=3&site_id[0]=4&tab=open',
        ),
    ).toBe('/operations/rostering?tab=open');
    expect(
        rosterAssignmentReturnTo(
            '/operations/rostering?site_id[0]=3&site_id[0]=4&tab=open',
        ),
    ).toBe('/operations/rostering?tab=open');
});
it('preserves selected week, tab and flat Site filters without external or nested return paths', () => {
    expect(
        rosterAssignmentReturnTo(
            '/operations/rostering?week=2026-10-12&tab=open&site_id%5B0%5D=3&site_id%5B1%5D=4&staff_id=7',
        ),
    ).toBe(
        '/operations/rostering?week=2026-10-12&tab=open&site_id%5B0%5D=3&site_id%5B1%5D=4&staff_id=7',
    );
    expect(
        rosterAssignmentReturnTo('https://elsewhere.test/operations/rostering'),
    ).toBe('/operations/rostering');
    expect(
        rosterAssignmentReturnTo(
            '/operations/rostering?site_id%5Bx%5D%5By%5D=3&tab=unknown',
        ),
    ).toBe('/operations/rostering');
});

const worker = {
    id: 7,
    name: 'Aroha King',
    weekly_hours: 32,
    is_eligible: true,
    blocked_reasons: [],
    warning_reasons: [],
    assessment_status: 'assessed',
    acknowledgement_required: false,
    reason_required: false,
    can_override_eligibility: false,
};
function staffResponse(candidate: Record<string, unknown> = worker, candidates = [candidate]) {
    vi.stubGlobal(
        'fetch',
        vi.fn().mockResolvedValue({
            ok: true,
            json: async () => ({
                candidates,
                current_user_id: null,
                locked: false,
                actor_id: 5,
                shift_source: source,
                shift_display: display,
            }),
        }),
    );
}
const shift = {
    id: 44,
    client: 'Ari Kauri',
    starts_at: '2026-10-12T20:00:00Z',
    ends_at: '2026-10-13T00:00:00Z',
    isOpen: true,
};
it('requires review of a preselected suggested worker before posting', async () => {
    staffResponse();
    const onAssign = vi.fn();
    render(
        <ReassignDialog
            open
            shift={shift}
            initialUserId={7}
            onAssign={onAssign}
            onOpenChange={vi.fn()}
        />,
    );
    const confirm = await screen.findByRole('button', {
        name: 'Confirm assignment',
    });
    expect(onAssign).not.toHaveBeenCalled();
    fireEvent.click(confirm);
    fireEvent.click(confirm);
    expect(onAssign).toHaveBeenCalledTimes(1);
    expect(onAssign).toHaveBeenCalledWith(44, 7, undefined, context);
});
it('keeps a warning with its worker and clears it when the manager chooses a different worker', async () => {
    const first = { ...worker, warning_reasons: ['Initial pattern warning'], acknowledgement_required: true };
    const second = { ...worker, id: 8, name: 'Tama Rangi' };
    staffResponse(first, [first, second]);
    function Workflow() {
        const assignment = useShiftAssignment(access());
        return <ReassignDialog open shift={shift} {...assignment.forShift(44)} onOpenChange={vi.fn()} onCandidateChange={(userId) => assignment.candidateChanged(44, userId)} onAssign={(id, userId, acknowledgement, captured) => assignment.assign(id, userId, acknowledgement, captured)} />;
    }
    render(<Workflow />);
    fireEvent.click(await screen.findByRole('button', { name: /Aroha King/ }));
    fireEvent.click(screen.getByRole('button', { name: 'Confirm assignment' }));
    const call = sent();
    act(() => {
        call.callbacks.onSuccess(response(receipt({ request_id: call.payload.request_id, outcome: 'not_saved', changed: false, reason: 'override_reason_required', review: { ...review, reason_required: true, warning_reasons: ['Worker A needs a specific override'] } })));
        call.callbacks.onFinish();
    });
    expect(screen.getByText('Worker A needs a specific override')).toBeVisible();
    expect(screen.getByRole('button', { name: 'Assign anyway' })).toBeDisabled();
    fireEvent.click(screen.getByRole('button', { name: 'Back' }));
    fireEvent.click(screen.getByRole('button', { name: /Tama Rangi/ }));
    expect(screen.queryByText('Worker A needs a specific override')).not.toBeInTheDocument();
    expect(screen.queryByLabelText(/Reason for overriding/)).not.toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Confirm assignment' })).toBeEnabled();
    fireEvent.click(screen.getByRole('button', { name: 'Confirm assignment' }));
    expect(transport.post).toHaveBeenCalledTimes(2);
    expect(sent(1).payload).toMatchObject({ user_id: 8, expected_source: source });
});
it('shows current canonical details instead of the old list row before assignment', async () => {
    staffResponse();
    const onAssign = vi.fn();
    render(<ReassignDialog open shift={{ ...shift, client: 'Old person', staff: 'Old worker', starts_at: '2026-10-12T20:00:00Z' }} workerTimezone="Pacific/Auckland" onOpenChange={vi.fn()} onAssign={onAssign} />);
    fireEvent.click(await screen.findByRole('button', { name: /Aroha King/ }));
    expect(screen.queryByText(/Old person/)).not.toBeInTheDocument();
    expect(screen.getByText(/Matai House/)).toBeVisible();
    expect(screen.getByText(/4 May/)).toBeVisible();
    fireEvent.click(screen.getByRole('button', { name: 'Confirm assignment' }));
    expect(onAssign).toHaveBeenCalledWith(44, 7, undefined, expect.objectContaining({ source, display }));
});
it('uses the displayed unassignment source without silently fetching a newer revision on Confirm', () => {
    const { result } = renderHook(() => useShiftAssignment(access()));
    const reviewed = { ...context, display: { ...display, staff: 'Current worker', isOpen: false } };
    act(() => { result.current.unassign(44, 'Worker called in sick', reviewed); });
    expect(fetch).not.toHaveBeenCalled();
    expect(sent().payload.expected_source).toEqual(source);
});
it('requires current canonical unassignment details and retains the reason during explicit refresh', async () => {
    const onConfirm = vi.fn().mockReturnValue(false);
    render(<UnassignMakeOpenDialog open shift={{ ...shift, client: 'Old person', staff: 'Old worker' }} workerTimezone="Pacific/Auckland" onOpenChange={vi.fn()} onConfirm={onConfirm} />);
    await waitFor(() => expect(screen.getByRole('button', { name: 'Unassign and make open' })).toBeEnabled());
    expect(screen.queryByText(/Old person|Old worker/)).not.toBeInTheDocument();
    expect(screen.getByText(/Current worker/)).toBeVisible();
    fireEvent.change(screen.getByLabelText('Reason (optional)'), { target: { value: 'Worker called in sick' } });
    fireEvent.click(screen.getByRole('button', { name: 'Refresh shift' }));
    await waitFor(() => expect(screen.getByRole('button', { name: 'Unassign and make open' })).toBeEnabled());
    expect(screen.getByLabelText('Reason (optional)')).toHaveValue('Worker called in sick');
    fireEvent.click(screen.getByRole('button', { name: 'Unassign and make open' }));
    expect(onConfirm).toHaveBeenCalledWith(expect.objectContaining({ staff: 'Current worker', site: 'Matai House' }), 'Worker called in sick', expect.objectContaining({ source, display: expect.objectContaining({ staff: 'Current worker' }) }));
});
it('blocks incomplete canonical shift details before confirmation', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, json: async () => ({ actor_id: 5, shift_source: source, current_user_id: 7, locked: false, candidates: [] }) }));
    const onConfirm = vi.fn();
    render(<UnassignMakeOpenDialog open shift={shift} onOpenChange={vi.fn()} onConfirm={onConfirm} />);
    expect(await screen.findByRole('alert')).toHaveTextContent(/could not be checked/);
    expect(screen.getByRole('button', { name: 'Unassign and make open' })).toBeDisabled();
    expect(onConfirm).not.toHaveBeenCalled();
});
it('lets ordinary warnings be acknowledged without an override grant or reason', async () => {
    staffResponse({
        ...worker,
        warning_reasons: ['Review this shift pattern.'],
        acknowledgement_required: true,
    });
    const onAssign = vi.fn();
    render(
        <ReassignDialog
            open
            shift={shift}
            onAssign={onAssign}
            onOpenChange={vi.fn()}
        />,
    );
    fireEvent.click(await screen.findByRole('button', { name: /Aroha King/ }));
    expect(
        screen.queryByLabelText(/Reason for overriding/),
    ).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'Confirm assignment' }));
    expect(onAssign).toHaveBeenCalledWith(44, 7, { reason: '' }, context);
});
it('requires the exact override permission rather than assuming it', async () => {
    staffResponse({
        ...worker,
        warning_reasons: ['Rest warning'],
        acknowledgement_required: true,
        reason_required: true,
        can_override_eligibility: true,
    });
    render(
        <ReassignDialog
            open
            shift={shift}
            onAssign={vi.fn()}
            onOpenChange={vi.fn()}
        />,
    );
    fireEvent.click(await screen.findByRole('button', { name: /Aroha King/ }));
    fireEvent.change(screen.getByLabelText(/Reason for overriding/), {
        target: { value: 'Senior staff cover' },
    });
    expect(
        screen.getByRole('button', { name: 'Assign anyway' }),
    ).toBeDisabled();
});
it('keeps an unassessed worker unselectable and does not reinterpret absence as eligibility', async () => {
    staffResponse({
        ...worker,
        assessment_status: 'unknown',
        is_eligible: false,
        warning_reasons: ['Eligibility could not be assessed.'],
    });
    render(
        <ReassignDialog
            open
            shift={shift}
            onAssign={vi.fn()}
            onOpenChange={vi.fn()}
        />,
    );
    expect(
        await screen.findByRole('button', { name: /Aroha King/ }),
    ).toBeDisabled();
    expect(screen.getByText('Not assessed')).toBeVisible();
});
it('retains the entered reason after denied unassignment and guards dirty cancellation', async () => {
    const onClose = vi.fn();
    const props = {
        open: true,
        shift,
        onConfirm: vi.fn().mockReturnValue(false),
        onOpenChange: onClose,
    };
    const view = render(<UnassignMakeOpenDialog {...props} />);
    await waitFor(() => expect(screen.getByRole('button', { name: 'Unassign and make open' })).toBeEnabled());
    fireEvent.change(screen.getByLabelText('Reason (optional)'), {
        target: { value: 'Worker called in sick' },
    });
    fireEvent.click(
        screen.getByRole('button', { name: 'Unassign and make open' }),
    );
    view.rerender(
        <UnassignMakeOpenDialog
            {...props}
            error="This shift has started. Use the replacement workflow instead."
        />,
    );
    expect(screen.getByLabelText('Reason (optional)')).toHaveValue(
        'Worker called in sick',
    );
    expect(screen.getByRole('alert')).toBeVisible();
    fireEvent.click(screen.getByRole('button', { name: 'Cancel' }));
    expect(onClose).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole('button', { name: 'Keep editing' }));
    expect(screen.getByLabelText('Reason (optional)')).toHaveValue(
        'Worker called in sick',
    );
});
it('keeps unassignment controls and dismissal locked during the request', () => {
    const onClose = vi.fn();
    render(
        <UnassignMakeOpenDialog
            open
            shift={shift}
            pending
            onConfirm={vi.fn()}
            onOpenChange={onClose}
        />,
    );
    expect(screen.getByRole('button', { name: 'Saving…' })).toBeDisabled();
    expect(screen.getByRole('button', { name: 'Cancel' })).toBeDisabled();
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' });
    expect(onClose).not.toHaveBeenCalled();
});
