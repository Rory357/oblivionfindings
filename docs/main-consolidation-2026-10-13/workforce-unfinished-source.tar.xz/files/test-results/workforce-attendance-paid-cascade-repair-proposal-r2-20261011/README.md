# Inactive break / paid-cascade R2

This sibling preserves the original five-path proposal and its HOLD review. The break suffix now checks retained ownership, status, clock-in/out, break start and both accumulators after normal event observers. The paid command locks and snapshots item identity, run/worker ownership and the complete stored Timesheet membership, then rechecks it after all paid saves. Existing membership extraction, paid replay, normal/legacy quiet saves, authority and transaction behavior remain.

Three added provider cases reach late ordinary model writes: start-event creation changes retained break minutes; end-event save changes retained break count; the second paid save changes payroll-item membership. Each confirms that its normal write occurred and the command rejects/rolls back the whole existing state. The earlier nine cases, existing settlement-route fault control and every original assertion remain. No new fixture events are bypassed.

Only pure file/hash/whole forward-inverse comparisons ran. Twelve new source-derived cases and the extended settlement case remain unrun; actual inventory/count and application/runtime approval are null/false. The same seven-file finite selection must later be framework-listed and tested in an owned isolated schema. Physical root commit/rollback, normal observer behavior, paid replay and process/schema closure require actual acceptance; independent SQL concurrency and durable request idempotence are not claimed.

This correction does not assert full settlement atomicity for unrelated writer paths or change the separate missing Timesheet-amendment HTTP journey, paid-sheet policy, clinical handover or health-and-safety behavior.
