<?php

use App\Domain\Hr\Models\HrAttendanceBreakEvent;
use App\Domain\Hr\Models\HrAttendanceSession;
use App\Models\Role;
use App\Models\User;
use Database\Seeders\RbacSeeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;

beforeEach(function () {
    $this->seed(RbacSeeder::class);

    $this->staff = User::factory()->create([
        'role' => 'support_worker',
        'approved_at' => now(),
    ]);

    $supportRole = Role::query()->where('name', 'support_worker')->first();
    if ($supportRole) {
        $this->staff->roles()->syncWithoutDetaching([$supportRole->id]);
    }

    $this->site = ensureCanonicalHrStaffProfile($this->staff);
});

test('staff can start and end a break on an open attendance session', function () {
    $session = HrAttendanceSession::query()->create([
        'tenant_id' => null,
        'user_id' => $this->staff->id,
        'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(),
        'status' => 'open',
        'source' => 'manual',
        'created_by' => $this->staff->id,
    ]);

    $this->actingAs($this->staff)
        ->post('/attendance/break/start', ['session_id' => $session->id])
        ->assertSessionHas('success');

    $session->refresh();
    expect($session->break_started_at)->not->toBeNull()
        ->and((int) $session->break_count)->toBe(1);

    $this->travel(15)->minutes();

    $this->actingAs($this->staff)
        ->post('/attendance/break/end', ['session_id' => $session->id])
        ->assertSessionHas('success');

    $session->refresh();
    expect($session->break_started_at)->toBeNull()
        ->and((int) $session->break_minutes)->toBeGreaterThanOrEqual(15);

    expect(HrAttendanceBreakEvent::query()->where('session_id', $session->id)->whereNotNull('ended_at')->exists())->toBeTrue();
});

test('staff cannot start a second break while one is already open', function () {
    $session = HrAttendanceSession::query()->create([
        'tenant_id' => null,
        'user_id' => $this->staff->id,
        'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(),
        'break_started_at' => now()->subMinutes(5),
        'status' => 'open',
        'source' => 'manual',
        'created_by' => $this->staff->id,
    ]);

    $this->actingAs($this->staff)
        ->post('/attendance/break/start', ['session_id' => $session->id])
        ->assertSessionHasErrors(['break']);
});

test('break commands recheck closed state under the attendance aggregate lock', function () {
    $session = HrAttendanceSession::query()->create([
        'tenant_id' => null,
        'user_id' => $this->staff->id,
        'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(),
        'clock_out_at' => now(),
        'status' => 'closed',
        'source' => 'manual',
        'created_by' => $this->staff->id,
        'closed_by' => $this->staff->id,
    ]);
    $before = $session->fresh()->getAttributes();

    $this->actingAs($this->staff)
        ->post('/attendance/break/start', ['session_id' => $session->id])
        ->assertSessionHasErrors(['break']);

    expect($session->fresh()->getAttributes())->toBe($before)
        ->and(HrAttendanceBreakEvent::query()->where('session_id', $session->id)->exists())->toBeFalse();
});

test('break start refuses a conflicting open event without creating a duplicate', function () {
    $session = HrAttendanceSession::query()->create([
        'tenant_id' => null,
        'user_id' => $this->staff->id,
        'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(),
        'status' => 'open',
        'source' => 'manual',
        'created_by' => $this->staff->id,
    ]);
    HrAttendanceBreakEvent::query()->create([
        'session_id' => $session->id,
        'started_at' => now()->subMinutes(5),
    ]);

    $this->actingAs($this->staff)
        ->post('/attendance/break/start', ['session_id' => $session->id])
        ->assertSessionHasErrors(['break']);

    $session->refresh();
    expect($session->break_started_at)->toBeNull()
        ->and((int) $session->break_count)->toBe(0)
        ->and(HrAttendanceBreakEvent::query()->where('session_id', $session->id)->count())->toBe(1);
});


function attendanceBreakAtomicState(): array
{
    $state = [];
    foreach (['hr_attendance_sessions', 'hr_attendance_break_events', 'hr_time_entries', 'timesheets', 'audit_logs', 'timeline_events'] as $table) {
        $state[$table] = DB::table($table)->orderBy('id')->get()->map(fn ($row) => (array) $row)->all();
    }

    return $state;
}

test('break start rolls back a vetoed or changed persisted break pair without success', function (string $fault) {
    $session = HrAttendanceSession::query()->create([
        'user_id' => $this->staff->id, 'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(), 'status' => 'open',
        'source' => 'manual', 'created_by' => $this->staff->id,
    ]);
    $this->actingAs($this->staff);
    Queue::fake();
    $before = attendanceBreakAtomicState();
    $original = Model::getEventDispatcher();
    $dispatcher = clone $original;
    $reached = false;
    if ($fault === 'event_veto') {
        $dispatcher->listen('eloquent.creating: '.HrAttendanceBreakEvent::class, function ($event) use ($session, &$reached) {
            if ((int) $event->session_id === (int) $session->id) {
                $reached = true;

                return false;
            }
        });
    } elseif ($fault === 'late_event_session') {
        $dispatcher->listen('eloquent.created: '.HrAttendanceBreakEvent::class, function ($event) use ($session, &$reached) {
            if ((int) $event->session_id === (int) $session->id) {
                $row = HrAttendanceSession::query()->findOrFail($session->id);
                expect($row->update(['break_minutes' => ((int) $row->break_minutes) + 1]))->toBeTrue();
                $reached = true;
            }
        });
    } else {
        $dispatcher->listen('eloquent.updating: '.HrAttendanceSession::class, function ($row) use ($session, $fault, &$reached) {
            if ((int) $row->id === (int) $session->id && $row->isDirty('break_started_at')) {
                $reached = true;
                if ($fault === 'session_veto') {
                    return false;
                }
                $row->break_count = ((int) $row->break_count) + 1;
            }
        });
    }
    Model::setEventDispatcher($dispatcher);
    try {
        $this->post(route('attendance.break.start'), ['session_id' => $session->id])
            ->assertRedirect()->assertSessionHasErrors('break')->assertSessionMissing('success');
    } finally {
        Model::setEventDispatcher($original);
    }
    expect($reached)->toBeTrue()
        ->and(attendanceBreakAtomicState())->toBe($before);
    Queue::assertNothingPushed();
})->with(['session_veto', 'event_veto', 'changed_count', 'late_event_session']);

test('break end rolls back a vetoed or changed persisted break pair without success', function (string $fault) {
    $startedAt = now()->subMinutes(15)->startOfSecond();
    $session = HrAttendanceSession::query()->create([
        'user_id' => $this->staff->id, 'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(), 'status' => 'open',
        'source' => 'manual', 'created_by' => $this->staff->id,
        'break_started_at' => $startedAt, 'break_count' => 1, 'break_minutes' => 5,
    ]);
    HrAttendanceBreakEvent::query()->create([
        'session_id' => $session->id, 'started_at' => $startedAt, 'created_by' => $this->staff->id,
    ]);
    $this->actingAs($this->staff);
    Queue::fake();
    $before = attendanceBreakAtomicState();
    $original = Model::getEventDispatcher();
    $dispatcher = clone $original;
    $reached = false;
    if ($fault === 'event_veto') {
        $dispatcher->listen('eloquent.updating: '.HrAttendanceBreakEvent::class, function ($event) use ($session, &$reached) {
            if ((int) $event->session_id === (int) $session->id && $event->ended_at !== null) {
                $reached = true;

                return false;
            }
        });
    } elseif ($fault === 'late_event_session') {
        $dispatcher->listen('eloquent.saved: '.HrAttendanceBreakEvent::class, function ($event) use ($session, &$reached) {
            if ((int) $event->session_id === (int) $session->id && $event->ended_at !== null) {
                $row = HrAttendanceSession::query()->findOrFail($session->id);
                expect($row->update(['break_count' => ((int) $row->break_count) + 1]))->toBeTrue();
                $reached = true;
            }
        });
    } else {
        $dispatcher->listen('eloquent.updating: '.HrAttendanceSession::class, function ($row) use ($session, $fault, &$reached) {
            if ((int) $row->id === (int) $session->id && $row->isDirty('break_started_at') && $row->break_started_at === null) {
                $reached = true;
                if ($fault === 'session_veto') {
                    return false;
                }
                $row->break_minutes = ((int) $row->break_minutes) + 1;
            }
        });
    }
    Model::setEventDispatcher($dispatcher);
    try {
        $this->post(route('attendance.break.end'), ['session_id' => $session->id])
            ->assertRedirect()->assertSessionHasErrors('break')->assertSessionMissing('success');
    } finally {
        Model::setEventDispatcher($original);
    }
    expect($reached)->toBeTrue()
        ->and(attendanceBreakAtomicState())->toBe($before);
    Queue::assertNothingPushed();
})->with(['session_veto', 'event_veto', 'changed_minutes', 'late_event_session']);

test('clock out rolls back when its active break event save is vetoed', function () {
    $startedAt = now()->subMinutes(15)->startOfSecond();
    $session = HrAttendanceSession::query()->create([
        'user_id' => $this->staff->id, 'site_id' => $this->site->id,
        'clock_in_at' => now()->subHour(), 'status' => 'open',
        'source' => 'manual', 'created_by' => $this->staff->id,
        'break_started_at' => $startedAt, 'break_count' => 1,
    ]);
    HrAttendanceBreakEvent::query()->create([
        'session_id' => $session->id, 'started_at' => $startedAt, 'created_by' => $this->staff->id,
    ]);
    $this->actingAs($this->staff);
    Queue::fake();
    $before = attendanceBreakAtomicState();
    $original = Model::getEventDispatcher();
    $dispatcher = clone $original;
    $reached = false;
    $dispatcher->listen('eloquent.updating: '.HrAttendanceBreakEvent::class, function ($event) use ($session, &$reached) {
        if ((int) $event->session_id === (int) $session->id && $event->ended_at !== null) {
            $reached = true;

            return false;
        }
    });
    Model::setEventDispatcher($dispatcher);
    try {
        $this->post(route('attendance.clockOut'), ['session_id' => $session->id])
            ->assertRedirect()->assertSessionHasErrors('clock_out')
            ->assertSessionMissing('success')->assertSessionMissing('attendance_result');
    } finally {
        Model::setEventDispatcher($original);
    }
    expect($reached)->toBeTrue()
        ->and(attendanceBreakAtomicState())->toBe($before);
    Queue::assertNothingPushed();
});
