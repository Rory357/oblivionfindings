export type AssignmentSource = { shift_id: number; revision: string };
export type AssignmentAction = 'assign' | 'unassign';
export type AssignmentAttempt = {
    action: AssignmentAction;
    actorId: number;
    requestId: string;
    shiftId: number;
    userId: number | null;
    source: AssignmentSource;
};
export type AssignmentReview = {
    assessment_status: 'assessed' | 'unknown';
    acknowledgement_required: boolean;
    reason_required: boolean;
    can_override_eligibility: boolean;
    warning_reasons: string[];
    blocked_reasons: string[];
};
export type AssignmentOutcome =
    | { outcome: 'saved' }
    | { outcome: 'not_saved'; reason: string; review: AssignmentReview | null }
    | { outcome: 'unknown' };

function record(value: unknown): Record<string, unknown> | null {
    return value && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, unknown>)
        : null;
}
export function assignmentSource(
    value: unknown,
    shiftId: number,
): AssignmentSource | null {
    const source = record(value);
    return source?.shift_id === shiftId &&
        typeof source.revision === 'string' &&
        /^[a-f0-9]{64}$/.test(source.revision)
        ? { shift_id: shiftId, revision: source.revision }
        : null;
}
function sameSource(left: AssignmentSource, right: AssignmentSource) {
    return left.shift_id === right.shift_id && left.revision === right.revision;
}
function reviewData(value: unknown): AssignmentReview | null {
    const review = record(value);
    if (
        !review ||
        (review.assessment_status !== 'assessed' &&
            review.assessment_status !== 'unknown') ||
        typeof review.acknowledgement_required !== 'boolean' ||
        typeof review.reason_required !== 'boolean' ||
        typeof review.can_override_eligibility !== 'boolean' ||
        !Array.isArray(review.warning_reasons) ||
        !review.warning_reasons.every((item) => typeof item === 'string') ||
        !Array.isArray(review.blocked_reasons) ||
        !review.blocked_reasons.every((item) => typeof item === 'string')
    )
        return null;
    return {
        assessment_status: review.assessment_status,
        acknowledgement_required: review.acknowledgement_required,
        reason_required: review.reason_required,
        can_override_eligibility: review.can_override_eligibility,
        warning_reasons: review.warning_reasons,
        blocked_reasons: review.blocked_reasons,
    };
}
/** Only the exact correlated server confirmation can settle a roster mutation. */
export function assignmentOutcome(
    value: unknown,
    expected: AssignmentAttempt,
): AssignmentOutcome {
    if (
        !Number.isSafeInteger(expected.actorId) ||
        expected.actorId <= 0 ||
        !Number.isSafeInteger(expected.shiftId) ||
        expected.shiftId <= 0 ||
        !/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(
            expected.requestId,
        ) ||
        !assignmentSource(expected.source, expected.shiftId) ||
        (expected.action === 'assign' &&
            (expected.userId === null ||
                !Number.isSafeInteger(expected.userId) ||
                expected.userId <= 0))
    )
        return { outcome: 'unknown' };
    const receipt = record(value);
    const before = assignmentSource(receipt?.expected_source, expected.shiftId);
    const after = assignmentSource(receipt?.source, expected.shiftId);
    if (
        !receipt ||
        receipt.version !== 1 ||
        receipt.scope !== 'single' ||
        receipt.action !== expected.action ||
        receipt.actor_id !== expected.actorId ||
        receipt.request_id !== expected.requestId ||
        receipt.shift_id !== expected.shiftId ||
        receipt.requested_user_id !== expected.userId ||
        !before ||
        !sameSource(before, expected.source) ||
        !after ||
        typeof receipt.changed !== 'boolean'
    )
        return { outcome: 'unknown' };
    if (
        receipt.outcome === 'saved' &&
        (expected.action === 'assign'
            ? receipt.user_id === expected.userId &&
              ['scheduled', 'in_progress'].includes(String(receipt.status))
            : receipt.user_id === null && receipt.status === 'draft')
    )
        return { outcome: 'saved' };
    if (
        receipt.outcome === 'not_saved' &&
        receipt.changed === false &&
        typeof receipt.reason === 'string' &&
        [
            'eligibility_warning',
            'override_reason_required',
            'locked',
            'in_progress',
            'source_changed',
        ].includes(receipt.reason)
    ) {
        const review = reviewData(receipt.review);
        if (
            ['eligibility_warning', 'override_reason_required'].includes(
                receipt.reason,
            ) &&
            !review
        )
            return { outcome: 'unknown' };
        return { outcome: 'not_saved', reason: receipt.reason, review };
    }
    return { outcome: 'unknown' };
}
