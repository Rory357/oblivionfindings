import { AlertTriangle, Loader2 } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';

import { ConfirmDialog } from '@/components/confirm-dialog';

import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { assignmentDate } from './assignment-time';

export type UnassignMakeOpenShift = {
    id: number;
    starts_at?: string | null;
    client?: string | null;
    staff?: string | null;
};

export type UnassignMakeOpenDialogProps = {
    open: boolean;
    shift: UnassignMakeOpenShift | null;
    pending?: boolean;
    error?: string | null;
    uncertain?: boolean;
    workerTimezone?: string;
    onOpenChange: (open: boolean) => void;
    onConfirm: (
        shift: UnassignMakeOpenShift,
        reason: string | null,
    ) => boolean | void;
};

export function UnassignMakeOpenDialog({
    open,
    shift,
    pending = false,
    error = null,
    uncertain = false,
    workerTimezone,
    onOpenChange,
    onConfirm,
}: UnassignMakeOpenDialogProps) {
    const [reason, setReason] = useState('');
    const [discardOpen, setDiscardOpen] = useState(false);
    const submitted = useRef(false);

    useEffect(() => {
        if (open) {
            setReason('');
            setDiscardOpen(false);
            submitted.current = false;
        }
    }, [open, shift?.id]);

    useEffect(() => {
        if (!pending) submitted.current = false;
    }, [pending]);

    if (!shift) return null;

    const dateLabel = shift.starts_at
        ? assignmentDate(shift.starts_at, workerTimezone)
        : 'this shift';
    const trimmedReason = reason.trim();

    function requestClose() {
        if (pending) return;
        if (trimmedReason) setDiscardOpen(true);
        else onOpenChange(false);
    }

    function submit() {
        if (!shift || pending || uncertain || submitted.current) return;
        submitted.current = true;
        if (onConfirm(shift, trimmedReason || null) === false)
            submitted.current = false;
    }

    return (
        <>
            <Dialog
                open={open}
                onOpenChange={(isOpen) => {
                    if (!isOpen) requestClose();
                }}
            >
                <DialogContent
                    className="max-h-[88dvh] overflow-y-auto"
                    style={{
                        width: 'min(92vw, 480px)',
                        maxWidth: 'min(92vw, 480px)',
                    }}
                >
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <AlertTriangle className="h-5 w-5 text-status-warning" />
                            Unassign and make open
                        </DialogTitle>
                        <DialogDescription>
                            You are about to unassign this shift.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-3 py-2">
                        <div className="rounded-md border border-status-warning/25 bg-status-warning-bg px-3 py-2 text-sm text-status-warning">
                            {dateLabel}
                            {shift.client ? ` · ${shift.client}` : ''}
                            {shift.staff ? ` · currently ${shift.staff}` : ''}
                        </div>
                        <div className="space-y-1.5">
                            <Label
                                htmlFor="unassign-make-open-reason"
                                className="text-sm font-medium"
                            >
                                Reason (optional)
                            </Label>
                            <Textarea
                                id="unassign-make-open-reason"
                                value={reason}
                                onChange={(event) =>
                                    setReason(event.target.value)
                                }
                                rows={4}
                                maxLength={2000}
                                disabled={pending}
                                readOnly={uncertain}
                                placeholder="e.g. Staff called in sick"
                            />
                            <p className="text-xs text-muted-foreground">
                                Not mandatory, but useful for audit and roster
                                handover.
                            </p>
                        </div>
                    </div>
                    {error ? (
                        <p
                            role="alert"
                            className="text-subtle text-status-critical"
                        >
                            {error}
                        </p>
                    ) : null}
                    {uncertain ? (
                        <p className="text-subtle">
                            Check this shift before trying again. The request
                            may already have changed the roster.
                        </p>
                    ) : null}
                    <DialogFooter className="flex-wrap">
                        <Button
                            variant="outline"
                            className="max-md:min-h-[44px]"
                            disabled={pending}
                            onClick={requestClose}
                        >
                            Cancel
                        </Button>
                        <Button
                            variant="destructive"
                            className="h-auto max-w-full whitespace-normal max-md:min-h-[44px]"
                            disabled={pending || uncertain}
                            onClick={submit}
                        >
                            {pending ? (
                                <Loader2
                                    aria-hidden="true"
                                    className="size-4 animate-spin"
                                />
                            ) : null}
                            {pending ? 'Saving…' : 'Unassign and make open'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <ConfirmDialog
                open={discardOpen}
                onClose={() => setDiscardOpen(false)}
                title="Discard this reason?"
                description="Your entered reason will be removed."
                confirmText="Discard reason"
                cancelText="Keep editing"
                buttonClassName="max-md:min-h-[44px]"
                onConfirm={() => {
                    setReason('');
                    setDiscardOpen(false);
                    onOpenChange(false);
                }}
            />
        </>
    );
}

export default UnassignMakeOpenDialog;
