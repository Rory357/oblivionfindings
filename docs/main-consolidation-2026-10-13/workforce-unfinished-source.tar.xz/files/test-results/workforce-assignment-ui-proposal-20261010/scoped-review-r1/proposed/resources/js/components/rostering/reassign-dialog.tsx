import { AlertTriangle, Loader2, Search, UserCheck, Users } from 'lucide-react';
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';

import { ConfirmDialog } from '@/components/confirm-dialog';

import {
    EligibilityStatusBadge,
    deriveEligibilityStatus,
} from '@/components/eligibility/eligibility-status-badge';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { cn } from '@/lib/utils';
import { assignmentRange } from './assignment-time';
import { assignmentSource } from './shift-assignment-result';
import type {
    AssignmentContext,
    AssignmentFeedback,
} from './use-shift-assignment';

export type ReassignShift = {
    id: number;
    starts_at?: string | null;
    ends_at?: string | null;
    client?: string | null;
    /** Current assignee name, when reassigning rather than filling an open shift. */
    staff?: string | null;
    isOpen?: boolean;
};

export type Candidate = {
    id: number;
    name: string;
    email?: string | null;
    weekly_hours: number;
    is_eligible: boolean;
    blocked_reasons: string[];
    warning_reasons: string[];
    has_staff_conflict?: boolean;
    has_time_off?: boolean;
    has_compliance_block?: boolean;
    has_tight_turnaround?: boolean;
    recommended_score?: number;
    acknowledgement_required?: boolean;
    reason_required?: boolean;
    can_override_eligibility?: boolean;
    assessment_status?: 'assessed' | 'unknown';
};

export type ReassignDialogProps = {
    open: boolean;
    shift: ReassignShift | null;
    /** Whether the viewer may override soft eligibility warnings. */
    canOverride?: boolean;
    pending?: boolean;
    error?: string | null;
    uncertain?: boolean;
    review?: AssignmentFeedback['review'];
    initialUserId?: number;
    workerTimezone?: string;
    onChecked?: (context: AssignmentContext) => void;
    onOpenChange: (open: boolean) => void;
    onAssign: (
        shiftId: number,
        userId: number,
        override?: { reason: string },
        context?: AssignmentContext,
    ) => boolean | void;
};

function isCandidate(value: unknown): value is Candidate {
    if (!value || typeof value !== 'object') return false;
    const candidate = value as Record<string, unknown>;
    return (
        typeof candidate.id === 'number' &&
        Number.isSafeInteger(candidate.id) &&
        candidate.id > 0 &&
        typeof candidate.name === 'string' &&
        !!candidate.name.trim() &&
        typeof candidate.weekly_hours === 'number' &&
        Number.isFinite(candidate.weekly_hours) &&
        candidate.weekly_hours >= 0 &&
        typeof candidate.is_eligible === 'boolean' &&
        Array.isArray(candidate.blocked_reasons) &&
        candidate.blocked_reasons.every((item) => typeof item === 'string') &&
        Array.isArray(candidate.warning_reasons) &&
        candidate.warning_reasons.every((item) => typeof item === 'string') &&
        (candidate.assessment_status === 'assessed' ||
            candidate.assessment_status === 'unknown') &&
        typeof candidate.acknowledgement_required === 'boolean' &&
        typeof candidate.reason_required === 'boolean' &&
        typeof candidate.can_override_eligibility === 'boolean'
    );
}

function initials(name: string): string {
    return name
        .split(/\s+/)
        .filter(Boolean)
        .map((w) => w[0]!)
        .slice(0, 2)
        .join('')
        .toUpperCase();
}

export function ReassignDialog({
    open,
    shift,
    canOverride = false,
    pending = false,
    error: assignmentError = null,
    uncertain = false,
    review = null,
    initialUserId,
    workerTimezone,
    onChecked,
    onOpenChange,
    onAssign,
}: ReassignDialogProps) {
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [candidates, setCandidates] = useState<Candidate[]>([]);
    const [currentUserId, setCurrentUserId] = useState<number | null>(null);
    const [query, setQuery] = useState('');
    const [pendingWarn, setPendingWarn] = useState<Candidate | null>(null);
    const [reason, setReason] = useState('');
    const [locked, setLocked] = useState(false);
    const [discardFor, setDiscardFor] = useState<'close' | 'back' | null>(null);
    const submitted = useRef(false);
    const [reload, setReload] = useState(0);
    const [context, setContext] = useState<AssignmentContext | null>(null);
    const opened = useRef<string>('');
    const checked = useRef(onChecked);
    useLayoutEffect(() => {
        checked.current = onChecked;
    }, [onChecked]);

    useEffect(() => {
        if (!pending) submitted.current = false;
    }, [pending]);

    const shiftId = shift?.id ?? null;

    useEffect(() => {
        if (!open || shiftId == null) {
            opened.current = '';
            return;
        }
        let cancelled = false;
        setLoading(true);
        setError(null);
        setCandidates([]);
        setQuery('');
        const key = String(shiftId);
        if (opened.current !== key) {
            setPendingWarn(null);
            setReason('');
            opened.current = key;
        }
        setContext(null);
        setLocked(false);
        setDiscardFor(null);
        submitted.current = false;
        fetch(`/operations/shifts/${shiftId}/candidates`, {
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
            credentials: 'same-origin',
        })
            .then((res) => {
                if (!res.ok) throw new Error(`HTTP ${res.status}`);
                return res.json();
            })
            .then((data) => {
                if (cancelled) return;
                const source = assignmentSource(data.shift_source, shiftId);
                if (
                    !source ||
                    typeof data.actor_id !== 'number' ||
                    !Number.isSafeInteger(data.actor_id) ||
                    data.actor_id <= 0 ||
                    !Array.isArray(data.candidates) ||
                    !data.candidates.every(isCandidate) ||
                    typeof data.locked !== 'boolean'
                ) {
                    throw new Error('Incomplete candidate assessment');
                }
                setCandidates(data.candidates);
                setContext({ actorId: data.actor_id, source });
                checked.current?.({ actorId: data.actor_id, source });
                setPendingWarn(
                    (prior) =>
                        data.candidates.find(
                            (item: Candidate) =>
                                item.id === (prior?.id ?? initialUserId) &&
                                item.assessment_status === 'assessed' &&
                                item.is_eligible,
                        ) ?? null,
                );
                setCurrentUserId(data.current_user_id ?? null);
                setLocked(Boolean(data.locked));
            })
            .catch(() => {
                if (!cancelled) {
                    setError(
                        'Staff checks could not be confirmed. Refresh staff before assigning.',
                    );
                }
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });
        return () => {
            cancelled = true;
        };
    }, [open, shiftId, reload, initialUserId]);

    const filtered = useMemo(() => {
        const q = query.trim().toLowerCase();
        if (!q) return candidates;
        return candidates.filter((c) => c.name.toLowerCase().includes(q));
    }, [candidates, query]);

    if (!shift) return null;

    const isOpenShift = shift.isOpen || currentUserId == null;
    const title = isOpenShift ? 'Assign staff' : 'Reassign shift';

    const pick = (c: Candidate) => {
        const { status } = deriveEligibilityStatus(c);
        if (
            pending ||
            uncertain ||
            submitted.current ||
            status === 'blocked' ||
            c.id === currentUserId ||
            c.assessment_status === 'unknown' ||
            typeof c.is_eligible !== 'boolean'
        )
            return;
        setPendingWarn(c);
        setReason('');
    };

    const warningReview = review ?? pendingWarn;
    const hasWarnings = !!warningReview?.warning_reasons.length;
    const reasonRequired =
        hasWarnings && warningReview?.reason_required !== false;
    const canConfirmWarning =
        !!pendingWarn &&
        !!context &&
        !loading &&
        !pending &&
        !uncertain &&
        warningReview?.assessment_status === 'assessed' &&
        warningReview.blocked_reasons.length === 0 &&
        (!reasonRequired ||
            (canOverride &&
                warningReview?.can_override_eligibility === true &&
                !!reason.trim()));
    const confirmOverride = () => {
        if (!pendingWarn || !canConfirmWarning || submitted.current) return;
        submitted.current = true;
        if (
            onAssign(
                shift.id,
                pendingWarn.id,
                hasWarnings
                    ? { reason: reasonRequired ? reason.trim() : '' }
                    : undefined,
                context ?? undefined,
            ) === false
        )
            submitted.current = false;
    };
    function requestExit(destination: 'close' | 'back') {
        if (pending) return;
        if (reason.trim()) setDiscardFor(destination);
        else if (destination === 'back') {
            setPendingWarn(null);
            setReason('');
        } else onOpenChange(false);
    }

    return (
        <>
            <Dialog
                open={open}
                onOpenChange={(isOpen) => {
                    if (!isOpen) requestExit('close');
                }}
            >
                <DialogContent
                    className="max-h-[88dvh] overflow-y-auto"
                    style={{
                        width: 'min(92vw, 480px)',
                        maxWidth: 'min(92vw, 480px)',
                    }}
                >
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <Users className="h-5 w-5 text-primary" />
                            {title}
                        </DialogTitle>
                        <DialogDescription>
                            {shift.client ? `${shift.client} · ` : ''}
                            {assignmentRange(
                                shift.starts_at,
                                shift.ends_at,
                                workerTimezone,
                            )}
                            {shift.staff && !isOpenShift
                                ? ` · currently ${shift.staff}`
                                : ''}
                        </DialogDescription>
                    </DialogHeader>

                    {pendingWarn && !loading ? (
                        <div className="min-w-0 space-y-3 py-1">
                            <div
                                className={cn(
                                    'rounded-lg border p-3',
                                    hasWarnings
                                        ? 'border-status-warning/30 bg-status-warning-bg/40'
                                        : 'border-border bg-muted/30',
                                )}
                            >
                                <div
                                    className={cn(
                                        'flex items-center gap-2 text-sm font-semibold',
                                        hasWarnings
                                            ? 'text-status-warning'
                                            : 'text-foreground',
                                    )}
                                >
                                    {hasWarnings ? (
                                        <AlertTriangle className="h-4 w-4" />
                                    ) : (
                                        <UserCheck className="h-4 w-4 text-primary" />
                                    )}
                                    {hasWarnings
                                        ? `${pendingWarn.name} has eligibility warnings`
                                        : `Assign ${pendingWarn.name}?`}
                                </div>
                                <ul className="mt-2 list-disc space-y-0.5 pl-5 text-xs text-muted-foreground">
                                    {(warningReview?.warning_reasons ?? []).map(
                                        (r, i) => (
                                            <li key={i}>{r}</li>
                                        ),
                                    )}
                                </ul>
                            </div>
                            {reasonRequired ? (
                                <div className="space-y-1.5">
                                    <label
                                        htmlFor="reassign-reason"
                                        className="text-sm font-medium"
                                    >
                                        Reason for overriding{' '}
                                        <span className="text-status-critical">
                                            *
                                        </span>
                                    </label>
                                    <textarea
                                        id="reassign-reason"
                                        value={reason}
                                        onChange={(e) =>
                                            setReason(e.target.value)
                                        }
                                        rows={3}
                                        maxLength={2000}
                                        disabled={pending}
                                        readOnly={uncertain}
                                        placeholder="Why is this assignment OK despite the warning?"
                                        className="block w-full rounded-md border border-input bg-background px-3 py-2 text-sm focus:border-primary focus:outline-none"
                                    />
                                    {!canOverride ||
                                    warningReview?.can_override_eligibility !==
                                        true ? (
                                        <p className="text-xs text-status-critical">
                                            You may not have permission to
                                            override warnings — this is
                                            re-checked on submit.
                                        </p>
                                    ) : null}
                                </div>
                            ) : (
                                <p className="text-subtle">
                                    {hasWarnings
                                        ? 'Review these warnings before confirming this assignment.'
                                        : 'Confirm this worker for the shift shown above.'}
                                </p>
                            )}
                        </div>
                    ) : locked ? (
                        <div className="py-8 text-center text-sm text-muted-foreground">
                            This shift is completed or cancelled, so it can no
                            longer be reassigned.
                        </div>
                    ) : (
                        <div className="min-w-0 space-y-2 py-1">
                            <div className="relative">
                                <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                                <input
                                    value={query}
                                    onChange={(e) => setQuery(e.target.value)}
                                    placeholder="Search staff…"
                                    className="w-full rounded-md border border-input bg-background py-2 pr-3 pl-9 text-sm focus:border-primary focus:outline-none"
                                />
                            </div>
                            <div className="max-h-[340px] min-w-0 space-y-1 overflow-y-auto">
                                {loading ? (
                                    <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
                                        <Loader2 className="h-4 w-4 animate-spin" />
                                        Loading staff…
                                    </div>
                                ) : error ? (
                                    <div className="py-10 text-center text-sm text-status-critical">
                                        <p>{error}</p>
                                        <Button
                                            variant="outline"
                                            className="mt-3 max-md:min-h-[44px]"
                                            disabled={pending || uncertain}
                                            onClick={() =>
                                                setReload((value) => value + 1)
                                            }
                                        >
                                            Refresh staff
                                        </Button>
                                    </div>
                                ) : filtered.length === 0 ? (
                                    <div className="py-10 text-center text-sm text-muted-foreground">
                                        No staff match.
                                    </div>
                                ) : (
                                    filtered.map((c) => (
                                        <CandidateRow
                                            key={c.id}
                                            candidate={c}
                                            isCurrent={c.id === currentUserId}
                                            disabled={pending || uncertain}
                                            onPick={() => pick(c)}
                                        />
                                    ))
                                )}
                            </div>
                        </div>
                    )}

                    {assignmentError ? (
                        <div>
                            <p
                                role="alert"
                                className="text-subtle text-status-critical"
                            >
                                {assignmentError}
                            </p>
                            {!pending && !uncertain ? (
                                <Button
                                    variant="outline"
                                    className="mt-2 max-md:min-h-[44px]"
                                    onClick={() =>
                                        setReload((value) => value + 1)
                                    }
                                >
                                    Refresh staff
                                </Button>
                            ) : null}
                        </div>
                    ) : null}
                    {uncertain ? (
                        <p className="text-subtle">
                            Check this shift before trying again. The request
                            may already have changed the roster.
                        </p>
                    ) : null}
                    <DialogFooter className="flex-wrap">
                        {pendingWarn ? (
                            <>
                                <Button
                                    variant="ghost"
                                    disabled={pending}
                                    className="max-md:min-h-[44px]"
                                    onClick={() => requestExit('back')}
                                >
                                    Back
                                </Button>
                                <Button
                                    disabled={!canConfirmWarning}
                                    className="max-md:min-h-[44px]"
                                    onClick={confirmOverride}
                                >
                                    {pending ? (
                                        <Loader2
                                            aria-hidden="true"
                                            className="size-4 animate-spin"
                                        />
                                    ) : null}
                                    {pending
                                        ? 'Saving…'
                                        : reasonRequired
                                          ? 'Assign anyway'
                                          : 'Confirm assignment'}
                                </Button>
                            </>
                        ) : (
                            <Button
                                variant="ghost"
                                disabled={pending}
                                className="max-md:min-h-[44px]"
                                onClick={() => requestExit('close')}
                            >
                                Cancel
                            </Button>
                        )}
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <ConfirmDialog
                open={discardFor !== null}
                onClose={() => setDiscardFor(null)}
                title="Discard this reason?"
                description="Your entered reason will be removed."
                confirmText="Discard reason"
                cancelText="Keep editing"
                buttonClassName="max-md:min-h-[44px]"
                onConfirm={() => {
                    const destination = discardFor;
                    setDiscardFor(null);
                    setReason('');
                    if (destination === 'back') setPendingWarn(null);
                    else onOpenChange(false);
                }}
            />
        </>
    );
}

function CandidateRow({
    candidate,
    isCurrent,
    onPick,
    disabled: busy,
}: {
    candidate: Candidate;
    isCurrent: boolean;
    onPick: () => void;
    disabled: boolean;
}) {
    const { status, warningCount } = deriveEligibilityStatus(candidate);
    const blocked = status === 'blocked';
    const unknown =
        candidate.assessment_status === 'unknown' ||
        typeof candidate.is_eligible !== 'boolean';
    const disabled = blocked || isCurrent || busy || unknown;
    const detail =
        candidate.blocked_reasons[0] ?? candidate.warning_reasons[0] ?? null;

    return (
        // eslint-disable-next-line no-restricted-syntax -- candidate list row with avatar + badge layout; not a shadcn Button.
        <button
            type="button"
            disabled={disabled}
            onClick={onPick}
            className={cn(
                'flex min-h-[44px] w-full items-center gap-3 overflow-hidden rounded-md border border-transparent px-2.5 py-2 text-left transition-colors',
                disabled
                    ? 'cursor-not-allowed opacity-60'
                    : 'hover:border-border hover:bg-muted/60',
            )}
        >
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent text-xs font-bold text-primary">
                {initials(candidate.name)}
            </div>
            <div className="min-w-0 flex-1">
                <div className="flex min-w-0 items-center gap-1.5">
                    <span className="truncate text-sm font-medium">
                        {candidate.name}
                    </span>
                    {isCurrent ? (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full bg-primary/10 px-1.5 py-0.5 text-[10px] font-semibold text-primary">
                            <UserCheck className="h-3 w-3" /> Current
                        </span>
                    ) : null}
                </div>
                <div className="truncate text-[11px] text-muted-foreground">
                    {Math.round(candidate.weekly_hours)}h this week
                    {detail ? ` · ${detail}` : ''}
                </div>
            </div>
            {unknown ? (
                <span className="text-subtle">Not assessed</span>
            ) : (
                <EligibilityStatusBadge
                    status={status}
                    warningCount={warningCount}
                    className="shrink-0"
                />
            )}
        </button>
    );
}

export default ReassignDialog;
