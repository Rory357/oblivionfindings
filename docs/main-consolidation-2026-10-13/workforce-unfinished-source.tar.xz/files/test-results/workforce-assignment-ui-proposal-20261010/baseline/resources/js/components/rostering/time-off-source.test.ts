import { describe, expect, it } from 'vitest';

import {
    buildRosterTimeOffRows,
    rosterTimeOffSummary,
    timeOffCalendarDays,
    timeOffCoversWorkerDay,
    timeOffDateSummary,
    type RosterHrLeaveSource,
    type RosterTimeOffSource,
} from './time-off-source';

const approved: RosterHrLeaveSource = {
    id: 23,
    user_id: 7,
    user: 'Aroha',
    status: 'approved',
    leave_type: 'annual',
    starts_at: '2026-10-26T00:00:00+13:00',
    ends_at: '2026-10-27T00:00:00+13:00',
    period: 'full_day',
    hours_requested: 5.25,
    selected_week_hours: 5.25,
};
const block: RosterTimeOffSource = {
    id: 23,
    user_id: 7,
    user: 'Aroha',
    type: 'annual',
    period: 'full_day',
    hr_leave_request_id: 23,
    starts_at: approved.starts_at,
    ends_at: approved.ends_at,
    label: 'Annual leave',
    notes: 'Private review-note sentinel',
};
const window = {
    timezone: 'Pacific/Auckland',
    starts_at: '2026-10-26T00:00:00+13:00',
    ends_at: '2026-11-02T00:00:00+13:00',
    leave_lookahead_ends_at: '2026-11-09T00:00:00+13:00',
};
function rows(
    blocks = [block],
    leave = [approved],
    pending: RosterHrLeaveSource[] = [],
) {
    return buildRosterTimeOffRows({
        blocks,
        approved: leave,
        pending,
        shifts: [],
    });
}

describe('roster leave source presentation', () => {
    it('shows one canonical record when a linked block has the same source and instants', () => {
        const result = rows([{ ...block, starts_at: '2026-10-25T11:00:00Z' }]);
        expect(result).toHaveLength(1);
        expect(result[0]).toMatchObject({
            key: 'hr_leave:23',
            kind: 'approved',
            requestedHours: 5.25,
        });
    });

    it.each([
        ['missing link', { hr_leave_request_id: null }],
        ['other source', { hr_leave_request_id: 24 }],
        ['other worker', { user_id: 8 }],
        ['other type', { type: 'unavailable' }],
        ['other period', { period: 'half_day_am' }],
        ['other start', { starts_at: '2026-10-26T01:00:00+13:00' }],
        ['other end', { ends_at: '2026-10-27T01:00:00+13:00' }],
        ['invalid dates', { starts_at: 'not an instant' }],
    ] as const)(
        'retains a projection with %s instead of hiding a distinct record',
        (_name, changed) => {
            expect(rows([{ ...block, ...changed }])).toHaveLength(2);
        },
    );

    it('does not hide a linked block when the canonical approved source was not returned', () => {
        expect(rows([block], [])).toMatchObject([
            { kind: 'linked_leave', requestedHours: null },
        ]);
    });

    it('never obtains HR reviewer notes from a linked block but retains independent notes', () => {
        const linked = rows([block], [])[0];
        expect(linked.reason).not.toContain('Private review-note sentinel');
        const independent = rows(
            [
                {
                    ...block,
                    hr_leave_request_id: null,
                    label: null,
                    notes: 'School appointment',
                },
            ],
            [],
        )[0];
        expect(independent).toMatchObject({
            kind: 'unavailability',
            reason: 'School appointment',
            requestedHours: null,
        });
    });

    it('retains missing and unexpected canonical statuses as unknown and never makes them actionable', () => {
        const result = rows(
            [block],
            [{ ...approved, status: undefined }],
            [{ ...approved, id: 24, status: 'declined' }],
        );
        expect(result.map((row) => row.kind)).toEqual([
            'linked_leave',
            'unknown',
            'unknown',
        ]);
    });

    it('uses source-prefixed keys even at the old numeric-offset collision boundary', () => {
        const result = rows([
            { ...block, id: 1_000_023, hr_leave_request_id: null },
        ]);
        expect(new Set(result.map((row) => row.key)).size).toBe(2);
    });

    it('keeps stored requested hours separate from selected-week hours and pending requests', () => {
        const result = rows(
            [],
            [{ ...approved, selected_week_hours: null }],
            [
                {
                    ...approved,
                    id: 24,
                    status: 'pending',
                    hours_requested: 99,
                    selected_week_hours: 99,
                },
            ],
        );
        expect(result[0]).toMatchObject({
            requestedHours: 5.25,
            selectedWeekHours: null,
        });
        expect(rosterTimeOffSummary(result, window)).toMatchObject({
            recordedApprovedHours: 0,
            approvedHoursUnknown: 1,
            pendingRequests: 1,
            weekAvailable: true,
        });
    });

    it('excludes lookahead-only hours and never substitutes day counts or unavailability hours', () => {
        const result = rows(
            [{ ...block, hr_leave_request_id: null }],
            [
                approved,
                {
                    ...approved,
                    id: 24,
                    starts_at: '2026-11-03T00:00:00+13:00',
                    ends_at: '2026-11-04T00:00:00+13:00',
                    hours_requested: 8,
                    selected_week_hours: 0,
                },
            ],
        );
        expect(rosterTimeOffSummary(result, window)).toMatchObject({
            recordedApprovedHours: 5.25,
            approvedHoursUnknown: 0,
            independentBlocks: 1,
        });
        expect(rosterTimeOffSummary(result)).toMatchObject({
            weekAvailable: false,
            recordedApprovedHours: 0,
        });
    });

    it('retains zero hours but treats invalid or absent amounts as unknown', () => {
        const result = rows(
            [],
            [
                { ...approved, selected_week_hours: 0 },
                {
                    ...approved,
                    id: 24,
                    hours_requested: -1,
                    selected_week_hours: Number.NaN,
                },
                {
                    ...approved,
                    id: 25,
                    hours_requested: undefined,
                    selected_week_hours: undefined,
                },
            ],
        );
        expect(result.map((row) => row.selectedWeekHours)).toEqual([
            0,
            null,
            null,
        ]);
        expect(result.map((row) => row.requestedHours)).toEqual([
            5.25,
            null,
            null,
        ]);
        expect(rosterTimeOffSummary(result, window).approvedHoursUnknown).toBe(
            2,
        );
    });

    it('counts each overlapping active duty once and excludes completed, cancelled and other staff duties', () => {
        const duty = {
            id: 10,
            user_id: 7,
            starts_at: '2026-10-26T09:00:00+13:00',
            ends_at: '2026-10-26T12:00:00+13:00',
            status: 'scheduled',
        };
        const result = buildRosterTimeOffRows({
            blocks: [{ ...block, hr_leave_request_id: null }],
            approved: [approved],
            pending: [],
            shifts: [
                duty,
                duty,
                { ...duty, id: 11, status: 'completed' },
                { ...duty, id: 12, status: 'cancelled' },
                { ...duty, id: 13, user_id: 8 },
            ],
        });
        expect(result.map((row) => row.impactedShiftIds)).toEqual([[10], [10]]);
        expect(rosterTimeOffSummary(result, window).impactedShiftIds).toEqual([
            10,
        ]);
    });

    it('uses the worker civil day and excludes exact end-midnight without local timestamp parsing', () => {
        expect(timeOffCoversWorkerDay(approved, '2026-10-26')).toBe(true);
        expect(timeOffCoversWorkerDay(approved, '2026-10-25')).toBe(false);
        expect(timeOffCoversWorkerDay(approved, '2026-10-27')).toBe(false);
        expect(timeOffDateSummary({ ...approved, period: 'half_day_am' })).toBe(
            '26 Oct 2026 · morning half day',
        );
    });

    it('covers the DST-shortened NZ day without counting it as a fractional day', () => {
        const dst = {
            starts_at: '2026-09-27T00:00:00+12:00',
            ends_at: '2026-09-28T00:00:00+13:00',
            period: 'half_day_pm',
        };
        expect(timeOffCoversWorkerDay(dst, '2026-09-27')).toBe(true);
        expect(timeOffCoversWorkerDay(dst, '2026-09-28')).toBe(false);
        expect(timeOffDateSummary(dst)).toBe(
            '27 Sep 2026 · afternoon half day',
        );
    });

    it('does not interpret naive timestamps or invalid date strings as a covered day', () => {
        const invalid = {
            starts_at: '2026-10-26T00:00:00',
            ends_at: '2026-10-27T00:00:00',
            period: 'full_day',
        };
        expect(timeOffCoversWorkerDay(invalid, '2026-10-26')).toBe(false);
        expect(timeOffCoversWorkerDay(approved, '2026-02-30')).toBe(false);
        expect(timeOffDateSummary(invalid)).toBe('Dates unavailable');
    });

    it('generates the full fourteen civil dates across month and year boundaries', () => {
        const days = timeOffCalendarDays('2026-12-28');
        expect(days).toHaveLength(14);
        expect(days[0]).toBe('2026-12-28');
        expect(days[13]).toBe('2027-01-10');
        expect(timeOffCalendarDays('2026-02-30')).toEqual([]);
    });
});
