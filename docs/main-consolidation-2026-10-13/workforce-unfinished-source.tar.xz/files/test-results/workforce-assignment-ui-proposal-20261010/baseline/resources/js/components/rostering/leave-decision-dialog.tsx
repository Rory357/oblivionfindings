import { ConfirmDialog } from '@/components/confirm-dialog';
import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Link } from '@inertiajs/react';
import { Loader2 } from 'lucide-react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';

export type RosterLeaveDecision = 'approve' | 'decline';
export type RosterLeaveDecisionTarget = {
    sourceId: number;
    staff: string;
    dateSummary: string;
    impact: number;
};

type LeaveDecisionDialogProps = {
    request: RosterLeaveDecisionTarget | null;
    action: RosterLeaveDecision;
    pending: boolean;
    error: string | null;
    reasonError?: string | null;
    uncertain?: boolean;
    canSubmit: boolean;
    reviewHref?: string;
    onClose: () => void;
    onConfirm: (reviewNotes: string) => boolean | void;
    onReturnFocus?: () => void;
};

export function LeaveDecisionDialog(props: LeaveDecisionDialogProps) {
    const requestClose = useRef(props.onClose);
    return (
        <Dialog
            open={!!props.request}
            onOpenChange={(open) => {
                if (!open) requestClose.current();
            }}
        >
            {props.request ? (
                <LeaveDecisionBody
                    key={`${props.request.sourceId}:${props.action}`}
                    {...props}
                    request={props.request}
                    registerClose={(handler) => {
                        requestClose.current = handler;
                    }}
                />
            ) : null}
        </Dialog>
    );
}

function LeaveDecisionBody({
    request,
    action,
    pending,
    error,
    reasonError,
    uncertain = false,
    canSubmit,
    reviewHref,
    onClose,
    onConfirm,
    onReturnFocus,
    registerClose,
}: Omit<LeaveDecisionDialogProps, 'request'> & {
    request: RosterLeaveDecisionTarget;
    registerClose: (handler: () => void) => void;
}) {
    const [notes, setNotes] = useState('');
    const [discardOpen, setDiscardOpen] = useState(false);
    const submitted = useRef(false);

    useEffect(() => {
        if (!pending) submitted.current = false;
    }, [pending]);

    const decline = action === 'decline';
    const ready =
        canSubmit && !pending && !uncertain && (!decline || !!notes.trim());

    function requestClose() {
        if (pending) return;
        if (notes.trim()) setDiscardOpen(true);
        else onClose();
    }

    useLayoutEffect(() => {
        registerClose(requestClose);
    });

    function confirm() {
        if (!ready || submitted.current) return;
        submitted.current = true;
        if (onConfirm(notes.trim()) === false) submitted.current = false;
    }

    return (
        <>
            <DialogContent
                className="max-h-[88dvh] overflow-y-auto"
                style={{
                    width: 'min(92vw, 480px)',
                    maxWidth: 'min(92vw, 480px)',
                }}
                onCloseAutoFocus={(event) => {
                    if (onReturnFocus) {
                        event.preventDefault();
                        onReturnFocus();
                    }
                }}
            >
                <DialogHeader>
                    <DialogTitle>
                        {decline
                            ? 'Decline leave request'
                            : 'Approve leave request'}
                    </DialogTitle>
                    <DialogDescription>
                        {request.staff} · {request.dateSummary}
                    </DialogDescription>
                </DialogHeader>
                <p className="text-subtle">
                    {decline
                        ? 'The staff member will be told why their request was declined.'
                        : 'Approve this request in HR and mark the staff member as on leave.'}{' '}
                    {request.impact > 0
                        ? `${request.impact} rostered ${request.impact === 1 ? 'shift overlaps' : 'shifts overlap'} this request. Review staffing separately.`
                        : null}
                </p>
                <div className="space-y-2">
                    <Label htmlFor="roster-leave-review-notes">
                        {decline
                            ? 'Reason (required)'
                            : 'Review note (optional)'}
                    </Label>
                    <Textarea
                        id="roster-leave-review-notes"
                        value={notes}
                        onChange={(event) => setNotes(event.target.value)}
                        maxLength={2000}
                        rows={4}
                        disabled={pending}
                        readOnly={uncertain}
                        aria-describedby={
                            reasonError
                                ? 'roster-leave-review-help roster-leave-reason-error'
                                : 'roster-leave-review-help'
                        }
                        aria-invalid={!!reasonError}
                    />
                    <p id="roster-leave-review-help" className="text-caption">
                        The staff member can see this note.
                    </p>
                    {reasonError ? (
                        <p
                            id="roster-leave-reason-error"
                            role="alert"
                            className="text-subtle text-status-critical!"
                        >
                            {reasonError}
                        </p>
                    ) : null}
                </div>
                {error ? (
                    <p
                        role="alert"
                        className="text-subtle text-status-critical!"
                    >
                        {error}
                    </p>
                ) : null}
                {uncertain ? (
                    <div className="space-y-2 rounded-md border border-border p-3">
                        <p className="text-subtle">
                            The result could not be confirmed. Check the request
                            before trying again.
                        </p>
                        {reviewHref ? (
                            <Button
                                asChild
                                variant="outline"
                                className="max-md:min-h-[44px]"
                            >
                                <Link
                                    href={reviewHref}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Check request in HR (new tab)
                                </Link>
                            </Button>
                        ) : null}
                    </div>
                ) : null}
                <DialogFooter className="flex-wrap">
                    <Button
                        variant="outline"
                        className="h-auto min-h-[44px] max-w-full whitespace-normal"
                        disabled={pending}
                        onClick={requestClose}
                    >
                        Cancel
                    </Button>
                    <Button
                        variant={decline ? 'destructive' : 'default'}
                        className="max-md:min-h-[44px]"
                        disabled={!ready}
                        onClick={confirm}
                    >
                        {pending ? (
                            <Loader2
                                aria-hidden="true"
                                className="size-4 animate-spin"
                            />
                        ) : null}
                        {pending
                            ? 'Saving…'
                            : decline
                              ? 'Decline request'
                              : 'Approve request'}
                    </Button>
                </DialogFooter>
            </DialogContent>
            <ConfirmDialog
                open={discardOpen}
                onClose={() => setDiscardOpen(false)}
                title="Discard this review note?"
                description="Your entered note will be removed."
                confirmText="Discard note"
                cancelText="Keep editing"
                buttonClassName="max-md:min-h-[44px]"
                onConfirm={() => {
                    setNotes('');
                    setDiscardOpen(false);
                    onClose();
                }}
            />
        </>
    );
}
