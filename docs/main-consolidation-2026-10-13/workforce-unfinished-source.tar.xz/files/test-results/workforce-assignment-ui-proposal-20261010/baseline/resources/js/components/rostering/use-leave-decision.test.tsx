import type { Page } from '@inertiajs/core';
import { act, renderHook } from '@testing-library/react';
import { webcrypto } from 'node:crypto';
import { afterEach, beforeEach, expect, it, vi } from 'vitest';
import type { RosterTimeOffRow } from './time-off-source';
import { leaveDecisionReceipt, useLeaveDecision } from './use-leave-decision';

const transport = vi.hoisted(() => ({ post: vi.fn() }));
vi.mock('@inertiajs/react', () => ({ router: transport }));
const uuid = '5291ca89-c1fd-4a79-82b0-04a70d9b3064';
const identity = {
    actorId: 5,
    sourceId: 12,
    action: 'decline' as const,
    requestId: uuid,
};
const row: RosterTimeOffRow = {
    key: 'hr_leave:12',
    source: 'hr_leave',
    sourceId: 12,
    userId: 8,
    staff: 'Test worker',
    reason: 'Personal leave',
    type: 'annual',
    period: 'full_day',
    starts_at: '2026-11-08T20:00:00Z',
    ends_at: '2026-11-09T04:00:00Z',
    kind: 'pending',
    requestedHours: 8,
    selectedWeekHours: 8,
    impactedShiftIds: [21],
};
const access = { actorId: 5, canReview: true, requests: [row] };
function receipt(overrides: Record<string, unknown> = {}) {
    return {
        version: 1,
        scope: 'leave_review',
        action: 'decline',
        actor_id: 5,
        leave_request_id: 12,
        request_id: uuid,
        outcome: 'confirmed',
        saved: {
            status: 'declined',
            reviewed_by: 5,
            reviewed_at: '2026-10-10T05:00:00Z',
            time_off_id: null,
        },
        committed_at: '2026-10-10T05:00:01Z',
        ...overrides,
    };
}
type Callbacks = {
    onSuccess: (page: Page) => void;
    onError: (errors: Record<string, string>) => void;
    onCancel: () => void;
    onFinish: () => void;
};
function sent() {
    const [url, payload, callbacks] = transport.post.mock.calls[0];
    return {
        url: url as string,
        payload: payload as { request_id: string; review_notes: string },
        callbacks: callbacks as Callbacks,
    };
}
function page(flash: unknown, actor = 5) {
    return {
        props: { auth: { user: { id: actor } }, flash },
    } as unknown as Page;
}
beforeEach(() => {
    vi.clearAllMocks();
    vi.stubGlobal('crypto', webcrypto);
});
afterEach(() => vi.unstubAllGlobals());

it('accepts only the current physical decision receipt and retains a separate post-commit error', () => {
    expect(
        leaveDecisionReceipt({ leave_review_result: receipt() }, identity)
            .status,
    ).toBe('confirmed');
    expect(
        leaveDecisionReceipt(
            { leave_review_result: receipt(), error: 'Webhook unavailable' },
            identity,
        ),
    ).toEqual({
        status: 'confirmed',
        message: 'Leave request declined.',
        warning: 'Webhook unavailable',
    });
    expect(
        leaveDecisionReceipt(
            {
                leave_review_result: receipt({
                    saved: {
                        status: 'declined',
                        reviewed_by: 5,
                        reviewed_at: '2026-10-10T05:00:00Z',
                        time_off_id: 71,
                    },
                }),
            },
            identity,
        ).status,
    ).toBe('confirmed');
});
it.each([
    { version: 2 },
    { scope: 'bulk' },
    { action: 'approve' },
    { actor_id: 6 },
    { leave_request_id: 13 },
    { request_id: 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa' },
    { outcome: 'not_confirmed' },
    { committed_at: null },
    { committed_at: '2026-10-10T05:00:00' },
    {
        saved: {
            status: 'approved',
            reviewed_by: 5,
            reviewed_at: '2026-10-10T05:00:00Z',
            time_off_id: 71,
        },
    },
    {
        saved: {
            status: 'declined',
            reviewed_by: 6,
            reviewed_at: '2026-10-10T05:00:00Z',
            time_off_id: null,
        },
    },
    {
        saved: {
            status: 'declined',
            reviewed_by: 5,
            reviewed_at: 'invalid',
            time_off_id: null,
        },
    },
    {
        saved: {
            status: 'declined',
            reviewed_by: 5,
            reviewed_at: '2026-10-10T05:00:00Z',
            time_off_id: 0,
        },
    },
])('holds uncertainty for mismatched receipt %j', (mismatch) => {
    expect(
        leaveDecisionReceipt(
            { leave_review_result: receipt(mismatch) },
            identity,
        ).status,
    ).toBe('unknown');
});
it('requires a real approved projection and never infers a save from legacy flash', () => {
    const expected = { ...identity, action: 'approve' as const };
    const saved = {
        status: 'approved',
        reviewed_by: 5,
        reviewed_at: '2026-10-10T05:00:00Z',
        time_off_id: 71,
    };
    expect(
        leaveDecisionReceipt(
            { leave_review_result: receipt({ action: 'approve', saved }) },
            expected,
        ).status,
    ).toBe('confirmed');
    expect(
        leaveDecisionReceipt(
            {
                leave_review_result: receipt({
                    action: 'approve',
                    saved: { ...saved, time_off_id: null },
                }),
            },
            expected,
        ).status,
    ).toBe('unknown');
    for (const flash of [
        { success: 'Approved' },
        { error: 'Not saved' },
        {},
        null,
    ])
        expect(leaveDecisionReceipt(flash, identity).status).toBe('unknown');
});
it.each([
    { ...access, canReview: false },
    { ...access, actorId: undefined },
    { ...access, requests: [{ ...row, kind: 'approved' as const }] },
    { ...access, requests: [{ ...row, source: 'staff_time_off' as const }] },
    { ...access, requests: [] },
])(
    'denies a missing capability, actor or current pending canonical source',
    (props) => {
        const { result } = renderHook(() => useLeaveDecision(props));
        act(() => {
            result.current.open(row, 'decline');
            result.current.submit('Reason');
        });
        expect(result.current.selection).toBeNull();
        expect(transport.post).not.toHaveBeenCalled();
    },
);
it('validates required/length notes locally, sends one immutable request and preserves current navigation', () => {
    const { result } = renderHook(() => useLeaveDecision(access));
    act(() => result.current.open(row, 'decline'));
    act(() => result.current.submit('  '));
    expect(result.current.outcome).toMatchObject({
        status: 'rejected',
        reasonError: expect.any(String),
    });
    act(() => result.current.submit('x'.repeat(2001)));
    expect(transport.post).not.toHaveBeenCalled();
    act(() => {
        result.current.submit('  Staffing needs review  ');
        result.current.submit('Second click');
        result.current.close();
    });
    const { url, payload } = sent();
    expect(url).toBe('/hr/leave/12/decline');
    expect(payload.review_notes).toBe('Staffing needs review');
    expect(payload.request_id).toMatch(/^[0-9a-f-]{36}$/);
    expect(payload).not.toHaveProperty('return_to');
    expect(transport.post).toHaveBeenCalledTimes(1);
    expect(result.current.pending).toBe(true);
    expect(result.current.selection?.request.sourceId).toBe(12);
});
it('allows a reviewed optional approval note and closes only after a bound confirmed response', () => {
    const { result } = renderHook(() => useLeaveDecision(access));
    act(() => result.current.open(row, 'approve'));
    act(() => result.current.submit(''));
    const { callbacks, payload } = sent();
    act(() => {
        callbacks.onSuccess(
            page({
                leave_review_result: receipt({
                    action: 'approve',
                    request_id: payload.request_id,
                    saved: {
                        status: 'approved',
                        reviewed_by: 5,
                        reviewed_at: '2026-10-10T05:00:00Z',
                        time_off_id: 71,
                    },
                }),
            }),
        );
        callbacks.onFinish();
    });
    expect(result.current.outcome?.status).toBe('confirmed');
    expect(result.current.selection).toBeNull();
    expect(result.current.pending).toBe(false);
});
it('retains validation errors and permits a distinct corrected attempt', () => {
    const { result } = renderHook(() => useLeaveDecision(access));
    act(() => result.current.open(row, 'decline'));
    act(() => result.current.submit('Reason'));
    const first = sent();
    act(() => {
        first.callbacks.onError({ review_notes: 'Add more detail' });
        first.callbacks.onFinish();
    });
    expect(result.current.selection).not.toBeNull();
    expect(result.current.outcome).toMatchObject({
        status: 'rejected',
        reasonError: 'Add more detail',
    });
    act(() => result.current.submit('Updated reason'));
    expect(transport.post).toHaveBeenCalledTimes(2);
    expect(transport.post.mock.calls[1][1].request_id).not.toBe(
        first.payload.request_id,
    );
});
it.each(['legacy', 'wrong_actor', 'business_error', 'cancel', 'finish_only'])(
    'keeps %s uncertain and prevents replay even after closing and reopening',
    (response) => {
        const { result } = renderHook(() => useLeaveDecision(access));
        act(() => result.current.open(row, 'decline'));
        act(() => result.current.submit('Reason'));
        const { callbacks, payload } = sent();
        act(() => {
            if (response === 'legacy')
                callbacks.onSuccess(page({ success: 'Declined' }));
            if (response === 'wrong_actor')
                callbacks.onSuccess(
                    page(
                        {
                            leave_review_result: receipt({
                                request_id: payload.request_id,
                            }),
                        },
                        6,
                    ),
                );
            if (response === 'business_error')
                callbacks.onSuccess(page({ error: 'Request changed' }));
            if (response === 'cancel') callbacks.onCancel();
            callbacks.onFinish();
        });
        expect(result.current.outcome?.status).toBe('unknown');
        expect(result.current.selection).not.toBeNull();
        act(() => {
            result.current.submit('Replay');
            result.current.close();
            result.current.open(row, 'approve');
        });
        expect(result.current.outcome?.status).toBe('unknown');
        act(() => result.current.submit('Opposite action'));
        expect(transport.post).toHaveBeenCalledTimes(1);
    },
);
it('purges private selection when review access changes and ignores a late response', () => {
    const { result, rerender } = renderHook(
        (props) => useLeaveDecision(props),
        { initialProps: access },
    );
    act(() => result.current.open(row, 'decline'));
    act(() => result.current.submit('Private note'));
    const { callbacks, payload } = sent();
    rerender({ ...access, canReview: false });
    expect(result.current.selection).toBeNull();
    act(() => {
        callbacks.onSuccess(
            page({
                leave_review_result: receipt({
                    request_id: payload.request_id,
                }),
            }),
        );
        callbacks.onFinish();
    });
    expect(result.current.outcome).toBeNull();
    expect(result.current.pending).toBe(false);
});
it('denies submission after the returned canonical request changed', () => {
    const { result, rerender } = renderHook(
        (props) => useLeaveDecision(props),
        { initialProps: access },
    );
    act(() => result.current.open(row, 'decline'));
    rerender({ ...access, requests: [] });
    act(() => result.current.submit('Reason'));
    expect(result.current.canSubmit).toBe(false);
    expect(transport.post).not.toHaveBeenCalled();
    expect(result.current.outcome?.status).toBe('rejected');
});
