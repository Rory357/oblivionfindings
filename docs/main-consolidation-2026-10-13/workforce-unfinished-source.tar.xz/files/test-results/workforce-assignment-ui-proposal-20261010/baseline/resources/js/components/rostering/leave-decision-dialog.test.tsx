import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, expect, it, vi } from 'vitest';
import { LeaveDecisionDialog } from './leave-decision-dialog';

vi.mock('@inertiajs/react', () => ({
    Link: (props: React.ComponentProps<'a'>) => <a {...props} />,
}));
const request = {
    sourceId: 12,
    staff: 'Test worker',
    dateSummary: '9 Nov 2026 · Morning',
    impact: 1,
};
const confirm = vi.fn(),
    close = vi.fn();
const props = {
    request,
    action: 'decline' as const,
    pending: false,
    error: null,
    canSubmit: true,
    onClose: close,
    onConfirm: confirm,
};
beforeEach(() => vi.clearAllMocks());

it('requires a non-whitespace decline reason and prevents same-turn duplicate confirmation', () => {
    render(<LeaveDecisionDialog {...props} />);
    const field = screen.getByLabelText('Reason (required)');
    const submit = screen.getByRole('button', { name: 'Decline request' });
    expect(submit.hasAttribute('disabled')).toBe(true);
    fireEvent.change(field, { target: { value: '  ' } });
    expect(submit.hasAttribute('disabled')).toBe(true);
    fireEvent.change(field, { target: { value: ' Staffing needs review ' } });
    fireEvent.click(submit);
    fireEvent.click(submit);
    expect(confirm).toHaveBeenCalledExactlyOnceWith('Staffing needs review');
    expect(field.getAttribute('maxlength')).toBe('2000');
    expect(screen.getByText(/Review staffing separately/)).toBeTruthy();
});
it('retains the entered note on a server error and separates field errors from general errors', () => {
    const view = render(<LeaveDecisionDialog {...props} />);
    fireEvent.change(screen.getByLabelText('Reason (required)'), {
        target: { value: 'Keep this reason' },
    });
    view.rerender(
        <LeaveDecisionDialog
            {...props}
            error="Access changed"
            reasonError="Add more detail"
        />,
    );
    const field = screen.getByLabelText(
        'Reason (required)',
    ) as HTMLTextAreaElement;
    expect(field.value).toBe('Keep this reason');
    expect(field.getAttribute('aria-invalid')).toBe('true');
    expect(screen.getByText('Add more detail')).toBeTruthy();
    view.rerender(<LeaveDecisionDialog {...props} error="Access changed" />);
    expect(field.getAttribute('aria-invalid')).toBe('false');
});
it('keeps dirty notes after Keep editing and discards only after explicit confirmation', () => {
    render(<LeaveDecisionDialog {...props} />);
    fireEvent.change(screen.getByLabelText('Reason (required)'), {
        target: { value: 'Private review note' },
    });
    fireEvent.click(screen.getByRole('button', { name: /^Cancel$/ }));
    expect(screen.getByRole('alertdialog')).toBeTruthy();
    fireEvent.click(screen.getByRole('button', { name: 'Keep editing' }));
    expect(
        (screen.getByLabelText('Reason (required)') as HTMLTextAreaElement)
            .value,
    ).toBe('Private review note');
    expect(close).not.toHaveBeenCalled();
    fireEvent.click(screen.getByRole('button', { name: /^Cancel$/ }));
    fireEvent.click(screen.getByRole('button', { name: 'Discard note' }));
    expect(close).toHaveBeenCalledTimes(1);
});
it('blocks close/submission while saving and retains uncertain notes without a retry action', () => {
    const view = render(<LeaveDecisionDialog {...props} />);
    fireEvent.change(screen.getByLabelText('Reason (required)'), {
        target: { value: 'Keep after timeout' },
    });
    view.rerender(<LeaveDecisionDialog {...props} pending />);
    fireEvent.keyDown(screen.getByRole('dialog'), { key: 'Escape' });
    expect(close).not.toHaveBeenCalled();
    expect(
        screen
            .getByRole('button', { name: 'Saving…' })
            .hasAttribute('disabled'),
    ).toBe(true);
    view.rerender(
        <LeaveDecisionDialog {...props} uncertain error="Result unknown" />,
    );
    expect(
        (screen.getByLabelText('Reason (required)') as HTMLTextAreaElement)
            .value,
    ).toBe('Keep after timeout');
    expect(
        screen
            .getByRole('button', { name: 'Decline request' })
            .hasAttribute('disabled'),
    ).toBe(true);
    expect(
        screen.queryByRole('link', { name: /Check request in HR/ }),
    ).toBeNull();
    view.rerender(
        <LeaveDecisionDialog {...props} uncertain reviewHref="/hr/leave/12" />,
    );
    expect(
        screen
            .getByRole('link', { name: /Check request in HR/ })
            .getAttribute('target'),
    ).toBe('_blank');
});
it('resets private notes between requests and restores caller-owned focus on close', async () => {
    const returnFocus = vi.fn();
    const view = render(
        <LeaveDecisionDialog {...props} onReturnFocus={returnFocus} />,
    );
    fireEvent.change(screen.getByLabelText('Reason (required)'), {
        target: { value: 'First request note' },
    });
    view.rerender(
        <LeaveDecisionDialog
            {...props}
            request={{ ...request, sourceId: 13 }}
            onReturnFocus={returnFocus}
        />,
    );
    expect(
        (screen.getByLabelText('Reason (required)') as HTMLTextAreaElement)
            .value,
    ).toBe('');
    await waitFor(() => expect(returnFocus).toHaveBeenCalled());
    returnFocus.mockClear();
    view.rerender(
        <LeaveDecisionDialog
            {...props}
            request={null}
            onReturnFocus={returnFocus}
        />,
    );
    expect(screen.queryByRole('dialog')).toBeNull();
    await waitFor(() => expect(returnFocus).toHaveBeenCalledTimes(1));
});
it('allows the optional approval note only with current review authority', () => {
    const view = render(
        <LeaveDecisionDialog {...props} action="approve" canSubmit={false} />,
    );
    expect(
        screen
            .getByRole('button', { name: 'Approve request' })
            .hasAttribute('disabled'),
    ).toBe(true);
    view.rerender(<LeaveDecisionDialog {...props} action="approve" />);
    fireEvent.click(screen.getByRole('button', { name: 'Approve request' }));
    expect(confirm).toHaveBeenCalledExactlyOnceWith('');
});

it('allows another reviewed confirmation when preparation was explicitly rejected before dispatch', () => {
    const notSent = vi.fn(() => false);
    render(<LeaveDecisionDialog {...props} onConfirm={notSent} />);
    fireEvent.change(screen.getByLabelText('Reason (required)'), {
        target: { value: 'Keep this reason' },
    });
    fireEvent.click(screen.getByRole('button', { name: 'Decline request' }));
    fireEvent.click(screen.getByRole('button', { name: 'Decline request' }));
    expect(notSent).toHaveBeenCalledTimes(2);
    expect(
        (screen.getByLabelText('Reason (required)') as HTMLTextAreaElement)
            .value,
    ).toBe('Keep this reason');
});
