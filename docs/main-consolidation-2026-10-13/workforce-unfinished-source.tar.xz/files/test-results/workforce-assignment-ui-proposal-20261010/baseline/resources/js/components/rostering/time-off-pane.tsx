import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/status-badge';
import { formatDateOnly, toDateInput, WORKER_TIMEZONE } from '@/lib/datetime';
import { Link } from '@inertiajs/react';
import { Check, Clock3, ExternalLink, Minus } from 'lucide-react';

import { avatarHueStyle } from './avatar-hue';
import { MicroStats, type MicroStat } from './micro-stats';
import {
    timeOffCalendarDays,
    timeOffCoversWorkerDay,
    timeOffDateSummary,
    type RosterTimeOffRow,
    type RosterTimeOffWindow,
} from './time-off-source';

export type TimeOffRequest = RosterTimeOffRow & {
    initials: string;
    hue: number;
};

export type TimeOffPaneProps = {
    stats: MicroStat[];
    requests: TimeOffRequest[];
    weekStart: Date;
    window?: RosterTimeOffWindow;
    canManage: boolean;
    /** Already authorised by the owning page; absent means no HR navigation. */
    hrApprovalsHref?: string;
    decisionPending?: boolean;
    onApprove?: (req: TimeOffRequest) => void;
    onDecline?: (req: TimeOffRequest) => void;
};

const kindLabel = {
    unavailability: 'Staff unavailability',
    linked_leave: 'Linked leave block',
    approved: 'Approved leave',
    pending: 'Pending request',
    unknown: 'Status unavailable',
} as const;

export function TimeOffPane({
    stats,
    requests,
    weekStart,
    window,
    canManage,
    hrApprovalsHref,
    decisionPending = false,
    onApprove,
    onDecline,
}: TimeOffPaneProps) {
    const timezone = window?.timezone || WORKER_TIMEZONE;
    const firstDay = window
        ? toDateInput(window.starts_at, timezone)
        : `${weekStart.getFullYear()}-${String(weekStart.getMonth() + 1).padStart(2, '0')}-${String(weekStart.getDate()).padStart(2, '0')}`;
    const days14 = timeOffCalendarDays(firstDay);
    const pending = requests.filter(
        (row) => row.source === 'hr_leave' && row.kind === 'pending',
    );

    return (
        <div className="min-w-0 space-y-4">
            <MicroStats stats={stats} />
            <div className="grid min-w-0 gap-4 xl:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
                <section className="min-w-0 rounded-[14px] border border-border bg-card p-4 shadow-sm">
                    <div className="mb-3 flex min-w-0 flex-wrap items-start justify-between gap-2">
                        <div className="min-w-0">
                            <h3
                                id="time-off-review-heading"
                                tabIndex={-1}
                                className="text-section-title"
                            >
                                Pending requests
                            </h3>
                            <p className="text-caption">
                                {pending.length === 0
                                    ? 'No pending HR requests returned for this view.'
                                    : 'Review the request before deciding.'}
                            </p>
                        </div>
                        {canManage && hrApprovalsHref && pending.length > 0 ? (
                            <Button
                                asChild
                                variant="outline"
                                size="sm"
                                className="max-md:min-h-[44px]"
                            >
                                <Link
                                    href={hrApprovalsHref}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <ExternalLink className="size-4" />
                                    Review in HR
                                    <span className="sr-only"> (new tab)</span>
                                </Link>
                            </Button>
                        ) : null}
                    </div>
                    {pending.length === 0 ? (
                        <p className="text-subtle rounded-md border border-dashed border-border p-4">
                            No pending leave requests.
                        </p>
                    ) : null}
                    <div className="space-y-2">
                        {pending.map((request) => (
                            <article
                                key={request.key}
                                className="grid min-w-0 items-start gap-3 rounded-md border border-border p-3 md:grid-cols-[minmax(0,160px)_minmax(0,1fr)_auto]"
                            >
                                <div className="flex min-w-0 items-center gap-2.5">
                                    <span
                                        aria-hidden="true"
                                        className="flex size-9 shrink-0 items-center justify-center rounded-full font-semibold"
                                        style={avatarHueStyle(request.hue)}
                                    >
                                        {request.initials}
                                    </span>
                                    <div className="min-w-0 [overflow-wrap:anywhere]">
                                        <p className="text-subtle font-semibold">
                                            {request.staff}
                                        </p>
                                        <p className="text-caption">
                                            {request.reason}
                                        </p>
                                    </div>
                                </div>
                                <div className="min-w-0 space-y-1 [overflow-wrap:anywhere]">
                                    <p className="text-subtle">
                                        {timeOffDateSummary(request, timezone)}
                                    </p>
                                    <div className="flex flex-wrap items-center gap-2">
                                        <StatusBadge status="pending">
                                            Pending request
                                        </StatusBadge>
                                        <span className="text-caption">
                                            {request.requestedHours === null
                                                ? 'Requested hours unavailable'
                                                : `${request.requestedHours} hr requested`}
                                        </span>
                                    </div>
                                    {request.impactedShiftIds.length > 0 ? (
                                        <p className="text-caption">
                                            {request.impactedShiftIds.length}{' '}
                                            active{' '}
                                            {request.impactedShiftIds.length ===
                                            1
                                                ? 'shift overlaps'
                                                : 'shifts overlap'}{' '}
                                            · review staffing separately
                                        </p>
                                    ) : null}
                                </div>
                                {canManage && onApprove && onDecline ? (
                                    <div className="flex flex-wrap items-center gap-2">
                                        <Button
                                            size="sm"
                                            className="max-md:min-h-[44px]"
                                            disabled={decisionPending}
                                            onClick={() => onApprove(request)}
                                        >
                                            Approve
                                        </Button>
                                        <Button
                                            size="sm"
                                            variant="outline"
                                            className="max-md:min-h-[44px]"
                                            disabled={decisionPending}
                                            onClick={() => onDecline(request)}
                                        >
                                            Decline
                                        </Button>
                                    </div>
                                ) : null}
                            </article>
                        ))}
                    </div>
                </section>
                <section className="min-w-0 rounded-[14px] border border-border bg-card p-4 shadow-sm">
                    <h3 className="text-section-title">
                        Time off · next 14 days
                    </h3>
                    <p className="text-caption mb-3">
                        Approved leave and pending requests cover this
                        lookahead. Independent unavailability is returned for
                        the selected week only.
                    </p>
                    {days14.length > 0 ? (
                        <p className="text-caption mb-2">
                            {formatDateOnly(days14[0])} →{' '}
                            {formatDateOnly(days14[13])} · {timezone}
                        </p>
                    ) : null}
                    <div
                        className="max-w-full overflow-x-auto rounded-md focus-visible:ring-2 focus-visible:ring-ring"
                        role="region"
                        aria-label="Time-off calendar; scroll across for all fourteen days"
                        tabIndex={0}
                    >
                        <table className="w-full min-w-[502px] table-fixed border-collapse text-center">
                            <thead>
                                <tr>
                                    <th
                                        scope="col"
                                        className="text-caption w-[110px] p-1 text-left"
                                    >
                                        Staff member
                                    </th>
                                    {days14.map((day) => (
                                        <th
                                            key={day}
                                            scope="col"
                                            className="text-caption p-1"
                                            aria-label={formatDateOnly(day)}
                                        >
                                            {day.slice(8)}
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody>
                                {requests.map((request) => (
                                    <tr
                                        key={request.key}
                                        className="border-t border-border"
                                    >
                                        <th
                                            scope="row"
                                            className="p-1 text-left font-normal [overflow-wrap:anywhere]"
                                        >
                                            <span className="text-subtle">
                                                {request.staff}
                                            </span>
                                            <span className="text-caption block">
                                                {kindLabel[request.kind]}
                                            </span>
                                            <span className="text-caption block">
                                                {timeOffDateSummary(
                                                    request,
                                                    timezone,
                                                )}
                                            </span>
                                        </th>
                                        {days14.map((day) => {
                                            const covered =
                                                timeOffCoversWorkerDay(
                                                    request,
                                                    day,
                                                    timezone,
                                                );
                                            const Icon =
                                                request.kind === 'approved'
                                                    ? Check
                                                    : request.kind === 'pending'
                                                      ? Clock3
                                                      : Minus;
                                            return (
                                                <td key={day} className="p-0.5">
                                                    {covered ? (
                                                        <span
                                                            className={`flex min-h-5 items-center justify-center rounded border ${request.kind === 'approved' ? 'border-status-success/40 bg-status-success-bg text-status-success' : request.kind === 'pending' ? 'border-dashed border-status-warning/40 bg-status-warning-bg text-status-warning' : 'border-border bg-muted text-muted-foreground'}`}
                                                        >
                                                            <Icon
                                                                className="size-3"
                                                                aria-hidden="true"
                                                            />
                                                            <span className="sr-only">
                                                                {
                                                                    kindLabel[
                                                                        request
                                                                            .kind
                                                                    ]
                                                                }{' '}
                                                                ·{' '}
                                                                {formatDateOnly(
                                                                    day,
                                                                )}
                                                            </span>
                                                        </span>
                                                    ) : (
                                                        <span className="sr-only">
                                                            No returned time-off
                                                            interval on this day
                                                        </span>
                                                    )}
                                                </td>
                                            );
                                        })}
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    {requests.length === 0 ? (
                        <p className="text-subtle mt-3">
                            No time-off records returned for this view.
                        </p>
                    ) : null}
                    <div className="text-caption mt-3 flex flex-wrap items-center gap-3">
                        <span className="inline-flex items-center gap-1">
                            <Check className="size-3" />
                            Approved leave
                        </span>
                        <span className="inline-flex items-center gap-1">
                            <Clock3 className="size-3" />
                            Pending request
                        </span>
                        <span className="inline-flex items-center gap-1">
                            <Minus className="size-3" />
                            Unavailability or linked block
                        </span>
                    </div>
                    <p className="text-caption mt-2">
                        Shifts and publication run separate staffing checks.
                        This calendar does not confirm cover.
                    </p>
                </section>
            </div>
        </div>
    );
}

export default TimeOffPane;
