import type { Page } from '@inertiajs/core';
import { router } from '@inertiajs/react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import type { RosterLeaveDecision } from './leave-decision-dialog';
import type { RosterTimeOffRow } from './time-off-source';

export const UNKNOWN_LEAVE_DECISION =
    'The result could not be confirmed. The decision may already have saved. Your review note is kept here. Check the request before another attempt.';

type Identity = {
    actorId: number;
    sourceId: number;
    action: RosterLeaveDecision;
    requestId: string;
};
type Selection = { request: RosterTimeOffRow; action: RosterLeaveDecision };
export type LeaveDecisionOutcome =
    | { status: 'confirmed'; message: string; warning?: string }
    | { status: 'rejected'; message: string; reasonError?: string }
    | { status: 'unknown'; message: string };

const object = (value: unknown): Record<string, unknown> =>
    value !== null && typeof value === 'object' && !Array.isArray(value)
        ? (value as Record<string, unknown>)
        : {};
const positiveId = (value: unknown): value is number =>
    typeof value === 'number' && Number.isSafeInteger(value) && value > 0;
const utcInstant = (value: unknown): value is string =>
    typeof value === 'string' &&
    /T.*Z$/.test(value) &&
    Number.isFinite(Date.parse(value));

/** Generic redirect success is not evidence of this review's physical commit. */
export function leaveDecisionReceipt(
    value: unknown,
    expected: Identity,
): LeaveDecisionOutcome {
    const flash = object(value),
        receipt = object(flash.leave_review_result),
        saved = object(receipt.saved);
    const matches =
        positiveId(expected.actorId) &&
        positiveId(expected.sourceId) &&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(
            expected.requestId,
        ) &&
        receipt.version === 1 &&
        receipt.scope === 'leave_review' &&
        receipt.actor_id === expected.actorId &&
        receipt.leave_request_id === expected.sourceId &&
        receipt.action === expected.action &&
        receipt.request_id === expected.requestId;
    if (
        matches &&
        receipt.outcome === 'confirmed' &&
        saved.status ===
            (expected.action === 'approve' ? 'approved' : 'declined') &&
        saved.reviewed_by === expected.actorId &&
        utcInstant(saved.reviewed_at) &&
        utcInstant(receipt.committed_at) &&
        (expected.action === 'approve'
            ? positiveId(saved.time_off_id)
            : saved.time_off_id === null || positiveId(saved.time_off_id))
    ) {
        return {
            status: 'confirmed',
            message:
                expected.action === 'approve'
                    ? 'Leave request approved.'
                    : 'Leave request declined.',
            // The checked decision can commit before an existing webhook fails.
            // Preserve that separate warning without claiming a rollback.
            ...(typeof flash.error === 'string' && flash.error.trim()
                ? { warning: flash.error }
                : {}),
        };
    }
    return { status: 'unknown', message: UNKNOWN_LEAVE_DECISION };
}

function currentRequest(rows: RosterTimeOffRow[], row: RosterTimeOffRow) {
    return rows.find(
        (candidate) =>
            candidate.key === row.key &&
            candidate.sourceId === row.sourceId &&
            candidate.userId === row.userId &&
            candidate.type === row.type &&
            candidate.period === row.period &&
            candidate.starts_at === row.starts_at &&
            candidate.ends_at === row.ends_at &&
            candidate.source === 'hr_leave' &&
            candidate.kind === 'pending' &&
            positiveId(candidate.sourceId),
    );
}

/** Notes stay in the dialog; uncertainty is held in memory and never replayed. */
export function useLeaveDecision({
    actorId,
    canReview,
    requests,
}: {
    actorId?: number;
    canReview: boolean;
    requests: RosterTimeOffRow[];
}) {
    const [selection, setSelection] = useState<Selection | null>(null);
    const [pending, setPending] = useState(false);
    const [outcome, setOutcome] = useState<LeaveDecisionOutcome | null>(null);
    const selected = useRef<Selection | null>(null),
        busy = useRef(false),
        mounted = useRef(true);
    const latest = useRef({ actorId, canReview, requests });
    const generation = useRef(0),
        unresolved = useRef(new Set<number>());
    useLayoutEffect(() => {
        const changedActor = latest.current.actorId !== actorId;
        const lostAccess = latest.current.canReview && !canReview;
        latest.current = { actorId, canReview, requests };
        if (changedActor || lostAccess) {
            generation.current += 1;
            if (lostAccess && !changedActor && busy.current && selected.current)
                unresolved.current.add(selected.current.request.sourceId);
            if (changedActor) unresolved.current.clear();
            selected.current = null;
            busy.current = false;
            setSelection(null);
            setPending(false);
            setOutcome(null);
        }
    }, [actorId, canReview, requests]);
    useEffect(() => {
        mounted.current = true;
        return () => {
            mounted.current = false;
            generation.current += 1;
        };
    }, []);

    function open(request: RosterTimeOffRow, action: RosterLeaveDecision) {
        const access = latest.current;
        if (
            !mounted.current ||
            busy.current ||
            selected.current ||
            access.canReview !== true ||
            !positiveId(access.actorId) ||
            (action !== 'approve' && action !== 'decline')
        )
            return;
        const canonical = currentRequest(access.requests, request);
        if (!canonical) return;
        const next = { request: canonical, action };
        selected.current = next;
        setSelection(next);
        setOutcome(
            unresolved.current.has(canonical.sourceId)
                ? { status: 'unknown', message: UNKNOWN_LEAVE_DECISION }
                : null,
        );
    }

    function close() {
        if (busy.current) return;
        selected.current = null;
        setSelection(null);
        setOutcome(null);
    }

    function submit(reviewNotes: string): boolean {
        const target = selected.current,
            access = latest.current;
        if (
            !mounted.current ||
            busy.current ||
            !target ||
            access.canReview !== true ||
            !positiveId(access.actorId) ||
            unresolved.current.has(target.request.sourceId)
        )
            return false;
        if (!currentRequest(access.requests, target.request)) {
            setOutcome({
                status: 'rejected',
                message:
                    'This request is no longer pending in the current view. Check its current status in HR.',
            });
            return false;
        }
        const notes = reviewNotes.trim();
        if ((target.action === 'decline' && !notes) || notes.length > 2000) {
            const reasonError =
                notes.length > 2000
                    ? 'Use no more than 2,000 characters.'
                    : 'Enter a reason for declining this request.';
            setOutcome({
                status: 'rejected',
                message: 'Review the note before saving.',
                reasonError,
            });
            return false;
        }
        let requestId: string;
        try {
            requestId = crypto.randomUUID();
        } catch {
            setOutcome({
                status: 'rejected',
                message:
                    'The review could not be prepared. Your note is kept here.',
            });
            return false;
        }
        const identity: Identity = {
            actorId: access.actorId,
            sourceId: target.request.sourceId,
            action: target.action,
            requestId,
        };
        const sentGeneration = generation.current;
        busy.current = true;
        setPending(true);
        setOutcome(null);
        let result: LeaveDecisionOutcome | null = null,
            finished = false;
        const current = () =>
            mounted.current &&
            generation.current === sentGeneration &&
            latest.current.actorId === identity.actorId &&
            latest.current.canReview === true;
        const finish = () => {
            if (finished) return;
            finished = true;
            if (!current()) return;
            busy.current = false;
            const next = result ?? {
                status: 'unknown' as const,
                message: UNKNOWN_LEAVE_DECISION,
            };
            if (next.status === 'unknown')
                unresolved.current.add(identity.sourceId);
            setPending(false);
            setOutcome(next);
            if (next.status === 'confirmed') {
                selected.current = null;
                setSelection(null);
            }
        };
        try {
            router.post(
                `/hr/leave/${identity.sourceId}/${identity.action}`,
                {
                    review_notes: notes,
                    request_id: requestId,
                },
                {
                    headers: { 'X-Leave-Review-Result': 'committed-v1' },
                    preserveScroll: true,
                    preserveState: true,
                    onSuccess: (page: Page) => {
                        if (finished || result || !current()) return;
                        const responseActor = object(
                            object(page.props.auth).user,
                        ).id;
                        result =
                            responseActor === identity.actorId
                                ? leaveDecisionReceipt(
                                      page.props.flash,
                                      identity,
                                  )
                                : {
                                      status: 'unknown',
                                      message: UNKNOWN_LEAVE_DECISION,
                                  };
                    },
                    onError: (errors: Record<string, string>) => {
                        if (finished || result || !current()) return;
                        // Existing field validation runs before the checked writer.
                        const keys = Object.keys(errors);
                        result =
                            keys.length > 0 &&
                            keys.every((key) =>
                                ['review_notes', 'request_id'].includes(key),
                            )
                                ? {
                                      status: 'rejected',
                                      message: Object.values(errors).join(' '),
                                      reasonError: errors.review_notes,
                                  }
                                : {
                                      status: 'unknown',
                                      message: UNKNOWN_LEAVE_DECISION,
                                  };
                    },
                    onCancel: () => {
                        if (!finished && !result && current())
                            result = {
                                status: 'unknown',
                                message: UNKNOWN_LEAVE_DECISION,
                            };
                    },
                    onFinish: finish,
                },
            );
        } catch {
            finish();
        }
        return true;
    }

    return {
        selection: canReview === true && positiveId(actorId) ? selection : null,
        pending,
        outcome,
        canSubmit:
            canReview === true &&
            positiveId(actorId) &&
            !!selection &&
            !!currentRequest(requests, selection.request) &&
            outcome?.status !== 'unknown',
        open,
        close,
        submit,
    };
}
