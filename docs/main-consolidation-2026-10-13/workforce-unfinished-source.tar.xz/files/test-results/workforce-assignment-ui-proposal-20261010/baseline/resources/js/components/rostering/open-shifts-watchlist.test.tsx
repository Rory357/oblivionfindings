import { fireEvent, render, screen, within } from '@testing-library/react';
import type { ReactNode } from 'react';
import { describe, expect, it, vi } from 'vitest';

vi.mock('@inertiajs/react', () => ({
    Link: ({
        href,
        children,
        ...props
    }: {
        href: string;
        children: ReactNode;
    }) => (
        <a href={href} {...props}>
            {children}
        </a>
    ),
}));

import OpenShiftsPane, {
    type EligibilityAlertItem,
    type EligibilityAlerts,
    type OpenShiftCard,
} from './open-shifts-pane';

const alert: EligibilityAlertItem = {
    id: 4,
    user_id: 22,
    starts_at: '2026-05-04T22:00:00Z',
    staff: 'Aroha King',
    site: 'Matai House',
    reason: 'Working outside declared availability',
    reason_codes: ['availability'],
    reasons: [
        {
            code: 'availability',
            severity: 'block',
            message: 'Working outside declared availability',
        },
    ],
    can: { view_shift: true, view_availability: true, edit_availability: true },
    urls: {
        shift: '/operations/shifts/4',
        availability: '/staff/22/availability',
    },
};

function view(eligibilityAlerts: EligibilityAlerts) {
    return render(
        <OpenShiftsPane
            stats={[]}
            shifts={[]}
            canManage
            onAssign={vi.fn()}
            eligibilityAlerts={eligibilityAlerts}
        />,
    );
}

describe('lawful and reason-specific eligibility watchlist actions', () => {
    it('keeps a genuine availability correction and the authorised Shift entry', () => {
        view({ blocked: [alert] });
        expect(
            screen.getByRole('link', { name: 'View shift' }),
        ).toHaveAttribute('href', '/operations/shifts/4');
        expect(
            screen.getByRole('link', {
                name: 'Edit availability for Aroha King',
            }),
        ).toHaveAttribute('href', '/staff/22/availability');
        expect(screen.getByText(/Tue 5 May/)).toBeVisible();
    });

    it('offers a read-only owning entry when availability editing is denied', () => {
        view({
            blocked: [
                { ...alert, can: { ...alert.can, edit_availability: false } },
            ],
        });
        expect(
            screen.getByRole('link', {
                name: 'View availability for Aroha King',
            }),
        ).toBeVisible();
        expect(
            screen.queryByRole('link', { name: /Edit availability/ }),
        ).not.toBeInTheDocument();
    });

    it.each([
        'hs_training',
        'compliance',
        'turnaround',
        'availability_leave',
        'availability_employment',
    ])(
        'does not send a %s problem to Availability even with a misleading old reason',
        (code) => {
            view({
                warnings: [
                    {
                        ...alert,
                        reason_codes: [code],
                        reasons: [
                            {
                                code,
                                severity: 'warning',
                                message: 'Needs review',
                            },
                        ],
                    },
                ],
            });
            expect(
                screen.queryByRole('link', { name: /availability for/ }),
            ).not.toBeInTheDocument();
            expect(
                screen.getByRole('link', { name: 'View shift' }),
            ).toBeVisible();
        },
    );

    it('shows both reasons and retains the availability entry for a genuine mixed warning', () => {
        view({
            blocked: [
                {
                    ...alert,
                    reason_codes: ['availability', 'hs_training'],
                    reasons: [
                        {
                            code: 'availability',
                            severity: 'block',
                            message: 'Outside working times',
                        },
                        {
                            code: 'hs_training',
                            severity: 'block',
                            message: 'First aid expired',
                        },
                    ],
                },
            ],
        });
        expect(screen.getByText('Outside working times')).toBeVisible();
        expect(screen.getByText('First aid expired')).toBeVisible();
        expect(
            screen.getByRole('link', { name: /Edit availability/ }),
        ).toBeVisible();
    });

    it('denies action links when capability fields are absent', () => {
        view({ blocked: [{ ...alert, can: undefined }] });
        expect(screen.queryAllByRole('link')).toHaveLength(0);
        expect(
            screen.getByText('Working outside declared availability'),
        ).toBeVisible();
    });

    it('requires strict boolean view grants', () => {
        const malformed = {
            view_shift: 'true',
            view_availability: 1,
            edit_availability: true,
        } as unknown as EligibilityAlertItem['can'];
        view({ blocked: [{ ...alert, can: malformed }] });
        expect(screen.queryAllByRole('link')).toHaveLength(0);
    });

    it.each([
        {
            shift: '/operations/shifts/5',
            availability: '/staff/23/availability',
        },
        {
            shift: '//example.invalid/operations/shifts/4',
            availability: 'https://example.invalid/staff/22/availability',
        },
    ])('rejects mismatched or external destinations %#', (urls) => {
        view({ blocked: [{ ...alert, urls }] });
        expect(screen.queryAllByRole('link')).toHaveLength(0);
    });

    it('withholds Availability for an unknown worker ID', () => {
        view({ blocked: [{ ...alert, user_id: null }] });
        expect(
            screen.queryByRole('link', { name: /availability for/ }),
        ).not.toBeInTheDocument();
        expect(screen.getByRole('link', { name: 'View shift' })).toBeVisible();
    });

    it('does not infer an action from human-readable reason text without a structured code', () => {
        view({ blocked: [{ ...alert, reason_codes: undefined }] });
        expect(
            screen.queryByRole('link', { name: /availability for/ }),
        ).not.toBeInTheDocument();
    });

    it('requires a structured list rather than accepting a string as the reason-code contract', () => {
        view({
            blocked: [
                {
                    ...alert,
                    reason_codes: 'availability' as unknown as string[],
                },
            ],
        });
        expect(
            screen.queryByRole('link', { name: /availability for/ }),
        ).not.toBeInTheDocument();
    });

    it('keeps failed assessments visible without marking the worker eligible or opening Availability', () => {
        view({
            unknown: [{ ...alert, reason: 'Assessment failed', reasons: [] }],
            assessment: {
                status: 'partial',
                total: 8,
                assessed: 7,
                unknown: 1,
                missing_staff: 0,
                evaluation_failed: 1,
            },
        });
        expect(screen.getByText('Not assessed')).toBeVisible();
        expect(screen.getByRole('status')).toHaveTextContent(
            '7 of 8 assigned shifts checked. 1 could not be assessed.',
        );
        expect(screen.getByRole('status')).toHaveTextContent(
            'A failed check does not mean a worker is eligible.',
        );
        expect(
            screen.queryByRole('link', { name: /availability for/ }),
        ).not.toBeInTheDocument();
        expect(screen.getByRole('link', { name: 'View shift' })).toBeVisible();
    });

    it('labels a non-assessed view truthfully even with no returned alert rows', () => {
        view({
            assessment: {
                status: 'not_assessed',
                total: 0,
                assessed: 0,
                unknown: 0,
                missing_staff: 0,
                evaluation_failed: 0,
            },
        });
        expect(screen.getByRole('status')).toHaveTextContent(
            'Eligibility has not been assessed in this view.',
        );
        expect(screen.queryByText(/fully eligible/i)).not.toBeInTheDocument();
    });

    it('labels capped rows as shown rather than presenting the page count as every assessment', () => {
        view({
            warnings: [alert],
            assessment: {
                status: 'partial',
                total: 32,
                assessed: 30,
                unknown: 2,
                missing_staff: 1,
                evaluation_failed: 1,
            },
        });
        expect(screen.getByText('1 shown')).toBeVisible();
        expect(screen.getByRole('status')).toHaveTextContent(
            '30 of 32 assigned shifts checked. 2 could not be assessed.',
        );
    });

    it('keeps each Shift action with its own row when several records need attention', () => {
        view({
            warnings: [
                alert,
                {
                    ...alert,
                    id: 9,
                    staff: 'Tama Rangi',
                    urls: { ...alert.urls, shift: '/operations/shifts/9' },
                },
            ],
        });
        const rows = screen.getAllByRole('article');
        expect(
            within(rows[0]).getByRole('link', { name: 'View shift' }),
        ).toHaveAttribute('href', '/operations/shifts/4');
        expect(
            within(rows[1]).getByRole('link', { name: 'View shift' }),
        ).toHaveAttribute('href', '/operations/shifts/9');
    });
});

describe('suggested staff assessment and assignment', () => {
    const shift: OpenShiftCard = {
        id: 7,
        day: 'Tuesday',
        start: '08:00',
        end: '16:00',
        hours: 8,
        client: 'Moana',
        site: 'Matai House',
        reason: null,
        eligible: 99,
        warnings: 98,
        suggestions: [],
        href: '/operations/shifts/7',
    };
    const suggestions: OpenShiftCard['suggestions'] = [
        {
            id: 1,
            name: 'Blocked worker',
            eligibility: { status: 'blocked', reasons: ['On approved leave'] },
        },
        {
            id: 2,
            name: 'Unchecked worker',
            eligibility: {
                status: 'unknown',
                reasons: ['Eligibility could not be assessed'],
            },
        },
        {
            id: 3,
            name: 'Warning worker',
            eligibility: {
                status: 'warning',
                reasons: ['Review qualification warning'],
            },
        },
        { id: 4, name: 'Ready worker' },
    ];

    it('assigns the first permitted displayed suggestion instead of the first blocked or unchecked worker', () => {
        const onAssign = vi.fn();
        const current = { ...shift, suggestions };
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[current]}
                canManage
                onAssign={onAssign}
            />,
        );
        fireEvent.click(screen.getByRole('button', { name: 'Assign' }));
        expect(onAssign).toHaveBeenCalledExactlyOnceWith(current, 3);
        expect(
            screen.getByRole('button', { name: /Blocked worker/ }),
        ).toBeDisabled();
        expect(
            screen.getByRole('button', { name: /Unchecked worker/ }),
        ).toBeDisabled();
    });

    it('keeps warning suggestions available to the authorised assignment callback', () => {
        const onAssign = vi.fn();
        const current = { ...shift, suggestions };
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[current]}
                canManage
                onAssign={onAssign}
            />,
        );
        fireEvent.click(screen.getByRole('button', { name: /Warning worker/ }));
        expect(onAssign).toHaveBeenCalledExactlyOnceWith(current, 3);
    });

    it('offers the owning shift when every suggestion needs assessment and withholds direct assignment', () => {
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[{ ...shift, suggestions: [suggestions[1]] }]}
                canManage
                onAssign={vi.fn()}
            />,
        );
        expect(
            screen.queryByRole('button', { name: 'Assign' }),
        ).not.toBeInTheDocument();
        expect(
            screen.getByRole('button', { name: /Unchecked worker/ }),
        ).toBeDisabled();
        expect(screen.getByRole('link', { name: 'View' })).toHaveAttribute(
            'href',
            '/operations/shifts/7',
        );
    });

    it('counts only the displayed suggestions rather than the assigned-shift totals or hidden candidates', () => {
        const current = {
            ...shift,
            suggestions: [
                ...suggestions,
                ...Array.from({ length: 5 }, (_, i) => ({
                    id: 10 + i,
                    name: `Worker ${i}`,
                })),
            ],
        };
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[current]}
                canManage
                onAssign={vi.fn()}
            />,
        );
        for (const [label, count] of [
            ['Ready · shown', '5'],
            ['Warnings · shown', '1'],
            ['Blocked · shown', '1'],
            ['Not assessed · shown', '1'],
        ]) {
            expect(screen.getByText(label).parentElement).toHaveTextContent(
                count,
            );
        }
        expect(
            screen.queryByRole('button', { name: 'Worker 4' }),
        ).not.toBeInTheDocument();
        expect(screen.queryByText('99')).not.toBeInTheDocument();
        expect(screen.queryByText('98')).not.toBeInTheDocument();
    });

    it('does not assign an eligible but hidden ninth suggestion through the primary action', () => {
        const current = {
            ...shift,
            suggestions: [
                ...Array.from({ length: 8 }, (_, i) => ({
                    id: 10 + i,
                    name: `Unchecked ${i}`,
                    eligibility: {
                        status: 'unknown' as const,
                        reasons: ['Assessment unavailable'],
                    },
                })),
                { id: 99, name: 'Hidden ready worker' },
            ],
        };
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[current]}
                canManage
                onAssign={vi.fn()}
            />,
        );
        expect(
            screen.queryByRole('button', { name: 'Assign' }),
        ).not.toBeInTheDocument();
        expect(
            screen.queryByRole('button', { name: 'Hidden ready worker' }),
        ).not.toBeInTheDocument();
    });

    it('preserves assignment denial for a viewer even when suggested workers are ready', () => {
        render(
            <OpenShiftsPane
                stats={[]}
                shifts={[{ ...shift, suggestions }]}
                canManage={false}
                onAssign={vi.fn()}
            />,
        );
        expect(
            screen.queryByRole('button', { name: 'Assign' }),
        ).not.toBeInTheDocument();
        expect(
            screen.getByRole('button', { name: /Ready worker/ }),
        ).toBeDisabled();
        expect(
            screen.getByRole('button', { name: /Warning worker/ }),
        ).toBeDisabled();
    });
});
