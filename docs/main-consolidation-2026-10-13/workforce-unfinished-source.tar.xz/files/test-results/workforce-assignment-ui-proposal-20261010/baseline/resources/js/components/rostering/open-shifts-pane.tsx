import { Link } from '@inertiajs/react';
import type { ReactNode } from 'react';

import { Button } from '@/components/ui/button';
import { StatusBadge } from '@/components/ui/status-badge';
import { formatDate, formatTime } from '@/lib/datetime';
import { cn } from '@/lib/utils';

import { MicroStats, type MicroStat } from './micro-stats';

export type OpenShiftCandidateEligibility = {
    status: 'warning' | 'blocked' | 'unknown';
    reasons: string[];
};

export type OpenShiftCard = {
    id: number;
    day: string;
    start: string;
    end: string;
    hours: number;
    client: string;
    site: string | null;
    reason: string | null;
    eligible: number;
    warnings: number;
    blocked?: string[];
    suggestions: Array<{
        id: number;
        name: string;
        hours?: number | null;
        meta?: string | null;
        eligibility?: OpenShiftCandidateEligibility;
    }>;
    href?: string;
};

export type EligibilityAlertItem = {
    id: number;
    user_id?: number | null;
    starts_at: string;
    staff: string;
    site: string;
    reason: string;
    reason_codes?: string[];
    reasons?: Array<{
        code: string;
        severity: 'block' | 'warning';
        message: string;
    }>;
    can?: {
        view_shift?: boolean;
        view_availability?: boolean;
        edit_availability?: boolean;
    };
    urls?: { shift?: string | null; availability?: string | null };
};

export type EligibilityAlerts = {
    blocked?: EligibilityAlertItem[];
    warnings?: EligibilityAlertItem[];
    unknown?: EligibilityAlertItem[];
    counts?: { unknown?: number };
    assessment?: {
        status: 'complete' | 'partial' | 'not_assessed';
        total: number;
        assessed: number;
        unknown: number;
        missing_staff: number;
        evaluation_failed: number;
    };
};

export type ReplacementRequestCard = {
    id: number;
    shift_id: number;
    status?: string | null;
    reason?: string | null;
    requested_at?: string | null;
    starts_at?: string | null;
    ends_at?: string | null;
    client?: string | null;
    location?: string | null;
    current_staff?: string | null;
    requested_by?: string | null;
    replacement_staff?: string | null;
};

export type OpenShiftsPaneProps = {
    stats: MicroStat[];
    shifts: OpenShiftCard[];
    canManage: boolean;
    replacementRequests?: ReplacementRequestCard[];
    eligibilityAlerts?: EligibilityAlerts;
    onAssign: (shift: OpenShiftCard, candidateUserId: number | string) => void;
    onFindReplacement?: (request: ReplacementRequestCard) => void;
    actionEndSlot?: ReactNode;
};

export function OpenShiftsPane({
    stats,
    shifts,
    canManage,
    replacementRequests = [],
    eligibilityAlerts,
    onAssign,
    onFindReplacement,
    actionEndSlot,
}: OpenShiftsPaneProps) {
    const blockedAlerts = eligibilityAlerts?.blocked ?? [];
    const warningAlerts = eligibilityAlerts?.warnings ?? [];
    const unknownAlerts = eligibilityAlerts?.unknown ?? [];
    const assessment = eligibilityAlerts?.assessment;
    const hasEligibilityAlerts =
        blockedAlerts.length > 0 ||
        warningAlerts.length > 0 ||
        unknownAlerts.length > 0 ||
        assessment?.status === 'partial' ||
        assessment?.status === 'not_assessed';

    return (
        <div className="space-y-4">
            <MicroStats stats={stats} />
            {hasEligibilityAlerts ? (
                <section className="rounded-[14px] border border-border bg-card p-4 shadow-sm">
                    <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
                        <div>
                            <h3 className="text-section-title">
                                Eligibility watchlist
                            </h3>
                            <p className="text-subtle">
                                Assigned shifts needing attention over the next
                                14 days. Review each shift before changing
                                staffing.
                            </p>
                        </div>
                        <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] font-semibold text-muted-foreground tabular-nums">
                            {blockedAlerts.length +
                                warningAlerts.length +
                                unknownAlerts.length}{' '}
                            shown
                        </span>
                    </div>
                    {assessment?.status === 'partial' ? (
                        <p role="status" className="text-subtle mb-3">
                            {assessment.assessed} of {assessment.total} assigned
                            shifts checked. {assessment.unknown} could not be
                            assessed. A failed check does not mean a worker is
                            eligible.
                        </p>
                    ) : assessment?.status === 'not_assessed' ? (
                        <p role="status" className="text-subtle mb-3">
                            Eligibility has not been assessed in this view.
                        </p>
                    ) : null}
                    <div className="grid gap-2 md:grid-cols-2">
                        {blockedAlerts.map((alert) => (
                            <EligibilityAlertRow
                                key={`blocked-${alert.id}`}
                                alert={alert}
                                tone="blocked"
                            />
                        ))}
                        {warningAlerts.map((alert) => (
                            <EligibilityAlertRow
                                key={`warning-${alert.id}`}
                                alert={alert}
                                tone="warning"
                            />
                        ))}
                        {unknownAlerts.map((alert) => (
                            <EligibilityAlertRow
                                key={`unknown-${alert.id}`}
                                alert={alert}
                                tone="unknown"
                            />
                        ))}
                    </div>
                </section>
            ) : null}
            {replacementRequests.length > 0 ? (
                <section className="rounded-[14px] border border-status-warning/35 bg-status-warning-bg/40 p-4">
                    <div className="mb-3 flex flex-wrap items-start justify-between gap-2">
                        <div>
                            <h3 className="text-sm font-bold tracking-tight">
                                Replacement requests
                            </h3>
                            <div className="text-[11px] text-muted-foreground">
                                Awaiting cover for assigned shifts
                            </div>
                        </div>
                        <span className="rounded-full bg-background/70 px-2 py-0.5 text-[11px] font-semibold text-muted-foreground tabular-nums">
                            {replacementRequests.length}
                        </span>
                    </div>
                    <div className="space-y-2">
                        {replacementRequests.map((req) => (
                            <article
                                key={req.id}
                                className="grid items-center gap-3 rounded-md border border-border bg-card p-3 md:grid-cols-[140px_1fr_auto]"
                            >
                                <div>
                                    <div className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
                                        {req.starts_at
                                            ? fmtDay(req.starts_at)
                                            : 'Shift'}
                                    </div>
                                    <div className="text-sm font-bold tabular-nums">
                                        {fmtTimeRange(
                                            req.starts_at,
                                            req.ends_at,
                                        )}
                                    </div>
                                </div>
                                <div className="min-w-0">
                                    <div className="truncate text-sm font-semibold">
                                        {req.requested_by ??
                                            'Replacement requested'}
                                    </div>
                                    <div className="truncate text-xs text-muted-foreground">
                                        {req.current_staff
                                            ? `Current staff: ${req.current_staff}`
                                            : 'Current staff not set'}
                                    </div>
                                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                                        {req.client ? (
                                            <span className="rounded bg-muted px-1.5 py-0.5">
                                                {req.client}
                                            </span>
                                        ) : null}
                                        {req.location ? (
                                            <span className="rounded bg-muted px-1.5 py-0.5">
                                                {req.location}
                                            </span>
                                        ) : null}
                                        {req.reason ? (
                                            <span className="rounded bg-status-warning-bg px-1.5 py-0.5 text-status-warning">
                                                {req.reason}
                                            </span>
                                        ) : null}
                                    </div>
                                </div>
                                <div className="flex items-center justify-end gap-2">
                                    {canManage ? (
                                        <Button
                                            size="sm"
                                            onClick={() =>
                                                onFindReplacement?.(req)
                                            }
                                        >
                                            Find cover
                                        </Button>
                                    ) : null}
                                    <Link
                                        href={`/operations/shifts/${req.shift_id}`}
                                    >
                                        <Button size="sm" variant="ghost">
                                            View
                                        </Button>
                                    </Link>
                                </div>
                            </article>
                        ))}
                    </div>
                </section>
            ) : null}
            <div className="space-y-3">
                {shifts.length === 0 ? (
                    <div className="rounded-[14px] border border-border bg-card p-6 text-center text-sm text-muted-foreground">
                        No open shifts in this week.
                    </div>
                ) : null}
                {shifts.map((sh) => (
                    <article
                        key={sh.id}
                        className="rounded-[14px] border border-l-4 border-border border-l-status-warning bg-card p-4"
                    >
                        <div className="grid items-center gap-4 md:grid-cols-[130px_1fr_auto_auto]">
                            <div>
                                <div className="text-xs font-semibold tracking-wider text-muted-foreground uppercase">
                                    {sh.day}
                                </div>
                                <div className="text-base font-bold tabular-nums">
                                    {sh.start} – {sh.end}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                    {sh.hours.toFixed(1)}h
                                </div>
                            </div>
                            <div className="min-w-0">
                                <div className="font-semibold break-words">
                                    {sh.client}
                                </div>
                                <div className="text-xs break-words text-muted-foreground">
                                    {sh.site
                                        ? sh.reason
                                            ? `${sh.site} · ${sh.reason}`
                                            : sh.site
                                        : (sh.reason ?? '')}
                                </div>
                            </div>
                            <div className="flex min-w-0 flex-wrap items-center gap-3">
                                <Stat
                                    label="Ready · shown"
                                    value={
                                        sh.suggestions
                                            .slice(0, 8)
                                            .filter(
                                                (candidate) =>
                                                    !candidate.eligibility,
                                            ).length
                                    }
                                    tone="ok"
                                />
                                <Stat
                                    label="Warnings · shown"
                                    value={
                                        sh.suggestions
                                            .slice(0, 8)
                                            .filter(
                                                (candidate) =>
                                                    candidate.eligibility
                                                        ?.status === 'warning',
                                            ).length
                                    }
                                    tone="warn"
                                />
                                <Stat
                                    label="Blocked · shown"
                                    value={
                                        sh.suggestions
                                            .slice(0, 8)
                                            .filter(
                                                (candidate) =>
                                                    candidate.eligibility
                                                        ?.status === 'blocked',
                                            ).length
                                    }
                                    tone="crit"
                                />
                                <Stat
                                    label="Not assessed · shown"
                                    value={
                                        sh.suggestions
                                            .slice(0, 8)
                                            .filter(
                                                (candidate) =>
                                                    candidate.eligibility
                                                        ?.status === 'unknown',
                                            ).length
                                    }
                                    tone="warn"
                                />
                            </div>
                            <div className="flex items-center gap-2">
                                {canManage &&
                                sh.suggestions
                                    .slice(0, 8)
                                    .some(
                                        (candidate) =>
                                            !candidate.eligibility ||
                                            candidate.eligibility.status ===
                                                'warning',
                                    ) ? (
                                    <Button
                                        size="sm"
                                        className="max-md:min-h-[44px]"
                                        onClick={() => {
                                            const candidate = sh.suggestions
                                                .slice(0, 8)
                                                .find(
                                                    (suggestion) =>
                                                        !suggestion.eligibility ||
                                                        suggestion.eligibility
                                                            .status ===
                                                            'warning',
                                                );
                                            if (candidate)
                                                onAssign(sh, candidate.id);
                                        }}
                                    >
                                        Assign
                                    </Button>
                                ) : null}
                                {sh.href ? (
                                    <Button
                                        asChild
                                        size="sm"
                                        variant="ghost"
                                        className="max-md:min-h-[44px]"
                                    >
                                        <Link href={sh.href}>View</Link>
                                    </Button>
                                ) : null}
                            </div>
                        </div>

                        <div className="mt-3 border-t border-dashed border-border pt-3">
                            <div className="mb-2 text-[11px] font-semibold tracking-wider text-muted-foreground uppercase">
                                Suggested staff
                            </div>
                            <div className="flex flex-wrap items-center gap-1.5">
                                {sh.suggestions.length === 0 ? (
                                    <span className="text-[11px] text-muted-foreground italic">
                                        No staff suggestions in this view. Open
                                        the shift to review staffing.
                                    </span>
                                ) : (
                                    sh.suggestions.slice(0, 8).map((nm, i) => {
                                        const meta = candidateMeta(nm);
                                        const elig = nm.eligibility;
                                        const isBlocked =
                                            elig?.status === 'blocked';
                                        const isWarning =
                                            elig?.status === 'warning';
                                        const isUnknown =
                                            elig?.status === 'unknown';
                                        const reasonTooltip = elig?.reasons
                                            ?.length
                                            ? elig.reasons.join(' · ')
                                            : undefined;
                                        const isBest =
                                            i === 0 &&
                                            !isBlocked &&
                                            !isWarning &&
                                            !isUnknown;

                                        return (
                                            <Button
                                                unstyled
                                                key={nm.id}
                                                type="button"
                                                aria-label={
                                                    reasonTooltip
                                                        ? `${nm.name} — ${isBlocked ? 'blocked' : isUnknown ? 'not assessed' : 'warning'}: ${reasonTooltip}`
                                                        : nm.name
                                                }
                                                title={reasonTooltip}
                                                data-eligibility={
                                                    elig?.status ?? 'eligible'
                                                }
                                                disabled={
                                                    !canManage ||
                                                    isBlocked ||
                                                    isUnknown
                                                }
                                                onClick={() =>
                                                    onAssign(sh, nm.id)
                                                }
                                                className={cn(
                                                    'inline-flex min-h-11 max-w-full items-center gap-1.5 rounded-full border px-2 py-1 text-xs font-medium transition',
                                                    isBlocked
                                                        ? 'cursor-not-allowed border-status-critical/40 bg-status-critical-bg/40 text-muted-foreground line-through'
                                                        : isWarning
                                                          ? 'border-status-warning bg-status-warning-bg text-foreground hover:bg-status-warning-bg/80'
                                                          : isBest
                                                            ? 'border-primary-fill bg-primary-fill text-primary-fill-foreground'
                                                            : 'border-border bg-background text-foreground hover:bg-accent',
                                                )}
                                            >
                                                <span className="inline-flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-background/50 text-[9px] font-bold text-foreground uppercase">
                                                    {nm.name
                                                        .split(' ')
                                                        .map((w) => w[0])
                                                        .slice(0, 2)
                                                        .join('')}
                                                </span>
                                                <span className="flex min-w-0 flex-col items-start leading-tight">
                                                    <span className="max-w-[9rem] truncate">
                                                        {nm.name}
                                                    </span>
                                                    {meta ? (
                                                        <span
                                                            className={cn(
                                                                'text-[10px] font-medium',
                                                                isBest
                                                                    ? 'text-primary-foreground/75'
                                                                    : 'text-muted-foreground',
                                                            )}
                                                        >
                                                            {meta}
                                                        </span>
                                                    ) : null}
                                                </span>
                                                {isBlocked ? (
                                                    <span
                                                        aria-hidden="true"
                                                        className="rounded-full bg-status-critical px-1.5 py-0.5 text-[9px] font-bold text-white uppercase"
                                                    >
                                                        Blocked
                                                    </span>
                                                ) : isUnknown ? (
                                                    <StatusBadge
                                                        variant="warning"
                                                        size="sm"
                                                    >
                                                        Not assessed
                                                    </StatusBadge>
                                                ) : isWarning ? (
                                                    <span
                                                        aria-hidden="true"
                                                        className="rounded-full bg-status-warning px-1.5 py-0.5 text-[9px] font-bold text-white uppercase"
                                                    >
                                                        Warn
                                                    </span>
                                                ) : isBest ? (
                                                    <span className="rounded-full bg-primary-foreground/15 px-1.5 py-0.5 text-[9px] font-bold uppercase">
                                                        best
                                                    </span>
                                                ) : null}
                                            </Button>
                                        );
                                    })
                                )}
                            </div>
                            {sh.blocked && sh.blocked.length > 0 ? (
                                <div className="mt-2 space-y-1">
                                    {sh.blocked.map((b, i) => (
                                        <div
                                            key={i}
                                            className="text-[11px] text-status-critical"
                                        >
                                            × {b}
                                        </div>
                                    ))}
                                </div>
                            ) : null}
                        </div>
                    </article>
                ))}
            </div>
            {actionEndSlot}
        </div>
    );
}

function EligibilityAlertRow({
    alert,
    tone,
}: {
    alert: EligibilityAlertItem;
    tone: 'blocked' | 'warning' | 'unknown';
}) {
    const blocked = tone === 'blocked';
    const validId = (id: unknown): id is number =>
        typeof id === 'number' && Number.isSafeInteger(id) && id > 0;
    const shiftHref =
        alert.can?.view_shift === true &&
        validId(alert.id) &&
        alert.urls?.shift === `/operations/shifts/${alert.id}`
            ? alert.urls.shift
            : null;
    const availabilityHref =
        tone !== 'unknown' &&
        alert.can?.view_availability === true &&
        Array.isArray(alert.reason_codes) &&
        alert.reason_codes.includes('availability') &&
        validId(alert.user_id) &&
        alert.urls?.availability === `/staff/${alert.user_id}/availability`
            ? alert.urls.availability
            : null;

    return (
        <article
            className={cn(
                'min-w-0 rounded-md border p-3',
                blocked
                    ? 'border-status-critical/30 bg-status-critical-bg/35'
                    : 'border-status-warning/30 bg-status-warning-bg/35',
            )}
        >
            <div className="flex min-w-0 flex-wrap items-center gap-2">
                <StatusBadge variant={blocked ? 'critical' : 'warning'}>
                    {blocked
                        ? 'Blocker'
                        : tone === 'unknown'
                          ? 'Not assessed'
                          : 'Warning'}
                </StatusBadge>
                <span className="text-subtle min-w-0 font-semibold break-words">
                    {alert.staff}
                </span>
                <span className="text-caption min-w-0 break-words">
                    {fmtDay(alert.starts_at)} · {alert.site}
                </span>
            </div>
            {alert.reasons?.length ? (
                <ul className="text-subtle mt-2 list-inside list-disc space-y-1">
                    {alert.reasons.map((reason, index) => (
                        <li
                            key={`${reason.code}:${index}`}
                            className="break-words"
                        >
                            {reason.message}
                        </li>
                    ))}
                </ul>
            ) : (
                <p className="text-subtle mt-2 break-words">{alert.reason}</p>
            )}
            {shiftHref || availabilityHref ? (
                <div className="mt-3 flex flex-wrap items-center gap-2">
                    {shiftHref ? (
                        <Button
                            asChild
                            size="sm"
                            variant="outline"
                            className="max-md:min-h-[44px]"
                        >
                            <Link href={shiftHref}>View shift</Link>
                        </Button>
                    ) : null}
                    {availabilityHref ? (
                        <Button
                            asChild
                            size="sm"
                            variant="outline"
                            className="max-md:min-h-[44px]"
                        >
                            <Link href={availabilityHref}>
                                {alert.can?.edit_availability === true
                                    ? 'Edit'
                                    : 'View'}{' '}
                                availability for {alert.staff}
                            </Link>
                        </Button>
                    ) : null}
                </div>
            ) : null}
        </article>
    );
}

function fmtDay(iso: string): string {
    return formatDate(iso, 'Date unavailable');
}

function fmtClock(iso?: string | null): string | null {
    if (!iso) return null;
    return formatTime(iso, '') || null;
}

function fmtTimeRange(starts?: string | null, ends?: string | null): string {
    const start = fmtClock(starts);
    const end = fmtClock(ends);
    if (start && end) return `${start} - ${end}`;
    if (start) return start;
    return 'Time not set';
}

function formatHours(hours: number): string {
    const rounded = Math.round(hours * 10) / 10;
    return Number.isInteger(rounded) ? String(rounded) : rounded.toFixed(1);
}

function candidateMeta(candidate: {
    hours?: number | null;
    meta?: string | null;
}): string | null {
    if (candidate.meta) return candidate.meta;
    if (
        typeof candidate.hours !== 'number' ||
        !Number.isFinite(candidate.hours)
    )
        return null;
    return `${formatHours(candidate.hours)}h this week`;
}

function Stat({
    label,
    value,
    tone,
}: {
    label: string;
    value: number;
    tone: 'ok' | 'warn' | 'crit';
}) {
    const c =
        tone === 'crit'
            ? 'text-status-critical'
            : tone === 'warn'
              ? 'text-status-warning'
              : 'text-status-success';
    return (
        <div className="text-center">
            <div className={cn('text-base font-bold tabular-nums', c)}>
                {value}
            </div>
            <div className="text-[10px] font-semibold tracking-wider text-muted-foreground uppercase">
                {label}
            </div>
        </div>
    );
}

export default OpenShiftsPane;
