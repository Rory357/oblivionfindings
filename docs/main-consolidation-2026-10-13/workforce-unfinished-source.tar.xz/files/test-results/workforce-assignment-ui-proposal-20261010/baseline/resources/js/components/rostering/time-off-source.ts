import { formatDateOnly, toDateInput, WORKER_TIMEZONE } from '@/lib/datetime';

export type RosterTimeOffSource = {
    id: number;
    user_id: number;
    user: string | null;
    starts_at: string | null;
    ends_at: string | null;
    type: string;
    period?: string | null;
    hr_leave_request_id?: number | null;
    label: string | null;
    notes: string | null;
};

export type RosterHrLeaveSource = {
    id: number;
    user_id: number;
    user: string | null;
    starts_at: string | null;
    ends_at: string | null;
    leave_type: string;
    status?: string | null;
    reason?: string | null;
    period?: string | null;
    hours_requested?: number | null;
    selected_week_hours?: number | null;
};

export type RosterTimeOffWindow = {
    timezone: string;
    starts_at: string;
    ends_at: string;
    leave_lookahead_ends_at: string;
};

export type RosterTimeOffRow = {
    key: string;
    source: 'staff_time_off' | 'hr_leave';
    sourceId: number;
    userId: number;
    staff: string;
    reason: string;
    type: string;
    period: string;
    starts_at: string | null;
    ends_at: string | null;
    kind:
        | 'unavailability'
        | 'linked_leave'
        | 'approved'
        | 'pending'
        | 'unknown';
    requestedHours: number | null;
    selectedWeekHours: number | null;
    impactedShiftIds: number[];
};

type Duty = {
    id: number;
    user_id: number | null;
    starts_at: string | null;
    ends_at: string | null;
    status: string;
};

// Server intervals are instants. Reject browser-local timestamps rather than
// interpreting the same record differently on two reviewers' computers.
function instant(value: string | null): number | null {
    if (!value || !/T.*(?:Z|[+-]\d{2}:\d{2})$/i.test(value)) return null;
    const parsed = Date.parse(value);
    return Number.isFinite(parsed) ? parsed : null;
}

function interval(row: { starts_at: string | null; ends_at: string | null }) {
    const start = instant(row.starts_at);
    const end = instant(row.ends_at);
    return start !== null && end !== null && end > start
        ? { start, end }
        : null;
}

function period(value?: string | null) {
    return value || 'full_day';
}

function hours(value?: number | null) {
    return typeof value === 'number' && Number.isFinite(value) && value >= 0
        ? value
        : null;
}

function overlap(
    left: { starts_at: string | null; ends_at: string | null },
    right: { starts_at: string | null; ends_at: string | null },
) {
    const a = interval(left);
    const b = interval(right);
    return !!a && !!b && a.start < b.end && b.start < a.end;
}

function sameApprovedSource(
    block: RosterTimeOffSource,
    leave: RosterHrLeaveSource,
) {
    const a = interval(block);
    const b = interval(leave);
    return (
        block.hr_leave_request_id === leave.id &&
        block.user_id === leave.user_id &&
        leave.status === 'approved' &&
        block.type === leave.leave_type &&
        period(block.period) === period(leave.period) &&
        !!a &&
        !!b &&
        a.start === b.start &&
        a.end === b.end
    );
}

export function buildRosterTimeOffRows({
    blocks,
    approved,
    pending,
    shifts,
}: {
    blocks: RosterTimeOffSource[];
    approved: RosterHrLeaveSource[];
    pending: RosterHrLeaveSource[];
    shifts: Duty[];
}): RosterTimeOffRow[] {
    function impact(userId: number, row: Parameters<typeof overlap>[0]) {
        return [
            ...new Set(
                shifts
                    .filter(
                        (duty) =>
                            duty.user_id === userId &&
                            ['draft', 'scheduled', 'in_progress'].includes(
                                duty.status,
                            ) &&
                            overlap(duty, row),
                    )
                    .map((duty) => duty.id),
            ),
        ];
    }
    const rows: RosterTimeOffRow[] = blocks
        .filter(
            (block) =>
                !approved.some((leave) => sameApprovedSource(block, leave)),
        )
        .map((block) => ({
            key: `staff_time_off:${block.id}`,
            source: 'staff_time_off',
            sourceId: block.id,
            userId: block.user_id,
            staff: block.user || 'Staff member',
            // A linked block never supplies the canonical HR review note.
            reason:
                block.label ||
                (block.hr_leave_request_id ? null : block.notes) ||
                block.type,
            type: block.type,
            period: period(block.period),
            starts_at: block.starts_at,
            ends_at: block.ends_at,
            kind: block.hr_leave_request_id ? 'linked_leave' : 'unavailability',
            requestedHours: null,
            selectedWeekHours: null,
            impactedShiftIds: impact(block.user_id, block),
        }));
    for (const [entries, expected] of [
        [approved, 'approved'],
        [pending, 'pending'],
    ] as const) {
        for (const leave of entries) {
            // Retain unexpected source rows without presenting them as approved
            // or offering a decision. A stale/partial response must stay visible.
            rows.push({
                key: `hr_leave:${leave.id}`,
                source: 'hr_leave',
                sourceId: leave.id,
                userId: leave.user_id,
                staff: leave.user || 'Staff member',
                reason:
                    leave.reason ||
                    `${leave.leave_type.replace(/_/g, ' ')} leave`,
                type: leave.leave_type,
                period: period(leave.period),
                starts_at: leave.starts_at,
                ends_at: leave.ends_at,
                kind: leave.status === expected ? expected : 'unknown',
                requestedHours: hours(leave.hours_requested),
                selectedWeekHours: interval(leave)
                    ? hours(leave.selected_week_hours)
                    : null,
                impactedShiftIds: impact(leave.user_id, leave),
            });
        }
    }
    return rows;
}

export function rosterTimeOffSummary(
    rows: RosterTimeOffRow[],
    window?: RosterTimeOffWindow,
) {
    const inWeek = window ? rows.filter((row) => overlap(row, window)) : [];
    const approved = inWeek.filter((row) => row.kind === 'approved');
    return {
        recordedApprovedHours: approved.reduce(
            (total, row) => total + (row.selectedWeekHours ?? 0),
            0,
        ),
        approvedHoursUnknown: approved.filter(
            (row) => row.selectedWeekHours === null,
        ).length,
        weekAvailable: !!window && !!interval(window),
        impactedShiftIds: [
            ...new Set(inWeek.flatMap((row) => row.impactedShiftIds)),
        ],
        pendingRequests: rows.filter((row) => row.kind === 'pending').length,
        independentBlocks: inWeek.filter((row) => row.kind === 'unavailability')
            .length,
    };
}

export function timeOffCoversWorkerDay(
    row: Pick<RosterTimeOffRow, 'starts_at' | 'ends_at'>,
    day: string,
    timezone = WORKER_TIMEZONE,
) {
    const range = interval(row);
    if (!range || !formatDateOnly(day, '')) return false;
    const first = toDateInput(range.start, timezone);
    // Intervals are exclusive at the end: midnight does not cover the next day.
    const last = toDateInput(range.end - 1, timezone);
    return day >= first && day <= last;
}

export function timeOffDateSummary(
    row: Pick<RosterTimeOffRow, 'starts_at' | 'ends_at' | 'period'>,
    timezone = WORKER_TIMEZONE,
) {
    const range = interval(row);
    if (!range) return 'Dates unavailable';
    const first = toDateInput(range.start, timezone);
    const last = toDateInput(range.end - 1, timezone);
    const dates =
        first === last
            ? formatDateOnly(first)
            : `${formatDateOnly(first)} → ${formatDateOnly(last)}`;
    const suffix =
        row.period === 'half_day_am'
            ? ' · morning half day'
            : row.period === 'half_day_pm'
              ? ' · afternoon half day'
              : '';
    return dates + suffix;
}

export function timeOffCalendarDays(firstDay: string) {
    if (!formatDateOnly(firstDay, '')) return [];
    return Array.from({ length: 14 }, (_, offset) => {
        const date = new Date(`${firstDay}T12:00:00Z`);
        date.setUTCDate(date.getUTCDate() + offset);
        return date.toISOString().slice(0, 10);
    });
}
