import { router } from '@inertiajs/react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { toast } from 'sonner';

import {
    assignmentDisplay,
    assignmentOutcome,
    assignmentSource,
    type AssignmentAttempt,
    type AssignmentContext,
    type AssignmentReview,
    type AssignmentSource,
} from './shift-assignment-result';

export type { AssignmentContext } from './shift-assignment-result';
export type AssignmentFeedback = {
    pending: boolean;
    error: string | null;
    uncertain: boolean;
    review: AssignmentReview | null;
    reviewUserId: number | null;
};
const initial: AssignmentFeedback = {
    pending: false,
    error: null,
    uncertain: false,
    review: null,
    reviewUserId: null,
};
const unknownMessage =
    'The save could not be confirmed. Check this shift before trying again.';
const messages: Record<string, string> = {
    eligibility_warning:
        'The staff checks need your review. No assignment was saved.',
    override_reason_required:
        'Enter a reason for this warning. No assignment was saved.',
    locked: 'This shift is locked. No changes were saved.',
    in_progress:
        'This shift has started. Use the replacement workflow instead.',
    source_changed:
        'This shift changed since you opened it. Refresh the shift before continuing.',
};

export function rosterAssignmentReturnTo(value: string): string {
    if (!value.startsWith('/operations/rostering') || value.startsWith('//'))
        return '/operations/rostering';
    let url: URL;
    try {
        url = new URL(value, 'https://local.invalid');
    } catch {
        return '/operations/rostering';
    }
    if (url.pathname !== '/operations/rostering')
        return '/operations/rostering';
    const params = new URLSearchParams();
    const sites = [...url.searchParams].filter(([key]) =>
        key.startsWith('site_id'),
    );
    const siteModes = new Set(
        sites.map(([key]) =>
            key === 'site_id'
                ? 'scalar'
                : key === 'site_id[]'
                  ? 'repeated'
                  : /^site_id\[(0|[1-9]|[1-4]\d)\]$/.test(key)
                    ? 'numbered'
                    : 'invalid',
        ),
    );
    const sitesValid =
        sites.length <= 50 &&
        siteModes.size <= 1 &&
        !siteModes.has('invalid') &&
        sites.every(
            ([key, selected]) =>
                selected.length <= 200 &&
                /^[1-9]\d*$/.test(selected) &&
                Number.isSafeInteger(Number(selected)) &&
                (key === 'site_id[]' ||
                    url.searchParams.getAll(key).length === 1),
        );
    const seenSites = new Set<string>();
    for (const [key, selected] of url.searchParams) {
        if (key.startsWith('site_id')) {
            if (sitesValid && !seenSites.has(selected)) {
                params.set(
                    key === 'site_id[]' ? `site_id[${seenSites.size}]` : key,
                    selected,
                );
                seenSites.add(selected);
            }
            continue;
        }
        if (
            params.size >= 100 ||
            selected.length > 200 ||
            url.searchParams.getAll(key).length !== 1
        )
            continue;
        if (key === 'week' && /^\d{4}-\d{2}-\d{2}$/.test(selected))
            params.set(key, selected);
        if (
            key === 'tab' &&
            [
                'shifts',
                'calendar',
                'open',
                'coverage',
                'timeoff',
                'availability',
                'capacity',
                'analytics',
                'templates',
                'recurring',
            ].includes(selected)
        )
            params.set(key, selected);
        if (
            /^(staff_id|client_id)$/.test(key) &&
            /^[1-9]\d*$/.test(selected) &&
            Number.isSafeInteger(Number(selected))
        )
            params.set(key, selected);
    }
    return url.pathname + (params.size ? `?${params}` : '');
}

export function useShiftAssignment({
    actorId,
    canManage,
    returnTo,
    onSaved,
}: {
    actorId: number | undefined;
    canManage: boolean;
    returnTo: string;
    onSaved: (action: 'assign' | 'unassign', shiftId: number) => void;
}) {
    const [feedback, setFeedback] = useState<
        Record<number, AssignmentFeedback>
    >({});
    const current = useRef({ actorId, canManage, onSaved });
    useLayoutEffect(() => {
        current.current = { actorId, canManage, onSaved };
    }, [actorId, canManage, onSaved]);
    const previousActor = useRef(actorId);
    const held = useRef(new Set<string>());
    const active = useRef<{
        actor: number;
        shift: number;
        identity: symbol;
        posted: boolean;
    } | null>(null);
    const mounted = useRef(true);
    useEffect(() => {
        mounted.current = true;
        return () => {
            mounted.current = false;
            active.current = null;
        };
    }, []);
    useLayoutEffect(() => {
        if (!canManage || previousActor.current !== actorId) {
            if (active.current?.posted)
                held.current.add(
                    `${active.current.actor}:${active.current.shift}`,
                );
            active.current = null;
            setFeedback({});
        }
        previousActor.current = actorId;
    }, [canManage, actorId]);
    function update(shiftId: number, value: AssignmentFeedback) {
        if (mounted.current)
            setFeedback((prior) => ({ ...prior, [shiftId]: value }));
    }
    function validActor() {
        return (
            current.current.canManage &&
            typeof current.current.actorId === 'number' &&
            Number.isSafeInteger(current.current.actorId) &&
            current.current.actorId > 0
        );
    }
    function acquire(shiftId: number) {
        if (
            !validActor() ||
            active.current ||
            !Number.isSafeInteger(shiftId) ||
            shiftId <= 0
        )
            return null;
        const actor = current.current.actorId!;
        if (held.current.has(`${actor}:${shiftId}`)) {
            update(shiftId, {
                ...initial,
                uncertain: true,
                error: unknownMessage,
            });
            return null;
        }
        const token = {
            actor,
            shift: shiftId,
            identity: Symbol(),
            posted: false,
        };
        active.current = token;
        update(shiftId, { ...initial, pending: true });
        return token;
    }
    function stillCurrent(token: NonNullable<typeof active.current>) {
        return (
            mounted.current &&
            active.current?.identity === token.identity &&
            validActor() &&
            current.current.actorId === token.actor
        );
    }
    function unknown(token: NonNullable<typeof active.current>) {
        if (!stillCurrent(token)) return;
        held.current.add(`${token.actor}:${token.shift}`);
        update(token.shift, {
            ...initial,
            uncertain: true,
            error: unknownMessage,
        });
    }
    function send(
        token: NonNullable<typeof active.current>,
        action: 'assign' | 'unassign',
        userId: number | null,
        source: AssignmentSource,
        acknowledgement?: { reason: string },
        reason?: string | null,
    ) {
        if (!stillCurrent(token)) return false;
        let requestId: string;
        try {
            requestId = crypto.randomUUID();
        } catch {
            update(token.shift, {
                ...initial,
                error: 'The request could not be started. Refresh the page before continuing.',
            });
            active.current = null;
            return false;
        }
        const expected: AssignmentAttempt = {
            action,
            actorId: token.actor,
            requestId,
            shiftId: token.shift,
            userId,
            source,
        };
        let settled = false;
        const settle = (receipt: unknown) => {
            if (!stillCurrent(token) || settled) return;
            settled = true;
            const result = assignmentOutcome(receipt, expected);
            if (result.outcome === 'saved') {
                update(token.shift, initial);
                toast.success(
                    action === 'assign'
                        ? 'Shift assigned.'
                        : 'Shift unassigned.',
                );
                current.current.onSaved(action, token.shift);
            } else if (result.outcome === 'not_saved') {
                update(token.shift, {
                    ...initial,
                    review: result.review,
                    reviewUserId: expected.userId,
                    error: messages[result.reason],
                });
            } else unknown(token);
        };
        try {
            token.posted = true;
            router.post(
                `/operations/shifts/${token.shift}/${action}`,
                {
                    request_id: requestId,
                    expected_source: source,
                    return_to: rosterAssignmentReturnTo(returnTo),
                    ...(action === 'assign'
                        ? { user_id: userId }
                        : { reason: reason || null }),
                    ...(acknowledgement
                        ? {
                              override_acknowledged: true,
                              override_reason: acknowledgement.reason,
                          }
                        : {}),
                },
                {
                    headers: { 'X-Shift-Assignment-Result': 'committed-v1' },
                    preserveScroll: true,
                    preserveState: true,
                    onSuccess: (page) => {
                        const auth = page.props.auth as
                            | { user?: { id?: unknown } }
                            | undefined;
                        if (
                            auth?.user?.id !== token.actor ||
                            page.props.canManageAny !== true
                        ) {
                            settled = true;
                            unknown(token);
                            return;
                        }
                        settle(
                            (
                                page.props.flash as
                                    | Record<string, unknown>
                                    | undefined
                            )?.shift_assignment_result,
                        );
                    },
                    onError: () => {
                        settled = true;
                        unknown(token);
                    },
                    onCancel: () => {
                        settled = true;
                        unknown(token);
                    },
                    onFinish: () => {
                        if (!stillCurrent(token)) return;
                        if (!settled) unknown(token);
                        active.current = null;
                    },
                },
            );
        } catch {
            unknown(token);
            active.current = null;
        }
        return true;
    }
    function assign(
        shiftId: number,
        userId: number,
        acknowledgement: { reason: string } | undefined,
        context: AssignmentContext | undefined,
    ) {
        if (
            !validActor() ||
            held.current.has(`${current.current.actorId}:${shiftId}`)
        )
            return false;
        if (
            !context ||
            context.actorId !== current.current.actorId ||
            !assignmentSource(context.source, shiftId) ||
            !assignmentDisplay(context.display, shiftId) ||
            !Number.isSafeInteger(userId) ||
            userId <= 0
        ) {
            update(shiftId, {
                ...initial,
                error: 'The staff checks are out of date. Refresh staff before assigning.',
            });
            return false;
        }
        const token = acquire(shiftId);
        return token
            ? send(token, 'assign', userId, context.source, acknowledgement)
            : false;
    }
    function unassign(
        shiftId: number,
        reason: string | null,
        context: AssignmentContext | undefined,
    ) {
        if (
            !validActor() ||
            held.current.has(`${current.current.actorId}:${shiftId}`)
        )
            return false;
        if (
            !context ||
            context.actorId !== current.current.actorId ||
            !assignmentSource(context.source, shiftId) ||
            !assignmentDisplay(context.display, shiftId) ||
            context.display.isOpen
        ) {
            update(shiftId, {
                ...initial,
                error: 'The shift details are out of date. Refresh the shift before continuing.',
            });
            return false;
        }
        const token = acquire(shiftId);
        return token
            ? send(token, 'unassign', null, context.source, undefined, reason)
            : false;
    }
    function checked(shiftId: number, context: AssignmentContext) {
        if (
            validActor() &&
            context.actorId === current.current.actorId &&
            assignmentSource(context.source, shiftId) &&
            !active.current &&
            !held.current.has(`${context.actorId}:${shiftId}`) &&
            feedback[shiftId]?.error
        )
            update(shiftId, initial);
    }
    function candidateChanged(shiftId: number, userId: number) {
        if (
            validActor() &&
            !active.current &&
            !held.current.has(`${current.current.actorId}:${shiftId}`) &&
            feedback[shiftId]?.review &&
            feedback[shiftId].reviewUserId !== userId
        )
            update(shiftId, initial);
    }
    return {
        assign,
        unassign,
        checked,
        candidateChanged,
        forShift: (shiftId: number | undefined) =>
            shiftId
                ? (feedback[shiftId] ??
                  (held.current.has(`${actorId}:${shiftId}`)
                      ? { ...initial, uncertain: true, error: unknownMessage }
                      : initial))
                : initial,
    };
}
