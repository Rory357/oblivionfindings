import { WORKER_LOCALE, WORKER_TIMEZONE } from '@/lib/datetime';

export function assignmentDate(
    value: string | null | undefined,
    timezone = WORKER_TIMEZONE,
): string {
    if (!value || !Number.isFinite(Date.parse(value)))
        return 'Date unavailable';
    try {
        return new Intl.DateTimeFormat(WORKER_LOCALE, {
            timeZone: timezone,
            weekday: 'short',
            day: 'numeric',
            month: 'short',
        }).format(new Date(value));
    } catch {
        return 'Date unavailable';
    }
}
export function assignmentRange(
    start: string | null | undefined,
    end: string | null | undefined,
    timezone = WORKER_TIMEZONE,
): string {
    if (!start || !Number.isFinite(Date.parse(start)))
        return 'Shift time unavailable';
    try {
        const time = new Intl.DateTimeFormat(WORKER_LOCALE, {
            timeZone: timezone,
            hour: 'numeric',
            minute: '2-digit',
            hour12: true,
        });
        const first = time.format(new Date(start)).toLowerCase();
        if (!end || !Number.isFinite(Date.parse(end)))
            return `${assignmentDate(start, timezone)} · ${first}`;
        const last = time.format(new Date(end)).toLowerCase();
        const startDate = assignmentDate(start, timezone),
            endDate = assignmentDate(end, timezone);
        return `${startDate} · ${first}–${startDate === endDate ? last : `${endDate}, ${last}`}`;
    } catch {
        return 'Shift time unavailable';
    }
}
