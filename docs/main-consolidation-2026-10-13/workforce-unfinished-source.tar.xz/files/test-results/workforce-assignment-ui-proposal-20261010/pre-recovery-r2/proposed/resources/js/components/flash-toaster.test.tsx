import { render } from '@testing-library/react';
import { beforeEach, expect, it, vi } from 'vitest';
import FlashToaster from './flash-toaster';
const { page, success, error, warning } = vi.hoisted(() => ({
    page: {
        component: 'operations/shift-notes/Index',
        props: {
            flash: {} as Record<string, unknown>,
            errors: {} as Record<string, unknown>,
        },
    },
    success: vi.fn(),
    error: vi.fn(),
    warning: vi.fn(),
}));
vi.mock('@inertiajs/react', () => ({ usePage: () => page }));
vi.mock('sonner', () => ({
    toast: Object.assign(vi.fn(), { success, error, warning }),
}));
beforeEach(() => {
    vi.clearAllMocks();
    page.component = 'operations/shift-notes/Index';
    page.props = { flash: {}, errors: {} };
});
it.each([undefined, { action: 'create', note_id: 7 }])(
    'leaves Notes success to its receipt-owning dialog',
    (receipt) => {
        page.props.flash = {
            success: 'Shift note added.',
            shift_note_result: receipt,
        };
        render(<FlashToaster />);
        expect(success).not.toHaveBeenCalled();
    },
);
it('preserves validation and error feedback on Notes', () => {
    page.props = {
        flash: { error: 'Access changed' },
        errors: { body: 'Write the note' },
    };
    render(<FlashToaster />);
    expect(error).toHaveBeenCalledWith('Access changed');
    expect(error).toHaveBeenCalledWith('Write the note');
});
it('preserves success notifications on other modules', () => {
    page.component = 'sites/Index';
    page.props.flash = { success: 'Site saved.' };
    render(<FlashToaster />);
    expect(success).toHaveBeenCalledWith('Site saved.');
});

it.each(['operations/timesheets/index', 'operations/rostering/index'])(
    'leaves single Timesheet results to their matching dialog on %s',
    (component) => {
        page.component = component;
        page.props.flash = { success: 'Timesheet updated.' };
        render(<FlashToaster />);
        expect(success).not.toHaveBeenCalled();
    },
);
it.each(['Selected timesheets approved.', 'Timesheet archived.'])(
    'preserves separate Timesheet catalogue and bulk feedback: %s',
    (message) => {
        page.component = 'operations/timesheets/index';
        page.props.flash = { success: message };
        render(<FlashToaster />);
        expect(success).toHaveBeenCalledWith(message);
    },
);

it.each([
    'Payroll adjustment marked as processed.',
    'This adjustment has already been marked as processed.',
])(
    'leaves external adjustment confirmation to its matching receipt: %s',
    (message) => {
        page.component = 'operations/timesheets/payroll-adjustments';
        page.props.flash = { success: message };
        render(<FlashToaster />);
        expect(success).not.toHaveBeenCalled();
    },
);

it.each([
    'operations/shifts/index',
    'operations/rostering/index',
    'operations/shifts/create',
    'operations/shifts/show',
    'operations/clients/show',
    'operations/rostering/conflicts',
])(
    'leaves single Shift confirmation to the owning wizard on %s',
    (component) => {
        page.component = component;
        page.props.flash = { success: 'Shift updated.' };
        render(<FlashToaster />);
        expect(success).not.toHaveBeenCalled();
    },
);
it('retains separate publish and series feedback on the Shift index', () => {
    page.component = 'operations/shifts/index';
    page.props.flash = { success: 'Shift published.' };
    render(<FlashToaster />);
    expect(success).toHaveBeenCalledWith('Shift published.');
});

it.each(['Leave request approved.', 'Leave request declined.'])(
    'leaves Rostering leave confirmation to the current decision dialog: %s',
    (message) => {
        page.component = 'operations/rostering/index';
        page.props.flash = { success: message };
        render(<FlashToaster />);
        expect(success).not.toHaveBeenCalled();
    },
);
it.each(['hr/leave/Index', 'hr/leave/Show'])(
    'preserves existing single-decision HR feedback on %s',
    (component) => {
        page.component = component;
        page.props.flash = { success: 'Leave request approved.' };
        render(<FlashToaster />);
        expect(success).toHaveBeenCalledWith('Leave request approved.');
    },
);
it('preserves separate bulk and error feedback in Rostering', () => {
    page.component = 'operations/rostering/index';
    page.props.flash = { success: 'Selected requests approved.' };
    const view = render(<FlashToaster />);
    expect(success).toHaveBeenCalledWith('Selected requests approved.');
    page.props.flash = {
        success: 'Leave request declined.',
        error: 'Request changed.',
    };
    view.rerender(<FlashToaster />);
    expect(error).toHaveBeenCalledWith('Request changed.');
    expect(success).toHaveBeenCalledTimes(1);
});

it.each(['Shift assigned.', 'Shift unassigned.'])(
    'leaves roster assignment confirmation to the correlated workflow: %s',
    (message) => {
        page.component = 'operations/rostering/index';
        page.props.flash = { success: message };
        render(<FlashToaster />);
        expect(success).not.toHaveBeenCalled();
    },
);
it('preserves legacy Shift assignment feedback outside Rostering', () => {
    page.component = 'operations/shifts/show';
    page.props.flash = { success: 'Shift assigned.' };
    render(<FlashToaster />);
    expect(success).toHaveBeenCalledWith('Shift assigned.');
});
