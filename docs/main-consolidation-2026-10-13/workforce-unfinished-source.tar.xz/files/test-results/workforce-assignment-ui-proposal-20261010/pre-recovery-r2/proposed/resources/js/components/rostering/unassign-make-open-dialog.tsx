import { AlertTriangle, Loader2 } from 'lucide-react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';

import { ConfirmDialog } from '@/components/confirm-dialog';

import { Button } from '@/components/ui/button';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { assignmentRange } from './assignment-time';
import {
    assignmentSnapshot,
    type AssignmentContext,
} from './shift-assignment-result';

export type UnassignMakeOpenShift = {
    id: number;
    starts_at?: string | null;
    ends_at?: string | null;
    client?: string | null;
    site?: string | null;
    staff?: string | null;
};

export type UnassignMakeOpenDialogProps = {
    open: boolean;
    shift: UnassignMakeOpenShift | null;
    pending?: boolean;
    error?: string | null;
    uncertain?: boolean;
    workerTimezone?: string;
    onChecked?: (context: AssignmentContext) => void;
    onOpenChange: (open: boolean) => void;
    onConfirm: (
        shift: UnassignMakeOpenShift,
        reason: string | null,
        context?: AssignmentContext,
    ) => boolean | void;
};

export function UnassignMakeOpenDialog({
    open,
    shift,
    pending = false,
    error: assignmentError = null,
    uncertain = false,
    workerTimezone,
    onChecked,
    onOpenChange,
    onConfirm,
}: UnassignMakeOpenDialogProps) {
    const [reason, setReason] = useState('');
    const [discardOpen, setDiscardOpen] = useState(false);
    const submitted = useRef(false);
    const checked = useRef(onChecked);
    useLayoutEffect(() => {
        checked.current = onChecked;
    }, [onChecked]);
    const [context, setContext] = useState<AssignmentContext | null>(null);
    const [loading, setLoading] = useState(false);
    const [loadError, setLoadError] = useState<string | null>(null);
    const [locked, setLocked] = useState(false);
    const [reload, setReload] = useState(0);
    const shiftId = shift?.id;

    useEffect(() => {
        if (!open || !shiftId) return;
        let cancelled = false;
        setContext(null);
        setLoading(true);
        setLoadError(null);
        setLocked(false);
        fetch(`/operations/shifts/${shiftId}/candidates`, {
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
        })
            .then(async (response) => {
                if (!response.ok) throw new Error('Current shift unavailable');
                const snapshot = assignmentSnapshot(
                    await response.json(),
                    shiftId,
                );
                if (!snapshot) throw new Error('Current shift unavailable');
                if (!cancelled) {
                    setContext(snapshot);
                    setLocked(snapshot.locked);
                    checked.current?.(snapshot);
                }
            })
            .catch(() => {
                if (!cancelled)
                    setLoadError(
                        'Current shift details could not be checked. Refresh the shift before continuing.',
                    );
            })
            .finally(() => {
                if (!cancelled) setLoading(false);
            });
        return () => {
            cancelled = true;
        };
    }, [open, shiftId, reload]);

    useEffect(() => {
        if (open) {
            setReason('');
            setDiscardOpen(false);
            submitted.current = false;
        }
    }, [open, shift?.id]);

    useEffect(() => {
        if (!pending) submitted.current = false;
    }, [pending]);

    if (!shift) return null;

    const displayed = context?.display;
    const dateLabel = displayed
        ? assignmentRange(
              displayed.starts_at,
              displayed.ends_at,
              workerTimezone,
          )
        : 'Checking current shift details…';
    const trimmedReason = reason.trim();

    function requestClose() {
        if (pending) return;
        if (trimmedReason) setDiscardOpen(true);
        else onOpenChange(false);
    }

    function submit() {
        if (
            !shift ||
            !context ||
            loading ||
            locked ||
            context.display.isOpen ||
            pending ||
            uncertain ||
            submitted.current
        )
            return;
        submitted.current = true;
        if (
            onConfirm(context.display, trimmedReason || null, context) === false
        )
            submitted.current = false;
    }

    return (
        <>
            <Dialog
                open={open}
                onOpenChange={(isOpen) => {
                    if (!isOpen) requestClose();
                }}
            >
                <DialogContent
                    showCloseButton={!pending}
                    className="max-h-[88dvh] overflow-y-auto"
                    style={{
                        width: 'min(92vw, 480px)',
                        maxWidth: 'min(92vw, 480px)',
                    }}
                >
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <AlertTriangle className="h-5 w-5 text-status-warning" />
                            Unassign and make open
                        </DialogTitle>
                        <DialogDescription>
                            You are about to unassign this shift.
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-3 py-2">
                        <div className="rounded-md border border-status-warning/25 bg-status-warning-bg px-3 py-2 text-sm break-words text-status-warning">
                            {dateLabel}
                            {displayed?.client ? ` · ${displayed.client}` : ''}
                            {displayed?.site ? ` · ${displayed.site}` : ''}
                            {displayed?.staff
                                ? ` · currently ${displayed.staff}`
                                : ''}
                        </div>
                        {displayed ? (
                            <p className="text-subtle">
                                Review these current shift details before
                                confirming.
                            </p>
                        ) : null}
                        {locked || displayed?.isOpen ? (
                            <p role="alert" className="text-subtle">
                                {locked
                                    ? 'This shift is completed or cancelled. It cannot be unassigned.'
                                    : 'There is no staff member assigned to this shift.'}
                            </p>
                        ) : null}
                        <div className="space-y-1.5">
                            <Label
                                htmlFor="unassign-make-open-reason"
                                className="text-sm font-medium"
                            >
                                Reason (optional)
                            </Label>
                            <Textarea
                                id="unassign-make-open-reason"
                                value={reason}
                                onChange={(event) =>
                                    setReason(event.target.value)
                                }
                                rows={4}
                                maxLength={2000}
                                disabled={pending || loading || !context}
                                readOnly={uncertain}
                                placeholder="e.g. Staff called in sick"
                            />
                            <p className="text-xs text-muted-foreground">
                                Not mandatory, but useful for audit and roster
                                handover.
                            </p>
                        </div>
                    </div>
                    {assignmentError || loadError ? (
                        <p
                            role="alert"
                            className="text-subtle break-words text-status-critical"
                        >
                            {assignmentError || loadError}
                        </p>
                    ) : null}
                    {uncertain ? (
                        <p className="text-subtle">
                            Check this shift before trying again. The request
                            may already have changed the roster.
                        </p>
                    ) : null}
                    <DialogFooter className="flex-wrap">
                        {uncertain ? (
                            <Button
                                asChild
                                variant="outline"
                                className="max-md:min-h-[44px]"
                            >
                                <a href={`/operations/shifts/${shift.id}`}>
                                    Open shift
                                </a>
                            </Button>
                        ) : null}
                        <Button
                            variant="outline"
                            className="max-md:min-h-[44px]"
                            disabled={pending || loading || uncertain}
                            onClick={() => setReload((value) => value + 1)}
                        >
                            Refresh shift
                        </Button>
                        <Button
                            variant="outline"
                            className="max-md:min-h-[44px]"
                            disabled={pending}
                            onClick={requestClose}
                        >
                            Cancel
                        </Button>
                        <Button
                            variant="destructive"
                            className="h-auto max-w-full whitespace-normal max-md:min-h-[44px]"
                            disabled={
                                pending ||
                                uncertain ||
                                loading ||
                                !context ||
                                locked ||
                                displayed?.isOpen
                            }
                            onClick={submit}
                        >
                            {pending ? (
                                <Loader2
                                    aria-hidden="true"
                                    className="size-4 animate-spin"
                                />
                            ) : null}
                            {pending
                                ? 'Saving…'
                                : loading
                                  ? 'Checking shift…'
                                  : 'Unassign and make open'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
            <ConfirmDialog
                open={discardOpen}
                onClose={() => setDiscardOpen(false)}
                title="Discard this reason?"
                description="Your entered reason will be removed."
                confirmText="Discard reason"
                cancelText="Keep editing"
                buttonClassName="max-md:min-h-[44px]"
                onConfirm={() => {
                    setReason('');
                    setDiscardOpen(false);
                    onOpenChange(false);
                }}
            />
        </>
    );
}

export default UnassignMakeOpenDialog;
