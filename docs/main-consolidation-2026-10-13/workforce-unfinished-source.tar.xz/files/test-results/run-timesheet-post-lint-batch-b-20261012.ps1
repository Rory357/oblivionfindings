param(
    [Parameter(Mandatory)][string]$ReviewedRunnerSha256,
    [Parameter(Mandatory)][string]$ReviewedConfigSha256,
    [Parameter(Mandatory)][ValidatePattern('^[a-z0-9-]{1,40}$')][string]$Attempt
)
$ErrorActionPreference = 'Stop'
$wfRoot = 'C:/Users/steph/Herd/oblivionfindings'
$wfConfig = Join-Path $wfRoot 'test-results/timesheet-post-lint-batch-b-20261012.vitest.config.mjs'
$wfPacket = Join-Path $wfRoot 'test-results/workforce-timesheet-legacy-owner-r3-20261012'
$wfOut = Join-Path $wfRoot ('test-results/timesheet-post-lint-batch-b-actual-' + $Attempt + '-20261012')
$wfNode = 'C:/Users/steph/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node.exe'
function Get-WfHash([string]$Path) { return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant() }
if ((Get-WfHash $PSCommandPath) -cne $ReviewedRunnerSha256 -or (Get-WfHash $wfConfig) -cne $ReviewedConfigSha256) { throw 'Reviewed runner/config changed.' }
if (Test-Path -LiteralPath $wfOut) { throw 'Preserve earlier attempt evidence.' }
if ((Get-WfHash (Join-Path $wfPacket 'manifest.json')) -cne 'c63f08a2c4d7797fe9665077c26f16a00c41d1005518c696ac6154f58e4c8be3') { throw 'Reviewed candidate changed.' }
$wfManifest = Get-Content -LiteralPath (Join-Path $wfPacket 'manifest.json') -Raw | ConvertFrom-Json -AsHashtable
$wfPins = @{}
foreach ($wfItem in $wfManifest.files.GetEnumerator()) { $wfPins[(Join-Path $wfPacket $wfItem.Key)] = $wfItem.Value }
$wfPostLintBindingPath = Join-Path $wfRoot 'test-results/workforce-timesheet-post-lint-fix-20261012/manifest.json'
if ((Get-WfHash $wfPostLintBindingPath) -cne 'f0b5e870954437acba34a66eec9c175c20a67bb7b5eb0df3fcdbb122b313f41a') { throw 'Reviewed exact post-lint binding changed.' }
$wfPostLintBinding = Get-Content -LiteralPath $wfPostLintBindingPath -Raw | ConvertFrom-Json -AsHashtable
if ($wfPostLintBinding.source_manifest_sha256 -cne 'c63f08a2c4d7797fe9665077c26f16a00c41d1005518c696ac6154f58e4c8be3' -or $wfPostLintBinding.source_updates.Count -ne 2) { throw 'Post-lint source lineage differs.' }
foreach ($wfUpdate in $wfPostLintBinding.source_updates.GetEnumerator()) {
    if (!$wfManifest.sources.ContainsKey($wfUpdate.Key) -or $wfManifest.sources[$wfUpdate.Key].after_sha256 -cne $wfUpdate.Value.before_sha256) { throw 'Post-lint transition is outside the reviewed owned source.' }
    # Only local expected input metadata changes; frozen R3 artifacts stay exact.
    $wfManifest.sources[$wfUpdate.Key].after_sha256 = $wfUpdate.Value.after_sha256
}
$wfPins[$wfPostLintBindingPath] = 'f0b5e870954437acba34a66eec9c175c20a67bb7b5eb0df3fcdbb122b313f41a'
$wfApplicationReceipt = Join-Path $wfRoot 'test-results/timesheet-post-lint-applied-20261012.json'
if ((Get-WfHash $wfApplicationReceipt) -cne '3f5eeb578bd36cca8e38638bbd20a5668f7e0aff1d96c6ef16778c8fc8930191') { throw 'Reviewed owned application receipt changed.' }
$wfApplied = Get-Content -LiteralPath $wfApplicationReceipt -Raw | ConvertFrom-Json -AsHashtable
if ($wfApplied.paths.Count -ne $wfManifest.sources.Count) { throw 'Owned application inventory changed.' }
foreach ($wfItem in $wfManifest.sources.GetEnumerator()) {
    if (!$wfApplied.paths.ContainsKey($wfItem.Key) -or $wfApplied.paths[$wfItem.Key] -cne $wfItem.Value.after_sha256) { throw 'Owned applied image differs from reviewed candidate.' }
    $wfPins[(Join-Path $wfRoot $wfItem.Key)] = $wfItem.Value.after_sha256
}
$wfPins[$wfApplicationReceipt] = Get-WfHash $wfApplicationReceipt
foreach ($wfItem in $wfManifest.dependencies.GetEnumerator()) {
    # Only the sixteen deliberately applied owned images advance from their
    # recorded before to exact reviewed after; unrelated context stays frozen.
    $wfExpected = if ($wfManifest.sources.ContainsKey($wfItem.Key)) { $wfManifest.sources[$wfItem.Key].after_sha256 } else { $wfItem.Value }
    $wfPins[(Join-Path $wfRoot $wfItem.Key)] = $wfExpected
}
$wfPins[$wfConfig] = $ReviewedConfigSha256
$wfPins[$PSCommandPath] = $ReviewedRunnerSha256
$wfRuntimeInputs = Join-Path $wfRoot 'test-results/timesheet-post-lint-runtime-inputs-20261012.json'
if ((Get-WfHash $wfRuntimeInputs) -cne 'f50064793c6a2b75aa372af75d367cc8f306c6f94dc37f0c0742761f362a8748') { throw 'Reviewed runtime import pins changed.' }
$wfPins[$wfRuntimeInputs] = Get-WfHash $wfRuntimeInputs
$wfRuntimeMap = Get-Content -LiteralPath $wfRuntimeInputs -Raw | ConvertFrom-Json -AsHashtable
foreach ($wfItem in $wfRuntimeMap.inputs.GetEnumerator()) { $wfPins[$wfItem.Key] = $wfItem.Value }
$wfClassifier = 'C:/Users/steph/.codex/worktrees/health-safety-workspace/oblivionfindings/.playwright-cli/hs-process-classifier.ps1'
$wfClassifierBytes = [IO.File]::ReadAllBytes($wfClassifier)
$wfClassifierDigest = [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($wfClassifierBytes)).ToLowerInvariant()
if ($wfClassifierDigest -cne $wfRuntimeMap.inputs[[IO.Path]::GetFullPath($wfClassifier)]) { throw 'Shared classifier bytes changed before loading.' }
# Execute the same verified bytes, never re-open a peer-owned source for execution.
. ([ScriptBlock]::Create([Text.Encoding]::UTF8.GetString($wfClassifierBytes)))
foreach ($wfPath in @('resources/js/test/setup.ts', 'vitest.config.ts', 'package.json', 'node_modules/vitest/vitest.mjs')) {
    $wfFull = Join-Path $wfRoot $wfPath; if (!$wfPins.ContainsKey($wfFull)) { $wfPins[$wfFull] = Get-WfHash $wfFull }
}
function Test-WfPins { foreach ($wfItem in $wfPins.GetEnumerator()) { if ((Get-WfHash $wfItem.Key) -cne $wfItem.Value) { throw ('Input changed: ' + $wfItem.Key) } } }
Test-WfPins
New-Item -ItemType Directory -Path $wfOut | Out-Null
$wfGate = [Threading.Mutex]::new($false, 'Local\OblivionWorkforceMainIntegrationNativeGate')
$wfHeld = $false; $wfStarted = $false; $wfProcess = $null; $wfIssue = $null
$wfSamples = @(); $wfExit = $null; $wfReport = $null; $wfAfterComplete = $false
$wfStdout = $null; $wfStderr = $null; $wfOwnPid = $null; $wfOwnClosed = $false; $wfStreamsClosed = $false
function Read-WfAdmission([int]$OwnPid = 0) {
    $wfOs = Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10
    $wfCpu = Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10
    $wfProcesses = @(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    if (!$wfOs -or $null -eq $wfOs.FreePhysicalMemory -or $wfOs.FreePhysicalMemory -le 0 -or
        !$wfCpu -or $null -eq $wfCpu.PercentProcessorTime -or $wfCpu.PercentProcessorTime -lt 0 -or
        $wfCpu.PercentProcessorTime -gt 100 -or $wfProcesses.Count -eq 0 -or
        @($wfProcesses | Group-Object ProcessId | Where-Object Count -NE 1).Count -gt 0 -or
        @($wfProcesses | Where-Object { $null -eq $_.ProcessId -or !$_.Name -or
            ($_.Name -eq 'node.exe' -and !$_.CommandLine) }).Count -gt 0) { throw 'Incomplete/invalid current resource or process observations.' }
    # Reuse the unchanged shared heavy-first engine. Unknown Node hosts stay unknown.
    $wfClassification = Get-ProcessClassification -ObservedProcesses @($wfProcesses | Where-Object ProcessId -NE $OwnPid) -ToolServiceIdentity $null
    $wfUnknownNative = @($wfProcesses | Where-Object { $_.ProcessId -in $wfClassification.unknownIds -and $_.Name -ne 'node.exe' })
    $wfHeavyIds = @($wfClassification.heavyNodeIds) + @($wfClassification.competingNativeIds) + @($wfUnknownNative | ForEach-Object ProcessId)
    $wfSamples += @{ utc = [DateTimeOffset]::UtcNow.ToString('o'); free_mib = [math]::Floor($wfOs.FreePhysicalMemory / 1024);
        cpu_percent = [int]$wfCpu.PercentProcessorTime; heavy_peer_ids = @($wfHeavyIds);
        complete_process_count = $wfProcesses.Count;
        node_hosts_observed = @($wfProcesses | Where-Object Name -EQ 'node.exe').Count;
        unknown_node_observations = @($wfProcesses | Where-Object { $_.Name -eq 'node.exe' -and $_.ProcessId -in $wfClassification.unknownIds } | ForEach-Object {
            @{ pid = [int]$_.ProcessId; parent_pid = [int]$_.ParentProcessId; name = $_.Name;
                birth_utc = $(if ($_.CreationDate) { $_.CreationDate.ToUniversalTime().ToString('o') } else { $null });
                executable = $_.ExecutablePath; classification = 'UNKNOWN' }
        });
        unknown_hosts_classified_idle = $false }
    Set-Variable -Scope Script -Name wfSamples -Value $wfSamples
    if ($wfSamples[-1].free_mib -lt 4096 -or $wfSamples[-1].cpu_percent -ge 70 -or $wfHeavyIds.Count -gt 0) { throw 'Current per-job resource/heavy-peer admission held.' }
}
try {
    try { $wfHeld = $wfGate.WaitOne(0) } catch [Threading.AbandonedMutexException] { $wfHeld = $true }
    if (!$wfHeld) { throw 'Shared test mutex is busy.' }
    Read-WfAdmission
    Start-Sleep -Milliseconds 500
    Read-WfAdmission
    Test-WfPins
    $wfStart = [Diagnostics.ProcessStartInfo]::new()
    $wfStart.FileName = $wfNode; $wfStart.WorkingDirectory = $wfRoot
    $wfStart.UseShellExecute = $false; $wfStart.CreateNoWindow = $true
    $wfStart.RedirectStandardOutput = $true; $wfStart.RedirectStandardError = $true
    foreach ($wfArg in @('--max-old-space-size=1024', 'node_modules/vitest/vitest.mjs', 'run', '--config', $wfConfig, '--configLoader', 'native',
        '--maxWorkers=1', '--pool=threads', '--fileParallelism=false', '--reporter=json', ('--outputFile=' + (Join-Path $wfOut 'vitest.json')))) {
        $wfStart.ArgumentList.Add($wfArg)
    }
    $wfProcess = [Diagnostics.Process]::new(); $wfProcess.StartInfo = $wfStart
    if (!$wfProcess.Start()) { throw 'Own test process did not start.' }
    $wfStarted = $true; $wfOwnPid = $wfProcess.Id
    $wfStdout = $wfProcess.StandardOutput.ReadToEndAsync(); $wfStderr = $wfProcess.StandardError.ReadToEndAsync()
    $wfClock = [Diagnostics.Stopwatch]::StartNew(); $wfLastSample = 0
    while (!$wfProcess.WaitForExit(1000)) {
        if ($wfClock.Elapsed.TotalSeconds -ge 60) { throw 'Own bounded test exceeded its cooperative 60-second deadline.' }
        if ($wfClock.Elapsed.TotalSeconds - $wfLastSample -ge 3) {
            Read-WfAdmission -OwnPid $wfProcess.Id
            $wfLastSample = $wfClock.Elapsed.TotalSeconds
        }
    }
    $wfExit = $wfProcess.ExitCode
    if (Test-Path -LiteralPath (Join-Path $wfOut 'vitest.json')) { $wfReport = Get-Content -LiteralPath (Join-Path $wfOut 'vitest.json') -Raw | ConvertFrom-Json }
    if ($wfExit -ne 0 -or !$wfReport.success -or $wfReport.numFailedTests -ne 0 -or $wfReport.numPendingTests -ne 0) { throw 'Affected suites failed; retain actual diagnostics.' }
} catch { $wfIssue = $_.Exception.Message }
finally {
    try {
        if ($wfStarted -and $wfProcess -and !$wfProcess.HasExited) {
            # This held Process object is exclusively the child started above.
            # Never adopt a PID or stop a peer/preview/service.
            $wfProcess.Kill($true)
            if (!$wfProcess.WaitForExit(10000)) { throw 'Own child exit remains unconfirmed after bounded termination.' }
        }
        $wfOwnClosed = !$wfStarted -or $wfProcess.HasExited
        if ($wfStarted -and $wfOwnClosed) {
            $wfStreamsClosed = $wfStdout.Wait(3000) -and $wfStderr.Wait(3000)
            foreach ($wfStream in @(@{ task = $wfStdout; file = 'tests.stdout.log' }, @{ task = $wfStderr; file = 'tests.stderr.log' })) {
                if ($wfStream.task.IsCompletedSuccessfully) {
                    [IO.File]::WriteAllText((Join-Path $wfOut $wfStream.file), $wfStream.task.Result)
                } else {
                    [IO.File]::WriteAllText((Join-Path $wfOut $wfStream.file), 'Output stream closure remains unconfirmed; no complete log is claimed.')
                }
            }
            if (!$wfStreamsClosed) { $wfIssue = 'Own output streams did not close within bounded draining.' }
        }
        Test-WfPins; $wfAfterComplete = $true
    } catch { $wfIssue = $_.Exception.Message }
    finally {
        if ($wfHeld) { $wfGate.ReleaseMutex() }
        $wfGate.Dispose()
        if ($wfProcess) { $wfProcess.Dispose() }
    }
}
$wfResult = @{ state = $(if ($wfStarted -and $wfExit -eq 0 -and !$wfIssue -and $wfOwnClosed -and $wfStreamsClosed) { 'ACTUAL_AFFECTED_SUITES_PASSED' } else { 'HELD_OR_FAILED' });
    started = $wfStarted; own_pid = $wfOwnPid; issue = $wfIssue; test_exit = $wfExit; resources = $wfSamples; input_pins = $wfPins;
    after_read_complete = $wfAfterComplete; own_child_exit_confirmed = $wfOwnClosed; output_streams_closed = $wfStreamsClosed; actual_total = $wfReport.numTotalTests; actual_passed = $wfReport.numPassedTests;
    actual_failed = $wfReport.numFailedTests; actual_pending = $wfReport.numPendingTests;
    worker_count = 1; max_heap_mib = 1024; deadline_seconds = 60; maximum_observation_overrun_seconds = 30; product_applied = $true;
    php_database_build_browser = $false; typecheck_included = $false; unknown_hosts_classified_idle = $false }
$wfResult | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $wfOut 'result.json') -Encoding utf8
$wfResult | Select-Object state,started,issue,test_exit,actual_total,actual_passed,actual_failed,actual_pending,after_read_complete | ConvertTo-Json
exit $(if ($wfResult.state -ceq 'ACTUAL_AFFECTED_SUITES_PASSED') { 0 } else { 1 })
