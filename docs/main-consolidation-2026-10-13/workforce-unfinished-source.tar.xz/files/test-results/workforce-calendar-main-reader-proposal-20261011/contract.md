# Calendar reader proposal for current MAIN

This is an inactive two-path source proposal, rebased on the current Calendar controller. It repairs only `events` and adds two private reader helpers/imports. Constructor, store, update and existing normalisation/client-match helpers remain byte-exact. No product, framework, parser, database, process or Git action has been performed. Calendar move/create authority, unchecked save/readback, root commit and uncertain response remain separate open writer work.

The route still requires the approved account/portal and `rostering.viewAny`. `shifts.viewAny` permits canonical coworkers in approved Sites; `shifts.manageAny` retains the existing feed Site exception. Other admitted readers keep own published duties (or legacy unpublished duties when publication is disabled). No new grants. Current `UserSiteAccessService` controls active/nonarchived Sites and canonical Client/Site/current-worker integrity. Selected scalar or flat Site IDs are intersected with that scope, never expand it; at most 50 requested IDs. Staff/Client filters narrow broad-reader displayed duties and do not remove legitimate coverage supply. Own-only display filters cannot expose another worker.

Civil date edges use configured worker timezone, falling back to app timezone then UTC; explicit offsets retain their instants. Start/end are normalised once to UTC for SQL and owning coverage. Only normalised order is compared. Start is inclusive, end exclusive; equal range is empty, overlap/carry-in is retained. Weekly coverage still uses its installed local-day rule expansion; no overnight/start-day/month staffing redesign.

Management coverage calls the existing owning coverage service per lawful selected Site. Every returned window—including exact hidden supply—is checked against canonical rules, Shifts and series before scalar projection. Unavailable/unsafe evidence never becomes assessed zero or leaked related models. Owning-service exceptions propagate as a failed request rather than a successful empty feed. This is an ordinary request read, not an atomic current-authority or concurrent-write certification.

Real numeric Shift IDs and existing event/status/task/Respite fields remain. Foreign service-context labels/IDs, corrupt linked series and replacements are withheld. `extendedProps.can_view_shift` is an additive boolean, computed only when the actor has current Show route viewAny/viewAssigned, its conditional own/publication rule, and canonical Site scope under the separate `reports.viewAny` exception. It implies no Edit, assignment or medication authority. Current Shift Show/eMAR source is untouched.

Exactly one non-event descriptor is appended to the existing array:

```ts
{
  id: 'roster-calendar-assessment', title: '', start: null, end: null,
  extendedProps: {
    event_type: 'calendar_assessment', schema_version: 1,
    actor_id: number, worker_timezone: string,
    range: { start: string, end: string, end_exclusive: true }, // canonical UTC ISO instants
    filters: { staff_id: number | null, client_id: number | null, site_ids: number[] | null },
    scope: {
      kind: 'approved_sites' | 'own', site_ids: number[], published_only: boolean,
      staff_id: number | null, client_id: number | null
    },
    coverage: {
      status: 'assessed' | 'partially_assessed' | 'not_assessed',
      reason: null | 'unsafe_source' | 'permission' | 'no_sites',
      finding_count: number | null
    }
  }
}
```

Requested Site IDs and effective cohort IDs are sorted/deduplicated; no 50-ID bound is applied to the full approved Site cohort. Filters echo validated requested identity; scope records effective authority/selection. Own scope fixes staff_id to the actor and client_id to null. Published_only follows the actual installed publication flag.

`assessed` means every owning-service window for the lawful Site cohort passed projection; reason is null and finding_count is the nonnegative count of actionable gap windows (zero is known zero). This is neither monthly/staff-specific availability nor Control Room actual duty. `partially_assessed` means one or more unsafe source windows were withheld; reason is unsafe_source and count is null even if some safe findings remain. `not_assessed` uses permission when the actor lacks the existing management coverage grant, or no_sites when the manager's lawful selected cohort is empty; count is null. Non-2xx errors mean the entire range is unavailable.

**Frontend composition is mandatory before applying this payload.** The only actual current endpoint fetch is CalendarPane→useRosterCalendarFeed. Its strict validEvents decoder rejects this descriptor because it has a non-event ID and null dates. Parent must separately decode/validate exactly one descriptor against actor/timezone/range/normalised filters/cohort, remove it from events, and keep an unknown/malformed/missing descriptor unavailable. It must never become a shift, care event, drag target or count. Existing mapShift already rejects null dates and mapGap rejects the descriptor type, but that happens after the current hook's rejection. Generated action/route modules describe the same endpoint; they contain no independent fetch/render consumer. calendar-shared is a type consumer only. No other non-generated production caller of this exact route/path was found. Future decoder must preserve real array event semantics and default-deny Show action unless can_view_shift is exactly true.

The historical-corrected Calendar test is reused byte-exact: 18 test declarations / 38 source-derived dataset cases, including permission, privacy, unsafe hidden supply, mixed civil/offset and DST/Show controls. Its lawful fixtures are explicitly reconciled to current AppSetting JSON casts, UTC frozen clock, normal Shift observer invariants and current Show permission/Site rules in fixture-rebase.json. Those historical source assertions and DELIVERY results are not current MAIN acceptance. Current MAIN58/19 evidence remains unproved. Future selection also includes whole current WorkforceRosteringReadPermissionIntegrityTest and whole six-method RespiteReadinessTest. Actual union is null until real framework listing. No new human policy is assumed; existing exceptions/publication/all-status feed behavior remain.
