# Independent Calendar MAIN reader source review

CLEAR_SOURCE_ONLY against manifest `eb145495` / patch `ad001760`. All 12 authored hashes, current 40 dependencies and seven historical references match. Both whole-file raw forwards/inverses, the constructor and complete store-to-end writer suffix are exact. The new test equals the lawful historical corrected bytes: 18 declarations / 38 source-derived controls. The whole current roster reader and six-method Respite class are retained; actual union inventory/count remains null.

No new implementation or fixture blocker was found. Civil/offset bounds are compared after UTC normalization with half-open overlap; Site/Client/current-worker and series integrity remain scoped. Coverage uses complete lawful Site supply before display filtering, checks hidden windows, and distinguishes unsafe/partial and unassessed from known zero. The numeric `can_view_shift` projection independently repeats the current Show viewAny/viewAssigned, conditional owner/publication and reports Site boundary; it is not an edit/assignment grant.

**Mandatory composition prerequisite:** current `resources/js/components/rostering/use-roster-calendar-feed.ts:18` accepts only real numeric/gap events with dates; its response decoder at line 91 rejects the assessment descriptor. Parent must compose the reviewed typed descriptor decoder/removal and default-deny Show consumer before applying the backend. This is an explicit integration hold, not a source defect hidden by this clearance.

JSON-encoded raw AppSetting updates, UTC frozen clock, lawful blank-zone setup ordering and actual completed timestamps are retained. Meaningful controls cover denied grants/Sites, mixed/DST edges, filtered supply, unsafe hidden Shift/series sources, real Show responses, whole state and Queue no-write preservation. No PHP/parser/framework/native/browser action was performed.

Calendar writer authority/save/readback/root-commit/recovery remains open. Current-MAIN58/19 evidence is unlocated and unproved; historical DELIVERY58 and old failures/abandoned schema are not relabelled. Full native/current frontend/browser acceptance is still required.
