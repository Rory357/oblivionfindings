# Parent review and future validation

Two proposed paths only: CalendarController reader code and new WorkforceCalendarReadIntegrityTest. `repair.patch` applies to the exact current controller before-image and absent test; `inverse.patch` restores those exact bytes/absence. No source application is authorised by this packet.

1. Independently review the source, current dependency snapshot, raw full forward/inverse and fixture rebase. Keep the separate current frontend marker decoder prerequisite open.
2. Review the parent-owned frontend descriptor/action composition before applying the payload; current hook rejects the descriptor. Preserve current eMAR and writer methods.
3. Parent admits syntax/Pint and real framework inventory in a fresh owned isolated current-MAIN mirror with current autoload/reflection, ordinary pending migrations and real Rostering Index/Shift Show pages. The three whole selected classes are in selection.json. Actual inventory/counts remain null. No launcher or schema helper is supplied here.
4. Separate native GO/resource/shared-gate/owned process and schema closure are required, preserving prior failed files and abandoned schema. Historical DELIVERY58 or frontend22 cannot close this source patch.
5. Verify actual scoped role/Site/civil-DST/filter/Show and unavailable-vs-zero browser journeys on the current bundle. Calendar saved-move/create authority/unchecked save/current returned tuple/physical root and transport recovery are explicitly outside this reader increment and remain open.

Only fresh ignored proposal files were authored. No private environment copy, product/source transfer, parser, PHP, SQL, process inspection, native or browser action occurred.
