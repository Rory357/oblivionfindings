from pathlib import Path
import datetime, difflib, hashlib, json, re

ROOT = Path('C:/Users/steph/Herd/oblivionfindings')
PACKET = ROOT / 'test-results/workforce-calendar-main-reader-proposal-20261011'
CONTROLLER = 'app/Http/Controllers/CalendarController.php'
TEST = 'tests/Feature/Rostering/WorkforceCalendarReadIntegrityTest.php'
HIST_CONTROLLER = 'test-results/workforce-calendar-format-proposal-20261010/proposed/' + CONTROLLER
HIST_TEST = 'test-results/workforce-calendar-fixture-input-repair-20261010/proposed/' + TEST
sha = lambda value: hashlib.sha256(value).hexdigest()

def dump(path, value):
    destination = PACKET / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))

def save(path, value):
    destination = PACKET / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        assert destination.read_bytes() == value, path
        return
    destination.write_bytes(value)

def block(data, method):
    match = re.search(rb'^    (?:public|protected|private)(?: static)? function ' + method.encode() + rb'\(', data, re.M)
    assert match, method
    index = data.find(b'{', match.start())
    depth, state = 0, None
    while index < len(data):
        pair, char = data[index:index+2], data[index:index+1]
        if state in (b"'", b'"'):
            if char == b'\\':
                index += 2
                continue
            if char == state:
                state = None
        elif state == b'//':
            if char == b'\n': state = None
        elif state == b'/*':
            if pair == b'*/':
                state = None
                index += 2
                continue
        elif char in (b"'", b'"'):
            state = char
        elif pair in (b'//', b'/*'):
            state = pair
            index += 2
            continue
        elif char == b'#':
            state = b'//'
        elif char == b'{':
            depth += 1
        elif char == b'}':
            depth -= 1
            if depth == 0: return data[match.start():index+1]
        index += 1
    raise AssertionError(method)

def patch(changes, reverse=False):
    result = b''
    for path, before, after in changes:
        if reverse: before, after = after, before
        left = b'/dev/null' if before is None else ('a/' + path).encode()
        right = b'/dev/null' if after is None else ('b/' + path).encode()
        result += b'diff --git a/' + path.encode() + b' b/' + path.encode() + b'\n'
        if before is None: result += b'new file mode 100644\n'
        if after is None: result += b'deleted file mode 100644\n'
        result += b''.join(difflib.diff_bytes(difflib.unified_diff,
            (before or b'').splitlines(keepends=True), (after or b'').splitlines(keepends=True),
            fromfile=left, tofile=right, n=3))
    return result

def reconstruct(before, patch_body):
    lines = patch_body.splitlines(keepends=True)
    original = (before or b'').splitlines(keepends=True)
    output, cursor, i = [], 0, 0
    while i < len(lines):
        line = lines[i]
        if not line.startswith(b'@@ '):
            i += 1
            continue
        match = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', line)
        assert match
        start = int(match.group(1)) - (1 if int(match.group(1)) else 0)
        assert start >= cursor
        output.extend(original[cursor:start]); cursor = start
        i += 1
        while i < len(lines) and not lines[i].startswith((b'@@ ', b'diff --git ')):
            item = lines[i]
            if item[:1] == b' ':
                assert original[cursor] == item[1:]
                output.append(item[1:]); cursor += 1
            elif item[:1] == b'-':
                assert original[cursor] == item[1:]
                cursor += 1
            elif item[:1] == b'+': output.append(item[1:])
            else: raise AssertionError(item)
            i += 1
    output.extend(original[cursor:])
    return b''.join(output)

before = (ROOT / CONTROLLER).read_bytes()
assert sha(before) == '69616a2f1233c2493f84301f198e8df1c8d2021d14ea35d4b4c2a797446a6f25'
assert not (ROOT / TEST).exists()
historical_controller = (ROOT / HIST_CONTROLLER).read_bytes()
historical_test = (ROOT / HIST_TEST).read_bytes()
assert sha(historical_controller) == '0539fe22a28c93a04b51b356fdb5def00380c6157a56a8bdf126e45329d65de1'
assert sha(historical_test) == 'e82fcb7aa91990d8a0c527aab23ed930454ffdf43a1d49b13a396c6fc559d0f9'
writer_marker = b'    public function storeShift(Request $request)'
after = historical_controller.split(writer_marker, 1)[0] + writer_marker + before.split(writer_marker, 1)[1]
preserved = ['__construct', 'storeShift', 'updateShift', 'normalizeShiftData', 'assertCoverageClientMatchesContext']
preservation = {method: {'before_sha256': sha(block(before, method)), 'after_sha256': sha(block(after, method)),
                         'exact': block(before, method) == block(after, method)} for method in preserved}
assert all(row['exact'] for row in preservation.values())
assert before.split(writer_marker, 1)[1] == after.split(writer_marker, 1)[1]
changes = [(CONTROLLER, before, after), (TEST, None, historical_test)]
save('before/' + CONTROLLER, before)
save('proposed/' + CONTROLLER, after)
save('proposed/' + TEST, historical_test)
forward, inverse = patch(changes), patch(changes, reverse=True)
save('repair.patch', forward)
save('inverse.patch', inverse)
inverses = []
for path, old, new in changes:
    single_forward, single_inverse = patch([(path, old, new)]), patch([(path, old, new)], reverse=True)
    assert reconstruct(old, single_forward) == (new or b'')
    assert reconstruct(new, single_inverse) == (old or b'')
    inverses.append({'path': path, 'raw_forward_exact': True, 'raw_inverse_exact': True,
                     'before_exists': old is not None, 'before_sha256': sha(old) if old is not None else None,
                     'after_sha256': sha(new) if new is not None else None})

selection = json.loads((ROOT / 'test-results/workforce-calendar-feed-proposal-r2-20261010/selection-source-derived.json').read_text(encoding='utf-8-sig'))
method_rows = selection['methods']
assert sum(row['source_derived_cases'] for row in method_rows) == 38
assert len(method_rows) == 18
for row in method_rows:
    body = block(historical_test, row['method'])
    if row['provider']:
        provider = block(historical_test, row['provider'])
        labels = re.findall(rb"'([^']+)'\s*=>", provider)
        assert len(labels) == row['source_derived_cases']
        row['source_derived_dataset_labels'] = [label.decode('utf-8') for label in labels]
    row['body_sha256'] = sha(body)
dump('selection.json', {
    'source_derived_only': True, 'framework_enumerated': False, 'actual_inventory': None,
    'actual_cases': None, 'actual_union_cases': None, 'approved': False, 'runtime_approved': False,
    'calendar_declared_cases': 38, 'calendar_declarations': method_rows,
    'files': [
        {'path': TEST, 'class': 'Tests\\Feature\\Rostering\\WorkforceCalendarReadIntegrityTest', 'scope': 'whole candidate class'},
        {'path': 'tests/Feature/Rostering/WorkforceRosteringReadPermissionIntegrityTest.php',
         'class': 'Tests\\Feature\\Rostering\\WorkforceRosteringReadPermissionIntegrityTest', 'scope': 'whole current class'},
        {'path': 'tests/Feature/Respite/RespiteReadinessTest.php', 'class': 'Tests\\Feature\\Respite\\RespiteReadinessTest',
         'scope': 'whole current six-method class', 'does_not_certify_calendar_move_writer': True}],
    'actual_listing_required_before_count_or_native_go': True})

dependencies = [
    CONTROLLER, 'app/Http/Controllers/ShiftController.php', 'app/Http/Controllers/RosteringController.php',
    'app/Services/UserSiteAccessService.php', 'app/Services/ShiftCoverageService.php', 'app/Services/CoverageRoleService.php',
    'app/Services/CurrentAuthorizationReads.php', 'app/Domain/Rostering/RosteringFeatureFlags.php',
    'app/Domain/Rostering/RosterPeriodService.php', 'app/Models/Shift.php', 'app/Models/ShiftSeries.php',
    'app/Models/Client.php', 'app/Models/Site.php', 'app/Models/User.php', 'app/Models/ServiceContext.php',
    'app/Models/SiteCoverageRequirement.php', 'app/Models/ShiftReplacementRequest.php', 'app/Models/AppSetting.php',
    'app/Support/ShiftTaskSupport.php', 'app/Domain/Hr/Models/HrEmployeeProfile.php',
    'app/Http/Middleware/EnsureAccountStillApproved.php', 'app/Http/Middleware/HandleInertiaRequests.php',
    'bootstrap/app.php', 'config/app.php', 'routes/operations.php', 'database/seeders/RbacSeeder.php',
    'database/factories/ShiftFactory.php', 'database/factories/ServiceContextFactory.php',
    'tests/TestCase.php', 'tests/Pest.php', 'tests/Support/FrozenClockTimezone.php',
    'tests/Feature/Rostering/WorkforceRosteringReadPermissionIntegrityTest.php',
    'tests/Feature/Respite/RespiteReadinessTest.php', 'resources/js/pages/operations/rostering/index.tsx',
    'resources/js/pages/operations/shifts/show.tsx', 'resources/js/components/rostering/calendar-pane.tsx',
    'resources/js/components/rostering/use-roster-calendar-feed.ts',
    'resources/js/components/rostering/calendar-shared.ts',
    'resources/js/actions/App/Http/Controllers/CalendarController.ts',
    'resources/js/routes/operations/rostering/calendar/index.ts',
]
pins = {path: sha((ROOT / path).read_bytes()) for path in dependencies}
dump('dependency-pins.json', {'root': str(ROOT), 'source_only_snapshot': True, 'pins': pins,
    'not_a_native_runtime_closure': True, 'head': None, 'head_not_inspected': True,
    'candidate_overlay': {CONTROLLER: sha(after), TEST: sha(historical_test)}})

historical_paths = [
    'test-results/workforce-calendar-current-main-source-reaudit-20261011/report.md',
    'test-results/workforce-calendar-current-main-source-reaudit-20261011/review.json',
    HIST_CONTROLLER, HIST_TEST,
    'test-results/workforce-calendar-feed-proposal-r2-20261010/manifest.json',
    'test-results/workforce-calendar-format-proposal-20261010/manifest.json',
    'test-results/workforce-calendar-fixture-input-repair-20261010/manifest.json',
]
historical = {path: sha((ROOT / path).read_bytes()) for path in historical_paths}
assert historical[historical_paths[0]] == '843fcc06e0c480c4fb5eb33a0a1bfb16e493ed7d84a0eed75702f74dac109f47'
assert historical[historical_paths[1]] == 'f957b2ada012237c75eca73f1031b0183c04e704501d651aedeb41360ce74146'
dump('fixture-rebase.json', {
    'current_main_test_before': 'ABSENT', 'historical_corrected_raw_source_sha256': sha(historical_test),
    'candidate_raw_source_sha256': sha(historical_test), 'whole_corrected_test_byte_exact': True,
    'all_18_case_method_bodies_providers_and_assertions_retained': True,
    '38_declarations_not_native_acceptance': True,
    'current_source_review': [
        'FrozenClockTimezone accepts the explicit UTC frozen instant used by setUp; no worker-zone frozen clock.',
        'AppSetting value is a JSON-cast field: normal updateOrCreate(true) and existing raw updates use JSON-encoded scalars, not SQL boolean 0/1.',
        'Completed fixture supplies actual_starts_at/actual_ends_at exactly equal to planned instants; normal Shift observers remain.',
        'Blank worker-zone case first creates all fixtures under valid UTC then sets worker zone blank immediately before the reader request.',
        'Actor remains approved support_worker with current Site employee profile and only literal permission overrides; no added grants or tenant fixtures.',
        'Canonical Site/Client/worker, service-context, series and replacement query primitives exist in current pinned MAIN.',
        'Current Show route still uses viewAny/viewAssigned, own publication conditional on management and reports.viewAny Site exception; current eMAR untouched.',
        'Real Rostering and Shift Show TSX page files are required for future HTTP/Inertia controls; tests do not disable page checks.',
        'Current full roster-reader and six-method Respite suites selected without editing them; no inferred preservation outcomes.'],
    'historical_references': historical,
    'unverified_current_main58_19': {'raw_locator': None, 'failure_attribution': None},
    'no_historical_delivery_acceptance_transferred': True})

contract = '''# Calendar reader proposal for current MAIN

This is an inactive two-path source proposal, rebased on the current Calendar controller. It repairs only `events` and adds two private reader helpers/imports. Constructor, store, update and existing normalisation/client-match helpers remain byte-exact. No product, framework, parser, database, process or Git action has been performed. Calendar move/create authority, unchecked save/readback, root commit and uncertain response remain separate open writer work.

The route still requires the approved account/portal and `rostering.viewAny`. `shifts.viewAny` permits canonical coworkers in approved Sites; `shifts.manageAny` retains the existing feed Site exception. Other admitted readers keep own published duties (or legacy unpublished duties when publication is disabled). No new grants. Current `UserSiteAccessService` controls active/nonarchived Sites and canonical Client/Site/current-worker integrity. Selected scalar or flat Site IDs are intersected with that scope, never expand it; at most 50 requested IDs. Staff/Client filters narrow broad-reader displayed duties and do not remove legitimate coverage supply. Own-only display filters cannot expose another worker.

Civil date edges use configured worker timezone, falling back to app timezone then UTC; explicit offsets retain their instants. Start/end are normalised once to UTC for SQL and owning coverage. Only normalised order is compared. Start is inclusive, end exclusive; equal range is empty, overlap/carry-in is retained. Weekly coverage still uses its installed local-day rule expansion; no overnight/start-day/month staffing redesign.

Management coverage calls the existing owning coverage service per lawful selected Site. Every returned window—including exact hidden supply—is checked against canonical rules, Shifts and series before scalar projection. Unavailable/unsafe evidence never becomes assessed zero or leaked related models. Owning-service exceptions propagate as a failed request rather than a successful empty feed. This is an ordinary request read, not an atomic current-authority or concurrent-write certification.

Real numeric Shift IDs and existing event/status/task/Respite fields remain. Foreign service-context labels/IDs, corrupt linked series and replacements are withheld. `extendedProps.can_view_shift` is an additive boolean, computed only when the actor has current Show route viewAny/viewAssigned, its conditional own/publication rule, and canonical Site scope under the separate `reports.viewAny` exception. It implies no Edit, assignment or medication authority. Current Shift Show/eMAR source is untouched.

Exactly one non-event descriptor is appended to the existing array:

```ts
{
  id: 'roster-calendar-assessment', title: '', start: null, end: null,
  extendedProps: {
    event_type: 'calendar_assessment', schema_version: 1,
    actor_id: number, worker_timezone: string,
    range: { start: string, end: string, end_exclusive: true }, // canonical UTC ISO instants
    filters: { staff_id: number | null, client_id: number | null, site_ids: number[] | null },
    scope: {
      kind: 'approved_sites' | 'own', site_ids: number[], published_only: boolean,
      staff_id: number | null, client_id: number | null
    },
    coverage: {
      status: 'assessed' | 'partially_assessed' | 'not_assessed',
      reason: null | 'unsafe_source' | 'permission' | 'no_sites',
      finding_count: number | null
    }
  }
}
```

Requested Site IDs and effective cohort IDs are sorted/deduplicated; no 50-ID bound is applied to the full approved Site cohort. Filters echo validated requested identity; scope records effective authority/selection. Own scope fixes staff_id to the actor and client_id to null. Published_only follows the actual installed publication flag.

`assessed` means every owning-service window for the lawful Site cohort passed projection; reason is null and finding_count is the nonnegative count of actionable gap windows (zero is known zero). This is neither monthly/staff-specific availability nor Control Room actual duty. `partially_assessed` means one or more unsafe source windows were withheld; reason is unsafe_source and count is null even if some safe findings remain. `not_assessed` uses permission when the actor lacks the existing management coverage grant, or no_sites when the manager's lawful selected cohort is empty; count is null. Non-2xx errors mean the entire range is unavailable.

**Frontend composition is mandatory before applying this payload.** The only actual current endpoint fetch is CalendarPane→useRosterCalendarFeed. Its strict validEvents decoder rejects this descriptor because it has a non-event ID and null dates. Parent must separately decode/validate exactly one descriptor against actor/timezone/range/normalised filters/cohort, remove it from events, and keep an unknown/malformed/missing descriptor unavailable. It must never become a shift, care event, drag target or count. Existing mapShift already rejects null dates and mapGap rejects the descriptor type, but that happens after the current hook's rejection. Generated action/route modules describe the same endpoint; they contain no independent fetch/render consumer. calendar-shared is a type consumer only. No other non-generated production caller of this exact route/path was found. Future decoder must preserve real array event semantics and default-deny Show action unless can_view_shift is exactly true.

The historical-corrected Calendar test is reused byte-exact: 18 test declarations / 38 source-derived dataset cases, including permission, privacy, unsafe hidden supply, mixed civil/offset and DST/Show controls. Its lawful fixtures are explicitly reconciled to current AppSetting JSON casts, UTC frozen clock, normal Shift observer invariants and current Show permission/Site rules in fixture-rebase.json. Those historical source assertions and DELIVERY results are not current MAIN acceptance. Current MAIN58/19 evidence remains unproved. Future selection also includes whole current WorkforceRosteringReadPermissionIntegrityTest and whole six-method RespiteReadinessTest. Actual union is null until real framework listing. No new human policy is assumed; existing exceptions/publication/all-status feed behavior remain.
'''
save('contract.md', contract.encode('utf-8'))
readme = '''# Parent review and future validation

Two proposed paths only: CalendarController reader code and new WorkforceCalendarReadIntegrityTest. `repair.patch` applies to the exact current controller before-image and absent test; `inverse.patch` restores those exact bytes/absence. No source application is authorised by this packet.

1. Independently review the source, current dependency snapshot, raw full forward/inverse and fixture rebase. Keep the separate current frontend marker decoder prerequisite open.
2. Review the parent-owned frontend descriptor/action composition before applying the payload; current hook rejects the descriptor. Preserve current eMAR and writer methods.
3. Parent admits syntax/Pint and real framework inventory in a fresh owned isolated current-MAIN mirror with current autoload/reflection, ordinary pending migrations and real Rostering Index/Shift Show pages. The three whole selected classes are in selection.json. Actual inventory/counts remain null. No launcher or schema helper is supplied here.
4. Separate native GO/resource/shared-gate/owned process and schema closure are required, preserving prior failed files and abandoned schema. Historical DELIVERY58 or frontend22 cannot close this source patch.
5. Verify actual scoped role/Site/civil-DST/filter/Show and unavailable-vs-zero browser journeys on the current bundle. Calendar saved-move/create authority/unchecked save/current returned tuple/physical root and transport recovery are explicitly outside this reader increment and remain open.

Only fresh ignored proposal files were authored. No private environment copy, product/source transfer, parser, PHP, SQL, process inspection, native or browser action occurred.
'''
save('README.md', readme.encode('utf-8'))
dump('source-proof.json', {
    'status': 'PURE_FILE_COMPOSITION_VERIFIED_NOT_PARSED_OR_EXECUTED',
    'root': str(ROOT), 'created_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'inverses': inverses, 'preserved_methods': preservation,
    'whole_store_to_end_suffix_exact': True, 'suffix_sha256': sha(before.split(writer_marker, 1)[1]),
    'reader_prefix_reused_from_formatted_historical_controller': True,
    'corrected_test_whole_bytes_reused': True,
    'source_dependencies_drift': [], 'historical_references_drift': [],
    'new_helpers': ['calendarSeriesScope', 'calendarCoverage'],
    'no_source_writer_policy_change': True, 'no_native_parser_or_browser_acceptance': True})
assert all(sha((ROOT / path).read_bytes()) == expected for path, expected in pins.items())
assert all(sha((ROOT / path).read_bytes()) == expected for path, expected in historical.items())
authored = {path.relative_to(PACKET).as_posix(): sha(path.read_bytes())
            for path in PACKET.rglob('*') if path.is_file() and path.name != 'manifest.json'}
dump('manifest.json', {
    'status': 'INACTIVE_SOURCE_ONLY_REVIEW_READY_WITH_FRONTEND_DECODER_DEPENDENCY',
    'root': str(ROOT), 'head': None, 'head_not_inspected': True,
    'approved': False, 'runtime_approved': False, 'framework_enumerated': False,
    'actual_inventory': None, 'actual_union_cases': None, 'actual_assertions': None,
    'candidate_paths': inverses, 'dependency_count': len(pins),
    'source_derived_calendar_cases': 38, 'preservation_class_scopes': 'whole current roster reader and whole RespiteReadiness',
    'source_report_sha256': historical[historical_paths[0]], 'source_review_sha256': historical[historical_paths[1]],
    'front_end_marker_decoder_composition_required': True,
    'current_main58_19_unproved': True, 'saved_move_writer_acceptance_open': True,
    'files': authored})
print(json.dumps({'packet': str(PACKET), 'manifest_sha256': sha((PACKET/'manifest.json').read_bytes()),
                  'controller_after_sha256': sha(after), 'test_after_sha256': sha(historical_test),
                  'patch_sha256': sha(forward), 'inverse_sha256': sha(inverse),
                  'dependencies': len(pins), 'authored_files': len(authored)+1,
                  'actual_union_cases': None}, indent=2))
