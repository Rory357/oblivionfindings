# Parent invocation only; own-schema closure is not test acceptance or retry.
param([switch]$Execute,[string]$ExpectedManifestSha256)
$ErrorActionPreference='Stop'
$packet=$PSScriptRoot
$manifestPath=Join-Path $packet 'manifest.json'
if (!$Execute -or !$ExpectedManifestSha256 -or (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash -ne $ExpectedManifestSha256) { throw 'Explicit parent GO and exact reviewed wrapper manifest required.' }
$manifest=Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
foreach ($p in $manifest.files.PSObject.Properties) { if ($p.Name -match '(^|[\/])\.\.([\/]|$)' -or [IO.Path]::IsPathRooted($p.Name) -or (Get-FileHash -LiteralPath (Join-Path $packet $p.Name) -Algorithm SHA256).Hash -ne $p.Value) { throw 'Reviewed closure input changed.' } }
$profile=Get-Content -LiteralPath (Join-Path $packet 'profile.json') -Raw | ConvertFrom-Json
$root=[IO.Path]::GetFullPath([string]$profile.root)
$php='C:/Users/steph/.config/herd/bin/php84/php.exe'
if ($root -ne [IO.Path]::GetFullPath('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings') -or (Get-Location).Path -ne $root -or $profile.database -cne 'oblivion_workforce_dlvcal_r2_20261010_81368' -or $profile.owner_pid -ne 81368 -or (Test-Path -LiteralPath "$root/.env") -or (Test-Path -LiteralPath "$root/.env.testing")) { throw 'Exact dotenv-free Delivery and original owner schema required.' }
if ((Get-FileHash -LiteralPath (Join-Path $packet 'reference/original-closure-manifest.json') -Algorithm SHA256).Hash -ne 'e6bdcdb7ee4afb6f9fddf4697097d97b38a2e3ed965f0508ad30998381e002a9') { throw 'Original reviewed closure proposal changed.' }
foreach ($f in @('process-absence.json','approval.json','schema-cleanup.json','schema-readback.json','wrapper-result.json','cleanup.stdout.log','cleanup.stderr.log','readback.stdout.log','readback.stderr.log')) { if (Test-Path -LiteralPath (Join-Path $packet $f)) { throw 'Prior closure attempt exists; preserve outputs and use a reviewed fresh sibling.' } }
function Assert-Original {
    if ((Get-FileHash -LiteralPath (Join-Path $root $profile.original_profile_path) -Algorithm SHA256).Hash -ne $profile.original_profile_sha256) { throw 'Original approved native profile changed.' }
    foreach ($p in $profile.source_pins.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root $p.Name) -Algorithm SHA256).Hash -ne $p.Value) { throw 'Original168 source changed; close before applying fixture transition.' } }
    foreach ($p in $profile.original_artifacts.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root ('test-results/delivery-calendar-r2-20261010/'+$p.Name)) -Algorithm SHA256).Hash -ne $p.Value.sha256) { throw 'Original failed evidence changed.' } }
}
Assert-Original
[xml]$xml=Get-Content -LiteralPath (Join-Path $root 'test-results/delivery-calendar-r2-20261010/phpunit.xml') -Raw
$names=@('DB_CONNECTION','DB_HOST','DB_PORT','DB_DATABASE','DB_USERNAME','DB_PASSWORD','DB_URL','DB_SOCKET')
$prior=[ordered]@{}; foreach ($name in $names) { $prior[$name]=[Environment]::GetEnvironmentVariable($name,'Process') }
$held=$false; $issue=$null; $cleanupExit=$null; $readbackExit=$null; $protected=@(); $drift=@(); $absence=$null; $started=[DateTimeOffset]::UtcNow
$mutex=[Threading.Mutex]::new($false,'Local\OblivionWorkforceMainIntegrationNativeGate')
try {
    try { $held=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $held=$true }
    if (!$held) { throw 'Shared native/import gate busy; no capture/approval/PHP/SQL.' }
    Assert-Original
    & (Join-Path $packet 'verify-absence.ps1') -Capture
    if (!(Test-Path -LiteralPath (Join-Path $packet 'process-absence.json'))) { throw 'Fresh peer/known-owner absence was not captured.' }
    $absence=Get-Content -LiteralPath (Join-Path $packet 'process-absence.json') -Raw | ConvertFrom-Json
    $protected=@($absence.protected_processes)
    # Only DB transport entries from the exact isolated XML; no application/cache/bootstrap environment.
    foreach ($name in $names) { $entry=@($xml.phpunit.php.env | Where-Object { $_.name -ceq $name }); if ($entry.Count -gt 1) { throw 'Ambiguous original DB transport entry.' }; [Environment]::SetEnvironmentVariable($name,$(if ($entry.Count -eq 1) {[string]$entry[0].value} else {$null}),'Process') }
    if ($env:DB_CONNECTION -ne 'mysql' -or $env:DB_HOST -ne '127.0.0.1' -or $env:DB_PORT -ne '3306' -or $env:DB_DATABASE -ne $profile.database_base -or ![string]::IsNullOrEmpty($env:DB_URL) -or ![string]::IsNullOrEmpty($env:DB_SOCKET)) { throw 'Original isolated DB transport is not exact local MySQL.' }
    [ordered]@{approved=$true;database=$profile.database;owner_pid=81368;process_absence_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'process-absence.json') -Algorithm SHA256).Hash.ToLowerInvariant();cleanup_tool_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'cleanup-schema.php') -Algorithm SHA256).Hash.ToLowerInvariant();wrapper_manifest_sha256=$ExpectedManifestSha256;approved_at_utc=[DateTimeOffset]::UtcNow.ToString('o')} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $packet 'approval.json') -Encoding utf8
    & $php -d memory_limit=256M -d max_execution_time=30 (Join-Path $packet 'cleanup-schema.php') '81368' '--verified-owned-process-absent' 1> (Join-Path $packet 'cleanup.stdout.log') 2> (Join-Path $packet 'cleanup.stderr.log')
    $cleanupExit=$LASTEXITCODE
    if ($cleanupExit -ne 0) { throw 'Exact original schema closure helper failed; retain outputs.' }
    & $php -d memory_limit=256M -d max_execution_time=30 (Join-Path $packet 'schema-readback.php') '--read-only-exact-owned-schema' 1> (Join-Path $packet 'readback.stdout.log') 2> (Join-Path $packet 'readback.stderr.log')
    $readbackExit=$LASTEXITCODE
    if ($readbackExit -ne 0) { throw 'Separate direct-PDO closure readback failed.' }
    $check=Get-Content -LiteralPath (Join-Path $packet 'schema-readback.json') -Raw | ConvertFrom-Json
    if ($check.schema_count -ne 0 -or $check.connections -ne 0 -or $check.database -cne $profile.database) { throw 'Separate schema/connections0 not proven.' }
} catch { $issue=$_.Exception.Message }
finally {
    try {
        Assert-Original
        if ($held) {
            $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
            foreach ($old in $protected) { $now=@($all | Where-Object { $_.ProcessId -eq $old.pid }); if ($now.Count -ne 1 -or $now[0].CreationDate.ToUniversalTime().ToString('o') -ne $old.birth -or $now[0].ExecutablePath -ne $old.executable -or $now[0].CommandLine -ne $old.command) { $drift += $old.pid } }
            if (@($all | Where-Object { $_.ProcessId -in @(81368,286956) -or $_.ParentProcessId -in @(81368,286956) -or $_.Name -ieq 'mysql.exe' -or ($_.Name -match '^php.*\.exe$' -and ([string]::IsNullOrWhiteSpace($_.CommandLine) -or $_.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)')) }).Count -ne 0) { throw 'Post-closure process absence uncertain; no stopping peers.' }
        }
    } catch { $issue=([string]$issue+'; final guards: '+$_.Exception.Message).Trim('; ') }
    foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name,$prior[$name],'Process') }
    if ($held) { $mutex.ReleaseMutex() }; $mutex.Dispose()
}
$closed=$null -eq $issue -and $cleanupExit -eq 0 -and $readbackExit -eq 0 -and $drift.Count -eq 0
$result=[ordered]@{status=$(if ($closed) {'EXACT_OLD_SCHEMA_CLOSED_VERIFIED'} else {'HELD_OR_FAILED_NO_NATIVE_ACCEPTANCE'});database=$profile.database;owner_pid=81368;started_at_utc=$started.ToString('o');finished_at_utc=[DateTimeOffset]::UtcNow.ToString('o');cleanup_exit=$cleanupExit;readback_exit=$readbackExit;protected_processes=$protected;protected_drift=$drift;issue=$issue;db_environment_restored=$true;original_launch_failed=$true;original_child_exit=$null;native_acceptance=$false;artifact_sha256=[ordered]@{}}
# Save outcome before optional output hashing; failures cannot erase the captured issue.
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $packet 'wrapper-result.json') -Encoding utf8
foreach ($name in @('process-absence.json','approval.json','schema-cleanup.json','schema-readback.json','cleanup.stdout.log','cleanup.stderr.log','readback.stdout.log','readback.stderr.log')) { $path=Join-Path $packet $name; if (Test-Path -LiteralPath $path) { try { $result.artifact_sha256[$name]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() } catch { $result.status='HELD_OR_FAILED_NO_NATIVE_ACCEPTANCE'; $result.issue=([string]$result.issue+'; artifact hash '+$name+': '+$_.Exception.Message).Trim('; '); $closed=$false } } }
$result | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath (Join-Path $packet 'wrapper-result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 5
exit $(if ($closed) {0} else {1})
