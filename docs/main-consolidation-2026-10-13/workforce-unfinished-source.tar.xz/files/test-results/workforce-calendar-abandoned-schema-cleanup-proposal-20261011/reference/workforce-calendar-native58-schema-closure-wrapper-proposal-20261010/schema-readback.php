<?php
// Parent-only direct PDO readback; no framework, mutate query or credentials output.
$profile = json_decode(file_get_contents(__DIR__.'/profile.json'), true, 512, JSON_THROW_ON_ERROR);
if (($argv[1] ?? '') !== '--read-only-exact-owned-schema' || $profile['database'] !== 'oblivion_workforce_dlvcal_r2_20261010_81368' || $profile['owner_pid'] !== 81368 || getenv('DB_HOST') !== '127.0.0.1' || getenv('DB_PORT') !== '3306' || ! in_array(getenv('DB_URL'), [false, ''], true) || ! in_array(getenv('DB_SOCKET'), [false, ''], true)) { throw new RuntimeException('Exact local original schema readback required.'); }
$pdo = new PDO('mysql:host=127.0.0.1;port=3306', getenv('DB_USERNAME'), getenv('DB_PASSWORD'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 10]);
$query = $pdo->prepare('SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?'); $query->execute([$profile['database']]); $schemas = (int) $query->fetchColumn();
$query = $pdo->prepare('SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE DB = ?'); $query->execute([$profile['database']]); $connections = (int) $query->fetchColumn();
$proof = ['database' => $profile['database'], 'owner_pid' => 81368, 'schema_count' => $schemas, 'connections' => $connections, 'read_only' => true, 'native_acceptance' => false];
file_put_contents(__DIR__.'/schema-readback.json', json_encode($proof, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
if ($schemas !== 0 || $connections !== 0) { throw new RuntimeException('Exact original schema closure not verified.'); }
