# Parent-invoked read-only proof only. No PHP, SQL, termination or process launch.
param([switch]$Capture)
$ErrorActionPreference='Stop'
$packet=$PSScriptRoot
$profile=Get-Content -LiteralPath (Join-Path $packet 'profile.json') -Raw | ConvertFrom-Json
$root=[IO.Path]::GetFullPath([string]$profile.root)
if (!$Capture -or $root -ne [IO.Path]::GetFullPath('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings') -or $profile.database -cne 'oblivion_workforce_dlvcal_r2_20261010_81368' -or $profile.owner_pid -ne 81368 -or $profile.known_child_pid -ne 286956) { throw 'Exact separately reviewed original owner/schema required.' }
if (Test-Path -LiteralPath (Join-Path $packet 'process-absence.json')) { throw 'Preserve prior process proof; no overwrite.' }
if ((Get-FileHash -LiteralPath (Join-Path $root $profile.original_profile_path) -Algorithm SHA256).Hash -ne $profile.original_profile_sha256) { throw 'Original authorised profile changed.' }
foreach ($p in $profile.source_pins.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root $p.Name) -Algorithm SHA256).Hash -ne $p.Value) { throw 'Original source transition needs separate review.' } }
foreach ($p in $profile.original_artifacts.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root ('test-results/delivery-calendar-r2-20261010/'+$p.Name)) -Algorithm SHA256).Hash -ne $p.Value.sha256) { throw 'Original failed evidence changed.' } }
$all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
$known=@($all | Where-Object { $_.ProcessId -in @(81368,286956) -or $_.ParentProcessId -in @(81368,286956) })
# Ambiguous reused PID and any still-linked process both refuse closure, without claiming ownership.
if ($known.Count -ne 0) { throw 'Original owner/known descendants or reused PID present; no closure permission.' }
$imports=@($all | Where-Object { $_.Name -ieq 'mysql.exe' })
$php=@($all | Where-Object { $_.Name -match '^php.*\.exe$' })
$unknown=@($php | Where-Object { [string]::IsNullOrWhiteSpace($_.CommandLine) -or $_.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)' })
$original=@($all | Where-Object { $_.CommandLine -and $_.CommandLine -match 'delivery-calendar-r2-20261010|oblivion_workforce_dlvcal_r2_20261010_81368' })
if ($imports.Count -ne 0 -or $unknown.Count -ne 0 -or $original.Count -ne 0) { throw 'Database-capable/old namespace process absence uncertain; hold without stopping peers.' }
$protected=@($php | ForEach-Object { [ordered]@{pid=[int]$_.ProcessId;birth=$_.CreationDate.ToUniversalTime().ToString('o');executable=$_.ExecutablePath;command=$_.CommandLine} })
[ordered]@{status='KNOWN_OWNER_AND_DATABASE_CAPABLE_PROCESS_ABSENCE_ONLY';root=$root;database=$profile.database;owner_pid=81368;known_child_pid=286956;captured_at_utc=[DateTimeOffset]::UtcNow.ToString('o');known_owner_and_child_absent=$true;linked_processes_absent=$true;non_preview_php_absent=$true;mysql_import_clients_absent=$true;old_namespace_processes_absent=$true;original_profile_sha256=$profile.original_profile_sha256;source_drift=@();original_artifact_drift=@();protected_processes=$protected;termination_or_database_action=$false;historical_complete_descendant_tracking_claim=$false;native_acceptance=$false} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $packet 'process-absence.json') -Encoding utf8
