<?php
// Direct PDO only; no application bootstrap, broad prune or sibling schema access.
$profile = json_decode(file_get_contents(__DIR__.'/profile.json'), true, 512, JSON_THROW_ON_ERROR);
$pid = filter_var($argv[1] ?? '', FILTER_VALIDATE_INT);
if (! $pid || $pid <= 0 || ($argv[2] ?? '') !== '--verified-owned-process-absent') { throw new RuntimeException('Verified exact owner PID required.'); }
if ($pid !== 81368 || $profile['database'] !== 'oblivion_workforce_dlvcal_r2_20261010_81368') { throw new RuntimeException('Only the exact original failed owner schema can be closed.'); }
$absenceBytes = file_get_contents(__DIR__.'/process-absence.json');
$absence = json_decode($absenceBytes, true, 512, JSON_THROW_ON_ERROR);
$approval = json_decode(file_get_contents(__DIR__.'/approval.json'), true, 512, JSON_THROW_ON_ERROR);
if (($approval['approved'] ?? false) !== true || ($approval['database'] ?? null) !== $profile['database'] || ($approval['owner_pid'] ?? null) !== 81368 || ($approval['process_absence_sha256'] ?? null) !== hash('sha256', $absenceBytes) || ($approval['cleanup_tool_sha256'] ?? null) !== hash_file('sha256', __FILE__)) { throw new RuntimeException('Separate parent closure review and exact process/tool binding required.'); }
$captured = new DateTimeImmutable($absence['captured_at_utc']);
$age = (new DateTimeImmutable('now', new DateTimeZone('UTC')))->getTimestamp() - $captured->getTimestamp();
if ($age < 0 || $age > 60 || ($absence['root'] ?? null) !== $profile['root'] || ($absence['database'] ?? null) !== $profile['database'] || ($absence['owner_pid'] ?? null) !== 81368 || ($absence['known_child_pid'] ?? null) !== 286956 || ($absence['original_profile_sha256'] ?? null) !== $profile['original_profile_sha256']) { throw new RuntimeException('Fresh exact-owner process absence required.'); }
foreach (['known_owner_and_child_absent', 'linked_processes_absent', 'non_preview_php_absent', 'mysql_import_clients_absent', 'old_namespace_processes_absent'] as $key) { if (($absence[$key] ?? false) !== true) { throw new RuntimeException('Required process absence unproven.'); } }
foreach ($profile['source_pins'] as $path => $hash) { if (hash_file('sha256', $profile['root'].'/'.$path) !== $hash) { throw new RuntimeException('Original source needs separate transition review.'); } }
if (hash_file('sha256', $profile['root'].'/'.$profile['original_profile_path']) !== $profile['original_profile_sha256']) { throw new RuntimeException('Original approved runtime profile changed.'); }
$database = $profile['database_base'].'_'.$pid;
if (preg_match('/\Aoblivion_workforce_dlvcal_r2_20261010_[1-9][0-9]*\z/D', $database) !== 1 || strlen($database) > 64 || getenv('DB_HOST') !== '127.0.0.1' || getenv('DB_PORT') !== '3306' || ! in_array(getenv('DB_URL'), [false, ''], true) || ! in_array(getenv('DB_SOCKET'), [false, ''], true)) { throw new RuntimeException('Exact local owned schema required.'); }
$pdo = new PDO('mysql:host=127.0.0.1;port=3306', getenv('DB_USERNAME'), getenv('DB_PASSWORD'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$query = $pdo->prepare('SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE DB = ?'); $query->execute([$database]); $connections = (int) $query->fetchColumn();
if ($connections !== 0) { throw new RuntimeException('Owned database still has connections; refuse drop.'); }
$pdo->exec('DROP DATABASE IF EXISTS `'.$database.'`');
$query = $pdo->prepare('SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?'); $query->execute([$database]);
$proof = ['database' => $database, 'owner_pid' => $pid, 'connections' => $connections, 'schema_count' => (int) $query->fetchColumn(), 'process_absence_sha256' => hash('sha256', $absenceBytes), 'original_profile_sha256' => $profile['original_profile_sha256'], 'native_acceptance' => false];
file_put_contents(__DIR__.'/schema-cleanup.json', json_encode($proof, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
if ($proof['schema_count'] !== 0) { throw new RuntimeException('Owned schema remains.'); }
