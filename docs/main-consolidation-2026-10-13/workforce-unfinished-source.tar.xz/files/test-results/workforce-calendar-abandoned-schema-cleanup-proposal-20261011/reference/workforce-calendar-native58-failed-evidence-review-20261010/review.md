# Calendar58 failed evidence review

Status: **FAILED / diagnostic only**. This review does not establish native acceptance, the actual child exit, or cleanup.

The raw JUnit identities exactly match the framework-listed 58 cases: Calendar38, Rostering reader19, Respite1. XML and stdout record 46 non-error/non-skipped cases with 881 assertions, plus 12 errors with one partial assertion, for 882 attempted assertions. Failures and skips are zero. All 46 non-error cases have rendered warnings from the optional missing DELIVERY `.env`; none is certified warning-free. Warning counts for error cases are not inferred.

Eleven errors are native JSON fixture writes at `WorkforceCalendarReadIntegrityTest.php:92` and `:378`: query-builder boolean updates bypass the installed `AppSetting` JSON cast. The twelfth is an invalid-timezone fixture setup at `:181` through `:437`: the test blanks the worker zone before normal Shift observers resolve a roster period. It fails before the Calendar HTTP read. A lawful fixture repair should retain normal model casts and observers, build the fixture under a valid worker zone, and change only the subsequent reader input. These failures do not justify changing application JSON storage or certifying blank-zone lifecycle mutations.

The approved profile, current 168 source pins, eight tool pins, and 29 autoloaded application/test/seeder paths match DELIVERY at HEAD `94e31596c05825f24ff4cb84f734aa971a3c4793`. Private cache/storage and isolated transports match the recorded bootstrap. The parent-approved admission records peer count0, free memory8375MiB and CPU25. These are source/bootstrap/admission observations, not final process or database closure.

The launcher diagnostic records shell exit1: `run.ps1:113` tried to hash redirected stdout while the PHP child still held it. No `result.json` or `schema-cleanup.json` exists. Actual child exit remains unknown; XML errors do not supply it. Parent later observed owner81368 and known conhost286956 absent. This review neither observed nor stopped processes, and that observation does not reconstruct the original retained handle or complete descendant history.

The sole derived temporary database is `oblivion_workforce_dlvcal_r2_20261010_81368`. Its existence and connections are unknown. Before any cleanup, the parent must establish adequate exact-owner/descendant absence, bind the approved base/PID and local connection configuration, and read only this database's schema and connection state. Uncertain orphan/descendant ownership or nonzero connections means no DROP. Any authorised exact-schema cleanup must produce separate schema/connection/protected-preview closure evidence; no closure is claimed here.

Original failed artifacts remain immutable. Fixture correction and improved launcher logging are separate proposals requiring a fresh guarded attempt. No current-main, frontend, build, browser or full-programme acceptance follows from this review.

Evidence hashes and all 58 individual outcomes are retained in `review.json`, `input-pins.json` and `case-evidence-58.json` beside this note. No PHP, framework, database, process, authentication, product or preview action was performed by the reviewer.
