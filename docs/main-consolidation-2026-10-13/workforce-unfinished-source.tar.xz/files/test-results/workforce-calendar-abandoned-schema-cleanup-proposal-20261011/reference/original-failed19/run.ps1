param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$packet = $PSScriptRoot
$profile = Get-Content -LiteralPath (Join-Path $packet 'profile.json') -Raw | ConvertFrom-Json
$root = [IO.Path]::GetFullPath([string]$profile.root)
$php = 'C:/Users/steph/.config/herd/bin/php84/php.exe'
$mysql = 'C:/Program Files/MySQL/MySQL Server 8.0/bin/mysql.exe'
if (!$Execute -or $profile.approved -ne $true -or !$profile.expected_head -or [int]$profile.expected_cases -le 0) { throw 'Author-only: final source/count pins and explicit parent execution GO required.' }
if ($root -ne 'C:\Users\steph\.codex\worktrees\workforce-delivery\oblivionfindings' -or (Get-Location).Path -ne $root -or (Test-Path -LiteralPath "$root/.env") -or (Test-Path -LiteralPath "$root/.env.testing")) { throw 'Exact dotenv-free integration working directory required.' }
if ((git rev-parse HEAD).Trim() -ne $profile.expected_head -or $profile.minimum_free_mib -ne 4096 -or $profile.maximum_cpu_percent -ne 85 -or $profile.deadline_seconds -ne 1800) { throw 'Reviewed source/finite guard changed.' }
if ($profile.framework_enumerated -ne $true) { throw 'Actual artifact-free list inventory is required before launch.' }
if ($profile.database_base -ne 'oblivion_workforce_dlvcal_r2_20261010' -or ($profile.database_base+'_4294967295').Length -gt 64 -or @($profile.test_files).Count -ne 3 -or @($profile.source_pins.PSObject.Properties).Count -ne 168) { throw 'Final bounded selection and relevant source pins required.' }
if ((@($profile.tools.PSObject.Properties.Name | Sort-Object) -join '|') -ne 'bootstrap.php|cleanup-schema.php|enumerate.ps1|list-bootstrap.php|pest-entry.php|phpunit-list.xml|phpunit.xml|run.ps1') { throw 'Exact eight reviewed native/list tools required.' }
function Assert-Pins {
    foreach ($item in $profile.source_pins.PSObject.Properties) { if ($item.Name -match '(^|[\\/])\.\.([\\/]|$)' -or [IO.Path]::IsPathRooted($item.Name) -or !(Test-Path -LiteralPath (Join-Path $root $item.Name)) -or (Get-FileHash -LiteralPath (Join-Path $root $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw ('Selected source pin changed: '+$item.Name) } }
    foreach ($item in $profile.tools.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $packet $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw 'Reviewed tool changed.' } }
}
function Get-Birth($process) { return $process.CreationDate.ToUniversalTime().ToString('o') }
function Get-Slot {
    $processes = @(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    foreach ($p in $processes) {
        if ($p.Name -ieq 'mysql.exe' -or ($p.Name -match '^php.*\.exe$' -and ([string]::IsNullOrWhiteSpace($p.CommandLine) -or $p.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)'))) { throw ('Peer PHP/Pest/import active; preserve PID '+$p.ProcessId) }
    }
    $os = Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10
    $cpuRows = @(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
    if ([long]$os.FreePhysicalMemory -le 0 -or $cpuRows.Count -ne 1 -or $null -eq $cpuRows[0].PercentProcessorTime) { throw 'Host capacity unknown.' }
    $free = [math]::Floor([long]$os.FreePhysicalMemory/1024)
    if ($free -lt 4096 -or [int]$cpuRows[0].PercentProcessorTime -gt 85) { throw 'Resource admission held; no bootstrap/schema/test started.' }
    return @($processes | Where-Object { $_.Name -match '^php.*\.exe$' } | ForEach-Object { [pscustomobject]@{pid=[int]$_.ProcessId;birth=(Get-Birth $_);command=$_.CommandLine;executable=$_.ExecutablePath} })
}
Assert-Pins
if (!$profile.inventory_sha256 -or !(Test-Path -LiteralPath (Join-Path $packet 'inventory.json')) -or (Get-FileHash -LiteralPath (Join-Path $packet 'inventory.json') -Algorithm SHA256).Hash -ne $profile.inventory_sha256) { throw 'Actual inventory binding missing or changed.' }
$inventory = Get-Content -LiteralPath (Join-Path $packet 'inventory.json') -Raw | ConvertFrom-Json
if ($inventory.framework_exit -ne 0 -or $inventory.application_bootstrap -ne $false -or $inventory.database_or_scenario_execution -ne $false -or $inventory.head -ne $profile.expected_head -or $inventory.count -ne $profile.expected_cases -or @($inventory.cases | Select-Object -Unique).Count -ne $inventory.count) { throw 'Actual no-application inventory does not match this run.' }
if ((ConvertTo-Json $inventory.source_pins -Compress -Depth 5) -ne (ConvertTo-Json $profile.source_pins -Compress -Depth 5)) { throw 'Inventory/source pin transition changed.' }
if ($inventory.filter -cne $profile.filter -or @($inventory.junit_identities).Count -ne $profile.expected_cases -or @($inventory.junit_identities | Select-Object -Unique).Count -ne $profile.expected_cases) { throw 'Selected inventory/filter/JUnit mapping changed.' }
foreach ($file in @($php,$mysql,(Join-Path $root $profile.schema.path))) { if (!(Test-Path -LiteralPath $file -PathType Leaf)) { throw 'Runtime dependency missing.' } }
if ((Get-FileHash -LiteralPath (Join-Path $root $profile.schema.path) -Algorithm SHA256).Hash -ne $profile.schema.sha256) { throw 'Existing native schema dump differs.' }
foreach ($file in @('result.json','stdout.log','stderr.log','junit.xml','autoload-proof.json','schema-cleanup.json')) { if (Test-Path -LiteralPath (Join-Path $packet $file)) { throw 'Prior execution exists; preserve it and use an explicitly reviewed fresh output folder.' } }
foreach ($kind in @('config','routes','services','packages')) { if (Test-Path -LiteralPath (Join-Path $packet ('cache/'+$kind+'.php'))) { throw 'Unexpected compiled metadata.' } }
foreach ($path in @('storage/framework/down','storage/framework/maintenance.php')) { if (Test-Path -LiteralPath (Join-Path $root $path)) { throw 'Root maintenance state exists; do not let TestCase remove shared files.' } }
[xml]$config = Get-Content -LiteralPath (Join-Path $packet 'phpunit.xml') -Raw
if ((@($config.phpunit.testsuites.testsuite.file | ForEach-Object { [IO.Path]::GetFullPath([string]$_) } | Sort-Object) -join '|') -ne (@($profile.test_files | ForEach-Object { [IO.Path]::GetFullPath((Join-Path $root $_)) } | Sort-Object) -join '|')) { throw 'Config and reviewed test files differ.' }
foreach ($entry in $config.phpunit.php.env) { [Environment]::SetEnvironmentVariable([string]$entry.name,[string]$entry.value,'Process') }
$env:MYSQL_BINARY=$mysql; $env:MYSQL_TEST_SCHEMA_PATH=Join-Path $root $profile.schema.path; $env:MYSQL_TEST_SCHEMA_REQUIRE_NATIVE='true'; $env:MYSQL_TEST_SCHEMA_TIMEOUT='900'
foreach ($name in @('TEST_TOKEN','PARALLEL_PROCESS','PROCESS_TOKEN','PARALLEL_PROCESS_TOKEN')) { [Environment]::SetEnvironmentVariable($name,$null,'Process') }
$mutex = [Threading.Mutex]::new($false,'Local\OblivionWorkforceMainIntegrationNativeGate')
$held=$false; $test=$null; $retainedHandle=$null; $retainedStartUtc=$null; $retainedExecutable=$null; $initialIdentityBound=$false; $seen=@{}; $exitCode=$null; $issue=$null; $cleanup=$false; $protected=@(); $protectedDrift=@(); $pinDrift=$false
function Track-Owned {
    $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    do {
        $new=@($all | Where-Object { $child=$_; $parent=@($all | Where-Object { [int]$_.ProcessId -eq [int]$child.ParentProcessId })[0]; $null -ne $parent -and $seen.ContainsKey([int]$parent.ProcessId) -and $seen[[int]$parent.ProcessId] -eq (Get-Birth $parent) -and $child.CreationDate -ge $parent.CreationDate -and !$seen.ContainsKey([int]$child.ProcessId) })
        foreach ($child in $new) { $seen[[int]$child.ProcessId]=Get-Birth $child }
    } while ($new.Count -gt 0)
    return @($all | Where-Object { $seen.ContainsKey([int]$_.ProcessId) -and $seen[[int]$_.ProcessId] -eq (Get-Birth $_) })
}
$started=[DateTimeOffset]::UtcNow
try {
    try { $held=$mutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $held=$true }
    if (!$held) { throw 'Owned native/import gate is busy.' }
    $protected=@(Get-Slot); Assert-Pins
    foreach ($dir in @('cache','storage/framework/cache/data','storage/framework/sessions','storage/framework/views','storage/logs','storage/app')) { $null=New-Item -ItemType Directory -Force -Path (Join-Path $packet $dir) }
    $pestArguments=@('test-results/delivery-calendar-r2-20261010/pest-entry.php') + @($profile.test_files) + @('--configuration=test-results/delivery-calendar-r2-20261010/phpunit.xml',('--filter='+$profile.filter),'--colors=never','--display-warnings','--log-junit=test-results/delivery-calendar-r2-20261010/junit.xml')
    $test=Start-Process -FilePath $php -ArgumentList $pestArguments -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $packet 'stdout.log') -RedirectStandardError (Join-Path $packet 'stderr.log') -PassThru
    $retainedHandle=$test.Handle; $retainedStartUtc=$test.StartTime.ToUniversalTime(); $retainedExecutable=$test.MainModule.FileName
    if ($retainedHandle -eq [IntPtr]::Zero -or $retainedExecutable -ne (Resolve-Path -LiteralPath $php).Path) { throw 'Retained native PHP identity unavailable.' }
    $actual=Get-CimInstance Win32_Process -Filter ('ProcessId='+$test.Id) -OperationTimeoutSec 10
    # CIM/DMTF birth has microsecond precision; the retained native StartTime has 100ns precision.
    $nativeMicros=$retainedStartUtc.Ticks-($retainedStartUtc.Ticks % 10)
    if (!$actual -or [int]$actual.ProcessId -ne $test.Id -or [int]$actual.ParentProcessId -ne $PID -or $actual.ExecutablePath -ne $retainedExecutable -or ($actual.CreationDate.ToUniversalTime().Ticks-($actual.CreationDate.ToUniversalTime().Ticks % 10)) -ne $nativeMicros -or $test.HasExited -or $test.Handle -ne $retainedHandle -or $test.StartTime.ToUniversalTime() -ne $retainedStartUtc) { throw 'First CIM identity is not the retained native PHP process.' }
    $seen[[int]$test.Id]=Get-Birth $actual
    $initialIdentityBound=$true
    while (!$test.HasExited) { $null=Track-Owned; if (([DateTimeOffset]::UtcNow-$started).TotalSeconds -gt 1800) { throw 'Finite owned test/import deadline exceeded.' }; Start-Sleep -Milliseconds 500; $test.Refresh() }
    $test.WaitForExit(); $exitCode=$test.ExitCode
    if ($null -eq $exitCode) { throw 'Actual child exit unavailable; no green inference from XML.' }
} catch { $issue=$_.Exception.Message }
finally {
    if ($null -ne $test) {
        try {
            if (!$initialIdentityBound) {
                # Never treat an empty tracking map as absence of the spawned owner/descendants.
                if ($null -eq $retainedHandle -or $retainedHandle -eq [IntPtr]::Zero -or $null -eq $retainedStartUtc -or $retainedExecutable -ne (Resolve-Path -LiteralPath $php).Path) { throw 'Retained owner identity uncertain; refuse termination and schema DROP.' }
                $test.Refresh()
                if (!$test.HasExited) {
                    if ($test.Handle -ne $retainedHandle -or $test.StartTime.ToUniversalTime() -ne $retainedStartUtc -or $test.MainModule.FileName -ne $retainedExecutable) { throw 'Retained owner identity changed; refuse termination and schema DROP.' }
                    $test.Kill()
                }
                if (!$test.WaitForExit(10000) -or !$test.HasExited) { throw 'Retained native owner absence unproven; refuse schema DROP.' }
                throw 'Initial CIM admission failed; retained owner exited but descendant absence unproven. Refuse schema DROP; parent-owned recovery required.'
            }
            $left=@(Track-Owned)
            foreach ($p in $left | Sort-Object CreationDate -Descending) { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop }
            $until=[DateTimeOffset]::UtcNow.AddSeconds(10)
            do { $left=@(Track-Owned); if ($left.Count -eq 0) { break }; Start-Sleep -Milliseconds 200 } while ([DateTimeOffset]::UtcNow -lt $until)
            if ($left.Count -ne 0) { throw 'Verified owned descendants remain; refuse schema cleanup.' }
            if (!$test.WaitForExit(10000) -or !$test.HasExited) { throw 'Retained native owner absence unproven; refuse schema DROP.' }
            & $php (Join-Path $packet 'cleanup-schema.php') ([string]$test.Id) '--verified-owned-process-absent'
            if ($LASTEXITCODE -ne 0) { throw 'Exact owned schema closure failed.' }; $cleanup=$true
        } catch { $issue=([string]$issue+'; cleanup: '+$_.Exception.Message).Trim('; ') }
    }
    try { Assert-Pins } catch { $pinDrift=$true; $issue=([string]$issue+'; pins: '+$_.Exception.Message).Trim('; ') }
    try { foreach ($old in $protected) { $now=Get-CimInstance Win32_Process -Filter ('ProcessId='+$old.pid) -OperationTimeoutSec 10; if (!$now -or (Get-Birth $now) -ne $old.birth -or $now.CommandLine -ne $old.command -or $now.ExecutablePath -ne $old.executable) { $protectedDrift += $old.pid } }
    } catch { $issue=([string]$issue+'; protected identity check unavailable').Trim('; ') }
    if ($held) { $mutex.ReleaseMutex() }; $mutex.Dispose()
}
$cases=@(); $bad=@(); $assertions=0; $passedAssertions=0; $failedPartial=0; $passedCases=0
if (Test-Path -LiteralPath (Join-Path $packet 'junit.xml')) { try { [xml]$junit=Get-Content -LiteralPath (Join-Path $packet 'junit.xml') -Raw; $cases=@($junit.SelectNodes('//testcase')); $bad=@($junit.SelectNodes('//testcase/failure|//testcase/error|//testcase/skipped')); foreach ($case in $cases) { $assertions += [int]$case.assertions; if (@($case.SelectNodes("./error|./failure|./skipped")).Count -eq 0) { $passedCases++; $passedAssertions += [int]$case.assertions } else { $failedPartial += [int]$case.assertions } } } catch { $issue=([string]$issue+'; invalid XML').Trim('; ') } }
foreach ($entry in $profile.expected_junit_class_counts.PSObject.Properties) { if (@($cases | Where-Object { $_.classname -ceq $entry.Name }).Count -ne [int]$entry.Value) { $issue=([string]$issue+'; exact selected raw class inventory differs').Trim('; ') } }
$actualJunit=@($cases | ForEach-Object { ([string]$_.classname+'::'+[string]$_.name) })
if ((@($actualJunit | Sort-Object) -join "`n") -cne (@($inventory.junit_identities | Sort-Object) -join "`n") -or @($actualJunit | Select-Object -Unique).Count -ne $cases.Count) { $issue=([string]$issue+'; exact selected raw JUnit identities differ').Trim('; ') }
$passed=$null -eq $issue -and $exitCode -eq 0 -and $cleanup -and !$pinDrift -and $protectedDrift.Count -eq 0 -and $cases.Count -eq [int]$profile.expected_cases -and $bad.Count -eq 0
$result=[ordered]@{status=$(if ($passed) {'PASSED_CLEAN'} else {'FAILED_OR_HELD'});root=$root;head=$profile.expected_head;started_at_utc=$started.ToString('o');finished_at_utc=[DateTimeOffset]::UtcNow.ToString('o');pest_pid=$(if ($test) {$test.Id} else {$null});actual_pest_exit=$exitCode;launcher_exit=$(if ($passed) {0} else {1});expected_cases=$profile.expected_cases;cases=$cases.Count;passed_cases=$passedCases;assertions=$passedAssertions;attempted_assertions=$assertions;passed_assertions=$passedAssertions;failed_partial_assertions=$failedPartial;unsuccessful=$bad.Count;cleanup_verified=$cleanup;source_pins=$profile.source_pins;source_drift=$pinDrift;protected_processes=$protected;protected_drift=$protectedDrift;issue=$issue;inventory_sha256=$profile.inventory_sha256;junit_identities=$actualJunit;artifacts=[ordered]@{xml='junit.xml';stdout='stdout.log';stderr='stderr.log';autoload='autoload-proof.json';cleanup='schema-cleanup.json';inventory='inventory.json'};artifact_sha256=[ordered]@{}}
foreach ($item in $result.artifacts.Keys) { $path=Join-Path $packet $result.artifacts[$item]; if (Test-Path -LiteralPath $path) { $result.artifact_sha256[$item]=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() } }
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath (Join-Path $packet 'result.json') -Encoding utf8
$result | ConvertTo-Json -Depth 5
exit $result.launcher_exit
