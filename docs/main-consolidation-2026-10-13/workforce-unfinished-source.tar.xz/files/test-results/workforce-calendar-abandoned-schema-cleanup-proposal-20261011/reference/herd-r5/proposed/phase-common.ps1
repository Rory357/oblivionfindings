$ErrorActionPreference='Stop'
$phasePacket=Split-Path -Parent $PSScriptRoot
$sourceRoot='C:/Users/steph/Herd/oblivionfindings'
$root='C:/Users/steph/Herd/oblivionfindings/test-results/workforce-main-timeoff-leave-source-mirror-r2-20261011/root'
$runtime=Join-Path $root 'test-results/main-timeoff-leave-native-r2-20261011'
$php='C:/Users/steph/.config/herd/bin/php84/php.exe'
$script:slotSamples=@()
function Sha([string]$path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Json($value) { return ConvertTo-Json $value -Compress -Depth 30 }
function Birth($process) { return $process.CreationDate.ToUniversalTime().ToString('o') }
function Inside([string]$base,[string]$relative) {
    if ([string]::IsNullOrWhiteSpace($relative) -or [IO.Path]::IsPathRooted($relative) -or $relative -match '(^|[\\/])\.\.([\\/]|$)' -or $relative -match ':') { throw 'Unsafe relative phase path.' }
    $b=[IO.Path]::GetFullPath($base).TrimEnd([char[]]'\/');$path=[IO.Path]::GetFullPath((Join-Path $b $relative))
    if (!$path.StartsWith($b+'\',[StringComparison]::OrdinalIgnoreCase)) {throw 'Phase path is not contained.'};return $path
}
function No-Reparse([string]$path,[string]$boundary) {
    $at=[IO.Path]::GetFullPath($path);$end=[IO.Path]::GetFullPath($boundary)
    if($at -ine $end -and !$at.StartsWith($end+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Reparse boundary differs.'}
    while($true){if(Test-Path -LiteralPath $at){if(((Get-Item -LiteralPath $at -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Unexpected owned write/source reparse path.'}};if($at -ieq $end){break};$at=[IO.Path]::GetDirectoryName($at)}
}
function Head {
    if ((Get-Content -LiteralPath (Join-Path $sourceRoot '.git/HEAD') -Raw).Trim() -cne 'ref: refs/heads/main' -or (Get-Content -LiteralPath (Join-Path $sourceRoot '.git/refs/heads/main') -Raw).Trim() -cne 'ce50e22f5b5b85fdd1bf42a8401ec31015deae80' -or $Checkpoint -cne 'ce50e22f5b5b85fdd1bf42a8401ec31015deae80') {throw 'Exact current parent MAIN checkpoint required; no Git command.'}
    return $Checkpoint
}
function Assert-Packet {
    if ($PSVersionTable.PSVersion.Major -lt 7 -or (Get-Process -Id $PID).Path -cne 'C:\Program Files\PowerShell\7\pwsh.exe') {throw 'Exact installed PowerShell7 required.'}
    No-Reparse $phasePacket $sourceRoot
    if((Sha (Join-Path $phasePacket 'manifest.json')) -cne $ManifestSha256){throw 'Reviewed packet manifest differs.'}
    $script:inputManifest=Get-Content -LiteralPath (Join-Path $phasePacket 'manifest.json') -Raw | ConvertFrom-Json
    if($inputManifest.state -cne 'INACTIVE_CURRENT_MAIN_LEAVE18_SOURCE_HELPERS'){throw 'Wrong inactive helper packet.'}
    foreach($pin in $inputManifest.authored_files.PSObject.Properties){$path=Inside $phasePacket $pin.Name;No-Reparse $path $sourceRoot;if((Sha $path) -cne $pin.Value){throw 'Authored helper/payload/reference changed.'}}
    if([IO.Path]::GetFullPath($SourceReviewPath) -cne [IO.Path]::GetFullPath((Join-Path $phasePacket 'independent-hr-review.json')) -or (Sha $SourceReviewPath) -cne $SourceReviewSha256){throw 'Exact new helper independent source review required.'}
    $review=Get-Content -LiteralPath $SourceReviewPath -Raw | ConvertFrom-Json
    if($review.status -cne 'CLEAR_SOURCE_ONLY' -or $review.manifest_sha256 -cne $ManifestSha256){throw 'New helper review must CLEAR this exact manifest.'}
    $script:data=Get-Content -LiteralPath (Join-Path $phasePacket 'data.json') -Raw | ConvertFrom-Json
    if($data.expected_head -cne (Head) -or @($data.current_source_pins.PSObject.Properties).Count -ne 7534 -or @($data.source_pins.PSObject.Properties).Count -ne 7539 -or @($data.overlay).Count -ne 10 -or @($data.test_files).Count -ne 18 -or @($data.metadata_pins.PSObject.Properties).Count -ne 13 -or @($data.package_mappings).Count -ne 64 -or @($data.page_pins.PSObject.Properties).Count -ne 8 -or @($data.static_pins.PSObject.Properties).Count -ne 2){throw 'Exact declared source/selection/metadata/page map required.'}
    foreach($pin in $data.historical_pins.PSObject.Properties){if((Sha $pin.Name) -cne $pin.Value){throw 'Historical source/result/failure changed.'}}
    foreach($pin in $data.finite_vendor_pins.PSObject.Properties){if((Sha (Inside $sourceRoot $pin.Name)) -cne $pin.Value){throw 'Finite installed vendor input changed.'}}
    foreach($pin in $data.runtime_executables.PSObject.Properties){if((Sha $pin.Name) -cne $pin.Value){throw 'Installed runtime executable changed.'}}
    foreach($pin in $data.metadata_pins.PSObject.Properties){$path=Inside $sourceRoot $pin.Name;No-Reparse $path $sourceRoot;if((Sha $path) -cne $pin.Value){throw 'Local Composer metadata changed.'}}
    foreach($mapping in $data.package_mappings){if($mapping.mirror_relative -cnotmatch '^vendor/[a-z0-9-]+$' -or !(Test-Path -LiteralPath $mapping.read_only_source -PathType Container)){throw 'Finite read-only installed package mapping unavailable.'}}
    foreach($entry in $data.overlay){$path=Inside $phasePacket $entry.payload_relative;No-Reparse $path $sourceRoot;if((Sha $path) -cne $entry.after_sha256){throw 'Reviewed ten-source payload changed.'}}
}
function Assert-Main([switch]$Before) {
    $null=Head
    $pins=$(if($Before){$data.current_source_pins}else{$data.source_pins})
    foreach($pin in $pins.PSObject.Properties){$path=Inside $sourceRoot $pin.Name;No-Reparse $path $sourceRoot;if((Sha $path) -cne $pin.Value){throw ('Exact MAIN source changed: '+$pin.Name)}}
    if($Before){foreach($entry in $data.overlay){if(!$entry.before_sha256 -and (Test-Path -LiteralPath (Inside $sourceRoot $entry.path))){throw 'New source target unexpectedly exists.'}}}
}
function Assert-Application {
    $appDir=Inside $sourceRoot $data.application_relative
    $path=Inside $appDir ($ApplicationAttemptName+'/application-result.json');No-Reparse $path $sourceRoot
    if((Sha $path) -cne $ApplicationReceiptSha256){throw 'Exact actual successful ten-source application receipt required.'}
    $receipt=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
    if($ApplicationAttemptName -cne $data.completed_application.attempt -or $ApplicationReceiptSha256 -cne $data.completed_application.receipt_sha256){throw 'Only exact completed R4 application lineage required; no reapplication.'}
    if($receipt.state -cne 'APPLIED_REVIEWED_LEAVE10_SOURCE_ONLY' -or $receipt.head -cne $Checkpoint -or $receipt.manifest_sha256 -cne $data.completed_application.manifest_sha256 -or $receipt.source_review_sha256 -cne $data.completed_application.source_review_sha256 -or $receipt.source_count -ne 10 -or (Json $receipt.source_pins) -cne (Json $data.source_pins) -or $null -ne $receipt.source_drift -or $null -ne $receipt.protected_drift -or $null -ne $receipt.issue -or ((@($receipt.written_paths | Sort-Object) -join '|') -cne (@($data.overlay.path | Sort-Object) -join '|')) -or $receipt.framework_or_database_invoked -ne $false){throw 'Actual application receipt/source/history differs.'}
    foreach($pin in $receipt.archived_before.PSObject.Properties){if((Sha (Inside (Split-Path -Parent $path) $pin.Name)) -cne $pin.Value){throw 'Complete source before-image changed.'}}
    Assert-Main
}
function Assert-PhaseInputs([switch]$Enumerated) {
    Assert-Packet;Assert-Application
    $prepPath=Join-Path $runtime 'mirror-preparation.json';No-Reparse $runtime $sourceRoot
    if((Sha $prepPath) -cne $PreparationSha256){throw 'Exact actual fresh mirror preparation required.'}
    $prep=Get-Content -LiteralPath $prepPath -Raw | ConvertFrom-Json
    $template=Get-Content -LiteralPath (Join-Path $phasePacket 'proposed/native/profile.json') -Raw | ConvertFrom-Json
    $profile=Get-Content -LiteralPath (Join-Path $runtime 'profile.json') -Raw | ConvertFrom-Json
    if($prep.state -cne 'PREPARED_SOURCE_MIRROR_NOT_TEST_ACCEPTANCE' -or $prep.mirror_root -cne [IO.Path]::GetFullPath($root) -or $prep.source_root -cne $sourceRoot -or $prep.head -cne $Checkpoint -or $prep.proposal_manifest_sha256 -cne $ManifestSha256 -or $prep.source_review_sha256 -cne $SourceReviewSha256 -or $prep.application_receipt_sha256 -cne $ApplicationReceiptSha256 -or $prep.source_count -ne 7539 -or $profile.approved -ne $false -or $profile.expected_head -cne $Checkpoint -or $profile.mirror_preparation_sha256 -cne $PreparationSha256){throw 'Prepared current HEAD/source application binding differs.'}
    foreach($pair in @(@('source_pins','source_pins'),@('metadata_pins','mirror_metadata_pins'),@('package_mappings','vendor_package_mappings'),@('tool_pins','tools'),@('schema','schema'),@('inertia_page_pins','inertia_page_pins'))){if((Json $prep.($pair[0])) -cne (Json $template.($pair[1]))){throw 'Exact prepared map differs.'}}
    $normal=Get-Content -LiteralPath (Join-Path $runtime 'profile.json') -Raw | ConvertFrom-Json
    $normal.expected_head=$null;$normal.mirror_preparation_sha256=$null
    if($Enumerated){
        if($profile.framework_enumerated -ne $true -or $profile.inventory_authorized -ne $true -or $profile.expected_cases -le 0 -or !$profile.inventory_sha256){throw 'Actual inventory not proved.'}
        $path=Join-Path $runtime 'inventory.json';if((Sha $path) -cne $profile.inventory_sha256){throw 'Actual inventory changed.'};$inventory=Get-Content -LiteralPath $path -Raw | ConvertFrom-Json
        if($inventory.framework_exit -ne 0 -or $inventory.head -cne $Checkpoint -or $inventory.count -ne $profile.expected_cases -or $inventory.application_bootstrap -ne $false -or $inventory.database_or_scenario_execution -ne $false -or (Json $inventory.source_pins) -cne (Json $data.source_pins) -or $inventory.filter -cne $data.filter -or @($inventory.cases | Select-Object -Unique).Count -ne $inventory.count -or @($inventory.junit_identities | Select-Object -Unique).Count -ne $inventory.count){throw 'Exact actual no-application inventory differs.'}
        if((Json $profile.expected_source_class_counts) -cne (Json $inventory.source_class_counts) -or (Json $profile.expected_junit_class_counts) -cne (Json $inventory.junit_class_counts)){throw 'Actual class counts not derived from this inventory.'}
        foreach($name in @('list.stdout.log','list.stderr.log')){$key=($name.Split('.')[1]+'_sha256');if((Sha (Join-Path $runtime $name)) -cne $inventory.$key){throw 'Actual raw list output changed.'}}
        $normal.inventory_authorized=$false;$normal.framework_enumerated=$false;$normal.expected_cases=$null;$normal.inventory_sha256=$null;$normal.expected_source_class_counts=[pscustomobject]@{};$normal.expected_junit_class_counts=[pscustomobject]@{}
    }
    if((Json $normal) -cne (Json $template)){throw 'Unreviewed profile field transition.'}
    foreach($pin in $data.source_pins.PSObject.Properties){$path=Inside $root $pin.Name;No-Reparse $path $root;if((Sha $path) -cne $pin.Value){throw ('Mirror source changed: '+$pin.Name)}}
    foreach($pin in $data.metadata_pins.PSObject.Properties){$path=Inside $root $pin.Name;No-Reparse $path $root;if((Sha $path) -cne $pin.Value){throw 'Owned local Composer metadata changed.'}}
    foreach($mapping in $data.package_mappings){$item=Get-Item -LiteralPath (Inside $root $mapping.mirror_relative) -Force;if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0 -or @($item.Target).Count -ne 1 -or [IO.Path]::GetFullPath([string](@($item.Target)[0])) -cne [IO.Path]::GetFullPath([string]$mapping.read_only_source)){throw 'Exact read-only package target differs.'}}
    foreach($pin in $data.finite_vendor_pins.PSObject.Properties){if((Sha (Inside $root $pin.Name)) -cne $pin.Value){throw 'Mirrored finite vendor input changed.'}}
    foreach($pin in $template.tools.PSObject.Properties){$path=Inside $runtime $pin.Name;No-Reparse $path $root;if((Sha $path) -cne $pin.Value){throw 'Reviewed native/list tool changed.'}}
    foreach($name in @('.env','.env.testing','pint.json')){if(Test-Path -LiteralPath (Join-Path $root $name)){throw 'No private dotenv or alternate Pint configuration permitted.'}}
    if(Test-Path -LiteralPath (Join-Path $sourceRoot 'pint.json')){throw 'Installed default Pint configuration required.'}
    if((Sha (Inside $root $template.schema.path)) -cne $template.schema.sha256){throw 'Sealed schema copy changed; no old schema access.'}
}
function Assert-HerdWorkers([object[]]$all,$expected,$executables) {
    $rows=@($expected)
    if ($rows.Count -ne 5 -or (@($rows.pid | Sort-Object) -join '|') -cne '141120|164416|173132|184208|318324' -or @($executables.PSObject.Properties).Count -ne 2) { throw 'Exact captured Herd five-worker cohort required.' }
    foreach ($pin in $executables.PSObject.Properties) { if ((Get-FileHash -LiteralPath $pin.Name -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pin.Value) { throw 'Captured Herd executable changed.' } }
    $cgi=@($all | Where-Object { $_.Name -ieq 'php-cgi.exe' })
    if ($cgi.Count -ne 5 -or (@($cgi.ProcessId | Sort-Object) -join '|') -cne (@($rows.pid | Sort-Object) -join '|')) { throw 'Unknown, restarted or absent CGI worker; no peer exclusion.' }
    $herdParent=$null
    foreach ($row in $rows) {
        $matches=@($all | Where-Object { [int]$_.ProcessId -eq [int]$row.pid })
        if ($matches.Count -ne 1) { throw 'Captured Herd worker absent or ambiguous.' }
        $now=$matches[0]
        if ($now.Name -cne $row.name -or $now.ExecutablePath -cne $row.executable -or $now.CommandLine -cne $row.command -or ('utc:'+$now.CreationDate.ToUniversalTime().ToString('o')) -cne $row.birth_text -or [int]$now.ParentProcessId -ne [int]$row.parent_pid) { throw 'Captured Herd worker identity or parent changed.' }
        $parents=@($all | Where-Object { [int]$_.ProcessId -eq [int]$row.parent_pid })
        if ($parents.Count -ne 1) { throw 'Captured Herd parent absent or ambiguous.' }
        $parent=$parents[0]
        if ($parent.Name -cne $row.parent_name -or $parent.ExecutablePath -cne $row.parent_executable -or $parent.CommandLine -cne $row.parent_command -or ('utc:'+$parent.CreationDate.ToUniversalTime().ToString('o')) -cne $row.parent_birth_text -or $parent.CreationDate -gt $now.CreationDate) { throw 'Captured Herd parent-chain identity changed.' }
        if ([int]$row.pid -eq 164416) {
            if ([int]$row.parent_pid -ne 179500 -or $row.parent_name -cne 'Herd.exe') { throw 'Exact original Herd application parent required.' }
            $herdParent=$parent
        } elseif ([int]$row.parent_pid -ne 164416 -or $row.parent_name -cne 'php-cgi.exe') { throw 'Exact original CGI child chain required.' }
    }
    if (!$herdParent) { throw 'Captured Herd application parent not proved.' }
    return [pscustomobject]@{pid=[int]$herdParent.ProcessId;birth=$herdParent.CreationDate.ToUniversalTime().ToString('o');command=$herdParent.CommandLine;executable=$herdParent.ExecutablePath;kind='protected-herd-parent'}
}

function Get-Slot {
    $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    $herdParent=Assert-HerdWorkers $all $data.herd_workers $data.herd_runtime_executables
    $herdIds=@($data.herd_workers | ForEach-Object { [int]$_.pid })
    foreach ($p in $all) { if ($p.Name -ieq 'mysql.exe' -or ($p.Name -match '^php.*\.exe$' -and [int]$p.ProcessId -notin $herdIds -and ([string]::IsNullOrWhiteSpace($p.CommandLine) -or $p.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)'))) { throw ('Peer PHP/Pest/import active; preserve PID '+$p.ProcessId) } }
    $os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10;$cpu=@(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
    if ([long]$os.FreePhysicalMemory -le 0 -or $cpu.Count -ne 1 -or $null -eq $cpu[0].PercentProcessorTime -or [math]::Floor([long]$os.FreePhysicalMemory/1024) -lt 4096 -or [int]$cpu[0].PercentProcessorTime -gt 85) { throw 'Original4096/CPU85 admission held; no phase command started.' }
    $script:slotSamples+=[ordered]@{at_utc=[DateTimeOffset]::UtcNow.ToString('o');free_mib=[math]::Floor([long]$os.FreePhysicalMemory/1024);cpu_percent=[int]$cpu[0].PercentProcessorTime;peer_non_preview_php=0;mysql_import_clients=0}
    return @($all | Where-Object { $_.Name -match '^php.*\.exe$' } | ForEach-Object { [pscustomobject]@{pid=[int]$_.ProcessId;birth=(Birth $_);command=$_.CommandLine;executable=$_.ExecutablePath} }) + @($herdParent)
}
function Check-Protected {
    $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10);$null=Assert-HerdWorkers $all $data.herd_workers $data.herd_runtime_executables
    foreach ($old in $protected) { $now=Get-CimInstance Win32_Process -Filter ('ProcessId='+$old.pid) -OperationTimeoutSec 10;if (!$now -or (Birth $now) -cne $old.birth -or $now.CommandLine -cne $old.command -or $now.ExecutablePath -cne $old.executable) { throw 'Protected preview identity changed.' } }
}

function Fresh-Attempt([string]$prefix) {
    $history=Join-Path $runtime 'phase-history'
    if (!(Test-Path -LiteralPath $history)) { $null=New-Item -ItemType Directory -Path $history }
    if (((Get-Item -LiteralPath $history -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'Unexpected phase-history mapping.' }
    $path=Inside $history ($prefix+'-'+$AttemptName)
    if (Test-Path -LiteralPath $path) { throw 'Existing attempt must be retained; choose a fresh reviewed attempt name.' }
    $null=New-Item -ItemType Directory -Path $path
    [IO.File]::Copy((Join-Path $runtime 'profile.json'),(Join-Path $path 'profile.before.json'),$false)
    return $path
}

function Invoke-PhaseCommand([string]$mode) {
    $job=Join-Path $attempt $mode;$null=New-Item -ItemType Directory -Path $job
    $request=[ordered]@{mode=$mode;root=$root;checkpoint=$Checkpoint;nonce=[Guid]::NewGuid().ToString();preparation_sha256=$PreparationSha256;phase_manifest_sha256=$ManifestSha256}
    $request | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $job 'request.json') -Encoding utf8
    $test=$null;$handle=$null;$nativeStart=$null;$nativeExe=$null;$bound=$false;$seen=@{};$exitCode=$null;$issue=$null;$closed=$false;$caught=$null
    function Save-State([string]$phase) { $safeBirths=[ordered]@{};foreach($key in @($seen.Keys | Sort-Object)){$safeBirths[[string]$key]=$seen[$key]};[ordered]@{phase=$phase;at_utc=[DateTimeOffset]::UtcNow.ToString('o');mode=$mode;owner_pid=$(if($test){$test.Id}else{$null});native_handle=$(if($handle){[string]$handle}else{$null});native_start_utc=$(if($nativeStart){$nativeStart.ToString('o')}else{$null});native_executable=$nativeExe;initial_identity_bound=$bound;known_births=$safeBirths;actual_exit=$exitCode;caught=$caught;issue=$issue;owned_absent=$closed} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $job 'owned-state.json') -Encoding utf8 }
    function Track-Owned {
        $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
        do { $new=@($all | Where-Object { $child=$_;$parent=@($all | Where-Object {[int]$_.ProcessId -eq [int]$child.ParentProcessId})[0];$null -ne $parent -and $seen.ContainsKey([int]$parent.ProcessId) -and $seen[[int]$parent.ProcessId] -ceq (Birth $parent) -and $child.CreationDate -ge $parent.CreationDate -and !$seen.ContainsKey([int]$child.ProcessId) });foreach($child in $new){$seen[[int]$child.ProcessId]=Birth $child} } while ($new.Count -gt 0)
        return @($all | Where-Object {$seen.ContainsKey([int]$_.ProcessId) -and $seen[[int]$_.ProcessId] -ceq (Birth $_)})
    }
    try {
        $null=Get-Slot
        $args=@('-n','-d','memory_limit=256M',(Join-Path $PSScriptRoot 'phase-command.php'),$mode,$job)
        $test=Start-Process -FilePath $php -ArgumentList $args -WorkingDirectory $root -WindowStyle Hidden -RedirectStandardOutput (Join-Path $job 'driver.stdout.log') -RedirectStandardError (Join-Path $job 'driver.stderr.log') -PassThru
        Save-State 'spawn-returned-before-artifact-read'
        $handle=$test.Handle;$nativeStart=$test.StartTime.ToUniversalTime();$nativeExe=$test.MainModule.FileName;Save-State 'retained-owner-captured'
        if ($handle -eq [IntPtr]::Zero -or $nativeExe -cne (Resolve-Path -LiteralPath $php).Path) { throw 'Retained native identity unavailable.' }
        $actual=Get-CimInstance Win32_Process -Filter ('ProcessId='+$test.Id) -OperationTimeoutSec 10
        $micros=$nativeStart.Ticks-($nativeStart.Ticks % 10)
        if (!$actual -or [int]$actual.ProcessId -ne $test.Id -or [int]$actual.ParentProcessId -ne $PID -or $actual.ExecutablePath -cne $nativeExe -or ($actual.CreationDate.ToUniversalTime().Ticks-($actual.CreationDate.ToUniversalTime().Ticks % 10)) -ne $micros -or $test.HasExited -or $test.Handle -ne $handle -or $test.StartTime.ToUniversalTime() -ne $nativeStart) { throw 'First CIM is not the exact retained native owner.' }
        $seen[[int]$test.Id]=Birth $actual;$bound=$true;Save-State 'initial-identity-bound'
        $readyPath=Join-Path $job 'ready.json'
        while (!(Test-Path -LiteralPath $readyPath)) { if ($test.HasExited -or ([DateTimeOffset]::UtcNow-$started).TotalSeconds -gt 1800) { throw 'No live ready owner inside original deadline.' };Start-Sleep -Milliseconds 100;$test.Refresh() }
        $ready=Get-Content -LiteralPath $readyPath -Raw | ConvertFrom-Json
        if ($ready.pid -ne $test.Id -or $ready.request_sha256 -cne (Sha (Join-Path $job 'request.json')) -or $ready.mode -cne $mode) { throw 'Pinned command driver ready state differs.' }
        [ordered]@{owner_pid=[int]$test.Id;request_sha256=$ready.request_sha256;nonce=$request.nonce} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $job 'go.json') -Encoding utf8
        while (!$test.HasExited) { $null=Track-Owned;if (([DateTimeOffset]::UtcNow-$started).TotalSeconds -gt 1800) { throw 'Original1800-second phase deadline exceeded.' };Start-Sleep -Milliseconds 200;$test.Refresh() }
        $test.WaitForExit();$exitCode=$test.ExitCode;Save-State 'actual-exit-before-log-hashing'
        if ($null -eq $exitCode -or $exitCode -ne 0) { throw 'Actual owned phase command failed or exit unavailable.' }
    } catch { $caught=[ordered]@{message=$_.Exception.Message;type=$_.Exception.GetType().FullName;script_line=$_.InvocationInfo.ScriptLineNumber;stack=$_.ScriptStackTrace};$issue=$_.Exception.Message;Save-State 'caught-before-owned-closure' }
    finally {
        if ($test) {
            try {
                if (!$bound) {
                    if (!$handle -or !$nativeStart -or $nativeExe -cne (Resolve-Path -LiteralPath $php).Path) { throw 'Uncertain retained owner; no termination/no acceptance.' }
                    $test.Refresh();if (!$test.HasExited) { if ($test.Handle -ne $handle -or $test.StartTime.ToUniversalTime() -ne $nativeStart -or $test.MainModule.FileName -cne $nativeExe) {throw 'Retained owner changed; do not stop.'};$test.Kill() }
                    if (!$test.WaitForExit(10000) -or !$test.HasExited) {throw 'Retained absence unproven.'}
                    throw 'Initial CIM admission failed; descendant absence remains unproven. No acceptance or DROP.'
                }
                $left=@(Track-Owned);foreach($p in $left | Sort-Object CreationDate -Descending){Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop}
                $until=[DateTimeOffset]::UtcNow.AddSeconds(10)
                do {$left=@(Track-Owned);if($left.Count -eq 0){break};Start-Sleep -Milliseconds 200} while([DateTimeOffset]::UtcNow -lt $until)
                if ($left.Count -ne 0 -or !$test.WaitForExit(10000) -or !$test.HasExited) { throw 'Owned owner/descendant absence unproven.' }
                $closed=$true
            } catch { $issue=([string]$issue+'; closure: '+$_.Exception.Message).Trim('; ') }
            Save-State 'closure-before-artifact-read'
        }
    }
    if ($issue -or !$closed -or $exitCode -ne 0) { throw ('Phase failed; preserve full attempt: '+$issue) }
    $command=Get-Content -LiteralPath (Join-Path $job 'command-result.json') -Raw | ConvertFrom-Json
    if ($command.mode -cne $mode -or $command.request_sha256 -cne (Sha (Join-Path $job 'request.json')) -or $command.exit_code -ne 0) { throw 'Actual command receipt differs.' }
    foreach ($step in $command.steps) { if ($step.exit_code -ne 0 -or !$step.started_at -or !$step.completed_at -or (Sha (Join-Path $job ($step.name+'.stdout.log'))) -cne $step.stdout_sha256 -or (Sha (Join-Path $job ($step.name+'.stderr.log'))) -cne $step.stderr_sha256 -or (Get-Item -LiteralPath (Join-Path $job ($step.name+'.stdout.log'))).Length -le 0) { throw 'Command/real output receipt missing or changed.' } }
    return $command
}
