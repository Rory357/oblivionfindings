# Source-only proposal; functions run only from the explicitly reviewed parent wrapper.
function Sha([string]$path) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
function Write-NewJson([string]$path,$value) {
    $bytes=[Text.UTF8Encoding]::new($false).GetBytes(($value|ConvertTo-Json -Depth 40)+[Environment]::NewLine)
    $stream=[IO.File]::Open($path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::Read)
    try{$stream.Write($bytes,0,$bytes.Length)}finally{$stream.Dispose()}
}
function No-Reparse([string]$path,[string]$boundary) {
    $at=[IO.Path]::GetFullPath($path);$end=[IO.Path]::GetFullPath($boundary).TrimEnd([char[]]'\/')
    if($at -ine $end -and !$at.StartsWith($end+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Owned output/source is outside the fixed boundary.'}
    while($true){if(Test-Path -LiteralPath $at){if(((Get-Item -LiteralPath $at -Force).Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Owned output/source reparse point refused.'}};if($at -ieq $end){break};$at=[IO.Path]::GetDirectoryName($at)}
}
function Read-ResolvedPath([string]$path) {
    $resolved=[IO.Path]::GetFullPath($path)
    for($hop=0;$hop -lt 16;$hop++){
        $probe=$resolved;$found=$false
        while($probe){
            if(Test-Path -LiteralPath $probe){
                $item=Get-Item -LiteralPath $probe -Force
                if(($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){
                    $target=$item.ResolveLinkTarget($true);if(!$target){throw 'Read-only vendor final target unresolved.'}
                    $tail=$resolved.Substring($probe.Length).TrimStart([char[]]'\/')
                    $resolved=$(if($tail){Join-Path $target.FullName $tail}else{$target.FullName});$found=$true;break
                }
            }
            $probe=[IO.Path]::GetDirectoryName($probe)
        }
        if(!$found){return [IO.Path]::GetFullPath($resolved)}
    }
    throw 'Read-only dependency reparse chain is ambiguous.'
}
function Assert-Inputs {
    foreach($pin in $manifest.files.PSObject.Properties){
        if([IO.Path]::IsPathRooted($pin.Name) -or $pin.Name -match '(^|[\/])\.\.([\/]|$)' -or $pin.Name -match ':'){throw 'Unsafe reviewed packet path.'}
        $path=Join-Path $packet $pin.Name;No-Reparse $path $packet
        if((Sha $path) -cne $pin.Value){throw 'Reviewed cleanup packet changed.'}
    }
    if(@($profile.source_pins.PSObject.Properties).Count -ne 257 -or @($profile.read_only_external_vendor.PSObject.Properties).Count -ne 15){throw 'Exact finite source union/vendor ownership map required.'}
    if((Get-Content -LiteralPath (Join-Path $root '.git') -Raw).Trim() -cne ('gitdir: '+$profile.delivery_gitdir) -or (Get-Content -LiteralPath (Join-Path $profile.delivery_gitdir 'HEAD') -Raw).Trim() -cne $profile.delivery_head_ref -or (Get-Content -LiteralPath $profile.delivery_ref_path -Raw).Trim() -cne $profile.delivery_head){throw 'Exact Delivery ownership/HEAD changed.'}
    foreach($pin in $profile.source_pins.PSObject.Properties){
        if([IO.Path]::IsPathRooted($pin.Name) -or $pin.Name -match '(^|[\/])\.\.([\/]|$)' -or $pin.Name -match ':'){throw 'Unsafe source pin.'}
        $path=Join-Path $root $pin.Name;$exception=$profile.read_only_external_vendor.PSObject.Properties[$pin.Name]
        if($exception){if($exception.Value.read_only -ne $true -or $exception.Value.sha256 -cne $pin.Value -or (Read-ResolvedPath $path) -ine [IO.Path]::GetFullPath($exception.Value.resolved) -or (Sha $exception.Value.resolved) -cne $pin.Value){throw 'Explicit read-only vendor ownership changed.'}}else{No-Reparse $path $root}
        if((Sha $path) -cne $pin.Value){throw ('Current scoped source changed: '+$pin.Name)}
    }
    foreach($pin in $profile.asset_pins.PSObject.Properties){$path=Join-Path $root $pin.Name;No-Reparse $path $root;if((Sha $path) -cne $pin.Value){throw 'Phone20 current build/assets changed.'}}
    foreach($pin in $profile.historical_pins.PSObject.Properties){if((Sha $pin.Name) -cne $pin.Value){throw 'Historical rejection/failed evidence/current-map reference changed.'}}
    foreach($pin in $profile.runtime_executables.PSObject.Properties){if((Sha $pin.Name) -cne $pin.Value){throw 'Exact PowerShell7/PHP executable changed.'}}
    if(Test-Path -LiteralPath (Join-Path $root '.env')){throw 'Delivery must remain dotenv-free.'}
    if(Test-Path -LiteralPath (Join-Path $root '.env.testing')){throw 'Delivery must remain testing-dotenv-free.'}
}
function Assert-HerdWorkers([object[]]$all,$expected,$executables) {
    $rows=@($expected)
    if ($rows.Count -ne 5 -or (@($rows.pid | Sort-Object) -join '|') -cne '141120|164416|173132|184208|318324' -or @($executables.PSObject.Properties).Count -ne 2) { throw 'Exact captured Herd five-worker cohort required.' }
    foreach ($pin in $executables.PSObject.Properties) { if ((Get-FileHash -LiteralPath $pin.Name -Algorithm SHA256).Hash.ToLowerInvariant() -cne $pin.Value) { throw 'Captured Herd executable changed.' } }
    $cgi=@($all | Where-Object { $_.Name -ieq 'php-cgi.exe' })
    if ($cgi.Count -ne 5 -or (@($cgi.ProcessId | Sort-Object) -join '|') -cne (@($rows.pid | Sort-Object) -join '|')) { throw 'Unknown, restarted or absent CGI worker; no peer exclusion.' }
    $herdParent=$null
    foreach ($row in $rows) {
        $matches=@($all | Where-Object { [int]$_.ProcessId -eq [int]$row.pid })
        if ($matches.Count -ne 1) { throw 'Captured Herd worker absent or ambiguous.' }
        $now=$matches[0]
        if ($now.Name -cne $row.name -or $now.ExecutablePath -cne $row.executable -or $now.CommandLine -cne $row.command -or ('utc:'+$now.CreationDate.ToUniversalTime().ToString('o')) -cne $row.birth_text -or [int]$now.ParentProcessId -ne [int]$row.parent_pid) { throw 'Captured Herd worker identity or parent changed.' }
        $parents=@($all | Where-Object { [int]$_.ProcessId -eq [int]$row.parent_pid })
        if ($parents.Count -ne 1) { throw 'Captured Herd parent absent or ambiguous.' }
        $parent=$parents[0]
        if ($parent.Name -cne $row.parent_name -or $parent.ExecutablePath -cne $row.parent_executable -or $parent.CommandLine -cne $row.parent_command -or ('utc:'+$parent.CreationDate.ToUniversalTime().ToString('o')) -cne $row.parent_birth_text -or $parent.CreationDate -gt $now.CreationDate) { throw 'Captured Herd parent-chain identity changed.' }
        if ([int]$row.pid -eq 164416) {
            if ([int]$row.parent_pid -ne 179500 -or $row.parent_name -cne 'Herd.exe') { throw 'Exact original Herd application parent required.' }
            $herdParent=$parent
        } elseif ([int]$row.parent_pid -ne 164416 -or $row.parent_name -cne 'php-cgi.exe') { throw 'Exact original CGI child chain required.' }
    }
    if (!$herdParent) { throw 'Captured Herd application parent not proved.' }
    return [pscustomobject]@{pid=[int]$herdParent.ProcessId;birth=$herdParent.CreationDate.ToUniversalTime().ToString('o');command=$herdParent.CommandLine;executable=$herdParent.ExecutablePath;kind='protected-herd-parent'}
}


function Capture-Absence([string]$phase,$protected) {
    $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    $known=@($all|Where-Object{[int]$_.ProcessId -in @(81368,286956) -or [int]$_.ParentProcessId -in @(81368,286956)})
    # Any reused original PID is a hold; no guessed historical ExitCode/descendant history.
    if($known.Count -ne 0){throw 'Original PID, reused PID or currently linked descendant present; no SQL.'}
    if(@($all|Where-Object{$_.CommandLine -and $_.CommandLine -match 'delivery-calendar-r2-20261010|oblivion_workforce_dlvcal_r2_20261010'}).Count -ne 0){throw 'Old-runtime/schema process is present; no SQL.'}
    $herdParent=Assert-HerdWorkers $all $profile.herd_workers $profile.herd_runtime_executables
    $herdIds=@($profile.herd_workers|ForEach-Object{[int]$_.pid})
    foreach($p in $all){if($p.Name -ieq 'mysql.exe' -or ($p.Name -match '^php.*\.exe$' -and [int]$p.ProcessId -notin $herdIds -and ([string]::IsNullOrWhiteSpace($p.CommandLine) -or $p.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)'))){throw ('Native PHP/Pest/import or unknown peer present; preserve PID '+$p.ProcessId)}}
    $now=@($all|Where-Object{$_.Name -match '^php.*\.exe$'}|ForEach-Object{[pscustomobject]@{pid=[int]$_.ProcessId;birth_text=('utc:'+$_.CreationDate.ToUniversalTime().ToString('o'));name=$_.Name;executable=$_.ExecutablePath;command=$_.CommandLine;parent_pid=[int]$_.ParentProcessId}})
    $now+=@([pscustomobject]@{pid=$herdParent.pid;birth_text=('utc:'+$herdParent.birth);name='Herd.exe';executable=$herdParent.executable;command=$herdParent.command;parent_pid=[int](@($all|Where-Object{$_.ProcessId -eq $herdParent.pid})[0].ParentProcessId)})
    if($protected){
        if(@($protected).Count -ne $now.Count){throw 'Protected preview/Herd cohort membership changed.'}
        foreach($before in $protected){$match=@($now|Where-Object{$_.pid -eq $before.pid});if($match.Count -ne 1 -or $match[0].birth_text -cne $before.birth_text -or $match[0].name -cne $before.name -or $match[0].executable -cne $before.executable -or $match[0].command -cne $before.command -or $match[0].parent_pid -ne $before.parent_pid){throw 'Protected preview/Herd identity changed.'}}
    }
    $os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10;$cpu=@(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
    if([long]$os.FreePhysicalMemory -le 0 -or $cpu.Count -ne 1 -or $null -eq $cpu[0].PercentProcessorTime){throw 'Resource snapshot is incomplete.'}
    $sample=[ordered]@{phase=$phase;at_utc=[DateTimeOffset]::UtcNow.ToString('o');free_mib=[math]::Floor([long]$os.FreePhysicalMemory/1024);cpu_percent=[int]$cpu[0].PercentProcessorTime;peer_native_php=0;mysql_import_clients=0}
    $script:samples+=@($sample)
    if($sample.free_mib -lt 4096 -or $sample.cpu_percent -gt 85){throw 'Original4096/CPU85 gate held; no cleanup launch.'}
    return [pscustomobject]@{status='FRESH_KNOWN_OWNER_LINK_AND_DATABASE_CAPABLE_PEER_ABSENCE';phase=$phase;captured_at_utc=[DateTimeOffset]::UtcNow.ToString('o');root=$root;database=$profile.database;owner_pid=81368;owner_birth_text=$profile.owner_birth_text;child_pid=286956;child_birth_text=$profile.child_birth_text;known_owner_and_child_absent=$true;linked_processes_absent=$true;old_namespace_processes_absent=$true;native_php_absent=$true;mysql_import_clients_absent=$true;protected_processes=$now;original_owner_exit=$null;historical_complete_descendant_closure=$null;native_acceptance=$false}
}
