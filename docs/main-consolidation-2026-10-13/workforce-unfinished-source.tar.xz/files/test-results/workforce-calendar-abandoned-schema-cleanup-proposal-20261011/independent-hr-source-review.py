"""Independent pure-file review; no PHP, process, SQL, parser or helper invocation."""
from pathlib import Path
import datetime, hashlib, json, re

ROOT=Path('C:/Users/steph/Herd/oblivionfindings')
PACKET=ROOT/'test-results/workforce-calendar-abandoned-schema-cleanup-proposal-20261011'
EXPECTED='f291ad7def2978f82a8b83a20b0da24780fd0b2d250d3c652a7237ce1cf0148c'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def load(path): return json.loads(path.read_bytes().decode('utf-8-sig'))
def put(path,value): path.write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode('utf-8'))
assert sha(PACKET/'manifest.json')==EXPECTED
manifest=load(PACKET/'manifest.json'); profile=load(PACKET/'profile.json'); transition=load(PACKET/'source-transition.json')
delivery=Path(profile['root'])
files=manifest['files']
assert len(files)==68
assert all(sha(PACKET/p)==h for p,h in files.items())
assert len(profile['source_pins'])==257 and len(profile['asset_pins'])==1861 and len(profile['historical_pins'])==133
assert all(sha(delivery/p)==h for p,h in profile['source_pins'].items())
assert all(sha(delivery/p)==h for p,h in profile['asset_pins'].items())
assert all(sha(Path(p))==h for p,h in profile['historical_pins'].items())
assert all(sha(Path(p))==h for p,h in profile['runtime_executables'].items())
assert all(sha(Path(p))==h for p,h in profile['herd_runtime_executables'].items())
for p,entry in profile['read_only_external_vendor'].items():
    assert entry['read_only'] is True and sha(Path(entry['resolved']))==entry['sha256']==profile['source_pins'][p]
    assert (delivery/p).resolve()==Path(entry['resolved']).resolve()
assert len(profile['read_only_external_vendor'])==15
assert (delivery/'.git').read_bytes().decode('utf-8-sig').strip()=='gitdir: '+profile['delivery_gitdir']
assert (Path(profile['delivery_gitdir'])/'HEAD').read_bytes().decode('utf-8-sig').strip()==profile['delivery_head_ref']
assert Path(profile['delivery_ref_path']).read_bytes().decode('utf-8-sig').strip()==profile['delivery_head']

old=transition['original168']; current=transition['current209']; phone=transition['phone217_original']; union=transition['current_finite_union257']
assert len(old)==168 and len(current)==209 and len(phone)==217 and len(union)==257
original_profile=load(PACKET/'reference/original-failed19/profile.json')
assert old==original_profile['source_pins']
current_profile=load(Path(transition['current209_profile']))
assert sha(Path(transition['current209_profile']))==transition['current209_profile_sha256']
assert current==current_profile['source_pins']
assert union==profile['source_pins']
assert {p:current.get(p) for p in old if old[p]!=current.get(p)}=={
    item['path']:item['current_sha256'] for item in transition['original168_to_current209_changes']}
assert len(transition['original168_to_current209_changes'])==5
assert sum(old[p]==current.get(p) for p in old)==163
assert {p:union.get(p) for p in phone if phone[p]!=union.get(p)}=={
    item['path']:item['current_sha256'] for item in transition['phone217_current_changes']}
assert len(transition['phone217_current_changes'])==4
assert all(union[p]==h for p,h in current.items())
assert len(transition['phone_findings_preserved'])==6
assert transition['historical_old_run_source_pins_modified'] is False
assert transition['new_test_inventory_or_native_acceptance'] is False
oldraw=[p for p in files if p.startswith('reference/original-failed19/')]
assert len(oldraw)==19
for p in oldraw:
    assert sha(delivery/'test-results/delivery-calendar-r2-20261010'/Path(p).name)==files[p]

helpers=['close-abandoned-schema.ps1','guards.ps1','cleanup-schema.php']
patch=(PACKET/'new-helper.patch').read_bytes().splitlines(keepends=True)
inverse=[]
for name in helpers:
    header=('+++ b/'+name+'\n').encode(); assert patch.count(header)==1
    i=patch.index(header)+1; assert re.match(rb'@@ -0,0 \+1,\d+ @@',patch[i]); i+=1
    additions=[]
    while i<len(patch) and not patch[i].startswith(b'--- '):
        assert patch[i].startswith(b'+'); additions.append(patch[i][1:]); i+=1
    raw=b''.join(additions); assert raw==(PACKET/name).read_bytes()
    # Removing every independently reconstructed added byte returns ABSENT.
    inverse.append({'path':name,'before':'ABSENT','after_sha256':hashlib.sha256(raw).hexdigest(),
                    'whole_forward_exact':True,'whole_inverse_returns_absent':True,'bytes':len(raw)})
guards=(PACKET/'guards.ps1').read_bytes()
herd_reference=(PACKET/'reference/herd-r5/proposed/phase-common.ps1').read_bytes()
function=lambda b:re.search(rb'(?ms)^function Assert-HerdWorkers.*?(?=^function |\Z)',b).group().rstrip()
assert function(guards)==function(herd_reference)
php=(PACKET/'cleanup-schema.php').read_bytes().decode('utf-8')
wrapper=(PACKET/'close-abandoned-schema.ps1').read_bytes().decode('utf-8')
assert php.count("$pdo->exec('DROP DATABASE `oblivion_workforce_dlvcal_r2_20261010_81368`')")==1
assert "mysql:host=127.0.0.1;port=3306'" in php and 'dbname=' not in php
assert re.search(r'\b(?:require(?:_once)?|include(?:_once)?)\s*[\(\'"]',php) is None
assert profile['database']=='oblivion_workforce_dlvcal_r2_20261010_81368'
assert profile['owner_pid']==81368 and profile['child_pid']==286956
assert profile['owner_birth_text']=='utc:2026-10-10T10:08:58.6303700Z'
assert profile['child_birth_text']=='utc:2026-10-10T10:08:58.6435610Z'
assert profile['resource_floor_mib']==4096 and profile['cpu_ceiling_percent']==85
assert profile['execution_authorized'] is False and profile['native_acceptance'] is False
assert profile['historical_owner_exit'] is None and profile['historical_complete_descendant_closure'] is None
assert profile['original_rejected_action_relabelled'] is False
assert not (PACKET/'attempts').exists()
bindings={p:sha(PACKET/p) for p in ['manifest.json','profile.json','source-proof.json','source-transition.json','new-helper.patch','README.md']+helpers}
review={
 'status':'CLEAR_SOURCE_ONLY','manifest_sha256':EXPECTED,'reviewer':'backend_hr_eligibility',
 'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'database':profile['database'],'bindings':bindings,
 'verification':{'packet_files':68,'packet_drift':[],'current_source_union':257,'current_source_drift':[],
  'current_assets':1861,'asset_drift':[],'historical_pins':133,'historical_drift':[],
  'old_failed_raw_files':19,'raw_preserved':True,'current_vendor_ownership_exceptions':15,
  'old168_changed':5,'old168_unchanged':163,'phone217_changed':4,'current209_exact':True,
  'delivery_head_exact':True,'whole_helper_forward_inverse':inverse,
  'reviewed_herd_function_exact':True,'herd_function_sha256':hashlib.sha256(function(guards)).hexdigest()},
 'findings':[],
 'scope_conclusions':[
  'Exact approved literal schema only; server-level PDO DSN has no dbname and no old-schema content query.',
  'Shared nonblocking gate plus repeated4096MiB/CPU85, fixed Herd five/parent identities and captured preview identities; peers are never stopped.',
  'Any original/reused81368 or286956 PID, current link or old namespace process refuses SQL; absence binding includes exact recorded births and15-second freshness.',
  'Direct current-account global PROCESS or ALL PRIVILEGES proof precedes exact PROCESSLIST zero counts; role-only visibility deliberately refuses.',
  'Only literal DROP follows immediate second zero count; before proof and exact schema/connection reread are retained.',
  'Fresh attempt files; source/history/assets/protected final reconciliation and private environment restoration are explicit.',
  'Unknown original exit/full descendant history and original rejected action remain unchanged; this action cannot retrospectively certify native success.'
 ],
 'limitations':[
  'No parser, helper, gate, CIM/process observation, PHP, SQL, credentials, product or Git action was performed by this reviewer.',
  'Syntax checks and fresh parent runtime process/protected/connection/schema evidence remain required; current schema presence/absence is unobserved.',
  'The existing live connection recheck does not create an exclusive MySQL reservation; adverse later connections/readback refuse verified success.',
  'Historical complete descendants and original native exit remain unknown after any separately authorised cleanup.',
  'The executable binds the separate independent-lifecycle-review.json; this additional independent HR review does not substitute that required receipt.'
 ],
 'actual_cleanup':None,'actual_connections':None,'historical_original_exit':None,
 'historical_full_descendant_closure':None,'native_acceptance':False,'reviewer_execution':False}
put(PACKET/'independent-hr-review.json',review)
md='''CLEAR_SOURCE_ONLY on manifest `'''+EXPECTED+'''`.

No source blocker found. Independently reconstructed all three new helper additions and their whole removal inverses; the reviewed Herd function is byte-exact. All68 authored/reference files,257 current source paths,1861 assets,133 historical pins and19 original failed outputs match. The original168 transition has exactly five current changes/163 unchanged; the phone217 transition has four, with all six open findings retained. Current209 and Delivery HEAD match their exact bound records.

The wrapper retains the nonblocking shared gate, repeated4096MiB/CPU85 admission, exact five Herd workers/parent and preview identities, no peer termination, original/reused PID/link/namespace refusal, and fresh15-second known owner/child birth-bound absence. Standalone PDO imports no application and has no dbname. Direct current-account global PROCESS/ALL PRIVILEGES visibility is required before exact-schema connection counts. The sole literal DROP is followed by exact schema/connections readback; already absent is a distinct no-DROP outcome. Private transport is derived only from the pinned isolated XML and restored; SQL/credentials/grant text are not printed. Raw failures and source/history/protected closure remain independently reviewable.

This review did not parse, invoke, query, observe processes, acquire a gate or modify products/history. Parent syntax checks, the separately required LC review, fresh absence/protected checks, visible zero connections and actual readback remain prerequisites. No current schema state or actual cleanup is claimed. Immediate connection counts are not an exclusive reservation. The old native exit/full descendant history remains UNKNOWN; original rejection and failed evidence are not relabelled by any separately authorised cleanup.
'''
(PACKET/'independent-hr-review.md').write_bytes(md.encode('utf-8'))
assert sha(PACKET/'manifest.json')==EXPECTED
print(json.dumps({'status':review['status'],'review_sha256':sha(PACKET/'independent-hr-review.json'),
 'markdown_sha256':sha(PACKET/'independent-hr-review.md'),'manifest_sha256':EXPECTED}))
