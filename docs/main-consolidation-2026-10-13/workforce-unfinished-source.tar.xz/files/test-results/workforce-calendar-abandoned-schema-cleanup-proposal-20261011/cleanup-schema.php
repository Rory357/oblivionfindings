<?php
// Parent-invoked standalone PDO only: literal authorised schema, no autoload/app/content query.
declare(strict_types=1);

function jsonFile(string $path): array { return json_decode(file_get_contents($path), true, 512, JSON_THROW_ON_ERROR); }
function saveNew(string $path, array $data): void {
    $handle = fopen($path, 'x');
    if ($handle === false) { throw new RuntimeException('Fresh immutable proof path required.'); }
    try { $bytes = json_encode($data, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR)."\n"; if (fwrite($handle, $bytes) !== strlen($bytes)) { throw new RuntimeException('Proof write failed.'); } }
    finally { fclose($handle); }
}
try {
    $attempt = $argv[1] ?? '';
    $manifestHash = $argv[2] ?? '';
    $reviewHash = $argv[3] ?? '';
    $prefix = realpath(__DIR__.'/attempts');
    $actual = realpath($attempt);
    if ($prefix === false || $actual === false || dirname($actual) !== $prefix || preg_match('/\Ar[1-9][0-9]{0,2}\z/D', basename($actual)) !== 1 || ! preg_match('/\A[a-f0-9]{64}\z/D', $manifestHash) || ! preg_match('/\A[a-f0-9]{64}\z/D', $reviewHash)) { throw new RuntimeException('Reviewed exact fresh attempt required.'); }
    if (hash_file('sha256', __DIR__.'/manifest.json') !== $manifestHash || hash_file('sha256', __DIR__.'/independent-lifecycle-review.json') !== $reviewHash) { throw new RuntimeException('Exact source review binding required.'); }
    $manifest = jsonFile(__DIR__.'/manifest.json');
    foreach ($manifest['files'] as $path => $hash) { if (str_contains($path, '..') || str_contains($path, ':') || str_starts_with($path, '/') || hash_file('sha256', __DIR__.'/'.$path) !== $hash) { throw new RuntimeException('Reviewed cleanup input changed.'); } }
    $review = jsonFile(__DIR__.'/independent-lifecycle-review.json');
    if (($review['status'] ?? null) !== 'CLEAR_SOURCE_ONLY' || ($review['manifest_sha256'] ?? null) !== $manifestHash) { throw new RuntimeException('Reviewed parent helper required.'); }
    $profile = jsonFile(__DIR__.'/profile.json');
    $schema = 'oblivion_workforce_dlvcal_r2_20261010_81368';
    if ($profile['database'] !== $schema || $profile['owner_pid'] !== 81368 || $profile['child_pid'] !== 286956 || $profile['execution_authorized'] !== false) { throw new RuntimeException('Only exact authorised old schema allowed.'); }
    foreach ($profile['source_pins'] as $path => $hash) { if (hash_file('sha256', $profile['root'].'/'.$path) !== $hash) { throw new RuntimeException('Current finite source guard changed.'); } }
    foreach ($profile['historical_pins'] as $path => $hash) { if (hash_file('sha256', $path) !== $hash) { throw new RuntimeException('Original failed/rejected evidence changed.'); } }
    $approval = jsonFile($actual.'/exact-parent-execution.json');
    $absenceBytes = file_get_contents($actual.'/process-absence.json');
    $absence = json_decode($absenceBytes, true, 512, JSON_THROW_ON_ERROR);
    if (($approval['approved_exact_schema_only'] ?? false) !== true || $approval['database'] !== $schema || $approval['owner_pid'] !== 81368 || $approval['child_pid'] !== 286956 || $approval['manifest_sha256'] !== $manifestHash || $approval['independent_review_sha256'] !== $reviewHash || $approval['cleanup_sha256'] !== hash_file('sha256', __FILE__) || $approval['process_absence_sha256'] !== hash('sha256', $absenceBytes)) { throw new RuntimeException('Explicit reviewed parent execution and process proof required.'); }
    $captured = new DateTimeImmutable($absence['captured_at_utc']);
    $age = microtime(true) - (float) $captured->format('U.u');
    if ($age < 0 || $age > 15 || $absence['root'] !== $profile['root'] || $absence['database'] !== $schema || $absence['owner_pid'] !== 81368 || $absence['child_pid'] !== 286956 || $absence['owner_birth_text'] !== 'utc:2026-10-10T10:08:58.6303700Z' || $absence['child_birth_text'] !== 'utc:2026-10-10T10:08:58.6435610Z' || $absence['original_owner_exit'] !== null || $absence['historical_complete_descendant_closure'] !== null) { throw new RuntimeException('Fresh absence with honest original unknown closure required.'); }
    foreach (['known_owner_and_child_absent','linked_processes_absent','old_namespace_processes_absent','native_php_absent','mysql_import_clients_absent'] as $key) { if (($absence[$key] ?? false) !== true) { throw new RuntimeException('Required fresh absence is unproven.'); } }
    if (getenv('DB_CONNECTION') !== 'mysql' || getenv('DB_HOST') !== '127.0.0.1' || getenv('DB_PORT') !== '3306' || getenv('DB_DATABASE') !== 'oblivion_workforce_dlvcal_r2_20261010' || ! in_array(getenv('DB_URL'), [false, ''], true) || ! in_array(getenv('DB_SOCKET'), [false, ''], true)) { throw new RuntimeException('Exact original local isolated transport required.'); }
    // No dbname in DSN: never connect to old schema or inspect its contents.
    $pdo = new PDO('mysql:host=127.0.0.1;port=3306', getenv('DB_USERNAME'), getenv('DB_PASSWORD'), [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT=>5]);
    // PROCESSLIST without PROCESS can hide other users. Prove current-account visibility, never add grants.
    $visible = false;
    foreach ($pdo->query('SHOW GRANTS FOR CURRENT_USER')->fetchAll(PDO::FETCH_COLUMN) as $grant) {
        if (preg_match('/\AGRANT (.+) ON \*\.\* TO /D', $grant, $match) === 1) {
            $tokens = array_map('trim', explode(',', $match[1]));
            if (in_array('ALL PRIVILEGES', $tokens, true) || in_array('PROCESS', $tokens, true)) { $visible = true; }
        }
    }
    if (! $visible) { throw new RuntimeException('Global process visibility not proven; refuse cleanup.'); }
    $pdo->exec('SET SESSION lock_wait_timeout = 10');
    $schemaQuery = $pdo->prepare('SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?');
    $connectionsQuery = $pdo->prepare('SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE DB = ?');
    $schemaQuery->execute([$schema]); $before = (int) $schemaQuery->fetchColumn();
    if (! in_array($before, [0,1], true)) { throw new RuntimeException('Exact schema metadata ambiguous.'); }
    $connectionsQuery->execute([$schema]); $connections = (int) $connectionsQuery->fetchColumn();
    if ($connections !== 0) { throw new RuntimeException('Exact schema still has connections; refuse cleanup.'); }
    $beforeProof = ['database'=>$schema,'schema_count_before'=>$before,'connections_before'=>$connections,'process_visibility_proven'=>true,'cleanup_pid'=>getmypid(),'manifest_sha256'=>$manifestHash,'independent_review_sha256'=>$reviewHash,'process_absence_sha256'=>hash('sha256',$absenceBytes),'original_owner_exit'=>null,'historical_complete_descendant_closure'=>null,'native_acceptance'=>false];
    saveNew($actual.'/before-drop.json', $beforeProof);
    // Last scoped connection count is immediately before the sole literal destructive statement.
    $connectionsQuery->execute([$schema]);
    if ((int) $connectionsQuery->fetchColumn() !== 0) { throw new RuntimeException('A connection appeared; refuse cleanup.'); }
    if ($before === 1) { $pdo->exec('DROP DATABASE `oblivion_workforce_dlvcal_r2_20261010_81368`'); }
    $schemaQuery->execute([$schema]); $after = (int) $schemaQuery->fetchColumn();
    $connectionsQuery->execute([$schema]); $afterConnections = (int) $connectionsQuery->fetchColumn();
    $proof = $beforeProof + ['schema_count_after'=>$after,'connections_after'=>$afterConnections,'drop_executed'=>$before===1,'state'=>$before===1?'EXACT_SCHEMA_DROP_READBACK':'EXACT_SCHEMA_ALREADY_ABSENT_READBACK'];
    saveNew($actual.'/schema-cleanup.json', $proof);
    if ($after !== 0 || $afterConnections !== 0) { throw new RuntimeException('Exact zero schema/connections readback not proven.'); }
    exit(0);
} catch (Throwable $error) {
    // No SQL/credential/grant text in output. Parent retains stage evidence and nonzero exit.
    fwrite(STDERR, 'Exact-schema cleanup guard or PDO phase failed; preserve this attempt and review.\n');
    exit(1);
}
