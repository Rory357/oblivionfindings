Calendar move candidate; inactive and source-only.

The cleared reader packet eb145495 is a prerequisite. This proposal adds only `extendedProps.shift_source` to its numeric Shift events. The value is a lowercase SHA256 over the same authorised Shift row as the displayed dates, excluding query-count attributes and created/updated timestamps. It is an opaque source identity, not permission or replay authority. The non-event assessment marker and all existing event fields remain unchanged. The strict assessment decoder/Show capability frontend composition remains required before applying the combined reader.

The existing PATCH route is retained. A modern caller sends `X-Calendar-Move-Result: committed-v1`, `request_id` (UUID), `expected_source` (exact 64-character displayed hash), and existing partial edit fields. Both submitted times are required together, normalised through the configured worker timezone for offset-free values, and stored as UTC at the existing second precision. Explicit offsets retain their instants. Stale source returns409 before writes. UUIDs correlate this attempt only; there is no ledger, replay, retry or recovered historical success claim.

A verified root save returns200 with the existing `{ok:true,shift}` shape, using a freshly read persisted Shift and the same existing limited Client/staff relations and tasks. Modern responses additionally contain:

```
calendar_move_result: {
  version: 1, scope: 'calendar_move', action: 'update',
  actor_id: number, shift_id: number, request_id: string,
  source: string, outcome: 'confirmed',
  saved: {id, client_id, site_id, user_id, service_context_id,
          status, starts_at, ends_at, shift_source},
  verified_at: 'UTC ISO at seconds'
}
```

Nullable IDs and dates retain null; planning status remains draft/scheduled. `verified_at` is the successful verification instant, not a reconstructed commit timestamp. The frontend must match current actor, action, Shift, attempt UUID and displayed source, then compare the saved tuple to submitted intent. Do not use an Inertia success callback, HTTP200 alone, missing response, or a receipt from another attempt as confirmation.

Nested Laravel transactions return202 `{ok:false,message,calendar_move_result:{...identity,outcome:'not_confirmed'}}`, with no saved tuple/model. Their caller still owns commit/rollback. A raw-PDO-only enclosure is left untouched and gets the same202 without executing the writer. Postcommit readback failure/mismatch is also202; a saved row may already exist. Legacy callers keep200 `{ok:true,shift}` only at a verified physical root, and receive202 when the save cannot be confirmed. Existing validation/authority errors retain403/404/409/422; unexpected database/commit/transport failure supplies no receipt and must remain unknown. No automatic retry is safe.

The command takes the existing application mutex, current actor/RBAC/profile evidence, the canonical Shift lock, and current Client/Site/assignee reads. Initial source ownership is retained for own-only edits; manageAny changes ownership authority but does not invent a Site bypass. Canonical planning Site scope uses the installed reports.viewAny exception; the reader's manageAny feed bypass does not imply write access. Both original and destination Client Sites and current workers must be lawful, and linked-series Sites must remain readable. Final current authority is rechecked after normal observers. No new grant, role or organisation boundary is introduced.

Completed, cancelled, in-progress and approved-Timesheet records retain the installed planning guard. The same Calendar eligibility-relevant fields trigger initial/final eligibility checks. Hard blocks and evaluation failures prevent saving. Ordinary warnings still save without a new blanket acknowledgement, reason or override grant. **The existing structured qualification-acknowledgement gap is explicitly a separate required proposal/contract, not closed by this writer packet.** It must preserve configured warn/block and existing qualification manager/acknowledgement/reason rules; neither this packet nor its ordinary-warning control certifies that separate seam.

Shift save(false), normal observer alteration, task save(false), coverage create/update(false), and later source/task/hold/timeline changes throw inside the one transaction. Two optional checked callbacks preserve existing CoverageReservationService and ShiftTimelineService defaults for every other caller. No replacement/lifecycle algorithm is transplanted. Manual task semantics and worker/handover-owned task protection remain; foreign task IDs deny. Existing publication observer owns the dirty marker. History fields and formatting use the existing service. Notifications are registered afterCommit, and notification/logger transport failure cannot turn a saved root into a false rollback claim.

New automatic holds are created inside the move transaction and disappear on failure. An existing caller-owned token remains as its precommand state after rollback, rather than being unchecked-released outside the failed transaction. Current TTL/window/token/coverage arithmetic and supply event ownership remain unchanged. This is an explicit correction to the old non-atomic compensation boundary, not a claim that reservation rules were redesigned.

Limits: no parser, formatter, application, inventory, native/database or browser execution occurred. Current source clearance is not concurrency/lock-contention/transport acceptance. The rule stack retains existing non-qualification advisory read semantics; this packet does not certify an atomic snapshot of every HR rule input. Required audits/publication run side effects are preserved through existing observers rather than replaced with a new audit architecture. Separate readback controls prove Shift/task/hold/timeline intent, current actor/source at transaction completion and physical root—not future immutability. eMAR, Shift Show, Leave, create and unrelated service methods remain unchanged.
