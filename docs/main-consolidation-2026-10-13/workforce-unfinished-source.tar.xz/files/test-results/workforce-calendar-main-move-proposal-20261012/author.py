from pathlib import Path
import hashlib, json, re, datetime, difflib

ROOT = Path('C:/Users/steph/Herd/oblivionfindings')
PACKET = ROOT / 'test-results/workforce-calendar-main-move-proposal-20261012'
READER = ROOT / 'test-results/workforce-calendar-main-reader-proposal-20261011'
sha = lambda b: hashlib.sha256(b).hexdigest()
# Pure text utilities only: do not import/execute the earlier authoring workflow.
utilities = (READER / 'author.py').read_text(encoding='utf-8-sig')
exec(utilities[utilities.index('def block('):utilities.index('before = (ROOT / CONTROLLER)')])

def save(relative, data):
    p = PACKET / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    if p.exists():
        assert p.read_bytes() == data, relative
    else:
        p.write_bytes(data)

def dump(relative, obj):
    save(relative, (json.dumps(obj, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))

controller_path = 'app/Http/Controllers/CalendarController.php'
current = (ROOT / controller_path).read_bytes()
reader = (READER / 'proposed' / controller_path).read_bytes()
assert sha(current) == '69616a2f1233c2493f84301f198e8df1c8d2021d14ea35d4b4c2a797446a6f25'
assert sha(reader) == '0539fe22a28c93a04b51b356fdb5def00380c6157a56a8bdf126e45329d65de1'
old_method = block(reader, 'updateShift')
method = old_method.decode('utf-8')
validation = method[method.index('        $data = $request->validate(['):method.index('        $data = $this->normalizeShiftData($data);')]
validation = validation.replace("        $data = $request->validate([", "        $modern = $request->header('X-Calendar-Move-Result') === 'committed-v1';\r\n        $data = $request->validate([\r\n            'request_id' => $modern ? ['required', 'uuid'] : ['sometimes', 'uuid'],\r\n            'expected_source' => $modern ? ['required', 'string', 'regex:/^[a-f0-9]{64}$/D'] : ['sometimes', 'string', 'regex:/^[a-f0-9]{64}$/D'],")
new_method = '''    public function updateShift(Request $request, Shift $shift)
    {
        $auth = $request->user();
        abort_unless($auth && $auth->canDo('shifts.update'), 403);
'''.replace('\n', '\r\n') + validation + '''        $result = app(CalendarShiftMove::class)->move($request, $shift, $this->normalizeShiftData($data));

        return response()->json($result['body'], $result['status']);
    }'''.replace('\n', '\r\n')
after = reader.replace(old_method, new_method.encode('utf-8'), 1)
after = after.replace(b'use App\\Services\\NotificationService;\r\n', b'use App\\Services\\NotificationService;\r\nuse App\\Services\\Operations\\CalendarShiftMove;\r\n', 1)
# Hash is opaque and computed from the same authorised Shift row as displayed times.
after = after.replace(b"                    'can_view_shift' =>", b"                    'shift_source' => CalendarShiftMove::source($shift),\r\n                    'can_view_shift' =>", 1)
save('current-before/' + controller_path, current)
save('before/' + controller_path, reader)
save('proposed/' + controller_path, after)
changes = [(controller_path, reader, after)]
preserved = {}
for method in ['__construct', 'storeShift', 'normalizeShiftData', 'assertCoverageClientMatchesContext', 'calendarSeriesScope', 'calendarCoverage']:
    assert block(reader, method) == block(after, method)
    preserved[controller_path + '::' + method] = sha(block(reader, method))
assert block(reader, 'events').replace(b"                    'can_view_shift' =>", b"                    'shift_source' => CalendarShiftMove::source($shift),\r\n                    'can_view_shift' =>", 1) == block(after, 'events')

path = 'app/Services/CoverageReservationService.php'
before = (ROOT / path).read_bytes()
after_hold = before
old = block(before, 'fulfill')
new = old.replace(b'?ShiftOpenPosition $position = null)', b'?ShiftOpenPosition $position = null, ?\\Closure $checkedWrite = null)')
new = new.replace(b"        $reservation->update([", b"        $write = $checkedWrite ?? static fn (CoverageReservation $row, array $values) => $row->update($values);\n        $write($reservation, [", 1)
after_hold = after_hold.replace(old, new)
old = block(before, 'reserveForCoveragePayload')
new = old.replace(b"string $reason = 'planning_fill')", b"string $reason = 'planning_fill', ?\\Closure $checkedWrite = null)")
new = new.replace(b'$reservationRoleKey, $reason)', b'$reservationRoleKey, $reason, $checkedWrite)') if b'$reservationRoleKey, $reason)' in new else new
new = new.replace(b'$coverageRequirementId, $roleKey, $reason)', b'$coverageRequirementId, $roleKey, $reason, $checkedWrite)')
new = new.replace(b"                $active->update([", b"                $write = $checkedWrite ?? static fn (CoverageReservation $row, array $values) => $row->update($values);\n                $write($active, [", 1)
new = new.replace(b"            return CoverageReservation::create([", b"            $values = [", 1)
ending = b"            ]);\n        });\n    }"
assert new.endswith(ending)
new = new[:-len(ending)] + b"            ];\n            if ($checkedWrite) {\n                return $checkedWrite(new CoverageReservation, $values);\n            }\n\n            return CoverageReservation::create($values);\n        });\n    }"
after_hold = after_hold.replace(old, new)
assert b'use ($actor, $siteId, $windowStartsAt, $windowEndsAt, $coverageRequirementId, $roleKey, $reason, $checkedWrite)' in after_hold
save('before/' + path, before)
save('proposed/' + path, after_hold)
changes.append((path, before, after_hold))
for method in re.findall(rb'^    (?:public|protected|private)(?: static)? function (\w+)\(', before, re.M):
    name = method.decode()
    if name not in ['fulfill', 'reserveForCoveragePayload']:
        assert block(before, name) == block(after_hold, name)
        preserved[path + '::' + name] = sha(block(before, name))

path = 'app/Services/ShiftTimelineService.php'
before = (ROOT / path).read_bytes()
old = block(before, 'syncSnapshot')
# The original builder fields and formatting methods remain byte exact.
values = old[old.index(b'            [\n                \'occurred_at\''):old.rindex(b'            ]')+len(b'            ]')]
values = values.replace(b'            [', b'        [', 1)
keys = b"['type' => self::SNAPSHOT_EVENT_TYPE, 'source_type' => Shift::class, 'source_id' => $shift->id]"
new = b"    public function syncSnapshot(Shift $shift, ?\\Closure $checkedWrite = null): TimelineEvent\n    {\n        $shift = $this->loadShiftContext($shift);\n        $keys = " + keys + b";\n        $values = " + values + b";\n        if ($checkedWrite) {\n            $row = TimelineEvent::query()->where($keys)->lockForUpdate()->first() ?? new TimelineEvent;\n\n            return $checkedWrite($row, [...$keys, ...$values]);\n        }\n\n        return TimelineEvent::query()->updateOrCreate($keys, $values);\n    }"
after_timeline = before.replace(old, new)
save('before/' + path, before)
save('proposed/' + path, after_timeline)
changes.append((path, before, after_timeline))
for method in re.findall(rb'^    (?:public|protected|private)(?: static)? function (\w+)\(', before, re.M):
    name = method.decode()
    if name != 'syncSnapshot':
        assert block(before, name) == block(after_timeline, name)
        preserved[path + '::' + name] = sha(block(before, name))

for path in ['app/Services/Operations/CalendarShiftMove.php', 'tests/Feature/Rostering/WorkforceCalendarMoveIntegrityTest.php']:
    assert not (ROOT / path).exists()
    changes.append((path, None, (PACKET / 'proposed' / path).read_bytes()))
forward = patch(changes)
inverse = patch(changes, reverse=True)
save('repair.patch', forward)
save('inverse.patch', inverse)
# Full current-MAIN composition explicitly includes the untouched reader prerequisite.
composed = [(changes[0][0], current, changes[0][2]), *changes[1:]]
save('current-main-composed.patch', patch(composed))
save('current-main-composed-inverse.patch', patch(composed, reverse=True))
proofs = []
for path, before, after in changes:
    assert reconstruct(before, patch([(path, before, after)])) == after
    assert reconstruct(after, patch([(path, before, after)], reverse=True)) == (before or b'')
    proofs.append({'path': path, 'before_exists': before is not None, 'before_sha256': sha(before) if before is not None else None,
        'after_sha256': sha(after), 'raw_forward_exact': True, 'raw_inverse_exact': True})

deps = json.loads((READER / 'dependency-pins.json').read_text(encoding='utf-8-sig'))
# The reader pins format is inspected rather than assumed by consumers.
own_dependencies = ['app/Services/Operations/WorkforceMutationGuard.php', 'app/Services/AuthorizationEvidenceLockService.php',
    'app/Services/CurrentAuthorizationReads.php', 'app/Services/CoverageReservationService.php', 'app/Services/ShiftTimelineService.php',
    'app/Services/ShiftStaffEligibilityService.php', 'app/Services/ShiftConflictService.php', 'app/Services/ShiftStateGuardService.php',
    'app/Services/NotificationService.php', 'app/Domain/Rostering/RosterPublishingService.php', 'app/Models/Shift.php',
    'app/Models/ShiftTask.php', 'app/Models/CoverageReservation.php', 'app/Models/TimelineEvent.php',
    'app/Models/Concerns/AuditableChanges.php', 'app/Models/Concerns/WritesLegacyOrganizationStorageContext.php',
    'app/Observers/ShiftObserver.php', 'app/Domain/Hr/Services/HrCurrentStaffService.php',
    'app/Services/UserSiteAccessService.php', 'app/Models/User.php', 'app/Models/Client.php', 'app/Models/Site.php',
    'app/Models/ShiftSeries.php', 'app/Models/ServiceContext.php', 'app/Models/SiteCoverageRequirement.php',
    'app/Services/Eligibility/EligibilityResult.php', 'app/Support/ShiftTaskSupport.php', 'routes/operations.php',
    'app/Http/Middleware/RoleScope.php', 'app/Http/Middleware/EnsureAccountStillApproved.php', 'config/app.php',
    'tests/TestCase.php', 'tests/Pest.php', 'tests/Support/OwnedTestDatabase.php', 'tests/Support/CommittedFixtureCleanup.php',
    'tests/Feature/Hr/WorkforceLeaveReviewReceiptIntegrityTest.php', 'app/Domain/Hr/Services/LeaveReviewReceipt.php',
    'tests/Feature/Rostering/WorkforceShiftSaveCommandIntegrityTest.php',
    'tests/Feature/Rostering/WorkforceRosteringReadPermissionIntegrityTest.php', 'tests/Feature/Respite/RespiteReadinessTest.php']
pins = {p: sha((ROOT / p).read_bytes()) for p in own_dependencies}
dump('dependency-pins.json', pins)
history = ['manifest.json', 'repair.patch', 'inverse.patch', 'dependency-pins.json', 'selection.json', 'source-proof.json',
    'independent-hr-review.json', 'proposed/' + controller_path, 'proposed/tests/Feature/Rostering/WorkforceCalendarReadIntegrityTest.php']
references = {str((READER / p).relative_to(ROOT)).replace('\\', '/'): sha((READER / p).read_bytes()) for p in history}
dump('prerequisite-pins.json', references)
test = changes[-1][2]
methods = re.findall(rb'^    public function (test_\w+)\(', test, re.M)
rows = []
for name in methods:
    body = block(test, name.decode())
    pos = test.index(body)
    prefix = test[:pos].splitlines()[-1:]
    m = re.search(rb"DataProvider\('([^']+)'\)", b''.join(prefix))
    provider = m.group(1).decode() if m else None
    labels = re.findall(rb"^            '([^']+)' =>", block(test, provider), re.M) if provider else []
    rows.append({'method': name.decode(), 'provider': provider, 'source_derived_cases': len(labels) if provider else 1,
        'dataset_labels': [x.decode() for x in labels], 'body_sha256': sha(body)})
dump('selection.json', {'source_derived_only': True, 'framework_enumerated': False, 'actual_inventory': None, 'actual_cases': None,
    'approved': False, 'runtime_approved': False, 'new_writer_cases': sum(r['source_derived_cases'] for r in rows), 'methods': rows,
    'required_union': ['whole proposed WorkforceCalendarMoveIntegrityTest', 'whole cleared WorkforceCalendarReadIntegrityTest',
        'whole current WorkforceRosteringReadPermissionIntegrityTest', 'whole current RespiteReadinessTest'],
    'union_actual_count': None, 'writer_default_service_preservation': ['whole current WorkforceShiftSaveCommandIntegrityTest recommended for optional callback default seams']})
dump('source-proof.json', {'state': 'PURE_FILE_COMPARISONS_ONLY', 'changes': proofs, 'preserved_unowned_method_bodies': preserved,
    'events_delta': 'one additive source hash field only over cleared reader', 'current_source_drift': [],
    'parser_framework_database_runtime_invoked': False})
files = {str(p.relative_to(PACKET)).replace('\\', '/'): sha(p.read_bytes()) for p in sorted(PACKET.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
dump('manifest.json', {'state': 'INACTIVE_SOURCE_ONLY_REVIEW_READY', 'root': str(ROOT), 'head': None,
    'head_not_inspected': True, 'approved': False, 'runtime_approved': False, 'framework_enumerated': False, 'actual_cases': None,
    'candidate_paths': proofs, 'reader_prerequisite_sha256': references['test-results/workforce-calendar-main-reader-proposal-20261011/manifest.json'],
    'front_end_marker_decoder_prerequisite_required': True, 'front_end_move_receipt_integration_required': True,
    'new_source_derived_cases': sum(r['source_derived_cases'] for r in rows), 'files': files})
print(json.dumps({'manifest': sha((PACKET/'manifest.json').read_bytes()), 'patch': sha(forward), 'source_derived_cases': sum(r['source_derived_cases'] for r in rows), 'preserved_methods': len(preserved), 'paths': proofs}, indent=2))
