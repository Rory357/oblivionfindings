# Calendar saved-move independent source review

HOLD_SOURCE_ONLY against manifest `315898f2f8e622f2cd169fe1d9c8d316a4a11fd6e83293d320abde79129c0a5b`.

Three concrete P1 source seams remain:

- **H1 — automatic hold intent:** new CoverageReservation links are omitted from pre-save intent, so a creating observer can inject a position link that fulfillment preserves. Bind explicit null links for new checked holds and cover that mutation.
- **H2 — final canonical destination:** the final authority pass still suppresses persisted Shift Site versus Client Site equality when `client_id` was submitted. Apply the prospective exemption only before persistence and cover a distinct destination Client moved late to another approved Site.
- **H3 — first timeline snapshot:** normal ShiftObserver writes the first snapshot without the checker; first-only reparenting can leave it behind while the later checked call creates a correct second row. Preserve the original snapshot identity/intent through normal observers and test that first boundary.

Five full candidate forwards/inverses and five current-MAIN composed directions are byte exact. All 20 authored pins, 40 current dependencies, nine reader prerequisites, and 50 preserved method bodies match. The 43 controls are source-derived; no framework inventory or runtime result exists.

Physical-root/PDO and nested/readback outcome separation, checked task writes/list preservation, terminal guards and notification failure containment are coherent within their stated scope. Separate structured qualification acknowledgement, descriptor/Show and move-receipt frontend integration remain required. No PHP/parser, runtime, process, DB, Git or product action was invoked. Frozen writer315898 remains unchanged.
