<?php

namespace App\Services\Operations;

use App\Domain\Hr\Services\HrCurrentStaffService;
use App\Models\Client;
use App\Models\CoverageReservation;
use App\Models\Shift;
use App\Models\ShiftSeries;
use App\Models\ShiftTask;
use App\Models\SiteCoverageRequirement;
use App\Models\User;
use App\Services\CoverageReservationService;
use App\Services\CurrentAuthorizationReads;
use App\Services\NotificationService;
use App\Services\ShiftConflictService;
use App\Services\ShiftStaffEligibilityService;
use App\Services\ShiftStateGuardService;
use App\Services\ShiftTimelineService;
use App\Services\UserSiteAccessService;
use App\Support\ShiftTaskSupport;
use Illuminate\Database\Connection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use PDO;

/** Calendar-only partial planning edit. UUIDs correlate one attempt; they never replay it. */
class CalendarShiftMove
{
    public function move(Request $request, Shift $bound, array $data): array
    {
        $connection = DB::connection();
        $pdo = $connection->getPdo();
        $root = $connection->transactionLevel() === 0 && ! $pdo->inTransaction();
        $modern = $request->header('X-Calendar-Move-Result') === 'committed-v1';
        $identity = $modern ? ['version' => 1, 'scope' => 'calendar_move', 'action' => 'update',
            'actor_id' => (int) $request->user()->id, 'shift_id' => (int) $bound->id,
            'request_id' => $data['request_id'], 'source' => $data['expected_source']] : null;
        $unknown = ['ok' => false, 'message' => 'The calendar change could not be confirmed. Refresh before deciding what to do next.'];
        if ($identity) {
            $unknown['calendar_move_result'] = [...$identity, 'outcome' => 'not_confirmed'];
        }
        // A raw PDO transaction is not owned by Laravel. Do not attempt to begin,
        // commit, roll back or change that enclosing transaction.
        if ($connection->transactionLevel() === 0 && $pdo->inTransaction()) {
            return ['status' => 202, 'body' => $unknown];
        }
        $result = DB::transaction(function () use ($request, $bound, $data, $modern): array {
            app(WorkforceMutationGuard::class)->lock();
            $shift = Shift::query()->whereKey($bound->id)->lockForUpdate()->firstOrFail();
            $origin = clone $shift;
            $source = self::source($shift);
            $actor = $this->authority($request->user(), $origin, $shift, $data);
            abort_unless($source === ($modern ? $data['expected_source'] : self::source($bound)), 409,
                'This Shift changed. Refresh its current record before moving it again.');
            $data = $this->intent($shift, $data);
            $prospective = clone $shift;
            $prospective->fill(Arr::except($data, ['tasks', 'coverage_reservation_token', 'coverage_rule_id', 'request_id', 'expected_source']));
            $actor = $this->authority($actor, $origin, $prospective, []);
            $this->editable($shift);
            $this->eligibility($prospective, $data);
            $tasks = $shift->tasks()->orderBy('id')->lockForUpdate()->get();
            foreach ($data['tasks'] ?? [] as $task) {
                abort_unless(empty($task['id']) || $tasks->contains(fn ($row) => (int) $row->id === (int) $task['id']), 404);
            }
            $proofs = [];
            $holds = app(CoverageReservationService::class);
            $reservationContext = [...$data, 'site_id' => $prospective->site_id, 'starts_at' => $prospective->starts_at,
                'ends_at' => $prospective->ends_at, 'coverage_roles' => $prospective->coverage_roles ?? []];
            $reservation = $holds->validateToken($data['coverage_reservation_token'] ?? null, $actor, [
                'site_id' => $prospective->site_id, 'coverage_requirement_id' => $data['coverage_rule_id'] ?? null,
                'window_starts_at' => $prospective->starts_at, 'window_ends_at' => $prospective->ends_at]);
            if ($reservation) {
                $reservation = CoverageReservation::query()->whereKey($reservation->id)->lockForUpdate()->firstOrFail();
                // Revalidate the locked row, including actor, token and expiry.
                abort_unless($reservation->status === CoverageReservationService::STATUS_ACTIVE
                    && (int) $reservation->reserved_by_user_id === (int) $actor->id
                    && $reservation->reservation_token === $data['coverage_reservation_token']
                    && (int) $reservation->site_id === (int) $prospective->site_id
                    && $reservation->window_starts_at?->equalTo($prospective->starts_at)
                    && $reservation->window_ends_at?->equalTo($prospective->ends_at)
                    && (empty($data['coverage_rule_id']) || (int) $reservation->coverage_requirement_id === (int) $data['coverage_rule_id'])
                    && $reservation->expires_at?->gt(now()), 409, 'This coverage hold is no longer active.');
            } elseif (array_intersect(array_keys($data), ['user_id', 'starts_at', 'ends_at', 'client_id', 'coverage_roles']) !== []) {
                $reservation = $holds->reserveForCoveragePayload($actor, $reservationContext, 'calendar_update',
                    checkedWrite: function (CoverageReservation $row, array $values) use (&$proofs) { return $this->write($row, $values, $proofs); });
            }
            $before = $this->noticeTuple($shift);
            $previousStartsAt = $shift->starts_at?->copy();
            $values = Arr::except($data, ['tasks', 'coverage_reservation_token', 'coverage_rule_id', 'request_id', 'expected_source']);
            // The installed publication observer is the sole owner of this field.
            $intent = clone $shift;
            $intent->fill($values);
            $dirtyFields = ['client_id', 'site_id', 'service_context_id', 'user_id', 'starts_at', 'ends_at', 'status',
                'shift_type', 'is_sleepover', 'is_on_call', 'is_lone_worker', 'expected_break_minutes', 'coverage_roles', 'location', 'notes'];
            if ($shift->published_at && ! $shift->publish_dirty_at && $intent->isDirty($dirtyFields)) {
                $values['publish_dirty_at'] = now()->startOfSecond();
            }
            $stored = $this->write($shift, $values, $proofs);
            ShiftTaskSupport::clearRemindersForShiftStartChange($stored, $previousStartsAt);
            foreach ($tasks as $task) {
                if ($previousStartsAt && ! $previousStartsAt->equalTo($stored->starts_at)
                    && $task->scheduled_time && $task->reminder_sent_at && ! $task->is_completed) {
                    $task->reminder_sent_at = null;
                }
                $proofs[$task::class.':'.$task->id] = [$task::class, (int) $task->id, self::row($task)];
            }
            $taskIds = $this->tasks($stored, $tasks, $data, $proofs);
            $holds->fulfill($reservation, $stored, checkedWrite: function ($row, $values) use (&$proofs) { return $this->write($row, $values, $proofs); });
            app(ShiftTimelineService::class)->syncSnapshot($stored,
                checkedWrite: function ($row, $values) use (&$proofs) { return $this->write($row, $values, $proofs); });
            // All normal model/audit/supply/timeline observers have now completed.
            $this->verify($proofs);
            abort_unless($stored->tasks()->orderBy('id')->pluck('id')->map(fn ($id) => (int) $id)->all() === $taskIds,
                409, 'The calendar task list changed while saving.');
            $stored = Shift::query()->whereKey($stored->id)->lockForUpdate()->firstOrFail();
            $actor = $this->authority($actor, $origin, $stored, $data);
            $this->editable($stored);
            $this->eligibility($stored, $data);
            $this->verify($proofs);
            if ($before !== $this->noticeTuple($stored) && $stored->user_id) {
                $this->notice($actor, $stored);
            }
            return ['shift' => $stored, 'source' => $source, 'proofs' => $proofs, 'task_ids' => $taskIds];
        });
        // A nested save may exist, but its physical transaction still belongs to
        // the caller. A transport/readback fault after commit is also unknown.
        try {
            if (! $root || ! $this->physicalExit($connection, $pdo)) {
                return ['status' => 202, 'body' => $unknown];
            }
            $stored = $this->readShift($connection, (int) $bound->id);
            if (! $stored || self::row($stored) !== self::row($result['shift'])) {
                return ['status' => 202, 'body' => $unknown];
            }
            $this->verify($result['proofs'], false);
            if ($stored->tasks()->orderBy('id')->pluck('id')->map(fn ($id) => (int) $id)->all() !== $result['task_ids']) {
                return ['status' => 202, 'body' => $unknown];
            }
            $stored->load(['client:id,first_name,last_name', 'staff:id,name', 'tasks']);
            if (! $this->physicalExit($connection, $pdo)) {
                return ['status' => 202, 'body' => $unknown];
            }
            $body = ['ok' => true, 'shift' => $stored];
            if ($identity) {
                $body['calendar_move_result'] = [...$identity, 'outcome' => 'confirmed', 'saved' => $this->saved($stored),
                    'verified_at' => now('UTC')->startOfSecond()->format('Y-m-d\TH:i:s.000\Z')];
            }
            return ['status' => 200, 'body' => $body];
        } catch (\Throwable) {
            return ['status' => 202, 'body' => $unknown];
        }
    }

    protected function readShift(Connection $connection, int $id): ?Shift
    {
        return Shift::on($connection->getName())->find($id);
    }

    private function physicalExit(Connection $connection, PDO $pdo): bool
    {
        return DB::connection() === $connection && $connection->getPdo() === $pdo
            && $connection->transactionLevel() === 0 && ! $pdo->inTransaction();
    }

    private function authority(User $actor, Shift $origin, Shift $target, array $data): User
    {
        $userId = array_key_exists('user_id', $data) ? $data['user_id'] : $target->user_id;
        $users = app(WorkforceMutationGuard::class)->lockParticipants($actor, 'shifts.update',
            [$origin->user_id, $userId], ['rostering.viewAny']);
        $actor = $users->get((int) $actor->id);
        abort_unless($actor->canDo('rostering.viewAny') && ! $actor->hasRole('client', 'next_of_kin')
            && ! in_array($actor->role, ['client', 'next_of_kin'], true), 403);
        // Ownership belongs to the record that was authorised at command entry.
        abort_unless($actor->canDo('shifts.manageAny') || (int) $origin->user_id === (int) $actor->id, 403);
        return CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($actor, $origin, $target, $data, $userId): User {
            $sites = app(UserSiteAccessService::class);
            $allowed = $sites->accessibleSiteIds($actor, ['reports.viewAny'], $reads);
            $targetClientId = array_key_exists('client_id', $data) ? (int) $data['client_id'] : (int) $target->client_id;
            foreach ([[$origin, (int) $origin->client_id, $origin->user_id], [$target, $targetClientId, $userId]] as [$row, $clientId, $workerId]) {
                $client = $reads->query(Client::query()->whereKey($clientId))->first();
                $rowSite = $row === $target && array_key_exists('client_id', $data) ? null : $row->site_id;
                abort_unless($client && (int) $client->site_id > 0 && (! $rowSite || (int) $rowSite === (int) $client->site_id), 404);
                abort_unless(in_array((int) $client->site_id, $allowed, true), 403, UserSiteAccessService::DEFAULT_MESSAGE);
                if ($workerId) {
                    abort_unless($reads->query($sites->applyFleetRecipientEligibility(User::query()->whereKey((int) $workerId), (int) $client->site_id))->exists(),
                        403, 'This staff member is not currently assigned to the shift site.');
                    abort_unless($reads->query(app(HrCurrentStaffService::class)->currentUsersQuery()->whereKey((int) $workerId))->exists(), 403);
                }
                if ($row->shift_series_id) {
                    $series = $reads->query(ShiftSeries::query()->whereKey((int) $row->shift_series_id))->first();
                    $seriesClient = $series?->client_id ? $reads->query(Client::query()->whereKey((int) $series->client_id))->first() : null;
                    $seriesSite = $series?->site_id ?: $seriesClient?->site_id;
                    abort_unless($series && $seriesSite && in_array((int) $seriesSite, $allowed, true)
                        && (! $series->client_id || ($seriesClient && (! $series->site_id || (int) $series->site_id === (int) $seriesClient->site_id))), 404);
                }
                $row->setRelation('client', $client);
                $row->setRelation('staff', $workerId ? $reads->query(User::query()->whereKey((int) $workerId))->first() : null);
            }
            if (! empty($data['coverage_rule_id'])) {
                abort_unless($reads->query(SiteCoverageRequirement::query()->whereKey((int) $data['coverage_rule_id'])
                    ->where('site_id', $target->client->site_id))->exists(), 422, 'The linked coverage rule does not match this Client Site.');
            }
            return $actor;
        });
    }

    private function intent(Shift $shift, array $data): array
    {
        if (array_key_exists('client_id', $data) || ! $shift->site_id) {
            $client = CurrentAuthorizationReads::within(fn ($reads) => $reads->query(Client::query()->whereKey($data['client_id'] ?? $shift->client_id))->firstOrFail());
            $data['site_id'] = $client->site_id;
            if (array_key_exists('client_id', $data) && ! array_key_exists('service_context_id', $data)) {
                $data['service_context_id'] = $client->service_context_id;
            }
        }
        $hasStart = array_key_exists('starts_at', $data);
        $hasEnd = array_key_exists('ends_at', $data);
        abort_unless($hasStart === $hasEnd, 422, 'Both starts_at and ends_at are required when updating time.');
        if ($hasStart) {
            $zone = (string) (config('app.worker_timezone') ?: config('app.timezone') ?: 'UTC');
            $data['starts_at'] = Carbon::parse($data['starts_at'], $zone)->utc()->startOfSecond();
            $data['ends_at'] = Carbon::parse($data['ends_at'], $zone)->utc()->startOfSecond();
            abort_unless($data['ends_at']->gt($data['starts_at']), 422, 'ends_at must be after starts_at.');
        }
        $userId = array_key_exists('user_id', $data) ? $data['user_id'] : $shift->user_id;
        if (array_key_exists('status', $data)) {
            $data['status'] = app(ShiftStateGuardService::class)->normalizePlanningStatus($data['status'], ! empty($userId));
        } elseif (array_key_exists('user_id', $data) && ! $userId && $shift->status === 'scheduled') {
            $data['status'] = 'draft';
        } elseif (array_key_exists('user_id', $data) && $userId && $shift->status === 'draft') {
            $data['status'] = 'scheduled';
        }
        return $data;
    }

    private function editable(Shift $shift): void
    {
        $approved = CurrentAuthorizationReads::within(fn ($reads) => $reads->query($shift->approvedTimesheets()->getQuery())->get());
        if ($approved->isNotEmpty()) {
            throw ValidationException::withMessages(['shift' => 'This shift has an approved timesheet and can no longer be edited from planning.']);
        }
        $shift->setRelation('timesheets', $approved);
        if (! in_array($shift->status, app(ShiftStateGuardService::class)->planningStatuses(), true)) {
            throw ValidationException::withMessages(['status' => 'This shift is already in a live or locked lifecycle state. Use the dedicated lifecycle actions instead of a planning edit.']);
        }
    }

    private function eligibility(Shift $shift, array $data): void
    {
        $conflicts = CurrentAuthorizationReads::within(fn ($reads) => $reads->query(Shift::query()->where('user_id', $shift->user_id)
            ->whereKeyNot($shift->id)->whereNotIn('status', ['cancelled', 'completed'])
            ->where('starts_at', '<', $shift->ends_at)->where('ends_at', '>', $shift->starts_at))->get());
        abort_if($shift->user_id && $conflicts->isNotEmpty(), 422, 'This staff member already has another shift during that time.');
        if ($shift->user_id && array_intersect(array_keys($data), ['user_id', 'starts_at', 'ends_at', 'required_licence_class', 'required_licence_endorsements']) !== []) {
            // Keep the Calendar's existing warning policy. No acknowledgement,
            // reason or override grant is introduced for ordinary warnings.
            $result = app(ShiftStaffEligibilityService::class)->evaluate($shift, $shift->staff, currentQualifications: true);
            abort_if($result->hasBlocks(), 422, 'The selected staff member is not eligible for this shift. Review the current eligibility checks.');
        }
    }

    private function tasks(Shift $shift, $existing, array $data, array &$proofs): array
    {
        $expectedIds = $existing->modelKeys();
        if (array_key_exists('tasks', $data)) {
            $incoming = ShiftTaskSupport::normalizeInputs($data['tasks']);
            $manual = $existing->filter(fn ($task) => ! $task->creation_key && ! $task->source_handover_id);
            $keep = $incoming->pluck('id')->filter()->map(fn ($id) => (int) $id)->all();
            $deleted = $manual->reject(fn ($task) => in_array((int) $task->id, $keep, true));
            abort_unless($shift->tasks()->whereIn('id', $deleted->modelKeys())->delete() === $deleted->count(), 409, 'The calendar task list could not be saved.');
            foreach ($deleted as $task) {
                unset($proofs[$task::class.':'.$task->id]);
                $expectedIds = array_values(array_diff($expectedIds, [$task->id]));
            }
            foreach ($incoming as $task) {
                $row = $task['id'] ? $existing->firstWhere('id', (int) $task['id']) : new ShiftTask;
                if ($row->creation_key || $row->source_handover_id) {
                    continue;
                }
                $values = ['shift_id' => $shift->id, 'label' => $task['label'], 'scheduled_time' => $task['scheduled_time'], 'sort_order' => $task['sort_order']];
                if (ShiftTaskSupport::normalizeTime($row->scheduled_time) !== $task['scheduled_time']) {
                    $values['reminder_sent_at'] = null;
                }
                $isNew = ! $row->exists;
                if ($isNew) {
                    $row->forceFill(['is_completed' => false, 'completed_at' => null, 'completed_by' => null, 'version' => 0,
                        'task_scope' => null, 'client_id' => null, 'created_by' => null, 'creation_key' => null, 'creation_hash' => null,
                        'scheduled_at' => null, 'steps' => null, 'source_handover_id' => null, 'source_item_key' => null, 'source_task_id' => null,
                        'help_requested_to' => null, 'help_reason' => null, 'help_status' => null, 'help_requested_at' => null, 'help_responded_at' => null]);
                }
                $saved = $this->write($row, $values, $proofs);
                if ($isNew) {
                    $expectedIds[] = $saved->id;
                }
            }
        }
        $expectedIds = array_map('intval', $expectedIds);
        sort($expectedIds);
        return $expectedIds;
    }

    private function write(Model $row, array $values, array &$proofs): Model
    {
        $expected = clone $row;
        $expected->forceFill($values);
        if ($expected instanceof ShiftTask && $row->exists && $expected->isDirty(['is_completed', 'label', 'scheduled_time', 'scheduled_at', 'steps'])) {
            $expected->version = ((int) $row->version) + 1;
        }
        $intent = self::row($expected);
        $row->forceFill($values);
        abort_unless($row->save() === true && $row->exists && $row->getKey(), 409, 'The calendar change could not be saved.');
        $stored = $row->newQuery()->whereKey($row->getKey())->lockForUpdate()->firstOrFail();
        $actual = self::row($stored);
        abort_unless(array_intersect_key($actual, $intent) === $intent, 409, 'The saved calendar record does not match the intended change.');
        $proofs[$stored::class.':'.$stored->id] = [$stored::class, (int) $stored->id, $actual];
        return $stored;
    }

    private function verify(array $proofs, bool $locked = true): void
    {
        foreach ($proofs as [$class, $id, $expected]) {
            $query = $class::query()->whereKey($id);
            if ($locked) {
                $query->lockForUpdate();
            }
            $stored = $query->first();
            abort_unless($stored && self::row($stored) === $expected, 409, 'A calendar record changed while saving.');
        }
    }

    public static function source(Shift $shift): string
    {
        return hash('sha256', json_encode(Arr::except(self::row($shift), ['incidents_count', 'tasks_total', 'tasks_completed']), JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES));
    }

    private static function row(Model $row): array
    {
        $values = [];
        foreach (array_diff(array_keys($row->getAttributes()), ['created_at', 'updated_at']) as $key) {
            $value = $row->getAttribute($key);
            if ($value instanceof \Carbon\CarbonInterface) {
                $value = $value->copy()->utc()->format('Y-m-d H:i:s');
            } elseif ($key === 'id' || str_ends_with($key, '_id') || in_array($key, ['sort_order', 'version'], true)) {
                $value = $value === null ? null : (int) $value;
            } elseif ($key === 'scheduled_time') {
                $value = ShiftTaskSupport::normalizeTime($value);
            }
            $values[$key] = self::canonical($value);
        }
        ksort($values);
        return $values;
    }

    private static function canonical(mixed $value): mixed
    {
        if (is_array($value)) {
            if (! array_is_list($value)) {
                ksort($value);
            }
            return array_map(self::canonical(...), $value);
        }
        return $value;
    }

    private function saved(Shift $shift): array
    {
        return ['id' => (int) $shift->id, 'client_id' => (int) $shift->client_id, 'site_id' => (int) $shift->site_id,
            'user_id' => $shift->user_id === null ? null : (int) $shift->user_id,
            'service_context_id' => $shift->service_context_id === null ? null : (int) $shift->service_context_id,
            'status' => $shift->status, 'starts_at' => $shift->starts_at?->copy()->utc()->format('Y-m-d\TH:i:s.000\Z'),
            'ends_at' => $shift->ends_at?->copy()->utc()->format('Y-m-d\TH:i:s.000\Z'), 'shift_source' => self::source($shift)];
    }

    private function noticeTuple(Shift $shift): array
    {
        return Arr::only(self::row($shift), ['user_id', 'starts_at', 'ends_at', 'location', 'service_context_id', 'status']);
    }

    private function notice(User $actor, Shift $shift): void
    {
        DB::afterCommit(function () use ($actor, $shift): void {
            try {
                app(NotificationService::class)->notifyCrud($actor, 'updated', 'shift', $shift, $shift->client, [
                    'title' => 'Shift updated', 'body' => $shift->client ? 'Client: '.$shift->client->first_name.' '.$shift->client->last_name : null,
                    'url' => url('/shifts/'.$shift->id), 'target_user_ids' => [(int) $shift->user_id]]);
            } catch (\Throwable $error) {
                try {
                    Log::warning('Calendar Shift notification failed after commit.', ['shift_id' => $shift->id, 'exception' => $error::class]);
                } catch (\Throwable) {
                    // Notification/log transport cannot turn a committed save into a failure.
                }
            }
        });
    }
}
