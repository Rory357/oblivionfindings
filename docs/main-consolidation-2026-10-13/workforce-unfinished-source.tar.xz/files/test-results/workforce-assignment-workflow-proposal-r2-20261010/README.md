# Inactive assignment confirmation proposal R2

Nothing is applied to DELIVERY. No PHP parser, formatter, framework inventory, native scenarios, database, process, build or browser action has run. The original draft and final wire contract remain intact; original-draft-pins.json seals the complete draft.

The five existing paths change only candidate transport, opt-in assign/unassign transport, one requester flash entry, optional lifecycle evidence, and optional checked history/replacement callbacks. The seven helpers and one acceptance class are new. Existing callers retain their return signatures and default paths. Show/eMAR and unrelated methods remain exact.

The candidate response now pairs shift_display with shift_source inside the existing manual command authority prefix: application mutex, canonical Client/Shift, current actor/action/Profile/Site. Times and identities come from the same locked Shift; Client names come from its current locked canonical Client; Site and assigned-owner names use current NOWAIT scalar reads. Only these already-authorised source labels are projected. No private HR fields or related models are returned. A missing historical owner produces a null label. Labels are informational; the digest binds Shift identity, time, assignment/status and source fields, not mutable name text.

The UI must fetch on dialog open or explicit refresh, replace display and digest together, and submit that displayed digest. Confirm cannot silently adopt a later source. Changed canonical provenance is tested through a fresh physical read. The installed lifecycle identity-hint reader can fail closed on an old nested RR provenance snapshot; this proposal does not replace its default lock prefix or claim all nested advisory reads succeed.

Modern commands enclose lifecycle, history, replacement/position, override and hold suffixes in one transaction and check intended stored values before return. Positive receipts require the same physical root/PDO after commit plus persisted source reread. Nested/raw-PDO, ambiguous commit, after-commit and presentation errors produce no positive result. Deliberate prewrite refusals require rollback plus a current source/authority proof. UUIDs correlate an explicit request; no durable replay or automatic retry is added.

All assessed warnings need acknowledgement. Only actual overrideable warnings require the installed override permission and reason. Unknown candidates are nonselectable. Candidates remain advisory; assignment rechecks current workload/eligibility. No grants, policies, schemas, qualifications, default source fingerprints or eMAR mechanics change.

Return context accepts bounded installed relative routes and finite flat numeric Site arrays. It preserves navigation only and confers no destination authority. The separate editor flash remains unchanged.

The new source-derived cases cover root tuple/history and side-effect proof, warnings and denials, faults and whole rollback, independent-PDO source/grant drift, display/digest coherence, released holds, uncertain/nested outcomes, correlation/privacy and navigation. They are not a framework inventory or semantic acceptance. Actual syntax/formatting, framework enumeration, bounded native selection with existing preservation cases, and frontend/browser acceptance remain future work.
