<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\Shift;
use App\Models\Site;
use App\Models\User;
use App\Services\CurrentAuthorizationReads;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;

/** Fixed semantic projection, independent of raw SQL column order and scalar driver types. */
final class ShiftAssignmentSource
{
    public static function describe(Shift $shift): array
    {
        $fields = array_merge(['id'], $shift->getFillable(), ['version', 'roster_period_id', 'published_at', 'publish_dirty_at']);

        return ['shift_id' => (int) $shift->id,
            'revision' => hash('sha256', json_encode(self::values($shift, $fields), JSON_THROW_ON_ERROR))];
    }

    /** Called only after the current command authority prefix, while this Shift/Client remain locked. */
    public static function display(Shift $shift): array
    {
        return CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($shift): array {
            // These are only the already-authorised canonical Shift's Site and assigned owner.
            // NOWAIT current scalar reads cannot wait on an inverse User/Site writer chain.
            $site = $reads->query(Site::query())->whereKey($shift->site_id)->first(['id', 'name']);
            $staff = $shift->user_id
                ? $reads->query(User::query())->whereKey($shift->user_id)->first(['id', 'name'])
                : null;
            $client = $shift->relationLoaded('client') ? $shift->getRelation('client') : null;
            if (! $client || (int) $client->id !== (int) $shift->client_id || (int) $client->site_id !== (int) $shift->site_id
                || ! $site || (int) $site->id !== (int) $shift->site_id) {
                throw new \LogicException('The assignment display has no canonical source.');
            }

            return ['id' => (int) $shift->id,
                'starts_at' => $shift->starts_at?->copy()->utc()->toIso8601String(),
                'ends_at' => $shift->ends_at?->copy()->utc()->toIso8601String(),
                'client' => trim($client->first_name.' '.$client->last_name) ?: null,
                'site' => $site->name ?: null, 'staff' => $staff?->name ?: null,
                'isOpen' => $shift->user_id === null];
        });
    }

    public static function values(Model $model, array $fields): array
    {
        $values = [];
        foreach ($fields as $field) {
            $value = $model->getAttribute($field);
            if ($value instanceof DateTimeInterface) {
                $value = \Carbon\CarbonImmutable::instance($value)->utc()->format('Y-m-d\TH:i:s.u\Z');
            } elseif ($value !== null && ($field === 'version' || $field === 'id' || str_ends_with($field, '_id')
                || in_array($field, ['source_id', 'created_by', 'approved_by', 'claimed_by', 'requested_by', 'overridden_by', 'started_by', 'completed_by', 'handover_waived_by'], true))) {
                $value = (int) $value;
            }
            $values[$field] = self::json($value);
        }

        return $values;
    }

    private static function json(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value, SORT_STRING);
        }

        return array_map(self::json(...), $value);
    }
}
