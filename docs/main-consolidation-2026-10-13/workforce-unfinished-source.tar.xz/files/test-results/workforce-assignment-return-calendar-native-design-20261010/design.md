# Inactive combined verification design

This is a selector/design note, not a runnable harness or approval. The reviewed Assignment R3 tools remain the baseline: all original ten files, 117-pin map, input/reference records, forward/inverse patches and independent review remain unchanged. Calendar's active168 profile and runtime namespace are not edited. No final source map, profile hash, target HEAD, namespace, database base or actual count is generated here.

The next source transition is conditional on Calendar runtime acceptance and exact owned cleanup. Parent records R3 fourteen-path application first, then the independently reviewed Return three-path composition. The two steps affect fifteen unique product paths. CalendarController and CalendarReadIntegrityTest remain independently owned Calendar inputs. Their final formatter-approved after hashes are **unresolved** in selector-design.json; existing pre-format hashes must not be guessed or used as final approval. Parent must also agree the next module scope/root/HEAD before final tools are authored.

The proposed finite selectors are copied from the reviewed R3 profile and current Calendar/Leave selectors, with Return's ten declared methods added. Thirteen files are included:

| File group | Selection |
| --- | --- |
| WorkforceShiftAssignmentCommandIntegrityTest | All 21 declared methods and their provider rows |
| ShiftControllerTest | The five reviewed direct assignment, governed warning and local Sunday/Monday methods |
| ShiftLifecycleServiceTest | The four reviewed assignment/override/unassignment history methods |
| WorkforceShiftSaveCommandIntegrityTest | The five reviewed root-save, nested, hold-veto, replacement rollback and requester-denial methods |
| WorkforceConflictQueueShiftReturnContextTest | All four declared methods/providers |
| WorkforceShiftShowActionCapabilityTest | All five declared methods/providers |
| ShiftMedicationVisibilityTest | All six declared methods |
| MedicationJourneyTest | Its declared known-local-return method/providers |
| WorkforceCalendarReadIntegrityTest | All eighteen currently declared methods/providers; confirm metadata preservation against HR's final formatter proof |
| WorkforceRosteringReadPermissionIntegrityTest | All fourteen declared methods/providers |
| RespiteReadinessTest | Only linked-respite Shift/Calendar preservation |
| WorkforceCalendarShiftReturnContextTest | All ten proposed methods/providers |
| WorkforceLeaveReviewReceiptIntegrityTest | All twelve accepted declared methods/providers, freshly rerun |

selector-design.json retains exact class, file, method and raw-method declarations. Its 106 method slots are **not a test case count**. All actual counts, class counts, inventory hash and approvals remain null/false. A later framework-only listing must resolve every selected provider row, reject missing/extra/duplicate identities, retain the optional Pest P namespace and reviewed raw-to-TestDox mapping, and bind exact JUnit identities. The original historical Return60 mappings remain completeness references, not current acceptance.

Future source-map construction uses the existing117 prospective map without removing its inputs, overlays only the reviewed Return two existing afters and new test, and adds the final Calendar pair plus the required Calendar/roster/Respite and LeaveReceipt regression dependencies from the reviewed current source references. It must preserve the applied Leave service/controller/receipt and approved fixture overlays. R3's Middleware requester entry is additive; existing Leave flash must remain byte-exact. The Calendar168 profile has five Assignment-owned dependencies that change, so its prior result and LeaveR4 result become historical after application. Keep each immutable rather than presenting them as current proof. Main integration separately retains its newer eMAR Show hunks and requires current-main privacy tests; this DELIVERY design cannot authorise whole-controller copying to main.

No candidate migration is introduced by Assignment, Return or Calendar. A fresh isolated native schema still needs the established schema import **and normal pending migrations** through Tests\TestCase::runPendingMigrationsAfterSchemaLoad. The reviewed dump lacks workforce_eligibility_rechecks and workforce_eligibility_observations; the 210000 refresh-table and 210100 progress migrations are known prerequisites. Preserve the ordinary pending migration call, rather than running only those two or bypassing observers. The parser/list helpers must continue without application/kernel/database/scenario bootstrap. No shared database, seed, vendor copy or auth/grant change is required.

After final inputs and parent scope are settled, author one fresh reviewed tool namespace from the exact R3 tools. Change only the necessary namespace/base, final source/dependency pins, selectors, reflection inputs and future inventory fields. Preserve the retained Process identity before CIM, exact birth/executable/command and descendant checks, no-DROP-on-unproven-absence boundary, zero connections before owned schema cleanup, protected finally closure, shared native gate and zero-peer checks. Admission remains 4,096 MiB free/CPU85, PHP1,024 MiB and deadline1,800 seconds. Original tools and accepted/failed outputs must not be overwritten.

Parent then performs actual syntax/import/format checks, a fresh no-scenario framework listing, and guarded native execution only after reviewing the complete inventory and explicit approval. Acceptance needs exact JUnit cases, no errors/failures/skips, both actual exits zero and exact source/protected/owned database closure. Optional missing-.env warnings stay visible. Frontend/TypeScript/build/browser checks are separately parent-owned; source-derived cases, historical passes or this note establish none of those outcomes.
