# Parent-only exact abandoned-schema cleanup. No application/bootstrap/list/native invocation.
param([switch]$Execute,[Parameter(Mandatory=$true)][string]$ExpectedManifestSha256,[Parameter(Mandatory=$true)][string]$IndependentReviewSha256,[Parameter(Mandatory=$true)][ValidatePattern('^r[1-9][0-9]{0,2}$')][string]$AttemptName)
$ErrorActionPreference='Stop'
$packet=$PSScriptRoot;$root='C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings'
$php='C:/Users/steph/.config/herd/bin/php84/php.exe';$ps7='C:/Program Files/PowerShell/7/pwsh.exe'
if(!$Execute -or $PSVersionTable.PSEdition -cne 'Core' -or [IO.Path]::GetFullPath((Get-Process -Id $PID).Path) -ine [IO.Path]::GetFullPath($ps7)){throw 'Explicit parent Execute and exact PowerShell7 required.'}
$manifestPath=Join-Path $packet 'manifest.json'
if($ExpectedManifestSha256 -notmatch '^[a-f0-9]{64}$' -or $IndependentReviewSha256 -notmatch '^[a-f0-9]{64}$' -or (Get-FileHash -LiteralPath $manifestPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ExpectedManifestSha256){throw 'Exact reviewed manifest required.'}
$manifest=Get-Content -LiteralPath $manifestPath -Raw|ConvertFrom-Json
foreach($name in @('guards.ps1','profile.json')){if((Get-FileHash -LiteralPath (Join-Path $packet $name) -Algorithm SHA256).Hash.ToLowerInvariant() -cne $manifest.files.PSObject.Properties[$name].Value){throw 'Reviewed guard/profile changed.'}}
$profile=Get-Content -LiteralPath (Join-Path $packet 'profile.json') -Raw|ConvertFrom-Json
$reviewPath=Join-Path $packet 'independent-lifecycle-review.json'
if((Get-FileHash -LiteralPath $reviewPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $IndependentReviewSha256){throw 'Exact independent review required.'}
$review=Get-Content -LiteralPath $reviewPath -Raw|ConvertFrom-Json
if($review.status -cne 'CLEAR_SOURCE_ONLY' -or $review.manifest_sha256 -cne $ExpectedManifestSha256 -or $manifest.status -cne 'INACTIVE_SOURCE_ONLY_PARENT_REVIEW_REQUIRED'){throw 'Independent source-only clearance must bind this exact proposal.'}
. (Join-Path $packet 'guards.ps1')
if($profile.database -cne 'oblivion_workforce_dlvcal_r2_20261010_81368' -or $profile.owner_pid -ne 81368 -or $profile.child_pid -ne 286956 -or [IO.Path]::GetFullPath($profile.root) -ine [IO.Path]::GetFullPath($root) -or $profile.execution_authorized -ne $false -or $profile.native_acceptance -ne $false){throw 'Exact inactive target/owner lineage required.'}
No-Reparse $packet 'C:/Users/steph/Herd/oblivionfindings'
Assert-Inputs
$attempt=Join-Path $packet ('attempts/'+$AttemptName);No-Reparse $attempt $packet
if(Test-Path -LiteralPath $attempt){throw 'Preserve prior attempt; no overwrite/retry within one invocation.'}
[void][IO.Directory]::CreateDirectory($attempt)
$names=@('DB_CONNECTION','DB_HOST','DB_PORT','DB_DATABASE','DB_USERNAME','DB_PASSWORD','DB_URL','DB_SOCKET')
$prior=[ordered]@{};foreach($name in $names){$prior[$name]=[Environment]::GetEnvironmentVariable($name,'Process')}
$held=$false;$issue=$null;$exitCode=$null;$proof=$null;$protected=@();$script:samples=@();$closure=$false;$launched=$false;$started=[DateTimeOffset]::UtcNow
$mutex=[Threading.Mutex]::new($false,'Local\OblivionWorkforceMainIntegrationNativeGate')
try{
    try{$held=$mutex.WaitOne(0)}catch [Threading.AbandonedMutexException]{$held=$true}
    if(!$held){throw 'Shared native/import gate busy; no CIM/credentials/PHP/SQL.'}
    Assert-Inputs
    $first=Capture-Absence 'admission1' @();$protected=@($first.protected_processes)
    Write-NewJson (Join-Path $attempt 'admission1.json') $first
    Start-Sleep -Milliseconds 500
    $second=Capture-Absence 'admission2' $protected
    Write-NewJson (Join-Path $attempt 'admission2.json') $second
    # Read only the original isolated XML transport; do not load/copy any private environment.
    [xml]$xml=Get-Content -LiteralPath (Join-Path $root $profile.original_xml_path) -Raw
    foreach($name in $names){$entries=@($xml.phpunit.php.env|Where-Object{$_.name -ceq $name});if($entries.Count -gt 1){throw 'Ambiguous original isolated transport.'};[Environment]::SetEnvironmentVariable($name,$(if($entries.Count -eq 1){[string]$entries[0].value}else{$null}),'Process')}
    if($env:DB_CONNECTION -cne 'mysql' -or $env:DB_HOST -cne '127.0.0.1' -or $env:DB_PORT -cne '3306' -or $env:DB_DATABASE -cne 'oblivion_workforce_dlvcal_r2_20261010' -or [string]::IsNullOrWhiteSpace($env:DB_USERNAME) -or ![string]::IsNullOrEmpty($env:DB_URL) -or ![string]::IsNullOrEmpty($env:DB_SOCKET)){throw 'Exact local original transport required.'}
    Assert-Inputs
    $absence=Capture-Absence 'immediately-before-pdo' $protected
    Write-NewJson (Join-Path $attempt 'process-absence.json') $absence
    $approval=[ordered]@{approved_exact_schema_only=$true;database=$profile.database;owner_pid=81368;child_pid=286956;manifest_sha256=$ExpectedManifestSha256;independent_review_sha256=$IndependentReviewSha256;process_absence_sha256=(Sha (Join-Path $attempt 'process-absence.json'));cleanup_sha256=(Sha (Join-Path $packet 'cleanup-schema.php'));parent_wrapper_pid=$PID;approved_at_utc=[DateTimeOffset]::UtcNow.ToString('o');original_owner_exit=$null;historical_complete_descendant_closure=$null;native_acceptance=$false}
    Write-NewJson (Join-Path $attempt 'exact-parent-execution.json') $approval
    # Synchronous pinned standalone PDO helper; it imports no code and launches no descendants.
    $launched=$true
    & $php -d memory_limit=256M -d max_execution_time=30 -d auto_prepend_file= -d auto_append_file= -d opcache.enable_cli=0 (Join-Path $packet 'cleanup-schema.php') $attempt $ExpectedManifestSha256 $IndependentReviewSha256 1> (Join-Path $attempt 'cleanup.stdout.log') 2> (Join-Path $attempt 'cleanup.stderr.log')
    $exitCode=$LASTEXITCODE
    if($exitCode -ne 0){throw 'Exact-schema PDO helper failed; preserve raw output; no retry.'}
    $proofPath=Join-Path $attempt 'schema-cleanup.json'
    $proof=Get-Content -LiteralPath $proofPath -Raw|ConvertFrom-Json
    if($proof.database -cne $profile.database -or $proof.connections_before -ne 0 -or $proof.connections_after -ne 0 -or $proof.schema_count_after -ne 0 -or $proof.process_visibility_proven -ne $true -or $proof.manifest_sha256 -cne $ExpectedManifestSha256 -or $proof.independent_review_sha256 -cne $IndependentReviewSha256 -or $proof.process_absence_sha256 -cne $approval.process_absence_sha256 -or $proof.native_acceptance -ne $false){throw 'Exact zero-connection/schema readback not proven.'}
}catch{$issue=$_.Exception.Message}
finally{
    try{
        Assert-Inputs
        if($held -and $protected.Count -gt 0){
            $after=Capture-Absence 'final-protected-source-closure' $protected
            if($proof -and @((Get-CimInstance Win32_Process -OperationTimeoutSec 10)|Where-Object{$_.ProcessId -eq $proof.cleanup_pid -or $_.ParentProcessId -eq $proof.cleanup_pid}).Count -ne 0){throw 'Cleanup CLI PID/reused PID or linked process still present.'}
            Write-NewJson (Join-Path $attempt 'final-process-absence.json') $after
            $closure=$true
        }
    }catch{$issue=([string]$issue+'; final guard: '+$_.Exception.Message).Trim('; ')}
    foreach($name in $names){[Environment]::SetEnvironmentVariable($name,$prior[$name],'Process')}
    if($held){$mutex.ReleaseMutex()};$mutex.Dispose()
}
$ok=$null -eq $issue -and $exitCode -eq 0 -and $closure
$result=[ordered]@{status=$(if($ok){'EXACT_AUTHORIZED_ABANDONED_SCHEMA_CLOSED_VERIFIED'}else{'HELD_OR_FAILED_NO_CLOSURE_ACCEPTANCE'});database=$profile.database;owner_pid=81368;child_pid=286956;started_at_utc=$started.ToString('o');finished_at_utc=[DateTimeOffset]::UtcNow.ToString('o');manifest_sha256=$ExpectedManifestSha256;independent_review_sha256=$IndependentReviewSha256;cleanup_launched=$launched;cleanup_exit=$exitCode;cleanup_verified=$ok;current_source_and_history_verified=$closure;protected_closure_verified=$closure;resource_samples=$script:samples;issue=$issue;db_environment_restored=$true;original_owner_exit=$null;historical_complete_descendant_closure=$null;original_rejection_preserved=$true;native_acceptance=$false;artifact_sha256=[ordered]@{}}
# Persist the outcome before optional hashes so no output lock masks the failure.
Write-NewJson (Join-Path $attempt 'result.json') $result
foreach($file in Get-ChildItem -LiteralPath $attempt -File){if($file.Name -cne 'result.json'){try{$result.artifact_sha256[$file.Name]=Sha $file.FullName}catch{$result.status='HELD_OR_FAILED_NO_CLOSURE_ACCEPTANCE';$result.cleanup_verified=$false;$result.issue=([string]$result.issue+'; output hash unavailable: '+$file.Name).Trim('; ');$ok=$false}}}
$result|ConvertTo-Json -Depth 40|Set-Content -LiteralPath (Join-Path $attempt 'result.json') -Encoding utf8
$result|ConvertTo-Json -Depth 6
exit $(if($ok){0}else{1})
