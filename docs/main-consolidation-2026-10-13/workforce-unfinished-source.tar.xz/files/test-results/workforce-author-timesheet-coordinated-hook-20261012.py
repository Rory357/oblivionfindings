from pathlib import Path
import hashlib, json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-access-recovery-guidance-proposal-r2-20261012'
FOUNDATION = ROOT / 'test-results/workforce-timesheet-write-coordination-foundation-proposal-r3-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-coordinated-command-hook-proposal-20261012'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def emit(name, raw):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), name
    p.write_bytes(raw)
def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)

assert not OUT.exists()
assert sha((BASE / 'manifest.json').read_bytes()) == 'b39d5f33c7f9603fb81d3abc8292909f3c14fc044ac04f1a4f9cc2c83d77ff3a'
assert sha((FOUNDATION / 'manifest.json').read_bytes()) == '50a20481e9fb440d88fc720c09420f3ab1cfc22ac7eff7f1b99309a5135a0ac8'
base = json.loads((BASE / 'manifest.json').read_bytes())
foundation = json.loads((FOUNDATION / 'manifest.json').read_bytes())
for packet, manifest in [(BASE, base), (FOUNDATION, foundation)]:
    for name, digest in manifest['files'].items(): assert sha((packet / name).read_bytes()) == digest, name
pins = dict(base['dependencies'])
pins.update(foundation['source_pins'])
for name, digest in pins.items(): assert sha((ROOT / name).read_bytes()) == digest, name
for packet in [BASE, FOUNDATION]:
    for name in ['manifest.json', 'source-proof.json']:
        p = packet / name; pins[p.relative_to(ROOT).as_posix()] = sha(p.read_bytes())
for name, digest in {
    'test-results/workforce-timesheet-access-recovery-guidance-independent-review-r2-20261012/review.json': '5b115d1cf3829279aafdaed624be25836d0c9d93ec82bc05c81ade1fde7c51a4',
    'test-results/workforce-timesheet-write-coordination-foundation-r3-independent-review-20261012/review.json': 'a1c07850096f2fadc79bf9138b5b1965927048dc54869acde2da23b999a16b76',
}.items():
    assert sha((ROOT / name).read_bytes()) == digest
    assert json.loads((ROOT / name).read_bytes())['status'] == 'CLEAR_SOURCE_ONLY'
    pins[name] = digest

hook_name = 'resources/js/components/timesheets/use-timesheet-command.ts'
test_name = 'resources/js/components/timesheets/use-timesheet-command.test.tsx'
hook = (BASE / 'proposed' / hook_name).read_bytes().decode()
hook = replace(hook, "import { useEffect, useLayoutEffect, useRef, useState } from 'react';",
'''import { useInsertionEffect, useLayoutEffect, useRef, useState } from 'react';
import type { TimesheetWriteLease, TimesheetWriteScope } from './timesheet-write-scope';''')
hook = replace(hook, 'export function useTimesheetCommand(context: string) {', '''/** Omit only for existing independent legacy callers. Coordinated owning pages
 * must pass the one stable page scope explicitly; {scope:null} denies dispatch.
 * Scope lifetime and all other writers/reads remain owning-page obligations. */
export function useTimesheetCommand(context: string, coordination?: {
    scope: TimesheetWriteScope | null;
}) {''')
start = hook.index('    const identity = useRef(context),')
end = hook.index('    const submit = async (', start)
hook = hook[:start] + '''    const identity = useRef(context), generation = useRef(0);
    const currentCoordination = useRef(coordination), contextChanged = useRef(false);
    type LocalLease = { scope: TimesheetWriteScope; token: TimesheetWriteLease;
        invoked: boolean; retiredNoSend: boolean };
    const activeLease = useRef<LocalLease | null>(null);
    // Publish only a committed source/coordination frame before child layouts.
    // No subscriber or React state updates occur during insertion.
    useInsertionEffect(() => {
        const previous = currentCoordination.current;
        if (identity.current !== context || previous?.scope !== coordination?.scope ||
            (previous === undefined) !== (coordination === undefined)) {
            identity.current = context;
            generation.current += 1;
            contextChanged.current = true;
        }
        currentCoordination.current = coordination;
    }, [context, coordination]);
    useLayoutEffect(() => {
        if (!contextChanged.current) return;
        contextChanged.current = false;
        if (attempted.current) {
            held.current = true;
            const owner = activeLease.current;
            if (owner) owner.scope.holdUnknown(owner.token);
            setOutcome({ status: 'unknown', message:
                'The record or signed-in user has changed. Check the original record before another action.' });
        }
    }, [context, coordination]);
    useLayoutEffect(() => {
        mounted.current = true;
        return () => {
            mounted.current = false;
            const owner = activeLease.current;
            if (!owner) return;
            // Commit removal prevents this hook's pending preparation dispatch.
            // An already invoked request is never described as not sent.
            if (!owner.invoked) {
                owner.retiredNoSend = owner.scope.completeNoSend(owner.token, 'preparation_exit');
                if (owner.retiredNoSend) activeLease.current = null;
                else owner.scope.holdUnknown(owner.token);
            } else owner.scope.holdUnknown(owner.token);
        };
    }, []);
''' + hook[end:]
hook = replace(hook, '''        if (!mounted.current || busy.current || held.current) return;
        busy.current = true;''', '''        if (!mounted.current || busy.current || held.current) return;
        const requestedCoordination = currentCoordination.current;
        let lease: LocalLease | null = null;
        if (requestedCoordination !== undefined) {
            const scope = requestedCoordination.scope;
            const token = scope?.tryPrepare(expected.actorId) ?? null;
            if (!scope || !token) {
                setOutcome({ status: 'rejected', message:
                    'Saving is unavailable in this view. Keep your entries and check any earlier timesheet action.' });
                return;
            }
            lease = { scope, token, invoked: false, retiredNoSend: false };
            activeLease.current = lease;
        }
        busy.current = true;''')
hook = replace(hook, '''            const next =
                !knownNotSent &&''', '''            let next: TimesheetOutcome =
                !knownNotSent &&''')
hook = replace(hook, '''            finished = true;
            busy.current = false;''', '''            finished = true;
            // Keep this hook busy through externally observable scope release.''')
hook = replace(hook, '''            held.current = next.status !== 'rejected';''', '''            if (lease) {
                const originalContext = mounted.current && sentContext === identity.current &&
                    sentGeneration === generation.current &&
                    currentCoordination.current?.scope === lease.scope;
                const released = knownNotSent
                    ? lease.retiredNoSend || lease.scope.completeNoSend(lease.token,
                        lease.invoked ? 'exact_before_veto' : 'preparation_exit')
                    : originalContext && next.status === 'confirmed' &&
                        lease.scope.completeMatched(lease.token);
                if (released) {
                    if (knownNotSent) lease.retiredNoSend = true;
                    if (activeLease.current === lease) activeLease.current = null;
                } else {
                    // Ordinary field errors do not certify that no write committed.
                    // Preserve them for review, but hold the original uncertain attempt.
                    lease.scope.holdUnknown(lease.token);
                    next = { status: 'unknown', message: UNKNOWN_TIMESHEET_RESULT,
                        ...(next.status === 'rejected' || next.status === 'unknown'
                            ? { errors: next.errors } : {}) };
                }
            }
            held.current = next.status !== 'rejected';
            busy.current = false;''')
hook = replace(hook, '''            sentGeneration !== generation.current
        ) {''', '''            sentGeneration !== generation.current ||
            (lease !== null && (currentCoordination.current?.scope !== lease.scope ||
                lease.retiredNoSend || !lease.scope.canDispatch(lease.token)))
        ) {''')
hook = replace(hook, '''            dispatching = true;
            router[method](url, payload, {''', '''            if (lease && !lease.scope.markInvoked(lease.token)) {
                result = { status: 'rejected', message:
                    'No request was sent because this view changed while preparing the action. Your entries are kept.' };
                finish(true);
                return;
            }
            if (lease) lease.invoked = true;
            dispatching = true;
            router[method](url, payload, {''')
hook = replace(hook, '''                onStart: () => { started = true; },''', '''                onStart: () => {
                    started = true;
                    if (!finished && lease) lease.scope.markStarted(lease.token);
                },''')
hook = hook.replace('                    callbackObserved = true;', '''                    callbackObserved = true;
                    if (!finished && lease) lease.scope.markCallback(lease.token);''')
assert hook.count('if (!finished && lease) lease.scope.markCallback(lease.token);') == 4
hook = replace(hook, '''            result = { status: 'unknown', message: UNKNOWN_TIMESHEET_RESULT };
            finish();
        } finally {''', '''            const preparationOnly = lease !== null && !lease.invoked;
            result = preparationOnly
                ? { status: 'rejected', message:
                    'No request was sent because preparation could not finish. Your entries are kept.' }
                : { status: 'unknown', message: UNKNOWN_TIMESHEET_RESULT };
            finish(preparationOnly);
        } finally {''')

original_test = (BASE / 'proposed' / test_name).read_bytes()
addition = (ROOT / 'test-results/workforce-timesheet-coordinated-hook-fixtures-20261012.txt').read_bytes()
assert sum(line.startswith(b"it('") for line in addition.splitlines()) == 11
test_import = b"import { TimesheetWriteScope } from './timesheet-write-scope';\n"
test = test_import + original_test + addition
files, sources, unchanged = {}, {}, []
entries = [(name, (BASE / 'before' / name).read_bytes(), (BASE / 'proposed' / name).read_bytes()) for name in base['sources']]
entries += [(entry['path'], b'', (FOUNDATION / 'new' / entry['path']).read_bytes()) for entry in foundation['paths']]
for name, before, parent in entries:
    after = hook.encode() if name == hook_name else test if name == test_name else parent
    current = (ROOT / name).read_bytes() if (ROOT / name).exists() else b''
    assert current == before, name
    if after == parent: unchanged.append(name)
    sources[name] = {'before_exists': (ROOT / name).exists(), 'before_sha256': sha(before),
                     'parent_sha256': sha(parent), 'after_sha256': sha(after)}
    for prefix, image in [('before', before), ('parent', parent), ('proposed', after)]:
        target = prefix + '/' + name; emit(target, image); files[target] = sha(image)
    transition = {'path': name, 'before_hex': before.hex(), 'parent_hex': parent.hex(), 'after_hex': after.hex()}
    for key, image in [('before_hex', before), ('parent_hex', parent), ('after_hex', after)]:
        assert bytes.fromhex(transition[key]) == image
    target = 'raw-transitions/' + name + '.json'; emit(target, encoded(transition)); files[target] = sha((OUT / target).read_bytes())
assert len(sources) == 13 and len(unchanged) == 11
assert test[len(test_import):len(test_import)+len(original_test)] == original_test
inventory = {'status': 'UNRUN', 'retained_workflow_source_slots': 69,
    'new_hook_declarations': 11, 'prospective_workflow_source_slots': 80,
    'foundation_source_slots_separate': 16, 'foundation_retained_unchanged': True,
    'executed': False, 'actual_inventory': None, 'actual_count': None}
readme = '''Inactive actual legacy hook coordination adapter; not applied or executed.

The existing useTimesheetCommand accepts an explicit stable page scope. Omission preserves existing independent legacy callers; explicitly passing scope:null denies before hash/transport. Coordinated callers acquire an opaque owner before pending/hash; another hook cannot prepare concurrently. Current committed context/coordination is published in insertion effect without notifications/state scheduling; context generation prevents observed change/restoration from authorizing stale preparation/results. Unmount layout cleanup retires provably uninvoked preparation or holds invoked/uncertain attempt in the external stable scope. Late preparation cannot release/dispatch over another lease; late callbacks cannot clear unknown ownership.

Actual router invocation/start/callbacks are wired to that captured lease. Existing exact synchronous same-visit before-veto adapter supplies no-send, not generic finish arguments. Scope release requires either that proved no-send or an original-context matching legacy receipt with recorded callback. In coordinated mode generic field errors retain highlighted fields but remain uncertain, because an error bag alone is not no-commit evidence. No separately certified rejection adapter is implemented. Matching legacy receipt is existing protocol correlation, NOT new UUID/AFTER/root/durable proof. Observer registration failure before invoked transport is a proven preparation exit in coordinated mode; omitted legacy callers retain earlier conservative behavior.

Eleven new actual hook source declarations cover shared prehash exclusion, hash-failure release, exact veto release, matching completion, unmount uncertainty, generic field errors, actor change, explicit missing scope, before-invocation registration failure, prep unmount/old continuation and context ABA. Existing whole hook test bytes remain exact after one new class import; prior69 workflow source slots plus11=80 prospective slots ALL UNRUN. The separate16 foundation controls remain unchanged; do not infer a verified combined native inventory. Thirteen full before/parent/after raw inverses; eleven other images exact, including all four foundation images and all other child callers. No React private hook/helper is mocked, only existing transport/crypto harness.

This is actual hook wiring only. Actual owning Index/provider mount and all direct bulk/archive/restore/read/correction/Action/View/Roster/MyDay peers remain unintegrated; shared scope must live once outside transient children and source changes/Back/page remount must not erase an original unknown attempt. No provider remount/durable recovery guarantee or request-ID/source/Site/role authority is invented. Existing forms do not yet pass the new option, so this proposal alone does not establish whole-page exclusion. Current cohort privacy, partial commits, context authority suppliers, read interruptions and server producer/root/witness/GET recovery remain required. No new endpoint, role, settings policy, header/hero/tokens or tenant boundary.

Source/pure-file hold only: no app edits/parser/type/lint/framework/native/build/browser/process/readiness/SQL/Git/deploy/probe/admission. Claude/eMAR and independent Control Room unchanged. Source assertions/pins are not test or application acceptance; actual inventory/count null. Independent review required before owning integration.
'''
for name, raw in [('README.md', readme.encode()), ('inventory.json', encoded(inventory)),
                  ('source-pins.json', encoded(pins)), ('author.py', Path(__file__).read_bytes()),
                  ('new-hook-fixtures.txt', addition)]:
    emit(name, raw); files[name] = sha(raw)
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
    'authoring_history': ['First pure author c25816 exit1 stopped before output creation: substring count also matched submit calls; corrected to line-anchored declaration count, preserved failure evidence.'],
    'raw_transitions_exact': 13, 'unchanged_parent_images': unchanged,
    'parent_hook_test_bytes_retained': True, 'application_input_drift': [],
    'applied': False, 'runtime_invoked': False, 'actual_inventory': None, 'actual_count': None}
raw = encoded(proof); emit('source-proof.json', raw)
manifest = {'status': 'UNAPPLIED_UNRUN_EXPLICIT_COORDINATED_LEGACY_HOOK_ADAPTER_ONLY',
    'sources': sources, 'files': files, 'dependencies': pins, 'inventory': inventory,
    'source_proof_sha256': sha(raw), 'applied': False, 'runtime_invoked': False,
    'owning_page_integration_implemented': False, 'actual_count': None}
raw = encoded(manifest); emit('manifest.json', raw)
print(json.dumps({'manifest_sha256': sha(raw), 'source_proof_sha256': manifest['source_proof_sha256'],
    'paths': len(sources), 'pins': len(pins), 'unchanged_images': len(unchanged),
    'prospective_workflow_slots_unrun': 80, 'foundation_slots_unrun_separate': 16,
    'actual_inventory': None, 'applied': False}))
