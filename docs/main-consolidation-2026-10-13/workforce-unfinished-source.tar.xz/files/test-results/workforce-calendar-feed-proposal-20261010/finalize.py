from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, difflib, re

ROOT = Path('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
PRIMARY = Path('C:/Users/steph/Herd/oblivionfindings')
PACKET = PRIMARY / 'test-results/workforce-calendar-feed-proposal-20261010'
AUDIT = PRIMARY / 'test-results/workforce-calendar-workflow-reaudit-20261010'
CONTROLLER = 'app/Http/Controllers/CalendarController.php'
TEST = 'tests/Feature/Rostering/WorkforceCalendarReadIntegrityTest.php'

def read(path):
    return Path('\\\\?\\' + str(path).replace('/', '\\')).read_bytes()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def save(name, value):
    (PACKET / name).write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

audit = json.loads(read(AUDIT / 'manifest.json'))
old = read(PACKET / 'baseline' / CONTROLLER)
new = read(PACKET / 'proposed' / CONTROLLER)
test = read(PACKET / 'proposed' / TEST)
assert read(ROOT / CONTROLLER) == old
assert not (ROOT / TEST).exists()
patch = read(PACKET / 'controller.patch') + ''.join(difflib.unified_diff([], test.decode().splitlines(keepends=True), fromfile='/dev/null', tofile='b/' + TEST)).encode()
(PACKET / 'repair.patch').write_bytes(patch)

def apply_hunks(source, sections):
    lines = source.decode().splitlines(keepends=True)
    out = []
    cursor = 0
    for start, removed, added in sections:
        assert lines[start:start + len(removed)] == removed
        out += lines[cursor:start] + added
        cursor = start + len(removed)
    return ''.join(out + lines[cursor:]).encode()

sections = []
lines = patch.decode().splitlines(keepends=True)
file_records = []
at = 0
while at < len(lines):
    assert lines[at].startswith('--- ')
    before_name = lines[at][4:].strip()
    after_name = lines[at + 1][4:].strip()
    at += 2
    hunks = []
    inverse = []
    while at < len(lines) and not lines[at].startswith('--- '):
        header = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[at])
        assert header
        old_start, old_count, new_start, new_count = [int(value) if value is not None else 1 for value in header.groups()]
        at += 1
        removed, added = [], []
        while at < len(lines) and not lines[at].startswith(('@@ ', '--- ')):
            kind, value = lines[at][0], lines[at][1:]
            assert kind in ' +-'
            if kind in ' -':
                removed.append(value)
            if kind in ' +':
                added.append(value)
            at += 1
        assert len(removed) == old_count and len(added) == new_count
        hunks.append((max(0, old_start - 1), removed, added))
        inverse.append((max(0, new_start - 1), added, removed))
    before = old if before_name != '/dev/null' else b''
    after = new if after_name == 'b/' + CONTROLLER else test
    assert apply_hunks(before, hunks) == after
    assert apply_hunks(after, inverse) == before
    file_records.append({'path': after_name[2:], 'before_sha256': sha(before) if before_name != '/dev/null' else None,
                         'after_sha256': sha(after), 'whole_forward_exact': True, 'whole_inverse_exact': True})

consumer_paths = [
    'resources/js/components/rostering/calendar-pane.tsx',
    'resources/js/components/rostering/calendar-shared.ts',
    'resources/js/routes/operations/rostering/calendar/index.ts',
    'resources/js/actions/App/Http/Controllers/CalendarController.ts',
    'tests/Feature/Respite/RespiteReadinessTest.php',
    'tests/e2e/operations-rostering-calendar-tab.spec.ts',
]
consumers = []
for path in consumer_paths:
    body = read(ROOT / path)
    consumers.append({'path': path, 'sha256': sha(body)})
pane = read(ROOT / consumer_paths[0]).decode()
assert "if (!ev.start || !ev.end) return null;" in pane
assert "ext.event_type !== 'coverage_gap' || !ev.start || !ev.end" in pane
assert 'events\r\n            .map(mapShift)' in pane or 'events\n            .map(mapShift)' in pane
assert 'events.map(mapGap)' in pane
respite = read(ROOT / consumer_paths[4]).decode()
assert "collect($calendarEvents)->firstWhere('id', $shift->id)" in respite
consumer_proof = {
    'scope': 'Repository source consumers only; not executed browser behavior or undocumented external clients.',
    'endpoint': '/operations/rostering/calendar/events', 'fixed_marker_id': 'roster-calendar-assessment',
    'response_readers': [
        {'path': consumer_paths[0], 'lines': [137, 139, 140, 184, 186, 1086, 1094],
         'proof': 'Both complete response pipelines discard the marker: mapShift rejects null start/end before numeric conversion; mapGap rejects event_type and null dates. All later day/count/detail paths consume those mapped arrays.'},
        {'path': consumer_paths[4], 'lines': [302, 310],
         'proof': 'The response selects a specific numeric Shift ID; the fixed string marker cannot replace that event. No array-count assertion.'},
    ],
    'non_response_consumers': [
        {'path': consumer_paths[2], 'proof': 'Generated URL/RouteDefinition/FormDefinition builder only; no response body reader.'},
        {'path': consumer_paths[3], 'proof': 'Generated URL/RouteDefinition/FormDefinition builder only; no response body reader.'},
        {'path': consumer_paths[5], 'lines': [22, 24, 35, 43], 'proof': 'E2E observes the request and calendar DOM; it does not count or decode feed records.'},
        {'path': consumer_paths[1], 'proof': 'Mapped data types/date helpers only; no endpoint request or raw response-count consumption.'},
    ],
    'search_scope': 'Actual resources/js, tests, routes and app endpoint literals/route name, including ignored generated JS. Archived docs route copies are not runtime consumers.',
    'pins': consumers, 'runtime_invoked': False,
}
save('consumer-proof.json', consumer_proof)

dependency_paths = [record['path'] for record in audit['source_pins']]
dependency_paths += [
    *consumer_paths,
    'app/Models/ShiftSeries.php', 'app/Models/ServiceContext.php', 'app/Models/SiteCoverageRequirement.php',
    'app/Models/RespiteBooking.php', 'app/Models/Site.php', 'app/Models/User.php',
    'app/Domain/Hr/Models/HrEmployeeProfile.php', 'app/Domain/Rostering/RosteringFeatureFlags.php',
    'app/Services/CoverageRoleService.php', 'app/Support/ShiftTaskSupport.php',
    'database/seeders/RbacSeeder.php', 'database/factories/ShiftFactory.php', 'database/factories/RespiteBookingFactory.php',
    'tests/Feature/Rostering/WorkforceRosteringReadPermissionIntegrityTest.php',
]
dependency_paths = list(dict.fromkeys(dependency_paths))
pins = [{'path': path, 'sha256': sha(read(ROOT / path))} for path in dependency_paths]
audit_drift = [{'path': record['path'], 'before': record['sha256'], 'current': sha(read(ROOT / record['path']))}
               for record in audit['source_pins'] if sha(read(ROOT / record['path'])) != record['sha256']]
histories = [{'path': 'test-results/workforce-calendar-workflow-reaudit-20261010/' + name, 'sha256': sha(read(AUDIT / name))}
             for name in ['manifest.json', 'report.md']]
for pin in audit['preserved_packet_pins']:
    assert sha(read(PRIMARY / pin['path'])) == pin['sha256']
    histories.append(pin)

methods = re.findall(r'public function (test_\w+)\(', test.decode())
provider_sizes = {'historicalStatuses': 3, 'civilDays': 6, 'unsafeSupply': 2}
inventory = []
for method in methods:
    position = test.decode().index('    public function ' + method)
    prefix = test.decode()[:position].splitlines()
    provider = re.search(r"DataProvider\('([^']+)'\)", prefix[-1])
    provider_name = provider.group(1) if provider else None
    inventory.append({'method': method, 'provider': provider_name, 'source_derived_cases': provider_sizes.get(provider_name, 1)})
derived = sum(row['source_derived_cases'] for row in inventory)
selection = {'source_derived_only': True, 'framework_enumerated': False, 'actual_inventory': None,
             'new_class': 'Tests\\Feature\\Rostering\\WorkforceCalendarReadIntegrityTest', 'new_path': TEST,
             'source_derived_new_cases': derived, 'methods': inventory,
             'bounded_preservation': [{'path': 'tests/Feature/Respite/RespiteReadinessTest.php', 'method': 'test_linked_respite_shift_is_identified_on_shift_and_calendar_surfaces', 'source_derived_cases': 1},
                                      {'path': 'tests/Feature/Rostering/WorkforceRosteringReadPermissionIntegrityTest.php', 'scope': 'full accepted reader class', 'source_derived_cases': 19}],
             'proposed_source_derived_total_with_preservation': derived + 20,
             'no_runner_or_execution_authorized': True}
save('selection-derived.json', selection)
proof = {'files': file_records, 'unowned_constructor_exact': True, 'four_existing_writer_helpers_whole_suffix_exact': True,
         'writer_suffix_sha256': sha(old[old.index(b'    public function storeShift('):]),
         'audit_dependency_drift': audit_drift, 'pending_packet_history_drift': [],
         'syntax_parser_invoked': False, 'framework_invoked': False, 'product_applied': False}
save('static-proof.json', proof)
drift = [pin for pin in pins if sha(read(ROOT / pin['path'])) != pin['sha256']]
assert not drift
authored_files = []
for path in sorted(PACKET.rglob('*')):
    if path.is_file() and path.name != 'manifest.json':
        authored_files.append({'path': path.relative_to(PACKET).as_posix(), 'sha256': sha(read(path))})
manifest = {'kind': 'inactive_calendar_feed_backend_proposal', 'created_at_utc': datetime.now(timezone.utc).isoformat(),
            'delivery_root': str(ROOT), 'head_reference_from_source_audit': audit['head_observed_read_only'],
            'owned_paths': file_records, 'dependency_pins': pins, 'dependency_drift_during_save': drift,
            'audit_drift': audit_drift, 'immutable_history_pins': histories, 'authored_files': authored_files,
            'source_derived_cases': derived, 'framework_enumerated': False, 'actual_cases': None,
            'source_applied': False, 'php_or_parser_invoked': False, 'database_or_process_action': False,
            'native_tests_or_browser_or_build_invoked': False, 'gate_acquired': False, 'scenario_acceptance_claimed': False,
            'repair_patch_sha256': sha(patch), 'contract_sha256': sha(read(PACKET / 'contract.md'))}
save('manifest.json', manifest)
print(json.dumps({'manifest': sha(read(PACKET / 'manifest.json')), 'patch': sha(patch), 'controller': sha(new), 'test': sha(test),
                  'contract': manifest['contract_sha256'], 'source_derived_cases': derived, 'test_methods': len(methods),
                  'dependencies': len(pins), 'drift': drift, 'audit_drift': audit_drift,
                  'consumer_proof': sha(read(PACKET / 'consumer-proof.json')), 'static_proof': sha(read(PACKET / 'static-proof.json'))}, indent=2))
