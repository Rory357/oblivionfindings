from pathlib import Path
import hashlib, json, difflib

ROOT = Path('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
PACKET = Path('C:/Users/steph/Herd/oblivionfindings/test-results/workforce-calendar-feed-proposal-20261010')
CONTROLLER = 'app/Http/Controllers/CalendarController.php'

def read(path):
    return Path('\\\\?\\' + str(path).replace('/', '\\')).read_bytes()

def digest(data):
    return hashlib.sha256(data).hexdigest()

original = read(ROOT / CONTROLLER)
newline = '\r\n' if b'\r\n' in original else '\n'
text = original.decode().replace('\r\n', '\n')
old_method = text[text.index('    public function events('):text.index('    public function storeShift(')]
mapper = old_method[old_method.index('        $shiftCoverageById ='):old_method.index('        return response()->json(')]
mapper = mapper.replace("'service_context_id' => $shift->service_context_id,", "'service_context_id' => $shift->serviceContext?->id,")
mapper = mapper.replace("'coverage_missing_staff' => $coverage['missing_staff'] ?? 0,", "'coverage_missing_staff' => $coverage['missing_staff'] ?? null,")
prefix = read(PACKET / 'events-prefix.php.txt').decode()
helpers = read(PACKET / 'helpers.php.txt').decode()
ending = '''        $assessment = [
            'id' => 'roster-calendar-assessment', 'title' => '', 'start' => null, 'end' => null,
            'extendedProps' => [
                'event_type' => 'calendar_assessment', 'schema_version' => 1, 'actor_id' => (int) $auth->id,
                'worker_timezone' => $timezone,
                'range' => ['start' => $start->toIso8601String(), 'end' => $end->toIso8601String(), 'end_exclusive' => true],
                'filters' => ['staff_id' => empty($data['staff_id']) ? null : (int) $data['staff_id'],
                    'client_id' => empty($data['client_id']) ? null : (int) $data['client_id'], 'site_ids' => $requestedSiteIds],
                'scope' => ['kind' => $canReadAny ? 'approved_sites' : 'own', 'site_ids' => $siteIds,
                    'published_only' => ! $canReadAny && app(RosteringFeatureFlags::class)->publishEnabled(),
                    'staff_id' => $canReadAny ? $staffId : (int) $auth->id, 'client_id' => $clientId],
                'coverage' => $coverageAssessment,
            ],
        ];

        return response()->json($shiftEvents->concat($coverageGapEvents)->push($assessment)->values());
    }

'''
candidate_text = text.replace(old_method, prefix + mapper + ending + helpers, 1)
for before, after in [
    ('use App\\Domain\\Hr\\Models\\HrDriverEligibility;\n', 'use App\\Domain\\Hr\\Models\\HrDriverEligibility;\nuse App\\Domain\\Rostering\\RosteringFeatureFlags;\n'),
    ('use App\\Models\\Shift;\n', 'use App\\Models\\Shift;\nuse App\\Models\\ShiftSeries;\nuse App\\Models\\Site;\n'),
    ('use App\\Services\\ShiftTimelineService;\n', 'use App\\Services\\ShiftTimelineService;\nuse App\\Services\\UserSiteAccessService;\n'),
    ('use Illuminate\\Http\\Request;\n', 'use Illuminate\\Database\\Eloquent\\Builder;\nuse Illuminate\\Http\\Request;\n'),
    ('use Illuminate\\Support\\Carbon;\n', 'use Illuminate\\Support\\Carbon;\nuse Illuminate\\Support\\Collection;\n'),
]:
    assert candidate_text.count(before) == 1
    candidate_text = candidate_text.replace(before, after, 1)
candidate = candidate_text.replace('\n', newline).encode()
out = PACKET / 'proposed' / CONTROLLER
out.parent.mkdir(parents=True, exist_ok=True)
out.write_bytes(candidate)
before = PACKET / 'baseline' / CONTROLLER
before.parent.mkdir(parents=True, exist_ok=True)
before.write_bytes(original)
patch = ''.join(difflib.unified_diff(original.decode().splitlines(keepends=True), candidate.decode().splitlines(keepends=True),
                                  fromfile='a/' + CONTROLLER, tofile='b/' + CONTROLLER)).encode()
(PACKET / 'controller.patch').write_bytes(patch)
suffix = b'    public function storeShift('
proof = {'scope': 'source-only; no PHP/parser/framework/application invocation',
         'baseline_sha256': digest(original), 'candidate_sha256': digest(candidate),
         'whole_existing_write_suffix_equal': original[original.index(suffix):] == candidate[candidate.index(suffix):],
         'existing_write_suffix_sha256': digest(original[original.index(suffix):]),
         'constructor_exact': text[text.index('    public function __construct'):text.index('    /**')] == candidate_text[candidate_text.index('    public function __construct'):candidate_text.index('    /**')],
         'source_application': False, 'syntax_checked': False, 'framework_enumerated': False, 'runtime_accepted': False}
assert proof['whole_existing_write_suffix_equal'] and proof['constructor_exact']
(PACKET / 'controller-byte-proof.json').write_text(json.dumps(proof, indent=2) + '\n', encoding='utf-8')
print(json.dumps(proof, indent=2))
