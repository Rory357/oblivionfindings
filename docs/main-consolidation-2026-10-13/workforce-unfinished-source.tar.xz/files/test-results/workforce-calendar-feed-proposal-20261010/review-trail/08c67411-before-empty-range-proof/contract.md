This is an inactive source proposal against DELIVERY 94e31596c. No application, parser, framework inventory, test, database, process or browser action is accepted by this packet.

The existing GET `/operations/rostering/calendar/events` still returns a JSON array. Numeric Shift IDs and existing gap IDs remain unchanged. One final array item has this exact shape:

```ts
type CalendarAssessment = {
    id: 'roster-calendar-assessment';
    title: '';
    start: null;
    end: null;
    extendedProps: {
        event_type: 'calendar_assessment';
        schema_version: 1;
        actor_id: number;
        worker_timezone: string;
        range: { start: string; end: string; end_exclusive: true };
        filters: {
            staff_id: number | null;
            client_id: number | null;
            site_ids: number[] | null;
        };
        scope: {
            kind: 'approved_sites' | 'own';
            site_ids: number[];
            published_only: boolean;
            staff_id: number | null;
            client_id: number | null;
        };
        coverage: {
            status: 'assessed' | 'partially_assessed' | 'not_assessed';
            reason: null | 'permission' | 'no_sites' | 'unsafe_source';
            finding_count: number | null;
        };
    };
};
```

`range.start/end` are UTC ISO-8601 instants, not date labels. Date-only request edges use the configured worker timezone, then application timezone, then UTC; explicit offsets preserve their instants. The end is exclusive. SQL records and owning coverage service receive exactly those edges. `worker_timezone` is the resolved configured timezone. This does not redefine the hero week, publication period, overnight grouping, or Calendar drag timestamps.

`filters` echoes normalized requested staff/Client IDs and the sorted distinct requested Site IDs; absent/null Sites are null, a deliberately empty supplied array stays empty. `scope` identifies the effective approved Sites and filters. Foreign/noncurrent Sites and a foreign Client filter cannot expand that scope. The own path ignores staff/Client display filters as before, sets staff_id to the actor and client_id to null. Its `published_only` follows the installed publication flag; it is false on the viewAny/management path. Site arrays are bounded to 50 positive numeric scalar values; nested values are rejected. The frontend must send its selected Site filter to receive matching scope rather than filtering a broader response only after download.

The route still requires `rostering.viewAny`. `shifts.viewAny` admits the coordinator's canonical approved-Site coworker records; `shifts.manageAny` is the existing Site bypass and write distinction. `reports.viewAny`, template rights and `calendar.viewAny` create no new feed bypass. All paths reuse the installed Shift/Client/current-worker intrinsic reader boundary. This deliberately closes the old management/own Calendar root leak as well as admitting lawful coordinator records. Current-profile filtering also applies to historical rows under that installed helper; no historical exception is invented. Canonical draft/completed/cancelled events remain in the feed. Completed test fixtures retain required actual-start/end evidence. Lawful respite fields stay on their numeric Shift event; no respite coverage or qualification policy is reinterpreted.

Global service Contexts stay readable and do not need equality with the Shift Site. A linked Context outside every permitted Site is masked from this feed without removing the otherwise canonical Shift. A linked recurring source must have canonical permitted Client/Site provenance (including the existing null-Site Client fallback and explicit-Site manual pattern). Active replacement metadata uses the existing intrinsic helper; no historical participant employment policy is added. Raw HR evidence, related Client lists, pattern workers, lifecycle acknowledgements and reservation DTOs are not projected.

Coverage remains the existing Site demand service under `shifts.manageAny`, calculated for effective Sites over the requested range. A Client filter narrows its Site; a staff or Client display filter never removes other canonical same-Site supply. Coverage is not a per-worker, per-Client, monthly staffing or publication verdict.

Every service window is checked before actionable-gap filtering, including exact supply that would produce no displayed findings. Canonical rule/preferred Client, contributing Shift IDs, recurring-source IDs/current assigned pattern worker, and open Shift IDs must be within the same permitted Site scope. Safe scalar calculations are retained without changing the coverage algorithm. Unsafe windows are withheld, not recomputed with reduced supply. `assessed` means all actual service windows passed that projection, including a legitimate zero-window/no-rule outcome; finding_count is the complete actionable gap-window count. `partially_assessed/unsafe_source` means at least one actual window failed projection, so finding_count is null even if no gaps are displayed. `not_assessed/permission` means no coverage grant; `not_assessed/no_sites` means no effective permitted Sites. Neither is zero. Service/query failures still fail the HTTP request; they are never converted to an assessed empty success.

The consumer must require exactly one matching marker, schema version, current actor, configured timezone, normalized requested range and filters before displaying coverage status/count. Missing, malformed, duplicate, mismatched, loading or failed responses are unavailable/loading. Do not retain an old-range count under a new month heading, infer zero from an empty gap array, use requested staff as the coverage denominator, or treat this record as an event/action. Ordinary authorized Shift totals can still be derived from the complete mapped records for the current response.

Repository consumer proof is in consumer-proof.json. CalendarPane's only runtime event pipeline invokes mapShift/mapGap, and both discard this marker because its dates are null; it cannot become a numeric Shift or day group. The retained respite test selects its specific numeric ID. E2E only observes the endpoint request and calendar DOM. Generated action/route helpers construct URLs and do not consume response bodies. External undocumented consumers are not claimed audited.

Frontend/index changes remain parent-owned and absent from this application patch: worker-local formatting/moves, selected-week anchor, bounded calendar_date URL context, lawful read filter gates, response identity validation and unavailable/loading display. Additive calendar_date assignment return composition needs a separate review; frozen assignment R3 is unchanged. No routes, writers, shared Calendar provider, schema, grants or eMAR source is changed.

Later acceptance requires peer source review, authorized syntax/formatting, actual framework enumeration, then an isolated native run including the new class and the retained respite feed method, followed by real coordinator/own/management Calendar navigation and failed-range recovery. All counts in this packet are source-derived only.
