from pathlib import Path
import hashlib, json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-write-coordination-foundation-proposal-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-write-coordination-foundation-proposal-r2-20261012'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def emit(name, raw):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists(), name
    target.write_bytes(raw)
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()

assert not OUT.exists(), 'Frozen successors must not be overwritten'
parent = json.loads((BASE / 'manifest.json').read_bytes())
assert sha((BASE / 'manifest.json').read_bytes()) == 'f5663b3408edcd36bf853547eb5c97938a3a04b24ff3e27a4955fc13c9337934'
for name, digest in parent['files'].items():
    assert sha((BASE / name).read_bytes()) == digest, name
review = 'test-results/workforce-timesheet-write-coordination-foundation-independent-review-20261012/review.json'
assert sha((ROOT / review).read_bytes()) == 'b097e0a42b128bb5cc10ecf7e7938a4e310618966f32ed45db2c1f28d3c74e72'

names = [item['path'] for item in parent['paths']]
scope = (BASE / 'new' / names[0]).read_bytes()
old = b'for (const listener of this.#listeners) {'
assert scope.count(old) == 1
scope = scope.replace(old, b'for (const listener of [...this.#listeners]) {')
old = b'if (!owner || !owner.invoked || owner.uncertain ||'
assert scope.count(old) == 1
scope = scope.replace(old, b'if (!owner || !owner.invoked || !owner.callback || owner.uncertain ||')
context = (BASE / 'new' / names[1]).read_bytes()
context = context.replace(b'useContext, useLayoutEffect', b'useContext, useInsertionEffect, useLayoutEffect', 1)
old = b'    useLayoutEffect(() => {\n        actor.current = actorId;\n        scope.observeActor();\n    }, [actorId, scope]);'
assert context.count(old) == 1
context = context.replace(old, b'''    // Publish only the committed identity, before descendant layout callbacks.
    // Do not notify subscribers or schedule React updates in insertion effects.
    useInsertionEffect(() => { actor.current = actorId; }, [actorId]);
    useLayoutEffect(() => { scope.observeActor(); }, [actorId, scope]);''')
original_test = (BASE / 'new' / names[2]).read_bytes()
extra = '''
it('requires an observed original callback before assessed completion', () => {
    const scope = new TimesheetWriteScope(() => 7), first = scope.tryPrepare(7)!;
    scope.markInvoked(first);
    expect(scope.completeMatched(first)).toBe(false);
    expect(scope.completeKnownRejection(first)).toBe(false);
    expect(scope.snapshot()).toBe('busy'); expect(scope.tryPrepare(7)).toBeNull();
    scope.markCallback(first);
    expect(scope.completeKnownRejection(first)).toBe(true);
    expect(scope.snapshot()).toBe('idle');
});
it('bounds a notification when a listener unsubscribes and resubscribes itself', () => {
    const scope = new TimesheetWriteScope(() => 7);
    let calls = 0;
    let unsubscribe: () => void;
    const listener = () => {
        calls += 1;
        unsubscribe();
        unsubscribe = scope.subscribe(listener);
    };
    unsubscribe = scope.subscribe(listener);
    const first = scope.tryPrepare(7)!;
    expect(first).toBeTypeOf('symbol'); expect(calls).toBe(1);
    expect(scope.completeNoSend(first, 'preparation_exit')).toBe(true);
    expect(calls).toBe(2); unsubscribe();
});
'''.encode()
test = original_test + extra
provider_name = 'resources/js/components/timesheets/timesheet-write-context.test.tsx'
provider_test = '''import { cleanup, render } from '@testing-library/react';
import { useLayoutEffect } from 'react';
import { afterEach, expect, it } from 'vitest';
import { TimesheetWriteProvider, useTimesheetWriteCoordination } from './timesheet-write-context';
import type { TimesheetWriteLease, TimesheetWriteScope } from './timesheet-write-scope';

afterEach(cleanup);
it.each(['preparation', 'completion'] as const)(
    'denies the original actor in a child layout callback after committed actor change: %s',
    (mode) => {
        let original: TimesheetWriteScope | null = null;
        let token: TimesheetWriteLease | null = null;
        let decision: boolean | null = null;
        function Child({ attempt }: { attempt: boolean }) {
            const { scope } = useTimesheetWriteCoordination();
            useLayoutEffect(() => {
                if (!scope) throw new Error('Owning provider missing');
                if (!attempt) {
                    original = scope;
                    token = scope.tryPrepare(7);
                    if (!token) throw new Error('Preparation denied');
                    if (mode === 'completion') {
                        scope.markInvoked(token);
                        scope.markCallback(token);
                    }
                } else {
                    expect(scope).toBe(original);
                    if (!token) throw new Error('Original token missing');
                    decision = mode === 'preparation'
                        ? scope.canDispatch(token) : scope.completeMatched(token);
                }
            }, [scope, attempt]);
            return null;
        }
        const page = render(<TimesheetWriteProvider actorId={7}><Child attempt={false} /></TimesheetWriteProvider>);
        expect(original).not.toBeNull();
        page.rerender(<TimesheetWriteProvider actorId={8}><Child attempt /></TimesheetWriteProvider>);
        expect(decision).toBe(false);
        expect(original!.snapshot()).toBe('needs_check');
        expect(original!.tryPrepare(8)).toBeNull();
    },
);
'''.encode()
images = dict(zip(names, [scope, context, test]))
images[provider_name] = provider_test
files, paths = {}, []
for name, raw in images.items():
    assert not (ROOT / name).exists(), name
    emit('new/' + name, raw)
    files['new/' + name] = sha(raw)
    paths.append({'path': name, 'before_exists': False, 'before_sha256': sha(b''), 'after_sha256': sha(raw)})
    transition = {'path': name, 'before_hex': '', 'after_hex': raw.hex()}
    assert bytes.fromhex(transition['after_hex']) == raw
    path = 'raw-transitions/' + name + '.json'
    emit(path, encoded(transition)); files[path] = sha((OUT / path).read_bytes())
    prior = (BASE / 'new' / name).read_bytes() if name in names else b''
    transition = {'path': name, 'parent_exists': name in names, 'before_hex': prior.hex(), 'after_hex': raw.hex()}
    assert bytes.fromhex(transition['before_hex']) == prior
    path = 'parent-transitions/' + name + '.json'
    emit(path, encoded(transition)); files[path] = sha((OUT / path).read_bytes())
assert test.startswith(original_test)
assert test.count(b"it('") == 14
assert provider_test.count(b'it.each(') == 1
pins = dict(parent['source_pins'])
for name, digest in pins.items(): assert sha((ROOT / name).read_bytes()) == digest, name
for name in ['test-results/workforce-timesheet-write-coordination-foundation-proposal-20261012/manifest.json',
             'test-results/workforce-timesheet-write-coordination-foundation-proposal-20261012/source-proof.json',
             review, 'node_modules/react-dom/cjs/react-dom-client.development.js']:
    pins[name] = sha((ROOT / name).read_bytes())
inventory = {'status': 'UNRUN', 'retained_unit_declarations': 12, 'new_unit_declarations': 2,
    'total_unit_declarations': 14, 'new_react_dataset_declarations': 1,
    'new_react_dataset_source_slots': 2, 'prospective_source_slots': 16,
    'executed': False, 'actual_inventory': None, 'actual_count': None,
    'actual_owning_page_or_hook_tests': None}
readme = '''Inactive R2 source successor; not connected to the application and not executed.

Addresses R1 review H1: useInsertionEffect publishes only the committed actor ref in mutation phase before descendant layout callbacks. It does not notify or schedule state updates there. Parent layout observes for normal subscribers; descendant canDispatch/completeMatched independently observes the fresh committed actor. No render-time ref mutation trusts an abandoned concurrent render. Installed React commit implementation is pinned as source; actual renderer behavior is unverified.

H2: notification iterates a finite copied listener batch so unsubscribe/resubscribe cannot append endlessly to that same notification. Throwing listeners still cannot strand an acquired token. H3: assessed completion also requires a recorded original invoked callback. Callback alone is not a receipt, permission, known rejection or server proof. Existing caller assessment obligations remain intact.

All twelve parent unit declarations are retained as an exact byte prefix; two new unit declarations cover no-callback refusal and listener resubscription. One actual React provider/child-layout dataset declares two source cases: pending preparation and assessed completion across committed actor7->8. Total prospective source slots16 (14 unit declarations plus2 dataset cases), ALL UNRUN; actual inventory/count null. No mocked private coordination API, no owning-page/hook or transport integration, no browser or aborted-render execution claimed. Previous69 workflow fixtures stay separate and unchanged.

Four new app paths are still absent. Four full raw addition inverses and four parent transitions are frozen. R1 and its HOLD review remain unchanged. No existing hook/Index/direct bulk/archive/restore/read/correction/Action/View/Roster/MyDay is wired. Exact Inertia visit adapters, current permissions/Sites/cohort, durable original attempt recovery, partial commits, page refresh/Back/owning callbacks and server producer/root/witness remain open. Caller completion methods do not authenticate assessments. The Symbol is only a private local lease, not a server command ID. Optional absent context must never grant write admission. No application edit/parser/framework/types/lint/build/browser/process/readiness/SQL/Git/deploy/probe/admission. Environmental hold and Claude/eMAR/Control Room boundaries unchanged.
'''
for name, raw in [('inventory.json', encoded(inventory)), ('source-pins.json', encoded(pins)),
                  ('README.md', readme.encode()), ('author.py', Path(__file__).read_bytes())]:
    emit(name, raw); files[name] = sha(raw)
for name, digest in files.items(): assert sha((OUT / name).read_bytes()) == digest, name
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
    'authoring_history': ['First pure-file attempt stopped before output creation at exact newline locator assertion (cbf0fd exit1); actual parent raw bytes use LF, corrected locator and retained failed evidence.'],
    'new_paths_still_absent': True, 'raw_addition_inverses_exact': 4,
    'parent_transitions_exact': 4, 'twelve_unit_declarations_exact_prefix': True,
    'input_drift': [], 'applied': False, 'runtime_invoked': False, 'actual_count': None}
raw = encoded(proof); emit('source-proof.json', raw)
manifest = {'status': 'UNAPPLIED_UNRUN_LOCAL_COORDINATION_FOUNDATION_R2_ONLY',
    'parent_manifest_sha256': sha((BASE / 'manifest.json').read_bytes()),
    'parent_hold_review_sha256': pins[review], 'paths': paths, 'files': files,
    'source_pins': pins, 'inventory': inventory, 'source_proof_sha256': sha(raw),
    'applied': False, 'runtime_invoked': False, 'owning_integration_implemented': False, 'actual_count': None}
raw = encoded(manifest); emit('manifest.json', raw)
print(json.dumps({'manifest_sha256': sha(raw), 'source_proof_sha256': manifest['source_proof_sha256'],
    'paths': 4, 'source_pins': len(pins), 'source_slots_unrun': 16, 'actual_count': None, 'applied': False}))
