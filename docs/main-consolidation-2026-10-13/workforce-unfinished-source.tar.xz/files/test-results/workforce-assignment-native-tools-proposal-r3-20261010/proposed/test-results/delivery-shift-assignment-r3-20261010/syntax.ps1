# Parent-only PHP lint/PowerShell AST; no application, kernel, listing or database construction.
param([switch]$Check)
$ErrorActionPreference = 'Stop'
$packet = $PSScriptRoot
$profilePath = Join-Path $packet 'profile.json'
$profile = Get-Content -LiteralPath $profilePath -Raw | ConvertFrom-Json
$root = [IO.Path]::GetFullPath([string]$profile.root)
if (!$Check -or $profile.syntax_authorized -ne $true -or $profile.approved -ne $false -or $profile.inventory_authorized -ne $false) { throw 'Explicit parent syntax approval only; no native/list permission.' }
if ($root -ne 'C:\Users\steph\.codex\worktrees\workforce-delivery\oblivionfindings' -or (Get-Location).Path -ne $root -or (git rev-parse HEAD).Trim() -ne $profile.expected_head) { throw 'Exact separately applied candidate root required.' }
foreach ($item in $profile.source_pins.PSObject.Properties) { if (!(Test-Path -LiteralPath (Join-Path $root $item.Name)) -or (Get-FileHash -LiteralPath (Join-Path $root $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw ('Parent candidate source differs: '+$item.Name) } }
foreach ($item in $profile.tools.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $packet $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw 'Reviewed parser/native tool changed.' } }
foreach ($file in @('syntax.json', 'syntax.stdout.log', 'syntax.stderr.log')) { if (Test-Path -LiteralPath (Join-Path $packet $file)) { throw 'Preserve prior parser output; no overwrite.' } }
$processes = @(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
foreach ($proc in $processes) { if ($proc.Name -ieq 'mysql.exe' -or ($proc.Name -match '^php.*\.exe$' -and ([string]::IsNullOrWhiteSpace($proc.CommandLine) -or $proc.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)'))) { throw ('Peer PHP/Pest/import active; preserve PID '+$proc.ProcessId) } }
$os = Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10
$cpu = @(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
if ([long]$os.FreePhysicalMemory -le 0 -or $cpu.Count -ne 1 -or $null -eq $cpu[0].PercentProcessorTime -or [math]::Floor([long]$os.FreePhysicalMemory/1024) -lt 4096 -or [int]$cpu[0].PercentProcessorTime -gt 85) { throw 'Parser resource admission held; no application execution.' }
$php = 'C:/Users/steph/.config/herd/bin/php84/php.exe'
$checked = @()
foreach ($item in $profile.source_pins.PSObject.Properties | Where-Object { $_.Name -like '*.php' -and $_.Name -notlike 'vendor/*' }) {
    & $php '-d' 'memory_limit=1024M' '-l' (Join-Path $root $item.Name) 1>> (Join-Path $packet 'syntax.stdout.log') 2>> (Join-Path $packet 'syntax.stderr.log')
    if ($LASTEXITCODE -ne 0) { throw ('Candidate syntax failed: '+$item.Name) }
    $checked += $item.Name
}
foreach ($item in $profile.tools.PSObject.Properties) {
    $path = Join-Path $packet $item.Name
    if ($item.Name -like '*.php') { & $php '-d' 'memory_limit=1024M' '-l' $path 1>> (Join-Path $packet 'syntax.stdout.log') 2>> (Join-Path $packet 'syntax.stderr.log'); if ($LASTEXITCODE -ne 0) { throw ('Tool syntax failed: '+$item.Name) } }
    elseif ($item.Name -like '*.ps1') { $tokens = $null; $parseErrors = $null; $null = [Management.Automation.Language.Parser]::ParseFile($path, [ref]$tokens, [ref]$parseErrors); if (@($parseErrors).Count -ne 0) { throw ('PowerShell AST failed: '+$item.Name) } }
}
foreach ($item in $profile.source_pins.PSObject.Properties) { if ((Get-FileHash -LiteralPath (Join-Path $root $item.Name) -Algorithm SHA256).Hash -ne $item.Value) { throw 'Source changed during parser pass.' } }
$proof = [ordered]@{head=$profile.expected_head;source_pins=$profile.source_pins;tools=$profile.tools;checked_php_sources=$checked;php_syntax_exit=0;powershell_ast_errors=0;application_bootstrap=$false;database_or_scenario_execution=$false;stdout_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'syntax.stdout.log') -Algorithm SHA256).Hash.ToLowerInvariant();stderr_sha256=(Get-FileHash -LiteralPath (Join-Path $packet 'syntax.stderr.log') -Algorithm SHA256).Hash.ToLowerInvariant()}
$proof | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $packet 'syntax.json') -Encoding utf8
$profile.syntax_sha256 = (Get-FileHash -LiteralPath (Join-Path $packet 'syntax.json') -Algorithm SHA256).Hash.ToLowerInvariant()
$profile.syntax_verified = $true
$profile.syntax_authorized = $false
$profile | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $profilePath -Encoding utf8
