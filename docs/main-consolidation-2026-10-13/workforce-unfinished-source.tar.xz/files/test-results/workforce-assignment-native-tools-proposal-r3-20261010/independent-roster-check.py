from pathlib import Path
import hashlib, json, re, xml.etree.ElementTree as ET

P = Path(__file__).resolve().parent
D = Path('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
C = P.parent / 'workforce-assignment-workflow-proposal-r3-20261010'
R = P.parent / 'workforce-leave-review-native-tools-proposal-r4-20261010'
T = P / 'proposed/test-results/delivery-shift-assignment-r3-20261010'
def data(p): return Path('\\\\?\\' + str(p.resolve()).replace('/', '\\')).read_bytes()
def sha(p): return hashlib.sha256(data(p)).hexdigest()
def js(p): return json.loads(data(p))
errors = []
def check(ok, label):
    if not ok: errors.append(label)
manifest = js(P/'manifest.json')
check(sha(P/'manifest.json') == 'ba38b7e0880b8c093c4888b632fba0396c9b21e00f45fb48c1bae6c4d12967eb', 'manifest')
for n,h in manifest['files'].items(): check(sha(P/n)==h,'packet:'+n)
inputs = js(P/'reference/input-pins.json')
for n,h in inputs.items(): check(sha(Path(n.replace('\\\\','\\')))==h,'reference:'+n)
for n in (P/'baseline').iterdir():
    check(data(n)==data(R/'proposed/test-results/delivery-leave-review-r4-20261010'/n.name),'R4baseline:'+n.name)
transition = js(P/'reference/source-transition.json')
candidate = js(C/'manifest.json')
profile = js(T/'profile.json')
check(transition['candidate14']==candidate['files'] and len(candidate['files'])==14,'candidate14')
check(transition['assignment_baseline42']==js(C/'source-pins.json')['pins'] and len(transition['assignment_baseline42'])==42,'baseline42')
for n,h in transition['assignment_baseline42'].items(): check(sha(D/n)==h,'current42:'+n)
for n,row in candidate['files'].items():
    check(sha(C/'proposed'/n)==row['after'],'candidateafter:'+n)
    check((not (D/n).exists()) if row['before'] is None else sha(D/n)==row['before'],'candidatebefore:'+n)
pins=transition['independent_proposed_source_pins']
check(pins==profile['source_pins'] and len(pins)==117,'117map')
for n,h in pins.items():
    check(sha((C/'proposed' if n in candidate['files'] else D)/n)==h,'117source:'+n)
for n,h in profile['tools'].items(): check(sha(T/n)==h,'toolpin:'+n)
check(len(profile['tools'])==9,'toolcount')

# Parse patch text only. This neither invokes git nor writes candidate tools.
def sections(p):
    lines=data(p).decode().splitlines(keepends=True); result={}; i=0
    while i<len(lines):
        if not lines[i].startswith('--- '): i+=1; continue
        old=lines[i][4:].strip(); new=lines[i+1][4:].strip(); i+=2; hunks=[]
        while i<len(lines) and not lines[i].startswith('--- '):
            if lines[i].startswith('@@ '):
                m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]); i+=1; body=[]
                while i<len(lines) and not lines[i].startswith(('@@ ','--- ')):
                    if lines[i][0:1] in [' ','+','-']: body.append(lines[i])
                    elif lines[i].startswith('\\ No newline'): body[-1]=body[-1].rstrip('\r\n')
                    i+=1
                hunks.append((int(m[1]),body))
            else:i+=1
        result[(old,new)]=hunks
    return result
def apply(base,hunks):
    original=base.decode().splitlines(keepends=True); out=[]; at=0
    for start,body in hunks:
        pos=max(0,start-1); out.extend(original[at:pos]); at=pos
        for row in body:
            if row[0] in ' -':
                assert original[at]==row[1:],(start,row,original[at]); at+=1
            if row[0] in ' +':out.append(row[1:])
    out.extend(original[at:]);return ''.join(out).encode()
forward=sections(P/'repair.patch'); inverse=sections(P/'inverse.patch')
for (old,new),hunks in forward.items():
    name=Path(new).name; before=data(P/'baseline'/name) if (P/'baseline'/name).exists() else b''
    check(apply(before,hunks)==data(T/name),'forward:'+name)
for (old,new),hunks in inverse.items():
    name=Path(old).name; after=data(P/'baseline'/name) if (P/'baseline'/name).exists() else b''
    check(apply(data(T/name),hunks)==after,'inverse:'+name)
check(len(forward)==len(inverse)==9 and data(P/'baseline/pest-entry.php')==data(T/'pest-entry.php'),'inversecount')

def normalized(b): return b.replace(b'delivery-leave-review-r4-20261010',b'delivery-shift-assignment-r3-20261010').replace(b'oblivion_workforce_dlvleave_r4_20261010',b'oblivion_workforce_dlvassign_r3_20261010')
oldrun=normalized(data(P/'baseline/run.ps1')); newrun=data(T/'run.ps1')
check(oldrun[oldrun.index(b'$mutex ='):]==newrun[newrun.index(b'$mutex ='):],'entiremutexprocessfinallyresulttail')
check(oldrun[oldrun.index(b'function Get-Birth'):oldrun.index(b'Assert-Pins\nif (!$profile.inventory_sha256')] == newrun[newrun.index(b'function Get-Birth'):newrun.index(b'Assert-Pins\nif ($profile.syntax_verified')], 'resourceslot')
check(normalized(data(P/'baseline/cleanup-schema.php'))==data(T/'cleanup-schema.php'),'cleanupentire')
check(data(P/'baseline/pest-entry.php')==data(T/'pest-entry.php'),'entryexact')
for n in ['phpunit.xml','phpunit-list.xml']:
    x=ET.fromstring(data(T/n)); files=[e.text.replace('\\','/').removeprefix(str(D).replace('\\','/')+'/') for e in x.findall('.//testsuite/file')]
    check(files==profile['test_files'],'XMLfiles:'+n)
    check(b'delivery-leave-review-' not in data(T/n),'XMLstale:'+n)

check(len(profile['selection'])==len(profile['test_files'])==8,'selection8')
for sel in profile['selection']:
    text=data((C/'proposed' if sel['file'] in candidate['files'] else D)/sel['file']).decode()
    methods=re.findall(r'public function (test_\w+)\(',text)
    check(set(sel['methods'])<=set(methods),'selectedmethods:'+sel['file'])
    if sel['whole_file']:check(set(sel['methods'])==set(methods),'wholefile:'+sel['file'])
    check(sel['raw_methods']==dict(zip(sel['methods'],sel['methods'])),'rawmapping:'+sel['file'])
source_cases=js(C/'selection-source-derived.json')
expected=[]
for row in source_cases['cases']:
    ident=source_cases['class']+'::'+row['method']+(('"'+row['dataset']+'"') if row['dataset'] is not None else '')
    name=row['method'][5:].replace('_',' '); name=name[0].upper()+name[1:]
    if row['dataset'] is not None:name+=' with data set "'+row['dataset']+'"'
    expected.append({'identity':ident,'junit_identity':source_cases['class'].replace('\\','.')+'::'+name})
check(profile['source_derived_required_candidate_cases']==expected and len(expected)==53,'case53mapping')
check(len({r['identity'] for r in expected})==53,'case53unique')
baseprofile=js(P/'baseline/profile.json')
check(profile['historical_return_cases']==baseprofile['historical_return_cases'] and len(profile['historical_return_cases'])==60,'historical60')
check(profile['expected_cases'] is None and profile['framework_enumerated'] is False and not profile['approved'] and not profile['inventory_authorized'] and not profile['syntax_authorized'] and not profile['syntax_verified'],'inactiveflags')
schema=js(P/'schema-source-review.json')
check(sha(D/schema['schema']['path'])==schema['schema']['sha256'],'dump')
for n in schema['required_pending_migrations']:check(n in pins and (D/n).exists(),'migrationpin:'+n)
check(sha(D/'tests/TestCase.php')==schema['testcase_pending_migration_path']['hash'],'TestCasepin')

summary={'packet_sha256':sha(P/'manifest.json'),'errors':errors,'manifest_files_checked':len(manifest['files']),'input_refs_checked':len(inputs),'whole_tool_forward_inverse':len(forward)+1,'baseline42_checked':42,'candidate14_checked':14,'independent117_checked':117,'selected_files':8,'required_new_source_cases':53,'historical_mapping':60,'protected_runner_tail_exact':not any('tail' in e for e in errors),'no_runtime_or_parser_invoked':True}
print(json.dumps(summary,indent=2))
