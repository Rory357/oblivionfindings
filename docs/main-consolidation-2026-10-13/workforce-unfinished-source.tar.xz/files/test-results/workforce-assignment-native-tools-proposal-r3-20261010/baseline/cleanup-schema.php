<?php
// Direct PDO only; no application bootstrap, broad prune or sibling schema access.
$profile = json_decode(file_get_contents(__DIR__.'/profile.json'), true, 512, JSON_THROW_ON_ERROR);
$pid = filter_var($argv[1] ?? '', FILTER_VALIDATE_INT);
if (! $pid || $pid <= 0 || ($argv[2] ?? '') !== '--verified-owned-process-absent') { throw new RuntimeException('Verified exact owner PID required.'); }
$database = $profile['database_base'].'_'.$pid;
if (preg_match('/\Aoblivion_workforce_dlvleave_r4_20261010_[1-9][0-9]*\z/D', $database) !== 1 || strlen($database) > 64 || getenv('DB_HOST') !== '127.0.0.1' || getenv('DB_PORT') !== '3306' || ! in_array(getenv('DB_URL'), [false, ''], true) || ! in_array(getenv('DB_SOCKET'), [false, ''], true)) { throw new RuntimeException('Exact local owned schema required.'); }
$pdo = new PDO('mysql:host=127.0.0.1;port=3306', getenv('DB_USERNAME'), getenv('DB_PASSWORD'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$query = $pdo->prepare('SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE DB = ?'); $query->execute([$database]); $connections = (int) $query->fetchColumn();
if ($connections !== 0) { throw new RuntimeException('Owned database still has connections; refuse drop.'); }
$pdo->exec('DROP DATABASE IF EXISTS `'.$database.'`');
$query = $pdo->prepare('SELECT COUNT(*) FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?'); $query->execute([$database]);
$proof = ['database' => $database, 'owner_pid' => $pid, 'connections' => $connections, 'schema_count' => (int) $query->fetchColumn()];
file_put_contents(__DIR__.'/schema-cleanup.json', json_encode($proof, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
if ($proof['schema_count'] !== 0) { throw new RuntimeException('Owned schema remains.'); }
