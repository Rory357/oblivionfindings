<?php
// No Application construction, kernel, DB, output artifacts or test execution.
if (! in_array('--list-tests', $_SERVER['argv'] ?? [], true)) { throw new RuntimeException('This bootstrap permits list-tests only.'); }
$root = 'C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings';
if (str_replace('\\', '/', realpath(dirname(__DIR__, 2)) ?: '') !== $root) { throw new RuntimeException('Foreign list root.'); }
$loader = require $root.'/vendor/autoload.php';
foreach (['App\\' => '/app', 'Tests\\' => '/tests', 'Database\\Seeders\\' => '/database/seeders', 'Database\\Factories\\' => '/database/factories'] as $prefix => $folder) { $loader->addPsr4($prefix, $root.$folder, true); }
foreach ([Tests\TestCase::class, App\Http\Controllers\RosteringController::class, App\Http\Controllers\Operations\QualificationMatchController::class, App\Services\Eligibility\WorkforceQualificationEvidence::class, App\Domain\Hr\Services\LeaveService::class, App\Domain\Hr\Services\WorkforceAvailabilityCoverageService::class, App\Domain\Hr\Services\LeaveReviewReceipt::class, App\Http\Controllers\Hr\LeaveController::class, App\Http\Middleware\HandleInertiaRequests::class] as $class) { if (! str_starts_with(str_replace('\\', '/', (new ReflectionClass($class))->getFileName()), $root.'/')) { throw new RuntimeException('Foreign actual list class.'); } }
if (str_replace('\\', '/', Pest\TestSuite::getInstance()->rootPath) !== $root) { throw new RuntimeException('Foreign Pest list root.'); }
