# Assignment / Calendar critical path, source-only

**No unexpected source conflict found.** Current DELIVERY is HEAD `94e31596c05825f24ff4cb84f734aa971a3c4793`. Assignment R3's 117-pin prospective map has 103 current matches and exactly 14 intended differences: six files match their reviewed before hashes and eight new paths are absent. All 42 R3 baseline references, 14 proposed after hashes, ten tool/reference hashes, and 90 Calendar Return frozen references are exact. Assignment syntax/list/runtime approval remains false and actual counts remain unset.

The active Calendar profile has 168 matching source pins and hash `9a3732c2789a6154c3bf7fee3a574b0732f82a04dd822d705b45e5ee6dc371a5`. It was not changed. Its applied CalendarController/read-test pair has no application-file overlap with Assignment14 or Return3. Nevertheless, applying Assignment changes five dependencies in that current Calendar profile:

- ShiftLifecycleService
- ShiftController
- HandleInertiaRequests
- CoverageReservationService
- ShiftReplacementService

Finish Calendar runtime acceptance and cleanup against that exact profile first. Its subsequent result must remain historical once these dependencies change.

Calendar Return is a clean **second source transition after R3**, not a patch against current DELIVERY. Its ShiftAssignmentReturn and ShiftController before bytes exactly equal R3's proposed after bytes; the third path is a new test. Together the two application steps affect 15 unique paths. Return changes only the bounded navigation parser, Show's fallback DTO and its new private helper; the reviewed command, Conflict Queue and medication return mechanics remain separate and unchanged.

Leave receipt preservation is exact: R3 Middleware reverses to the current DELIVERY file by removing one unique `shift_assignment_result` requester projection. The existing `leave_review_result` and every other prior byte survive. Return owns no Middleware/Leave source. A fresh relevant leave receipt regression is still appropriate because the shared flash dependency changes; R4 is not silently reused as current acceptance.

Current main is now `d55c97b211712284c4336ce3537721f703e4b28f`; its ShiftController still hashes `93e305a72c80939b139bdf6808652507206b8e10cc177b5d63a40e83cdf79dfc`. Its difference from DELIVERY is exactly the reviewed eMAR Show change: omit `client.medicalProfile`/`client.risks` eager loads and use `ShiftMedicationCardAccess::canRead`. Pure in-memory composition retains those changes on both R3 and Return, producing the previously reviewed hashes `11735df3…` and `5e1ddd64…`. Copying either whole DELIVERY-based controller onto main would regress eMAR. Main Middleware also needs the separate Leave-plus-Assignment composition, rather than a stale whole-file replacement.

Recommended sequence:

1. Complete Calendar's unchanged168 acceptance/closure.
2. Parent applies exact R3 fourteen paths with fresh before checks and a separate application record.
3. Parent applies exact Return three paths as its own reviewed transition after those R3 before checks. Retain both original proposals and original tool profiles.
4. Review a fresh combined profile/namespace. Preserve R3's existing named selectors; add the accepted Calendar source/dependency bindings and its three selected regression files, Return's new class, and LeaveReviewReceiptIntegrityTest. The proposed union is thirteen files, with duplicate selectors removed; actual case count requires a later framework listing. Original R3 tools117 omit the newly applied Calendar feed pair and its selected regressions, so they cannot alone certify this combined product.
5. Perform actual syntax/import/format checks, framework listing, then guarded isolated native acceptance under parent GO. Main delivery requires the narrow eMAR-preserving composition plus current-main dependency/privacy regressions, including ShiftAndTransportMedicationPrivacyTest. Parent frontend/types/build/browser checks follow separately.

This check did not apply any source, modify a harness/profile, invoke a parser/framework/database/process/authentication action, or interact with Claude. The 53 Assignment and 33 Return cases are source-derived proposals, not executed inventory or acceptance. Exact differences and proposed finite file union are in `review.json` and `source-difference14.json`.
