<?php

namespace App\Repositories;

class ConfigurationJsonRepository
{





protected $finderOptions = [
'exclude',
'notPath',
'notName',
];








public function __construct(protected $path, protected $preset)
{

}






public function finder()
{
return collect($this->get())
->filter(fn ($value, $key) => in_array($key, $this->finderOptions))
->toArray();
}






public function rules()
{
return $this->get()['rules'] ?? [];
}






public function cacheFile()
{
return $this->get()['cache-file'] ?? null;
}






public function preset()
{
return $this->preset ?: ($this->get()['preset'] ?? 'laravel');
}






protected function get()
{
if (! is_null($this->path) && $this->fileExists((string) $this->path)) {
$baseConfig = json_decode(file_get_contents($this->path), true);

if (isset($baseConfig['extend'])) {
$baseConfig = $this->resolveExtend($baseConfig);
}

return tap($baseConfig, function ($configuration) {
if (! is_array($configuration)) {
abort(1, sprintf('The configuration file [%s] is not valid JSON.', $this->path));
}
});
}

return [];
}






protected function fileExists(string $path)
{
return match (true) {
str_starts_with($path, 'http://') || str_starts_with($path, 'https://') => str_contains(get_headers($path)[0], '200 OK'),
default => file_exists($path)
};
}







private function resolveExtend(array $configuration)
{
$path = realpath(dirname($this->path).DIRECTORY_SEPARATOR.$configuration['extend']);

$extended = json_decode(file_get_contents($path), true);

if (isset($extended['extend'])) {
throw new \LogicException('Pint configuration cannot extend from more than 1 file.');
}

return array_replace_recursive($extended, $configuration);
}
}
