# Calendar formatting-only transition

This inactive packet starts from the two applied Calendar R2 sources and the current unapproved 168-pin DELIVERY profile. It copies the sources into `baseline/` and `proposed/`; only the latter may be formatted. Original failed syntax/Pint output is retained byte-for-byte in `failed-source-r1-reference/`.

`format-copies.ps1` uses the installed DELIVERY Pint proxy/build from the same DELIVERY working directory as the failed check. There is no root `pint.json`; the installed default Laravel preset is used. It requires the existing shared mutex, at least 3072 MiB free, CPU at most 85%, and no non-preview PHP or MySQL import client. PHP is capped at 256 MiB. Preview identities, all 168 live source pins, installed formatter/config inputs, and referenced history are checked again after the copied-source work.

The first attempt stopped before PHP because sandbox CIM access was unavailable; its script/result are preserved in `initial-cim-hold/`. The escalated `actual-r2/` attempt also stopped before PHP because another PHP process was active. Neither attempt changed the inactive source copies or product files.

The original zero-peer guard and all its held attempts remain unchanged. Its ten-minute watcher ended naturally. Parent then authorised a separate copied-source-only profile: `format-copies-source-only.ps1` requires at least 6144 MiB free, CPU at most 50%, the same shared mutex and PHP256. It permits identified Pest/PHPUnit peers only as read-only process observations, rejects imports and unknown non-preview PHP, and compares protected preview identities without stopping any peer. This changes no native, list or browser guard. Separate private caches avoid shared formatter state.

`source-only-r1/` records actual formatter, installed Pint test, no-INI `TOKEN_PARSE` import/token equivalence and both syntax checks, all exit 0. The before/after proof retains the exact import multiset and every other non-whitespace token, including comments/literals (only CRLF comment normalization is allowed); line-sensitive tokens are rejected. `repair.patch` and `inverse.patch` contain only the two source formatting changes. `profile.patch` changes only their two source hashes in the unapproved 168-pin profile, with every other field unchanged.

A fresh attempt always uses a fresh output directory; previous results cannot be overwritten. No framework listing, application bootstrap, database action, native scenario, product application, or execution permission is supplied by this packet.

The 58 prospective cases remain source-derived only. Accepted Leave R4 and historical Return/Coverage receipts remain separate immutable evidence. The profile's inventory, count, approval, selection, resource, process, and database guards must remain unchanged; a later parent-approved application can replace only the two source pins.
