<?php

declare(strict_types=1);

$root = __DIR__;
$manifest = json_decode(file_get_contents($root.'/authoring.json'), true, 512, JSON_THROW_ON_ERROR);
$rows = [];
$normalize = static function (string $source): array {
    preg_match_all('/^use [^;\r\n]+;/m', $source, $matches);
    $imports = $matches[0];
    sort($imports, SORT_STRING);
    $body = preg_replace('/^use [^;\r\n]+;/m', '', $source);
    $tokens = [];
    foreach (token_get_all($body, TOKEN_PARSE) as $token) {
        if (is_array($token)) {
            if ($token[0] === T_WHITESPACE) {
                continue;
            }
            if ($token[0] === T_LINE) {
                throw new RuntimeException('Line-sensitive source needs separate review.');
            }
            $value = $token[1];
            if (in_array($token[0], [T_OPEN_TAG, T_COMMENT, T_DOC_COMMENT], true)) {
                $value = str_replace("\r\n", "\n", $value);
            }
            $tokens[] = [$token[0], $value];
        } else {
            $tokens[] = $token;
        }
    }

    return [$imports, $tokens];
};
foreach ($manifest['files'] as $file) {
    $relative = str_replace('\\', '/', $file['path']);
    $before = file_get_contents($root.'/baseline/'.$relative);
    $after = file_get_contents($root.'/proposed/'.$relative);
    if (hash('sha256', $before) !== $file['before_sha256']) {
        throw new RuntimeException('Baseline drift.');
    }
    [$beforeImports, $beforeTokens] = $normalize($before);
    [$afterImports, $afterTokens] = $normalize($after);
    if ($beforeImports !== $afterImports || $beforeTokens !== $afterTokens) {
        throw new RuntimeException('Non-format token/import/comment change: '.$relative);
    }
    $rows[] = [
        'path' => $relative,
        'before_sha256' => hash('sha256', $before),
        'after_sha256' => hash('sha256', $after),
        'imports_exact_as_set' => true,
        'all_other_non_whitespace_tokens_exact' => true,
        'token_count' => count($afterTokens),
    ];
}
echo json_encode(['state' => 'INACTIVE_FORMAT_ONLY_TOKEN_IMPORT_SYNTAX_CLEAR', 'files' => $rows, 'product_applied' => false, 'framework_or_database_loaded' => false], JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR), "\n";
