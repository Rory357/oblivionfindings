import bz2
import hashlib
import json
import struct
import zlib
from pathlib import Path

packet = Path(__file__).resolve().parent
author_path = packet / 'authoring.json'
author = json.loads(author_path.read_bytes())
pint = Path(author['root']) / 'vendor/laravel/pint/builds/pint'
data = pint.read_bytes()
assert hashlib.sha256(data).hexdigest() == author['installed_tools'][str(pint)]
pos = data.index(b'__HALT_COMPILER();') + len(b'__HALT_COMPILER(); ?>\r\n')
length = struct.unpack_from('<I', data, pos)[0]
pos += 4
body = pos + length
count = struct.unpack_from('<I', data, pos)[0]
pos += 10
length = struct.unpack_from('<I', data, pos)[0]
pos += 4 + length
length = struct.unpack_from('<I', data, pos)[0]
pos += 4 + length
entries = []
for _ in range(count):
    length = struct.unpack_from('<I', data, pos)[0]
    pos += 4
    name = data[pos:pos+length].decode('utf-8')
    pos += length
    size, stamp, compressed, crc, flags, metadata = struct.unpack_from('<IIIIII', data, pos)
    pos += 24 + metadata
    entries.append((name, size, compressed, crc, flags))
wanted = {'app/Repositories/ConfigurationJsonRepository.php', 'app/Factories/ConfigurationFactory.php', 'app/Factories/ConfigurationResolverFactory.php', 'app/Providers/RepositoriesServiceProvider.php', 'resources/presets/laravel.php'}
pins = []
for name, size, compressed, crc, flags in entries:
    raw = data[body:body+compressed]
    body += compressed
    if name not in wanted:
        continue
    source = zlib.decompress(raw, -15) if flags & 0x1000 else bz2.decompress(raw) if flags & 0x2000 else raw
    assert len(source) == size and (zlib.crc32(source) & 0xffffffff) == crc
    destination = packet / 'installed-format-configuration' / name
    if destination.exists():
        raise RuntimeError('Preserve captured installed source.')
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(source)
    pins.append({'phar_entry': name, 'path': str(destination.relative_to(packet)).replace('\\', '/'), 'sha256': hashlib.sha256(source).hexdigest()})
assert len(pins) == len(wanted)
author['pint_configuration']['captured_installed_config_sources'] = pins
author['pint_configuration']['private_cache_files'] = ['actual-rN/pint-format.cache', 'actual-rN/pint-test.cache']
author['pint_configuration']['rule_configuration_unchanged_by_private_cache_flag'] = True
author_path.write_text(json.dumps(author, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'pure_phar_source_extraction': True, 'php_or_application_loaded': False, 'captured_files': len(pins)}))
