$ErrorActionPreference='Stop'
$packet=$PSScriptRoot
$author=Get-Content -LiteralPath (Join-Path $packet 'authoring.json') -Raw | ConvertFrom-Json
$root=[string]$author.root
$php=[string]$author.php_path
$profile=Get-Content -LiteralPath $author.profile_path -Raw | ConvertFrom-Json
$resultPath=Join-Path $packet 'format-result.json'
if (Test-Path -LiteralPath $resultPath) {throw 'Preserve actual formatter result; no replay.'}
function Sha([string]$Path) {(Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
function Assert-Originals {
    if ((Sha $author.profile_path) -ne $author.profile_before_sha256 -or $profile.approved -ne $false -or $profile.inventory_authorized -ne $false -or $null -ne $profile.expected_cases -or @($profile.source_pins.PSObject.Properties).Count -ne 168) {throw 'Exact unapproved 168-pin baseline required.'}
    foreach ($pin in $profile.source_pins.PSObject.Properties) {if ((Sha (Join-Path $root $pin.Name)) -ne $pin.Value) {throw ('Live source changed: '+$pin.Name)}}
    foreach ($pin in $author.installed_tools.PSObject.Properties) {if ((Sha $pin.Name) -ne $pin.Value) {throw 'Installed formatter/config input changed.'}}
    foreach ($pin in $author.history_pins) {if ((Sha $pin.path) -ne $pin.sha256) {throw 'Original failed/reviewed/accepted history changed.'}}
    if ((Sha $php) -ne $author.php_sha256 -or (Test-Path -LiteralPath (Join-Path $root 'pint.json')) -or (Sha (Join-Path $packet 'verify-format.php')) -ne $author.verify_format_reuse.sha256) {throw 'Reviewed formatter/runtime/token configuration changed.'}
}
function Slot {
    $all=@(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    $peers=@($all | Where-Object {$_.Name -ieq 'mysql.exe' -or ($_.Name -match '^php.*\.exe$' -and ([string]::IsNullOrWhiteSpace($_.CommandLine) -or $_.CommandLine -notmatch '(?:\s-S\s|artisan\s+serve)'))})
    $os=Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10
    $cpu=@(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
    $free=[math]::Floor([long]$os.FreePhysicalMemory/1024)
    $percent=$(if ($cpu.Count -eq 1 -and $null -ne $cpu[0].PercentProcessorTime) {[int]$cpu[0].PercentProcessorTime} else {$null})
    $sample=[ordered]@{at_utc=[DateTimeOffset]::UtcNow.ToString('o');free_mib=$free;cpu_percent=$percent;peer_php_or_import_pids=@($peers | ForEach-Object {[int]$_.ProcessId})}
    $script:samples+=@($sample)
    if ($free -lt 3072 -or $null -eq $percent -or $percent -gt 85 -or $peers.Count -ne 0) {throw 'HOLD: formatter requires >=3072 MiB, CPU<=85, zero non-preview PHP/imports.'}
    return @($all | Where-Object {$_.Name -match '^php.*\.exe$'} | ForEach-Object {@{pid=[int]$_.ProcessId;birth=$_.CreationDate.ToUniversalTime().ToString('o');executable=$_.ExecutablePath;command=$_.CommandLine}})
}
$mutex=[Threading.Mutex]::new($false,'Local\OblivionWorkforceMainIntegrationNativeGate')
$held=$false; $samples=@(); $protected=@(); $drift=@(); $steps=@(); $issue=$null; $state='HELD_OR_FAILED'
$started=[DateTimeOffset]::UtcNow
try {
    try {$held=$mutex.WaitOne(0)} catch [Threading.AbandonedMutexException] {$held=$true}
    if (!$held) {throw 'HOLD: existing shared native/import gate busy.'}
    Assert-Originals
    $protected=@(Slot)
    foreach ($file in $author.files) {foreach ($kind in @('baseline','proposed')) {if ((Sha (Join-Path $packet ($kind+'/'+$file.path))) -ne $file.before_sha256) {throw 'Exact inactive copies required before formatter.'}}}
    Push-Location -LiteralPath $root
    try {
        if ((git rev-parse HEAD).Trim() -ne $author.expected_head) {throw 'Exact Delivery HEAD required.'}
        $copies=@($author.files | ForEach-Object {Join-Path $packet ('proposed/'+$_.path)})
        & $php -d memory_limit=256M vendor/bin/pint --format=json @copies 1> (Join-Path $packet 'pint-format.stdout.log') 2> (Join-Path $packet 'pint-format.stderr.log')
        $steps+=@{name='pint-format-copies';exit_code=$LASTEXITCODE}
        if ($LASTEXITCODE -ne 0) {throw 'Formatter failed; preserve inactive result.'}
        $null=Slot
        & $php -d memory_limit=256M vendor/bin/pint --test --format=json @copies 1> (Join-Path $packet 'pint-test.stdout.log') 2> (Join-Path $packet 'pint-test.stderr.log')
        $steps+=@{name='pint-test-copies';exit_code=$LASTEXITCODE}
        if ($LASTEXITCODE -ne 0) {throw 'Formatted copies still fail installed Pint.'}
        $null=Slot
        & $php -n -d memory_limit=256M (Join-Path $packet 'verify-format.php') 1> (Join-Path $packet 'token-proof.json') 2> (Join-Path $packet 'token-proof.stderr.log')
        $steps+=@{name='no-ini-token-parse-equivalence';exit_code=$LASTEXITCODE}
        if ($LASTEXITCODE -ne 0) {throw 'Non-format token/import change or syntax error.'}
        $index=0
        foreach ($copy in $copies) {
            $index++; $null=Slot
            & $php -n -d memory_limit=256M -l $copy 1> (Join-Path $packet ('syntax-'+$index+'.stdout.log')) 2> (Join-Path $packet ('syntax-'+$index+'.stderr.log'))
            $steps+=@{name=('syntax-copy-'+$index);exit_code=$LASTEXITCODE}
            if ($LASTEXITCODE -ne 0) {throw 'Copy syntax failed.'}
        }
        $state='INACTIVE_FORMAT_TOKEN_SYNTAX_CLEAR'
    } finally {Pop-Location}
} catch {$issue=$_.Exception.Message}
finally {
    try {Assert-Originals} catch {$state='HELD_OR_FAILED';$issue=([string]$issue+'; originals: '+$_.Exception.Message).Trim('; ')}
    try {
        foreach ($old in $protected) {
            $now=Get-CimInstance Win32_Process -Filter ('ProcessId='+$old.pid) -OperationTimeoutSec 10
            if (!$now -or $now.CreationDate.ToUniversalTime().ToString('o') -ne $old.birth -or $now.ExecutablePath -ne $old.executable -or $now.CommandLine -ne $old.command) {$drift+=$old.pid}
        }
        if ($drift.Count) {$state='HELD_OR_FAILED';$issue=([string]$issue+'; protected preview identity drift').Trim('; ')}
    } catch {$state='HELD_OR_FAILED';$issue=([string]$issue+'; protected check unavailable').Trim('; ')}
    if ($held) {$mutex.ReleaseMutex()};$mutex.Dispose()
}
$result=[ordered]@{state=$state;started_at_utc=$started.ToString('o');completed_at_utc=[DateTimeOffset]::UtcNow.ToString('o');minimum_free_mib=3072;maximum_cpu_percent=85;php_memory_limit='256M';samples=$samples;protected_processes=$protected;protected_drift=$drift;steps=$steps;issue=$issue;profile_before_sha256=$author.profile_before_sha256;live_source_pins_unchanged=168;product_applied=$false;inventory_or_native_authorized=$false;framework_or_database_invoked=$false}
$result | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $resultPath -Encoding utf8
$result | Select-Object state,steps,issue | ConvertTo-Json -Depth 5
if ($state -ne 'INACTIVE_FORMAT_TOKEN_SYNTAX_CLEAR') {exit 75}
