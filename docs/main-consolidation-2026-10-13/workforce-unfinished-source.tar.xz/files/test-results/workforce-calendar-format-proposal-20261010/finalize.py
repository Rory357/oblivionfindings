import difflib
import hashlib
import json
import re
from pathlib import Path

packet = Path(__file__).resolve().parent
primary = packet.parent.parent
author = json.loads((packet / 'authoring.json').read_bytes())
delivery = Path(author['root'])

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def json_read(path):
    data = path.read_bytes()
    return json.loads(data.decode('utf-16' if data[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig'))

def write_json(path, value):
    if path.exists():
        raise RuntimeError('Preserve existing final proof: ' + str(path))
    path.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')

attempts = sorted(packet.glob('actual-r*/format-result.json')) + sorted(packet.glob('source-only-r*/format-result.json'))
passed = [path for path in attempts if json_read(path)['state'] == 'INACTIVE_FORMAT_TOKEN_SYNTAX_CLEAR']
if len(passed) != 1:
    raise RuntimeError('Exactly one actual copied-source formatting/token/syntax success required.')
actual_dir = passed[0].parent
actual = json_read(passed[0])
assert actual['product_applied'] is False and actual['framework_or_database_invoked'] is False
assert actual['inventory_or_native_authorized'] is False and not actual['protected_drift']
assert len(actual['steps']) == 5 and all(row['exit_code'] == 0 for row in actual['steps'])
assert actual['minimum_free_mib'] == 6144 and actual['maximum_cpu_percent'] == 50
assert actual['php_memory_limit'] == '256M' and actual['source_only_peer_test_concurrency_authorized'] is True
assert actual['peer_processes_observed_only'] is True
assert actual['samples'] and all(row['free_mib'] >= 6144 and row['cpu_percent'] <= 50 and not row['blocked_php_or_import_pids'] for row in actual['samples'])
token = json_read(actual_dir / 'token-proof.json')
assert token['state'] == 'INACTIVE_FORMAT_ONLY_TOKEN_IMPORT_SYNTAX_CLEAR'
assert len(token['files']) == 2 and token['product_applied'] is False
assert token['framework_or_database_loaded'] is False
before_profile_path = packet / 'profile.before.json'
assert sha(before_profile_path) == author['profile_before_sha256'] == sha(Path(author['profile_path']))
before = json.loads(before_profile_path.read_bytes())
assert len(before['source_pins']) == 168
for path, expected in before['source_pins'].items():
    assert sha(delivery / path) == expected, path
for record in author['history_pins']:
    assert sha(Path(record['path'])) == record['sha256'], record['path']
for copied in (packet / 'failed-source-r1-reference').iterdir():
    if copied.is_file():
        original = primary / 'test-results/workforce-calendar-native-checks-20261010/source-r1' / copied.name
        assert copied.read_bytes() == original.read_bytes()
for path, expected in author['installed_tools'].items():
    assert sha(Path(path)) == expected, path
assert sha(Path(author['php_path'])) == author['php_sha256']
for item in author['pint_configuration']['captured_installed_config_sources']:
    assert sha(packet / item['path']) == item['sha256']

guard_baseline = (packet / 'format-copies.ps1').read_bytes()
guard_proposed = (packet / 'format-copies-source-only.ps1').read_bytes()
guard_patch = ''.join(difflib.unified_diff(guard_baseline.decode('utf-8').splitlines(keepends=True), guard_proposed.decode('utf-8').splitlines(keepends=True), fromfile='a/format-copies.ps1', tofile='b/format-copies-source-only.ps1')).encode('utf-8')
(packet / 'source-only-guard.patch').write_bytes(guard_patch)
write_json(packet / 'source-only-profile.json', {
    'scope': 'Parent-authorised two inactive copies only; no native/list/browser authority',
    'minimum_free_mib': 6144, 'maximum_cpu_percent': 50, 'php_memory_limit': '256M',
    'shared_mutex': 'Local\\OblivionWorkforceMainIntegrationNativeGate',
    'identified_peer_tests': 'Observed only; no stop/mutation; unknown PHP and mysql imports still deny',
    'protected_previews': 'Exact PID/birth/executable/command comparison retained',
    'cache_paths': [str((actual_dir / name).relative_to(packet)) for name in ['pint-format.cache', 'pint-test.cache']],
    'original_zero_peer_guard_sha256': sha(packet / 'format-copies.ps1'),
    'separate_source_only_guard_sha256': sha(packet / 'format-copies-source-only.ps1'),
    'actual_copied_source_result_sha256': sha(passed[0]),
    'original_zero_peer_attempts_retained': len(list(packet.glob('actual-r*/format-result.json'))),
    'native_inventory_browser_guards_changed': False,
})

utility = (primary / 'test-results/workforce-leave-review-read-integration-plan-20261010/independent-eligibility-review.py').read_text(encoding='utf-8')
scope = {'re': re}
exec(utility[utility.index('def patch_sections('):utility.index('\nforward = ')], scope)

def patch_for(rows, reverse=False):
    parts = []
    for path, baseline, proposed in rows:
        old, new = (proposed, baseline) if reverse else (baseline, proposed)
        parts.append(''.join(difflib.unified_diff(old.decode('utf-8').splitlines(keepends=True), new.decode('utf-8').splitlines(keepends=True), fromfile='a/'+path, tofile='b/'+path)))
    return ''.join(parts).encode('utf-8')

sources = []
transitions = []
profile_text = before_profile_path.read_text(encoding='utf-8')
for row in author['files']:
    path = row['path']
    raw = (packet / 'baseline' / path).read_bytes()
    formatted = (packet / 'proposed' / path).read_bytes()
    before_sha, after_sha = hashlib.sha256(raw).hexdigest(), hashlib.sha256(formatted).hexdigest()
    assert before_sha == row['before_sha256'] == sha(delivery / path)
    assert before_sha != after_sha
    proof = next(item for item in token['files'] if item['path'] == path)
    assert proof['before_sha256'] == before_sha and proof['after_sha256'] == after_sha
    assert proof['imports_exact_as_set'] is True and proof['all_other_non_whitespace_tokens_exact'] is True
    assert profile_text.count(before_sha) == 1
    profile_text = profile_text.replace(before_sha, after_sha)
    sources.append((path, raw, formatted))
    transitions.append({'path': path, 'before_sha256': before_sha, 'after_sha256': after_sha})
after_profile = json.loads(profile_text)
expected_after = json.loads(before_profile_path.read_bytes())
for row in transitions:
    expected_after['source_pins'][row['path']] = row['after_sha256']
assert after_profile == expected_after
assert len(after_profile['source_pins']) == 168
assert after_profile['approved'] is False and after_profile['inventory_authorized'] is False
assert after_profile['framework_enumerated'] is False and after_profile['expected_cases'] is None
assert after_profile['inventory_sha256'] is None
(packet / 'profile.proposed.json').write_text(profile_text, encoding='utf-8')
source_patch = patch_for(sources)
inverse_patch = patch_for(sources, True)
(packet / 'repair.patch').write_bytes(source_patch)
(packet / 'inverse.patch').write_bytes(inverse_patch)
sections = scope['patch_sections'](source_patch)
inverse_sections = scope['patch_sections'](inverse_patch)
assert len(sections) == len(inverse_sections) == 2
for (_, baseline, proposed), forward, inverse in zip(sources, sections, inverse_sections):
    assert scope['apply_section'](baseline, forward) == proposed
    assert scope['apply_section'](proposed, forward, reverse=True) == baseline
    assert scope['apply_section'](proposed, inverse) == baseline
profile_patch = patch_for([('test-results/delivery-calendar-r2-20261010/profile.json', before_profile_path.read_bytes(), (packet / 'profile.proposed.json').read_bytes())])
(packet / 'profile.patch').write_bytes(profile_patch)
section = scope['patch_sections'](profile_patch)[0]
assert scope['apply_section'](before_profile_path.read_bytes(), section) == (packet / 'profile.proposed.json').read_bytes()
assert scope['apply_section']((packet / 'profile.proposed.json').read_bytes(), section, reverse=True) == before_profile_path.read_bytes()
guard_section = scope['patch_sections'](guard_patch)[0]
assert scope['apply_section'](guard_baseline, guard_section) == guard_proposed
assert scope['apply_section'](guard_proposed, guard_section, reverse=True) == guard_baseline

old_map = before['source_pins']
new_map = after_profile['source_pins']
write_json(packet / 'source168-before.json', old_map)
write_json(packet / 'source168-proposed.json', new_map)
changed = [path for path in old_map if old_map[path] != new_map[path]]
assert changed == [row['path'] for row in transitions]
write_json(packet / 'proof.json', {
    'status': 'INACTIVE_FORMAT_ONLY_ACTUAL_STATIC_CLEAR',
    'source_transitions': transitions, 'source_pin_count_before': 168, 'source_pin_count_after': 168,
    'whole_two_source_forward_reverse_inverse_exact': True,
    'profile_forward_reverse_exact': True, 'profile_only_two_source_pins_changed': True,
    'approval_inventory_selection_process_resource_database_fields_unchanged': True,
    'token_proof_path': str((actual_dir / 'token-proof.json').relative_to(packet)),
    'actual_result_path': str(passed[0].relative_to(packet)),
    'actual_static_steps': actual['steps'], 'protected_preview_drift': actual['protected_drift'],
    'source_only_resource_profile_sha256': sha(packet / 'source-only-profile.json'),
    'separate_source_only_guard_forward_inverse_exact': True,
    'native_inventory_browser_guards_unchanged': True,
    'installed_config': author['pint_configuration'],
    'live_delivery_168_source_pins_and_profile_unchanged': True,
    'original_failed_source_r1_reference_exact': True,
    'history_pin_count': len(author['history_pins']), 'history_drift': [],
    'product_applied': False, 'framework_listing_or_native_cases_run': False,
    'actual_case_count': None, 'native_or_inventory_permission_granted': False,
})
write_json(packet / 'manifest.json', {
    'status': 'INACTIVE_CALENDAR_TWO_SOURCE_FORMAT_TRANSITION_REVIEW_READY',
    'product_applied': False, 'approved': False, 'inventory_authorized': False, 'actual_case_count': None,
    'delivery_root': str(delivery), 'expected_head': author['expected_head'],
    'source_transitions': transitions,
    'profile_before_sha256': sha(before_profile_path), 'profile_proposed_sha256': sha(packet / 'profile.proposed.json'),
    'repair_patch_sha256': sha(packet / 'repair.patch'), 'profile_patch_sha256': sha(packet / 'profile.patch'),
    'proof_sha256': sha(packet / 'proof.json'),
    'files': [{'path': str(p.relative_to(packet)).replace('\\', '/'), 'sha256': sha(p)} for p in sorted(packet.rglob('*')) if p.is_file()],
    'limitations': ['Formatting/token/syntax checks ran only on inactive copies; no product application or framework/DB/native scenario.', 'Calendar58 remains source-derived; accepted Leave R4 and historical Return/Coverage results are separate immutable evidence.', 'Parent review/application and fresh source-static checks precede any explicit framework inventory or native permission.'],
})
print(json.dumps({'manifest_sha256': sha(packet / 'manifest.json'), 'proof_sha256': sha(packet / 'proof.json'), 'source_transitions': transitions, 'profile_proposed_sha256': sha(packet / 'profile.proposed.json')}))
