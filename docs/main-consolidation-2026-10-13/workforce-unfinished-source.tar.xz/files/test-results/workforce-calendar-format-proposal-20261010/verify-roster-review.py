"""Independent pure file/hash/diff review. Executes no PHP or proposal script."""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import bz2
import json
from pathlib import Path
import re
import struct
import zlib

P = Path(__file__).resolve().parent
ROOT = P.parent.parent
def read(p):
    raw = Path(p).read_bytes()
    return json.loads(raw.decode('utf-16' if raw[:2] in (b'\xff\xfe', b'\xfe\xff') else 'utf-8-sig'))
def digest(p):
    return sha256(Path(p).read_bytes()).hexdigest()
def pin(p, h):
    assert digest(p) == h, str(p)
def sections(path):
    raw = Path(path).read_bytes()
    return [b'--- a/' + x for x in raw.split(b'--- a/')[1:]]
def apply(raw, section, reverse=False):
    source = raw.splitlines(keepends=True)
    lines = section.splitlines(keepends=True)
    result, pos, index = [], 0, 2
    while index < len(lines):
        header = re.match(rb'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[index])
        assert header, lines[index]
        start = int(header[3 if reverse else 1]) - 1
        assert start >= pos
        result.extend(source[pos:start]); pos = start; index += 1
        while index < len(lines) and not lines[index].startswith(b'@@ '):
            flag, text = lines[index][:1], lines[index][1:]
            assert flag in (b' ', b'+', b'-')
            if reverse:
                flag = {b'+': b'-', b'-': b'+', b' ': b' '}[flag]
            if flag in (b' ', b'-'):
                assert source[pos] == text, (pos, source[pos], text)
                pos += 1
            if flag in (b' ', b'+'):
                result.append(text)
            index += 1
    result.extend(source[pos:])
    return b''.join(result)

pin(P / 'manifest.json', 'c591b2399b76264bcc77dd75493a88f75549535ccbd012c58b48929bdcaca618')
m = read(P / 'manifest.json')
for row in m['files']:
    pin(P / row['path'], row['sha256'])
a = read(P / 'authoring.json')
delivery = Path(a['root'])
before = read(P / 'profile.before.json')
after = read(P / 'profile.proposed.json')
pin(a['profile_path'], m['profile_before_sha256'])
assert Path(a['profile_path']).read_bytes() == (P / 'profile.before.json').read_bytes()
old_map, new_map = before['source_pins'], after['source_pins']
assert len(old_map) == len(new_map) == 168
assert old_map == read(P / 'source168-before.json') and new_map == read(P / 'source168-proposed.json')
assert set(old_map) == set(new_map)
changed = [path for path in old_map if old_map[path] != new_map[path]]
assert changed == [x['path'] for x in m['source_transitions']]
expected = json.loads(json.dumps(before))
forward, inverse = sections(P / 'repair.patch'), sections(P / 'inverse.patch')
assert len(forward) == len(inverse) == len(m['source_transitions']) == 2
for row, fwd, inv in zip(m['source_transitions'], forward, inverse):
    path = row['path']
    pin(P / 'baseline' / path, row['before_sha256'])
    pin(P / 'proposed' / path, row['after_sha256'])
    old = (P / 'baseline' / path).read_bytes(); new = (P / 'proposed' / path).read_bytes()
    assert apply(old, fwd) == new and apply(new, fwd, True) == old and apply(new, inv) == old and apply(old, inv, True) == new
    # The complete actual source delta is only import order and blank lines.
    old_lines, new_lines = old.splitlines(keepends=True), new.splitlines(keepends=True)
    assert Counter(x for x in old_lines if x.startswith(b'use ')) == Counter(x for x in new_lines if x.startswith(b'use '))
    clean = lambda ls: [x for x in ls if x.strip() and not x.startswith(b'use ')]
    assert clean(old_lines) == clean(new_lines)
    assert old_map[path] == row['before_sha256'] and new_map[path] == row['after_sha256']
    expected['source_pins'][path] = row['after_sha256']
assert after == expected
profile_section = sections(P / 'profile.patch')
assert len(profile_section) == 1
old_profile = (P / 'profile.before.json').read_bytes(); new_profile = (P / 'profile.proposed.json').read_bytes()
assert apply(old_profile, profile_section[0]) == new_profile and apply(new_profile, profile_section[0], True) == old_profile
for path, h in old_map.items():
    pin(delivery / path, h)
for name, h in before['tools'].items():
    pin(Path(a['profile_path']).parent / name, h)
pin(delivery / before['schema']['path'], before['schema']['sha256'])
assert before['approved'] is False and before['inventory_authorized'] is False and before['framework_enumerated'] is False
assert before['expected_cases'] is None and before['inventory_sha256'] is None
assert before['minimum_free_mib'] == 4096 and before['maximum_cpu_percent'] == 85
for path, h in a['installed_tools'].items():
    pin(path, h)
pin(a['php_path'], a['php_sha256'])
pin(a['verify_format_reuse']['path'], a['verify_format_reuse']['sha256'])
assert digest(P / 'verify-format.php') == a['verify_format_reuse']['sha256']
assert not (delivery / 'pint.json').exists()
# Independently recover the five recorded configuration files from the pinned PHAR.
data = (delivery / 'vendor/laravel/pint/builds/pint').read_bytes()
pos = data.index(b'__HALT_COMPILER();') + len(b'__HALT_COMPILER(); ?>\r\n')
length = struct.unpack_from('<I', data, pos)[0]; pos += 4; body = pos + length
count = struct.unpack_from('<I', data, pos)[0]; pos += 10
for _ in range(2):
    length = struct.unpack_from('<I', data, pos)[0]; pos += 4 + length
entries = []
for _ in range(count):
    length = struct.unpack_from('<I', data, pos)[0]; pos += 4
    name = data[pos:pos+length].decode('utf-8'); pos += length
    size, stamp, compressed, crc, flags, metadata = struct.unpack_from('<IIIIII', data, pos); pos += 24 + metadata
    entries.append((name, size, compressed, crc, flags))
wanted = {x['phar_entry']: x for x in a['pint_configuration']['captured_installed_config_sources']}
found = set()
for name, size, compressed, crc, flags in entries:
    raw = data[body:body+compressed]; body += compressed
    if name not in wanted:
        continue
    content = zlib.decompress(raw, -15) if flags & 0x1000 else bz2.decompress(raw) if flags & 0x2000 else raw
    assert len(content) == size and zlib.crc32(content) & 0xffffffff == crc
    assert content == (P / wanted[name]['path']).read_bytes()
    found.add(name)
assert found == set(wanted) and len(found) == 5
repo = (P / 'installed-format-configuration/app/Repositories/ConfigurationJsonRepository.php').read_text()
resolver = (P / 'installed-format-configuration/app/Factories/ConfigurationResolverFactory.php').read_text()
assert "['preset'] ?? 'laravel'" in repo and "getOption('cache-file')" in resolver
result = read(P / 'source-only-r1/format-result.json')
assert result['state'] == 'INACTIVE_FORMAT_TOKEN_SYNTAX_CLEAR' and result['issue'] is None
assert result['minimum_free_mib'] == 6144 and result['maximum_cpu_percent'] == 50 and result['php_memory_limit'] == '256M'
assert result['steps'] == read(P / 'proof.json')['actual_static_steps'] and len(result['steps']) == 5
assert all(x['exit_code'] == 0 for x in result['steps']) and result['protected_drift'] == []
assert all(x['free_mib'] >= 6144 and x['cpu_percent'] <= 50 and x['blocked_php_or_import_pids'] == [] for x in result['samples'])
for field in ('product_applied', 'inventory_or_native_authorized', 'framework_or_database_invoked'):
    assert result[field] is False
token = read(P / 'source-only-r1/token-proof.json')
assert token['files'] and token['product_applied'] is False and token['framework_or_database_loaded'] is False
for row, transition in zip(token['files'], m['source_transitions']):
    assert all(row[k] == transition[k] for k in ('path', 'before_sha256', 'after_sha256'))
    assert row['imports_exact_as_set'] and row['all_other_non_whitespace_tokens_exact']
assert read(P / 'source-only-r1/pint-format.stdout.log')['result'] == 'fixed'
assert read(P / 'source-only-r1/pint-test.stdout.log')['result'] == 'passed'
for path in (P / 'source-only-r1').glob('*.stderr.log'):
    assert path.read_bytes() == b''
for n in (1, 2):
    assert 'No syntax errors detected' in (P / f'source-only-r1/syntax-{n}.stdout.log').read_text(encoding='utf-8-sig')
holds = list(P.glob('actual-r*/format-result.json'))
assert len(holds) == 16
for p in holds:
    value = read(p)
    assert value['state'] == 'HELD_OR_FAILED' and value['steps'] == [] and value['product_applied'] is False
for record in a['history_pins']:
    pin(record['path'], record['sha256'])
for p in (P / 'failed-source-r1-reference').iterdir():
    assert p.read_bytes() == (ROOT / 'test-results/workforce-calendar-native-checks-20261010/source-r1' / p.name).read_bytes()
assert read(P / 'failed-source-r1-reference/result.json')['pint_exit'] == 1
history_files = 0
for parent_packet in ('workforce-calendar-feed-proposal-r2-20261010', 'workforce-calendar-native-tools-proposal-r2-20261010'):
    folder = ROOT / 'test-results' / parent_packet
    for row in read(folder / 'manifest.json')['files']:
        pin(folder / row['path'], row['sha256']); history_files += 1
guard = (P / 'format-copies.ps1').read_bytes(); source_only = (P / 'format-copies-source-only.ps1').read_bytes()
g = sections(P / 'source-only-guard.patch')
assert len(g) == 1 and apply(guard, g[0]) == source_only and apply(source_only, g[0], True) == guard
assert b'zero non-preview PHP/imports' in guard and b'--cache-file=' in source_only
assert b'Stop-Process' not in source_only and b'.Kill(' not in source_only
report = {
    'status': 'CLEAR_FORMAT_ONLY_SOURCE_PROFILE_TRANSITION',
    'reviewed_utc': datetime.now(timezone.utc).isoformat(),
    'manifest_sha256': digest(P / 'manifest.json'),
    'repair_patch_sha256': digest(P / 'repair.patch'),
    'profile_patch_sha256': digest(P / 'profile.patch'),
    'verification_script_sha256': digest(__file__),
    'authored_hashes_checked': len(m['files']),
    'whole2_forward_reverse_explicit_inverse_exact': True,
    'complete_source_delta_only_import_order_and_blank_lines': True,
    'recorded_TOKEN_PARSE_import_multiset_and_non_whitespace_tokens_exact': True,
    'profile_whole_forward_reverse_exact_and_only2_source_pin_fields_changed': True,
    'current168_before_and_candidate168_after_maps_exact': True,
    'all8_native_tools_and_sealed_schema_unchanged': True,
    'installed7_formatter_inputs_and5_PHAR_config_sources_exact': True,
    'installed_default_laravel_preset_no_root_config_private_caches_only': True,
    'actual_copied_checks': result['steps'],
    'source_only_guard_separate_and_full_inverse_exact': True,
    'original16_zero_peer_holds_and_failed_Pint_preserved': True,
    'history_pin_count_checked': len(a['history_pins']),
    'original_source_and_tool_candidate_authored_records_checked': history_files,
    'native_approval_false_framework_count_null_unchanged': True,
    'source_transitions': m['source_transitions'],
    'profile_before_sha256': m['profile_before_sha256'],
    'profile_after_sha256': m['profile_proposed_sha256'],
    'findings': [],
    'scope_limits': [
        'Independent review performed pure file/hash/diff/JSON and PHAR-byte comparisons only; no PHP/parser/formatter/framework/runtime/database/gate/process/application action invoked.',
        'Recorded formatter, Pint-test, TOKEN_PARSE and syntax success concern only inactive copies under the separately authorised source-only guard. Native/list/browser guards and approvals remain unchanged.',
        'The profile JSON has a serialization line-ending change; decoded data differs only at the two named source_pins, and both complete byte directions reconstruct exactly.',
        'This clearance supports parent application of only the two formatted PHP files and their two profile pins. It supplies no framework listing/native permission or acceptance; prospective58 cases remain source-derived.',
        'Current-main/eMAR/phone20, production build, real browser and broader programme acceptance are not changed or certified.'
    ]
}
(P / 'independent-roster-review.json').write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
(P / 'independent-roster-review.md').write_text('CLEAR for the two formatting-only PHP transitions and their profile pins. Full source forwards/reverses/inverses match; every nonblank line outside the unchanged import multiset is exact. The installed default Laravel preset and actual copied-source Pint/Pint-test/TOKEN_PARSE/two syntax results bind the proposed hashes, all exit0.\n\nAll168 current pins match; the proposed168 map changes only the two PHP hashes. All native tools, selection, resource/ownership/cleanup fields, false approvals and null inventory remain unchanged. JSON line-ending serialization differs, with complete byte reversibility. Original failed Pint,16 zero-peer holds,24 history pins and earlier source/tool review packets remain exact.\n\nIndependent review used pure file/hash/diff/JSON/PHAR-byte comparisons only. Parent may apply the two files and two profile pins; no framework/native/build/browser or current-main/programme acceptance is supplied.\n', encoding='utf-8')
print(json.dumps(dict(status=report['status'], review_sha256=digest(P / 'independent-roster-review.json'), md_sha256=digest(P / 'independent-roster-review.md'), script_sha256=digest(__file__), authored=len(m['files']), history_authored=history_files)))
