from pathlib import Path
import hashlib, json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-coordinated-command-hook-proposal-r2-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-coordinated-callers-proposal-20261012'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def emit(name, raw):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), name
    p.write_bytes(raw)
def replace(text, old, new):
    assert text.count(old) == 1, old[:100]
    return text.replace(old, new)

assert not OUT.exists()
assert sha((BASE / 'manifest.json').read_bytes()) == '388c05f80ed32ce825a7e935ed1d76bbe463877786d615d22c6072a2de306967'
parent = json.loads((BASE / 'manifest.json').read_bytes())
for name, digest in parent['files'].items(): assert sha((BASE / name).read_bytes()) == digest, name
pins = dict(parent['dependencies'])
for name, digest in pins.items(): assert sha((ROOT / name).read_bytes()) == digest, name
for name in [BASE.relative_to(ROOT).as_posix() + '/manifest.json',
             BASE.relative_to(ROOT).as_posix() + '/source-proof.json']:
    pins[name] = sha((ROOT / name).read_bytes())
review = 'test-results/workforce-timesheet-coordinated-command-hook-r2-independent-review-20261012/review.json'
assert sha((ROOT / review).read_bytes()) == '6259b732bc7810ec452e3870aebe73c3f8dc7e365d0205b427081678e67b2383'
assert json.loads((ROOT / review).read_bytes())['status'] == 'CLEAR_SOURCE_ONLY'
pins[review] = sha((ROOT / review).read_bytes())

prefix = 'resources/js/components/timesheets/'
wizard_name = prefix + 'timesheet-wizard.tsx'
action_name = prefix + 'timesheet-action-dialog.tsx'
edit_name = prefix + 'edit-timesheet-dialog.tsx'
view_name = prefix + 'view-timesheet-dialog.tsx'
wizard = (BASE / 'proposed' / wizard_name).read_bytes().decode()
wizard = replace(wizard, '''    canSubmit?: boolean;
    workerTimezone?: string;
};''', '''    canSubmit?: boolean;
    workerTimezone?: string;
    /** Explicit shared page coordination; omit only for independent legacy hosts. */
    writeCoordination?: Parameters<typeof useTimesheetCommand>[1];
};''')
wizard = replace(wizard, '''        `${currentActorId}:${record?.id ?? 'create'}:${canSave}:${canSubmit}:${timesheetEditContext(record)}`,
    );''', '''        `${currentActorId}:${record?.id ?? 'create'}:${canSave}:${canSubmit}:${timesheetEditContext(record)}`,
        props.writeCoordination,
    );''')
edit = (BASE / 'proposed' / edit_name).read_bytes().decode()
edit = replace(edit, '    type EditTimesheetRow,', '    type EditTimesheetRow,\n    type TimesheetWizardProps,')
edit = replace(edit, '    workerTimezone,\n}: {', '    workerTimezone,\n    writeCoordination,\n}: {')
edit = replace(edit, '    workerTimezone?: string;\n}) {', "    workerTimezone?: string;\n    writeCoordination?: TimesheetWizardProps['writeCoordination'];\n}) {")
edit = replace(edit, '            workerTimezone={workerTimezone}', '            workerTimezone={workerTimezone}\n            writeCoordination={writeCoordination}')
action = (BASE / 'proposed' / action_name).read_bytes().decode()
action = replace(action, '    canAct: boolean;\n    onOpenChange:', '    canAct: boolean;\n    writeCoordination?: Parameters<typeof useTimesheetCommand>[1];\n    onOpenChange:')
action = replace(action, '    canAct,\n    onOpenChange,', '    canAct,\n    writeCoordination,\n    onOpenChange,')
action = replace(action, '''        `${currentActor}:${record.id}:${record.staff?.id ?? record.user_id}:${record.shift?.id ?? ''}:${currentClientId}:${action}:${canAct}`,
    );''', '''        `${currentActor}:${record.id}:${record.staff?.id ?? record.user_id}:${record.shift?.id ?? ''}:${currentClientId}:${action}:${canAct}`,
        writeCoordination,
    );''')
view_before = (ROOT / view_name).read_bytes()
assert sha(view_before) == '6c08f8d05fde0654a06fa91d54f09e7de567aa53b07165f4b16338c5f3f169f9'
view = view_before.decode()
view = replace(view, '    canSubmit,\n}: {', '    canSubmit,\n    writeCoordination,\n}: {')
view = replace(view, '    canSubmit?: boolean;\n}) {', "    canSubmit?: boolean;\n    writeCoordination?: Parameters<typeof TimesheetActionDialog>[0]['writeCoordination'];\n}) {")
view = replace(view, '                    action={reasonAction}\n                    record={t}', '                    action={reasonAction}\n                    record={t}\n                    writeCoordination={writeCoordination}')
images = {wizard_name: wizard.encode(), edit_name: edit.encode(), action_name: action.encode(), view_name: view.encode()}
fixture_specs = [
    ('timesheet-wizard.test.tsx', 'wizard', 3),
    ('timesheet-action-dialog.test.tsx', 'action', 1),
    ('view-timesheet-permissions.test.tsx', 'view', 1),
]
for basename, suffix, count in fixture_specs:
    name = prefix + basename
    old = (BASE / 'proposed' / name).read_bytes()
    extra = (ROOT / f'test-results/workforce-timesheet-coordinated-callers-{suffix}-fixtures-20261012.txt').read_bytes()
    assert sum(line.startswith(b"it('") for line in extra.splitlines()) == count
    addition_import = b"import { TimesheetWriteScope } from './timesheet-write-scope';\n" if suffix != 'view' else b''
    if suffix == 'wizard':
        addition_import += b"import { TimesheetActionDialog } from './timesheet-action-dialog';\n"
    raw = addition_import + old + extra
    assert raw[len(addition_import):len(addition_import)+len(old)] == old
    images[name] = raw

entries = [(name, (BASE / 'before' / name).read_bytes(), (BASE / 'proposed' / name).read_bytes()) for name in parent['sources']]
entries.append((view_name, view_before, view_before))
files, sources, unchanged = {}, {}, []
for name, before, prior in entries:
    after = images.get(name, prior)
    assert ((ROOT / name).read_bytes() if (ROOT / name).exists() else b'') == before, name
    if after == prior: unchanged.append(name)
    sources[name] = {'before_exists': (ROOT / name).exists(), 'before_sha256': sha(before),
        'parent_sha256': sha(prior), 'after_sha256': sha(after)}
    for sub, raw in [('before', before), ('parent', prior), ('proposed', after)]:
        name_in_packet = sub + '/' + name; emit(name_in_packet, raw); files[name_in_packet] = sha(raw)
    transition = {'path': name, 'before_hex': before.hex(), 'parent_hex': prior.hex(), 'after_hex': after.hex()}
    for key, raw in [('before_hex', before), ('parent_hex', prior), ('after_hex', after)]: assert bytes.fromhex(transition[key]) == raw
    name_in_packet = 'raw-transitions/' + name + '.json'; emit(name_in_packet, encoded(transition)); files[name_in_packet] = sha((OUT / name_in_packet).read_bytes())
assert len(sources) == 14 and len(unchanged) == 7
pins[view_name] = sha(view_before)
create_name = prefix + 'create-timesheet-dialog.tsx'
pins[create_name] = sha((ROOT / create_name).read_bytes())
inventory = {'status': 'UNRUN', 'retained_workflow_source_slots': 86,
    'new_actual_child_declarations': 5, 'prospective_workflow_source_slots': 91,
    'foundation_source_slots_separate': 16, 'foundation_retained_unchanged': True,
    'executed': False, 'actual_inventory': None, 'actual_count': None}
readme = '''Inactive explicit caller wiring successor to source-clear coordinated hook R2, not installed or executed.

Actual Wizard accepts and passes the explicit stable-page coordination option. Existing Create inherits the Wizard type and spreads props without a separate replacement wrapper. Nullable retained Edit forwards the option. Action accepts/forwards it to the real hook, and actual View forwards the same option to its nested review action. Omitted options preserve independent legacy hosts; explicit scope:null denies before hash/dispatch. Planned coordinated hosts must explicitly supply their stable scope or null, never silently omit on a missing-provider path. No permission comes from the coordinator. Existing current actor/source/canSave/canSubmit/canAct/target/private gates remain unchanged.

Five appended actual child source declarations: Create receives shared scope and retains visible errors/notes/unknown/no retry; retained Edit explicitly missing scope refuses sending; Create hidden with its pending command blocks a sibling Action using the same scope; Action preserves reason and visible error under unknown shared hold; View passes explicit null through its nested Action and refuses sending. Existing whole child test bytes are retained after at most one class import; real hook/scope used, only existing transport/clock UI test harness mocks. Prior86 workflow slots plus5=91 prospective slots UNRUN; separate16 foundation slots unchanged. No actual rendering/type/DOM/phone/desktop/inertia/server/lifetime acceptance is invented.

Fourteen full raw before/parent/after inverses, seven other images exact (including actual hook/hook test and all four foundation files). No hero/header/CSS/token/date semantics/new UI chrome or role/tenant change. Existing create source is pinned unchanged and its real forwarding is exercised by a prospective source fixture.

This is concrete caller wiring, still no actual owning Index/provider mount, direct bulk/archive/restore/read/correction/other hosts full exclusion or current-cohort privacy closure. Action/View still have transient owner destruction; shared scope retains uncertain exclusion but does not preserve that destroyed reason/draft or manufacture durable original command data. Root must retain actual Action owner outside transient parent conditions and finish source/privacy/Back/page-remount/recovery before activation. Visible send controls do not yet preemptively subscribe to foreign shared busy state; the hook refuses the attempted send with feedback, and the planned full UI needs that status/disabled explanation. No UUID/AFTER/root/witness/current recovery producer is implemented. Do not ship this subset as whole-page integration.

Source/pure-file only under existing environmental hold: no app edit/parser/types/lint/framework/native/build/browser/process/readiness/SQL/Git/deploy/probe/admission. Independent eMAR/Claude and Control Room unchanged. Review required, actual inventory/count null.
'''
for name, raw in [('README.md', readme.encode()), ('inventory.json', encoded(inventory)),
                  ('source-pins.json', encoded(pins)), ('author.py', Path(__file__).read_bytes())]:
    emit(name, raw); files[name] = sha(raw)
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
    'raw_transitions_exact': 14, 'unchanged_parent_images': unchanged,
    'three_parent_child_test_bodies_retained': True, 'application_input_drift': [],
    'applied': False, 'runtime_invoked': False, 'actual_inventory': None, 'actual_count': None}
raw = encoded(proof); emit('source-proof.json', raw)
manifest = {'status': 'UNAPPLIED_UNRUN_EXPLICIT_WIZARD_EDIT_ACTION_VIEW_CALLER_WIRING_ONLY',
    'sources': sources, 'files': files, 'dependencies': pins, 'inventory': inventory,
    'parent_manifest_sha256': sha((BASE / 'manifest.json').read_bytes()),
    'parent_clear_review_sha256': pins[review], 'source_proof_sha256': sha(raw),
    'applied': False, 'runtime_invoked': False, 'owning_page_integration_implemented': False, 'actual_count': None}
raw = encoded(manifest); emit('manifest.json', raw)
print(json.dumps({'manifest_sha256': sha(raw), 'source_proof_sha256': manifest['source_proof_sha256'],
    'paths': 14, 'pins': len(pins), 'unchanged_images': 7,
    'prospective_workflow_slots_unrun': 91, 'foundation_slots_unrun_separate': 16,
    'actual_inventory': None, 'applied': False}))
