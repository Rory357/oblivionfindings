from pathlib import Path
import hashlib
import json

ROOT = Path('C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-review-retention-proposal-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-review-retention-proposal-r2-20261012'
NAME = 'resources/js/pages/operations/timesheets/index-read.test.tsx'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def emit(name, raw):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), name
    path.write_bytes(raw)
    return sha(raw)

assert not OUT.exists()
base_raw = (BASE / 'manifest.json').read_bytes()
assert sha(base_raw) == 'c1fcb16ee842daf45656e82f91adf8f3712116bf65b343b1c40452b31564a694'
base = json.loads(base_raw)
for name, digest in base['files'].items():
    assert sha((BASE / name).read_bytes()) == digest, name
pins = dict(base['dependencies'])
for name, digest in pins.items():
    assert sha((ROOT / name).read_bytes()) == digest, name
pins[BASE.relative_to(ROOT).as_posix() + '/manifest.json'] = sha(base_raw)

prior = (BASE / 'proposed' / NAME).read_bytes()
marker = b"it('routes a View review callback through the real stable owner and withholds it on cohort withdrawal', () => {"
start = prior.index(marker)
end = prior.index(b"it('does not open an owning review", start)
old = prior[start:end]
new = old.replace(
    b'    const mounted = render(<TimesheetsIndex {...props} />);',
    b'    const permitted = { ...row, can_return: true };\n'
    b'    const current = { ...props, timesheets: { data: [permitted] } };\n'
    b'    const mounted = render(<TimesheetsIndex {...current} />);', 1,
).replace(b"onReviewAction(row, 'return')", b"onReviewAction(permitted, 'return')", 1).replace(
    b"    fireEvent.change(screen.getByLabelText('What needs changing?'),",
    b"    expect(screen.getByLabelText('What needs changing?')).toBeEnabled();\n"
    b"    fireEvent.change(screen.getByLabelText('What needs changing?'),", 1,
).replace(b'<TimesheetsIndex {...props} timesheets={{ data: [] }} />',
          b'<TimesheetsIndex {...current} timesheets={{ data: [] }} />', 1).replace(
    b'<TimesheetsIndex {...props} />', b'<TimesheetsIndex {...current} />', 1,
)
assert new != old
after = prior[:start] + new + prior[end:]
assert after[:start] == prior[:start] and after.endswith(prior[end:])

files, sources, unchanged = {}, {}, []
for name, source in base['sources'].items():
    before = (BASE / 'before' / name).read_bytes()
    parent = (BASE / 'proposed' / name).read_bytes()
    proposed = after if name == NAME else parent
    actual = ROOT / name
    assert actual.exists() == source['before_exists'], name
    assert (actual.read_bytes() if actual.exists() else b'') == before, name
    if proposed == parent:
        unchanged.append(name)
    sources[name] = {'before_exists': actual.exists(), 'before_sha256': sha(before),
                     'parent_sha256': sha(parent), 'after_sha256': sha(proposed)}
    for folder, raw in [('before', before), ('parent', parent), ('proposed', proposed)]:
        files[folder + '/' + name] = emit(folder + '/' + name, raw)
    transition = {'path': name, 'before_hex': before.hex(),
                  'parent_hex': parent.hex(), 'after_hex': proposed.hex()}
    for key, raw in [('before_hex', before), ('parent_hex', parent), ('after_hex', proposed)]:
        assert bytes.fromhex(transition[key]) == raw
    target = 'raw-transitions/' + name + '.json'
    files[target] = emit(target, encoded(transition))
assert len(sources) == 18 and len(unchanged) == 17
inventory = dict(base['inventory'])
readme = (
    'Inactive fixture-only successor to c1fcb16e; original packet and review remain intact.\n\n'
    'Only the new real Index/View review retention fixture changes. It now supplies a current '
    'row with can_return:true and asserts the real Action textarea is enabled before typing. '
    'The same permitted cohort is restored after withdrawal. No disabled-control synthetic '
    'change is relied on. All earlier Index cases and the other new callback case remain exact.\n\n'
    'All seventeen other proposed application/test images match the parent exactly. '
    'Source inventories stay UNRUN and actual counts null. No application-source edit, parser, '
    'framework, type, lint, build, browser, process, SQL, Git, admission or deployment occurred. '
    'No page-wide coordination, native user journey or backend receipt acceptance is inferred.\n'
)
for name, raw in [('README.md', readme.encode()), ('inventory.json', encoded(inventory)),
                  ('source-pins.json', encoded(pins)), ('author.py', Path(__file__).read_bytes())]:
    files[name] = emit(name, raw)
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
         'raw_transitions_exact': 18, 'unchanged_parent_images': unchanged,
         'fixture_change_only': NAME, 'old_index_prefix_and_suffix_exact': True,
         'application_input_drift': [], 'applied': False, 'runtime_invoked': False,
         'actual_inventory': None, 'actual_count': None}
proof_sha = emit('source-proof.json', encoded(proof))
manifest = {'status': 'UNAPPLIED_UNRUN_REVIEW_RETENTION_FIXTURE_ONLY', 'sources': sources,
            'files': files, 'dependencies': pins, 'inventory': inventory,
            'parent_manifest_sha256': sha(base_raw), 'source_proof_sha256': proof_sha,
            'applied': False, 'runtime_invoked': False,
            'page_wide_coordination_complete': False, 'actual_count': None}
manifest_sha = emit('manifest.json', encoded(manifest))
print(json.dumps({'manifest_sha256': manifest_sha, 'source_proof_sha256': proof_sha,
                  'unchanged_parent_images': len(unchanged), 'actual_count': None}))
