<?php

namespace Tests\Feature\Rostering;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Domain\Shifts\Assignment\ShiftAssignmentReceipt;
use App\Domain\Shifts\Assignment\ShiftAssignmentReturn;
use App\Domain\Shifts\Assignment\ShiftAssignmentSource;
use App\Models\Client;
use App\Models\Permission;
use App\Models\Role;
use App\Models\ServiceContext;
use App\Models\Shift;
use App\Models\ShiftEligibilityOverride;
use App\Models\ShiftOpenPosition;
use App\Models\ShiftReplacementRequest;
use App\Models\Site;
use App\Models\TimelineEvent;
use App\Models\User;
use App\Services\Eligibility\AssignmentEligibilityGateway;
use App\Services\Eligibility\EligibilityResult;
use App\Services\ShiftStaffEligibilityService;
use Illuminate\Database\Connection;
use Illuminate\Database\DatabaseTransactionsManager;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use Illuminate\Testing\TestResponse;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\Support\CommittedFixtureCleanup;
use Tests\Support\OwnedTestDatabase;
use Tests\TestCase;

/** Inactive acceptance source. Real lifecycle/gateway/workload, existing owned-database helpers only. */
class WorkforceShiftAssignmentCommandIntegrityTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;
    private Client $client;
    private ServiceContext $context;
    private User $actor;
    private User $worker;
    private bool $committed = false;

    protected function setUp(): void
    {
        parent::setUp();
        Carbon::setTestNow(Carbon::parse('2026-10-10 00:00:00.456789', 'UTC'));
        config(['app.worker_timezone' => 'Pacific/Auckland']);
        $this->beforeApplicationDestroyed(CommittedFixtureCleanup::capture()->restore(...));
        Queue::fake();
        Notification::fake();
        $this->site = Site::factory()->create(['is_active' => true, 'archived' => false, 'archived_at' => null]);
        $this->context = ServiceContext::factory()->create(['site_id' => null, 'is_active' => true, 'type' => 'residential']);
        $this->client = Client::factory()->create(['site_id' => $this->site->id, 'service_context_id' => $this->context->id, 'status' => 'active']);
        $this->actor = $this->person(['shifts.manageAny', 'shifts.viewAny', 'rostering.viewAny']);
        $this->worker = $this->person([]);
    }

    protected function tearDown(): void
    {
        try {
            DB::purge('assignment_writer');
            if ($this->committed && DB::transactionLevel() === 0) {
                DB::beginTransaction();
            }
            Carbon::setTestNow();
        } finally {
            parent::tearDown();
        }
    }

    public static function successfulAssignments(): array
    {
        return ['draft first assignment' => ['draft', false, 'scheduled'],
            'scheduled reassignment' => ['scheduled', true, 'scheduled'],
            'in progress reassignment' => ['in_progress', true, 'in_progress']];
    }

    #[DataProvider('successfulAssignments')]
    public function test_root_assign_confirms_exact_physical_tuple_and_keeps_selected_context(string $status, bool $previous, string $savedStatus): void
    {
        $row = $this->shift(['status' => $status, 'user_id' => $previous ? $this->person([])->id : null,
            'actual_starts_at' => $status === 'in_progress' ? '2026-10-20 20:00:00' : null]);
        $source = $this->candidateSource($row);
        $this->decision('pass');
        $this->commitFixtures();
        $writer = $this->writer();
        $returnTo = '/operations/rostering?week=2026-10-19&tab=calendar&staff_id='.$this->worker->id.'&client_id='.$this->client->id.'&site_id%5B0%5D='.$this->site->id;
        $uuid = (string) Str::uuid();
        $response = $this->production(fn () => $this->submit('assign', $row, $source, ['request_id' => $uuid, 'return_to' => $returnTo]));
        $response->assertRedirect($returnTo);
        $stored = $writer->table('shifts')->where('id', $row->id)->first();
        $this->assertSame($this->worker->id, (int) $stored->user_id);
        $this->assertSame($savedStatus, $stored->status);
        $this->assertSame('Exact original notes', $stored->notes);
        $receipt = $this->receipt($response, 'assign', $row, $uuid, $source);
        $this->assertSame('saved', $receipt['outcome']);
        $this->assertTrue($receipt['changed']);
        $this->assertSame($savedStatus, $receipt['status']);
        $this->assertSame($this->worker->id, $receipt['user_id']);
        $event = $writer->table('timeline_events')->where('type', 'shift_assigned')->where('source_id', $row->id)->first();
        $this->assertNotNull($event);
        $this->assertSame($this->actor->id, (int) $event->actor_user_id);
        $this->assertSame($this->worker->id, json_decode($event->meta, true)['assigned_user_id']);
        $this->assertFalse(DB::connection()->getPdo()->inTransaction());
    }

    public function test_root_unassign_proves_draft_null_without_claiming_public_open_or_publication(): void
    {
        $row = $this->shift(['status' => 'scheduled', 'user_id' => $this->worker->id]);
        $source = $this->candidateSource($row);
        $this->commitFixtures();
        $writer = $this->writer();
        $uuid = (string) Str::uuid();
        $response = $this->production(fn () => $this->submit('unassign', $row, $source, ['request_id' => $uuid, 'reason' => 'Private manager reason']));
        $receipt = $this->receipt($response, 'unassign', $row, $uuid, $source);
        $this->assertSame('saved', $receipt['outcome']);
        $this->assertNull($receipt['user_id']);
        $this->assertSame('draft', $receipt['status']);
        $this->assertStringNotContainsString('Private manager reason', json_encode($receipt));
        $this->assertNull($writer->table('shifts')->where('id', $row->id)->value('user_id'));
        $this->assertSame('draft', $writer->table('shifts')->where('id', $row->id)->value('status'));
        $this->assertSame(0, $writer->table('shift_open_positions')->where('shift_id', $row->id)->count());
        $this->assertSame(1, $writer->table('timeline_events')->where('source_type', Shift::class)->where('source_id', $row->id)->where('type', 'shift_unassigned')->count());
    }

    public static function warnings(): array
    {
        return ['ordinary requires acknowledgement' => [false, false, '', 'not_saved', 'eligibility_warning'],
            'ordinary acknowledged without override grant' => [false, true, '', 'saved', null],
            'override reason required' => [true, true, '', 'not_saved', 'override_reason_required'],
            'authorised override with reason' => [true, true, 'Reviewed present evidence', 'saved', null]];
    }

    #[DataProvider('warnings')]
    public function test_warning_contract_distinguishes_ordinary_acknowledgement_and_exact_override_reason(bool $overrideable, bool $ack, string $reason, string $outcome, ?string $why): void
    {
        if ($overrideable) {
            $this->actor = $this->person(['shifts.manageAny', 'rostering.viewAny', 'shifts.overrideEligibility']);
        }
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->decision($overrideable ? 'override' : 'ordinary');
        $this->commitFixtures();
        $before = $this->state();
        $queue = $this->queueState();
        $uuid = (string) Str::uuid();
        $response = $this->production(fn () => $this->submit('assign', $row, $source, ['request_id' => $uuid,
            'override_acknowledged' => $ack, 'override_reason' => $reason]));
        $receipt = $this->receipt($response, 'assign', $row, $uuid, $source);
        $this->assertSame($outcome, $receipt['outcome']);
        $this->assertSame($why, $receipt['reason']);
        $this->assertTrue($receipt['review']['acknowledgement_required']);
        $this->assertSame($overrideable, $receipt['review']['reason_required']);
        $this->assertSame($overrideable, $receipt['review']['can_override_eligibility']);
        $this->assertStringNotContainsString('Different private Client', json_encode($receipt));
        if ($outcome === 'not_saved') {
            $this->assertSame($before, $this->state());
            $this->assertSame($queue, $this->queueState());
        } else {
            $this->assertSame($this->worker->id, (int) $row->fresh()->user_id);
            $this->assertSame($overrideable ? 1 : 0, ShiftEligibilityOverride::where('shift_id', $row->id)->count());
        }
    }

    public function test_override_acknowledgement_does_not_bypass_a_missing_current_override_grant(): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->decision('override');
        $this->commitFixtures();
        $before = $this->state();
        $queue = $this->queueState();
        $this->production(fn () => $this->submit('assign', $row, $source, ['override_acknowledged' => true, 'override_reason' => 'A reason is not a grant']))->assertForbidden();
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queueState());
        $this->assertNull(session('shift_assignment_result'));
    }

    public static function saveFaults(): array
    {
        return ['assign veto' => ['assign', 'shift_veto'], 'unassign veto' => ['unassign', 'shift_veto'],
            'assignment history veto' => ['assign', 'timeline_veto'], 'unassignment history veto' => ['unassign', 'timeline_veto'],
            'late source mutation' => ['assign', 'late_shift'], 'history intent alteration' => ['assign', 'history_intent']];
    }

    #[DataProvider('saveFaults')]
    public function test_write_veto_and_late_observer_changes_roll_back_whole_root_command(string $action, string $fault): void
    {
        $row = $this->shift(['user_id' => $action === 'unassign' ? $this->worker->id : null,
            'status' => $action === 'unassign' ? 'scheduled' : 'draft']);
        $source = $this->candidateSource($row);
        $this->decision('pass');
        $this->commitFixtures();
        $this->isolateModelEvents();
        if ($fault === 'shift_veto') {
            Shift::updating(static fn (Shift $saving) => (int) $saving->id === (int) $row->id ? false : null);
        } elseif ($fault === 'timeline_veto') {
            TimelineEvent::saving(static fn (TimelineEvent $saving) => in_array($saving->type, ['shift_assigned', 'shift_unassigned'], true) ? false : null);
        } elseif ($fault === 'history_intent') {
            TimelineEvent::saving(static function (TimelineEvent $saving): void {
                if ($saving->type === 'shift_assigned') {
                    $saving->actor_user_id = null;
                }
            });
        } else {
            TimelineEvent::saved(static function (TimelineEvent $saved) use ($row): void {
                if ($saved->type === 'shift_assigned') {
                    DB::table('shifts')->where('id', $row->id)->update(['notes' => 'Late foreign alteration']);
                }
            });
        }
        $before = $this->state();
        $queue = $this->queueState();
        $response = $this->production(fn () => $this->submit($action, $row, $source, json: true));
        $this->assertGreaterThanOrEqual(400, $response->status());
        $this->assertSame($before, $this->state($this->writer()));
        $this->assertSame($queue, $this->queueState());
        $this->assertNull(session('shift_assignment_result'));
    }

    public function test_root_reassignment_checks_replacement_position_and_fractional_clock_history_before_commit(): void
    {
        $previous = $this->person([]);
        $row = $this->shift(['user_id' => $previous->id, 'status' => 'scheduled']);
        $replacement = ShiftReplacementRequest::create(['shift_id' => $row->id, 'requested_by' => $this->actor->id,
            'current_staff_id' => $previous->id, 'status' => 'requested', 'reason' => 'Requested cover', 'requested_at' => now()]);
        $position = ShiftOpenPosition::create(['shift_id' => $row->id, 'replacement_request_id' => $replacement->id, 'status' => 'open', 'coverage_roles' => [], 'required_skills' => []]);
        $source = $this->candidateSource($row);
        $this->decision('pass');
        $this->commitFixtures();
        $response = $this->production(fn () => $this->submit('assign', $row, $source));
        $response->assertSessionHas('shift_assignment_result.outcome', 'saved');
        $this->assertSame('approved', $replacement->fresh()->status);
        $this->assertSame($this->worker->id, (int) $replacement->fresh()->replacement_user_id);
        $this->assertSame('filled', $position->fresh()->status);
        $this->assertSame($this->worker->id, (int) $position->fresh()->claimed_by);
        $this->assertSame(1, TimelineEvent::where('source_type', ShiftReplacementRequest::class)->where('source_id', $replacement->id)->where('type', 'shift_replacement_approved')->count());
    }

    public static function replacementFaults(): array
    {
        return ['replacement veto' => ['replacement'], 'position intent alteration' => ['position'], 'replacement history veto' => ['history']];
    }

    #[DataProvider('replacementFaults')]
    public function test_reassignment_rolls_back_when_required_replacement_suffix_does_not_persist(string $fault): void
    {
        $previous = $this->person([]);
        $row = $this->shift(['user_id' => $previous->id, 'status' => 'scheduled']);
        $replacement = ShiftReplacementRequest::create(['shift_id' => $row->id, 'requested_by' => $this->actor->id,
            'current_staff_id' => $previous->id, 'status' => 'requested', 'reason' => 'Requested cover', 'requested_at' => now()]);
        ShiftOpenPosition::create(['shift_id' => $row->id, 'replacement_request_id' => $replacement->id, 'status' => 'open', 'coverage_roles' => [], 'required_skills' => []]);
        $source = $this->candidateSource($row);
        $this->decision('pass');
        $this->commitFixtures();
        $this->isolateModelEvents();
        if ($fault === 'replacement') {
            ShiftReplacementRequest::updating(static fn () => false);
        } elseif ($fault === 'position') {
            ShiftOpenPosition::updating(static function (ShiftOpenPosition $position): void { $position->claimed_by = null; });
        } else {
            TimelineEvent::saving(static fn (TimelineEvent $event) => $event->type === 'shift_replacement_approved' ? false : null);
        }
        $before = $this->state();
        $queue = $this->queueState();
        $response = $this->production(fn () => $this->submit('assign', $row, $source, json: true));
        $this->assertGreaterThanOrEqual(400, $response->status());
        $this->assertSame($before, $this->state($this->writer()));
        $this->assertSame($queue, $this->queueState());
        $this->assertNull(session('shift_assignment_result'));
    }

    public function test_displayed_source_change_is_known_no_write_and_current_source_is_returned(): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->commitFixtures();
        $writer = $this->writer();
        $writer->table('shifts')->where('id', $row->id)->update(['notes' => 'Independently committed current notes']);
        $before = $this->state($writer);
        $queue = $this->queueState();
        $response = $this->production(fn () => $this->submit('assign', $row, $source));
        $response->assertSessionHas('shift_assignment_result.outcome', 'not_saved')->assertSessionHas('shift_assignment_result.reason', 'source_changed');
        $this->assertSame($source, session('shift_assignment_result.expected_source'));
        $this->assertNotSame($source, session('shift_assignment_result.source'));
        $this->assertSame($before, $this->state($writer));
        $this->assertSame($queue, $this->queueState());
    }

    public static function lockedStates(): array
    {
        return ['assign completed' => ['assign', 'completed', 'locked'], 'unassign cancelled' => ['unassign', 'cancelled', 'locked'],
            'unassign in progress' => ['unassign', 'in_progress', 'in_progress']];
    }

    #[DataProvider('lockedStates')]
    public function test_current_locked_outcome_never_becomes_a_successful_mutation(string $action, string $status, string $reason): void
    {
        $row = $this->shift(['user_id' => $this->worker->id, 'status' => $status,
            'actual_starts_at' => in_array($status, ['completed', 'in_progress'], true) ? '2026-10-20 20:00:00' : null,
            'actual_ends_at' => $status === 'completed' ? '2026-10-20 21:00:00' : null]);
        $source = ShiftAssignmentSource::describe($row->fresh());
        $this->commitFixtures();
        $before = $this->state();
        $queue = $this->queueState();
        $response = $this->production(fn () => $this->submit($action, $row, $source));
        $response->assertSessionHas('shift_assignment_result.outcome', 'not_saved')->assertSessionHas('shift_assignment_result.reason', $reason);
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queueState());
    }

    public function test_current_grant_revocation_after_cached_permission_is_not_overruled_by_displayed_source(): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->assertTrue($this->actor->canDo('shifts.manageAny'));
        $this->commitFixtures();
        $writer = $this->writer();
        $ids = $this->actor->roles()->pluck('roles.id')->all();
        $writer->table('role_permission')->whereIn('role_id', $ids)->where('permission_id', Permission::where('key', 'shifts.manageAny')->value('id'))->delete();
        $before = $this->state($writer);
        $queue = $this->queueState();
        $this->production(fn () => $this->submit('assign', $row, $source))->assertForbidden();
        $this->assertSame($before, $this->state($writer));
        $this->assertSame($queue, $this->queueState());
        $this->assertNull(session('shift_assignment_result'));
    }

    public static function boundaries(): array
    {
        return ['logical nested transaction' => ['nested'], 'raw PDO transaction' => ['pdo']];
    }

    #[DataProvider('boundaries')]
    public function test_nested_or_raw_pdo_boundary_withholds_physical_confirmation(string $boundary): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->decision('pass');
        if ($boundary === 'nested') {
            $this->assertSame(1, DB::transactionLevel());
            $this->submit('assign', $row, $source)->assertRedirect();
            $this->assertNull(session('shift_assignment_result'));
        } else {
            $this->commitFixtures();
            DB::connection()->getPdo()->beginTransaction();
            try {
                $response = $this->submit('assign', $row, $source);
                $this->assertGreaterThanOrEqual(400, $response->status());
                $this->assertNull(session('shift_assignment_result'));
            } finally {
                if (DB::connection()->getPdo()->inTransaction()) {
                    DB::connection()->getPdo()->rollBack();
                }
            }
            $this->assertNull($row->fresh()->user_id);
        }
    }

    public function test_candidate_failure_is_unknown_unselectable_and_private_rule_text_is_not_projected(): void
    {
        $row = $this->shift();
        $this->mock(ShiftStaffEligibilityService::class, function ($mock): void {
            $mock->shouldReceive('evaluate')->andReturnUsing(function (Shift $shift, User $worker): EligibilityResult {
                if ((int) $worker->id === (int) $this->worker->id) {
                    throw new \RuntimeException('Private underlying assessment failure');
                }
                return EligibilityResult::fromChecks([['rule' => 'conflict', 'passed' => false, 'severity' => 'block',
                    'overrideable' => false, 'message' => 'Different private Client needs cover']]);
            });
        });
        $before = $this->state();
        $queue = $this->queueState();
        $response = $this->actingAs($this->actor)->getJson(route('operations.shifts.candidates', $row))->assertOk();
        $unknown = collect($response->json('candidates'))->firstWhere('id', $this->worker->id);
        $this->assertNotNull($unknown);
        $this->assertSame('unknown', $unknown['assessment_status']);
        $this->assertFalse($unknown['is_eligible']);
        $this->assertFalse($unknown['acknowledgement_required']);
        $this->assertFalse($unknown['reason_required']);
        $this->assertFalse($unknown['can_override_eligibility']);
        $this->assertStringNotContainsString('Different private Client', $response->getContent());
        $this->assertStringNotContainsString('Private underlying', $response->getContent());
        $this->assertSame($this->actor->id, $response->json('actor_id'));
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queueState());
    }

    public function test_source_is_stable_after_sql_reload_but_changes_for_real_field_edits(): void
    {
        $row = $this->shift(['coverage_roles' => ['driver', 'caregiver'], 'is_on_call' => false, 'notes' => null]);
        $reordered = new Shift;
        $reordered->setRawAttributes(array_reverse($row->fresh()->getAttributes(), true), true);
        $this->assertSame(ShiftAssignmentSource::describe($row->fresh()), ShiftAssignmentSource::describe($reordered));
        $source = ShiftAssignmentSource::describe($reordered);
        $reordered->is_on_call = true;
        $this->assertNotSame($source, ShiftAssignmentSource::describe($reordered));
        $reordered->is_on_call = false;
        $reordered->coverage_roles = ['caregiver', 'driver'];
        $this->assertNotSame($source, ShiftAssignmentSource::describe($reordered));
    }

    public static function deniedAssessments(): array
    {
        return ['hard block' => ['block', 422], 'unavailable' => ['unavailable', 503]];
    }

    #[DataProvider('deniedAssessments')]
    public function test_real_gateway_block_and_unavailable_do_not_confirm_or_change_assignment(string $kind, int $status): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->mock(ShiftStaffEligibilityService::class, function ($mock) use ($kind): void {
            $mock->shouldReceive('evaluate')->andReturnUsing(static function () use ($kind): EligibilityResult {
                if ($kind === 'unavailable') {
                    throw new \RuntimeException('Private underlying query failure');
                }
                return EligibilityResult::fromChecks([['rule' => 'availability_leave', 'passed' => false, 'severity' => 'block',
                    'overrideable' => false, 'message' => 'Approved leave overlaps the duty']]);
            });
        });
        $this->commitFixtures();
        $before = $this->state();
        $queue = $this->queueState();
        $this->production(fn () => $this->submit('assign', $row, $source, json: true))->assertStatus($status);
        $this->assertSame($before, $this->state($this->writer()));
        $this->assertSame($queue, $this->queueState());
        $this->assertNull(session('shift_assignment_result'));
    }

    public function test_after_commit_failure_is_unconfirmed_even_though_independent_reader_sees_saved_assignment(): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        $this->decision('pass');
        $this->commitFixtures();
        $this->isolateModelEvents();
        Shift::saved(static function (Shift $saved) use ($row): void {
            if ((int) $saved->id === (int) $row->id && $saved->user_id !== null) {
                DB::afterCommit(static fn () => throw new \RuntimeException('Transport suffix failed after physical commit'));
            }
        });
        $response = $this->production(fn () => $this->submit('assign', $row, $source));
        $this->assertGreaterThanOrEqual(400, $response->status());
        $this->assertSame($this->worker->id, (int) $this->writer()->table('shifts')->where('id', $row->id)->value('user_id'));
        $this->assertNull(session('shift_assignment_result'));
    }

    public function test_legacy_header_omission_keeps_legacy_warning_response_without_modern_receipt(): void
    {
        $row = $this->shift();
        $this->decision('ordinary');
        $before = $this->state();
        $queue = $this->queueState();
        $this->actingAs($this->actor)->post(route('operations.shifts.assign', $row), ['user_id' => $this->worker->id])
            ->assertRedirect()->assertSessionHas('assignment_warnings');
        $this->assertSame($before, $this->state());
        $this->assertSame($queue, $this->queueState());
        $this->assertNull(session('shift_assignment_result'));
    }

    public function test_requester_uuid_and_editor_result_are_separate_and_validation_clears_stale_assignment_flash(): void
    {
        $row = $this->shift();
        $source = $this->candidateSource($row);
        session()->flash('shift_result', ['actor_id' => $this->actor->id, 'editor' => 'retained']);
        session()->flash('shift_assignment_result', ['actor_id' => $this->actor->id, 'request_id' => (string) Str::uuid()]);
        $this->actingAs($this->actor)->withHeader('X-Shift-Assignment-Result', 'committed-v1')
            ->post(route('operations.shifts.assign', $row), ['user_id' => $this->worker->id])->assertSessionHasErrors(['request_id', 'expected_source']);
        $this->assertNull(session('shift_assignment_result'));
        $this->assertSame('retained', session('shift_result.editor'));
        $this->decision('pass');
        $this->commitFixtures();
        $uuid = (string) Str::uuid();
        $response = $this->production(fn () => $this->submit('assign', $row, $source, ['request_id' => $uuid]));
        $this->receipt($response, 'assign', $row, $uuid, $source);
        $request = Request::create('/operations/rostering');
        $request->setLaravelSession(session()->driver());
        $request->setUserResolver(fn () => $this->worker);
        $this->assertNull(ShiftAssignmentReceipt::forRequester($request));
        $request->setUserResolver(fn () => $this->actor);
        $this->assertSame($uuid, ShiftAssignmentReceipt::forRequester($request)['request_id']);
    }

    public static function returnLocations(): array
    {
        return ['flat indexed Sites' => ['/operations/rostering?week=2026-10-19&tab=open&site_id[0]=3&site_id[1]=4', '/operations/rostering?week=2026-10-19&tab=open&site_id%5B0%5D=3&site_id%5B1%5D=4'],
            'flat empty brackets' => ['/operations/rostering?site_id[]=3&site_id[]=4', '/operations/rostering?site_id%5B0%5D=3&site_id%5B1%5D=4'],
            'external' => ['https://foreign.example/operations/rostering', '/operations/rostering'],
            'nested Sites' => ['/operations/rostering?site_id[x][y]=3', '/operations/rostering'],
            'mixed Sites' => ['/operations/rostering?site_id=3&site_id[]=4', '/operations/rostering'],
            'duplicate week' => ['/operations/rostering?week=2026-10-19&week=2026-10-26', '/operations/rostering'],
            'encoded control' => ['/operations/rostering?tab=open%0a', '/operations/rostering'],
            'non Monday' => ['/operations/rostering?week=2026-10-20', '/operations/rostering']];
    }

    #[DataProvider('returnLocations')]
    public function test_navigation_preserves_only_finite_allowed_context(string $input, string $expected): void
    {
        $this->assertSame($expected, ShiftAssignmentReturn::location($input, 123, $this->actor));
    }

    private function candidateSource(Shift $row): array
    {
        // Uses the real endpoint as the frontend does. Default normal eligibility may warn; source remains lawful.
        $response = $this->actingAs($this->actor)->getJson(route('operations.shifts.candidates', $row))->assertOk();
        $this->assertSame($row->id, $response->json('shift_source.shift_id'));
        $this->assertMatchesRegularExpression('/\A[a-f0-9]{64}\z/', $response->json('shift_source.revision'));

        return $response->json('shift_source');
    }

    private function submit(string $action, Shift $row, array $source, array $extra = [], bool $json = false): TestResponse
    {
        $data = array_replace(['request_id' => (string) Str::uuid(), 'expected_source' => $source,
            'return_to' => '/operations/rostering?week=2026-10-19&tab=open'], $action === 'assign' ? ['user_id' => $this->worker->id] : [], $extra);

        $this->actingAs($this->actor)->withHeader('X-Shift-Assignment-Result', 'committed-v1');

        return $json ? $this->postJson(route('operations.shifts.'.$action, $row), $data) : $this->post(route('operations.shifts.'.$action, $row), $data);
    }

    private function receipt(TestResponse $response, string $action, Shift $row, string $uuid, array $source): array
    {
        $response->assertRedirect()->assertSessionHas('shift_assignment_result');
        $result = session('shift_assignment_result');
        $this->assertSame(1, $result['version']);
        $this->assertSame('single', $result['scope']);
        $this->assertSame($action, $result['action']);
        $this->assertSame($uuid, $result['request_id']);
        $this->assertSame($this->actor->id, $result['actor_id']);
        $this->assertSame($row->id, $result['shift_id']);
        $this->assertSame($action === 'assign' ? $this->worker->id : null, $result['requested_user_id']);
        $this->assertSame($source, $result['expected_source']);
        $this->assertSame(ShiftAssignmentSource::describe($row->fresh()), $result['source']);

        return $result;
    }

    private function decision(string $kind): void
    {
        $this->mock(ShiftStaffEligibilityService::class, function ($mock) use ($kind): void {
            $mock->shouldReceive('evaluate')->andReturnUsing(static function () use ($kind): EligibilityResult {
                return EligibilityResult::fromChecks($kind === 'pass' ? [] : [['rule' => 'turnaround', 'passed' => false,
                    'severity' => 'warning', 'overrideable' => $kind === 'override', 'message' => 'Different private Client before this duty']]);
            });
        });
        $this->assertSame(AssignmentEligibilityGateway::class, get_class(app(AssignmentEligibilityGateway::class)));
    }

    private function person(array $keys): User
    {
        $user = User::factory()->create(['role' => 'support_worker', 'approved_at' => now(), 'external_clinical_account' => false]);
        if ($keys !== []) {
            $role = Role::create(['name' => 'assignment-'.Str::uuid(), 'label' => 'Assignment fixture', 'type' => 'custom', 'level' => 10]);
            $role->permissions()->sync(collect($keys)->map(fn ($key) => Permission::firstOrCreate(['key' => $key],
                ['description' => $key, 'group' => 'shifts', 'module' => 'Operations'])->id));
            $user->roles()->attach($role);
        }
        HrEmployeeProfile::factory()->create(['user_id' => $user->id, 'primary_site_id' => $this->site->id, 'secondary_site_ids' => [],
            'start_date' => '2026-01-01', 'end_date' => null, 'is_active' => true, 'hourly_rate' => 25, 'created_by' => $user->id, 'updated_by' => $user->id]);

        return $user->fresh();
    }

    private function shift(array $extra = []): Shift
    {
        return Shift::factory()->create(array_replace(['client_id' => $this->client->id, 'site_id' => $this->site->id,
            'service_context_id' => $this->context->id, 'user_id' => null, 'created_by' => $this->actor->id,
            'starts_at' => '2026-10-20 20:00:00', 'ends_at' => '2026-10-20 21:00:00', 'status' => 'draft',
            'notes' => 'Exact original notes', 'location' => 'Lawful location', 'shift_type' => 'standard',
            'is_sleepover' => false, 'is_on_call' => false, 'is_lone_worker' => false, 'expected_break_minutes' => 0,
            'coverage_roles' => [], 'required_licence_class' => null, 'required_licence_endorsements' => []], $extra));
    }

    private function state(?Connection $connection = null): array
    {
        $connection ??= DB::connection();
        return collect(['shifts', 'shift_tasks', 'shift_eligibility_overrides', 'coverage_reservations', 'shift_replacement_requests',
            'shift_open_positions', 'timeline_events', 'audit_logs', 'notifications', 'workforce_eligibility_rechecks',
            'workforce_eligibility_observations', 'timesheets', 'hr_time_entries', 'billing_entries', 'shift_signals', 'shift_signal_outbox'])
            ->mapWithKeys(fn ($table) => [$table => $connection->table($table)->orderBy('id')->get()->map(fn ($row) => (array) $row)->all()])->all();
    }

    private function queueState(): array
    {
        return collect(Queue::pushedJobs())->map(fn ($entries) => array_map(static fn ($entry) => [
            'job' => serialize($entry['job']), 'queue' => $entry['queue'], 'data' => $entry['data'] ?? null], $entries))->all();
    }

    private function commitFixtures(): void
    {
        $connection = DB::connection();
        $this->assertTrue(app()->environment('testing'));
        $this->assertSame('mysql', $connection->getDriverName());
        $this->assertSame(static::$isolatedMysqlDatabase, $connection->getDatabaseName());
        $this->assertTrue(OwnedTestDatabase::isOwnedBy($connection->getDatabaseName(), getmypid()));
        $this->assertSame($connection->getDatabaseName(), $connection->selectOne('SELECT DATABASE() AS db')->db);
        $this->assertSame(1, DB::transactionLevel());
        DB::commit();
        $this->committed = true;
        $this->assertSame(0, DB::transactionLevel());
        $this->assertFalse($connection->getPdo()->inTransaction());
    }

    private function writer(): Connection
    {
        config(['database.connections.assignment_writer' => array_replace(DB::connection()->getConfig(), ['name' => 'assignment_writer'])]);
        if (! DB::connection('assignment_writer')->getPdo()) {
            throw new \LogicException('Fixture writer was not available.');
        }
        $writer = DB::connection('assignment_writer');
        $this->assertSame(DB::connection()->getDatabaseName(), $writer->getDatabaseName());
        $this->assertTrue(OwnedTestDatabase::isOwnedBy($writer->getDatabaseName(), getmypid()));
        $this->assertSame($writer->getDatabaseName(), $writer->selectOne('SELECT DATABASE() AS db')->db);
        $this->assertNotSame(DB::connection()->getPdo(), $writer->getPdo());
        $this->assertSame(0, $writer->transactionLevel());
        $this->assertFalse($writer->getPdo()->inTransaction());

        return $writer;
    }

    private function production(callable $action): mixed
    {
        $connection = DB::connection();
        $testing = app('db.transactions');
        $production = new DatabaseTransactionsManager;
        app()->instance('db.transactions', $production);
        $connection->setTransactionManager($production);
        try {
            return $action();
        } finally {
            while ($connection->transactionLevel() > 0) {
                $connection->rollBack();
            }
            $this->assertFalse($connection->getPdo()->inTransaction());
            app()->instance('db.transactions', $testing);
            $connection->setTransactionManager($testing);
        }
    }

    private function isolateModelEvents(): void
    {
        $events = Model::getEventDispatcher();
        Model::setEventDispatcher(clone $events);
        $this->beforeApplicationDestroyed(static fn () => Model::setEventDispatcher($events));
    }
}
