<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\User;
use Carbon\CarbonImmutable;

/** Navigation filters never grant access. Destination handlers still re-authorise their records. */
final class ShiftAssignmentReturn
{
    public static function location(mixed $input, int $shiftId, User $actor): string
    {
        $fallback = route('operations.rostering.index', [], false);
        if (! is_string($input) || strlen($input) > 2048 || preg_match('/[\\\\\x00-\x20\x7f]/', $input)
            || preg_match('/[\\\\\x00-\x20\x7f]/', rawurldecode($input))) {
            return $fallback;
        }
        $parts = parse_url($input);
        if ($parts === false || array_diff(array_keys($parts), ['path', 'query']) !== [] || ! str_starts_with($input, '/')) {
            return $fallback;
        }
        $path = $parts['path'] ?? '';
        if (! in_array($path, ['/operations/rostering', '/operations/rostering/conflicts', '/operations/shifts/'.$shiftId], true)) {
            return $fallback;
        }
        $values = [];
        $siteValues = [];
        $siteStyle = null;
        $seen = [];
        foreach (($parts['query'] ?? '') === '' ? [] : explode('&', $parts['query']) as $pair) {
            $pieces = explode('=', $pair, 2);
            if (count($pieces) !== 2) {
                return $fallback;
            }
            [$key, $value] = array_map('urldecode', $pieces);
            if (preg_match('/[\\\\\x00-\x1f\x7f]/', $key.$value)) {
                return $fallback;
            }
            if ($path === '/operations/rostering' && preg_match('/\Asite_id(?:\[(\d*)\])?\z/', $key, $match)) {
                $style = str_contains($key, '[') ? 'array' : 'scalar';
                if (($siteStyle !== null && $style !== $siteStyle) || ($key !== 'site_id[]' && isset($seen[$key]))
                    || (isset($match[1]) && $match[1] !== '' && (string) (int) $match[1] !== $match[1])
                    || ! preg_match('/\A[1-9]\d{0,9}\z/', $value) || count($siteValues) >= 50) {
                    return $fallback;
                }
                $seen[$key] = true;
                $siteStyle = $style;
                $siteValues[] = (int) $value;
                continue;
            }
            if (isset($seen[$key])) {
                return $fallback;
            }
            $seen[$key] = true;
            if ($key === 'week' && $path !== '/operations/shifts/'.$shiftId) {
                try {
                    $date = CarbonImmutable::createFromFormat('!Y-m-d', $value, (string) (config('app.worker_timezone') ?: config('app.timezone') ?: 'UTC'));
                    if (! $date || $date->format('Y-m-d') !== $value || ! $date->isMonday()) {
                        return $fallback;
                    }
                } catch (\Throwable) {
                    return $fallback;
                }
            } elseif ($key === 'tab') {
                $tabs = $path === '/operations/rostering'
                    ? ['shifts', 'calendar', 'open', 'coverage', 'timeoff', 'availability', 'capacity', 'analytics', 'templates', 'recurring']
                    : ['tasks', 'medications', 'coverage', 'assignment', 'transport', 'replacement', 'observations', 'forms', 'notes', 'audit', 'incidents'];
                if ($path === '/operations/rostering/conflicts' || ! in_array($value, $tabs, true)) {
                    return $fallback;
                }
            } elseif ($path === '/operations/rostering' && in_array($key, ['staff_id', 'client_id'], true) && preg_match('/\A[1-9]\d{0,9}\z/', $value)) {
                $value = (int) $value;
            } elseif ($path === '/operations/shifts/'.$shiftId && $key === 'return_to') {
                // One level only, matching the existing Show Conflict Queue contract.
                $target = self::location($value, $shiftId, $actor);
                if (! str_starts_with($target, '/operations/rostering/conflicts') || str_contains($target, 'return_to')) {
                    return $fallback;
                }
                $value = $target;
            } else {
                return $fallback;
            }
            $values[$key] = $value;
        }
        if ($path === '/operations/rostering/conflicts' && ! $actor->canDo('rostering.viewAny')) {
            return $fallback;
        }
        if ($siteValues !== []) {
            $values['site_id'] = $siteStyle === 'scalar' ? $siteValues[0] : array_values(array_unique($siteValues));
        }

        return $path.($values === [] ? '' : '?'.http_build_query($values, '', '&', PHP_QUERY_RFC3986));
    }
}
