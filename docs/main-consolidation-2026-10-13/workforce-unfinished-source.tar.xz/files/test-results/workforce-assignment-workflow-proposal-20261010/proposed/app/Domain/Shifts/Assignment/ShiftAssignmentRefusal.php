<?php

namespace App\Domain\Shifts\Assignment;

/** Only deliberately classified pre-write command decisions use this exception. */
final class ShiftAssignmentRefusal extends \RuntimeException
{
    public function __construct(public readonly string $reason)
    {
        parent::__construct('No assignment changes were applied.');
    }
}
