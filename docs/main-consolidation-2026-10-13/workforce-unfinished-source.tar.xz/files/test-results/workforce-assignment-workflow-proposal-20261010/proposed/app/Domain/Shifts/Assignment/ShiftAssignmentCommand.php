<?php

namespace App\Domain\Shifts\Assignment;

use App\Domain\Shifts\Lifecycle\ShiftLifecycleService;
use App\Models\Shift;
use App\Models\User;
use Illuminate\Support\Facades\DB;

final class ShiftAssignmentCommand
{
    public function __construct(private readonly ShiftLifecycleService $lifecycle) {}

    public function execute(string $action, Shift $shift, User $actor, array $data): array
    {
        $userId = $action === 'assign' ? (int) $data['user_id'] : null;
        $evidence = new ShiftAssignmentEvidence($action, $data['expected_source'], $userId, $data);
        try {
            $stored = DB::transaction(function () use ($action, $shift, $actor, $data, $evidence) {
                if ($action === 'assign') {
                    $stored = $this->lifecycle->assign($shift, $actor, User::staff()->findOrFail($data['user_id']),
                        ['override_acknowledged' => (bool) ($data['override_acknowledged'] ?? false),
                            'override_reason' => trim((string) ($data['override_reason'] ?? ''))],
                        reservationReason: 'assignment', commandEvidence: $evidence);
                } else {
                    $reason = trim((string) ($data['reason'] ?? ''));
                    $stored = $this->lifecycle->unassign($shift, $actor, $reason === '' ? null : $reason, $evidence);
                }

                return $evidence->finish($stored);
            });
            $reason = null;
        } catch (ShiftAssignmentRefusal $refusal) {
            // The only refusal sites precede all command writes. Re-authorise and prove rollback source;
            // a subsequent external change or permission loss withholds confirmation instead of guessing.
            $stored = $this->lifecycle->assignmentReadContext($shift, $actor,
                function (Shift $current, User $currentActor) use ($evidence) {
                    if (! $evidence->before || ! $evidence->actor || (int) $currentActor->id !== (int) $evidence->actor->id
                        || ShiftAssignmentSource::describe($current) !== ShiftAssignmentSource::describe($evidence->before)) {
                        throw new \LogicException('The original assignment source could not be confirmed.');
                    }

                    return $current;
                });
            $reason = $refusal->reason;
        }

        return ['version' => 1, 'scope' => 'single', 'action' => $action, 'request_id' => $data['request_id'],
            'actor_id' => (int) $evidence->actor->id, 'shift_id' => (int) $stored->id, 'requested_user_id' => $userId,
            'expected_source' => $data['expected_source'], 'outcome' => $reason === null ? 'saved' : 'not_saved',
            'changed' => $reason === null && (($evidence->before->user_id === null ? null : (int) $evidence->before->user_id) !== ($stored->user_id === null ? null : (int) $stored->user_id) || $evidence->before->status !== $stored->status),
            'source' => ShiftAssignmentSource::describe($stored), 'user_id' => $stored->user_id === null ? null : (int) $stored->user_id,
            'status' => $stored->status, 'reason' => $reason, 'review' => $evidence->review];
    }
}
