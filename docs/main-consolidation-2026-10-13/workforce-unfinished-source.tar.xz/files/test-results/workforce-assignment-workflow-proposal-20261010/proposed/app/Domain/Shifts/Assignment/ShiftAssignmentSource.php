<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\Shift;
use DateTimeInterface;
use Illuminate\Database\Eloquent\Model;

/** Fixed semantic projection, independent of raw SQL column order and scalar driver types. */
final class ShiftAssignmentSource
{
    public static function describe(Shift $shift): array
    {
        $fields = array_merge(['id'], $shift->getFillable(), ['version', 'roster_period_id', 'published_at', 'publish_dirty_at']);

        return ['shift_id' => (int) $shift->id,
            'revision' => hash('sha256', json_encode(self::values($shift, $fields), JSON_THROW_ON_ERROR))];
    }

    public static function values(Model $model, array $fields): array
    {
        $values = [];
        foreach ($fields as $field) {
            $value = $model->getAttribute($field);
            if ($value instanceof DateTimeInterface) {
                $value = \Carbon\CarbonImmutable::instance($value)->utc()->format('Y-m-d\TH:i:s.u\Z');
            } elseif ($value !== null && ($field === 'version' || $field === 'id' || str_ends_with($field, '_id')
                || in_array($field, ['source_id', 'created_by', 'approved_by', 'claimed_by', 'requested_by', 'overridden_by', 'started_by', 'completed_by', 'handover_waived_by'], true))) {
                $value = (int) $value;
            }
            $values[$field] = self::json($value);
        }

        return $values;
    }

    private static function json(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }
        if (! array_is_list($value)) {
            ksort($value, SORT_STRING);
        }

        return array_map(self::json(...), $value);
    }
}
