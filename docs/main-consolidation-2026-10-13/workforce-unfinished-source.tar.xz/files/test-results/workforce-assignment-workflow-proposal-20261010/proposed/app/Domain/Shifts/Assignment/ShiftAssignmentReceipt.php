<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\Shift;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Throwable;

/** Correlation only. No durable replay or generic success inference. */
final class ShiftAssignmentReceipt
{
    private mixed $connection = null;
    private mixed $pdo = null;
    private bool $root = false;

    public function begin(Request $request): void
    {
        $request->session()->forget('shift_assignment_result');
        try {
            $this->connection = DB::connection();
            $this->pdo = $this->connection->getPdo();
            $this->root = $this->connection->transactionLevel() === 0 && ! $this->pdo->inTransaction();
        } catch (Throwable) {
            $this->root = false;
        }
    }

    public function present(Request $request, array $result): void
    {
        try {
            if (! $this->root || DB::connection() !== $this->connection || $this->connection->getPdo() !== $this->pdo
                || $this->connection->transactionLevel() !== 0 || $this->pdo->inTransaction()) {
                return;
            }
            $row = Shift::query()->whereKey($result['shift_id'])->first();
            if (! $row || ShiftAssignmentSource::describe($row) !== $result['source']) {
                return;
            }
            $request->session()->flash('shift_assignment_result', $result);
        } catch (Throwable) {
            $request->session()->forget('shift_assignment_result');
        }
    }

    public static function forRequester(Request $request): ?array
    {
        $result = $request->session()->get('shift_assignment_result');
        if (! is_array($result) || ($result['version'] ?? null) !== 1 || ($result['scope'] ?? null) !== 'single'
            || ($result['actor_id'] ?? null) !== $request->user()?->id || ! in_array($result['action'] ?? null, ['assign', 'unassign'], true)
            || ! in_array($result['outcome'] ?? null, ['saved', 'not_saved'], true)
            || ! is_string($result['request_id'] ?? null) || ! \Illuminate\Support\Str::isUuid($result['request_id'])) {
            return null;
        }

        return $result;
    }
}
