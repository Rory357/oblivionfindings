<?php

namespace App\Domain\Shifts\Assignment;

use App\Models\User;
use App\Services\Eligibility\EligibilityResult;

/** Never forwards raw rule/evidence messages, which can contain a different Client's name. */
final class ShiftAssignmentReview
{
    public static function unknown(): array
    {
        return ['assessment_status' => 'unknown', 'acknowledgement_required' => false,
            'reason_required' => false, 'can_override_eligibility' => false,
            'warning_reasons' => ['Eligibility could not be assessed. Review before assigning.'], 'blocked_reasons' => []];
    }

    public static function fromResult(EligibilityResult $result, User $actor): array
    {
        $blocked = [];
        $warnings = [];
        foreach ($result->checked_rules as $check) {
            if (! is_array($check) || ! is_string($check['rule'] ?? null) || ! is_bool($check['passed'] ?? null)
                || ! in_array($check['severity'] ?? null, ['block', 'warning', 'info'], true)) {
                throw new \UnexpectedValueException('Eligibility assessment was incomplete.');
            }
            if ($check['passed'] || $check['severity'] === 'info') {
                continue;
            }
            $message = self::message($check['rule']);
            if ($check['severity'] === 'block') {
                $blocked[] = $message;
            } else {
                $warnings[] = $message;
            }
        }
        // Do not turn a malformed aggregate with absent rule rows into a pass.
        if ($result->hasBlocks() && $blocked === []) {
            $blocked[] = 'This worker cannot be assigned. Review the current eligibility checks.';
        }
        if ($result->hasWarnings() && $warnings === []) {
            $warnings[] = 'Review the current eligibility warnings before assigning.';
        }

        return ['assessment_status' => 'assessed', 'acknowledgement_required' => $result->hasWarnings(),
            'reason_required' => $result->hasWarnings() && $result->overrideable_warnings !== [],
            'can_override_eligibility' => $actor->canDo('shifts.overrideEligibility'),
            'warning_reasons' => array_values(array_unique($warnings)), 'blocked_reasons' => array_values(array_unique($blocked))];
    }

    private static function message(string $rule): string
    {
        return match (true) {
            $rule === 'conflict' => 'This worker has an overlapping duty.',
            in_array($rule, ['time_off', 'availability_leave'], true) => 'This worker has time off during this duty.',
            $rule === 'availability' => 'This duty is outside the worker’s availability.',
            $rule === 'availability_employment' => 'Review the worker’s employment dates for this duty.',
            $rule === 'turnaround' => 'Review the turnaround time between duties.',
            str_starts_with($rule, 'fatigue') => 'Review the worker’s hours and rest between duties.',
            $rule === 'client_qualification' => 'Review the required Client qualifications for this duty.',
            str_starts_with($rule, 'house_qualification') => 'Review the required House qualifications for this duty.',
            in_array($rule, ['compliance', 'onboarding', 'hs_training', 'driver_licence', 'medication_competency'], true) => 'Review the worker’s required eligibility evidence for this duty.',
            in_array($rule, ['coverage_roles', 'overfill'], true) => 'Review the current staffing coverage for this duty.',
            default => 'Review the current eligibility checks for this duty.',
        };
    }
}
