from pathlib import Path
import json,hashlib,difflib,re

P=Path(__file__).parent
ROOT=Path('C:/Users/steph/.codex/worktrees/workforce-delivery/oblivionfindings')
def read(p): return Path('\\\\?\\'+str(p).replace('/','\\')).read_bytes()
def sha(b): return hashlib.sha256(b).hexdigest()
def write(path,obj): path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf-8')

# Text-only lexical spans; not PHP parsing or discovery.
def methods(b):
    text=b.decode(); result={}
    for match in re.finditer(r'^    (?:(?:public|protected|private|static|final)\s+)+function\s+(\w+)\s*\(',text,re.M):
        start=match.start(); i=match.end(); mode=None; depth=0; opened=False
        while i<len(text):
            c=text[i]; two=text[i:i+2]
            if mode in ["'",'"','`']:
                if c=='\\': i+=2; continue
                if c==mode: mode=None
            elif mode=='line':
                if c=='\n': mode=None
            elif mode=='block':
                if two=='*/': mode=None; i+=2; continue
            elif two=='//': mode='line'; i+=2; continue
            elif two=='/*': mode='block'; i+=2; continue
            elif c=='#' and text[i:i+2]!='#[': mode='line'
            elif c in ["'",'"','`']: mode=c
            elif c=='{': depth+=1; opened=True
            elif c=='}':
                depth-=1
                if opened and depth==0:
                    result[match.group(1)]=text[start:i+1].encode();break
            i+=1
        assert match.group(1) in result,match.group(1)
    return result

paths=sorted(str(q.relative_to(P/'proposed')).replace('\\','/') for q in (P/'proposed').rglob('*.php'))
files={}; patch=[]; blocks=[]
for path in paths:
    after=read(P/'proposed'/path)
    original=P/'baseline'/path
    before=read(original) if original.exists() else b''
    live=read(ROOT/path) if original.exists() else None
    if live is not None: assert live==before,path
    else: assert not (ROOT/path).exists(),path
    files[path]={'before':sha(before) if original.exists() else None,'after':sha(after),'new':not original.exists()}
    diff=list(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),
        fromfile='a/'+path if original.exists() else '/dev/null',tofile='b/'+path,n=3))
    patch.extend(diff);blocks.append((path,diff,before,after))

# Independent full-file forward/reverse reconstruction of the generated patch.
def apply(lines,diff,reverse=False):
    src=lines;out=[];cursor=0;i=2
    while i<len(diff):
        m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',diff[i])
        assert m,diff[i]
        old=int(m.group(3) if reverse else m.group(1)); oldcount=int((m.group(4) if reverse else m.group(2)) or 1)
        at=old-1 if oldcount else old
        assert at>=cursor
        out.extend(src[cursor:at]);cursor=at;i+=1
        while i<len(diff) and not diff[i].startswith('@@ '):
            sign=diff[i][0];body=diff[i][1:]
            if reverse: sign={'+':'-','-':'+',' ':' '}[sign]
            if sign in [' ','-']:
                assert cursor<len(src) and src[cursor]==body,(cursor,src[cursor:cursor+1],body)
                cursor+=1
            if sign in [' ','+']:out.append(body)
            i+=1
    out.extend(src[cursor:]);return ''.join(out).encode()

inverse={}
for path,diff,before,after in blocks:
    assert apply(before.decode().splitlines(keepends=True),diff)==after,path
    assert apply(after.decode().splitlines(keepends=True),diff,True)==before,path
    inverse[path]={'forward_exact':True,'whole_inverse_exact':True}
(P/'repair.patch').write_bytes(''.join(patch).encode())

owned={
'app/Http/Controllers/ShiftController.php':['candidates','assign','unassign'],
'app/Http/Middleware/HandleInertiaRequests.php':['share'],
'app/Domain/Shifts/Lifecycle/ShiftLifecycleService.php':['assign','unassign'],
'app/Services/ShiftTimelineService.php':['recordAssigned','recordUnassigned'],
'app/Services/ShiftReplacementService.php':['resolveFromManualAssignment','logTimelineEvent'],
}
preserved={}
for path,changed in owned.items():
    before=methods(read(P/'baseline'/path));after=methods(read(P/'proposed'/path)); proofs={}
    for name,body in before.items():
        if name not in changed:
            assert after.get(name)==body,(path,name)
            proofs[name]=sha(body)
    preserved[path]={'changed_existing_methods':changed,'new_methods':list(set(after)-set(before)),
        'unowned_methods_exact':proofs,'unowned_count':len(proofs)}

# Middleware delta is precisely one lazy result entry, no permission/editor flash rewrite.
mw='app/Http/Middleware/HandleInertiaRequests.php'
addition=b"                'shift_assignment_result' => fn () => \\App\\Domain\\Shifts\\Assignment\\ShiftAssignmentReceipt::forRequester($request),\n"
assert read(P/'proposed'/mw).replace(addition,b'',1)==read(P/'baseline'/mw)

audit=Path('C:/Users/steph/Herd/oblivionfindings/test-results/workforce-assignment-workflow-reaudit-20261010')
pins=json.loads(read(audit/'source-pins.json'))['pins']
more=['app/Models/TimelineEvent.php','app/Models/CoverageReservation.php','app/Models/ShiftEligibilityOverride.php',
      'app/Models/ShiftReplacementRequest.php','app/Models/ShiftOpenPosition.php','app/Models/Role.php','app/Models/Permission.php','app/Models/User.php',
      'app/Services/Timeline/TimelineEmitter.php','app/Services/CurrentAuthorizationReads.php','app/Services/AuthorizationEvidenceLockService.php',
      'app/Services/Medication/MedicationGovernanceScopeService.php','app/Services/Eligibility/ProposedShiftWorkloadService.php',
      'app/Services/ShiftSafetyInvariantService.php','tests/Support/CommittedFixtureCleanup.php','tests/Support/OwnedTestDatabase.php',
      'tests/Feature/Rostering/WorkforceShiftSaveCommandIntegrityTest.php','resources/js/pages/operations/shifts/components/shift-show-redesign.tsx']
for path in more:pins[path]=sha(read(ROOT/path))
drift=[path for path,digest in pins.items() if sha(read(ROOT/path))!=digest]
assert not drift,drift
write(P/'source-pins.json',{'root':str(ROOT),'scope':'inactive baseline evidence, not an active source freeze','pins':pins,'drift':drift})

testpath='tests/Feature/Rostering/WorkforceShiftAssignmentCommandIntegrityTest.php'
test=read(P/'proposed'/testpath); spans=methods(test)
providers={name:re.findall(r"'([^']+)'\s*=>\s*\[",body.decode()) for name,body in spans.items() if b'return [' in body and name in ['successfulAssignments','warnings','saveFaults','replacementFaults','lockedStates','boundaries','deniedAssessments','returnLocations']}
cases=[]
text=test.decode()
for name,body in spans.items():
    if not name.startswith('test_'):continue
    pos=text.index(body.decode());prefix=text[max(0,pos-90):pos]
    provider=re.search(r"#\[DataProvider\('([^']+)'\)\]\s*$",prefix)
    if provider:
        for label in providers[provider.group(1)]:cases.append({'method':name,'provider':provider.group(1),'dataset':label})
    else:cases.append({'method':name,'provider':None,'dataset':None})
write(P/'selection-source-derived.json',{'class':'Tests\\Feature\\Rostering\\WorkforceShiftAssignmentCommandIntegrityTest','file':testpath,
    'source_derived_cases':len(cases),'named_test_methods':len([x for x in spans if x.startswith('test_')]),'cases':cases,
    'framework_enumerated':False,'actual_inventory':None,'runtime_invoked':False})

write(P/'inverse-proof.json',inverse)
write(P/'method-byte-proof.json',preserved)
write(P/'static-proof.json',{'whole_forward_inverse_files':len(inverse),'unowned_methods_exact':sum(v['unowned_count'] for v in preserved.values()),
    'middleware_one_entry_inverse_exact':True,'controller_show_eMAR_body_exact':True,'source_pins':len(pins),'drift':drift,
    'source_derived_test_cases':len(cases),'syntax_invoked':False,'formatter_invoked':False,'framework_invoked':False,'product_edits':False})
manifest={'status':'INACTIVE_SOURCE_AND_TEST_PROPOSAL_ONLY','approved':False,'delivery_head':'94e31596c05825f24ff4cb84f734aa971a3c4793',
    'root':str(ROOT),'files':files,'source_pins':len(pins),'source_derived_cases':len(cases),'actual_inventory':None,
    'artifacts':{x:sha(read(P/x)) for x in ['repair.patch','source-pins.json','inverse-proof.json','method-byte-proof.json','static-proof.json','selection-source-derived.json']},
    'final_wire_contract':{'path':str(audit/'contract-final.md'),'sha256':sha(read(audit/'contract-final.md'))},
    'runtime_invoked':False,'product_edits':False,'parser_invoked':False}
write(P/'manifest.json',manifest)
print(json.dumps({'manifest':sha(read(P/'manifest.json')),'patch':sha(read(P/'repair.patch')),'files':len(files),
    'unowned_methods':sum(v['unowned_count'] for v in preserved.values()),'source_derived_cases':len(cases),'drift':drift},indent=2))
