# Inactive single-Shift assignment proposal

This is source and test authoring only. Nothing is applied to DELIVERY. PHP parsing, formatting, framework inventory, native scenarios, database work and process actions have not run.

The five existing paths change only candidates and opt-in assign/unassign transport, the one requester-bound flash entry, optional lifecycle command evidence, and optional checked history/replacement callbacks. Existing call signatures remain compatible; callers omitting command evidence retain their installed behaviour. Show/eMAR and unrelated writers remain byte-exact.

Modern submissions capture the candidate endpoint's opaque source, require current authority and canonical Client/Site, enclose lifecycle plus history/replacement/hold suffixes in one transaction, and verify intended stored values. A positive receipt requires the same physical root/PDO after return and a persisted source reread. Nested/raw-PDO, ambiguous commit, after-commit and projection failures produce no positive receipt. Deliberate prewrite refusals require rollback plus a current authority/source proof. UUIDs correlate one explicit request; this adds no durable replay or automatic retry.

Every assessed warning needs acknowledgement. Only the evaluator's actual overrideable-warning subset requires the existing override permission and a nonblank reason. Unknown candidates are nonselectable. Candidate assessments remain advisory until the authoritative command recheck. The new source is a fixed semantic Shift projection rather than SQL attribute ordering.

Return navigation accepts only bounded installed relative roster/queue/same-Shift paths and their enumerated fields, including finite one-dimensional numeric Site arrays. It does not grant access to a destination.

The proposed acceptance class uses existing isolated-database/fixture cleanup support, the real lifecycle/gateway/workload, and decision-seam controls. Source-derived identities are planning evidence only. Actual syntax, formatter, framework inventory, root scenarios and default-caller preservation selection remain future acceptance requirements.

This original draft is preserved before the additive canonical-display R2 proposal. Its wire reference is the immutable contract-final.md in the source audit packet.
