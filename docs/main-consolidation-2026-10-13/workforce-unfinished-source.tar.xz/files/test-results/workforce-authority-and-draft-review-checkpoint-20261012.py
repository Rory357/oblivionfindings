from pathlib import Path
import hashlib
import json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

owned = {
    'docs/workforce-audit-2026-10-05/DELIVERY-STATUS.txt': '12a8d0b310bc3279a80461f9047fc2db99ed482c26562647d554407fa8408745',
    'docs/workforce-audit-2026-10-05/OUTSTANDING-WORK-HANDOFF.md': '5ef7038c1ce609877e7646cdb96cd6c6730f93192c599d625253a014d0ba14a9',
    'test-results/workforce-coordinator-source-update-20261012.txt': 'dbdf4abbfe8f16f67e4d88151fef8afb7bf6eb2f69944d4cccce6de2eaafd306',
}
evidence = {
    'test-results/workforce-timesheet-legacy-authority-suffix-proposal-20261012/manifest.json': 'ad628378088c2fad5cc37d51db1de2a4b95ebd040c05cc0557429f640a995c4c',
    'test-results/workforce-timesheet-legacy-authority-suffix-proposal-20261012/source-proof.json': 'c231d42e62310308890027c544fb2e2a71f7a976f40f6d570054d9a6872648a1',
    'test-results/workforce-timesheet-legacy-authority-suffix-independent-review-20261012/review.json': '9e881039c92fa717981a362def3ead46e57d2c8263e951472348a7d298a791de',
    'test-results/workforce-timesheet-preparation-draft-parity-proposal-20261012/manifest.json': 'f21ecfea46cfda8bb0253a8bcc5bd0d5f9dba750d428c346e7cbdec883699ea4',
    'test-results/workforce-timesheet-preparation-draft-parity-proposal-20261012/source-proof.json': 'e4365b302f2cbf737a697fd7c2ed710d2ee0841cb0f08c66fe9350a0d80771f2',
    'test-results/workforce-timesheet-preparation-draft-parity-independent-review-20261012/review.json': '51827328b9c8918ca4ba50d75fd105c280ec5d05a24c64099cb8e605204cbc45',
}
for name, expected in evidence.items():
    assert sha((ROOT / name).read_bytes()) == expected, name
for stem, proposal in [
    ('legacy-authority-suffix', 'ad628378088c2fad5cc37d51db1de2a4b95ebd040c05cc0557429f640a995c4c'),
    ('preparation-draft-parity', 'f21ecfea46cfda8bb0253a8bcc5bd0d5f9dba750d428c346e7cbdec883699ea4'),
]:
    review = json.loads((ROOT / f'test-results/workforce-timesheet-{stem}-independent-review-20261012/review.json').read_bytes())
    assert review['status'] == 'CLEAR_SOURCE_ONLY'
    assert review['manifest_sha256'] == proposal

note = '''Latest source checkpoint: final authority repair and deliberate draft-save parity — 12 October 2026

The human-confirmed default remains staff requests for their own approved timesheets; managers-only is configurable and another authorised manager reviews. Linked applied corrections update Attendance and Timesheet effective records while preserving existing original history. These policy choices do not constitute installed-setting or workflow acceptance. Full31-module goal remains ACTIVE/incomplete; Control Room and Claude/eMAR remain independent.

Backend seven-action repair ad628378/proofc231d42e is independently CLEAR_SOURCE_ONLY9e881039/proofd20cc597. Normal save, audit, reconciliation, HR, billing, holiday and final Eloquent retrieval callbacks remain. A subsequent callback-free current-read suffix rechecks actual raw fields, actor approval/current roles/deny overrides and installed aliases, ownership/self-approval, current canonical source Sites/profile and assigned-Shift recipient predicates on the retained PDO/transaction. Update/resubmit retain original and proposed Site access; combined create-and-submit retains both original grants. Existing standalone manual Site-less draft and manager-created open-Shift own-user draft positives are preserved. Fresh post-notification authority/full raw-original comparison may withhold a receipt without undoing a lawful commit or claiming no write. The hypothesised mutable notice-result path was withdrawn on review: the actual notification helper receives a clone. Seven inverses,116 preserved method bodies and42 bounded pins match.69 new source slots and nine whole preservation suites remain UNRUN; actual union/inventory null. No correction UUID, checked-AFTER, durable witness/recovery, allocation-review suffix, bulk aggregate or archive/restore completion is implied.

Root's fixture-only successor f21ecfea/proofe4365b30 is independently CLEAR_SOURCE_ONLY51827328/prooffd03523c. One existing actual Wizard submit-grant case now extends after all preserved assertions: a cancelled submit sends nothing; after Back and review, only a deliberate Save as draft under the surviving create grant prepares the existing POST with submit=false, original Shift77 and retained notes. No PUT, close, receipt, success callback or Saved assertion is invented. All seven other images, including all three products, remain byte-exact to preparation-context3db9. Eight raw/current and parent image pairs, single literal inverse and105 finite dependencies match.53 prospective inventoried cases unchanged/UNRUN, older child cases additionally preserved, actual count null. Mock hashing/router is preparation-only and proves no physical HTTP/persistence/browser journey.

Next backend work is assigned to the existing RO agent: bounded exact Timesheet-row/default encoding for correction expected evidence, derived from actual schema and writer bodies. Missing canonical fields/producer ownership must remain explicit rather than being replaced with an unauthenticated digest. This is an assignment, not frozen implementation or certificate acceptance. Page-wide synchronous admission before hashing, two-way legacy/correction coordination, unknown draft/attempt retention through transient dialog closes, direct bulk/archive/restore outcomes, read interruption and browser Back remain unfinished frontend workflows. The pending seven-versus-six navigation choice stays unchanged; no separate settings entry is silently removed.

Coordinator's latest incoming instruction says it can read owned handoff files directly and needs no retry of the rejected outgoing message or extra report-permission request for oversight. It acknowledged the53-case parent preparation source packet, not delivery of the prepared local note. This local note remains UNSENT; no cross-chat send or agent relay occurred. No runtime admission/shared integration was supplied. Source/pure-file/evidence/owned-handoff/internal-agent work only: no application-source/parser/type/lint/framework/native/build/browser/process/readiness/SQL/Git/deployment or new probe/push. Parent-owned11-host launch-root/trusted-receipt hold remains; peer processes and protected preview are untouched. Last verified pushed MAINce50e22f. Preserve all historical checkpoints, failures, HOLDs and evidence limits below.


'''
before = {}
for name, expected in owned.items():
    raw = (ROOT / name).read_bytes()
    assert sha(raw) == expected, name
    before[name] = raw
payload = note.replace('\n', '\r\n').encode('utf-8')
out = ROOT / 'test-results/workforce-authority-and-draft-review-checkpoint-20261012.json'
assert not out.exists(), 'Do not overwrite frozen evidence'
after = {}
for name, raw in before.items():
    (ROOT / name).write_bytes(payload + raw)
    written = (ROOT / name).read_bytes()
    assert written[len(payload):] == raw, name
    after[name] = sha(written)
record = {
    'status': 'PURE_OWNED_HANDOFF_CHECKPOINT_ONLY',
    'evidence': evidence, 'before': owned, 'after': after,
    'all_history_bytes_preserved': True,
    'backend_review': 'CLEAR_SOURCE_ONLY', 'frontend_fixture_review': 'CLEAR_SOURCE_ONLY',
    'backend_new_source_slots_unrun': 69, 'frontend_inventoried_source_cases_unrun': 53,
    'actual_inventory': None, 'runtime_invoked': False, 'product_applied': False,
    'git_invoked': False, 'message_sent': False, 'goal_complete': False,
}
out.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'checkpoint_sha256': sha(out.read_bytes()), 'after': after,
    'runtime_invoked': False, 'product_applied': False, 'history_preserved': True}))
