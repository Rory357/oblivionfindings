from pathlib import Path
import hashlib, json

ROOT = Path(r'C:/Users/steph/Herd/oblivionfindings')
BASE = ROOT / 'test-results/workforce-timesheet-write-coordination-foundation-proposal-r2-20261012'
OUT = ROOT / 'test-results/workforce-timesheet-write-coordination-foundation-proposal-r3-20261012'
REVIEW = 'test-results/workforce-timesheet-write-coordination-foundation-r2-independent-review-20261012/review.json'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def encoded(value): return (json.dumps(value, indent=2) + '\n').encode()
def emit(name, raw):
    p = OUT / name; p.parent.mkdir(parents=True, exist_ok=True)
    assert not p.exists(), name
    p.write_bytes(raw)

assert not OUT.exists()
assert sha((BASE / 'manifest.json').read_bytes()) == '7dacafb90bb97245821d6fdb2bc02b97098fff9df3ce90789ed46d361f9e3756'
parent = json.loads((BASE / 'manifest.json').read_bytes())
for name, digest in parent['files'].items(): assert sha((BASE / name).read_bytes()) == digest, name
assert sha((ROOT / REVIEW).read_bytes()) == '3db52a94c6cd842f010a0a4fdf86c98899725f9a3f26197157bda9eaa78db520'
assert json.loads((ROOT / REVIEW).read_bytes())['status'] == 'HOLD_SOURCE_ONLY'
pins = dict(parent['source_pins'])
for name, digest in pins.items(): assert sha((ROOT / name).read_bytes()) == digest, name
for name in [BASE.relative_to(ROOT).as_posix() + '/manifest.json',
             BASE.relative_to(ROOT).as_posix() + '/source-proof.json', REVIEW]:
    pins[name] = sha((ROOT / name).read_bytes())

fixture = 'resources/js/components/timesheets/timesheet-write-context.test.tsx'
raw = (BASE / 'new' / fixture).read_bytes()
old = b'''        let original: TimesheetWriteScope | null = null;
        let token: TimesheetWriteLease | null = null;
        let decision: boolean | null = null;'''
new = b'''        const capture: {
            scope: TimesheetWriteScope | null;
            token: TimesheetWriteLease | null;
            decision: boolean | null;
        } = { scope: null, token: null, decision: null };'''
assert raw.count(old) == 1
raw = raw.replace(old, new)
replacements = [
    (b'original = scope;', b'capture.scope = scope;'),
    (b'token = scope.tryPrepare(7);', b'capture.token = scope.tryPrepare(7);'),
    (b'if (!token)', b'if (!capture.token)'),
    (b'scope.markInvoked(token)', b'scope.markInvoked(capture.token)'),
    (b'scope.markCallback(token)', b'scope.markCallback(capture.token)'),
    (b'toBe(original)', b'toBe(capture.scope)'),
    (b'decision = mode', b'capture.decision = mode'),
    (b'scope.canDispatch(token)', b'scope.canDispatch(capture.token)'),
    (b'scope.completeMatched(token)', b'scope.completeMatched(capture.token)'),
    (b'expect(original)', b'expect(capture.scope)'),
    (b'expect(decision)', b'expect(capture.decision)'),
    (b'original!.snapshot()', b'capture.scope!.snapshot()'),
    (b'original!.tryPrepare(8)', b'capture.scope!.tryPrepare(8)'),
]
for old, new in replacements:
    assert old in raw, old
    raw = raw.replace(old, new)
assert b'let original:' not in raw and b'let token:' not in raw and b'let decision:' not in raw
assert raw.count(b'it.each(') == 1
files, paths = {}, []
unchanged = []
for entry in parent['paths']:
    name = entry['path']
    before = (BASE / 'new' / name).read_bytes()
    after = raw if name == fixture else before
    if name != fixture: unchanged.append(name)
    assert not (ROOT / name).exists(), name
    emit('new/' + name, after); files['new/' + name] = sha(after)
    paths.append({'path': name, 'before_exists': False, 'before_sha256': sha(b''),
                  'parent_sha256': sha(before), 'after_sha256': sha(after)})
    for prefix, prior in [('raw-transitions', b''), ('parent-transitions', before)]:
        transition = {'path': name, 'before_hex': prior.hex(), 'after_hex': after.hex()}
        assert bytes.fromhex(transition['before_hex']) == prior
        assert bytes.fromhex(transition['after_hex']) == after
        target = prefix + '/' + name + '.json'
        emit(target, encoded(transition)); files[target] = sha((OUT / target).read_bytes())
assert len(unchanged) == 3
inventory = parent['inventory']
readme = '''Inactive fixture-only R3 successor. Preserves R1 HOLD and R2 HOLD as separate immutable evidence.

The provider dataset now captures scope/token/decision in an explicitly typed mutable holder, instead of outer locals initialized to null whose callback assignments are invisible to TypeScript control-flow analysis. Callback-local non-null token checks remain before every original owner operation. The two preparation/completion child-layout actor-change source cases and assertions are unchanged in purpose. Scope/context/unit product source images are exact to R2: finite notification batch, callback requirement, committed-actor insertion publication remain intact. No compiler or test execution/type-pass claim.

Four new app paths remain absent, four complete raw addition inverses plus four parent transitions. All12 original unit declarations remain retained;2 added unit declarations plus2 React dataset cases remain16 prospective source slots UNRUN, actual inventory/count null. Prior69 caller fixtures are separate and unchanged. No owning hook/Index/direct bulk/archive/restore/read/correction/Action/View/Roster/MyDay integration, exact visit adapter, server authority/UUID/receipt/durable producer/root/witness or page recovery is implemented. Source-shape coherence is not user workflow acceptance. No app edits/parser/types/framework/native/build/browser/process/readiness/SQL/Git/deploy/probe/admission; independent Claude/eMAR/Control Room and environmental hold unchanged.
'''
for name, value in [('README.md', readme.encode()), ('source-pins.json', encoded(pins)),
                    ('inventory.json', encoded(inventory)), ('author.py', Path(__file__).read_bytes())]:
    emit(name, value); files[name] = sha(value)
proof = {'status': 'PURE_SOURCE_FREEZE_ONLY', 'files': files, 'source_pins': pins,
    'unchanged_parent_images': unchanged, 'new_paths_still_absent': True,
    'raw_addition_inverses_exact': 4, 'parent_transitions_exact': 4,
    'input_drift': [], 'applied': False, 'runtime_invoked': False, 'actual_count': None}
raw = encoded(proof); emit('source-proof.json', raw)
manifest = {'status': 'UNAPPLIED_UNRUN_COORDINATION_PROVIDER_FIXTURE_R3_ONLY',
    'parent_manifest_sha256': sha((BASE / 'manifest.json').read_bytes()),
    'parent_hold_review_sha256': pins[REVIEW], 'paths': paths, 'files': files,
    'source_pins': pins, 'inventory': inventory, 'source_proof_sha256': sha(raw),
    'applied': False, 'runtime_invoked': False, 'owning_integration_implemented': False, 'actual_count': None}
raw = encoded(manifest); emit('manifest.json', raw)
print(json.dumps({'manifest_sha256': sha(raw), 'source_proof_sha256': manifest['source_proof_sha256'],
                  'unchanged_product_images': len(unchanged), 'source_slots_unrun': 16,
                  'actual_count': None, 'applied': False}))
