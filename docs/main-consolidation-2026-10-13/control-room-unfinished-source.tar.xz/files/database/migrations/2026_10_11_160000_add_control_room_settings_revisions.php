<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        foreach (['control_room_signal_rules', 'control_room_triage_queues', 'control_room_maintenance_windows'] as $table) {
            Schema::table($table, fn (Blueprint $blueprint) => $blueprint->unsignedBigInteger('settings_revision')->default(1));
        }
    }

    public function down(): void
    {
        foreach (['control_room_signal_rules', 'control_room_triage_queues', 'control_room_maintenance_windows'] as $table) {
            Schema::table($table, fn (Blueprint $blueprint) => $blueprint->dropColumn('settings_revision'));
        }
    }
};
