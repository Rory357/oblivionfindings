<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('control_room_alert_reporting_decisions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('alert_id')->constrained('control_room_alerts', indexName: 'cr_reporting_alert_fk')->restrictOnDelete();
            $table->unsignedInteger('revision');
            $table->uuid('command_id');
            $table->char('command_hash', 64);
            $table->string('state', 24);
            $table->text('reason');
            $table->foreignId('actor_user_id')->nullable()->constrained('users', indexName: 'cr_reporting_actor_fk')->nullOnDelete();
            $table->char('source_signature', 64);
            $table->timestamp('decided_at');
            $table->unique(['alert_id', 'revision'], 'cr_reporting_revision_uq');
            $table->unique(['alert_id', 'command_id'], 'cr_reporting_command_uq');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('control_room_alert_reporting_decisions');
    }
};
