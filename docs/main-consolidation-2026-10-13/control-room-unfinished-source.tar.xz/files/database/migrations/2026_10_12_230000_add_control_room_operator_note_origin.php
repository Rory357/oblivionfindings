<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('control_room_operator_notes', function (Blueprint $table): void {
            // No historical backfill: a missing original context stays unproven.
            $table->json('operator_origin')->nullable();
        });
    }

    public function down(): void
    {
        Schema::table('control_room_operator_notes', function (Blueprint $table): void {
            $table->dropColumn('operator_origin');
        });
    }
};
