<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Models\AuditLog;
use App\Models\ControlRoom\ConfigOption;
use App\Models\ControlRoom\MaintenanceWindow;
use App\Models\ControlRoom\SignalRule;
use App\Models\ControlRoom\TriageQueue;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use App\Services\ControlRoom\ControlRoomSettingsRevisionService;
use Database\Seeders\RbacSeeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ControlRoomSettingsControllerTest extends TestCase
{
    use RefreshDatabase;

    protected User $admin;

    protected User $supportWorker;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RbacSeeder::class);

        $this->admin = User::factory()->create(['role' => 'admin', 'approved_at' => now()]);
        $this->admin->roles()->attach(Role::where('name', 'admin')->first());

        $this->supportWorker = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        $this->supportWorker->roles()->attach(Role::where('name', 'support_worker')->first());
    }

    public function test_index_requires_manage_permission(): void
    {
        $this->actingAs($this->supportWorker)
            ->get('/control-room/settings')
            ->assertForbidden();
    }

    public function test_index_renders_inertia_settings_page(): void
    {
        $this->actingAs($this->admin)
            ->get('/control-room/settings')
            ->assertOk()
            ->assertInertia(fn ($page) => $page
                ->component('control-room/settings')
                ->has('signalRules')
                ->has('triageQueues')
                ->has('maintenanceWindows')
                ->has('configOptions')
            );
    }

    public function test_site_scoped_manager_receives_only_approved_maintenance_and_actual_catalog_roles(): void
    {
        $site = Site::factory()->create();
        $other = Site::factory()->create();
        $manager = $this->siteManager($site);
        foreach ([[$site, 'scheduled'], [$site, 'completed'], [$other, 'scheduled'], [$other, 'completed']] as [$windowSite, $status]) {
            $this->maintenance($windowSite->id, $status);
        }
        $this->maintenance(null);

        $this->actingAs($manager)->get('/control-room/settings?tab=maintenance')->assertOk()
            ->assertInertia(fn ($page) => $page->component('control-room/settings')->where('activeTab', 'maintenance')
                ->where('canScheduleAllSites', false)->has('sites', 1)->where('sites.0.id', $site->id)
                ->has('maintenanceWindows', 2)->where('maintenanceWindows', fn ($rows) => collect($rows)->every(fn ($row) => (int) $row['site_id'] === $site->id))
                ->where('roleChoices', fn ($rows) => collect($rows)->pluck('value')->sort()->values()->all()
                    === Role::query()->pluck('name')->sort()->values()->all()));
    }

    public function test_outside_site_and_global_maintenance_cannot_be_edited_or_cancelled_by_scoped_manager(): void
    {
        $site = Site::factory()->create();
        $manager = $this->siteManager($site);
        foreach ([$this->maintenance(Site::factory()->create()->id), $this->maintenance(null)] as $window) {
            $this->actingAs($manager)->put("/control-room/settings/maintenance/{$window->id}", [
                'name' => 'Attempted move into my site', 'site_id' => $site->id,
                'starts_at' => now()->addHour()->toISOString(), 'ends_at' => now()->addHours(2)->toISOString(),
            ])->assertForbidden();
            $this->actingAs($manager)->post("/control-room/settings/maintenance/{$window->id}/cancel")->assertForbidden();
            $this->assertSame('scheduled', $window->fresh()->status);
            $this->assertNotSame('Attempted move into my site', $window->fresh()->name);
        }
    }

    public function test_maintenance_submission_revalidates_site_scope_and_requires_explicit_site_for_scoped_manager(): void
    {
        $site = Site::factory()->create();
        $manager = $this->siteManager($site);
        $data = ['name' => 'Site maintenance', 'starts_at' => now()->addHour()->toISOString(), 'ends_at' => now()->addHours(2)->toISOString()];
        $this->actingAs($manager)->post('/control-room/settings/maintenance', $data)->assertSessionHasErrors('site_id');
        $this->actingAs($manager)->post('/control-room/settings/maintenance', [...$data, 'site_id' => Site::factory()->create()->id])->assertForbidden();
        $this->assertDatabaseCount('control_room_maintenance_windows', 0);
        $this->actingAs($manager)->post('/control-room/settings/maintenance', [...$data, 'site_id' => $site->id])->assertRedirect();
        $this->assertDatabaseHas('control_room_maintenance_windows', ['name' => 'Site maintenance', 'site_id' => $site->id]);
    }

    public function test_queue_rejects_unknown_new_roles_and_sources_without_erasing_legacy_configuration(): void
    {
        $data = ['name' => 'Routing', 'code' => 'routing', 'tier' => 1, 'assigned_roles' => ['definitely_missing_role'], 'handle_sources' => ['invented_source']];
        $this->actingAs($this->admin)->post('/control-room/settings/queues', $data)->assertSessionHasErrors(['assigned_roles.0', 'handle_sources.0']);
        $this->assertDatabaseCount('control_room_triage_queues', 0);
        $queue = TriageQueue::query()->create([...$data, 'is_active' => true, 'assigned_users' => [$this->admin->id], 'handle_alert_types' => ['historical_type']]);
        $this->actingAs($this->admin)->put("/control-room/settings/queues/{$queue->id}", [...$data, 'name' => 'Reviewed routing', 'expected_version' => $this->version($queue)])->assertRedirect();
        $fresh = $queue->fresh();
        $this->assertSame(['definitely_missing_role'], $fresh->assigned_roles);
        $this->assertSame(['invented_source'], $fresh->handle_sources);
        $this->assertSame([$this->admin->id], $fresh->assigned_users);
        $this->assertSame(['historical_type'], $fresh->handle_alert_types);
    }

    public function test_automatic_escalation_requires_an_active_distinct_destination(): void
    {
        $queue = TriageQueue::query()->create(['name' => 'First', 'code' => 'first', 'tier' => 1, 'is_active' => true]);
        $inactive = TriageQueue::query()->create(['name' => 'Inactive', 'code' => 'inactive', 'tier' => 2, 'is_active' => false]);
        $data = ['name' => $queue->name, 'code' => $queue->code, 'tier' => 1, 'auto_escalate_after_minutes' => 5];
        foreach ([null, $queue->id, $inactive->id] as $destination) {
            $this->actingAs($this->admin)->put("/control-room/settings/queues/{$queue->id}", [...$data, 'escalate_to_queue_id' => $destination, 'expected_version' => $this->version($queue)])
                ->assertSessionHasErrors('escalate_to_queue_id');
        }
        $this->assertNull($queue->fresh()->auto_escalate_after_minutes);
    }

    public function test_editing_rule_preserves_unedited_notification_candidates(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50, 'is_active' => true,
            'notify_roles' => ['admin'], 'notify_users' => [$this->admin->id]]);
        $this->actingAs($this->admin)->put("/control-room/settings/rules/{$rule->id}", ['name' => 'Reviewed', 'priority' => 20, 'expected_version' => $this->version($rule)])->assertRedirect();
        $this->assertSame(['admin'], $rule->fresh()->notify_roles);
        $this->assertSame([$this->admin->id], $rule->fresh()->notify_users);
    }

    private function siteManager(Site $site): User
    {
        $manager = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        $manager->roles()->sync([Role::query()->where('name', 'support_worker')->sole()->id]);
        $manager->permissionOverrides()->sync(Permission::query()->where('key', 'controlRoom.alerts.manage')->pluck('id')
            ->mapWithKeys(fn ($id): array => [$id => ['allowed' => true]]));
        HrEmployeeProfile::factory()->create(['user_id' => $manager->id, 'primary_site_id' => $site->id,
            'secondary_site_ids' => [], 'position_role' => 'support_worker', 'is_active' => true,
            'start_date' => today()->subYear(), 'created_by' => $manager->id, 'updated_by' => $manager->id]);

        return $manager;
    }

    private function maintenance(?int $siteId, string $status = 'scheduled'): MaintenanceWindow
    {
        return MaintenanceWindow::query()->create(['name' => "Maintenance {$siteId} {$status}", 'site_id' => $siteId,
            'status' => $status, 'starts_at' => $status === 'completed' ? now()->subHour() : now()->addHour(),
            'ends_at' => $status === 'completed' ? now()->subMinute() : now()->addHours(2), 'created_by_user_id' => $this->admin->id]);
    }

    private function version(Model $record): string
    {
        return app(ControlRoomSettingsRevisionService::class)->version($record->fresh());
    }

    public function test_two_rule_readers_cannot_overwrite_newer_hidden_notification_routing(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50, 'notify_roles' => ['admin'], 'notify_users' => [$this->admin->id]]);
        $firstVersion = $this->version($rule);
        $secondVersion = $this->version($rule);
        $url = "/control-room/settings/rules/{$rule->id}";
        $this->actingAs($this->admin)->putJson($url, ['name' => 'First saved', 'priority' => 10,
            'notify_roles' => ['support_worker'], 'notify_users' => [$this->supportWorker->id], 'expected_version' => $firstVersion])->assertRedirect();
        $this->putJson($url, ['name' => 'Second draft', 'priority' => 50, 'expected_version' => $secondVersion])
            ->assertStatus(409)->assertJsonPath('code', 'settings_conflict')->assertJsonPath('current.name', 'First saved')
            ->assertJsonPath('current.notify_roles', ['support_worker'])->assertJsonPath('current.notify_users', [$this->supportWorker->id]);
        $this->assertSame('First saved', $rule->fresh()->name);
        $this->assertSame(['support_worker'], $rule->fresh()->notify_roles);
        $this->putJson($url, ['name' => 'Second reviewed', 'priority' => 10, 'expected_version' => $this->version($rule)])->assertRedirect();
        $this->assertSame('Second reviewed', $rule->fresh()->name);
        $this->assertSame([$this->supportWorker->id], $rule->fresh()->notify_users);
        $this->assertSame(3, (int) $rule->fresh()->settings_revision);
    }

    public function test_two_queue_readers_cannot_replace_newer_named_routing_or_alert_types(): void
    {
        $queue = TriageQueue::query()->create(['name' => 'Routing', 'code' => 'routing-version', 'tier' => 1,
            'assigned_users' => [$this->admin->id], 'handle_alert_types' => ['historical_type']]);
        $oldVersion = $this->version($queue);
        $url = "/control-room/settings/queues/{$queue->id}";
        $this->actingAs($this->admin)->putJson($url, ['name' => 'New saved routing', 'code' => $queue->code, 'tier' => 2,
            'assigned_users' => [$this->supportWorker->id], 'handle_alert_types' => ['current_type'], 'expected_version' => $oldVersion])->assertRedirect();
        $this->putJson($url, ['name' => 'Older draft', 'code' => $queue->code, 'tier' => 1, 'assigned_users' => [$this->admin->id],
            'handle_alert_types' => ['historical_type'], 'expected_version' => $oldVersion])->assertStatus(409)
            ->assertJsonPath('current.tier', 2)->assertJsonPath('current.handle_alert_types', ['current_type']);
        $this->assertSame([$this->supportWorker->id], $queue->fresh()->assigned_users);
        $this->assertSame(['current_type'], $queue->fresh()->handle_alert_types);
    }

    public function test_maintenance_edit_and_cancel_require_the_current_reviewed_interval(): void
    {
        $window = $this->maintenance(null);
        $oldVersion = $this->version($window);
        $url = "/control-room/settings/maintenance/{$window->id}";
        $starts = now()->addHours(4)->toISOString();
        $ends = now()->addHours(6)->toISOString();
        $this->actingAs($this->admin)->putJson($url, ['name' => 'New interval', 'starts_at' => $starts, 'ends_at' => $ends,
            'expected_version' => $oldVersion])->assertRedirect();
        $this->putJson($url, ['name' => 'Old interval draft', 'starts_at' => now()->addHour()->toISOString(),
            'ends_at' => now()->addHours(2)->toISOString(), 'expected_version' => $oldVersion])->assertStatus(409)
            ->assertJsonPath('current.name', 'New interval');
        $this->postJson($url.'/cancel', ['expected_version' => $oldVersion])->assertStatus(409);
        $this->assertTrue($window->fresh()->starts_at->equalTo($starts));
        $this->assertSame('scheduled', $window->fresh()->status);
        $this->postJson($url.'/cancel', ['expected_version' => $this->version($window)])->assertRedirect();
        $this->assertSame('cancelled', $window->fresh()->status);
    }

    public function test_same_second_change_and_return_to_original_values_does_not_restore_an_old_version(): void
    {
        $this->freezeTime();
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $oldVersion = $this->version($rule);
        $url = "/control-room/settings/rules/{$rule->id}";
        $this->actingAs($this->admin)->putJson($url, ['name' => 'Temporary', 'priority' => 50, 'expected_version' => $oldVersion])->assertRedirect();
        $this->putJson($url, ['name' => 'Original', 'priority' => 50, 'expected_version' => $this->version($rule)])->assertRedirect();
        $this->assertNotSame($oldVersion, $this->version($rule));
        $this->putJson($url, ['name' => 'Stale reader', 'priority' => 50, 'expected_version' => $oldVersion])->assertStatus(409);
        $this->assertSame('Original', $rule->fresh()->name);
    }

    public function test_inertia_conflict_returns_errors_and_fresh_saved_props_without_success(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $oldVersion = $this->version($rule);
        $url = "/control-room/settings/rules/{$rule->id}";
        $this->actingAs($this->admin)->put($url, ['name' => 'Colleague saved', 'priority' => 20, 'expected_version' => $oldVersion])->assertRedirect();
        $this->from('/control-room/settings?tab=rules')->withHeader('X-Inertia', 'true')
            ->put($url, ['name' => 'My retained draft', 'priority' => 50, 'expected_version' => $oldVersion])
            ->assertRedirect('/control-room/settings?tab=rules')->assertSessionHasErrors('save_conflict')->assertSessionMissing('success');
        $this->get('/control-room/settings?tab=rules')->assertInertia(fn ($page) => $page->component('control-room/settings')
            ->where('signalRules.0.name', 'Colleague saved')->where('signalRules.0.version', $this->version($rule)));
        $this->assertSame('Colleague saved', $rule->fresh()->name);
    }

    public function test_missing_version_and_failed_validation_do_not_advance_the_revision_and_allow_explicit_retry(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $version = $this->version($rule);
        $url = "/control-room/settings/rules/{$rule->id}";
        $this->actingAs($this->admin)->putJson($url, ['name' => 'Unchecked', 'priority' => 20])->assertUnprocessable()->assertJsonValidationErrors('expected_version');
        $this->putJson($url, ['name' => '', 'priority' => 20, 'expected_version' => $version])->assertUnprocessable()->assertJsonValidationErrors('name');
        $this->assertSame($version, $this->version($rule));
        $this->assertSame('Original', $rule->fresh()->name);
        $this->putJson($url, ['name' => 'Reviewed retry', 'priority' => 20, 'expected_version' => $version])->assertRedirect();
        $this->assertSame('Reviewed retry', $rule->fresh()->name);
    }

    public function test_failed_audit_rolls_back_setting_and_version_before_a_reviewed_retry(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $version = $this->version($rule);
        $dispatcher = Model::getEventDispatcher();
        Model::setEventDispatcher(clone $dispatcher);
        AuditLog::creating(static function (AuditLog $audit): void {
            if ($audit->action === 'controlRoom.settings.rule.update') {
                throw new \RuntimeException('Injected settings audit failure.');
            }
        });
        $this->withoutExceptionHandling();
        $caught = null;
        try {
            $this->actingAs($this->admin)->put("/control-room/settings/rules/{$rule->id}", [
                'name' => 'Must roll back', 'priority' => 20, 'expected_version' => $version,
            ]);
        } catch (\RuntimeException $exception) {
            $caught = $exception;
        } finally {
            Model::setEventDispatcher($dispatcher);
            $this->withExceptionHandling();
        }
        $this->assertSame('Injected settings audit failure.', $caught?->getMessage());
        $this->assertSame('Original', $rule->fresh()->name);
        $this->assertSame($version, $this->version($rule));
        $this->assertDatabaseMissing('audit_logs', ['action' => 'controlRoom.settings.rule.update', 'auditable_id' => $rule->id]);
        $this->put("/control-room/settings/rules/{$rule->id}", ['name' => 'Reviewed retry', 'priority' => 20, 'expected_version' => $version])->assertRedirect();
        $this->assertSame('Reviewed retry', $rule->fresh()->name);
    }

    public function test_an_audit_save_veto_rolls_back_the_setting_and_revision_before_a_valid_retry(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $version = $this->version($rule);
        $original = $rule->fresh()->getRawOriginal();
        $dispatcher = Model::getEventDispatcher();
        Model::setEventDispatcher(clone $dispatcher);
        AuditLog::creating(fn (AuditLog $audit) => $audit->action === 'controlRoom.settings.rule.update' ? false : null);
        $this->withoutExceptionHandling();
        $caught = null;
        try {
            $this->actingAs($this->admin)->put("/control-room/settings/rules/{$rule->id}", [
                'name' => 'Refused audit draft', 'priority' => 20, 'expected_version' => $version,
            ]);
        } catch (\RuntimeException $exception) {
            $caught = $exception;
        } finally {
            Model::setEventDispatcher($dispatcher);
            $this->withExceptionHandling();
        }
        $this->assertSame('The audit record could not be saved.', $caught?->getMessage());
        $this->assertSame($original, $rule->fresh()->getRawOriginal());
        $this->assertSame($version, $this->version($rule));
        $this->assertDatabaseMissing('audit_logs', ['action' => 'controlRoom.settings.rule.update', 'auditable_id' => $rule->id]);
        $this->put("/control-room/settings/rules/{$rule->id}", [
            'name' => 'Reviewed retry', 'priority' => 20, 'expected_version' => $version,
        ])->assertRedirect();
        $this->assertSame('Reviewed retry', $rule->fresh()->name);
        $this->assertNotSame($version, $this->version($rule));
        $this->assertDatabaseHas('audit_logs', ['action' => 'controlRoom.settings.rule.update', 'auditable_id' => $rule->id]);
    }

    public function test_vetoed_setting_save_and_delete_keep_the_original_version_without_a_success_audit(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $version = $this->version($rule);
        $original = $rule->fresh()->getRawOriginal();
        $url = "/control-room/settings/rules/{$rule->id}";
        $this->actingAs($this->admin);

        foreach (['update', 'delete'] as $operation) {
            $dispatcher = Model::getEventDispatcher();
            Model::setEventDispatcher(clone $dispatcher);
            $vetoed = false;
            $veto = function (SignalRule $current) use ($rule, &$vetoed): ?bool {
                if ((int) $current->id === (int) $rule->id) {
                    $vetoed = true;

                    return false;
                }

                return null;
            };
            if ($operation === 'update') {
                SignalRule::saving($veto);
            } else {
                SignalRule::deleting($veto);
            }
            $this->withoutExceptionHandling();
            $caught = null;
            try {
                if ($operation === 'update') {
                    $this->put($url, ['name' => 'Refused draft', 'priority' => 20, 'expected_version' => $version]);
                } else {
                    $this->delete($url, ['expected_version' => $version]);
                }
            } catch (\RuntimeException $exception) {
                $caught = $exception;
            } finally {
                Model::setEventDispatcher($dispatcher);
                $this->withExceptionHandling();
            }

            $this->assertTrue($vetoed, 'A real Eloquent event must veto the mutation.');
            $this->assertSame($operation === 'update'
                ? 'The setting could not be saved. Your draft has been kept.'
                : 'The setting could not be deleted. The saved setting has been kept.', $caught?->getMessage());
            $this->assertSame($original, $rule->fresh()->getRawOriginal());
            $this->assertSame($version, $this->version($rule));
            $this->assertDatabaseMissing('audit_logs', ['action' => 'controlRoom.settings.rule.'.$operation, 'auditable_id' => $rule->id]);
        }
        $this->put($url, ['name' => 'Reviewed retry', 'priority' => 20, 'expected_version' => $version])->assertRedirect();
        $this->assertSame('Reviewed retry', $rule->fresh()->name);
    }

    public function test_delete_refuses_an_old_rule_version_after_a_colleague_changes_it(): void
    {
        $rule = SignalRule::query()->create(['name' => 'Original', 'priority' => 50]);
        $oldVersion = $this->version($rule);
        $url = "/control-room/settings/rules/{$rule->id}";
        $this->actingAs($this->admin)->putJson($url, ['name' => 'New saved rule', 'priority' => 10, 'expected_version' => $oldVersion])->assertRedirect();
        $this->deleteJson($url, ['expected_version' => $oldVersion])->assertStatus(409)->assertJsonPath('current.name', 'New saved rule');
        $this->assertDatabaseHas('control_room_signal_rules', ['id' => $rule->id, 'name' => 'New saved rule']);
    }

    // ── Signal rules ─────────────────────────────────────

    public function test_store_signal_rule_creates_rule(): void
    {
        $this->actingAs($this->admin)
            ->post('/control-room/settings/rules', [
                'name' => 'Critical to T1',
                'priority' => 10,
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('control_room_signal_rules', [
            'name' => 'Critical to T1',
            'priority' => 10,
        ]);
    }

    public function test_store_signal_rule_validates_required(): void
    {
        $this->actingAs($this->admin)
            ->post('/control-room/settings/rules', [])
            ->assertSessionHasErrors(['name', 'priority']);
    }

    public function test_delete_signal_rule_removes_record(): void
    {
        $rule = SignalRule::create([
            'name' => 'To delete',
            'priority' => 50,
            'is_active' => true,
        ]);

        $this->actingAs($this->admin)
            ->delete("/control-room/settings/rules/{$rule->id}", ['expected_version' => $this->version($rule)])
            ->assertRedirect();

        $this->assertDatabaseMissing('control_room_signal_rules', ['id' => $rule->id]);
    }

    // ── Triage queues ────────────────────────────────────

    public function test_store_queue_creates_record(): void
    {
        $this->actingAs($this->admin)
            ->post('/control-room/settings/queues', [
                'name' => 'Tier 1',
                'code' => 'tier-1',
                'tier' => 1,
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('control_room_triage_queues', [
            'name' => 'Tier 1',
            'code' => 'tier-1',
        ]);
    }

    public function test_store_queue_rejects_duplicate_code(): void
    {
        TriageQueue::create([
            'name' => 'First',
            'code' => 'taken',
            'tier' => 1,
            'is_active' => true,
        ]);

        $this->actingAs($this->admin)
            ->post('/control-room/settings/queues', [
                'name' => 'Duplicate',
                'code' => 'taken',
                'tier' => 2,
            ])
            ->assertSessionHasErrors('code');
    }

    // ── Maintenance windows ──────────────────────────────

    public function test_store_maintenance_window_schedules(): void
    {
        $this->actingAs($this->admin)
            ->post('/control-room/settings/maintenance', [
                'name' => 'Patch Tuesday',
                'starts_at' => now()->addHour()->toDateTimeString(),
                'ends_at' => now()->addHours(3)->toDateTimeString(),
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('control_room_maintenance_windows', [
            'name' => 'Patch Tuesday',
            'status' => 'scheduled',
        ]);
    }

    public function test_store_maintenance_window_rejects_past_start(): void
    {
        $this->actingAs($this->admin)
            ->post('/control-room/settings/maintenance', [
                'name' => 'Past',
                'starts_at' => now()->subHour()->toDateTimeString(),
                'ends_at' => now()->addHour()->toDateTimeString(),
            ])
            ->assertSessionHasErrors('starts_at');
    }

    public function test_cancel_maintenance_window_marks_cancelled(): void
    {
        $window = MaintenanceWindow::create([
            'name' => 'To cancel',
            'starts_at' => now()->addHour(),
            'ends_at' => now()->addHours(2),
            'status' => 'scheduled',
            'created_by_user_id' => $this->admin->id,
        ]);

        $this->actingAs($this->admin)
            ->post("/control-room/settings/maintenance/{$window->id}/cancel", ['expected_version' => $this->version($window)])
            ->assertRedirect();

        $this->assertSame('cancelled', $window->fresh()->status);
    }

    public function test_cancel_maintenance_window_rejects_completed(): void
    {
        $window = MaintenanceWindow::create([
            'name' => 'Already done',
            'starts_at' => now()->subHours(3),
            'ends_at' => now()->subHour(),
            'status' => 'completed',
            'created_by_user_id' => $this->admin->id,
        ]);

        $this->actingAs($this->admin)
            ->post("/control-room/settings/maintenance/{$window->id}/cancel")
            ->assertStatus(422);
    }

    // ── Config options ───────────────────────────────────

    public function test_store_config_option_creates_record(): void
    {
        $this->actingAs($this->admin)
            ->post('/control-room/settings/options', [
                'group' => 'category',
                'value' => 'fire',
                'label' => 'Fire',
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('control_room_config_options', [
            'group' => 'category',
            'value' => 'fire',
            'label' => 'Fire',
        ]);
    }

    public function test_delete_config_option_removes_record(): void
    {
        $option = ConfigOption::create([
            'group' => 'category',
            'value' => 'temp',
            'label' => 'Temp',
            'is_active' => true,
            'sort_order' => 1,
        ]);

        $this->actingAs($this->admin)
            ->delete("/control-room/settings/options/{$option->id}")
            ->assertRedirect();

        $this->assertDatabaseMissing('control_room_config_options', ['id' => $option->id]);
    }
}
