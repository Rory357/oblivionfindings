<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Models\AuditLog;
use App\Models\ControlRoom\AlertSla;
use App\Models\ControlRoom\OperatorNote;
use App\Models\ControlRoom\SlaDefinition;
use App\Models\ControlRoomAlert;
use App\Models\Permission;
use App\Models\Site;
use App\Models\User;
use App\Services\ControlRoom\AlertWorkspaceService;
use App\Services\ControlRoom\ControlRoomAlertLifecycleService;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use App\Services\ControlRoom\ControlRoomSourceContentService;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use InvalidArgumentException;
use PHPUnit\Framework\Attributes\DataProvider;
use RuntimeException;
use Tests\TestCase;

/** Persisted operator-origin identity and checked writer regressions. Authored, runtime UNRUN. */
class ControlRoomOperatorRootNoteTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;

    private User $actor;

    private ControlRoomAlert $alert;

    protected function setUp(): void
    {
        parent::setUp();
        Queue::fake();
        $this->seed(RbacSeeder::class);
        $this->site = Site::factory()->create(['is_active' => true]);
        $this->actor = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        HrEmployeeProfile::factory()->create(['user_id' => $this->actor->id, 'primary_site_id' => $this->site->id,
            'secondary_site_ids' => [], 'is_active' => true, 'start_date' => now('Pacific/Auckland')->subYear()->toDateString(), 'end_date' => null]);
        foreach (['controlRoom.alerts.view', 'controlRoom.alerts.manage'] as $key) {
            $this->actor->permissionOverrides()->attach(Permission::where('key', $key)->sole(), ['allowed' => true]);
        }
        $this->alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'source' => 'operations', 'alert_type' => 'operations.workplace_injury', 'site_id' => $this->site->id,
            'client_id' => null, 'status' => ControlRoomAlert::STATUS_TRIAGING, 'notes' => null,
            'context' => ['workplace_injury_id' => null],
        ]));
    }

    public function test_resolution_binds_actual_persisted_note_actor_alert_digest_and_activity(): void
    {
        $resolved = $this->resolve();
        $note = OperatorNote::where('alert_id', $this->alert->id)->sole();
        $this->assertSame('Independent operator response', $note->content);
        $this->assertSame($this->actor->id, $note->user_id);
        $this->assertSame(OperatorNote::TYPE_DECISION, $note->type);
        $expected = ['version' => 1, 'source' => 'operator_note', 'operator_note_id' => $note->id,
            'alert_id' => $resolved->id, 'actor_user_id' => $this->actor->id, 'text_sha256' => hash('sha256', $note->content),
        ];
        foreach ($expected as $key => $value) {
            $this->assertSame($value, $resolved->context['root_note_origin'][$key]);
        }
        $this->assertSame($note->id, collect($resolved->context['activity_log'])->last()['operator_note_id']);
        $this->assertTrue(AuditLog::where('action', 'controlRoom.alert.resolve')->where('auditable_id', $resolved->id)->exists());
    }

    public function test_proved_independent_root_is_visible_and_searchable_when_medical_source_is_unavailable(): void
    {
        $this->resolve();
        $workspace = $this->workspace();
        $this->assertSame('Independent operator response', $workspace['alert']['notes']);
        $this->assertSame('readable', $workspace['alert']['notes_access']);
        $this->assertArrayNotHasKey('root_note_origin', $workspace['alert']['context']);
        $this->assertSame([$this->alert->id], $this->search('Independent operator response'));
    }

    public function test_marker_without_persisted_note_does_not_authorize_text_or_search(): void
    {
        $this->alert->updateQuietly(['notes' => 'PRIVATE-FORGED-ORIGIN', 'context' => $this->alert->context + ['root_note_origin' => [
            'version' => 1, 'source' => 'operator_note', 'operator_note_id' => 999999, 'alert_id' => $this->alert->id,
            'actor_user_id' => $this->actor->id, 'text_sha256' => hash('sha256', 'PRIVATE-FORGED-ORIGIN'),
        ]]]);
        $this->assertWithheld('PRIVATE-FORGED-ORIGIN');
    }

    public function test_edited_or_missing_actual_note_invalidates_origin_even_if_marker_is_unchanged(): void
    {
        $this->resolve();
        $note = OperatorNote::where('alert_id', $this->alert->id)->sole();
        $note->update(['content' => 'Edited typed note']);
        $this->assertWithheld('Independent operator response');
        $note->delete();
        $this->assertWithheld('Independent operator response');
    }

    public function test_wrong_alert_actor_or_note_classification_cannot_supply_origin(): void
    {
        $this->resolve();
        $note = OperatorNote::where('alert_id', $this->alert->id)->sole();
        $other = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create(['site_id' => $this->site->id]));
        $note->update(['alert_id' => $other->id]);
        $this->assertWithheld('Independent operator response');
        $note->update(['alert_id' => $this->alert->id, 'user_id' => User::factory()->create()->id]);
        $this->assertWithheld('Independent operator response');
        $note->update(['user_id' => $this->actor->id, 'type' => OperatorNote::TYPE_NOTE]);
        $this->assertWithheld('Independent operator response');
    }

    public function test_changed_text_source_overwrite_cannot_borrow_old_operator_origin(): void
    {
        $this->resolve();
        $this->alert->updateQuietly(['notes' => 'PRIVATE-SOURCE-REPLACEMENT']);
        $this->assertWithheld('PRIVATE-SOURCE-REPLACEMENT');
    }

    public function test_same_text_source_ownership_requires_atomic_operator_origin_invalidation(): void
    {
        $this->resolve();
        // Source-writer contract fixture only. Canonical H&S writer implementation is owner-owned/pending.
        DB::transaction(function (): void {
            $locked = ControlRoomAlert::whereKey($this->alert->id)->lockForUpdate()->sole();
            $context = $locked->context;
            unset($context['root_note_origin']);
            $locked->updateQuietly(['notes' => 'Independent operator response', 'context' => $context]);
        });
        $this->assertWithheld('Independent operator response');
        $this->assertSame(1, OperatorNote::where('alert_id', $this->alert->id)->count());
    }

    public function test_existing_nonnull_source_root_and_empty_string_are_never_reclassified(): void
    {
        foreach (['PRIVATE-LEGACY-SOURCE', ''] as $text) {
            $this->alert->updateQuietly(['status' => ControlRoomAlert::STATUS_TRIAGING, 'notes' => $text]);
            $resolved = $this->resolve();
            $this->assertSame($text, $resolved->notes);
            $this->assertArrayNotHasKey('root_note_origin', $resolved->context);
            $this->assertNull($this->workspace()['alert']['notes']);
        }
    }

    public function test_note_creation_event_veto_rolls_back_resolution_and_retry_has_one_note(): void
    {
        $veto = true;
        OperatorNote::creating(function () use (&$veto) {
            return ! $veto;
        });
        $this->assertRollback(fn () => $this->resolve());
        $veto = false;
        $this->resolve();
        $this->assertSame(1, OperatorNote::where('alert_id', $this->alert->id)->count());
        try {
            $this->resolve();
            $this->fail('A terminal retry must not create another operator note.');
        } catch (InvalidArgumentException) {
            $this->assertSame(1, OperatorNote::where('alert_id', $this->alert->id)->count());
        }
    }

    public function test_alert_save_event_veto_rolls_back_note_activity_reference_and_audit(): void
    {
        $veto = true;
        $id = $this->alert->id;
        ControlRoomAlert::saving(fn ($alert) => ! ($veto && $alert->id === $id && $alert->status === ControlRoomAlert::STATUS_RESOLVED));
        $this->assertRollback(fn () => $this->resolve());
    }

    public function test_mandatory_audit_save_veto_rolls_back_note_activity_reference_and_status(): void
    {
        AuditLog::creating(fn ($audit) => $audit->action !== 'controlRoom.alert.resolve');
        $this->assertRollback(fn () => $this->resolve());
    }

    public function test_typed_note_append_save_veto_leaves_no_orphan_note_or_activity(): void
    {
        $id = $this->alert->id;
        ControlRoomAlert::saving(fn ($alert) => $alert->id !== $id);
        $this->assertRollback(fn () => app(ControlRoomAlertLifecycleService::class)->appendOperatorNote(
            $this->alert, $this->actor, 'Independent typed note', 'operator_note'));
    }

    public function test_operator_origin_does_not_bypass_current_alert_site_in_search(): void
    {
        $this->resolve();
        $this->actor->hrEmployeeProfile->update(['primary_site_id' => Site::factory()->create(['is_active' => true])->id]);
        $this->assertSame([], $this->search('Independent operator response'));
    }

    public function test_successful_save_that_drops_new_resolution_activity_reaches_audit_and_rolls_back(): void
    {
        $this->priorActivity();
        $saved = $audited = 0;
        $id = $this->alert->id;
        ControlRoomAlert::saving(function ($alert) use ($id, &$saved) {
            if ($alert->id === $id && $alert->status === ControlRoomAlert::STATUS_RESOLVED) {
                $saved++;
                $context = $alert->context;
                array_pop($context['activity_log']);
                $alert->context = $context;
            }

            return true;
        });
        AuditLog::created(function ($audit) use (&$audited, $id) {
            if ($audit->action === 'controlRoom.alert.resolve' && (int) $audit->auditable_id === $id) {
                $audited++;
            }
        });
        $this->assertRollback(fn () => $this->resolve());
        $this->assertSame(1, $saved);
        $this->assertSame(1, $audited, 'The successful save must reach the late audit, then fail final verification.');
    }

    public function test_successful_saved_callback_that_rewrites_prior_history_rolls_back(): void
    {
        $this->priorActivity();
        $reached = $audited = 0;
        $id = $this->alert->id;
        ControlRoomAlert::saved(function ($alert) use ($id, &$reached) {
            if ($alert->id === $id && $alert->status === ControlRoomAlert::STATUS_RESOLVED) {
                $reached++;
                $context = $alert->context;
                $context['activity_log'][0]['content'] = 'Rewritten prior history';
                DB::table('control_room_alerts')->where('id', $id)->update(['context' => json_encode($context)]);
            }

            return true;
        });
        AuditLog::created(function ($audit) use (&$audited, $id) {
            if ($audit->action === 'controlRoom.alert.resolve' && (int) $audit->auditable_id === $id) {
                $audited++;
            }
        });
        $this->assertRollback(fn () => $this->resolve());
        $this->assertSame(1, $reached);
        $this->assertSame(1, $audited);
    }

    public function test_successful_append_save_with_changed_activity_link_reaches_audit_and_rolls_back(): void
    {
        $this->priorActivity('PRIVATE-LEGACY-SOURCE');
        $reached = $audited = 0;
        $id = $this->alert->id;
        ControlRoomAlert::saving(function ($alert) use ($id, &$reached) {
            if ($alert->id === $id) {
                $reached++;
                $context = $alert->context;
                $last = array_key_last($context['activity_log']);
                $context['activity_log'][$last]['operator_note_id'] = 999999;
                $context['activity_log'][$last]['transition'] = 'Unexpected transition';
                $alert->context = $context;
            }

            return true;
        });
        AuditLog::created(function ($audit) use (&$audited, $id) {
            if ($audit->action === 'controlRoom.alert.addNote' && (int) $audit->auditable_id === $id) {
                $audited++;
            }
        });
        $this->assertRollback(fn () => $this->append());
        $this->assertSame(1, $reached);
        $this->assertSame(1, $audited);
    }

    public static function lateMutations(): array
    {
        $cases = [];
        foreach (['note_content', 'note_actor', 'note_type', 'note_purpose', 'note_origin', 'note_delete', 'root_text',
            'root_origin', 'status', 'resolved_at', 'resolved_actor', 'resolution_code', 'snoozed_until',
            'snoozed_actor', 'activity_link', 'activity_drop', 'activity_content', 'activity_actor',
            'activity_actor_name', 'activity_transition', 'activity_purpose', 'activity_time',
            'prior_history', 'audit_delete', 'audit_actor'] as $mutation) {
            $cases[$mutation] = [$mutation, null];
        }
        $cases['nonnull source root'] = ['root_text', 'PRIVATE-LEGACY-SOURCE'];
        $cases['empty string root'] = ['root_text', ''];
        $cases['nonnull source provenance'] = ['root_origin', 'PRIVATE-LEGACY-SOURCE'];

        return $cases;
    }

    #[DataProvider('lateMutations')]
    public function test_late_successful_audit_callback_cannot_change_final_resolution_tuple(string $mutation, ?string $root): void
    {
        $this->priorActivity($root);
        $reached = $this->lateAuditMutation('controlRoom.alert.resolve', $mutation);
        $this->assertRollback(fn () => $this->resolve());
        $this->assertSame(1, $reached->count, 'The actual late audit callback must execute successfully before final verification.');
    }

    #[DataProvider('lateMutations')]
    public function test_late_successful_audit_callback_cannot_change_final_append_tuple(string $mutation, ?string $root): void
    {
        $this->priorActivity($root);
        $reached = $this->lateAuditMutation('controlRoom.alert.addNote', $mutation);
        $this->assertRollback(fn () => $this->append());
        $this->assertSame(1, $reached->count);
    }

    public function test_actual_sla_saved_callback_that_changes_note_reaches_audit_and_rolls_back_cycle(): void
    {
        $definition = SlaDefinition::create(['name' => 'Operator final tuple SLA', 'code' => 'operator-final-tuple',
            'acknowledge_target_minutes' => 5, 'response_target_minutes' => 10, 'resolution_target_minutes' => 30, 'is_active' => true]);
        $sla = AlertSla::createFromDefinition($this->alert, $definition);
        $reached = $audited = 0;
        $id = $this->alert->id;
        AlertSla::saved(function ($saved) use (&$reached, $sla, $id) {
            if ($saved->id === $sla->id && $saved->resolved_at !== null) {
                $reached++;
                $this->assertSame(1, DB::table('control_room_operator_notes')->where('alert_id', $id)->count());
                DB::table('control_room_operator_notes')->where('alert_id', $id)->update(['content' => 'Changed during SLA callback']);
            }

            return true;
        });
        AuditLog::created(function ($audit) use (&$audited, $id) {
            if ($audit->action === 'controlRoom.alert.resolve' && (int) $audit->auditable_id === $id) {
                $audited++;
            }
        });
        $this->assertRollback(fn () => $this->resolve());
        $this->assertSame(1, $reached);
        $this->assertSame(1, $audited);
        $this->assertNull($sla->fresh()->resolved_at);
    }

    public function test_successful_append_preserves_prior_history_root_and_lifecycle_tuple(): void
    {
        $this->priorActivity('PRIVATE-LEGACY-SOURCE');
        $this->alert->updateQuietly(['snoozed_until' => now()->addHour(), 'snoozed_by_user_id' => $this->actor->id]);
        $before = $this->alert->fresh()->getRawOriginal();
        $note = $this->append();
        $after = $this->alert->fresh()->getRawOriginal();
        $history = $this->alert->fresh()->context['activity_log'];
        $this->assertCount(2, $history);
        $this->assertSame('Previous independent response', $history[0]['content']);
        $this->assertSame($note->id, $history[1]['operator_note_id']);
        $this->assertSame('Independent typed note', $history[1]['content']);
        foreach (['status', 'resolved_at', 'resolved_by_user_id', 'resolution_code', 'notes', 'snoozed_until', 'snoozed_by_user_id'] as $field) {
            $this->assertSame($before[$field], $after[$field]);
        }
    }

    private function priorActivity(?string $root = null): void
    {
        $context = $this->alert->fresh()->context;
        $context['activity_log'] = [['type' => 'lifecycle_note', 'transition' => 'acknowledge',
            'content' => 'Previous independent response', 'user_id' => $this->actor->id,
            'user_name' => $this->actor->name, 'created_at' => now()->subHour()->toIso8601String()]];
        $this->alert->updateQuietly(['notes' => $root, 'context' => $context]);
    }

    private function append(): OperatorNote
    {
        return app(ControlRoomAlertLifecycleService::class)->appendOperatorNote(
            $this->alert, $this->actor, 'Independent typed note', 'operator_note');
    }

    private function lateAuditMutation(string $action, string $mutation): object
    {
        $reached = (object) ['count' => 0];
        $id = $this->alert->id;
        $otherActorId = User::factory()->create()->id;
        AuditLog::created(function ($audit) use ($reached, $action, $mutation, $id, $otherActorId) {
            if ($audit->action !== $action || (int) $audit->auditable_id !== $id) {
                return true;
            }
            $reached->count++;
            $this->assertTrue($audit->exists);
            $note = DB::table('control_room_operator_notes')->where('alert_id', $id)->sole();
            $this->assertSame($action === 'controlRoom.alert.resolve' ? 'Independent operator response' : 'Independent typed note', $note->content);
            if (str_starts_with($mutation, 'note_')) {
                if ($mutation === 'note_delete') {
                    DB::table('control_room_operator_notes')->where('id', $note->id)->delete();
                } else {
                    $changes = match ($mutation) {
                        'note_content' => ['content' => 'Late changed note'],
                        'note_actor' => ['user_id' => $otherActorId],
                        'note_type' => ['type' => OperatorNote::TYPE_ESCALATION],
                        'note_purpose' => ['purpose' => OperatorNote::PURPOSE_IMMEDIATE_CONTROLS],
                        'note_origin' => ['operator_origin' => json_encode(['version' => 1, 'source' => 'independent_operator', 'site_id' => 999999])],
                    };
                    DB::table('control_room_operator_notes')->where('id', $note->id)->update($changes);
                }
            } elseif (str_starts_with($mutation, 'audit_')) {
                if ($mutation === 'audit_delete') {
                    DB::table('audit_logs')->where('id', $audit->id)->delete();
                } else {
                    DB::table('audit_logs')->where('id', $audit->id)->update(['user_id' => $otherActorId]);
                }
            } else {
                $context = json_decode(DB::table('control_room_alerts')->where('id', $id)->value('context'), true, 512, JSON_THROW_ON_ERROR);
                $changes = match ($mutation) {
                    'root_text' => ['notes' => 'Late changed root'],
                    'status' => ['status' => ControlRoomAlert::STATUS_OPEN],
                    'resolved_at' => ['resolved_at' => '2020-01-01 00:00:00'],
                    'resolved_actor' => ['resolved_by_user_id' => $otherActorId],
                    'resolution_code' => ['resolution_code' => 'late_changed'],
                    'snoozed_until' => ['snoozed_until' => now()->addDay()->format('Y-m-d H:i:s')],
                    'snoozed_actor' => ['snoozed_by_user_id' => $otherActorId],
                    default => [],
                };
                if ($mutation === 'root_origin') {
                    $context['root_note_origin'] = ['version' => 1, 'source' => 'operator_note', 'operator_note_id' => 999999];
                } elseif (str_starts_with($mutation, 'activity_')) {
                    if ($mutation === 'activity_drop') {
                        array_pop($context['activity_log']);
                    } else {
                        $entry = match ($mutation) {
                            'activity_link' => ['operator_note_id' => 999999],
                            'activity_content' => ['content' => 'Late changed activity'],
                            'activity_actor' => ['user_id' => $otherActorId],
                            'activity_actor_name' => ['user_name' => 'Late changed actor name'],
                            'activity_transition' => ['transition' => 'late_changed'],
                            'activity_purpose' => ['purpose' => OperatorNote::PURPOSE_IMMEDIATE_CONTROLS],
                            'activity_time' => ['created_at' => '2020-01-01T00:00:00+00:00'],
                        };
                        $last = array_key_last($context['activity_log']);
                        $context['activity_log'][$last] = array_replace($context['activity_log'][$last], $entry);
                    }
                } elseif ($mutation === 'prior_history') {
                    $context['activity_log'][0]['content'] = 'Late changed previous history';
                }
                if (in_array($mutation, ['root_origin', 'prior_history'], true) || str_starts_with($mutation, 'activity_')) {
                    $changes['context'] = json_encode($context);
                }
                $this->assertSame(1, DB::table('control_room_alerts')->where('id', $id)->update($changes));
            }

            return true;
        });

        return $reached;
    }

    private function resolve(): ControlRoomAlert
    {
        return app(ControlRoomAlertLifecycleService::class)->resolve($this->alert, $this->actor, 'Independent operator response', 'controlled');
    }

    private function workspace(): array
    {
        return app(AlertWorkspaceService::class)->build($this->actor, $this->alert->id);
    }

    private function search(string $text): array
    {
        return app(ControlRoomGovernanceReadService::class)->withCurrentViewer($this->actor,
            function ($current, $context) use ($text): array {
                $candidates = ControlRoomAlert::query()->whereKey($this->alert->id);

                return $context->query(app(ControlRoomSourceContentService::class)->applyReadableNotes(
                    clone $candidates, $current, $context, $candidates))->where('notes', 'like', '%'.$text.'%')->pluck('id')->all();
            });
    }

    private function assertWithheld(string $text): void
    {
        $this->assertNull($this->workspace()['alert']['notes']);
        $this->assertSame([], $this->search($text));
    }

    private function assertRollback(callable $write): void
    {
        $before = $this->alert->fresh()->getRawOriginal();
        $beforeNotes = DB::table('control_room_operator_notes')->where('alert_id', $this->alert->id)->orderBy('id')->get()->all();
        $beforeAudits = DB::table('audit_logs')->where('auditable_type', $this->alert->getMorphClass())->where('auditable_id', $this->alert->id)->orderBy('id')->get()->all();
        $beforeSla = DB::table('control_room_alert_sla')->where('alert_id', $this->alert->id)->get()->all();
        try {
            $write();
            $this->fail('The rejected command must fail visibly.');
        } catch (RuntimeException) {
            $this->assertSame($before, $this->alert->fresh()->getRawOriginal());
            $this->assertEquals($beforeNotes, DB::table('control_room_operator_notes')->where('alert_id', $this->alert->id)->orderBy('id')->get()->all());
            $this->assertEquals($beforeAudits, DB::table('audit_logs')->where('auditable_type', $this->alert->getMorphClass())->where('auditable_id', $this->alert->id)->orderBy('id')->get()->all());
            $this->assertEquals($beforeSla, DB::table('control_room_alert_sla')->where('alert_id', $this->alert->id)->get()->all());
        }
    }
}
