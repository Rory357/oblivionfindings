<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Domain\SecurityDevices\Enums\LinkType;
use App\Domain\SecurityDevices\Models\Device;
use App\Domain\SecurityDevices\Models\DeviceAssetLink;
use App\Domain\SecurityDevices\Models\DeviceAssignment;
use App\Jobs\DispatchFleetSignalOutbox;
use App\Models\Asset;
use App\Models\AuditLog;
use App\Models\Client;
use App\Models\ConsentType;
use App\Models\FleetSignal;
use App\Models\FleetSignalOutbox;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use App\Services\AuthorizationEvidenceLockService;
use Database\Seeders\RbacSeeder;
use Database\Seeders\SecurityDevicesPermissionsSeeder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Bus;
use Illuminate\Support\Str;
use Tests\Support\AuthoritativeConsentFixture;
use Tests\TestCase;

class SignalOutboxControllerTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private User $supportWorker;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RbacSeeder::class);
        $this->seed(SecurityDevicesPermissionsSeeder::class);

        $this->admin = User::factory()->create(['role' => 'admin', 'approved_at' => now()]);
        $this->admin->roles()->attach(Role::where('name', 'admin')->first());

        $this->supportWorker = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        $this->supportWorker->roles()->attach(Role::where('name', 'support_worker')->first());
    }

    public function test_settings_index_exposes_failed_signal_outbox_rows(): void
    {
        $outbox = $this->createOutbox(['status' => 'unroutable']);

        $this->actingAs($this->admin)
            ->get('/control-room/settings?tab=signal-outbox')
            ->assertOk()
            ->assertInertia(fn ($page) => $page
                ->component('control-room/settings')
                ->has('signalOutbox', 1)
                ->where('signalOutbox.0.id', $outbox->id)
                ->where('signalOutbox.0.status', 'unroutable')
                ->where('signalOutbox.0.can_retry', true)
                ->where('signalOutbox.0.signal.id', $outbox->fleet_signal_id)
            );
    }

    public function test_settings_exposes_status_explanations_without_internal_transport_errors_or_signal_payload(): void
    {
        $privateError = 'Private client note; password=outbox-secret; SQL SELECT protected_source';
        foreach ([
            'failed' => 'Delivery failed. Review the source record before retrying.',
            'dead_letter' => 'Repeated delivery attempts failed. Review the source record before retrying.',
            'unroutable' => 'This signal could not be routed to a response. Review its source record.',
        ] as $status => $message) {
            $outbox = $this->createOutbox(['status' => $status, 'last_error' => $privateError]);
            $this->actingAs($this->admin)->get('/control-room/settings?tab=signal-outbox')
                ->assertOk()->assertDontSee($privateError)
                ->assertInertia(fn ($page) => $page->component('control-room/settings')
                    ->where('signalOutbox.0.id', $outbox->id)->where('signalOutbox.0.last_error', $message)
                    ->missing('signalOutbox.0.signal.payload'));
            $this->assertSame($privateError, $outbox->fresh()->last_error);
            $outbox->delete();
        }
    }

    public function test_retry_requires_manage_permission(): void
    {
        $outbox = $this->createOutbox();

        $this->actingAs($this->supportWorker)
            ->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")
            ->assertForbidden();
    }

    public function test_retry_resets_outbox_dispatches_job_and_audits(): void
    {
        Bus::fake();
        $outbox = $this->createOutbox([
            'status' => 'failed',
            'last_error' => 'Timeout',
            'last_attempt_at' => now()->subMinutes(10),
        ]);

        $this->actingAs($this->admin)
            ->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")
            ->assertRedirect('/control-room/settings?tab=signal-outbox');

        $outbox->refresh();

        $this->assertSame('pending', $outbox->status);
        $this->assertNull($outbox->last_error);

        Bus::assertDispatched(DispatchFleetSignalOutbox::class, fn ($job) => $job->outboxId === $outbox->id);

        $this->assertDatabaseHas('audit_logs', [
            'action' => 'controlRoom.signalOutbox.retry',
            'auditable_type' => $outbox->getMorphClass(),
            'auditable_id' => $outbox->id,
            'user_id' => $this->admin->id,
        ]);
    }

    public function test_retry_is_throttled_for_recent_attempt(): void
    {
        Bus::fake();
        $outbox = $this->createOutbox([
            'status' => 'failed',
            'last_attempt_at' => now()->subMinute(),
        ]);

        $this->actingAs($this->admin)
            ->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")
            ->assertStatus(429);

        $this->assertSame('failed', $outbox->fresh()->status);
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
    }

    public function test_current_source_access_scopes_list_and_denies_other_site_direct_retry(): void
    {
        Bus::fake();
        $site = Site::factory()->create();
        $operator = $this->siteOperator($site, ['controlRoom.alerts.manage', 'fleet.viewAny', 'fleet.vehicles.viewAllSites']);
        $permitted = $this->createOutbox([], $site);
        $other = $this->createOutbox([], Site::factory()->create());
        $this->actingAs($operator)->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 1)->where('signalOutbox.0.id', $permitted->id));
        $this->post("/control-room/settings/signal-outbox/{$other->id}/retry")->assertNotFound();
        $this->assertSame('failed', $other->fresh()->status);
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
        $this->post("/control-room/settings/signal-outbox/{$permitted->id}/retry")->assertRedirect();
        Bus::assertDispatched(DispatchFleetSignalOutbox::class, fn ($job) => $job->outboxId === $permitted->id);
    }

    public function test_management_alone_cannot_read_or_retry_fleet_source_records(): void
    {
        Bus::fake();
        $site = Site::factory()->create();
        $operator = $this->siteOperator($site, ['controlRoom.alerts.manage']);
        $outbox = $this->createOutbox([], $site);
        $this->actingAs($operator)->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 0));
        $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
        $this->assertSame('failed', $outbox->fresh()->status);
    }

    public function test_personal_signal_without_current_location_consent_and_mismatched_asset_link_are_not_disclosed(): void
    {
        Bus::fake();
        $outbox = $this->createOutbox();
        $asset = $outbox->signal->asset;
        $client = Client::factory()->create(['site_id' => $asset->site_id]);
        $asset->update(['client_id' => $client->id]);
        $this->actingAs($this->admin)->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 0));
        $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
        $asset->update(['client_id' => null]);
        DeviceAssetLink::query()->where('device_id', $outbox->signal->device_id)->update(['unlinked_at' => now()]);
        $this->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 0));
        $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
        $this->assertSame('failed', $outbox->fresh()->status);
    }

    public function test_retry_replay_of_pending_work_does_not_dispatch_or_audit_twice(): void
    {
        Bus::fake();
        $outbox = $this->createOutbox();
        $url = "/control-room/settings/signal-outbox/{$outbox->id}/retry";
        $this->actingAs($this->admin)->post($url)->assertRedirect();
        $this->post($url)->assertRedirect()->assertSessionHas('success', 'This signal delivery is already queued or being processed.');
        Bus::assertDispatchedTimes(DispatchFleetSignalOutbox::class, 1);
        $this->assertSame(1, AuditLog::query()->where('action', 'controlRoom.signalOutbox.retry')->where('auditable_id', $outbox->id)->count());
    }

    public function test_refused_retry_save_or_audit_preserves_the_original_failed_row_and_dispatches_nothing(): void
    {
        Bus::fake();
        $outbox = $this->createOutbox(['last_error' => 'Original diagnostic']);
        $original = $outbox->fresh()->getRawOriginal();
        $this->actingAs($this->admin);
        foreach (['save', 'audit_exception', 'audit_veto'] as $failure) {
            $dispatcher = Model::getEventDispatcher();
            Model::setEventDispatcher(clone $dispatcher);
            if ($failure === 'save') {
                FleetSignalOutbox::saving(fn (FleetSignalOutbox $current) => (int) $current->id === (int) $outbox->id && $current->status === 'pending' ? false : null);
            } else {
                AuditLog::creating(function (AuditLog $audit) use ($failure): ?bool {
                    if ($audit->action === 'controlRoom.signalOutbox.retry') {
                        if ($failure === 'audit_veto') {
                            return false;
                        }
                        throw new \RuntimeException('Injected retry audit failure.');
                    }

                    return null;
                });
            }
            $this->withoutExceptionHandling();
            $caught = null;
            try {
                $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry");
            } catch (\RuntimeException $exception) {
                $caught = $exception;
            } finally {
                Model::setEventDispatcher($dispatcher);
                $this->withExceptionHandling();
            }
            $this->assertNotNull($caught);
            $this->assertSame($original, $outbox->fresh()->getRawOriginal());
            $this->assertDatabaseMissing('audit_logs', ['action' => 'controlRoom.signalOutbox.retry', 'auditable_id' => $outbox->id]);
            Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
        }
    }

    public function test_source_change_at_final_actor_read_denies_retry_even_with_an_eager_loaded_source(): void
    {
        Bus::fake();
        $site = Site::factory()->create();
        $operator = $this->siteOperator($site);
        $outbox = $this->createOutbox([], $site);
        $outbox->load('signal.asset', 'signal.device');
        $newSite = Site::factory()->create();
        $authorization = new class($outbox, $newSite) extends AuthorizationEvidenceLockService
        {
            public function __construct(private FleetSignalOutbox $outbox, private Site $newSite) {}

            public function lockForUserWithoutWaiting(User|int $user, array $permissionKeys): User
            {
                Asset::query()->whereKey($this->outbox->signal->asset_id)->update(['site_id' => $this->newSite->id]);

                return parent::lockForUserWithoutWaiting($user, $permissionKeys);
            }
        };
        app()->instance(AuthorizationEvidenceLockService::class, $authorization);
        $this->actingAs($operator)->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
        $this->assertSame('failed', $outbox->fresh()->status);
    }

    public function test_an_enqueue_failure_keeps_the_original_failure_and_diagnostics_visible_for_an_explicit_retry(): void
    {
        $outbox = $this->createOutbox(['status' => 'unroutable', 'last_error' => 'Original source diagnostic']);
        $attempts = $outbox->attempts;
        $attemptedAt = $outbox->last_attempt_at->toISOString();
        Bus::shouldReceive('dispatch')->once()->andThrow(new \RuntimeException('Private broker error'));
        $this->withoutExceptionHandling();
        $caught = null;
        try {
            $this->actingAs($this->admin)->post("/control-room/settings/signal-outbox/{$outbox->id}/retry");
        } catch (\RuntimeException $exception) {
            $caught = $exception;
        } finally {
            $this->withExceptionHandling();
        }
        $this->assertSame('The signal retry could not be queued. Review the saved delivery before retrying.', $caught?->getMessage());
        $this->assertSame('unroutable', $outbox->fresh()->status);
        $this->assertSame('Original source diagnostic', $outbox->fresh()->last_error);
        $this->assertSame($attempts, $outbox->fresh()->attempts);
        $this->assertSame($attemptedAt, $outbox->fresh()->last_attempt_at->toISOString());
        $this->get('/control-room/settings?tab=signal-outbox')->assertOk()->assertDontSee('Private broker error')
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 1)->where('signalOutbox.0.id', $outbox->id)
                ->where('signalOutbox.0.can_retry', true));
    }

    public function test_current_device_visibility_does_not_open_signal_history_recorded_under_other_site_custody(): void
    {
        Bus::fake();
        $site = Site::factory()->create();
        $operator = $this->siteOperator($site);
        $outbox = $this->createOutbox([], $site);
        $signal = $outbox->signal;
        DeviceAssignment::query()->where('device_id', $signal->device_id)->update([
            'assigned_at' => now()->subDays(3), 'released_at' => now()->subHours(2),
            'custody_site_id' => Site::factory()->create()->id,
        ]);
        DeviceAssignment::query()->create(['device_id' => $signal->device_id, 'assignable_type' => DeviceAssignment::TARGET_VEHICLE,
            'assignable_id' => $signal->asset_id, 'custody_site_id' => $site->id,
            'assignment_type' => 'permanent', 'assigned_at' => now()->subHours(2)]);
        $signal->update(['occurred_at' => now()->subDay()]);
        $this->actingAs($operator)->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 0));
        $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
    }

    public function test_permitted_personal_source_is_rechecked_after_current_location_consent_withdrawal(): void
    {
        Bus::fake();
        $outbox = $this->createOutbox();
        $signal = $outbox->signal;
        $asset = $signal->asset;
        $client = Client::factory()->create(['site_id' => $asset->site_id, 'status' => 'active']);
        $asset->update(['client_id' => $client->id]);
        $type = ConsentType::query()->firstOrCreate(['name' => 'Personal Tracker (Wandering Risk)'], [
            'category' => 'operational', 'description' => 'Resident tracker safety',
            'purpose' => 'Client personal safety tracking', 'legal_basis' => 'consent', 'allows_withdrawal' => true, 'active' => true,
        ]);
        $consent = AuthoritativeConsentFixture::manualSelf($client, $type, $this->admin);
        DeviceAssignment::query()->where('device_id', $signal->device_id)->update(['released_at' => now()]);
        DeviceAssignment::query()->create(['device_id' => $signal->device_id, 'assignable_type' => DeviceAssignment::TARGET_CLIENT,
            'assignable_id' => $client->id, 'custody_site_id' => $client->site_id, 'assignment_type' => 'permanent',
            'assigned_at' => now(), 'consent_id' => $consent->id]);
        $signal->update(['occurred_at' => now()]);
        $this->admin->load('roles.permissions', 'permissionOverrides');
        $this->actingAs($this->admin)->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 1)->where('signalOutbox.0.id', $outbox->id));
        $consent->update(['status' => 'withdrawn', 'withdrawn_at' => now()]);
        $this->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 0));
        $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
        $this->assertSame('failed', $outbox->fresh()->status);
        Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
    }

    public function test_loaded_viewer_cannot_retain_source_access_after_permission_staff_or_site_correction(): void
    {
        Bus::fake();
        foreach (['permission', 'staff', 'site'] as $correction) {
            $site = Site::factory()->create();
            $operator = $this->siteOperator($site);
            $outbox = $this->createOutbox([], $site);
            $operator->load('roles.permissions', 'permissionOverrides', 'hrEmployeeProfile');
            $this->actingAs($operator)->get('/control-room/settings?tab=signal-outbox')->assertOk()
                ->assertInertia(fn ($page) => $page->has('signalOutbox', 1)->where('signalOutbox.0.id', $outbox->id));
            if ($correction === 'permission') {
                $operator->permissionOverrides()->updateExistingPivot(Permission::query()->where('key', 'fleet.viewAny')->sole()->id, ['allowed' => false]);
            } elseif ($correction === 'staff') {
                HrEmployeeProfile::query()->where('user_id', $operator->id)->update(['is_active' => false]);
            } else {
                HrEmployeeProfile::query()->where('user_id', $operator->id)->update(['primary_site_id' => Site::factory()->create()->id]);
            }
            $this->get('/control-room/settings?tab=signal-outbox')->assertOk()
                ->assertInertia(fn ($page) => $page->has('signalOutbox', 0));
            $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertNotFound();
            $this->assertSame('failed', $outbox->fresh()->status);
            Bus::assertNotDispatched(DispatchFleetSignalOutbox::class);
        }
    }

    public function test_a_canonical_home_site_only_vehicle_can_be_reviewed_and_retried_without_a_fabricated_direct_site(): void
    {
        Bus::fake();
        $site = Site::factory()->create();
        $operator = $this->siteOperator($site);
        $outbox = $this->createOutbox([], $site);
        $outbox->signal->asset->update(['site_id' => null, 'home_site_id' => $site->id]);
        $this->actingAs($operator)->get('/control-room/settings?tab=signal-outbox')->assertOk()
            ->assertInertia(fn ($page) => $page->has('signalOutbox', 1)->where('signalOutbox.0.id', $outbox->id));
        $this->post("/control-room/settings/signal-outbox/{$outbox->id}/retry")->assertRedirect();
        Bus::assertDispatched(DispatchFleetSignalOutbox::class, fn ($job) => $job->outboxId === $outbox->id);
    }

    private function siteOperator(Site $site, array $permissions = ['controlRoom.alerts.manage', 'fleet.viewAny']): User
    {
        $user = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        $user->roles()->sync([Role::query()->where('name', 'support_worker')->sole()->id]);
        $grants = Permission::query()->pluck('id')->mapWithKeys(fn ($id) => [$id => ['allowed' => false]]);
        foreach (Permission::query()->whereIn('key', $permissions)->pluck('id') as $id) {
            $grants[$id] = ['allowed' => true];
        }
        $user->permissionOverrides()->sync($grants->all());
        HrEmployeeProfile::factory()->create(['user_id' => $user->id, 'position_role' => 'support_worker',
            'primary_site_id' => $site->id, 'secondary_site_ids' => [], 'is_active' => true,
            'start_date' => today()->subYear()]);

        return $user;
    }

    private function createOutbox(array $overrides = [], ?Site $site = null): FleetSignalOutbox
    {
        $site ??= Site::factory()->create();
        $asset = Asset::factory()->vehicle()->create(['site_id' => $site->id]);
        $device = Device::factory()->tracking()->create();
        DeviceAssignment::query()->create(['device_id' => $device->id, 'assignable_type' => DeviceAssignment::TARGET_VEHICLE,
            'assignable_id' => $asset->id, 'custody_site_id' => $site->id, 'assignment_type' => 'permanent', 'assigned_at' => now()->subDay()]);
        DeviceAssetLink::query()->create(['device_id' => $device->id, 'asset_id' => $asset->id,
            'link_type' => LinkType::InstalledIn, 'linked_at' => now()->subDay()]);
        $signal = FleetSignal::create([
            'asset_id' => $asset->id,
            'device_id' => $device->id,
            'signal_type' => 'vehicle.speeding',
            'severity_hint' => 'high',
            'occurred_at' => now(),
            'idempotency_key' => 'test-signal-'.Str::uuid(),
            'payload' => ['speed' => 88],
        ]);

        return FleetSignalOutbox::create(array_merge([
            'fleet_signal_id' => $signal->id,
            'status' => 'failed',
            'attempts' => 2,
            'last_attempt_at' => now()->subMinutes(6),
            'last_error' => 'Processor unavailable',
        ], $overrides));
    }
}
