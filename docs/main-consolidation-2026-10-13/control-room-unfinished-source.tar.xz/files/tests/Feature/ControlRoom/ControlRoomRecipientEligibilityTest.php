<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Jobs\Notifications\DeliverControlRoomAlertNotificationJob;
use App\Jobs\Notifications\RecoverControlRoomAlertNotificationsJob;
use App\Models\ControlRoom\Communication;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoom\TriageQueue;
use App\Models\ControlRoomAlert;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use App\Notifications\ControlRoomAlertNotification;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\ControlRoom\AlertAutomationService;
use App\Services\ControlRoom\ControlRoomNotificationService;
use App\Services\ControlRoom\ControlRoomRecipientEligibilityService;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Notification;
use Illuminate\Support\Facades\Queue;
use Tests\TestCase;

class ControlRoomRecipientEligibilityTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RbacSeeder::class);
    }

    public function test_named_configuration_does_not_override_current_staff_site_or_permission_denial(): void
    {
        $site = Site::factory()->create();
        $allowed = $this->operator($site);
        $wrongSite = $this->operator(Site::factory()->create());
        $inactive = $this->operator($site);
        $inactive->hrEmployeeProfile->update(['is_active' => false]);
        $revoked = $this->operator($site);
        $this->denyRead($revoked);
        $queue = $this->queue([$wrongSite->id, $inactive->id, $revoked->id, $allowed->id]);
        $alert = $this->alert($site, $queue);

        $rows = app(ControlRoomNotificationService::class)->stageAlertNotifications($alert, null, $queue);

        $this->assertSame([$allowed->id], $rows->pluck('target_user_id')->all());
        $this->assertDatabaseCount('control_room_communications', 1);
    }

    public function test_delivery_revalidates_permission_revoked_after_staging_and_keeps_the_authorised_fallback(): void
    {
        Notification::fake();
        $site = Site::factory()->create();
        $first = $this->operator($site);
        $fallback = $this->operator($site);
        $queue = $this->queue([$first->id, $fallback->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $rows = $service->stageAlertNotifications($alert, null, $queue);
        $this->denyRead($first);

        $replacementIds = DB::transaction(fn () => $service->deliverStagedNotification($rows->firstWhere('target_user_id', $first->id)));
        $this->assertNotNull($rows->firstWhere('target_user_id', $first->id)->fresh()->superseded_at);
        foreach ($replacementIds as $id) {
            $row = Communication::query()->findOrFail($id);
            DB::transaction(fn () => $service->deliverStagedNotification($row));
        }

        Notification::assertNotSentTo($first, ControlRoomAlertNotification::class);
        Notification::assertSentTo($fallback, ControlRoomAlertNotification::class);
        $this->assertSame(1, $alert->communications()->where('status', 'sent')->count());
    }

    public function test_inactive_recipient_after_staging_is_superseded_without_a_sent_receipt(): void
    {
        Notification::fake();
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $recipient->hrEmployeeProfile->update(['is_active' => false]);

        DB::transaction(fn () => $service->deliverStagedNotification($row));

        Notification::assertNothingSent();
        $this->assertNotNull($row->fresh()->superseded_at);
        $this->assertSame(0, $alert->communications()->where('status', 'sent')->count());
    }

    public function test_a_planned_future_duty_does_not_start_actual_ownership(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        Shift::query()->create(['name' => 'Future plan', 'starts_at' => now()->addDay(),
            'status' => 'active', 'shift_lead_user_id' => $recipient->id, 'team_members' => []]);

        app(AlertAutomationService::class)->autoAssign($alert);

        $this->assertNull($alert->fresh()->assigned_to_user_id);
        $this->assertNull($alert->fresh()->acknowledged_at);
        $this->assertSame('no_eligible_on_duty_owner', data_get($alert->fresh()->context, 'assignment_routing.state'));
    }

    public function test_automatic_ownership_falls_through_wrong_site_inactive_and_off_duty_candidates_to_actual_duty(): void
    {
        $site = Site::factory()->create();
        $wrongSite = $this->operator(Site::factory()->create());
        $inactive = $this->operator($site);
        $inactive->hrEmployeeProfile->update(['is_active' => false]);
        $offDuty = $this->operator($site);
        $eligible = $this->operator($site);
        $queue = $this->queue([$wrongSite->id, $inactive->id, $offDuty->id]);
        $alert = $this->alert($site, $queue);
        Shift::query()->create(['name' => 'Actual duty', 'starts_at' => now()->subMinute(), 'status' => 'active',
            'shift_lead_user_id' => $eligible->id, 'team_members' => [$wrongSite->id, $inactive->id]]);

        app(AlertAutomationService::class)->autoAssign($alert);

        $this->assertSame($eligible->id, $alert->fresh()->assigned_to_user_id);
        $this->assertSame('current_duty_fallback', data_get($alert->fresh()->context, 'auto_assign_reason'));
        $this->assertSame(ControlRoomAlert::STATUS_OPEN, $alert->fresh()->status);
        $this->assertNull($alert->fresh()->acknowledged_at);
    }

    public function test_notification_uses_current_duty_fallback_when_named_candidates_are_denied(): void
    {
        $site = Site::factory()->create();
        $wrongSite = $this->operator(Site::factory()->create());
        $eligible = $this->operator($site);
        $queue = $this->queue([$wrongSite->id]);
        $alert = $this->alert($site, $queue);
        Shift::query()->create(['name' => 'Actual duty', 'starts_at' => now()->subMinute(), 'status' => 'active',
            'shift_lead_user_id' => $eligible->id, 'team_members' => []]);

        $rows = app(ControlRoomNotificationService::class)->stageAlertNotifications($alert, null, $queue);

        $this->assertSame([$eligible->id], $rows->pluck('target_user_id')->all());
        $this->assertSame('pending', $rows->sole()->status);
        $this->assertNull($rows->sole()->sent_at);
    }

    public function test_staging_uses_current_response_facts_instead_of_a_callers_old_alert_model(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $preloaded = $this->alert($site, $queue);
        $preloaded->fresh()->update(['status' => 'ack', 'escalation_level' => 2]);

        $row = app(ControlRoomNotificationService::class)->stageAlertNotifications($preloaded, null, $queue)->sole();

        $this->assertSame('open', $preloaded->status);
        $this->assertSame('ack', $row->notification_payload['status']);
        $this->assertSame(2, (int) $row->notification_payload['escalation_level']);
        $this->assertNull($row->sent_at);
    }

    public function test_delivery_replaces_stale_status_and_escalation_with_current_response_facts(): void
    {
        Notification::fake();
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $oldRow = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $alert->update(['status' => 'ack', 'escalation_level' => 2]);

        $ids = DB::transaction(fn () => $service->deliverStagedNotification($oldRow));
        Notification::assertNothingSent();
        $this->assertNotNull($oldRow->fresh()->superseded_at);
        $this->assertCount(1, $ids);
        $replacement = Communication::query()->findOrFail($ids[0]);
        DB::transaction(fn () => $service->deliverStagedNotification($replacement));

        Notification::assertSentTo($recipient, ControlRoomAlertNotification::class, function ($notification) use ($recipient): bool {
            $data = $notification->toArray($recipient);

            return $data['status'] === 'ack' && (int) $data['escalation_level'] === 2;
        });
        $this->assertSame('sent', $replacement->fresh()->status);
        $this->assertNull($replacement->fresh()->delivered_at);
        $this->assertNull($alert->fresh()->acknowledged_at);
    }

    public function test_response_completion_supersedes_pending_initial_notices_without_new_delivery_or_history_changes(): void
    {
        Notification::fake();
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $preloaded = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $oldRow = $service->stageAlertNotifications($preloaded, null, $queue)->sole();
        $resolvedAt = now()->startOfSecond();
        $preloaded->fresh()->update(['status' => 'resolved', 'resolved_at' => $resolvedAt]);

        $this->assertSame([], DB::transaction(fn () => $service->deliverStagedNotification($oldRow)));
        $this->assertCount(0, $service->stageAlertNotifications($preloaded, null, $queue));
        Notification::assertNothingSent();
        $this->assertNotNull($oldRow->fresh()->superseded_at);
        $this->assertNull($oldRow->fresh()->sent_at);
        $this->assertDatabaseCount('control_room_communications', 1);
        $this->assertSame('resolved', $preloaded->fresh()->status);
        $this->assertTrue($preloaded->fresh()->resolved_at->equalTo($resolvedAt));
    }

    public function test_a_source_change_at_final_eligibility_retains_durable_recovery_work_for_current_facts(): void
    {
        Notification::fake();
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $changed = false;
        $service = $this->notificationsWithFinalReadChange(function () use ($alert, &$changed): void {
            $alert->fresh()->update(['status' => 'ack', 'severity' => 'critical', 'escalation_level' => 2]);
            $changed = true;
        });
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();

        $this->assertSame([], DB::transaction(fn () => $service->deliverStagedNotification($row)));
        $this->assertTrue($changed, 'The state change must occur before the final real eligibility read.');
        Notification::assertNothingSent();
        $this->assertSame('failed', $row->fresh()->status);
        $this->assertSame(1, (int) $row->fresh()->retry_count);
        $this->assertNull($row->fresh()->superseded_at);
        $this->assertNull($row->fresh()->sent_at);
        $this->assertSame('routing_retry_pending', data_get($alert->fresh()->context, 'notification_routing.state'));
        $this->travel(61)->seconds();
        (new RecoverControlRoomAlertNotificationsJob)->handle();
        Queue::assertPushed(DeliverControlRoomAlertNotificationJob::class, fn ($job) => $job->communicationId === $row->id);

        $ids = DB::transaction(fn () => $service->deliverStagedNotification($row->fresh()));
        $this->assertCount(1, $ids);
        $this->assertNotNull($row->fresh()->superseded_at);
        DB::transaction(fn () => $service->deliverStagedNotification(Communication::query()->findOrFail($ids[0])));
        Notification::assertSentTo($recipient, ControlRoomAlertNotification::class, function ($notification) use ($recipient): bool {
            $data = $notification->toArray($recipient);

            return $data['status'] === 'ack' && $data['severity'] === 'critical' && (int) $data['escalation_level'] === 2;
        });
        $this->assertNull($alert->fresh()->acknowledged_at);
    }

    public function test_a_site_change_at_final_eligibility_routes_recovery_to_the_current_approved_recipient(): void
    {
        Notification::fake();
        $site = Site::factory()->create();
        $newSite = Site::factory()->create();
        $first = $this->operator($site);
        $replacement = $this->operator($newSite);
        $queue = $this->queue([$first->id, $replacement->id]);
        $alert = $this->alert($site, $queue);
        $changed = false;
        $service = $this->notificationsWithFinalReadChange(function () use ($alert, $newSite, &$changed): void {
            $alert->fresh()->update(['site_id' => $newSite->id]);
            $changed = true;
        });
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();

        DB::transaction(fn () => $service->deliverStagedNotification($row));
        $this->assertTrue($changed);
        Notification::assertNothingSent();
        $this->assertNull($row->fresh()->superseded_at);
        $this->assertSame('failed', $row->fresh()->status);
        $ids = DB::transaction(fn () => $service->deliverStagedNotification($row->fresh()));
        $this->assertCount(1, $ids);
        $current = Communication::query()->findOrFail($ids[0]);
        $this->assertSame($replacement->id, $current->target_user_id);
        DB::transaction(fn () => $service->deliverStagedNotification($current));
        Notification::assertNotSentTo($first, ControlRoomAlertNotification::class);
        Notification::assertSentTo($replacement, ControlRoomAlertNotification::class);
        $this->assertSame(1, $alert->communications()->where('status', 'sent')->count());
    }

    public function test_revocation_at_final_eligibility_leaves_retry_work_then_an_explicit_no_recipient_state(): void
    {
        Notification::fake();
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $revoked = false;
        $service = $this->notificationsWithFinalReadChange(function () use ($recipient, &$revoked): void {
            $this->denyRead($recipient);
            $revoked = true;
        });
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();

        DB::transaction(fn () => $service->deliverStagedNotification($row));
        $this->assertTrue($revoked);
        $this->assertNull($row->fresh()->superseded_at);
        $this->assertSame('routing_retry_pending', data_get($alert->fresh()->context, 'notification_routing.state'));
        $this->assertSame([], DB::transaction(fn () => $service->deliverStagedNotification($row->fresh())));
        Notification::assertNothingSent();
        $this->assertNotNull($row->fresh()->superseded_at);
        $this->assertSame('no_eligible_recipients', data_get($alert->fresh()->context, 'notification_routing.state'));
        $this->assertSame(0, data_get($alert->fresh()->context, 'notification_routing.eligible_recipients'));
        $this->assertDatabaseCount('control_room_communications', 1);
        $this->assertNull($alert->fresh()->acknowledged_at);
    }

    public function test_completion_at_final_eligibility_stays_superseded_without_retry_work(): void
    {
        Notification::fake();
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $completed = false;
        $service = $this->notificationsWithFinalReadChange(function () use ($alert, &$completed): void {
            $alert->fresh()->update(['status' => 'resolved', 'resolved_at' => now()->startOfSecond()]);
            $completed = true;
        });
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();

        DB::transaction(fn () => $service->deliverStagedNotification($row));
        $this->assertTrue($completed);
        Notification::assertNothingSent();
        $this->assertNotNull($row->fresh()->superseded_at);
        $this->assertNull($row->fresh()->sent_at);
        $this->assertSame(0, (int) $row->fresh()->retry_count);
        $this->travel(61)->seconds();
        (new RecoverControlRoomAlertNotificationsJob)->handle();
        Queue::assertNothingPushed();
        $this->assertSame('resolved', $alert->fresh()->status);
    }

    public function test_repeated_final_revocation_is_bounded_and_leaves_an_explicit_delivery_failure(): void
    {
        Notification::fake();
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $row = app(ControlRoomNotificationService::class)->stageAlertNotifications($alert, null, $queue)->sole();
        for ($attempt = 1; $attempt <= 3; $attempt++) {
            $this->setReadPermission($recipient, true);
            $revoked = false;
            $service = $this->notificationsWithFinalReadChange(function () use ($recipient, &$revoked): void {
                $this->denyRead($recipient);
                $revoked = true;
            });
            DB::transaction(fn () => $service->deliverStagedNotification($row->fresh()));
            $this->assertTrue($revoked);
            $this->assertSame($attempt, (int) $row->fresh()->retry_count);
        }
        $this->assertSame('failed', $row->fresh()->status);
        $this->assertNull($row->fresh()->superseded_at);
        $this->assertNull($row->fresh()->sent_at);
        $this->assertSame('routing_requires_review', data_get($alert->fresh()->context, 'notification_routing.state'));
        $this->assertStringContainsString('review current recipients', $row->fresh()->status_detail);
        $this->travel(301)->seconds();
        (new RecoverControlRoomAlertNotificationsJob)->handle();
        Queue::assertNothingPushed();
        $this->assertSame([], DB::transaction(fn () => $service->deliverStagedNotification($row->fresh())));
        Notification::assertNothingSent();
        $this->assertDatabaseCount('control_room_communications', 1);
    }

    public function test_a_vetoed_changed_routing_save_retains_original_row_and_alert_context_without_dispatch(): void
    {
        Notification::fake();
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = $this->notificationsWithFinalReadChange(fn () => $this->denyRead($recipient));
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $originalRow = $row->fresh()->getRawOriginal();
        $originalContext = $alert->fresh()->context;
        $originalDispatcher = Communication::getEventDispatcher();
        Communication::setEventDispatcher(clone $originalDispatcher);
        $vetoed = false;
        Communication::saving(function (Communication $saving) use ($row, &$vetoed): ?bool {
            if ((int) $saving->id === (int) $row->id && $saving->status === 'failed') {
                $vetoed = true;

                return false;
            }

            return null;
        });

        try {
            try {
                DB::transaction(fn () => $service->deliverStagedNotification($row));
                $this->fail('A refused durable recovery write must abort the transaction.');
            } catch (\RuntimeException $exception) {
                $this->assertSame('Changed notification routing intent was not persisted.', $exception->getMessage());
            }
        } finally {
            Communication::setEventDispatcher($originalDispatcher);
        }

        $this->assertTrue($vetoed, 'The real Eloquent saving event must refuse the recovery write.');
        $this->assertSame($originalRow, $row->fresh()->getRawOriginal());
        $this->assertSame($originalContext, $alert->fresh()->context);
        $this->assertNull($alert->fresh()->acknowledged_at);
        $this->assertNull($alert->fresh()->acknowledged_by_user_id);
        $this->assertDatabaseCount('control_room_communications', 1);
        Notification::assertNothingSent();
        Queue::assertNothingPushed();
    }

    public function test_refused_sent_state_rolls_back_the_real_database_notification_and_valid_retry_delivers_once(): void
    {
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $original = $row->fresh()->getRawOriginal();
        $originalContext = $alert->fresh()->context;

        $this->withRefusedWrite(Communication::class, 'saving',
            fn (Communication $saving): bool => (int) $saving->id === (int) $row->id && $saving->status === 'sent',
            fn () => DB::transaction(fn () => $service->deliverStagedNotification($row)),
            'Notification sent state was not persisted.');

        $this->assertSame($original, $row->fresh()->getRawOriginal());
        $this->assertSame($originalContext, $alert->fresh()->context);
        $this->assertDatabaseCount('notifications', 0);
        Queue::assertNothingPushed();

        (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
        (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
        $this->assertSame('sent', $row->fresh()->status);
        $this->assertNotNull($row->fresh()->sent_at);
        $this->assertDatabaseCount('notifications', 1);
        $notification = $recipient->notifications()->sole();
        $this->assertSame(ControlRoomAlertNotification::class, $notification->type);
        $this->assertSame((int) $alert->id, (int) $notification->data['alert_id']);
        $this->assertNull($alert->fresh()->acknowledged_at);
        $this->assertDatabaseCount('control_room_communications', 1);
    }

    public function test_unsaved_initial_communication_rolls_back_all_staging_without_false_routing_or_dispatch(): void
    {
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $first = $this->operator($site);
        $second = $this->operator($site);
        $queue = $this->queue([$first->id, $second->id]);
        $alert = $this->alert($site, $queue);
        $originalContext = $alert->fresh()->context;
        $service = app(ControlRoomNotificationService::class);

        $this->withRefusedWrite(Communication::class, 'creating',
            fn (Communication $creating): bool => (int) $creating->target_user_id === (int) $second->id,
            fn () => $service->stageAlertNotifications($alert, null, $queue),
            'Notification communication was not persisted.');

        $this->assertDatabaseCount('control_room_communications', 0);
        $this->assertDatabaseCount('notifications', 0);
        $this->assertSame($originalContext, $alert->fresh()->context);
        Queue::assertNothingPushed();

        $rows = $service->stageAlertNotifications($alert, null, $queue);
        $this->assertEqualsCanonicalizing([$first->id, $second->id], $rows->pluck('target_user_id')->all());
        foreach ($rows as $row) {
            $this->assertTrue($row->exists);
            $this->assertNotNull($row->getKey());
            $this->assertDatabaseHas('control_room_communications', ['id' => $row->id, 'delivery_key' => $row->delivery_key]);
        }
        $this->assertSame(2, data_get($alert->fresh()->context, 'notification_routing.eligible_recipients'));
        $this->assertDatabaseCount('control_room_communications', 2);
    }

    public function test_refused_payload_repair_preserves_the_canonical_row_and_routing_until_valid_retry(): void
    {
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $row->update(['notification_payload' => null, 'content' => 'Older payload']);
        $original = $row->fresh()->getRawOriginal();
        $originalContext = $alert->fresh()->context;

        $this->withRefusedWrite(Communication::class, 'saving',
            fn (Communication $saving): bool => (int) $saving->id === (int) $row->id && $saving->isDirty('notification_payload'),
            fn () => $service->stageAlertNotifications($alert, null, $queue),
            'Notification routing payload was not persisted.');

        $this->assertSame($original, $row->fresh()->getRawOriginal());
        $this->assertSame($originalContext, $alert->fresh()->context);
        $this->assertDatabaseCount('notifications', 0);
        Queue::assertNothingPushed();

        $repaired = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $this->assertSame($row->id, $repaired->id);
        $this->assertSame((int) $alert->id, $repaired->notification_payload['alert_id']);
        $this->assertSame('pending', $repaired->status);
        $this->assertDatabaseCount('control_room_communications', 1);
    }

    public function test_refused_revival_keeps_the_notice_superseded_until_a_valid_staging_retry(): void
    {
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $row->update(['superseded_at' => now(), 'status_detail' => 'Previous routing']);
        $original = $row->fresh()->getRawOriginal();
        $originalContext = $alert->fresh()->context;

        $this->withRefusedWrite(Communication::class, 'saving',
            fn (Communication $saving): bool => (int) $saving->id === (int) $row->id
                && $saving->isDirty('superseded_at') && $saving->superseded_at === null,
            fn () => $service->stageAlertNotifications($alert, null, $queue),
            'Notification routing revival was not persisted.');

        $this->assertSame($original, $row->fresh()->getRawOriginal());
        $this->assertSame($originalContext, $alert->fresh()->context);
        $this->assertDatabaseCount('notifications', 0);
        Queue::assertNothingPushed();

        $revived = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $this->assertSame($row->id, $revived->id);
        $this->assertNull($revived->superseded_at);
        $this->assertNull($revived->status_detail);
        $this->assertDatabaseCount('control_room_communications', 1);
    }

    public function test_refused_completion_supersession_preserves_the_pending_row_without_a_notification(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $alert->update(['status' => 'resolved', 'resolved_at' => now()]);
        $original = $row->fresh()->getRawOriginal();
        $originalContext = $alert->fresh()->context;

        $this->withRefusedWrite(Communication::class, 'saving',
            fn (Communication $saving): bool => (int) $saving->id === (int) $row->id && $saving->superseded_at !== null,
            fn () => $service->deliverStagedNotification($row),
            'Completed notification supersession was not persisted.');

        $this->assertSame($original, $row->fresh()->getRawOriginal());
        $this->assertSame($originalContext, $alert->fresh()->context);
        $this->assertDatabaseCount('notifications', 0);
        $this->assertSame([], $service->deliverStagedNotification($row));
        $this->assertNotNull($row->fresh()->superseded_at);
        $this->assertNull($row->fresh()->sent_at);
        $this->assertSame('resolved', $alert->fresh()->status);
    }

    public function test_a_stale_pending_model_cannot_deliver_an_already_sent_canonical_notice_twice(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();

        $this->assertSame([], $service->deliverStagedNotification($row));
        $this->assertSame('pending', $row->status);
        $this->assertSame('sent', $row->fresh()->status);
        $this->assertSame([], $service->deliverStagedNotification($row));
        $this->assertDatabaseCount('notifications', 1);
        $this->assertDatabaseCount('control_room_communications', 1);
    }

    public function test_a_refused_database_notification_cannot_produce_a_sent_communication(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $original = $row->fresh()->getRawOriginal();

        $this->withRefusedWrite(DatabaseNotification::class, 'creating',
            fn (DatabaseNotification $creating): bool => (int) $creating->notifiable_id === (int) $recipient->id,
            fn () => $service->deliverStagedNotification($row),
            'Control Room database notification was not persisted.');

        $this->assertSame($original, $row->fresh()->getRawOriginal());
        $this->assertDatabaseCount('notifications', 0);
        (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
        $this->assertDatabaseCount('notifications', 1);
        $this->assertSame('sent', $row->fresh()->status);
    }

    public function test_an_unsaved_direct_notification_ledger_rolls_back_the_real_notification(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);

        $this->withRefusedWrite(Communication::class, 'creating',
            fn (Communication $creating): bool => $creating->status === 'sent',
            fn () => $service->notifyAlert($alert, null, $queue),
            'Notification communication was not persisted.');

        $this->assertDatabaseCount('notifications', 0);
        $this->assertDatabaseCount('control_room_communications', 0);
        $service->notifyAlert($alert, null, $queue);
        $this->assertDatabaseCount('notifications', 1);
        $this->assertDatabaseCount('control_room_communications', 1);
        $this->assertSame('sent', $alert->communications()->sole()->status);
    }

    public function test_job_failure_recording_veto_is_truthful_and_operator_copy_excludes_raw_exception_details(): void
    {
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $original = $row->fresh()->getRawOriginal();
        $originalContext = $alert->fresh()->context;
        $privateFailure = 'private medical detail; SQL binding and provider credential';
        $dispatcher = DatabaseNotification::getEventDispatcher();
        DatabaseNotification::setEventDispatcher(clone $dispatcher);
        DatabaseNotification::creating(function () use ($privateFailure): void {
            throw new \RuntimeException($privateFailure);
        });

        try {
            $failure = $this->withRefusedWrite(Communication::class, 'saving',
                fn (Communication $saving): bool => (int) $saving->id === (int) $row->id && $saving->status === 'failed',
                fn () => (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service),
                'Notification failure recovery state was not persisted.');
            $this->assertSame($privateFailure, $failure->getPrevious()?->getMessage());
            $this->assertSame($original, $row->fresh()->getRawOriginal());
            $this->assertSame($originalContext, $alert->fresh()->context);
            $this->assertDatabaseCount('notifications', 0);
            Queue::assertNothingPushed();

            try {
                (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
                $this->fail('The original delivery failure must still propagate after its durable recovery write.');
            } catch (\RuntimeException $exception) {
                $this->assertSame($privateFailure, $exception->getMessage());
            }
            $failed = $row->fresh();
            $this->assertSame('failed', $failed->status);
            $this->assertSame(1, (int) $failed->retry_count);
            $this->assertSame('Delivery failed. This notice was not sent. A retry is pending.', $failed->status_detail);
            $this->assertStringNotContainsString($privateFailure, $failed->status_detail);
            $this->assertDatabaseCount('notifications', 0);
        } finally {
            DatabaseNotification::setEventDispatcher($dispatcher);
        }

        (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
        (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
        $this->assertDatabaseCount('notifications', 1);
        $this->assertSame('sent', $row->fresh()->status);
        $this->assertNull($row->fresh()->status_detail);
    }

    public function test_unpersisted_and_deleted_communications_cannot_deliver_or_return_dispatch_ids(): void
    {
        Queue::fake([DeliverControlRoomAlertNotificationJob::class]);
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $unsaved = $row->replicate();
        $this->assertFalse($unsaved->exists);
        $this->assertNull($unsaved->getKey());
        $deleted = $row->fresh();
        $row->delete();
        $originalContext = $alert->fresh()->context;

        $this->assertTrue($deleted->exists);
        foreach ([$unsaved, $deleted] as $missing) {
            try {
                $service->deliverStagedNotification($missing);
                $this->fail('Delivery must reject a communication that is not persisted.');
            } catch (\RuntimeException $exception) {
                $this->assertSame('Notification communication was not persisted.', $exception->getMessage());
            }
        }

        $this->assertDatabaseCount('notifications', 0);
        $this->assertDatabaseCount('control_room_communications', 0);
        $this->assertSame($originalContext, $alert->fresh()->context);
        Queue::assertNothingPushed();
    }

    public function test_last_delivery_failure_uses_safe_review_copy_without_claiming_another_retry(): void
    {
        $site = Site::factory()->create();
        $recipient = $this->operator($site);
        $queue = $this->queue([$recipient->id]);
        $alert = $this->alert($site, $queue);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($alert, null, $queue)->sole();
        $row->update(['retry_count' => 2]);
        $dispatcher = DatabaseNotification::getEventDispatcher();
        DatabaseNotification::setEventDispatcher(clone $dispatcher);
        $attempted = 0;
        DatabaseNotification::creating(function () use (&$attempted): void {
            $attempted++;
            throw new \RuntimeException('Private failed delivery detail');
        });

        try {
            try {
                (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
                $this->fail('The final delivery failure must propagate.');
            } catch (\RuntimeException $exception) {
                $this->assertSame('Private failed delivery detail', $exception->getMessage());
            }
            (new DeliverControlRoomAlertNotificationJob($row->id))->handle($service);
        } finally {
            DatabaseNotification::setEventDispatcher($dispatcher);
        }

        $this->assertSame(1, $attempted);
        $this->assertSame('failed', $row->fresh()->status);
        $this->assertSame(3, (int) $row->fresh()->retry_count);
        $this->assertSame('Delivery failed. This notice was not sent. Review delivery failures and current routing.', $row->fresh()->status_detail);
        $this->assertDatabaseCount('notifications', 0);
    }

    /** Refuse a real model write while retaining every installed event listener. */
    private function withRefusedWrite(string $model, string $event, \Closure $condition, \Closure $operation, string $message): \RuntimeException
    {
        $dispatcher = $model::getEventDispatcher();
        $model::setEventDispatcher(clone $dispatcher);
        $vetoed = false;
        $model::{$event}(function ($writing) use ($condition, &$vetoed): ?bool {
            if ($condition($writing)) {
                $vetoed = true;

                return false;
            }

            return null;
        });
        $failure = null;
        try {
            try {
                $operation();
                $this->fail('A refused write must abort its owning transaction.');
            } catch (\RuntimeException $exception) {
                $this->assertSame($message, $exception->getMessage());
                $failure = $exception;
            }
        } finally {
            $model::setEventDispatcher($dispatcher);
        }

        $this->assertTrue($vetoed, 'The real Eloquent event must refuse the write.');
        $this->assertInstanceOf(\RuntimeException::class, $failure);

        return $failure;
    }

    /** A timing adapter mutates real persisted state before final authorization; every real lock/read still runs. */
    private function notificationsWithFinalReadChange(\Closure $change): ControlRoomNotificationService
    {
        $authorization = new class($change) extends AuthorizationEvidenceLockService
        {
            public function __construct(private ?\Closure $change) {}

            public function lockForUserWithoutWaiting(User|int $user, array $permissionKeys): User
            {
                $functions = array_column(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS), 'function');
                if ($this->change !== null && in_array('deliverStagedNotification', $functions, true)
                    && array_intersect(['authorizedRecipients', 'stageAlertNotifications'], $functions) === []) {
                    $change = $this->change;
                    $this->change = null;
                    $change();
                }

                return parent::lockForUserWithoutWaiting($user, $permissionKeys);
            }
        };
        app()->instance(AuthorizationEvidenceLockService::class, $authorization);
        app()->forgetInstance(ControlRoomRecipientEligibilityService::class);
        app()->forgetInstance(ControlRoomNotificationService::class);

        return app(ControlRoomNotificationService::class);
    }

    private function operator(Site $site): User
    {
        $user = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        $user->roles()->sync([Role::query()->where('name', 'support_worker')->sole()->id]);
        $user->permissionOverrides()->sync(Permission::query()->whereIn('key', ['controlRoom.alerts.view', 'controlRoom.alerts.manage'])
            ->pluck('id')->mapWithKeys(fn ($id): array => [$id => ['allowed' => true]]));
        HrEmployeeProfile::factory()->create(['user_id' => $user->id, 'position_role' => 'support_worker',
            'primary_site_id' => $site->id, 'secondary_site_ids' => [], 'is_active' => true,
            'start_date' => today()->subYear(), 'created_by' => $user->id, 'updated_by' => $user->id]);

        return $user;
    }

    private function denyRead(User $user): void
    {
        $this->setReadPermission($user, false);
    }

    private function setReadPermission(User $user, bool $allowed): void
    {
        $user->permissionOverrides()->sync(Permission::query()->whereIn('key', ['controlRoom.alerts.view', 'controlRoom.alerts.manage'])
            ->pluck('id')->mapWithKeys(fn ($id): array => [$id => ['allowed' => $allowed]]));
    }

    private function queue(array $ids): TriageQueue
    {
        return TriageQueue::query()->create(['name' => 'Actual routing', 'code' => 'actual-routing',
            'tier' => 1, 'is_active' => true, 'assigned_users' => $ids, 'assigned_roles' => []]);
    }

    private function alert(Site $site, TriageQueue $queue): ControlRoomAlert
    {
        return ControlRoomAlert::factory()->open()->create(['site_id' => $site->id, 'client_id' => null,
            'assigned_to_user_id' => null, 'queue_id' => $queue->id, 'source' => 'device', 'alert_type' => 'Device Offline', 'context' => []]);
    }
}
