<?php

namespace Tests\Feature\ControlRoom;

use App\Models\ControlRoomAlert;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use Database\Factories\ControlRoomAlertFactory;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Carbon;
use Tests\TestCase;

class ControlRoomStatsControllerTest extends TestCase
{
    use RefreshDatabase;

    protected User $admin;

    protected Site $site;

    protected function setUp(): void
    {
        parent::setUp();

        $this->seed(RbacSeeder::class);

        $this->admin = User::factory()->create([
            'organization_id' => 1,
            'role' => 'admin',
            'approved_at' => now(),
        ]);
        $this->admin->roles()->attach(Role::where('name', 'admin')->first());
        $this->site = Site::factory()->create([
            'tenant_id' => $this->admin->organization_id,
        ]);
    }

    public function test_stats_requires_authentication(): void
    {
        $this->get('/control-room/stats')->assertRedirect('/login');
    }

    public function test_stats_blocked_for_user_without_permission(): void
    {
        $user = User::factory()->create([
            'organization_id' => $this->admin->organization_id,
            'approved_at' => now(),
        ]);

        $this->actingAs($user)
            ->get('/control-room/stats')
            ->assertForbidden();
    }

    public function test_stats_renders_inertia_page_with_kpis(): void
    {
        $this->actingAs($this->admin)
            ->get('/control-room/stats')
            ->assertOk()
            ->assertInertia(fn ($page) => $page
                ->component('control-room/stats')
                ->has('kpis')
                ->has('volume_trend')
                ->has('top_sources')
                ->has('top_alert_types')
                ->has('severity_distribution')
                ->has('operator_performance')
                ->has('shift_comparison')
                ->has('signal_sources')
                ->where('period', '7d')
            );
    }

    public function test_stats_accepts_24h_period(): void
    {
        $this->actingAs($this->admin)
            ->get('/control-room/stats?period=24h')
            ->assertOk()
            ->assertInertia(fn ($page) => $page->where('period', '24h'));
    }

    public function test_missing_measurements_remain_unavailable_instead_of_zero_time(): void
    {
        $this->actingAs($this->admin)->get('/control-room/stats')->assertOk()
            ->assertInertia(fn ($page) => $page->where('kpis.avg_acknowledge_minutes', null)
                ->where('kpis.avg_resolution_hours', null)->where('kpis.sla_compliance_pct', null));
    }

    public function test_stats_falls_back_to_default_for_invalid_period(): void
    {
        $this->actingAs($this->admin)
            ->get('/control-room/stats?period=bogus')
            ->assertOk()
            ->assertInertia(fn ($page) => $page->where('period', '7d'));
    }

    public function test_stats_aggregates_open_alerts(): void
    {
        $this->alertFactory()->open()->count(3)->create();
        $this->alertFactory()->resolved()->count(2)->create();

        $this->actingAs($this->admin)
            ->get('/control-room/stats')
            ->assertOk()
            ->assertInertia(fn ($page) => $page
                ->where('kpis.open_alerts', 3)
            );
    }

    public function test_today_uses_the_worker_day_on_both_sides_of_daylight_saving_and_excludes_future_signals(): void
    {
        foreach ([
            ['2026-10-11 13:00:00', '2026-10-11 11:00:00', '2026-10-12'],
            ['2026-04-05 13:00:00', '2026-04-05 12:00:00', '2026-04-06'],
        ] as [$asOf, $dayStart, $workerDate]) {
            $this->travelTo(Carbon::parse($asOf, 'UTC'));
            $start = Carbon::parse($dayStart, 'UTC');
            $this->alertFactory()->open()->create(['triggered_at' => $start->copy()->subSecond()]);
            $this->alertFactory()->open()->create(['triggered_at' => $start]);
            $this->alertFactory()->open()->create(['triggered_at' => now()->subSecond()]);
            $this->alertFactory()->open()->create(['triggered_at' => now()->addHour()]);

            $this->actingAs($this->admin)->get('/control-room/stats')->assertOk()
                ->assertInertia(fn ($page) => $page->where('kpis.alerts_today', 2)
                    ->where('kpis.today_date', $workerDate));
        }
    }

    public function test_operator_counts_use_actual_acknowledgement_actor_and_period(): void
    {
        $this->freezeTime();
        $acknowledger = User::factory()->create(['name' => 'Response operator']);
        $assignee = User::factory()->create(['name' => 'Later owner']);
        $this->alertFactory()->acknowledged()->create([
            'triggered_at' => now()->subDays(40), 'acknowledged_at' => now()->subHour(),
            'acknowledged_by_user_id' => $acknowledger->id, 'assigned_to_user_id' => $assignee->id,
            'assigned_at' => now(),
        ]);
        $this->alertFactory()->open()->create(['triggered_at' => now()->subMinute(), 'assigned_to_user_id' => $assignee->id]);
        $this->alertFactory()->acknowledged()->create([
            'triggered_at' => now()->subDays(50), 'acknowledged_at' => now()->subDays(40),
            'acknowledged_by_user_id' => $acknowledger->id,
        ]);

        $this->actingAs($this->admin)->get('/control-room/stats?period=7d')->assertOk()
            ->assertInertia(fn ($page) => $page->has('operator_performance', 1)
                ->where('operator_performance.0.name', 'Response operator')
                ->where('operator_performance.0.alerts_handled', 1)
                ->where('operator_performance.0.avg_response_minutes', fn ($value) => (float) $value === 57540.0));
    }

    private function alertFactory(): ControlRoomAlertFactory
    {
        return ControlRoomAlert::factory()->state([
            'site_id' => $this->site->id,
        ]);
    }
}
