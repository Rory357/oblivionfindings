<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Governance\Models\BoardPack;
use App\Domain\Governance\Models\GovernanceMeeting;
use App\Domain\Governance\Notifications\BoardPackPublishedNotification;
use App\Domain\Governance\Services\BoardPackAccessService;
use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\MedicationAlert;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use App\Models\WorkplaceInjury;
use App\Notifications\AppEventNotification;
use App\Notifications\ControlRoomAlertNotification;
use App\Notifications\MedicationAlertNotification;
use App\Services\ControlRoom\ControlRoomDatabaseNotificationAccessService;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\Medication\Alerts\MedicationAlertCatalogue;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use LogicException;
use Tests\TestCase;

/** Actual persisted notices/current RBAC/HR/Site and HTTP consumers. Authored, runtime UNRUN. */
class ControlRoomDatabaseNotificationReadTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;

    private User $viewer;

    private ControlRoomAlert $alert;

    protected function setUp(): void
    {
        parent::setUp();
        Queue::fake();
        $this->seed(RbacSeeder::class);
        $this->site = Site::factory()->create(['is_active' => true]);
        $this->viewer = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        HrEmployeeProfile::factory()->create(['user_id' => $this->viewer->id, 'primary_site_id' => $this->site->id,
            'secondary_site_ids' => [], 'is_active' => true, 'start_date' => now('Pacific/Auckland')->subYear()->toDateString(), 'end_date' => null]);
        $this->permission('controlRoom.alerts.view', true);
        $this->alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'source' => 'operations', 'alert_type' => 'operations.workplace_injury', 'site_id' => $this->site->id,
            'client_id' => null, 'status' => ControlRoomAlert::STATUS_OPEN,
            // Missing protected source still permits independent urgent response under CR authority.
            'context' => ['workplace_injury_id' => null], 'notes' => 'PRIVATE-MEDICAL-COPY',
        ]));
    }

    public function test_historic_medical_payload_is_reprojected_and_unavailable_source_keeps_generic_response(): void
    {
        $id = $this->notice();
        $header = app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer);
        $this->assertSame(1, $header['unread_count']);
        $this->assertSame($id, $header['items'][0]['id']);
        $data = $header['items'][0]['data'];
        $this->assertSame('Workplace injury response', $data['title']);
        $this->assertSame($this->alert->severity, $data['severity']);
        $this->assertArrayNotHasKey('context', $data);
        $this->assertStringNotContainsString('PRIVATE-', json_encode($header, JSON_THROW_ON_ERROR));
        $this->assertStringContainsString('PRIVATE-', DB::table('notifications')->where('id', $id)->value('data'));
    }

    public function test_warmed_module_permission_revocation_hides_only_cr_rows(): void
    {
        $id = $this->notice();
        $other = $this->notice(['title' => 'Independent update'], AppEventNotification::class);
        $this->viewer->load('roles.permissions', 'permissionOverrides', 'hrEmployeeProfile');
        $this->assertSame(2, app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['unread_count']);
        $this->permission('controlRoom.alerts.view', false);
        $header = app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer);
        $this->assertSame(1, $header['unread_count']);
        $this->assertSame([$other], array_column($header['items'], 'id'));
        $this->assertNull(DB::table('notifications')->where('id', $id)->value('read_at'));
    }

    public function test_role_permission_revocation_rebuilds_current_authority(): void
    {
        $this->viewer->permissionOverrides()->detach(Permission::where('key', 'controlRoom.alerts.view')->sole());
        $role = Role::create(['name' => 'notification_reader_regression']);
        $role->permissions()->attach(Permission::where('key', 'controlRoom.alerts.view')->sole());
        $this->viewer->roles()->attach($role);
        $this->viewer->load('roles.permissions', 'permissionOverrides');
        $this->notice();
        $this->assertSame(1, app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['unread_count']);
        $role->permissions()->detach();
        $this->assertSame(0, app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['unread_count']);
    }

    public function test_current_site_and_current_staff_revocation_hide_cr_without_blanking_other_types(): void
    {
        $this->notice();
        $other = $this->notice(['title' => 'Unaffected update'], AppEventNotification::class);
        $this->viewer->load('hrEmployeeProfile');
        $this->viewer->hrEmployeeProfile->update(['primary_site_id' => Site::factory()->create(['is_active' => true])->id]);
        $this->assertSame([$other], array_column(app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['items'], 'id'));
        $this->viewer->hrEmployeeProfile->update(['primary_site_id' => $this->site->id, 'is_active' => false]);
        $this->assertSame([$other], array_column(app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['items'], 'id'));
    }

    public function test_invalid_id_and_mismatched_class_or_semantic_type_are_excluded_before_limits(): void
    {
        $valid = $this->notice();
        $data = ['type' => 'control_room_alert', 'alert_id' => $this->alert->id];
        $bad = [
            $this->notice($data + ['title' => 'PRIVATE-FORGED'], AppEventNotification::class),
            $this->notice(['type' => 'medication_alert', 'alert_id' => $this->alert->id]),
        ];
        foreach ([null, 0, -1, true, 1.5, $this->alert->id.'x', '0'.$this->alert->id, [], 999999999] as $id) {
            $bad[] = $this->notice(['type' => 'control_room_alert', 'alert_id' => $id]);
        }
        $header = app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer);
        $this->assertSame(1, $header['unread_count']);
        $this->assertSame([$valid], array_column($header['items'], 'id'));
        foreach ($bad as $id) {
            $this->assertDirectDenied($id);
        }
    }

    public function test_canonical_json_string_id_is_supported_without_numeric_coercion(): void
    {
        $id = $this->notice(['type' => 'control_room_alert', 'alert_id' => (string) $this->alert->id]);
        $header = app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer);
        $this->assertSame([$id], array_column($header['items'], 'id'));
        $this->assertSame((int) $this->alert->id, $header['items'][0]['data']['alert_id']);
    }

    public function test_both_actual_pages_count_and_project_the_same_visible_rows(): void
    {
        $id = $this->notice();
        $this->notice(['type' => 'control_room_alert', 'alert_id' => null]);
        foreach (['/notifications' => 'unread_count', '/portal/notifications' => 'unreadCount'] as $path => $countKey) {
            $response = $this->actingAs($this->viewer)->get($path)->assertOk();
            $this->assertSame(1, $response->inertiaProps($countKey));
            $this->assertSame(1, $response->inertiaProps('notifications.total'));
            $this->assertSame($id, $response->inertiaProps('notifications.data.0.id'));
            $this->assertStringNotContainsString('PRIVATE-', json_encode($response->inertiaProps('notifications.data'), JSON_THROW_ON_ERROR));
        }
    }

    public function test_actual_my_day_digest_and_count_share_current_projection(): void
    {
        $id = $this->notice();
        $this->notice(['type' => 'control_room_alert', 'alert_id' => null]);
        $response = $this->actingAs($this->viewer)->get('/my-day')->assertOk();
        $this->assertSame(1, $response->inertiaProps('stats.notifications_unread'));
        $this->assertSame($id, $response->inertiaProps('notifications.0.id'));
        $this->assertSame('Workplace injury response', $response->inertiaProps('notifications.0.title'));
    }

    public function test_read_and_acknowledge_mutate_notice_only_and_never_attend_medication_or_acknowledge_alert(): void
    {
        $id = $this->notice();
        $before = $this->alert->fresh()->getRawOriginal();
        $access = app(ControlRoomDatabaseNotificationAccessService::class);
        $attended = 0;
        $attendance = function () use (&$attended): void {
            $attended++;
        };
        $this->assertTrue($access->mutate($this->viewer, $id, otherAttendance: $attendance));
        $this->assertTrue($access->mutate($this->viewer, $id, acknowledge: true, otherAttendance: $attendance));
        $this->assertSame(0, $attended);
        $this->assertNotNull(DB::table('notifications')->where('id', $id)->value('read_at'));
        $this->assertNotNull(DB::table('notifications')->where('id', $id)->value('acknowledged_at'));
        $this->assertSame($before, $this->alert->fresh()->getRawOriginal());
    }

    public function test_revoked_direct_mutations_and_read_all_preserve_denied_notice(): void
    {
        $id = $this->notice();
        $other = $this->notice(['title' => 'Independent update'], AppEventNotification::class);
        $this->permission('controlRoom.alerts.view', false);
        $before = (array) DB::table('notifications')->where('id', $id)->first();
        $this->assertDirectDenied($id);
        foreach (['/inbox/notifications/read-all', '/portal/notifications/read-all'] as $path) {
            $this->actingAs($this->viewer)->post($path)->assertRedirect();
            $this->assertSame($before, (array) DB::table('notifications')->where('id', $id)->first());
            $this->assertNotNull(DB::table('notifications')->where('id', $other)->value('read_at'));
        }
    }

    public function test_other_recipient_notification_cannot_be_borrowed_for_projection_or_mutation(): void
    {
        $other = User::factory()->create();
        $id = $this->notice();
        DB::table('notifications')->where('id', $id)->update(['notifiable_id' => $other->id]);
        $this->assertDirectDenied($id);
        $this->assertSame(0, app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['unread_count']);
    }

    public function test_unrelated_notification_visibility_matches_canonical_board_and_medication_policy(): void
    {
        $this->notice();
        $this->notice(['title' => 'Independent update'], AppEventNotification::class);
        $this->notice(['type' => 'medication_alert', 'medication_alert_id' => 999999], AppEventNotification::class);
        $expected = app(BoardPackAccessService::class)->visibleNotificationQuery($this->viewer)->where('type', '!=', ControlRoomAlertNotification::class)->pluck('id')->all();
        $actual = array_column(array_filter(app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer)['items'],
            fn ($row) => $row['type'] !== ControlRoomAlertNotification::class), 'id');
        $this->assertEqualsCanonicalizing($expected, $actual);
    }

    public function test_query_cannot_execute_after_current_callback_expires(): void
    {
        $access = app(ControlRoomDatabaseNotificationAccessService::class);
        $escaped = null;
        $access->withCurrentViewer($this->viewer, function ($current, $context) use ($access, &$escaped): array {
            $escaped = $access->visibleQuery($current, $context);

            return [];
        });
        $this->expectException(LogicException::class);
        $escaped->count();
    }

    public function test_actual_deferred_header_uses_projected_cr_data(): void
    {
        $id = $this->notice();
        $this->notice(['type' => 'control_room_alert', 'alert_id' => null]);
        $response = $this->actingAs($this->viewer)->get('/notifications', $this->inertiaPartialHeaders('notifications/index', 'inbox'))
            ->assertOk()->assertJsonPath('props.inbox.notifications.unread_count', 1)
            ->assertJsonCount(1, 'props.inbox.notifications.items')->assertJsonPath('props.inbox.notifications.items.0.id', $id);
        $this->assertStringNotContainsString('PRIVATE-', json_encode($response->json('props.inbox'), JSON_THROW_ON_ERROR));
    }

    public function test_current_source_permission_revocation_preserves_only_generic_response_payload(): void
    {
        $injury = WorkplaceInjury::withoutEvents(fn () => WorkplaceInjury::factory()->create([
            'user_id' => $this->viewer->id, 'site_id' => $this->site->id, 'created_by' => $this->viewer->id,
            'description' => 'Canonical factual event', 'notes' => 'PRIVATE-RECOVERY', 'source_schema_version' => 0, 'source_revision' => 0,
        ]));
        $this->alert->updateQuietly(['context' => ['workplace_injury_id' => $injury->id, 'site_id' => $this->site->id, 'user_id' => $this->viewer->id]]);
        HsEvent::withoutEvents(fn () => HsEvent::factory()->create([
            'control_room_alert_id' => $this->alert->id, 'source_type' => WorkplaceInjury::class, 'source_id' => $injury->id,
            'event_category' => HsEvent::CATEGORY_INJURY, 'site_id' => $this->site->id, 'staff_id' => $this->viewer->id, 'client_id' => null,
            'idempotency_key' => HsEvent::buildIdempotencyKey(WorkplaceInjury::class, $injury->id, HsEvent::CATEGORY_INJURY),
        ]));
        $this->permission('hazards.view', true);
        $id = $this->notice();
        $access = app(ControlRoomDatabaseNotificationAccessService::class);
        $this->assertSame(1, $access->header($this->viewer)['unread_count']);
        $this->viewer->load('permissionOverrides', 'roles.permissions');
        $this->permission('hazards.view', false);
        $header = $access->header($this->viewer);
        $this->assertSame([$id], array_column($header['items'], 'id'));
        $this->assertSame('Workplace injury response', $header['items'][0]['data']['title']);
        $this->assertStringNotContainsString('PRIVATE-', json_encode($header, JSON_THROW_ON_ERROR));
    }

    public function test_generic_reminder_scope_cannot_redistribute_cr_semantic_payload_under_workflow_class(): void
    {
        $bad = $this->notice(['type' => 'control_room_alert', 'alert_id' => $this->alert->id, 'event_key' => 'timesheets.approved'], AppEventNotification::class);
        $good = $this->notice(['title' => 'Workflow update', 'event_key' => 'timesheets.approved'], AppEventNotification::class);
        $ids = ControlRoomDatabaseNotificationAccessService::applyOtherTypesScope(DatabaseNotification::query())
            ->where('type', AppEventNotification::class)->where('data->event_key', 'timesheets.approved')->pluck('id')->all();
        $this->assertSame([$good], $ids);
        $this->assertNotContains($bad, $ids);
    }

    public function test_cr_only_context_cannot_downgrade_other_notification_permission_evidence(): void
    {
        $this->expectException(LogicException::class);
        HealthSafetyReadContext::within($this->viewer, ControlRoomGovernanceReadService::PERMISSIONS,
            fn ($context) => app(ControlRoomDatabaseNotificationAccessService::class)->withCurrentViewer($this->viewer, fn (): array => [], $context));
    }

    public function test_board_pack_permissions_and_own_medication_notice_survive_cr_revocation(): void
    {
        $this->permission('governance.packs.view', true);
        $this->permission('governance.packs.manage', true);
        $this->permission('governance.meetings.view', true);
        $meeting = GovernanceMeeting::create(['meeting_type' => 'full_board', 'title' => 'Board meeting',
            'scheduled_at' => now()->addWeek(), 'duration_minutes' => 60, 'status' => 'scheduled', 'quorum_required' => 50, 'created_by' => $this->viewer->id]);
        $pack = BoardPack::create(['governance_meeting_id' => $meeting->id, 'revision_number' => 1,
            'build_status' => 'published', 'generated_by' => $this->viewer->id]);
        $packId = $this->notice(['pack_id' => $pack->id, 'title' => 'Board papers'], BoardPackPublishedNotification::class);
        $medicine = MedicationAlert::create(['type' => MedicationAlertCatalogue::RENEWALS, 'dedupe_key' => (string) Str::uuid(),
            'site_id' => $this->site->id, 'client_id' => null, 'staff_user_id' => $this->viewer->id, 'controlled' => false,
            'title' => 'Your competency', 'message' => 'Renew your competency', 'short_message' => 'Renewal',
            'severity' => 'warning', 'status' => MedicationAlert::STATUS_OPEN, 'raised_at' => now()]);
        $medicineId = $this->notice(['type' => 'medication_alert', 'medication_alert_id' => $medicine->id,
            'title' => 'Your competency', 'ack_required' => true], MedicationAlertNotification::class);
        $this->notice();
        $this->permission('controlRoom.alerts.view', false);
        $header = app(ControlRoomDatabaseNotificationAccessService::class)->header($this->viewer);
        $this->assertSame(2, $header['unread_count']);
        $this->assertEqualsCanonicalizing([$packId, $medicineId], array_column($header['items'], 'id'));
        $attendance = 0;
        app(ControlRoomDatabaseNotificationAccessService::class)->mutate($this->viewer, $medicineId,
            otherAttendance: function () use (&$attendance): void {
                $attendance++;
            });
        $this->assertSame(1, $attendance);
        $this->permission('governance.packs.view', false);
        $this->assertDirectDenied($packId);
    }

    private function permission(string $key, bool $allowed): void
    {
        $this->viewer->permissionOverrides()->syncWithoutDetaching([Permission::where('key', $key)->sole()->id => ['allowed' => $allowed]]);
    }

    private function notice(?array $data = null, string $class = ControlRoomAlertNotification::class): string
    {
        $id = (string) Str::uuid();
        DB::table('notifications')->insert([
            'id' => $id, 'type' => $class, 'notifiable_type' => $this->viewer->getMorphClass(), 'notifiable_id' => $this->viewer->id,
            'data' => json_encode($data ?? ['type' => 'control_room_alert', 'alert_id' => $this->alert->id,
                'title' => 'PRIVATE-TREATMENT', 'body' => 'PRIVATE-RECOVERY', 'context' => ['medical' => 'PRIVATE-ASSESSMENT'],
                'severity' => 'PRIVATE-FORGED-SEVERITY', 'ack_required' => true]),
            'read_at' => null, 'acknowledged_at' => null, 'created_at' => now(), 'updated_at' => now(),
        ]);

        return $id;
    }

    private function assertDirectDenied(string $id): void
    {
        foreach (['/inbox/notifications/'.$id.'/read', '/inbox/notifications/'.$id.'/acknowledge', '/portal/notifications/'.$id.'/read'] as $path) {
            $this->actingAs($this->viewer)->post($path)->assertNotFound();
        }
    }
}
