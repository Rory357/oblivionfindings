<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Http\Middleware\HandleInertiaRequests;
use App\Models\ControlRoom\Communication;
use App\Models\ControlRoom\OperatorNote;
use App\Models\ControlRoom\TriageQueue;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\Permission;
use App\Models\Site;
use App\Models\User;
use App\Models\WorkplaceInjury;
use App\Models\WorkplaceInjurySourceVersion;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\ControlRoom\AlertWorklistPresenter;
use App\Services\ControlRoom\AlertWorklistQuery;
use App\Services\ControlRoom\AlertWorkspaceService;
use App\Services\ControlRoom\ControlRoomDeskService;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use App\Services\ControlRoom\ControlRoomNotificationService;
use App\Services\ControlRoom\ControlRoomRecipientEligibilityService;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\HealthSafety\InjuryAccessService;
use App\Services\HealthSafety\RestraintCommandValues;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use LogicException;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;
use Tests\TestCase;

/** Real current-evidence and copied-source regressions. Authored; runtime UNRUN. */
class ControlRoomCurrentSourceReadTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;

    private User $viewer;

    private User $worker;

    private WorkplaceInjury $injury;

    private ControlRoomAlert $alert;

    private HsEvent $event;

    protected function setUp(): void
    {
        parent::setUp();
        Queue::fake();
        $this->seed(RbacSeeder::class);
        $this->site = Site::factory()->create(['is_active' => true]);
        $this->worker = $this->staff([]);
        $this->viewer = $this->staff(['controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage', 'hazards.view']);
        $this->injury = WorkplaceInjury::withoutEvents(fn () => WorkplaceInjury::factory()->create([
            'user_id' => $this->worker->id, 'site_id' => $this->site->id, 'created_by' => $this->viewer->id,
            'reference_number' => 'INJ-CURRENT-FACT', 'description' => 'Canonical factual occurrence',
            'source_schema_version' => 0, 'source_revision' => 0, 'status' => 'under_treatment',
            'immediate_treatment' => 'PRIVATE-TREATMENT', 'medical_treatment_type' => 'specialist',
            'notes' => 'PRIVATE-RECOVERY', 'acc_claim_number' => 'PRIVATE-CLAIM',
        ]));
        $this->alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'source' => 'operations', 'alert_type' => 'operations.workplace_injury', 'client_id' => null,
            'site_id' => $this->site->id, 'status' => ControlRoomAlert::STATUS_OPEN,
            'notes' => 'PRIVATE-COPIED-NOTE', 'context' => [
                'workplace_injury_id' => $this->injury->id, 'site_id' => $this->site->id, 'user_id' => $this->worker->id,
                'description' => 'PRIVATE-OLD-COPY', 'acc_claim_number' => 'PRIVATE-COPIED-CLAIM',
                'activity_log' => [['transition' => 'acknowledge', 'content' => 'Independent response work', 'user_id' => $this->viewer->id],
                    ['source' => 'workplace_injury', 'workplace_injury_id' => $this->injury->id, 'content' => 'PRIVATE-COPIED-ACTIVITY']],
            ],
        ]));
        $this->event = HsEvent::withoutEvents(fn () => HsEvent::factory()->create([
            'control_room_alert_id' => $this->alert->id, 'source_type' => WorkplaceInjury::class,
            'source_id' => $this->injury->id, 'event_category' => HsEvent::CATEGORY_INJURY,
            'site_id' => $this->site->id, 'staff_id' => $this->worker->id, 'client_id' => null, 'asset_id' => null,
            'created_by' => $this->viewer->id, 'reference_number' => 'HS-CANONICAL-SEARCH',
            'handover_status' => HsEvent::HANDOVER_ACCEPTED,
            'idempotency_key' => HsEvent::buildIdempotencyKey(WorkplaceInjury::class, $this->injury->id, HsEvent::CATEGORY_INJURY),
        ]));
    }

    public function test_factual_reader_uses_canonical_description_and_excludes_private_copies(): void
    {
        $row = app(AlertWorklistPresenter::class)->present($this->alert, $this->viewer);
        $this->assertSame('Canonical factual occurrence', $row['summary']);
        $this->assertSame('readable', $row['journey']['health_safety_access']);
        $this->assertNoPrivateText($row);
        $workspace = app(AlertWorkspaceService::class)->build($this->viewer, $this->alert->id);
        $this->assertNull($workspace['alert']['notes']);
        $this->assertSame('Independent response work', $workspace['alert']['context']['activity_log'][0]['content']);
        $this->assertSame($this->viewer->id, $workspace['alert']['context']['activity_log'][0]['user_id']);
        $this->assertNoPrivateText($workspace);
    }

    public function test_warmed_source_permission_revocation_and_restore_rebuilds_current_facts(): void
    {
        $this->viewer->load('permissionOverrides', 'roles.permissions', 'hrEmployeeProfile');
        $presenter = app(AlertWorklistPresenter::class);
        $this->assertSame('Canonical factual occurrence', $presenter->present($this->alert, $this->viewer)['summary']);
        $this->allow('hazards.view', false);
        $this->assertTrue($this->viewer->canDo('hazards.view'));
        $denied = $presenter->present($this->alert, $this->viewer);
        $this->assertSame('restricted', $denied['journey']['health_safety_access']);
        $this->assertNull($denied['actions']['health_safety_href']);
        $this->assertNoPrivateText($denied);
        $this->allow('hazards.view', true);
        $this->assertSame('Canonical factual occurrence', $presenter->present($this->alert, $this->viewer)['summary']);
    }

    public function test_source_manage_without_read_does_not_grant_factual_access(): void
    {
        $this->allow('hazards.view', false);
        $this->allow('hazards.manage', true);
        $this->assertSame('restricted', $this->governance()['injury_access']);
        $this->assertNull($this->governance()['injury_source']);
    }

    public function test_current_module_revocation_is_independent_of_source_permission(): void
    {
        $this->viewer->load('permissionOverrides', 'roles.permissions', 'hrEmployeeProfile');
        foreach (['controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage'] as $key) {
            $this->allow($key, false);
        }
        $this->assertTrue($this->viewer->canDo('controlRoom.viewAny'));
        $this->denied(fn () => app(AlertWorklistPresenter::class)->present($this->alert, $this->viewer), 403);
    }

    public function test_source_site_and_worker_corrections_reject_stale_alert_tuples(): void
    {
        $other = $this->staff([]);
        $this->injury->updateQuietly(['user_id' => $other->id]);
        $this->assertContains($this->governance()['injury_access'], ['restricted', 'unavailable']);
        $this->injury->updateQuietly(['user_id' => $this->worker->id]);
        $this->assertSame('readable', $this->governance()['injury_access']);
        $otherSite = Site::factory()->create(['is_active' => true]);
        $this->injury->updateQuietly(['site_id' => $otherSite->id]);
        $this->assertContains($this->governance()['injury_access'], ['restricted', 'unavailable']);
    }

    public function test_missing_typed_source_proof_is_unavailable_and_known_reporting_remains_open(): void
    {
        $this->injury->updateQuietly(['source_schema_version' => 1, 'source_revision' => 1]);
        $record = $this->governance();
        $this->assertSame('unavailable', $record['injury_access']);
        $row = app(AlertWorklistPresenter::class)->present($this->alert, $this->viewer);
        $this->assertSame('required', $row['reporting']['state']);
        $this->assertFalse($row['reporting']['canCreate']);
        $this->assertFalse($row['reporting']['canDecide']);
    }

    public function test_typed_factual_version_is_readable_without_reading_private_version_content(): void
    {
        $this->version();
        DB::enableQueryLog();
        DB::flushQueryLog();
        try {
            $record = $this->governance();
            $this->assertSame('readable', $record['injury_access']);
            $this->assertNoPrivateText($record);
            foreach (DB::getQueryLog() as $query) {
                $sql = strtolower($query['query']);
                $this->assertDoesNotMatchRegularExpression('/select\s+(?:[`"]?workplace_injuries[`"]?\.)?\*\s+from\s+[`"]?workplace_injuries/i', $sql);
                foreach (['medical_treatment_type', 'immediate_treatment', 'acc_claim_number', 'work_capacity_assessments', 'return_to_work_plans'] as $private) {
                    $this->assertStringNotContainsString($private, $sql);
                }
                if (str_contains($sql, 'workplace_injury_source_versions')) {
                    $this->assertDoesNotMatchRegularExpression('/(?<![a-z_])content(?![a-z_])/', $sql);
                }
            }
        } finally {
            DB::disableQueryLog();
        }
    }

    public function test_private_note_search_and_hse_reference_search_follow_current_source_access(): void
    {
        $worklists = app(AlertWorklistQuery::class);
        $this->assertSame(0, $worklists->materialize($this->viewer, ['q' => 'PRIVATE-COPIED-NOTE'], fn ($q): int => $q->count()));
        $this->assertSame(1, $worklists->materialize($this->viewer, ['q' => 'HS-CANONICAL-SEARCH'], fn ($q): int => $q->count()));
        $this->allow('hazards.view', false);
        $this->assertSame(0, $worklists->materialize($this->viewer, ['q' => 'HS-CANONICAL-SEARCH'], fn ($q): int => $q->count()));
    }

    public function test_filtered_hse_discovery_does_not_consider_unrelated_site_candidates(): void
    {
        $this->assertSame([], app(AlertWorklistQuery::class)->materialize($this->viewer,
            ['ids' => [$this->alert->id], 'site_id' => Site::factory()->create()->id, 'q' => 'HS-CANONICAL-SEARCH'],
            fn ($q): array => $q->pluck('control_room_alerts.id')->all()));
    }

    public function test_incident_search_count_and_page_do_not_match_denied_hse_reference(): void
    {
        $this->allow('hazards.view', false);
        $this->withoutMiddleware(HandleInertiaRequests::class);
        $this->actingAs($this->viewer)->get('/control-room/incidents?search=HS-CANONICAL-SEARCH')
            ->assertOk()->assertInertia(fn ($page) => $page->has('journeys.data', 0)->where('journeys.meta.total', 0));
    }

    public function test_alert_list_staff_picker_is_detached_inside_the_current_read(): void
    {
        $context = app(AlertWorklistQuery::class)->viewContextFor($this->viewer);
        $this->assertNotEmpty($context['staff']);
        foreach ($context['staff'] as $staff) {
            $this->assertIsArray($staff);
            $this->assertArrayHasKey('id', $staff);
        }
        $this->withoutMiddleware(HandleInertiaRequests::class);
        $this->actingAs($this->viewer)->get('/control-room/alerts')
            ->assertOk()->assertInertia(fn ($page) => $page->has('staff')->has('alerts.data', 1));
    }

    public function test_personal_queue_retains_independent_followups_and_rechecks_current_module_access(): void
    {
        $this->alert->updateQuietly(['assigned_to_user_id' => $this->viewer->id]);
        OperatorNote::create(['alert_id' => $this->alert->id, 'user_id' => $this->viewer->id,
            'type' => OperatorNote::TYPE_NOTE, 'purpose' => OperatorNote::PURPOSE_GENERAL,
            'content' => 'Independent follow-up', 'requires_followup' => true, 'followup_at' => now()->addDay()]);
        $this->allow('hazards.view', false);
        $this->withoutMiddleware(HandleInertiaRequests::class);
        $this->actingAs($this->viewer)->get('/control-room/my-tasks')->assertOk()
            ->assertInertia(fn ($page) => $page->has('my_alerts', 1)->where('stats.my_open', 1)
                ->where('my_alerts.0.summary', 'Workplace injury response')
                ->where('my_followups.0.content', 'Independent follow-up'));
        $this->viewer->load('permissionOverrides', 'roles.permissions');
        $this->allow('controlRoom.viewAny', false);
        $this->assertTrue($this->viewer->canDo('controlRoom.viewAny'));
        $this->get('/control-room/my-tasks')->assertForbidden();
    }

    public function test_escalation_note_search_keeps_exact_queue_filters_and_canonical_source_privacy(): void
    {
        $queue = TriageQueue::factory()->create(['is_active' => true]);
        $otherQueue = TriageQueue::factory()->create(['is_active' => true]);
        $this->alert->updateQuietly(['queue_id' => $queue->id]);
        $this->withoutMiddleware(HandleInertiaRequests::class);
        $this->actingAs($this->viewer)->get('/control-room/escalations?search=PRIVATE-COPIED-NOTE')->assertOk()
            ->assertInertia(fn ($page) => $page->has('worklist.data', 0)->where('worklist.total', 0));
        $this->alert->updateQuietly(['notes' => 'Canonical factual occurrence']);
        $this->get('/control-room/escalations?search=Canonical')->assertOk()
            ->assertInertia(fn ($page) => $page->has('worklist.data', 1)->where('worklist.total', 1));
        $this->get('/control-room/escalations?search=Canonical&queue_id='.$otherQueue->id)->assertOk()
            ->assertInertia(fn ($page) => $page->has('worklist.data', 0)->where('worklist.total', 0));
        $this->allow('hazards.view', false);
        $this->get('/control-room/escalations?search=Canonical')->assertOk()
            ->assertInertia(fn ($page) => $page->has('worklist.data', 0)->where('worklist.total', 0));
    }

    public function test_null_source_keys_cannot_make_unproven_copied_notes_searchable(): void
    {
        $queue = TriageQueue::factory()->create(['is_active' => true]);
        foreach (['workplace_injury_id', 'restraint_event_id'] as $sourceKey) {
            $alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
                'site_id' => $this->site->id, 'queue_id' => $queue->id, 'status' => ControlRoomAlert::STATUS_OPEN,
                'source' => 'manual', 'alert_type' => 'urgent response', 'client_id' => null,
                'notes' => 'PRIVATE-UNKNOWN-'.$sourceKey, 'context' => ['normalized_data' => [$sourceKey => null]],
            ]));
            $this->assertSame(0, app(AlertWorklistQuery::class)->materialize($this->viewer,
                ['ids' => [$alert->id], 'q' => 'PRIVATE-UNKNOWN-'.$sourceKey], fn ($query): int => $query->count()));
            $this->assertNoPrivateText(app(AlertWorklistPresenter::class)->present($alert, $this->viewer));
            $this->withoutMiddleware(HandleInertiaRequests::class);
            $this->actingAs($this->viewer)->get('/control-room/escalations?search=PRIVATE-UNKNOWN-'.$sourceKey)->assertOk()
                ->assertInertia(fn ($page) => $page->has('worklist.data', 0)->where('worklist.total', 0));
        }
    }

    public function test_same_desk_service_rechecks_source_and_module_authority_after_warm_read(): void
    {
        $desk = app(ControlRoomDeskService::class);
        $this->assertSame('Canonical factual occurrence', $desk->live($this->viewer)['worklist']['data'][0]['summary']);
        $this->allow('hazards.view', false);
        $this->assertNotSame('Canonical factual occurrence', $desk->live($this->viewer)['worklist']['data'][0]['summary']);
        foreach (['controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage'] as $key) {
            $this->allow($key, false);
        }
        $this->denied(fn () => $desk->live($this->viewer), 403);
    }

    public function test_saved_summary_is_reprojected_and_historical_workflow_is_retained(): void
    {
        $snapshot = ['alerts' => [['id' => $this->alert->id, 'summary' => 'PRIVATE-SAVED-MEDICAL',
            'summary_origin' => ['type' => 'injury', 'injury_id' => $this->injury->id], 'status' => 'open',
            'journey' => ['incident_access' => 'absent', 'incident_reference' => null,
                'health_safety_access' => 'readable', 'health_safety_reference' => 'HS-CANONICAL-SEARCH']]]];
        $projected = app(ControlRoomGovernanceReadService::class)->forSnapshotViewer($snapshot, $this->viewer);
        $this->assertSame('Canonical factual occurrence', $projected['alerts'][0]['summary']);
        $this->allow('hazards.view', false);
        $projected = app(ControlRoomGovernanceReadService::class)->forSnapshotViewer($snapshot, $this->viewer);
        $this->assertSame('Workplace injury response', $projected['alerts'][0]['summary']);
        $this->assertSame('open', $projected['alerts'][0]['status']);
        $this->assertNull($projected['alerts'][0]['journey']['health_safety_reference']);
        $this->assertNoPrivateText($projected);
    }

    public function test_missing_context_and_returned_live_builder_fail_visibly(): void
    {
        try {
            app(AlertWorklistQuery::class)->forUser($this->viewer);
            $this->fail('A builder needs an active consumer callback.');
        } catch (LogicException) {
            $this->addToAssertionCount(1);
        }
        $this->expectException(LogicException::class);
        app(AlertWorklistQuery::class)->materialize($this->viewer, [], fn ($query) => $query);
    }

    public function test_escaped_builder_cannot_execute_after_its_callback(): void
    {
        $escaped = null;
        app(AlertWorklistQuery::class)->materialize($this->viewer, [], function ($query) use (&$escaped): array {
            $escaped = $query;

            return [];
        });
        $this->expectException(LogicException::class);
        $escaped->count();
    }

    public function test_wrong_viewer_context_is_rejected_without_fallback(): void
    {
        $other = $this->staff(['controlRoom.viewAny']);
        $this->expectException(LogicException::class);
        HealthSafetyReadContext::within($this->viewer, ControlRoomGovernanceReadService::PERMISSIONS,
            fn ($context) => app(AlertWorklistQuery::class)->materialize($other, [], fn ($q): int => $q->count(), $context));
    }

    public function test_underprepared_context_is_rejected_without_granting_source_or_module_access(): void
    {
        $this->expectException(LogicException::class);
        HealthSafetyReadContext::within($this->viewer, ['controlRoom.viewAny'],
            fn ($context) => app(AlertWorklistQuery::class)->materialize($this->viewer, [], fn ($q): int => $q->count(), $context));
    }

    public function test_generic_notification_survives_source_denial_with_no_medical_payload(): void
    {
        $this->allow('hazards.view', false);
        $queue = TriageQueue::factory()->create(['assigned_users' => [$this->viewer->id], 'assigned_roles' => [], 'is_active' => true]);
        $this->alert->updateQuietly(['queue_id' => $queue->id]);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($this->alert, null, $queue)->sole();
        $this->assertNoPrivateText($row->notification_payload);
        $service->deliverStagedNotification($row);
        $this->assertSame('sent', $row->fresh()->status);
        $this->assertSame(1, $this->viewer->notifications()->count());
        $this->assertNoPrivateText($this->viewer->notifications()->sole()->data);
    }

    public function test_source_revision_changes_refresh_pending_purpose_proof_before_delivery(): void
    {
        $queue = TriageQueue::factory()->create(['assigned_users' => [$this->viewer->id], 'assigned_roles' => [], 'is_active' => true]);
        $this->alert->updateQuietly(['queue_id' => $queue->id]);
        $service = app(ControlRoomNotificationService::class);
        $row = $service->stageAlertNotifications($this->alert, null, $queue)->sole();
        $signature = $row->notification_payload['source_privacy_signature'];
        $this->injury->updateQuietly(['description' => 'Corrected factual occurrence']);
        $service->deliverStagedNotification($row);
        $this->assertSame('sent', $row->fresh()->status);
        $this->assertNotSame($signature, $row->fresh()->notification_payload['source_privacy_signature']);
        $this->assertSame(1, $this->viewer->notifications()->count());
    }

    public function test_eligibility_does_not_swallow_an_operation_failure_after_admission(): void
    {
        $this->expectException(HttpException::class);
        app(ControlRoomRecipientEligibilityService::class)->withCurrentEligible($this->alert, $this->viewer,
            fn () => abort(403, 'Actual operation failure.'));
    }

    public function test_unrelated_urgent_response_keeps_its_operational_text_and_actions(): void
    {
        $ordinary = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'source' => 'manual', 'alert_type' => 'urgent response',
            'client_id' => null, 'severity' => 'critical', 'status' => ControlRoomAlert::STATUS_OPEN,
            'context' => ['description' => 'Independent urgent operational response'], 'notes' => null,
        ]));
        $this->allow('hazards.view', false);
        $row = app(AlertWorklistPresenter::class)->present($ordinary, $this->viewer);
        $this->assertSame('Independent urgent operational response', $row['summary']);
        $this->assertTrue($row['actions']['can_acknowledge']);
        $this->assertSame($this->viewer->canDo('controlRoom.alerts.escalate'), $row['actions']['can_escalate']);
        $this->assertSame('absent', $row['journey']['health_safety_access']);
    }

    public function test_expired_context_cannot_be_reused_by_a_new_consumer(): void
    {
        $escaped = null;
        HealthSafetyReadContext::within($this->viewer, ControlRoomGovernanceReadService::PERMISSIONS,
            function ($context) use (&$escaped): array {
                $escaped = $context;

                return [];
            });
        $this->expectException(LogicException::class);
        app(AlertWorklistQuery::class)->materialize($this->viewer, [], fn ($q): int => $q->count(), $escaped);
    }

    public function test_returned_source_model_is_rejected_by_the_outer_read_boundary(): void
    {
        $this->expectException(LogicException::class);
        app(ControlRoomGovernanceReadService::class)->withCurrentViewer($this->viewer,
            fn ($current, $context) => $context->query(WorkplaceInjury::query())->find($this->injury->id));
    }

    public function test_final_source_tuple_race_retains_retry_then_sends_one_current_generic_notice(): void
    {
        $queue = TriageQueue::factory()->create(['assigned_users' => [$this->viewer->id], 'assigned_roles' => [], 'is_active' => true]);
        $this->alert->updateQuietly(['queue_id' => $queue->id]);
        $row = app(ControlRoomNotificationService::class)->stageAlertNotifications($this->alert, null, $queue)->sole();
        $replacementWorker = $this->staff([]);
        $injuryId = $this->injury->id;
        $replacementId = $replacementWorker->id;
        $change = fn () => DB::table('workplace_injuries')->where('id', $injuryId)->update(['user_id' => $replacementId]);
        $locks = new class($change) extends AuthorizationEvidenceLockService
        {
            public function __construct(private ?\Closure $change) {}

            public function lockForUserWithoutWaiting(User|int $user, array $permissionKeys): User
            {
                $functions = array_column(debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS), 'function');
                if ($this->change !== null && in_array('deliverStagedNotification', $functions, true)
                    && array_intersect(['authorizedRecipients', 'stageAlertNotifications', 'currentNotificationSnapshot'], $functions) === []) {
                    $change = $this->change;
                    $this->change = null;
                    $change();
                }

                return parent::lockForUserWithoutWaiting($user, $permissionKeys);
            }
        };
        app()->instance(AuthorizationEvidenceLockService::class, $locks);
        app()->forgetInstance(ControlRoomRecipientEligibilityService::class);
        app()->forgetInstance(ControlRoomNotificationService::class);
        $service = app(ControlRoomNotificationService::class);
        $service->deliverStagedNotification($row);
        $this->assertSame('failed', $row->fresh()->status);
        $this->assertSame(1, $row->fresh()->retry_count);
        $this->assertSame(0, $this->viewer->notifications()->count());
        $this->assertNull($row->fresh()->superseded_at);
        $service->deliverStagedNotification($row->fresh());
        $this->assertSame('sent', $row->fresh()->status);
        $this->assertSame(1, $this->viewer->notifications()->count());
        $this->assertNoPrivateText($this->viewer->notifications()->sole()->data);
    }

    public function test_legacy_notification_log_text_is_masked_and_independent_conversation_is_retained(): void
    {
        foreach (['notification' => 'PRIVATE-LEGACY-NOTICE', 'general' => 'Independent operational communication'] as $purpose => $content) {
            Communication::query()->create(['alert_id' => $this->alert->id, 'channel' => 'in_app', 'direction' => 'outbound',
                'purpose' => $purpose, 'status' => 'sent', 'target_user_id' => $this->viewer->id, 'content' => $content]);
        }
        $workspace = app(AlertWorkspaceService::class)->build($this->viewer, $this->alert->id);
        $rows = collect($workspace['communications'])->keyBy('purpose');
        $this->assertStringNotContainsString('PRIVATE-', $rows['notification']['content']);
        $this->assertSame('Independent operational communication', $rows['general']['content']);
    }

    public function test_supplied_batch_record_cannot_cross_alert_identity_inside_the_same_context(): void
    {
        $ordinary = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'source' => 'manual', 'alert_type' => 'urgent response', 'client_id' => null,
            'context' => ['description' => 'Separate operational work'],
        ]));
        $row = app(ControlRoomGovernanceReadService::class)->withCurrentViewer($this->viewer,
            function ($current, $context) use ($ordinary): array {
                $borrowed = app(AlertWorklistPresenter::class)->governanceForAlerts([$this->alert], $current, $context)->get($this->alert->id);

                return app(AlertWorklistPresenter::class)->present($ordinary, $current, governance: $borrowed, readContext: $context);
            });
        $this->assertSame($ordinary->id, $row['id']);
        $this->assertSame('Separate operational work', $row['summary']);
        $this->assertNull($row['journey']['health_safety_reference']);
        $this->assertSame('absent', $row['journey']['health_safety_access']);
    }

    private function governance(): array
    {
        return app(ControlRoomGovernanceReadService::class)->forAlerts([$this->alert], $this->viewer)->get($this->alert->id);
    }

    private function version(): WorkplaceInjurySourceVersion
    {
        $this->injury->updateQuietly(['source_schema_version' => 1, 'source_revision' => 1]);
        $facts = InjuryAccessService::factualSnapshot($this->injury->fresh());
        $private = ['scope' => 'medical', 'after' => ['notes' => 'PRIVATE-VERSION-CONTENT']];

        return WorkplaceInjurySourceVersion::create([
            'workplace_injury_id' => $this->injury->id, 'aggregate_revision' => 1, 'source_schema_version' => 1,
            'source_type' => 'injury', 'source_id' => $this->injury->id, 'command' => 'record_injury',
            'worker_id' => $this->worker->id, 'site_id' => $this->site->id,
            'recorded_by' => $this->viewer->id, 'recorder_snapshot' => ['id' => $this->viewer->id],
            'factual_content' => $facts, 'factual_digest' => RestraintCommandValues::digest($facts),
            'content' => $private, 'content_digest' => RestraintCommandValues::digest($private), 'recorded_at' => now()->utc(),
        ]);
    }

    private function staff(array $permissions): User
    {
        $user = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        HrEmployeeProfile::factory()->create(['user_id' => $user->id, 'primary_site_id' => $this->site->id,
            'secondary_site_ids' => [], 'is_active' => true, 'start_date' => now('Pacific/Auckland')->subYear()->toDateString(), 'end_date' => null]);
        foreach ($permissions as $key) {
            $user->permissionOverrides()->attach(Permission::where('key', $key)->sole(), ['allowed' => true]);
        }

        return $user;
    }

    private function allow(string $key, bool $allowed): void
    {
        $this->viewer->permissionOverrides()->syncWithoutDetaching([Permission::where('key', $key)->sole()->id => ['allowed' => $allowed]]);
    }

    private function assertNoPrivateText(array $value): void
    {
        $this->assertStringNotContainsString('PRIVATE-', json_encode($value, JSON_THROW_ON_ERROR));
    }

    private function denied(callable $read, int $status): void
    {
        try {
            $read();
            $this->fail('Current module admission must deny this read.');
        } catch (HttpExceptionInterface $error) {
            $this->assertSame($status, $error->getStatusCode());
        }
    }
}
