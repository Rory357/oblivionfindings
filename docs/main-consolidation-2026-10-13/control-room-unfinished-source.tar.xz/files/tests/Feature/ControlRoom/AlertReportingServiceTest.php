<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Models\Client;
use App\Models\ClientIncident;
use App\Models\ControlRoom\AlertReportingDecision;
use App\Models\ControlRoom\Signal;
use App\Models\ControlRoom\SignalSource;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\MedicationError;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use App\Models\WorkplaceInjury;
use App\Services\ControlRoom\AlertReportingPolicy;
use App\Services\ControlRoom\AlertReportingService;
use App\Services\Medication\MedicationSignalService;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Tests\TestCase;

class AlertReportingServiceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->seed(RbacSeeder::class);
    }

    public function test_unknown_technical_and_staffing_sources_do_not_invent_a_mandatory_incident(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        foreach (['device', 'shift_operations', 'legacy_unknown'] as $source) {
            $alert = $this->alert($site, $operator, ['source' => $source]);
            $projection = app(AlertReportingService::class)->present($alert, $operator);
            $this->assertSame('decision_needed', $projection['state']);
            $this->assertNull($projection['basis']['policy']);
            $this->assertTrue($projection['canDecide']);
            $this->assertNull(app(AlertReportingService::class)->resolutionRequirement($alert));
        }
    }

    public function test_a_correlated_canonical_medication_error_retains_its_actual_requirement_after_a_person_moves(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator, ['client_id' => Client::factory()->create(['site_id' => $site->id])->id]);
        $error = $this->medicationSource($alert, $operator, true);
        $alert->client->update(['site_id' => Site::factory()->create()->id]);
        $basis = app(AlertReportingPolicy::class)->forAlert($alert);
        $this->assertTrue($basis['required']);
        $this->assertFalse($basis['canDecide']);
        $this->assertSame('MedicationErrorWorkflow::incidentRequired', $basis['policy']['reference']);
        $this->assertNull($basis['policy']['version']);
        $this->assertNotNull(app(AlertReportingService::class)->resolutionRequirement($alert));
        $this->assertNull($error->client_incident_id);
    }

    public function test_source_context_without_a_canonical_medication_record_is_not_reporting_policy(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator, ['context' => ['normalized_data' => [
            'medication_error_id' => 12345, 'incident_required' => true, 'policy_version' => 'claimed',
        ]]]);
        $basis = app(AlertReportingPolicy::class)->forAlert($alert);
        $this->assertFalse($basis['required']);
        $this->assertNull($basis['policy']);
    }

    public function test_an_unrelated_submitted_incident_does_not_satisfy_the_medication_sources_report(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator, ['client_id' => Client::factory()->create(['site_id' => $site->id])->id]);
        $error = $this->medicationSource($alert, $operator);
        $unrelated = ClientIncident::withoutEvents(fn () => ClientIncident::factory()->create([
            'client_id' => $alert->client_id, 'site_id' => $site->id, 'reported_by' => $operator->id,
            'status' => 'submitted', 'control_room_alert_id' => $alert->id,
        ]));
        $reporting = app(AlertReportingService::class);
        $this->assertSame('linked', $reporting->present($alert, $operator)['state']);
        $this->assertNotNull($reporting->resolutionRequirement($alert));
        $error->update(['client_incident_id' => $unrelated->id]);
        $this->assertNull($reporting->resolutionRequirement($alert));
        $unrelated->update(['status' => 'draft']);
        $this->assertNotNull($reporting->resolutionRequirement($alert));
    }

    public function test_mandatory_reporting_cannot_be_waived_by_an_operator_command(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator, ['client_id' => Client::factory()->create(['site_id' => $site->id])->id]);
        $this->medicationSource($alert, $operator);
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), $this->command())->assertStatus(422);
        $this->assertDatabaseCount('control_room_alert_reporting_decisions', 0);
    }

    public function test_identical_replay_returns_the_original_receipt_after_a_later_revision(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator);
        $first = $this->command();
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), $first)
            ->assertOk()->assertJsonPath('decision.revision', 1)->assertJsonPath('decision.state', 'not_required');
        $this->postJson($this->decisionUrl($alert), $this->command('required', 1))
            ->assertOk()->assertJsonPath('decision.revision', 2)->assertJsonPath('reporting.state', 'required');
        $this->postJson($this->decisionUrl($alert), $first)->assertOk()
            ->assertJsonPath('decision.revision', 1)->assertJsonPath('decision.state', 'not_required')
            ->assertJsonPath('reporting.revision', 2)->assertJsonPath('reporting.state', 'required');
        $this->assertDatabaseCount('control_room_alert_reporting_decisions', 2);
        $this->assertSame($operator->id, AlertReportingDecision::query()->firstOrFail()->actor_user_id);
        $this->assertDatabaseHas('audit_logs', ['action' => 'controlRoom.alert.reportingDecided']);
    }

    public function test_conflicting_payload_and_a_fresh_stale_revision_are_rejected(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator);
        $command = $this->command();
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), $command)->assertOk();
        $this->postJson($this->decisionUrl($alert), [...$command, 'reason' => 'A conflicting basis'])->assertStatus(409);
        $this->postJson($this->decisionUrl($alert), $this->command('required', 0))->assertStatus(409);
        $this->assertDatabaseCount('control_room_alert_reporting_decisions', 1);
    }

    public function test_reader_privacy_and_nonempty_write_reason_are_independent(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $reader = $this->viewer($site, ['controlRoom.alerts.view']);
        $alert = $this->alert($site, $operator);
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), [...$this->command(), 'reason' => '   '])->assertStatus(422);
        $command = $this->command();
        $this->postJson($this->decisionUrl($alert), $command)->assertOk();
        $projection = app(AlertReportingService::class)->present($alert, $reader);
        $this->assertSame('not_required', $projection['state']);
        $this->assertNull($projection['decision']['reason']);
        $this->assertNull($projection['decision']['actor']);
        $this->assertFalse($projection['canDecide']);
        $this->assertSame($command['reason'], app(AlertReportingService::class)->present($alert, $operator)['decision']['reason']);
    }

    public function test_revoked_access_and_another_site_cannot_write_or_replay(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $other = $this->viewer(Site::factory()->create(), ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator);
        $command = $this->command();
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), $command)->assertOk();
        $this->actingAs($other)->postJson($this->decisionUrl($alert), $this->command())->assertForbidden();
        $operator->permissionOverrides()->sync([]);
        $this->actingAs($operator->fresh())->postJson($this->decisionUrl($alert), $command)->assertForbidden();
        $this->assertDatabaseCount('control_room_alert_reporting_decisions', 1);
    }

    public function test_a_changed_source_invalidates_a_previous_decision_without_losing_its_attribution(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator);
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), $this->command())->assertOk();
        $alert->update(['source' => 'shift_operations']);
        $projection = app(AlertReportingService::class)->present($alert, $operator);
        $this->assertSame('decision_needed', $projection['state']);
        $this->assertSame(1, $projection['revision']);
        $this->assertSame($operator->id, $projection['decision']['actor']['id']);
        $this->assertNull(app(AlertReportingService::class)->resolutionRequirement($alert));
    }

    public function test_staff_injury_reporting_uses_its_exact_canonical_staff_report_and_event_without_a_supported_person(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $injury = WorkplaceInjury::withoutEvents(fn () => WorkplaceInjury::factory()->create([
            'user_id' => $operator->id, 'site_id' => $site->id, 'status' => 'reported', 'created_by' => $operator->id,
        ]));
        $alert = $this->alert($site, $operator, ['client_id' => null, 'source' => 'operations',
            'alert_type' => 'operations.workplace_injury', 'context' => ['workplace_injury_id' => $injury->id]]);
        $service = app(AlertReportingService::class);
        $this->assertSame('required', $service->present($alert, $operator)['state']);
        $this->assertNotNull($service->resolutionRequirement($alert));
        $event = HsEvent::factory()->create(['source_type' => WorkplaceInjury::class, 'source_id' => $injury->id,
            'client_id' => null, 'staff_id' => $operator->id, 'site_id' => $site->id,
            'control_room_alert_id' => $alert->id, 'status' => HsEvent::STATUS_OPEN,
            'handover_status' => HsEvent::HANDOVER_AWAITING_ACCEPTANCE]);

        $projection = $service->present($alert, $operator);
        $this->assertSame('linked', $projection['state']);
        $this->assertSame('workplace_injury_report_required', $projection['basis']['code']);
        $this->assertFalse($projection['canCreate']);
        $this->assertFalse($projection['canDecide']);
        $this->assertSame(['kind' => 'workplace_injury', 'label' => 'Staff injury report',
            'access' => 'restricted', 'href' => null, 'recorded' => true], $projection['target']);
        $this->assertNull($service->resolutionRequirement($alert));
        $this->assertSame(HsEvent::HANDOVER_AWAITING_ACCEPTANCE, $event->fresh()->handover_status);
        $this->assertSame(HsEvent::STATUS_OPEN, $event->fresh()->status);
        $injury->updateQuietly(['status' => 'return_to_work']);
        $this->assertNull($service->resolutionRequirement($alert));
        $injury->updateQuietly(['status' => 'recovered']);
        $this->assertNull($service->resolutionRequirement($alert));
        $this->assertSame(0, ClientIncident::query()->where('control_room_alert_id', $alert->id)->count());
    }

    public function test_a_different_staff_report_at_the_same_site_cannot_satisfy_the_required_source(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $injuries = WorkplaceInjury::withoutEvents(fn () => WorkplaceInjury::factory()->count(2)->create([
            'user_id' => $operator->id, 'site_id' => $site->id, 'status' => 'reported', 'created_by' => $operator->id,
        ]));
        $alert = $this->alert($site, $operator, ['client_id' => null, 'source' => 'operations',
            'alert_type' => 'operations.workplace_injury', 'context' => ['workplace_injury_id' => $injuries[0]->id]]);
        HsEvent::factory()->create(['source_type' => WorkplaceInjury::class, 'source_id' => $injuries[1]->id,
            'client_id' => null, 'staff_id' => $operator->id, 'site_id' => $site->id, 'control_room_alert_id' => $alert->id]);

        $this->assertSame('required', app(AlertReportingService::class)->present($alert, $operator)['state']);
        $this->assertNotNull(app(AlertReportingService::class)->resolutionRequirement($alert));
    }

    public function test_human_required_reporting_without_a_destination_is_retained_as_a_routing_issue(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator, ['client_id' => null]);
        $this->actingAs($operator)->postJson($this->decisionUrl($alert), $this->command('required'))->assertOk();
        $projection = app(AlertReportingService::class)->present($alert, $operator);

        $this->assertSame('required', $projection['state']);
        $this->assertSame('reporting_route_unavailable', $projection['basis']['code']);
        $this->assertFalse($projection['canCreate']);
        $this->assertNull($projection['target']);
        $this->assertNotNull(app(AlertReportingService::class)->resolutionRequirement($alert));
        $this->assertDatabaseCount('control_room_alert_reporting_decisions', 1);
    }

    public function test_reporting_batches_do_not_add_queries_per_alert(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alerts = ControlRoomAlert::factory()->count(80)->create(['site_id' => $site->id, 'client_id' => null,
            'source' => 'device', 'alert_type' => 'Device Offline', 'context' => []]);
        $operator->load(['permissionOverrides', 'roles.permissions', 'hrEmployeeProfile']);
        $service = app(AlertReportingService::class);
        DB::enableQueryLog();
        DB::flushQueryLog();
        $service->forAlerts($alerts->take(3), $operator);
        $smallCount = count(DB::getQueryLog());
        DB::flushQueryLog();
        $rows = $service->forAlerts($alerts, $operator);
        $largeQueries = DB::getQueryLog();
        DB::disableQueryLog();

        $this->assertCount(80, $rows);
        $this->assertLessThanOrEqual($smallCount + 2, count($largeQueries), collect($largeQueries)->pluck('query')->implode("\n"));
        $this->assertLessThan(50, count($largeQueries));
        $this->assertSame(['decision_needed'], $rows->pluck('state')->unique()->values()->all());
    }

    public function test_a_receipt_cannot_be_rewritten_or_deleted_through_the_model(): void
    {
        $site = Site::factory()->create();
        $operator = $this->viewer($site, ['controlRoom.alerts.manage']);
        $alert = $this->alert($site, $operator);
        $command = $this->command();
        $receipt = app(AlertReportingService::class)->decide($alert, $operator, $command);
        foreach (['update', 'delete'] as $operation) {
            try {
                $operation === 'update' ? $receipt->update(['reason' => 'Replacement']) : $receipt->delete();
                $this->fail('Immutable reporting history accepted '.$operation);
            } catch (\DomainException $exception) {
                $this->assertStringContainsString($operation === 'update' ? 'immutable' : 'cannot be deleted', $exception->getMessage());
            }
        }
        $this->assertSame($command['reason'], $receipt->fresh()->reason);
        $this->assertDatabaseCount('control_room_alert_reporting_decisions', 1);
    }

    private function viewer(Site $site, array $permissions): User
    {
        $viewer = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        $viewer->roles()->sync([Role::query()->where('name', 'support_worker')->firstOrFail()->id]);
        $viewer->permissionOverrides()->sync(Permission::query()->whereIn('key', $permissions)->pluck('id')
            ->mapWithKeys(fn ($id) => [$id => ['allowed' => true]]));
        HrEmployeeProfile::factory()->create([
            'user_id' => $viewer->id, 'position_role' => 'support_worker', 'primary_site_id' => $site->id,
            'secondary_site_ids' => [], 'start_date' => today()->subYear(), 'is_active' => true,
            'created_by' => $viewer->id, 'updated_by' => $viewer->id,
        ]);

        return $viewer;
    }

    private function alert(Site $site, User $operator, array $attributes = []): ControlRoomAlert
    {
        return ControlRoomAlert::factory()->create([
            'site_id' => $site->id, 'created_by_user_id' => $operator->id,
            'source' => 'device', 'alert_type' => 'Device Offline', 'context' => [], ...$attributes,
        ]);
    }

    private function medicationSource(ControlRoomAlert $alert, User $operator, bool $correlated = false): MedicationError
    {
        $error = MedicationError::query()->create([
            'client_id' => $alert->client_id, 'reported_by' => $operator->id, 'reported_at' => now(),
            'report_source' => 'more_than_ordered', 'reached_client' => 'yes', 'harm_level' => 'severe',
            'severity' => 'critical', 'error_type' => 'wrong_dose', 'description' => 'Source facts', 'status' => 'reported',
        ]);
        $source = SignalSource::query()->firstOrCreate(['slug' => 'medication'], [
            'name' => 'Medication / eMAR', 'vendor' => 'internal', 'status' => 'active',
        ]);
        $signal = Signal::query()->create([
            'signal_source_id' => $source->id, 'signal_type_code' => MedicationSignalService::TYPE_ERROR,
            'client_id' => $alert->client_id, 'site_id' => $alert->site_id, 'occurred_at' => now(),
            'idempotency_key' => hash('sha256', (string) Str::uuid()), 'status' => 'processed',
            'alert_id' => $correlated ? null : $alert->id, 'correlated_alert_id' => $correlated ? $alert->id : null,
            'payload' => [], 'normalized_data' => ['medication_error_id' => $error->id],
        ]);
        if (! $correlated) {
            $alert->update(['origin_signal_id' => $signal->id]);
        }

        return $error;
    }

    private function command(string $state = 'not_required', int $revision = 0): array
    {
        return ['state' => $state, 'reason' => 'The source response was reviewed.',
            'expected_revision' => $revision, 'command_id' => (string) Str::uuid()];
    }

    private function decisionUrl(ControlRoomAlert $alert): string
    {
        return '/control-room/alerts/'.$alert->id.'/reporting-decision';
    }
}
