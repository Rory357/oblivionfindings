import { CommandCentrePage } from '@/components/command-centre/command-centre-page';
import PageShell from '@/components/page-shell';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import AppLayout from '@/layouts/app-layout';
import { formatDateOnly, formatRelative } from '@/lib/datetime';
import { Head, router, usePage } from '@inertiajs/react';
import {
    Activity,
    TrendingUp,
    Users,
    Wifi,
    WifiOff,
} from 'lucide-react';
import { useEffect, useRef } from 'react';
import {
    Area,
    AreaChart,
    Bar,
    BarChart,
    CartesianGrid,
    Cell,
    Pie,
    PieChart,
    ResponsiveContainer,
    Tooltip,
    XAxis,
    YAxis,
} from 'recharts';

interface Props {
    period: string;
    kpis: {
        avg_acknowledge_minutes: number | null;
        avg_resolution_hours: number | null;
        sla_compliance_pct: number | null;
        open_alerts: number;
        alerts_today: number;
        today_date: string;
    };
    volume_trend: { label: string; count: number }[];
    top_sources: { name: string; count: number }[];
    top_alert_types: { name: string; count: number }[];
    severity_distribution: Record<string, number>;
    operator_performance: {
        name: string;
        alerts_handled: number;
        avg_response_minutes: number | null;
    }[];
    shift_comparison: {
        name: string;
        duration_hours: number;
        alerts_created: number;
        alerts_resolved: number;
        alerts_escalated: number;
    }[];
    signal_sources: {
        name: string;
        status: string;
        last_heartbeat_at: string | null;
        signal_count_24h: number;
        is_healthy: boolean;
    }[];
}

const SEVERITY_COLORS: Record<string, string> = {
    critical: 'var(--status-critical)',
    high: 'var(--status-warning)',
    medium: 'var(--status-warning)',
    low: 'var(--status-info)',
};

const CHART_COLORS = [
    'var(--chart-1)',
    'var(--chart-2)',
    'var(--chart-3)',
    'var(--chart-4)',
    'var(--chart-5)',
    'var(--chart-1)',
    'var(--chart-2)',
    'var(--chart-3)',
    'var(--chart-4)',
    'var(--chart-5)',
];

const breadcrumbs = [
    { title: 'Home', href: '/dashboard' },
    { title: 'Control Room', href: '/control-room' },
    { title: 'Live Statistics', href: '#' },
];

export default function ControlRoomStats({
    period,
    kpis,
    volume_trend,
    top_sources,
    top_alert_types,
    severity_distribution,
    operator_performance,
    shift_comparison,
    signal_sources,
}: Props) {
    const currentQuery = new URL(usePage().url, 'https://control-room.invalid').searchParams;
    const sectionHref = (section: string) => `/control-room/stats?${currentQuery.toString()}#${section}`;
    // Auto-refresh every 30 seconds
    const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

    useEffect(() => {
        timerRef.current = setInterval(() => {
            router.reload({
                only: [
                    'kpis',
                    'volume_trend',
                    'top_sources',
                    'top_alert_types',
                    'severity_distribution',
                    'operator_performance',
                    'shift_comparison',
                    'signal_sources',
                ],
            });
        }, 30_000);
        return () => {
            if (timerRef.current) clearInterval(timerRef.current);
        };
    }, []);

    const handlePeriodChange = (newPeriod: string) => {
        const query = new URLSearchParams(currentQuery);
        query.set('period', newPeriod);
        query.delete('page');
        router.get(
            `/control-room/stats?${query.toString()}`,
            {},
            { preserveState: true, preserveScroll: true },
        );
    };

    // Prepare severity pie data
    const severityPieData = Object.entries(severity_distribution).map(
        ([name, value]) => ({
            name: name.charAt(0).toUpperCase() + name.slice(1),
            value,
            color: SEVERITY_COLORS[name] ?? 'var(--muted-foreground)',
        }),
    );

    // Max for operator bar visualization
    const maxOperatorAlerts = Math.max(
        ...operator_performance.map((o) => o.alerts_handled),
        1,
    );

    const periodLabel =
        period === '24h'
            ? 'Last 24 Hours'
            : period === '7d'
              ? 'Last 7 Days'
              : 'Last 30 Days';

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Live Statistics - Control Room" />
            <PageShell>
                <CommandCentrePage
                    variant="compact"
                    current="/control-room/stats"
                    icon={TrendingUp}
                    title="Operational analytics"
                    description="Review Control Room workload, SLA performance, trends, and service health away from the live desk."
                    status="Analytics workspace"
                    freshness={periodLabel}
                    metricGroups={[{
                        title: 'Recorded response performance', icon: TrendingUp, metrics: [
                            { label: 'Average acknowledgement', value: kpis.avg_acknowledge_minutes === null ? '—' : `${kpis.avg_acknowledge_minutes}m`, caption: kpis.avg_acknowledge_minutes === null ? 'No measured timings' : 'recorded human acknowledgement', tone: 'neutral', href: sectionHref('stats-timings') },
                            { label: 'Average resolution', value: kpis.avg_resolution_hours === null ? '—' : `${kpis.avg_resolution_hours}h`, caption: kpis.avg_resolution_hours === null ? 'No measured timings' : 'recorded response timings', tone: 'neutral', href: sectionHref('stats-timings') },
                            { label: 'Response targets met', value: kpis.sla_compliance_pct === null ? '—' : `${kpis.sla_compliance_pct}%`, caption: kpis.sla_compliance_pct === null ? 'No assessed targets' : 'assessed targets in this period', tone: 'success', href: sectionHref('stats-timings') },
                            { label: 'Awaiting outcome', value: String(kpis.open_alerts), caption: 'current responses across all dates', tone: kpis.open_alerts > 0 ? 'warning' : 'success', href: sectionHref('stats-current-work') },
                            { label: 'Raised today', value: String(kpis.alerts_today), caption: formatDateOnly(kpis.today_date), tone: 'neutral', href: sectionHref('stats-current-work') },
                        ],
                    }]}
                    filters={
                        <div className="flex items-center gap-3">
                            <div className="flex items-center gap-1.5 text-xs text-primary-foreground/80">
                                <span className="relative flex h-2 w-2">
                                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-status-success opacity-75" />
                                    <span className="relative inline-flex h-2 w-2 rounded-full bg-status-success" />
                                </span>
                                Auto-refreshing
                            </div>
                            <Select
                                value={period}
                                onValueChange={handlePeriodChange}
                            >
                                <SelectTrigger aria-label="Statistics period" className="w-[160px] border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground backdrop-blur-sm hover:bg-primary-foreground/20">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="24h">
                                        Last 24 Hours
                                    </SelectItem>
                                    <SelectItem value="7d">
                                        Last 7 Days
                                    </SelectItem>
                                    <SelectItem value="30d">
                                        Last 30 Days
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                        </div>
                    }
                >
                    <div className="grid gap-4 lg:grid-cols-2">
                        <Card id="stats-timings">
                            <CardHeader><CardTitle>Recorded timings and response targets</CardTitle></CardHeader>
                            <CardContent className="space-y-2 text-sm text-muted-foreground">
                                <p>Average human acknowledgement: {kpis.avg_acknowledge_minutes === null ? 'Not measured' : `${kpis.avg_acknowledge_minutes} minutes`}.</p>
                                <p>Average recorded resolution: {kpis.avg_resolution_hours === null ? 'Not measured' : `${kpis.avg_resolution_hours} hours`}.</p>
                                <p>Response targets met: {kpis.sla_compliance_pct === null ? 'No assessed targets' : `${kpis.sla_compliance_pct}%`}. These figures use recorded, assessed response cycles in the selected period. Missing timings remain unmeasured.</p>
                            </CardContent>
                        </Card>
                        <Card id="stats-current-work">
                            <CardHeader><CardTitle>Current permitted activity</CardTitle></CardHeader>
                            <CardContent className="space-y-2 text-sm text-muted-foreground">
                                <p>{kpis.open_alerts} current responses await an operational outcome, including work raised before the selected period.</p>
                                <p>{kpis.alerts_today} responses were raised today ({formatDateOnly(kpis.today_date)} in Auckland). This daily figure is independent of the selected analytics period.</p>
                                <p>Operational outcomes, human acknowledgement and source reporting or safety governance completion are separate facts.</p>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Charts Grid */}
                    <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-2">
                        {/* Alert Volume Trend */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-base">
                                    Alert Volume Trend
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="h-[280px]">
                                    <ResponsiveContainer
                                        width="100%"
                                        height="100%"
                                    >
                                        <AreaChart data={volume_trend}>
                                            <defs>
                                                <linearGradient
                                                    id="volumeGradient"
                                                    x1="0"
                                                    y1="0"
                                                    x2="0"
                                                    y2="1"
                                                >
                                                    <stop
                                                        offset="5%"
                                                        stopColor="var(--chart-1)"
                                                        stopOpacity={0.3}
                                                    />
                                                    <stop
                                                        offset="95%"
                                                        stopColor="var(--chart-1)"
                                                        stopOpacity={0}
                                                    />
                                                </linearGradient>
                                            </defs>
                                            <CartesianGrid
                                                strokeDasharray="3 3"
                                                className="stroke-muted"
                                            />
                                            <XAxis
                                                dataKey="label"
                                                tick={{ fontSize: 11 }}
                                                interval="preserveStartEnd"
                                                className="text-muted-foreground"
                                            />
                                            <YAxis
                                                tick={{ fontSize: 11 }}
                                                allowDecimals={false}
                                                className="text-muted-foreground"
                                            />
                                            <Tooltip
                                                contentStyle={{
                                                    backgroundColor:
                                                        'var(--card)',
                                                    border: '1px solid var(--border)',
                                                    borderRadius: '8px',
                                                    fontSize: '12px',
                                                }}
                                            />
                                            <Area
                                                type="monotone"
                                                dataKey="count"
                                                stroke="var(--chart-1)"
                                                strokeWidth={2}
                                                fill="url(#volumeGradient)"
                                                name="Alerts"
                                            />
                                        </AreaChart>
                                    </ResponsiveContainer>
                                </div>
                            </CardContent>
                        </Card>

                        {/* Severity Distribution */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-base">
                                    Severity Distribution (Unresolved)
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="h-[280px]">
                                    {severityPieData.length === 0 ? (
                                        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                                            No unresolved alerts
                                        </div>
                                    ) : (
                                        <ResponsiveContainer
                                            width="100%"
                                            height="100%"
                                        >
                                            <PieChart>
                                                <Pie
                                                    data={severityPieData}
                                                    cx="50%"
                                                    cy="50%"
                                                    innerRadius={60}
                                                    outerRadius={100}
                                                    paddingAngle={3}
                                                    dataKey="value"
                                                    nameKey="name"
                                                    label={({ name, value }) =>
                                                        `${name}: ${value}`
                                                    }
                                                >
                                                    {severityPieData.map(
                                                        (entry, index) => (
                                                            <Cell
                                                                key={index}
                                                                fill={
                                                                    entry.color
                                                                }
                                                            />
                                                        ),
                                                    )}
                                                </Pie>
                                                <Tooltip
                                                    contentStyle={{
                                                        backgroundColor:
                                                            'var(--card)',
                                                        border: '1px solid var(--border)',
                                                        borderRadius: '8px',
                                                        fontSize: '12px',
                                                    }}
                                                />
                                            </PieChart>
                                        </ResponsiveContainer>
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Top Sources */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-base">
                                    Top Sources ({periodLabel})
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="h-[280px]">
                                    {top_sources.length === 0 ? (
                                        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                                            No data for this period
                                        </div>
                                    ) : (
                                        <ResponsiveContainer
                                            width="100%"
                                            height="100%"
                                        >
                                            <BarChart
                                                data={top_sources}
                                                layout="vertical"
                                                margin={{ left: 80 }}
                                            >
                                                <CartesianGrid
                                                    strokeDasharray="3 3"
                                                    className="stroke-muted"
                                                />
                                                <XAxis
                                                    type="number"
                                                    tick={{ fontSize: 11 }}
                                                    allowDecimals={false}
                                                />
                                                <YAxis
                                                    type="category"
                                                    dataKey="name"
                                                    tick={{ fontSize: 11 }}
                                                    width={75}
                                                />
                                                <Tooltip
                                                    contentStyle={{
                                                        backgroundColor:
                                                            'var(--card)',
                                                        border: '1px solid var(--border)',
                                                        borderRadius: '8px',
                                                        fontSize: '12px',
                                                    }}
                                                />
                                                <Bar
                                                    dataKey="count"
                                                    fill="var(--chart-2)"
                                                    radius={[0, 4, 4, 0]}
                                                    name="Alerts"
                                                />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Top Alert Types */}
                        <Card>
                            <CardHeader>
                                <CardTitle className="text-base">
                                    Top Alert Types ({periodLabel})
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="h-[280px]">
                                    {top_alert_types.length === 0 ? (
                                        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                                            No data for this period
                                        </div>
                                    ) : (
                                        <ResponsiveContainer
                                            width="100%"
                                            height="100%"
                                        >
                                            <BarChart
                                                data={top_alert_types}
                                                layout="vertical"
                                                margin={{ left: 80 }}
                                            >
                                                <CartesianGrid
                                                    strokeDasharray="3 3"
                                                    className="stroke-muted"
                                                />
                                                <XAxis
                                                    type="number"
                                                    tick={{ fontSize: 11 }}
                                                    allowDecimals={false}
                                                />
                                                <YAxis
                                                    type="category"
                                                    dataKey="name"
                                                    tick={{ fontSize: 11 }}
                                                    width={75}
                                                />
                                                <Tooltip
                                                    contentStyle={{
                                                        backgroundColor:
                                                            'var(--card)',
                                                        border: '1px solid var(--border)',
                                                        borderRadius: '8px',
                                                        fontSize: '12px',
                                                    }}
                                                />
                                                <Bar
                                                    dataKey="count"
                                                    fill="var(--chart-3)"
                                                    radius={[0, 4, 4, 0]}
                                                    name="Alerts"
                                                />
                                            </BarChart>
                                        </ResponsiveContainer>
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Operator Performance */}
                    <div className="mt-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Users className="h-4 w-4" />
                                    Operator Performance ({periodLabel})
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                {operator_performance.length === 0 ? (
                                    <p className="text-sm text-muted-foreground">
                                        No operator data for this period.
                                    </p>
                                ) : (
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="border-b text-left text-muted-foreground">
                                                    <th className="pr-4 pb-3 font-medium">
                                                        Operator
                                                    </th>
                                                    <th className="pr-4 pb-3 text-right font-medium">
                                                        Acknowledgements
                                                    </th>
                                                    <th className="pr-4 pb-3 text-right font-medium">
                                                        Average acknowledgement
                                                    </th>
                                                    <th className="hidden pb-3 font-medium sm:table-cell">
                                                        Volume
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {operator_performance.map(
                                                    (op, i) => (
                                                        <tr
                                                            key={i}
                                                            className="border-b last:border-0"
                                                        >
                                                            <td className="py-3 pr-4 font-medium">
                                                                {op.name}
                                                            </td>
                                                            <td className="py-3 pr-4 text-right">
                                                                {
                                                                    op.alerts_handled
                                                                }
                                                            </td>
                                                            <td className="py-3 pr-4 text-right">
                                                                {op.avg_response_minutes !==
                                                                null
                                                                    ? `${op.avg_response_minutes}m`
                                                                    : '-'}
                                                            </td>
                                                            <td className="hidden py-3 sm:table-cell">
                                                                <div className="h-2 w-full max-w-[200px] rounded-full bg-muted">
                                                                    <div
                                                                        className="h-2 rounded-full bg-primary"
                                                                        style={{
                                                                            width: `${(op.alerts_handled / maxOperatorAlerts) * 100}%`,
                                                                        }}
                                                                    />
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ),
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Shift Comparison */}
                    <div className="mt-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Activity className="h-4 w-4" />
                                    Shift Comparison (Last 5 Completed)
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                {shift_comparison.length === 0 ? (
                                    <p className="text-sm text-muted-foreground">
                                        No completed shifts found.
                                    </p>
                                ) : (
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead>
                                                <tr className="border-b text-left text-muted-foreground">
                                                    <th className="pr-4 pb-3 font-medium">
                                                        Shift
                                                    </th>
                                                    <th className="pr-4 pb-3 text-right font-medium">
                                                        Duration
                                                    </th>
                                                    <th className="pr-4 pb-3 text-right font-medium">
                                                        Created
                                                    </th>
                                                    <th className="pr-4 pb-3 text-right font-medium">
                                                        Resolved
                                                    </th>
                                                    <th className="pb-3 text-right font-medium">
                                                        Escalated
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {shift_comparison.map(
                                                    (s, i) => (
                                                        <tr
                                                            key={i}
                                                            className="border-b last:border-0"
                                                        >
                                                            <td className="py-3 pr-4 font-medium">
                                                                {s.name}
                                                            </td>
                                                            <td className="py-3 pr-4 text-right">
                                                                {
                                                                    s.duration_hours
                                                                }
                                                                h
                                                            </td>
                                                            <td className="py-3 pr-4 text-right">
                                                                {
                                                                    s.alerts_created
                                                                }
                                                            </td>
                                                            <td className="py-3 pr-4 text-right text-status-success dark:text-status-success">
                                                                {
                                                                    s.alerts_resolved
                                                                }
                                                            </td>
                                                            <td className="py-3 text-right">
                                                                {s.alerts_escalated >
                                                                0 ? (
                                                                    <span className="text-status-warning dark:text-status-warning">
                                                                        {
                                                                            s.alerts_escalated
                                                                        }
                                                                    </span>
                                                                ) : (
                                                                    <span>
                                                                        {
                                                                            s.alerts_escalated
                                                                        }
                                                                    </span>
                                                                )}
                                                            </td>
                                                        </tr>
                                                    ),
                                                )}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </div>

                    {/* Signal Source Health */}
                    <div className="mt-6">
                        <Card>
                            <CardHeader>
                                <CardTitle className="flex items-center gap-2 text-base">
                                    <Wifi className="h-4 w-4" />
                                    Signal Source Health
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                {signal_sources.length === 0 ? (
                                    <p className="text-sm text-muted-foreground">
                                        No signal sources configured.
                                    </p>
                                ) : (
                                    <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                                        {signal_sources.map((ss, i) => (
                                            <div
                                                key={i}
                                                className={`rounded-lg border p-4 ${
                                                    !ss.is_healthy
                                                        ? 'border-status-critical/30 bg-status-critical-bg dark:border-status-critical/30'
                                                        : 'border-border'
                                                }`}
                                            >
                                                <div className="flex items-start justify-between">
                                                    <div className="flex items-center gap-2">
                                                        <span
                                                            className={`inline-block h-2.5 w-2.5 rounded-full ${
                                                                ss.is_healthy
                                                                    ? 'bg-status-success'
                                                                    : 'bg-status-critical'
                                                            }`}
                                                        />
                                                        <span className="text-sm font-medium">
                                                            {ss.name}
                                                        </span>
                                                    </div>
                                                    <Badge
                                                        variant="secondary"
                                                        className="text-xs"
                                                    >
                                                        {ss.signal_count_24h} /
                                                        24h
                                                    </Badge>
                                                </div>
                                                <div className="mt-2 flex items-center gap-1 text-xs text-muted-foreground">
                                                    {ss.is_healthy ? (
                                                        <Wifi className="h-3 w-3" />
                                                    ) : (
                                                        <WifiOff className="h-3 w-3 text-status-critical" />
                                                    )}
                                                    <span>
                                                        {ss.last_heartbeat_at
                                                            ? formatRelative(
                                                                  ss.last_heartbeat_at,
                                                              )
                                                            : 'No heartbeat'}
                                                    </span>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </CardContent>
                        </Card>
                    </div>
                </CommandCentrePage>
            </PageShell>
        </AppLayout>
    );
}
