import { CommandCentrePage } from '@/components/command-centre/command-centre-page';
import { ConfirmDialog } from '@/components/confirm-dialog';
import { AlertStatusChip } from '@/components/control-room/alert-worklist/alert-status';
import { PageHeaderFilterCheck } from '@/components/page';
import PageShell from '@/components/page-shell';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import AppLayout from '@/layouts/app-layout';
import { formatDateTime, formatRelative } from '@/lib/datetime';
import type { SharedData } from '@/types';
import { Head, router, usePage } from '@inertiajs/react';
import { Pencil, Plus, RefreshCw, Settings2, Trash2, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import {
    DeleteConfirmDialog,
    MaintenanceWindowDialog,
    SignalRuleDialog,
    TriageQueueDialog,
} from './_settings-dialogs';
import type {
    MaintenanceWindowData,
    PlaybookOption,
    RoutingChoice,
    SignalRuleData,
    SignalSourceOption,
    SignalTypeOption,
    SiteOption,
    TriageQueueData,
} from './_settings-types';

// --- TypeScript Interfaces ---

interface SignalOutboxRow {
    id: number;
    status: 'failed' | 'dead_letter' | 'unroutable';
    attempts: number;
    last_attempt_at: string | null;
    last_error: string | null;
    created_at: string | null;
    updated_at: string | null;
    can_retry: boolean;
    signal: {
        id: number;
        asset_id: number;
        device_id: number | null;
        signal_type: string;
        severity_hint: string;
        occurred_at: string | null;
    } | null;
}

interface Props {
    activeTab: string;
    sourceChoices: RoutingChoice[];
    roleChoices: RoutingChoice[];
    canScheduleAllSites: boolean;
    signalRules: SignalRuleData[];
    signalTypes: SignalTypeOption[];
    signalSources: SignalSourceOption[];
    triageQueues: TriageQueueData[];
    maintenanceWindows: MaintenanceWindowData[];
    signalOutbox: SignalOutboxRow[];
    signalOutboxLimited?: boolean;
    playbooks: PlaybookOption[];
    sites: SiteOption[];
    configOptions: Record<
        string,
        Array<{
            id: number;
            group: string;
            value: string;
            label: string;
            color: string | null;
            description: string | null;
            sort_order: number;
            is_active: boolean;
        }>
    >;
}

// --- Helpers ---

const statusColors: Record<string, string> = {
    active: 'bg-status-success-bg text-status-success',
    inactive: 'bg-muted text-muted-foreground',
    maintenance: 'bg-status-warning-bg text-status-warning',
};

const windowStatusColors: Record<string, string> = {
    scheduled: 'bg-status-info-bg text-status-info',
    active: 'bg-status-success-bg text-status-success',
    completed: 'bg-muted text-muted-foreground',
    cancelled: 'bg-status-critical-bg text-status-critical',
};

const outboxStatusColors: Record<string, string> = {
    failed: 'bg-status-warning-bg text-status-warning',
    dead_letter: 'bg-status-critical-bg text-status-critical',
    unroutable: 'bg-status-critical-bg text-status-critical',
};

function heartbeatColor(isoString: string | null): string {
    if (!isoString) return 'text-status-critical';
    const diffMins = (Date.now() - new Date(isoString).getTime()) / 60000;
    if (diffMins < 5) return 'text-status-success';
    if (diffMins < 10) return 'text-status-warning';
    return 'text-status-critical';
}

// --- Main Page Component ---

export default function ControlRoomSettings({
    activeTab,
    sourceChoices,
    roleChoices,
    canScheduleAllSites,
    signalRules,
    signalTypes,
    signalSources,
    triageQueues,
    maintenanceWindows,
    signalOutbox,
    signalOutboxLimited = false,
    playbooks,
    sites,
    configOptions,
}: Props) {
    const { errors } = usePage<
        SharedData & { errors: Record<string, string> }
    >().props;
    const [narrow, setNarrow] = useState(false);
    useEffect(() => setNarrow(false), [activeTab]);
    const enabledOnly =
        narrow && ['rules', 'queues', 'ticket-options'].includes(activeTab);
    const visibleRules = signalRules.filter(
        (row) => !enabledOnly || activeTab !== 'rules' || row.is_active,
    );
    const visibleQueues = triageQueues.filter(
        (row) => !enabledOnly || activeTab !== 'queues' || row.is_active,
    );
    const visibleSources = signalSources.filter(
        (row) => !narrow || activeTab !== 'sources' || row.is_healthy,
    );
    const visibleWindows = maintenanceWindows.filter(
        (row) =>
            !narrow ||
            activeTab !== 'maintenance' ||
            ['active', 'scheduled'].includes(row.status),
    );
    const visibleOutbox = signalOutbox.filter(
        (row) => !narrow || activeTab !== 'signal-outbox' || row.can_retry,
    );
    const allOptions = Object.values(configOptions ?? {}).flat();
    const visibleOptions = allOptions.filter(
        (row) =>
            !enabledOnly || activeTab !== 'ticket-options' || row.is_active,
    );
    const recordHref = (id: string) =>
        '/control-room/settings?tab=' + activeTab + '#' + id;
    const searchItems =
        activeTab === 'rules'
            ? visibleRules.map((row) => ({
                  key: 'rule-' + row.id,
                  label: row.name,
                  href: recordHref('rule-' + row.id),
              }))
            : activeTab === 'queues'
              ? visibleQueues.map((row) => ({
                    key: 'queue-' + row.id,
                    label: row.name,
                    href: recordHref('queue-' + row.id),
                }))
              : activeTab === 'sources'
                ? visibleSources.map((row) => ({
                      key: 'source-' + row.id,
                      label: row.name,
                      href: recordHref('source-' + row.id),
                      keywords: [row.slug, row.vendor],
                  }))
                : activeTab === 'maintenance'
                  ? visibleWindows.map((row) => ({
                        key: 'window-' + row.id,
                        label: row.name,
                        href: recordHref('window-' + row.id),
                    }))
                  : activeTab === 'signal-outbox'
                    ? visibleOutbox.map((row) => ({
                          key: 'outbox-' + row.id,
                          label:
                              (row.signal?.signal_type ??
                                  'Unavailable signal') +
                              ' · ' +
                              row.status,
                          href: recordHref('outbox-' + row.id),
                      }))
                    : visibleOptions.map((row) => ({
                          key: 'option-' + row.id,
                          label: row.label,
                          href: recordHref('option-' + row.id),
                          keywords: [row.value, row.group],
                      }));
    const filterLabel =
        activeTab === 'sources'
            ? 'Recent heartbeat only'
            : activeTab === 'maintenance'
              ? 'Current and planned only'
              : activeTab === 'signal-outbox'
                ? 'Retry ready only'
                : 'Enabled only';

    // Config options state
    const [optionDialogOpen, setOptionDialogOpen] = useState(false);
    const [optionGroup, setOptionGroup] = useState('category');
    const [optionValue, setOptionValue] = useState('');
    const [optionLabel, setOptionLabel] = useState('');
    const [optionColor, setOptionColor] = useState('');
    const [optionDesc, setOptionDesc] = useState('');
    const [deleteOptionId, setDeleteOptionId] = useState<number | null>(null);

    // Signal Rules state
    const [ruleDialogOpen, setRuleDialogOpen] = useState(false);
    const [editingRule, setEditingRule] = useState<SignalRuleData | null>(null);
    const [deleteRuleId, setDeleteRuleId] = useState<number | null>(null);
    const [deleteRuleVersion, setDeleteRuleVersion] = useState<string | null>(
        null,
    );

    // Queue state
    const [queueDialogOpen, setQueueDialogOpen] = useState(false);
    const [editingQueue, setEditingQueue] = useState<TriageQueueData | null>(
        null,
    );

    // Maintenance window state
    const [mwDialogOpen, setMwDialogOpen] = useState(false);
    const [editingMw, setEditingMw] = useState<MaintenanceWindowData | null>(
        null,
    );
    const [cancelWindow, setCancelWindow] =
        useState<MaintenanceWindowData | null>(null);
    const [cancelProcessing, setCancelProcessing] = useState(false);
    const cancelBusy = useRef(false);
    const currentRule = editingRule
        ? signalRules.find((row) => row.id === editingRule.id)
        : null;
    const currentQueue = editingQueue
        ? triageQueues.find((row) => row.id === editingQueue.id)
        : null;
    const currentWindow = editingMw
        ? maintenanceWindows.find((row) => row.id === editingMw.id)
        : null;
    const missingSetting =
        (ruleDialogOpen && editingRule && !currentRule) ||
        (queueDialogOpen && editingQueue && !currentQueue) ||
        (mwDialogOpen && editingMw && !currentWindow);

    function handleDeleteRule() {
        if (!deleteRuleId) return;
        router.delete(`/control-room/settings/rules/${deleteRuleId}`, {
            data: { expected_version: deleteRuleVersion },
            onSuccess: () => setDeleteRuleId(null),
        });
    }

    function handleToggleRuleActive(rule: SignalRuleData) {
        router.put(
            `/control-room/settings/rules/${rule.id}`,
            {
                ...rule,
                expected_version: rule.version,
                conditions: (rule.conditions ?? {}) as Record<
                    string,
                    string | number | boolean | null
                >,
                is_active: !rule.is_active,
            },
            { preserveScroll: true },
        );
    }

    function handleToggleQueueActive(queue: TriageQueueData) {
        router.put(
            `/control-room/settings/queues/${queue.id}`,
            {
                ...queue,
                expected_version: queue.version,
                is_active: !queue.is_active,
            },
            { preserveScroll: true },
        );
    }

    function handleCancelWindow(windowId: number) {
        const window = maintenanceWindows.find((row) => row.id === windowId);
        if (window) setCancelWindow(window);
    }

    function confirmCancelWindow() {
        if (!cancelWindow || cancelBusy.current) return;
        cancelBusy.current = true;
        setCancelProcessing(true);
        router.post(
            `/control-room/settings/maintenance/${cancelWindow.id}/cancel`,
            { expected_version: cancelWindow.version },
            {
                preserveScroll: true,
                onSuccess: () => setCancelWindow(null),
                onError: () => setCancelWindow(null),
                onFinish: () => {
                    cancelBusy.current = false;
                    setCancelProcessing(false);
                },
            },
        );
    }

    function handleRetryOutbox(outboxId: number) {
        router.post(
            `/control-room/settings/signal-outbox/${outboxId}/retry`,
            {},
            { preserveScroll: true },
        );
    }

    const breadcrumbs = [
        { title: 'Home', href: '/dashboard' },
        { title: 'Control Room', href: '/control-room' },
        { title: 'Settings', href: '#' },
    ];

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title="Control Room Settings" />
            <PageShell>
                <CommandCentrePage
                    variant="compact"
                    current="/control-room/settings"
                    icon={Settings2}
                    title="Settings"
                    description="Configure signal rules, triage queues, sources, maintenance windows, and ticket options."
                    status="Configuration workspace"
                    searchItems={searchItems}
                    filters={
                        <PageHeaderFilterCheck
                            label={filterLabel}
                            checked={narrow}
                            onChange={setNarrow}
                        />
                    }
                    metricGroups={[
                        {
                            title: 'Configuration',
                            icon: Settings2,
                            metrics: [
                                {
                                    label: 'Routing rules',
                                    value: String(visibleRules.length),
                                    caption: 'configured rules',
                                    tone: 'neutral',
                                    href: '/control-room/settings?tab=rules',
                                },
                                {
                                    label: 'Queues',
                                    value: String(visibleQueues.length),
                                    caption: 'response queues',
                                    tone: 'neutral',
                                    href: '/control-room/settings?tab=queues',
                                },
                                {
                                    label: 'Sources',
                                    value: String(visibleSources.length),
                                    caption: 'configured sources',
                                    tone: 'neutral',
                                    href: '/control-room/settings?tab=sources',
                                },
                                {
                                    label: 'Maintenance',
                                    value: String(visibleWindows.length),
                                    caption: 'current, planned and recent',
                                    tone: 'neutral',
                                    href: '/control-room/settings?tab=maintenance',
                                },
                                {
                                    label: 'Recovery',
                                    value: String(visibleOutbox.length),
                                    caption: 'latest retained problem rows',
                                    tone: visibleOutbox.length
                                        ? 'warning'
                                        : 'neutral',
                                    href: '/control-room/settings?tab=signal-outbox',
                                },
                                {
                                    label: 'Response options',
                                    value: String(visibleOptions.length),
                                    caption: 'configured choices',
                                    tone: 'neutral',
                                    href: '/control-room/settings?tab=ticket-options',
                                },
                            ],
                        },
                    ]}
                >
                    <div className="space-y-5">
                        {errors?.save_conflict && (
                            <Alert variant="destructive">
                                <AlertDescription>
                                    {errors.save_conflict}
                                </AlertDescription>
                            </Alert>
                        )}

                        {/* --- Tab 1: Signal Rules --- */}
                        {activeTab === 'rules' ? (
                            <section id="settings-rules" className="space-y-4">
                                <Card>
                                    <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
                                        <CardTitle className="text-base">
                                            Signal Rules
                                        </CardTitle>
                                        <Button
                                            size="sm"
                                            className="frontline-tap"
                                            onClick={() => {
                                                setEditingRule(null);
                                                setRuleDialogOpen(true);
                                            }}
                                        >
                                            <Plus className="mr-1.5 h-4 w-4" />
                                            Create Rule
                                        </Button>
                                    </CardHeader>
                                    <CardContent>
                                        {visibleRules.length === 0 ? (
                                            <p className="py-8 text-center text-sm text-muted-foreground">
                                                No signal rules configured yet.
                                                Create one to get started.
                                            </p>
                                        ) : (
                                            <div className="overflow-x-auto">
                                                <table className="w-full text-sm">
                                                    <thead>
                                                        <tr className="border-b text-left text-muted-foreground">
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Name
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Signal Type
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Source
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Priority
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Severity
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Dedup
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Active
                                                            </th>
                                                            <th className="pb-2 font-medium">
                                                                Actions
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {visibleRules.map(
                                                            (rule) => (
                                                                <tr
                                                                    key={
                                                                        rule.id
                                                                    }
                                                                    id={
                                                                        'rule-' +
                                                                        rule.id
                                                                    }
                                                                    className="border-b last:border-0"
                                                                >
                                                                    <td className="py-2.5 pr-4 font-medium">
                                                                        {
                                                                            rule.name
                                                                        }
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 text-muted-foreground">
                                                                        {rule.signal_type_name ??
                                                                            'Any'}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 text-muted-foreground">
                                                                        {rule.signal_source_name ??
                                                                            'Any'}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {
                                                                            rule.priority
                                                                        }
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {rule.output_severity ? (
                                                                            <AlertStatusChip
                                                                                kind="severity"
                                                                                value={
                                                                                    rule.output_severity
                                                                                }
                                                                            />
                                                                        ) : (
                                                                            <span className="text-muted-foreground">
                                                                                Inherit
                                                                            </span>
                                                                        )}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {rule.dedup_window_minutes
                                                                            ? `${rule.dedup_window_minutes}m`
                                                                            : '-'}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <label
                                                                            htmlFor={`signal-rule-active-${rule.id}`}
                                                                            className="frontline-tap flex cursor-pointer items-center justify-center rounded-md"
                                                                        >
                                                                            <Switch
                                                                                id={`signal-rule-active-${rule.id}`}
                                                                                aria-label={`Signal rule ${rule.name} active`}
                                                                                checked={
                                                                                    rule.is_active
                                                                                }
                                                                                onCheckedChange={() =>
                                                                                    handleToggleRuleActive(
                                                                                        rule,
                                                                                    )
                                                                                }
                                                                            />
                                                                        </label>
                                                                    </td>
                                                                    <td className="py-2.5">
                                                                        <div className="flex gap-1">
                                                                            <Button
                                                                                aria-label={`Edit signal rule ${rule.name}`}
                                                                                variant="ghost"
                                                                                size="sm"
                                                                                className="frontline-tap"
                                                                                onClick={() => {
                                                                                    setEditingRule(
                                                                                        rule,
                                                                                    );
                                                                                    setRuleDialogOpen(
                                                                                        true,
                                                                                    );
                                                                                }}
                                                                            >
                                                                                <Pencil className="h-3.5 w-3.5" />
                                                                            </Button>
                                                                            <Button
                                                                                aria-label={`Delete signal rule ${rule.name}`}
                                                                                variant="ghost"
                                                                                size="sm"
                                                                                className="frontline-tap"
                                                                                onClick={() => {
                                                                                    setDeleteRuleId(
                                                                                        rule.id,
                                                                                    );
                                                                                    setDeleteRuleVersion(
                                                                                        rule.version,
                                                                                    );
                                                                                }}
                                                                            >
                                                                                <Trash2 className="h-3.5 w-3.5 text-status-critical" />
                                                                            </Button>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            ),
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </section>
                        ) : null}

                        {/* --- Tab 2: Triage Queues --- */}
                        {activeTab === 'queues' ? (
                            <section id="settings-queues" className="space-y-4">
                                <Card>
                                    <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
                                        <CardTitle className="text-base">
                                            Triage Queues
                                        </CardTitle>
                                        <Button
                                            size="sm"
                                            className="frontline-tap"
                                            onClick={() => {
                                                setEditingQueue(null);
                                                setQueueDialogOpen(true);
                                            }}
                                        >
                                            <Plus className="mr-1.5 h-4 w-4" />
                                            Create Queue
                                        </Button>
                                    </CardHeader>
                                    <CardContent>
                                        {visibleQueues.length === 0 ? (
                                            <p className="py-8 text-center text-sm text-muted-foreground">
                                                No triage queues configured yet.
                                            </p>
                                        ) : (
                                            <div className="overflow-x-auto">
                                                <table className="w-full text-sm">
                                                    <thead>
                                                        <tr className="border-b text-left text-muted-foreground">
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Name
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Code
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Tier
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Severities
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Sources
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Auto-Escalate
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Next Queue
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Open
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Active
                                                            </th>
                                                            <th className="pb-2 font-medium">
                                                                Actions
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {visibleQueues.map(
                                                            (queue) => (
                                                                <tr
                                                                    key={
                                                                        queue.id
                                                                    }
                                                                    id={
                                                                        'queue-' +
                                                                        queue.id
                                                                    }
                                                                    className="border-b last:border-0"
                                                                >
                                                                    <td className="py-2.5 pr-4 font-medium">
                                                                        {
                                                                            queue.name
                                                                        }
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 font-mono text-xs text-muted-foreground">
                                                                        {
                                                                            queue.code
                                                                        }
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <Badge variant="outline">
                                                                            T
                                                                            {
                                                                                queue.tier
                                                                            }
                                                                        </Badge>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <div className="flex flex-wrap gap-1">
                                                                            {queue.handle_severities.map(
                                                                                (
                                                                                    s,
                                                                                ) => (
                                                                                    <AlertStatusChip
                                                                                        key={
                                                                                            s
                                                                                        }
                                                                                        kind="severity"
                                                                                        value={
                                                                                            s
                                                                                        }
                                                                                    />
                                                                                ),
                                                                            )}
                                                                            {queue
                                                                                .handle_severities
                                                                                .length ===
                                                                                0 && (
                                                                                <span className="text-muted-foreground">
                                                                                    All
                                                                                </span>
                                                                            )}
                                                                        </div>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <div className="flex flex-wrap gap-1">
                                                                            {queue.handle_sources.map(
                                                                                (
                                                                                    s,
                                                                                ) => (
                                                                                    <Badge
                                                                                        key={
                                                                                            s
                                                                                        }
                                                                                        variant="outline"
                                                                                        className="text-xs"
                                                                                    >
                                                                                        {
                                                                                            s
                                                                                        }
                                                                                    </Badge>
                                                                                ),
                                                                            )}
                                                                            {queue
                                                                                .handle_sources
                                                                                .length ===
                                                                                0 && (
                                                                                <span className="text-muted-foreground">
                                                                                    All
                                                                                </span>
                                                                            )}
                                                                        </div>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {queue.auto_escalate_after_minutes
                                                                            ? `${queue.auto_escalate_after_minutes}m`
                                                                            : '-'}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 text-muted-foreground">
                                                                        {queue.escalate_to_queue_name ??
                                                                            '-'}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <Badge
                                                                            variant="outline"
                                                                            className={
                                                                                queue.open_alert_count >
                                                                                0
                                                                                    ? 'bg-status-warning-bg text-status-warning'
                                                                                    : ''
                                                                            }
                                                                        >
                                                                            {
                                                                                queue.open_alert_count
                                                                            }
                                                                        </Badge>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <label
                                                                            htmlFor={`triage-queue-active-${queue.id}`}
                                                                            className="frontline-tap flex cursor-pointer items-center justify-center rounded-md"
                                                                        >
                                                                            <Switch
                                                                                id={`triage-queue-active-${queue.id}`}
                                                                                aria-label={`Triage queue ${queue.name} active`}
                                                                                checked={
                                                                                    queue.is_active
                                                                                }
                                                                                onCheckedChange={() =>
                                                                                    handleToggleQueueActive(
                                                                                        queue,
                                                                                    )
                                                                                }
                                                                            />
                                                                        </label>
                                                                    </td>
                                                                    <td className="py-2.5">
                                                                        <Button
                                                                            aria-label={`Edit triage queue ${queue.name}`}
                                                                            variant="ghost"
                                                                            size="sm"
                                                                            className="frontline-tap"
                                                                            onClick={() => {
                                                                                setEditingQueue(
                                                                                    queue,
                                                                                );
                                                                                setQueueDialogOpen(
                                                                                    true,
                                                                                );
                                                                            }}
                                                                        >
                                                                            <Pencil className="h-3.5 w-3.5" />
                                                                        </Button>
                                                                    </td>
                                                                </tr>
                                                            ),
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </section>
                        ) : null}

                        {/* --- Tab 3: Signal Sources (read-only) --- */}
                        {activeTab === 'sources' ? (
                            <section
                                id="settings-sources"
                                className="space-y-4"
                            >
                                {signalSources.length === 0 ? (
                                    <Card>
                                        <CardContent className="py-8 text-center text-sm text-muted-foreground">
                                            No signal sources configured.
                                        </CardContent>
                                    </Card>
                                ) : (
                                    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                                        {visibleSources.map((source) => (
                                            <Card
                                                key={source.id}
                                                id={'source-' + source.id}
                                            >
                                                <CardHeader className="pb-3">
                                                    <div className="flex items-start justify-between">
                                                        <div>
                                                            <CardTitle className="text-base">
                                                                {source.name}
                                                            </CardTitle>
                                                            {source.vendor && (
                                                                <p className="mt-0.5 text-xs text-muted-foreground">
                                                                    {
                                                                        source.vendor
                                                                    }
                                                                </p>
                                                            )}
                                                        </div>
                                                        <Badge
                                                            variant="outline"
                                                            className={
                                                                statusColors[
                                                                    source
                                                                        .status
                                                                ] ?? ''
                                                            }
                                                        >
                                                            {source.status}
                                                        </Badge>
                                                    </div>
                                                </CardHeader>
                                                <CardContent className="space-y-3">
                                                    <div className="grid grid-cols-2 gap-2 text-sm">
                                                        <div>
                                                            <p className="text-xs text-muted-foreground">
                                                                Last Heartbeat
                                                            </p>
                                                            <p
                                                                className={`font-medium ${heartbeatColor(source.last_heartbeat_at)}`}
                                                            >
                                                                {formatRelative(
                                                                    source.last_heartbeat_at,
                                                                )}
                                                            </p>
                                                        </div>
                                                        <div>
                                                            <p className="text-xs text-muted-foreground">
                                                                Last Signal
                                                            </p>
                                                            <p className="font-medium">
                                                                {formatRelative(
                                                                    source.last_signal_at,
                                                                )}
                                                            </p>
                                                        </div>
                                                    </div>
                                                    <div>
                                                        <p className="text-xs text-muted-foreground">
                                                            24h Signal Count
                                                        </p>
                                                        <p className="text-lg font-semibold">
                                                            {source.signal_count_24h.toLocaleString()}
                                                        </p>
                                                    </div>
                                                    {source.capabilities
                                                        .length > 0 && (
                                                        <div>
                                                            <p className="mb-1 text-xs text-muted-foreground">
                                                                Capabilities
                                                            </p>
                                                            <div className="flex flex-wrap gap-1">
                                                                {source.capabilities.map(
                                                                    (cap) => (
                                                                        <Badge
                                                                            key={
                                                                                cap
                                                                            }
                                                                            variant="secondary"
                                                                            className="text-xs"
                                                                        >
                                                                            {
                                                                                cap
                                                                            }
                                                                        </Badge>
                                                                    ),
                                                                )}
                                                            </div>
                                                        </div>
                                                    )}
                                                </CardContent>
                                            </Card>
                                        ))}
                                    </div>
                                )}
                            </section>
                        ) : null}

                        {/* --- Tab 4: Signal Outbox --- */}
                        {activeTab === 'signal-outbox' ? (
                            <section
                                id="settings-signal-outbox"
                                className="space-y-4"
                            >
                                <Card>
                                    <CardHeader>
                                        <CardTitle className="text-base">
                                            Failed signal deliveries
                                        </CardTitle>
                                    </CardHeader>
                                    <CardContent>
                                        <p className="mb-4 text-sm text-muted-foreground">
                                            Showing failures for source records you can currently access.
                                            {signalOutboxLimited && ' This is a limited list; more failures may need review.'}
                                        </p>
                                        {visibleOutbox.length === 0 ? (
                                            <p className="py-8 text-center text-sm text-muted-foreground">
                                                {narrow
                                                    ? 'No failed deliveries ready for retry in your current source access.'
                                                    : 'No failed deliveries available in your current source access.'}
                                            </p>
                                        ) : (
                                            <div className="overflow-x-auto">
                                                <table className="w-full text-sm">
                                                    <thead>
                                                        <tr className="border-b text-left text-muted-foreground">
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Signal
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Status
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Attempts
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Last Attempt
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Error
                                                            </th>
                                                            <th className="pb-2 font-medium">
                                                                Action
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {visibleOutbox.map(
                                                            (row) => (
                                                                <tr
                                                                    key={row.id}
                                                                    id={
                                                                        'outbox-' +
                                                                        row.id
                                                                    }
                                                                    className="border-b last:border-0"
                                                                >
                                                                    <td className="py-2.5 pr-4">
                                                                        <div className="font-medium">
                                                                            {row
                                                                                .signal
                                                                                ?.signal_type ??
                                                                                `Outbox #${row.id}`}
                                                                        </div>
                                                                        <div className="text-xs text-muted-foreground">
                                                                            {row.signal
                                                                                ? `Signal #${row.signal.id} - Asset #${row.signal.asset_id}`
                                                                                : 'Missing source signal'}
                                                                        </div>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <Badge
                                                                            variant="outline"
                                                                            className={
                                                                                outboxStatusColors[
                                                                                    row
                                                                                        .status
                                                                                ] ??
                                                                                ''
                                                                            }
                                                                        >
                                                                            {
                                                                                row.status
                                                                            }
                                                                        </Badge>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {
                                                                            row.attempts
                                                                        }
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 text-muted-foreground">
                                                                        {formatDateTime(
                                                                            row.last_attempt_at,
                                                                        )}
                                                                    </td>
                                                                    <td className="max-w-[280px] truncate py-2.5 pr-4 text-muted-foreground">
                                                                        {row.last_error ??
                                                                            '-'}
                                                                    </td>
                                                                    <td className="py-2.5">
                                                                        <Button
                                                                            aria-label={`Retry signal delivery ${row.id}`}
                                                                            variant="outline"
                                                                            size="sm"
                                                                            className="frontline-tap"
                                                                            disabled={
                                                                                !row.can_retry
                                                                            }
                                                                            onClick={() =>
                                                                                handleRetryOutbox(
                                                                                    row.id,
                                                                                )
                                                                            }
                                                                        >
                                                                            <RefreshCw className="mr-1.5 h-3.5 w-3.5" />
                                                                            Retry
                                                                        </Button>
                                                                    </td>
                                                                </tr>
                                                            ),
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </section>
                        ) : null}

                        {/* --- Tab 5: Maintenance Windows --- */}
                        {activeTab === 'maintenance' ? (
                            <section
                                id="settings-maintenance"
                                className="space-y-4"
                            >
                                <Card>
                                    <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
                                        <CardTitle className="text-base">
                                            Maintenance Windows
                                        </CardTitle>
                                        <Button
                                            size="sm"
                                            className="frontline-tap"
                                            onClick={() => {
                                                setEditingMw(null);
                                                setMwDialogOpen(true);
                                            }}
                                        >
                                            <Plus className="mr-1.5 h-4 w-4" />
                                            Schedule Window
                                        </Button>
                                    </CardHeader>
                                    <CardContent>
                                        {visibleWindows.length === 0 ? (
                                            <p className="py-8 text-center text-sm text-muted-foreground">
                                                No maintenance windows
                                                scheduled.
                                            </p>
                                        ) : (
                                            <div className="overflow-x-auto">
                                                <table className="w-full text-sm">
                                                    <thead>
                                                        <tr className="border-b text-left text-muted-foreground">
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Name
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Source / Site
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Starts At
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Ends At
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Status
                                                            </th>
                                                            <th className="pr-4 pb-2 font-medium">
                                                                Created By
                                                            </th>
                                                            <th className="pb-2 font-medium">
                                                                Actions
                                                            </th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {visibleWindows.map(
                                                            (mw) => (
                                                                <tr
                                                                    key={mw.id}
                                                                    id={
                                                                        'window-' +
                                                                        mw.id
                                                                    }
                                                                    className="border-b last:border-0"
                                                                >
                                                                    <td className="py-2.5 pr-4 font-medium">
                                                                        {
                                                                            mw.name
                                                                        }
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 text-muted-foreground">
                                                                        {mw.signal_source_name ??
                                                                            'All sources'}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {formatDateTime(
                                                                            mw.starts_at,
                                                                        )}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        {formatDateTime(
                                                                            mw.ends_at,
                                                                        )}
                                                                    </td>
                                                                    <td className="py-2.5 pr-4">
                                                                        <Badge
                                                                            variant="outline"
                                                                            className={
                                                                                windowStatusColors[
                                                                                    mw
                                                                                        .status
                                                                                ] ??
                                                                                ''
                                                                            }
                                                                        >
                                                                            {
                                                                                mw.status
                                                                            }
                                                                        </Badge>
                                                                    </td>
                                                                    <td className="py-2.5 pr-4 text-muted-foreground">
                                                                        {mw.created_by_name ??
                                                                            '-'}
                                                                    </td>
                                                                    <td className="py-2.5">
                                                                        <div className="flex gap-1">
                                                                            {(mw.status ===
                                                                                'scheduled' ||
                                                                                mw.status ===
                                                                                    'active') && (
                                                                                <>
                                                                                    <Button
                                                                                        aria-label={`Edit maintenance window ${mw.name}`}
                                                                                        variant="ghost"
                                                                                        size="sm"
                                                                                        className="frontline-tap"
                                                                                        onClick={() => {
                                                                                            setEditingMw(
                                                                                                mw,
                                                                                            );
                                                                                            setMwDialogOpen(
                                                                                                true,
                                                                                            );
                                                                                        }}
                                                                                    >
                                                                                        <Pencil className="h-3.5 w-3.5" />
                                                                                    </Button>
                                                                                    <Button
                                                                                        aria-label={`Cancel maintenance window ${mw.name}`}
                                                                                        variant="ghost"
                                                                                        size="sm"
                                                                                        className="frontline-tap"
                                                                                        onClick={() =>
                                                                                            handleCancelWindow(
                                                                                                mw.id,
                                                                                            )
                                                                                        }
                                                                                    >
                                                                                        <X className="h-3.5 w-3.5 text-status-critical" />
                                                                                    </Button>
                                                                                </>
                                                                            )}
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                            ),
                                                        )}
                                                    </tbody>
                                                </table>
                                            </div>
                                        )}
                                    </CardContent>
                                </Card>
                            </section>
                        ) : null}
                        {/* --- Tab 5: Ticket Options --- */}
                        {activeTab === 'ticket-options' ? (
                            <section
                                id="settings-ticket-options"
                                className="space-y-4"
                            >
                                {(
                                    [
                                        'category',
                                        'resolution_code',
                                        'task_category',
                                    ] as const
                                ).map((group) => {
                                    const groupLabels: Record<string, string> =
                                        {
                                            category: 'Alert Categories',
                                            resolution_code: 'Resolution Codes',
                                            task_category: 'Task Categories',
                                        };
                                    const items = (
                                        configOptions?.[group] ?? []
                                    ).filter(
                                        (row) => !enabledOnly || row.is_active,
                                    );
                                    return (
                                        <Card key={group}>
                                            <CardHeader className="flex flex-row flex-wrap items-center justify-between gap-3">
                                                <CardTitle className="text-base">
                                                    {groupLabels[group] ??
                                                        group}
                                                </CardTitle>
                                                <Button
                                                    aria-label={`Add ${groupLabels[group]} option`}
                                                    size="sm"
                                                    className="frontline-tap"
                                                    onClick={() => {
                                                        setOptionGroup(group);
                                                        setOptionValue('');
                                                        setOptionLabel('');
                                                        setOptionColor('');
                                                        setOptionDesc('');
                                                        setOptionDialogOpen(
                                                            true,
                                                        );
                                                    }}
                                                >
                                                    <Plus className="mr-1 h-4 w-4" />{' '}
                                                    Add
                                                </Button>
                                            </CardHeader>
                                            <CardContent>
                                                {items.length === 0 ? (
                                                    <p className="py-4 text-center text-sm text-muted-foreground">
                                                        No options configured.
                                                        Click Add to create one.
                                                    </p>
                                                ) : (
                                                    <div className="space-y-2">
                                                        {items.map((opt) => (
                                                            <div
                                                                key={opt.id}
                                                                id={
                                                                    'option-' +
                                                                    opt.id
                                                                }
                                                                className="flex flex-wrap items-center justify-between gap-3 rounded-lg border px-4 py-2.5"
                                                            >
                                                                <div className="flex min-w-0 items-center gap-3">
                                                                    {opt.color && (
                                                                        <span
                                                                            className="inline-block h-3 w-3 rounded-full"
                                                                            style={{
                                                                                backgroundColor:
                                                                                    opt.color,
                                                                            }}
                                                                        />
                                                                    )}
                                                                    <div className="min-w-0">
                                                                        <span className="text-sm font-medium break-words">
                                                                            {
                                                                                opt.label
                                                                            }
                                                                        </span>
                                                                        <span className="ml-2 text-xs break-all text-muted-foreground">
                                                                            (
                                                                            {
                                                                                opt.value
                                                                            }
                                                                            )
                                                                        </span>
                                                                        {opt.description && (
                                                                            <p className="text-xs text-muted-foreground">
                                                                                {
                                                                                    opt.description
                                                                                }
                                                                            </p>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                                <div className="flex flex-wrap items-center gap-2">
                                                                    <label
                                                                        htmlFor={`ticket-option-active-${opt.id}`}
                                                                        className="frontline-tap flex cursor-pointer items-center justify-center rounded-md"
                                                                    >
                                                                        <Switch
                                                                            id={`ticket-option-active-${opt.id}`}
                                                                            aria-label={`${groupLabels[group]} option ${opt.label} (${opt.value}) active`}
                                                                            checked={
                                                                                opt.is_active
                                                                            }
                                                                            onCheckedChange={() =>
                                                                                router.put(
                                                                                    `/control-room/settings/options/${opt.id}`,
                                                                                    {
                                                                                        is_active:
                                                                                            !opt.is_active,
                                                                                    },
                                                                                    {
                                                                                        preserveScroll: true,
                                                                                    },
                                                                                )
                                                                            }
                                                                        />
                                                                    </label>
                                                                    <OptionDeleteControl
                                                                        optionName={`${groupLabels[group]} option ${opt.label} (${opt.value})`}
                                                                        onConfirm={() =>
                                                                            router.delete(
                                                                                `/control-room/settings/options/${opt.id}`,
                                                                                {
                                                                                    preserveScroll: true,
                                                                                },
                                                                            )
                                                                        }
                                                                    />
                                                                </div>
                                                            </div>
                                                        ))}
                                                    </div>
                                                )}
                                            </CardContent>
                                        </Card>
                                    );
                                })}
                            </section>
                        ) : null}
                    </div>

                    {/* Add Option Dialog */}
                    {optionDialogOpen && (
                        <Dialog
                            open={optionDialogOpen}
                            onOpenChange={setOptionDialogOpen}
                        >
                            <DialogContent className="max-h-[calc(100dvh-1rem)] w-[calc(100vw-1rem)] overflow-y-auto sm:max-h-[85vh] [&>[data-slot=dialog-close]]:inline-flex [&>[data-slot=dialog-close]]:min-h-[44px] [&>[data-slot=dialog-close]]:min-w-[44px] [&>[data-slot=dialog-close]]:items-center [&>[data-slot=dialog-close]]:justify-center">
                                <DialogHeader>
                                    <DialogTitle>Add Option</DialogTitle>
                                    <DialogDescription>
                                        Add a reusable value to the selected
                                        Control Room option group.
                                    </DialogDescription>
                                </DialogHeader>
                                <div className="space-y-3 py-2">
                                    <div>
                                        <Label htmlFor="option-value">
                                            Option value (slug){' '}
                                            <span aria-hidden="true">*</span>
                                        </Label>
                                        <Input
                                            id="option-value"
                                            className="frontline-tap"
                                            required
                                            value={optionValue}
                                            onChange={(e) =>
                                                setOptionValue(
                                                    e.target.value
                                                        .toLowerCase()
                                                        .replace(
                                                            /[^a-z0-9_]/g,
                                                            '_',
                                                        ),
                                                )
                                            }
                                            placeholder="e.g. incident"
                                        />
                                    </div>
                                    <div>
                                        <Label htmlFor="option-label">
                                            Display label{' '}
                                            <span aria-hidden="true">*</span>
                                        </Label>
                                        <Input
                                            id="option-label"
                                            className="frontline-tap"
                                            required
                                            value={optionLabel}
                                            onChange={(e) =>
                                                setOptionLabel(e.target.value)
                                            }
                                            placeholder="e.g. Incident"
                                        />
                                    </div>
                                    <div>
                                        <Label htmlFor="option-color">
                                            Option colour (hex)
                                        </Label>
                                        <div className="flex items-center gap-2">
                                            <Input
                                                id="option-color"
                                                value={optionColor}
                                                onChange={(e) =>
                                                    setOptionColor(
                                                        e.target.value,
                                                    )
                                                }
                                                placeholder="#ef4444"
                                                className="frontline-tap flex-1"
                                            />
                                            {optionColor && (
                                                <span
                                                    className="inline-block h-6 w-6 rounded-full border"
                                                    style={{
                                                        backgroundColor:
                                                            optionColor,
                                                    }}
                                                />
                                            )}
                                        </div>
                                    </div>
                                    <div>
                                        <Label htmlFor="option-description">
                                            Option description (optional)
                                        </Label>
                                        <Input
                                            id="option-description"
                                            className="frontline-tap"
                                            value={optionDesc}
                                            onChange={(e) =>
                                                setOptionDesc(e.target.value)
                                            }
                                            placeholder="Brief description..."
                                        />
                                    </div>
                                </div>
                                <DialogFooter>
                                    <Button
                                        variant="ghost"
                                        className="frontline-tap"
                                        onClick={() =>
                                            setOptionDialogOpen(false)
                                        }
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        className="frontline-tap"
                                        disabled={
                                            !optionValue.trim() ||
                                            !optionLabel.trim()
                                        }
                                        onClick={() => {
                                            router.post(
                                                '/control-room/settings/options',
                                                {
                                                    group: optionGroup,
                                                    value: optionValue.trim(),
                                                    label: optionLabel.trim(),
                                                    color:
                                                        optionColor.trim() ||
                                                        null,
                                                    description:
                                                        optionDesc.trim() ||
                                                        null,
                                                },
                                                {
                                                    preserveScroll: true,
                                                    onSuccess: () =>
                                                        setOptionDialogOpen(
                                                            false,
                                                        ),
                                                },
                                            );
                                        }}
                                    >
                                        Create
                                    </Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                    )}

                    {/* Dialogs */}
                    <ConfirmDialog
                        open={cancelWindow !== null}
                        onClose={() => {
                            if (!cancelBusy.current) setCancelWindow(null);
                        }}
                        onConfirm={confirmCancelWindow}
                        title="Cancel this maintenance window?"
                        description="Matching rules will no longer use this window for maintenance suppression. Active responses stay open."
                        confirmText={
                            cancelProcessing ? 'Cancelling…' : 'Cancel window'
                        }
                        cancelText="Keep window"
                        processing={cancelProcessing}
                        frontline
                    />
                    {missingSetting && (
                        <Dialog
                            open
                            onOpenChange={(open) => {
                                if (!open) {
                                    setRuleDialogOpen(false);
                                    setQueueDialogOpen(false);
                                    setMwDialogOpen(false);
                                }
                            }}
                        >
                            <DialogContent
                                className="frontline-dialog"
                                style={{
                                    width: 'min(92vw, 480px)',
                                    maxWidth: 'min(92vw, 480px)',
                                }}
                            >
                                <DialogHeader>
                                    <DialogTitle>
                                        Setting unavailable
                                    </DialogTitle>
                                    <DialogDescription>
                                        This setting is no longer available in
                                        your current Settings view. Close this
                                        window and review the available
                                        settings.
                                    </DialogDescription>
                                </DialogHeader>
                                <DialogFooter>
                                    <Button
                                        onClick={() => {
                                            setRuleDialogOpen(false);
                                            setQueueDialogOpen(false);
                                            setMwDialogOpen(false);
                                        }}
                                    >
                                        Close
                                    </Button>
                                </DialogFooter>
                            </DialogContent>
                        </Dialog>
                    )}
                    {ruleDialogOpen && (!editingRule || currentRule) && (
                        <SignalRuleDialog
                            open={ruleDialogOpen}
                            onClose={() => {
                                setRuleDialogOpen(false);
                                setEditingRule(null);
                            }}
                            rule={currentRule ?? null}
                            signalTypes={signalTypes}
                            signalSources={signalSources}
                            playbooks={playbooks}
                        />
                    )}

                    {queueDialogOpen && (!editingQueue || currentQueue) && (
                        <TriageQueueDialog
                            open={queueDialogOpen}
                            onClose={() => {
                                setQueueDialogOpen(false);
                                setEditingQueue(null);
                            }}
                            queue={currentQueue ?? null}
                            allQueues={triageQueues}
                            sourceChoices={sourceChoices}
                            roleChoices={roleChoices}
                        />
                    )}

                    {mwDialogOpen && (!editingMw || currentWindow) && (
                        <MaintenanceWindowDialog
                            open={mwDialogOpen}
                            onClose={() => {
                                setMwDialogOpen(false);
                                setEditingMw(null);
                            }}
                            window={currentWindow ?? null}
                            signalSources={signalSources}
                            sites={sites}
                            canScheduleAllSites={canScheduleAllSites}
                        />
                    )}

                    <DeleteConfirmDialog
                        open={deleteRuleId !== null}
                        onClose={() => setDeleteRuleId(null)}
                        onConfirm={handleDeleteRule}
                        title="Delete Signal Rule"
                        description="Are you sure you want to delete this signal rule? This action cannot be undone."
                    />
                </CommandCentrePage>
            </PageShell>
        </AppLayout>
    );
}
