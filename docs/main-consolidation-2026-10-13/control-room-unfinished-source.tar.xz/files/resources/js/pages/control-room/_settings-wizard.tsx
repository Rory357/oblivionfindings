import { Button } from '@/components/ui/button';
import {
    Command,
    CommandEmpty,
    CommandGroup,
    CommandInput,
    CommandItem,
    CommandList,
} from '@/components/ui/command';
import { Label } from '@/components/ui/label';
import {
    Popover,
    PopoverContent,
    PopoverTrigger,
} from '@/components/ui/popover';
import {
    ReviewCard,
    ReviewRow,
    WizardShell,
    WizardStepPane,
    WizardSuccessPane,
    type WizardStep,
} from '@/components/wizard/shell';
import { useSettingsLeaveConfirmation } from '@/hooks/use-settings-leave-confirmation';
import type { SharedData } from '@/types';
import type { FormDataConvertible } from '@inertiajs/core';
import { router, usePage, useRemember } from '@inertiajs/react';
import { Check, ChevronsUpDown, Loader2, Settings2 } from 'lucide-react';
import {
    useEffect,
    useRef,
    useState,
    type FormEvent,
    type ReactNode,
    type SetStateAction,
} from 'react';
import type { RoutingChoice } from './_settings-types';

type Errors = Record<string, string>;
type Values = Record<string, FormDataConvertible>;
type Frame<T> = { values: T; baseline: string; step: number };

/** History memory belongs to this actor and exact settings record, never a global draft. */
export function useSettingsWizard<T extends Values>(
    entity: string,
    id: number | undefined,
    initial: T,
    onClose: () => void,
    steps: readonly WizardStep[],
    fields: readonly (readonly string[])[],
    validate: (values: T) => Errors,
) {
    const actor = usePage<SharedData>().props.auth.user.id;
    const key = `control-room:settings:${actor}:${entity}:${id ?? 'new'}`;
    const [draft, setDraft] = useRemember<Frame<T> | null>(null, key);
    const [errors, setErrors] = useState<Errors>({});
    const [processing, setProcessing] = useState(false);
    const [saved, setSaved] = useState(false);
    const busy = useRef(false);
    const body = useRef<HTMLDivElement>(null);
    const baseline = JSON.stringify(initial);
    const form = draft?.values ?? initial;
    const step = Math.min(draft?.step ?? 0, steps.length - 1);
    const dirty =
        !saved && JSON.stringify(form) !== (draft?.baseline ?? baseline);
    const stale = dirty && draft?.baseline !== baseline;
    const clear = () => {
        setDraft(null);
        router.remember(null, key);
        setErrors({});
    };
    const leave = useSettingsLeaveConfirmation(
        dirty,
        'Discard this draft?',
        'Your unsaved settings will be discarded. Keep editing to retain them. A save already sent may still finish; review the saved setting before retrying.',
        clear,
    );
    useEffect(() => {
        // A pristine history entry can adopt current saved values. A dirty one must be reviewed explicitly.
        if (draft && !dirty && draft.baseline !== baseline) setDraft(null);
    }, [draft, dirty, baseline, setDraft]);
    useEffect(() => {
        if (processing) return;
        const first = Object.keys(errors).find((name) =>
            fields[step]?.includes(name.split('.')[0]),
        );
        if (!first) return;
        const field = Array.from(
            body.current?.querySelectorAll<HTMLElement>('[data-field]') ?? [],
        ).find((element) => element.dataset.field === first.split('.')[0]);
        field?.querySelector<HTMLElement>('input, textarea, button')?.focus();
    }, [errors, step, fields, processing]);

    const setForm = (value: SetStateAction<T>) => {
        if (busy.current) return;
        setDraft((previous) => ({
            values:
                typeof value === 'function'
                    ? value(previous?.values ?? initial)
                    : value,
            baseline: previous?.baseline ?? baseline,
            step: previous?.step ?? 0,
        }));
    };
    const goTo = (index: number) => {
        if (busy.current) return;
        setDraft((previous) => ({
            values: previous?.values ?? initial,
            baseline: previous?.baseline ?? baseline,
            step: index,
        }));
    };
    const showErrors = (next: Errors) => {
        setErrors(next);
        const first = Object.keys(next)[0]?.split('.')[0];
        const index = first
            ? fields.findIndex((group) => group.includes(first))
            : -1;
        goTo(index < 0 ? 0 : index);
    };
    const close = () => {
        if (!busy.current) leave.request(onClose);
    };
    const submit = (
        event: FormEvent,
        payload: () => Values,
        url: string,
        edit: boolean,
    ) => {
        event.preventDefault();
        if (busy.current || stale) return;
        const next = validate(form);
        if (step < steps.length - 1) {
            const current = Object.fromEntries(
                Object.entries(next).filter(([field]) =>
                    fields[step].includes(field.split('.')[0]),
                ),
            );
            if (Object.keys(current).length) showErrors(current);
            else {
                setErrors({});
                goTo(step + 1);
            }
            return;
        }
        if (Object.keys(next).length) {
            showErrors(next);
            return;
        }
        const data = payload();
        busy.current = true;
        setProcessing(true);
        setErrors({});
        router[edit ? 'put' : 'post'](url, data, {
            preserveScroll: true,
            onError: (nextErrors) => {
                busy.current = false;
                showErrors(nextErrors);
            },
            onSuccess: () => {
                clear();
                if (edit) onClose();
                else setSaved(true);
            },
            onFinish: () => {
                busy.current = false;
                setProcessing(false);
            },
        });
    };
    const editableValues = Object.entries(form)
        .filter(([field]) => field !== 'expected_version')
        .map(([, value]) => value);
    const configured = editableValues.filter(
        (value) =>
            value !== '' &&
            value !== null &&
            value !== undefined &&
            (!Array.isArray(value) || value.length > 0),
    ).length;
    const pct = Math.round((configured / editableValues.length) * 100);
    const reconcile = () => {
        if (busy.current || !draft) return;
        try {
            const original = JSON.parse(draft.baseline) as T;
            const merged = { ...initial };
            for (const field of Object.keys(initial) as (keyof T)[]) {
                if (
                    field !== 'expected_version' &&
                    JSON.stringify(form[field]) !==
                        JSON.stringify(original[field])
                )
                    merged[field] = form[field];
            }
            setDraft({ values: merged, baseline, step: steps.length - 1 });
            setErrors({});
        } catch {
            setErrors({
                save_conflict:
                    'This draft cannot be reconciled. Use the current saved values to continue.',
            });
        }
    };
    return {
        form,
        setForm,
        step,
        goTo,
        errors,
        processing,
        saved,
        stale,
        body,
        close,
        submit,
        pct,
        reconcile,
        confirmation: leave.confirmation,
        restart: () => {
            clear();
            setSaved(false);
        },
        reset: () => leave.request(clear),
        done: onClose,
    };
}

type Wizard = Pick<
    ReturnType<typeof useSettingsWizard>,
    | 'step'
    | 'goTo'
    | 'errors'
    | 'processing'
    | 'saved'
    | 'stale'
    | 'body'
    | 'close'
    | 'confirmation'
    | 'restart'
    | 'reset'
    | 'done'
    | 'pct'
    | 'reconcile'
>;

export function SettingsWizard({
    open,
    title,
    description,
    steps,
    wizard,
    submit,
    currentSaved,
    children,
}: {
    open: boolean;
    title: string;
    description: string;
    steps: readonly WizardStep[];
    wizard: Wizard;
    submit: (event: FormEvent) => void;
    currentSaved?: ReactNode;
    children: ReactNode;
}) {
    const formId = `settings-${steps[0].key}-form`;
    return (
        <>
            <WizardShell
                open={open}
                onClose={wizard.close}
                title={title}
                description={description}
                railIcon={Settings2}
                railTitle={title}
                railSub={description}
                steps={steps.map((step) => ({
                    ...step,
                    disabled: wizard.processing,
                }))}
                stepIndex={wizard.step}
                onStepClick={wizard.goTo}
                sequential={false}
                bodyRef={wizard.body}
                pct={wizard.pct}
                pctLabel="Configured fields"
                frontline
                footerStart={
                    <>
                        <Button
                            type="button"
                            variant="outline"
                            onClick={wizard.close}
                            disabled={wizard.processing}
                        >
                            Cancel
                        </Button>
                        {wizard.step > 0 && (
                            <Button
                                type="button"
                                variant="outline"
                                onClick={() => wizard.goTo(wizard.step - 1)}
                                disabled={wizard.processing}
                            >
                                Back
                            </Button>
                        )}
                    </>
                }
                footerEnd={
                    <Button
                        type="submit"
                        form={formId}
                        disabled={wizard.processing || wizard.stale}
                    >
                        {wizard.processing && (
                            <Loader2 className="mr-2 size-4 animate-spin" />
                        )}
                        {wizard.processing
                            ? 'Saving…'
                            : wizard.step === steps.length - 1
                              ? 'Save settings'
                              : 'Continue'}
                    </Button>
                }
                success={
                    wizard.saved ? (
                        <WizardSuccessPane
                            title="Settings saved"
                            blurb="The saved configuration is available in Settings. Delivery and ownership still depend on current eligible people and actual duty."
                            actions={
                                <>
                                    <Button onClick={wizard.done}>Done</Button>
                                    <Button
                                        variant="outline"
                                        onClick={wizard.restart}
                                    >
                                        Add another
                                    </Button>
                                </>
                            }
                        />
                    ) : undefined
                }
            >
                <WizardStepPane key={wizard.step}>
                    <form
                        id={formId}
                        onSubmit={submit}
                        noValidate
                        className="space-y-5"
                    >
                        {wizard.stale && (
                            <div
                                role="alert"
                                className="rounded-lg border border-status-warning/30 bg-status-warning-bg p-3 text-sm"
                            >
                                <p>
                                    The saved setting changed since this draft.
                                    Your entries are retained. Review the
                                    current saved values before saving.
                                </p>
                                <div className="mt-3">{currentSaved}</div>
                                <p className="mt-3">
                                    Keeping your changed fields adopts newer
                                    saved values for the rest. Review again
                                    before saving.
                                </p>
                                <div className="mt-2 flex flex-wrap gap-2">
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={wizard.reset}
                                    >
                                        Use current saved values
                                    </Button>
                                    <Button
                                        type="button"
                                        variant="outline"
                                        onClick={wizard.reconcile}
                                    >
                                        Keep my changed fields
                                    </Button>
                                </div>
                            </div>
                        )}
                        {Object.keys(wizard.errors).length > 0 && (
                            <div
                                role="alert"
                                className="rounded-lg border border-status-critical/30 bg-status-critical-bg p-3 text-sm"
                            >
                                <p className="font-medium">
                                    Check these entries before saving.
                                </p>
                                <ul className="mt-1 list-inside list-disc">
                                    {Object.entries(wizard.errors).map(
                                        ([key, message]) => (
                                            <li key={key}>{message}</li>
                                        ),
                                    )}
                                </ul>
                            </div>
                        )}
                        <fieldset
                            disabled={wizard.processing}
                            className="min-w-0 space-y-5"
                        >
                            {children}
                        </fieldset>
                    </form>
                </WizardStepPane>
            </WizardShell>
            {wizard.confirmation}
        </>
    );
}

type ControlProps = {
    id: string;
    'aria-invalid': boolean | undefined;
    'aria-describedby': string | undefined;
};
export function SettingsField({
    name,
    label,
    errors,
    children,
    hint,
}: {
    name: string;
    label: string;
    errors: Errors;
    children: (props: ControlProps) => ReactNode;
    hint?: string;
}) {
    const error = Object.entries(errors).find(
        ([key]) => key === name || key.startsWith(`${name}.`),
    )?.[1];
    const id = `setting-${name}`;
    return (
        <div data-field={name} className="space-y-2">
            <Label htmlFor={id}>{label}</Label>
            {children({
                id,
                'aria-invalid': error ? true : undefined,
                'aria-describedby': error
                    ? `${id}-error`
                    : hint
                      ? `${id}-hint`
                      : undefined,
            })}
            {hint && (
                <p id={`${id}-hint`} className="text-xs text-muted-foreground">
                    {hint}
                </p>
            )}
            {error && (
                <p id={`${id}-error`} className="text-sm text-status-critical">
                    {error}
                </p>
            )}
        </div>
    );
}

/** Complete authorised configuration catalog; typed search never becomes a relationship. */
export function SettingsChoice({
    choices,
    selected,
    onChange,
    label,
    multiple = false,
    emptyLabel,
    ...accessibility
}: {
    choices: RoutingChoice[];
    selected: string[];
    onChange: (values: string[]) => void;
    label: string;
    multiple?: boolean;
    emptyLabel: string;
} & ControlProps) {
    const [open, setOpen] = useState(false);
    const known = new Set(choices.map((choice) => choice.value));
    const options = [
        ...choices,
        ...selected
            .filter((value) => !known.has(value))
            .map((value) => ({
                value,
                label: `Unavailable selection: ${value}`,
            })),
    ];
    const display = selected
        .map(
            (value) =>
                options.find((choice) => choice.value === value)?.label ??
                value,
        )
        .join(', ');
    return (
        <Popover open={open} onOpenChange={setOpen}>
            <PopoverTrigger asChild>
                <Button
                    type="button"
                    variant="outline"
                    role="combobox"
                    aria-label={label}
                    aria-expanded={open}
                    {...accessibility}
                    className="min-h-11 w-full justify-between gap-2 text-left font-normal"
                >
                    <span className="min-w-0 truncate">
                        {display || emptyLabel}
                    </span>
                    <ChevronsUpDown className="size-4 shrink-0" />
                </Button>
            </PopoverTrigger>
            <PopoverContent
                align="start"
                className="w-[var(--radix-popover-trigger-width)] min-w-0 p-0"
            >
                <Command
                    onKeyDown={(event) => {
                        if (event.key === 'Enter') event.preventDefault();
                    }}
                >
                    <CommandInput
                        aria-label={`Search ${label.toLowerCase()}`}
                        placeholder="Search choices…"
                    />
                    <CommandList>
                        <CommandEmpty>No matching choices.</CommandEmpty>
                        <CommandGroup>
                            <CommandItem
                                value={`clear ${emptyLabel}`}
                                onSelect={() => {
                                    onChange([]);
                                    setOpen(false);
                                }}
                            >
                                {emptyLabel}
                            </CommandItem>
                            {options.map((choice) => (
                                <CommandItem
                                    key={choice.value}
                                    value={`${choice.label} ${choice.value}`}
                                    onSelect={() => {
                                        onChange(
                                            multiple
                                                ? selected.includes(
                                                      choice.value,
                                                  )
                                                    ? selected.filter(
                                                          (value) =>
                                                              value !==
                                                              choice.value,
                                                      )
                                                    : [
                                                          ...selected,
                                                          choice.value,
                                                      ]
                                                : [choice.value],
                                        );
                                        if (!multiple) setOpen(false);
                                    }}
                                >
                                    <Check
                                        className={`mr-2 size-4 ${selected.includes(choice.value) ? 'opacity-100' : 'opacity-0'}`}
                                    />
                                    {choice.label}
                                </CommandItem>
                            ))}
                        </CommandGroup>
                    </CommandList>
                </Command>
            </PopoverContent>
        </Popover>
    );
}

export function SettingsReview({
    title,
    step,
    wizard,
    rows,
    readOnly = false,
}: {
    title: string;
    step: number;
    wizard: Wizard;
    rows: Record<string, ReactNode>;
    readOnly?: boolean;
}) {
    return (
        <ReviewCard
            icon={Settings2}
            title={title}
            onEdit={readOnly ? undefined : () => wizard.goTo(step)}
        >
            {Object.entries(rows).map(([label, value]) => (
                <ReviewRow key={label} label={label} value={value} />
            ))}
        </ReviewCard>
    );
}

export function requiredText(
    errors: Errors,
    field: string,
    value: string,
    label: string,
    max: number,
) {
    if (!value.trim()) errors[field] = `Enter ${label.toLowerCase()}.`;
    else if (value.length > max)
        errors[field] = `${label} must be ${max} characters or fewer.`;
}
export function boundedInteger(
    errors: Errors,
    field: string,
    value: string,
    label: string,
    min: number,
    max: number,
    optional = false,
) {
    if (optional && value === '') return;
    if (!/^\d+$/.test(value) || Number(value) < min || Number(value) > max)
        errors[field] =
            `${label} must be a whole number from ${min} to ${max}.`;
}
