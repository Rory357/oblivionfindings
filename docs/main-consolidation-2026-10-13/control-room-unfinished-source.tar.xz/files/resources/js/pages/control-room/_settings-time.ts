import { formatDateOnly, workerTimeOffsets } from '@/lib/datetime';

/** A paired Auckland wall time becomes an instant only after DST is resolved. */
export function maintenanceInstant(
    date: string,
    time: string,
    offset: string,
): { iso: string | null; error: string | null } {
    if (!date || !time)
        return { iso: null, error: 'Choose both a date and time.' };
    if (
        !formatDateOnly(date, '') ||
        !/^([01]\d|2[0-3]):[0-5]\d$/.test(time)
    ) {
        return { iso: null, error: 'Choose a valid calendar date and time.' };
    }
    const offsets = workerTimeOffsets(`${date}T${time}`);
    if (!offsets.length)
        return {
            iso: null,
            error: 'This time does not exist in Auckland because the clocks move forward. Choose another time.',
        };
    const chosen = offsets.length === 1 ? offsets[0] : offset;
    if (!offsets.includes(chosen))
        return {
            iso: null,
            error: 'This time occurs twice when the clocks move back. Choose which occurrence to use.',
        };
    return {
        iso: new Date(`${date}T${time}:00${chosen}`).toISOString(),
        error: null,
    };
}
