import {
    act,
    cleanup,
    fireEvent,
    render,
    screen,
    within,
} from '@testing-library/react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { SignalRuleDialog } from './_settings-dialogs';
import type { SignalRuleData } from './_settings-types';

const fixture = vi.hoisted(() => {
    const memory = new Map<string, unknown>();
    return {
        actor: 10,
        memory,
        router: {
            post: vi.fn(),
            put: vi.fn(),
            visit: vi.fn(),
            restore: vi.fn((key = 'default') => memory.get(key)),
            remember: vi.fn((value: unknown, key = 'default') => {
                memory.set(key, value);
            }),
            on: vi.fn(() => () => {}),
        },
    };
});

// Externalised Inertia hooks retain the installed Core singleton. Adapt its
// actual methods so the real useRemember hook and the form share one history.
vi.mock('@inertiajs/react', async () => {
    const actual = await vi.importActual<typeof import('@inertiajs/react')>('@inertiajs/react');
    Object.assign(actual.router, fixture.router);
    return {
        ...actual,
        router: actual.router,
        usePage: () => ({ props: { auth: { user: { id: fixture.actor } } } }),
    };
});

beforeEach(() => {
    fixture.actor = 10;
    fixture.memory.clear();
    vi.clearAllMocks();
});
afterEach(cleanup);

const original: SignalRuleData = {
    id: 41,
    version: 'a'.repeat(64),
    name: 'Existing rule',
    signal_type_id: null,
    signal_type_code: null,
    signal_type_name: null,
    signal_source_id: null,
    signal_source_name: null,
    priority: 50,
    conditions: null,
    output_severity: null,
    output_escalation_level: 0,
    output_tier: 1,
    dedup_window_minutes: null,
    deduplicate: false,
    suppress_in_maintenance: true,
    notify_roles: ['admin'],
    notify_users: [90],
    playbook_id: null,
    playbook_name: null,
    is_active: true,
};
const props = {
    open: true,
    onClose: vi.fn(),
    rule: null as SignalRuleData | null,
    signalTypes: [],
    signalSources: [],
    playbooks: [],
};
const next = () =>
    fireEvent.click(screen.getByRole('button', { name: 'Continue' }));
const review = () => {
    next();
    next();
    next();
};
type ResponseCallbacks = {
    onError: (errors: Record<string, string>) => void;
    onSuccess: () => void;
    onFinish: () => void;
};

describe('Control Room settings wizard', () => {
    it('reviews the complete rule and sends one save without replacing hidden notification routing', () => {
        render(<SignalRuleDialog {...props} rule={original} />);
        expect(fixture.router.restore).toHaveBeenCalledWith('control-room:settings:10:rule:41');
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'Reviewed rule' },
        });
        review();
        fireEvent.click(screen.getByRole('button', { name: 'Save settings' }));
        fireEvent.submit(document.getElementById('settings-rule-match-form')!);
        expect(fixture.router.put).toHaveBeenCalledTimes(1);
        const [url, data] = fixture.router.put.mock.calls[0];
        expect(url).toBe('/control-room/settings/rules/41');
        expect(data).toMatchObject({
            name: 'Reviewed rule',
            output_tier: 1,
            priority: 50,
            deduplicate: false,
        });
        expect(data.expected_version).toBe(original.version);
        expect(data).not.toHaveProperty('notify_roles');
        expect(data).not.toHaveProperty('notify_users');
    });

    it('returns a server validation error to its field while retaining other entered values', () => {
        render(<SignalRuleDialog {...props} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'New rule' },
        });
        fireEvent.change(screen.getByLabelText('Conditions (JSON)'), {
            target: { value: '{"site_id":7}' },
        });
        review();
        fireEvent.click(screen.getByRole('button', { name: 'Save settings' }));
        const callbacks = fixture.router.post.mock
            .calls[0][2] as ResponseCallbacks;
        act(() => {
            callbacks.onError({ name: 'Choose a different rule name.' });
            callbacks.onFinish();
        });
        expect(screen.getByLabelText('Rule name')).toHaveValue('New rule');
        expect(screen.getByLabelText('Rule name')).toHaveFocus();
        expect(screen.getByLabelText('Conditions (JSON)')).toHaveValue(
            '{"site_id":7}',
        );
        expect(screen.getByLabelText('Rule name')).toHaveAttribute(
            'aria-invalid',
            'true',
        );
        expect(props.onClose).not.toHaveBeenCalled();
    });

    it('keeps dirty entries when discard is cancelled and clears only this draft when confirmed', () => {
        const close = vi.fn();
        render(<SignalRuleDialog {...props} rule={original} onClose={close} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'Retain this draft' },
        });
        fireEvent.click(
            screen.getByRole('button', { name: 'Close', exact: true }),
        );
        fireEvent.click(
            within(screen.getByRole('alertdialog')).getByRole('button', {
                name: 'Cancel',
                exact: true,
            }),
        );
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'Retain this draft',
        );
        expect(close).not.toHaveBeenCalled();
        fireEvent.click(
            screen.getByRole('button', { name: 'Close', exact: true }),
        );
        fireEvent.click(
            within(screen.getByRole('alertdialog')).getByRole('button', {
                name: 'Discard and continue',
            }),
        );
        expect(close).toHaveBeenCalledTimes(1);
        expect(
            fixture.memory.get('control-room:settings:10:rule:41'),
        ).toBeNull();
    });

    it('restores a draft only for the exact record it belongs to', () => {
        const view = render(<SignalRuleDialog {...props} rule={original} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'First record draft' },
        });
        view.rerender(
            <SignalRuleDialog
                {...props}
                rule={{ ...original, id: 42, name: 'Second saved rule' }}
            />,
        );
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'Second saved rule',
        );
        view.rerender(<SignalRuleDialog {...props} rule={original} />);
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'First record draft',
        );
    });

    it('does not carry an open draft into another account or save it under that account', () => {
        const view = render(<SignalRuleDialog {...props} rule={original} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'Private first actor draft' },
        });
        fixture.actor = 11;
        view.rerender(<SignalRuleDialog {...props} rule={original} />);
        expect(screen.getByLabelText('Rule name')).toHaveValue('Existing rule');
        expect(
            JSON.stringify(
                fixture.memory.get('control-room:settings:11:rule:41'),
            ),
        ).not.toContain('Private first actor draft');
        fixture.actor = 10;
        view.rerender(<SignalRuleDialog {...props} rule={original} />);
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'Private first actor draft',
        );
    });

    it('requires an explicit review when saved values change beneath a retained draft', () => {
        const view = render(<SignalRuleDialog {...props} rule={original} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'My unsaved rule' },
        });
        view.rerender(
            <SignalRuleDialog
                {...props}
                rule={{ ...original, name: 'Changed by colleague' }}
            />,
        );
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'My unsaved rule',
        );
        expect(screen.getByRole('button', { name: 'Continue' })).toBeDisabled();
        fireEvent.click(
            screen.getByRole('button', { name: 'Use current saved values' }),
        );
        fireEvent.click(
            within(screen.getByRole('alertdialog')).getByRole('button', {
                name: 'Discard and continue',
            }),
        );
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'Changed by colleague',
        );
        expect(screen.getByRole('button', { name: 'Continue' })).toBeEnabled();
    });

    it('preserves a conflicting draft and reconciles changed fields with current values before an explicit retry', () => {
        const view = render(<SignalRuleDialog {...props} rule={original} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'My retained draft' },
        });
        review();
        fireEvent.click(screen.getByRole('button', { name: 'Save settings' }));
        const callbacks = fixture.router.put.mock
            .calls[0][2] as ResponseCallbacks;
        act(() => {
            callbacks.onError({
                save_conflict:
                    'Another reader saved newer settings. Review before retrying.',
            });
            callbacks.onFinish();
        });
        view.rerender(
            <SignalRuleDialog
                {...props}
                rule={{
                    ...original,
                    version: 'b'.repeat(64),
                    name: 'Colleague saved',
                    priority: 15,
                    notify_roles: ['support_worker'],
                    notify_users: [91, 92],
                }}
            />,
        );
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'My retained draft',
        );
        expect(screen.getByText('Colleague saved')).toBeInTheDocument();
        expect(
            screen.getByText('1 roles and 2 named people retained'),
        ).toBeInTheDocument();
        expect(screen.getByRole('button', { name: 'Continue' })).toBeDisabled();
        fireEvent.click(
            screen.getByRole('button', { name: 'Keep my changed fields' }),
        );
        expect(fixture.router.put).toHaveBeenCalledTimes(1);
        expect(screen.getByText('My retained draft')).toBeInTheDocument();
        expect(screen.getByText('15')).toBeInTheDocument();
        fireEvent.click(screen.getByRole('button', { name: 'Save settings' }));
        expect(fixture.router.put).toHaveBeenCalledTimes(2);
        expect(fixture.router.put.mock.calls[1][1]).toMatchObject({
            name: 'My retained draft',
            priority: 15,
            expected_version: 'b'.repeat(64),
        });
        expect(fixture.router.put.mock.calls[1][1]).not.toHaveProperty(
            'notify_users',
        );
        expect(props.onClose).not.toHaveBeenCalled();
    });

    it('retains a failed save for a deliberate retry and clears the draft only after success', () => {
        render(<SignalRuleDialog {...props} rule={original} />);
        fireEvent.change(screen.getByLabelText('Rule name'), {
            target: { value: 'Retry this rule' },
        });
        review();
        fireEvent.click(screen.getByRole('button', { name: 'Save settings' }));
        const failed = fixture.router.put.mock.calls[0][2] as ResponseCallbacks;
        act(() => {
            failed.onError({
                name: 'The save could not complete. Check the name and try again.',
            });
            failed.onFinish();
        });
        expect(screen.getByLabelText('Rule name')).toHaveValue(
            'Retry this rule',
        );
        expect(props.onClose).not.toHaveBeenCalled();
        expect(
            fixture.memory.get('control-room:settings:10:rule:41'),
        ).not.toBeNull();
        review();
        fireEvent.click(screen.getByRole('button', { name: 'Save settings' }));
        expect(fixture.router.put).toHaveBeenCalledTimes(2);
        const successful = fixture.router.put.mock
            .calls[1][2] as ResponseCallbacks;
        act(() => {
            successful.onSuccess();
            successful.onFinish();
        });
        expect(props.onClose).toHaveBeenCalledTimes(1);
        expect(
            fixture.memory.get('control-room:settings:10:rule:41'),
        ).toBeNull();
    });
});
