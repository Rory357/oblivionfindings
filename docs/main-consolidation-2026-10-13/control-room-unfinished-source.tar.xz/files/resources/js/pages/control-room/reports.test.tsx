import { fireEvent, render, screen, within } from '@testing-library/react';
import type { ComponentProps, ReactNode } from 'react';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import ControlRoomReports from './reports';

const state = vi.hoisted(() => ({ url: '/control-room/reports?period=90d', get: vi.fn() }));
vi.mock('@inertiajs/react', () => ({
    Head: () => null,
    usePage: () => ({ url: state.url, props: { auth: { can: { controlRoom: { viewAny: true } } } } }),
    router: { get: state.get, visit: vi.fn() },
    Link: ({ href, children }: { href: string; children: ReactNode }) => <a href={href}>{children}</a>,
}));
vi.mock('@/layouts/app-layout', () => ({ default: ({ children }: { children: ReactNode }) => <>{children}</> }));

const base: ComponentProps<typeof ControlRoomReports> = {
    period: '90d',
    stats: { total_alerts: 40, resolved_alerts: 5, cohort_resolved_alerts: 4, resolution_rate: 10,
        avg_resolution_hours: null, escalated_count: 2, escalation_rate: 5 },
    by_severity: {}, by_status: {}, by_source: {}, by_alert_type: {}, daily_trend: [],
    response_time_by_severity: {}, top_assignees: [],
};

beforeEach(() => { state.url = '/control-room/reports?period=90d'; vi.clearAllMocks(); });

describe('Control Room report figures', () => {
    it('shows every returned date beyond thirty with matching accessible chart and daily figures', () => {
        const trend = Array.from({ length: 40 }, (_, index) => ({
            date: index < 31 ? `2026-01-${String(index + 1).padStart(2, '0')}` : `2026-02-${String(index - 30).padStart(2, '0')}`,
            count: index + 1,
        }));
        render(<ControlRoomReports {...base} daily_trend={trend} />);
        const chart = screen.getByRole('list', { name: 'Daily response counts' });
        expect(within(chart).getAllByRole('listitem')).toHaveLength(40);
        expect(within(chart).getByRole('listitem', { name: '1 Jan 2026: 1 response' })).toBeInTheDocument();
        expect(within(chart).getByRole('listitem', { name: '9 Feb 2026: 40 responses' })).toBeInTheDocument();
        fireEvent.click(screen.getByText('View daily counts'));
        const figures = screen.getByRole('table', { name: 'Daily response figures' });
        expect(within(figures).getAllByRole('row')).toHaveLength(41);
        expect(screen.getByText('All 40 recorded dates in this period are shown.')).toBeInTheDocument();
    });

    it('keeps zero and fractional measurements visible while missing timings stay unmeasured', () => {
        render(<ControlRoomReports {...base} response_time_by_severity={{ critical: 0, high: 3.3, medium: null }} />);
        const timings = screen.getByRole('region', { name: 'Average response time by severity' });
        expect(within(timings).getByText('0 min')).toBeInTheDocument();
        expect(within(timings).getByText('3.3 min')).toBeInTheDocument();
        expect(within(timings).getAllByText('Not measured')).toHaveLength(2);
    });

    it('preserves custom dates and Site scope in export and meter drilldowns', () => {
        state.url = '/control-room/reports?period=custom&date_from=2026-01-01&date_to=2026-02-09&site_id=9';
        render(<ControlRoomReports {...base} period="custom" />);
        expect(screen.getByRole('link', { name: 'Export CSV' })).toHaveAttribute('href',
            '/control-room/reports/export?period=custom&date_from=2026-01-01&date_to=2026-02-09&site_id=9');
        expect(screen.getByRole('link', { name: 'View raised' })).toHaveAttribute('href',
            '/control-room/reports?period=custom&date_from=2026-01-01&date_to=2026-02-09&site_id=9#report-volume');
    });

    it('distinguishes unavailable daily counts from a genuinely empty period without fabricating a zero', () => {
        const view = render(<ControlRoomReports {...base} />);
        expect(screen.getByText('Daily counts are unavailable for this report period.')).toBeInTheDocument();
        expect(screen.queryByRole('list', { name: 'Daily response counts' })).not.toBeInTheDocument();
        expect(within(screen.getByRole('region', { name: 'Average response time by severity' })).getAllByText('Not measured')).toHaveLength(4);
        view.rerender(<ControlRoomReports {...base} stats={{ ...base.stats, total_alerts: 0 }} />);
        expect(screen.getByText('No responses were raised in this report period.')).toBeInTheDocument();
        expect(screen.queryByText('Daily counts are unavailable for this report period.')).not.toBeInTheDocument();
    });
});
