import { afterEach, describe, expect, it } from 'vitest';
import { maintenanceInstant } from './_settings-time';

const originalZone = process.env.TZ;
afterEach(() => {
    process.env.TZ = originalZone;
});

describe('Maintenance window instants', () => {
    it('preserves the chosen Auckland day and exact minute in a different browser timezone', () => {
        process.env.TZ = 'America/Los_Angeles';
        expect(maintenanceInstant('2026-07-15', '00:17', '')).toEqual({
            iso: '2026-07-14T12:17:00.000Z',
            error: null,
        });
    });
    it('uses Auckland summer time for a multi-day interval', () => {
        expect(maintenanceInstant('2026-12-30', '23:59', '').iso).toBe(
            '2026-12-30T10:59:00.000Z',
        );
        expect(maintenanceInstant('2027-01-01', '00:01', '').iso).toBe(
            '2026-12-31T11:01:00.000Z',
        );
    });
    it('rejects a skipped spring time instead of shifting it silently', () => {
        expect(maintenanceInstant('2026-09-27', '02:17', '')).toEqual({
            iso: null,
            error: expect.stringContaining('does not exist'),
        });
    });
    it('requires an explicit occurrence for a repeated autumn time', () => {
        expect(maintenanceInstant('2026-04-05', '02:17', '')).toEqual({
            iso: null,
            error: expect.stringContaining('occurs twice'),
        });
    });
    it('retains either selected autumn occurrence as a different exact instant', () => {
        expect(maintenanceInstant('2026-04-05', '02:17', '+13:00').iso).toBe(
            '2026-04-04T13:17:00.000Z',
        );
        expect(maintenanceInstant('2026-04-05', '02:17', '+12:00').iso).toBe(
            '2026-04-04T14:17:00.000Z',
        );
    });
    it('keeps partial or invalid pairs as drafts without a timestamp', () => {
        for (const [date, time] of [
            ['', '10:10'],
            ['2026-07-15', ''],
            ['2026-02-30', '10:10'],
            ['2026-07-15', '24:00'],
        ]) {
            expect(maintenanceInstant(date, time, '').iso).toBeNull();
        }
    });
});
