export interface SignalTypeOption {
    id: number;
    code: string;
    name: string;
    category: string;
    default_severity: string;
}

export interface SignalSourceOption {
    id: number;
    name: string;
    slug: string;
    vendor: string;
    status: 'active' | 'inactive' | 'maintenance';
    capabilities: string[];
    last_heartbeat_at: string | null;
    last_signal_at: string | null;
    signal_count_24h: number;
    is_healthy: boolean;
}

export interface SignalRuleData {
    id: number;
    version: string;
    name: string;
    signal_type_id: number | null;
    signal_type_code: string | null;
    signal_type_name: string | null;
    signal_source_id: number | null;
    signal_source_name: string | null;
    priority: number;
    conditions: Record<string, unknown> | null;
    output_severity: string | null;
    output_escalation_level: number | null;
    output_tier: number | null;
    dedup_window_minutes: number | null;
    deduplicate: boolean;
    suppress_in_maintenance: boolean;
    notify_roles: string[];
    notify_users: number[];
    playbook_id: number | null;
    playbook_name: string | null;
    is_active: boolean;
}

export interface TriageQueueData {
    id: number;
    version: string;
    name: string;
    code: string;
    tier: number;
    description: string | null;
    handle_severities: string[];
    handle_sources: string[];
    handle_alert_types: string[];
    assigned_roles: string[];
    assigned_users: number[];
    auto_escalate_after_minutes: number | null;
    escalate_to_queue_id: number | null;
    escalate_to_queue_name: string | null;
    is_active: boolean;
    open_alert_count: number;
}

export interface MaintenanceWindowData {
    id: number;
    version: string;
    name: string;
    description: string | null;
    signal_source_id: number | null;
    signal_source_name: string | null;
    site_id: number | null;
    starts_at: string;
    ends_at: string;
    status: 'scheduled' | 'active' | 'completed' | 'cancelled';
    created_by_name: string | null;
}

export interface PlaybookOption {
    id: number;
    name: string;
    code: string;
}

export interface SiteOption {
    id: number;
    name: string;
}

export interface RoutingChoice {
    value: string;
    label: string;
}
