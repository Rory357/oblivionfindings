import { ConfirmDialog } from '@/components/confirm-dialog';
import { DatePicker } from '@/components/fleet-assets/maintenance/date-picker';
import { TimePicker } from '@/components/fleet-assets/maintenance/time-picker';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import type { WizardStep } from '@/components/wizard/shell';
import {
    formatDateTime,
    toDatetimeLocal,
    WORKER_TIMEZONE,
    workerTimeOffset,
    workerTimeOffsets,
} from '@/lib/datetime';
import type { SharedData } from '@/types';
import { usePage } from '@inertiajs/react';
import {
    AlertTriangle,
    Check,
    Clock3,
    Filter,
    ListFilter,
    Settings2,
} from 'lucide-react';
import type { FormEvent } from 'react';
import { maintenanceInstant } from './_settings-time';
import type {
    MaintenanceWindowData,
    PlaybookOption,
    RoutingChoice,
    SignalRuleData,
    SignalSourceOption,
    SignalTypeOption,
    SiteOption,
    TriageQueueData,
} from './_settings-types';
import {
    boundedInteger,
    requiredText,
    SettingsChoice,
    SettingsField,
    SettingsReview,
    SettingsWizard,
    useSettingsWizard,
} from './_settings-wizard';

const SEVERITIES = [
    { value: '', label: 'Inherit', description: 'Keep the signal severity.' },
    { value: 'low', label: 'Low', description: 'Routine response.' },
    {
        value: 'medium',
        label: 'Medium',
        description: 'Needs timely attention.',
    },
    { value: 'high', label: 'High', description: 'Needs urgent attention.' },
    {
        value: 'critical',
        label: 'Critical',
        description: 'Immediate response.',
    },
] as const;
const RULE_STEPS: readonly WizardStep[] = [
    {
        key: 'rule-match',
        label: 'Match signals',
        blurb: 'Name, source and conditions',
        icon: Filter,
    },
    {
        key: 'rule-response',
        label: 'Response',
        blurb: 'Severity, tier and playbook',
        icon: AlertTriangle,
    },
    {
        key: 'rule-processing',
        label: 'Processing',
        blurb: 'Duplicates and maintenance',
        icon: Settings2,
    },
    {
        key: 'rule-review',
        label: 'Review',
        blurb: 'Check before saving',
        icon: Check,
    },
];
const RULE_FIELDS = [
    [
        'name',
        'signal_type_id',
        'signal_type_code',
        'signal_source_id',
        'conditions',
    ],
    [
        'priority',
        'output_severity',
        'output_escalation_level',
        'output_tier',
        'playbook_id',
    ],
    [
        'dedup_window_minutes',
        'deduplicate',
        'suppress_in_maintenance',
        'is_active',
        'notify_roles',
        'notify_users',
    ],
    [],
] as const;
const QUEUE_STEPS: readonly WizardStep[] = [
    {
        key: 'queue-details',
        label: 'Details',
        blurb: 'Name, code and tier',
        icon: ListFilter,
    },
    {
        key: 'queue-routing',
        label: 'Routing',
        blurb: 'Sources and eligible roles',
        icon: Filter,
    },
    {
        key: 'queue-escalation',
        label: 'Escalation',
        blurb: 'Timing and destination',
        icon: Clock3,
    },
    {
        key: 'queue-review',
        label: 'Review',
        blurb: 'Check before saving',
        icon: Check,
    },
];
const QUEUE_FIELDS = [
    ['name', 'code', 'tier', 'description'],
    [
        'handle_severities',
        'handle_sources',
        'handle_alert_types',
        'assigned_roles',
        'assigned_users',
    ],
    ['auto_escalate_after_minutes', 'escalate_to_queue_id', 'is_active'],
    [],
] as const;
const WINDOW_STEPS: readonly WizardStep[] = [
    {
        key: 'maintenance-scope',
        label: 'Scope',
        blurb: 'Name, source and site',
        icon: Filter,
    },
    {
        key: 'maintenance-time',
        label: 'When',
        blurb: 'Start and end in Auckland time',
        icon: Clock3,
    },
    {
        key: 'maintenance-review',
        label: 'Review',
        blurb: 'Check scope and interval',
        icon: Check,
    },
];
const WINDOW_FIELDS = [
    ['name', 'description', 'signal_source_id', 'site_id'],
    ['starts_at', 'ends_at'],
    [],
] as const;
const catalog = (rows: { id: number; name: string }[]): RoutingChoice[] =>
    rows.map((row) => ({ value: String(row.id), label: row.name }));
const labelFor = (value: string, choices: RoutingChoice[], fallback: string) =>
    value
        ? (choices.find((choice) => choice.value === value)?.label ??
          'Unavailable selection')
        : fallback;
const describeChoices = (
    values: string[],
    choices: RoutingChoice[],
    fallback: string,
) =>
    values.length
        ? values.map((value) => labelFor(value, choices, '')).join(', ')
        : fallback;

function Toggle({
    id,
    label,
    checked,
    onChange,
}: {
    id: string;
    label: string;
    checked: boolean;
    onChange: (value: boolean) => void;
}) {
    return (
        <div className="flex min-h-11 items-center gap-3">
            <Switch id={id} checked={checked} onCheckedChange={onChange} />
            <Label
                htmlFor={id}
                className="frontline-tap inline-flex cursor-pointer items-center"
            >
                {label}
            </Label>
        </div>
    );
}

export function SignalRuleDialog({
    open,
    onClose,
    rule,
    signalTypes,
    signalSources,
    playbooks,
}: {
    open: boolean;
    onClose: () => void;
    rule: SignalRuleData | null;
    signalTypes: SignalTypeOption[];
    signalSources: SignalSourceOption[];
    playbooks: PlaybookOption[];
}) {
    const actor = usePage<SharedData>().props.auth.user.id;
    return open ? (
        <SignalRuleBody
            key={`${actor}:${rule?.id ?? 'new'}`}
            open={open}
            onClose={onClose}
            rule={rule}
            signalTypes={signalTypes}
            signalSources={signalSources}
            playbooks={playbooks}
        />
    ) : null;
}

function SignalRuleBody({
    open,
    onClose,
    rule,
    signalTypes,
    signalSources,
    playbooks,
}: Parameters<typeof SignalRuleDialog>[0]) {
    const initial = {
        expected_version: rule?.version ?? '',
        name: rule?.name ?? '',
        signal_type_id: rule?.signal_type_id?.toString() ?? '',
        signal_source_id: rule?.signal_source_id?.toString() ?? '',
        priority: rule?.priority?.toString() ?? '100',
        conditions: rule?.conditions
            ? JSON.stringify(rule.conditions, null, 2)
            : '',
        output_severity: rule?.output_severity ?? '',
        output_escalation_level:
            rule?.output_escalation_level?.toString() ?? '0',
        output_tier: rule?.output_tier?.toString() ?? '1',
        dedup_window_minutes: rule?.dedup_window_minutes?.toString() ?? '',
        deduplicate: rule?.deduplicate ?? false,
        suppress_in_maintenance: rule?.suppress_in_maintenance ?? true,
        playbook_id: rule?.playbook_id?.toString() ?? '',
        is_active: rule?.is_active ?? true,
    };
    const wizard = useSettingsWizard(
        'rule',
        rule?.id,
        initial,
        onClose,
        RULE_STEPS,
        RULE_FIELDS,
        (values) => {
            const errors: Record<string, string> = {};
            requiredText(errors, 'name', values.name, 'Rule name', 255);
            boundedInteger(
                errors,
                'priority',
                values.priority,
                'Rule priority',
                0,
                1000,
            );
            boundedInteger(
                errors,
                'output_escalation_level',
                values.output_escalation_level,
                'Escalation level',
                0,
                10,
                true,
            );
            boundedInteger(
                errors,
                'output_tier',
                values.output_tier,
                'Output tier',
                1,
                5,
                true,
            );
            boundedInteger(
                errors,
                'dedup_window_minutes',
                values.dedup_window_minutes,
                'Deduplication window',
                0,
                10080,
                true,
            );
            if (values.conditions.trim()) {
                try {
                    const conditions: unknown = JSON.parse(values.conditions);
                    if (conditions === null || typeof conditions !== 'object')
                        throw new Error('Expected an object or array');
                } catch {
                    errors.conditions =
                        'Enter a JSON object or array for the conditions, or leave them blank.';
                }
            }
            return errors;
        },
    );
    const { form, setForm, errors } = wizard;
    const types = catalog(signalTypes);
    const sources = catalog(signalSources);
    const books = catalog(playbooks);
    const submit = (event: FormEvent) =>
        wizard.submit(
            event,
            () => ({
                name: form.name,
                signal_type_id: form.signal_type_id
                    ? Number(form.signal_type_id)
                    : null,
                ...(rule ? { expected_version: form.expected_version } : {}),
                signal_type_code: form.signal_type_id
                    ? (signalTypes.find(
                          (type) => type.id === Number(form.signal_type_id),
                      )?.code ??
                      (form.signal_type_id === initial.signal_type_id
                          ? (rule?.signal_type_code ?? null)
                          : null))
                    : null,
                signal_source_id: form.signal_source_id
                    ? Number(form.signal_source_id)
                    : null,
                priority: Number(form.priority),
                conditions: form.conditions.trim()
                    ? JSON.parse(form.conditions)
                    : null,
                output_severity: form.output_severity || null,
                output_escalation_level: form.output_escalation_level
                    ? Number(form.output_escalation_level)
                    : null,
                output_tier: form.output_tier ? Number(form.output_tier) : null,
                dedup_window_minutes: form.dedup_window_minutes
                    ? Number(form.dedup_window_minutes)
                    : null,
                deduplicate: form.deduplicate,
                suppress_in_maintenance: form.suppress_in_maintenance,
                playbook_id: form.playbook_id ? Number(form.playbook_id) : null,
                is_active: form.is_active,
                // Existing notification candidacy is retained by the update endpoint; this form does not replace it.
            }),
            rule
                ? `/control-room/settings/rules/${rule.id}`
                : '/control-room/settings/rules',
            !!rule,
        );
    return (
        <SettingsWizard
            open={open}
            title={rule ? 'Edit signal rule' : 'Create signal rule'}
            description="Choose which signals match and how their responses are configured."
            steps={RULE_STEPS}
            wizard={wizard}
            submit={submit}
            currentSaved={
                <SettingsReview
                    readOnly
                    title="Current saved rule"
                    step={0}
                    wizard={wizard}
                    rows={{
                        Name: initial.name,
                        Type: labelFor(
                            initial.signal_type_id,
                            types,
                            'Any type',
                        ),
                        Source: labelFor(
                            initial.signal_source_id,
                            sources,
                            'Any source',
                        ),
                        Conditions:
                            initial.conditions || 'No additional conditions',
                        Priority: initial.priority,
                        Severity: initial.output_severity || 'Inherit',
                        Tier: initial.output_tier,
                        'Escalation level': initial.output_escalation_level,
                        Playbook: labelFor(
                            initial.playbook_id,
                            books,
                            'No playbook',
                        ),
                        'Duplicate window':
                            initial.dedup_window_minutes || 'Source default',
                        Deduplicate: initial.deduplicate ? 'Yes' : 'No',
                        'Maintenance suppression':
                            initial.suppress_in_maintenance ? 'Yes' : 'No',
                        Enabled: initial.is_active ? 'Yes' : 'No',
                        'Notification routing': `${rule?.notify_roles.length ?? 0} roles and ${rule?.notify_users.length ?? 0} named people retained`,
                    }}
                />
            }
        >
            {wizard.step === 0 && (
                <>
                    <SettingsField
                        name="name"
                        label="Rule name"
                        errors={errors}
                    >
                        {(props) => (
                            <Input
                                {...props}
                                value={form.name}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        name: event.target.value,
                                    })
                                }
                                required
                            />
                        )}
                    </SettingsField>
                    <div className="grid gap-4 sm:grid-cols-2">
                        <SettingsField
                            name="signal_type_id"
                            label="Signal type"
                            errors={errors}
                        >
                            {(props) => (
                                <SettingsChoice
                                    {...props}
                                    label="Signal type"
                                    choices={types}
                                    selected={
                                        form.signal_type_id
                                            ? [form.signal_type_id]
                                            : []
                                    }
                                    emptyLabel="Any type"
                                    onChange={(values) =>
                                        setForm({
                                            ...form,
                                            signal_type_id: values[0] ?? '',
                                        })
                                    }
                                />
                            )}
                        </SettingsField>
                        <SettingsField
                            name="signal_source_id"
                            label="Signal source"
                            errors={errors}
                        >
                            {(props) => (
                                <SettingsChoice
                                    {...props}
                                    label="Signal source"
                                    choices={sources}
                                    selected={
                                        form.signal_source_id
                                            ? [form.signal_source_id]
                                            : []
                                    }
                                    emptyLabel="Any source"
                                    onChange={(values) =>
                                        setForm({
                                            ...form,
                                            signal_source_id: values[0] ?? '',
                                        })
                                    }
                                />
                            )}
                        </SettingsField>
                    </div>
                    <SettingsField
                        name="conditions"
                        label="Conditions (JSON)"
                        errors={errors}
                        hint="Optional structured conditions for this signal rule."
                    >
                        {(props) => (
                            <Textarea
                                {...props}
                                rows={5}
                                className="font-mono text-sm"
                                value={form.conditions}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        conditions: event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                </>
            )}
            {wizard.step === 1 && (
                <>
                    <SettingsField
                        name="output_severity"
                        label="Output severity"
                        errors={errors}
                    >
                        {(props) => (
                            <div
                                id={props.id}
                                role="group"
                                aria-label="Output severity"
                                aria-describedby={props['aria-describedby']}
                                className="grid grid-cols-2 gap-2 sm:grid-cols-3"
                            >
                                {SEVERITIES.map((choice) => (
                                    <Button
                                        key={choice.value}
                                        type="button"
                                        variant="outline"
                                        aria-pressed={
                                            form.output_severity ===
                                            choice.value
                                        }
                                        onClick={() =>
                                            setForm({
                                                ...form,
                                                output_severity: choice.value,
                                            })
                                        }
                                        className={`h-auto min-h-16 justify-start gap-2 p-3 text-left whitespace-normal ${form.output_severity === choice.value ? 'border-primary bg-primary/10 ring-1 ring-primary/40' : ''}`}
                                    >
                                        <AlertTriangle className="size-4 shrink-0 text-primary" />
                                        <span>
                                            <span className="block font-medium">
                                                {choice.label}
                                            </span>
                                            <span className="block text-xs font-normal text-muted-foreground">
                                                {choice.description}
                                            </span>
                                        </span>
                                    </Button>
                                ))}
                            </div>
                        )}
                    </SettingsField>
                    <div className="grid gap-4 sm:grid-cols-3">
                        {(
                            [
                                {
                                    name: 'priority',
                                    label: 'Rule priority',
                                    min: 0,
                                    max: 1000,
                                },
                                {
                                    name: 'output_escalation_level',
                                    label: 'Escalation level',
                                    min: 0,
                                    max: 10,
                                },
                                {
                                    name: 'output_tier',
                                    label: 'Output tier',
                                    min: 1,
                                    max: 5,
                                },
                            ] as const
                        ).map((field) => (
                            <SettingsField
                                key={field.name}
                                name={field.name}
                                label={field.label}
                                errors={errors}
                            >
                                {(props) => (
                                    <Input
                                        {...props}
                                        type="number"
                                        min={field.min}
                                        max={field.max}
                                        value={form[field.name]}
                                        onChange={(event) =>
                                            setForm({
                                                ...form,
                                                [field.name]:
                                                    event.target.value,
                                            })
                                        }
                                    />
                                )}
                            </SettingsField>
                        ))}
                    </div>
                    <SettingsField
                        name="playbook_id"
                        label="Playbook"
                        errors={errors}
                    >
                        {(props) => (
                            <SettingsChoice
                                {...props}
                                label="Playbook"
                                choices={books}
                                selected={
                                    form.playbook_id ? [form.playbook_id] : []
                                }
                                emptyLabel="No playbook"
                                onChange={(values) =>
                                    setForm({
                                        ...form,
                                        playbook_id: values[0] ?? '',
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                </>
            )}
            {wizard.step === 2 && (
                <>
                    <SettingsField
                        name="dedup_window_minutes"
                        label="Deduplication window (minutes)"
                        errors={errors}
                    >
                        {(props) => (
                            <Input
                                {...props}
                                type="number"
                                min={0}
                                max={10080}
                                value={form.dedup_window_minutes}
                                placeholder="Use the source default"
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        dedup_window_minutes:
                                            event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                    <Toggle
                        id="rule-deduplicate"
                        label="Deduplicate matching signals"
                        checked={form.deduplicate}
                        onChange={(value) =>
                            setForm({ ...form, deduplicate: value })
                        }
                    />
                    <Toggle
                        id="rule-maintenance"
                        label="Suppress during applicable maintenance"
                        checked={form.suppress_in_maintenance}
                        onChange={(value) =>
                            setForm({ ...form, suppress_in_maintenance: value })
                        }
                    />
                    <Toggle
                        id="rule-enabled"
                        label="Rule enabled"
                        checked={form.is_active}
                        onChange={(value) =>
                            setForm({ ...form, is_active: value })
                        }
                    />
                    <p className="text-sm text-muted-foreground">
                        Existing notification routing is retained:{' '}
                        {rule?.notify_roles.length ?? 0} configured roles and{' '}
                        {rule?.notify_users.length ?? 0} named people. Each
                        recipient is checked against current staff, site and
                        source access when a message is sent.
                    </p>
                </>
            )}
            {wizard.step === 3 && (
                <div className="grid gap-4 sm:grid-cols-2">
                    <SettingsReview
                        title="Match signals"
                        step={0}
                        wizard={wizard}
                        rows={{
                            Name: form.name,
                            Type: labelFor(
                                form.signal_type_id,
                                types,
                                'Any type',
                            ),
                            Source: labelFor(
                                form.signal_source_id,
                                sources,
                                'Any source',
                            ),
                            Conditions:
                                form.conditions || 'No additional conditions',
                        }}
                    />
                    <SettingsReview
                        title="Response"
                        step={1}
                        wizard={wizard}
                        rows={{
                            Severity: SEVERITIES.find(
                                (choice) =>
                                    choice.value === form.output_severity,
                            )?.label,
                            Priority: form.priority,
                            'Escalation level':
                                form.output_escalation_level || 'No override',
                            Tier: form.output_tier || 'No override',
                            Playbook: labelFor(
                                form.playbook_id,
                                books,
                                'No playbook',
                            ),
                        }}
                    />
                    <SettingsReview
                        title="Processing"
                        step={2}
                        wizard={wizard}
                        rows={{
                            Deduplicate: form.deduplicate ? 'Yes' : 'No',
                            'Duplicate window': form.dedup_window_minutes
                                ? `${form.dedup_window_minutes} minutes`
                                : 'Source default',
                            'Maintenance suppression':
                                form.suppress_in_maintenance ? 'Yes' : 'No',
                            Enabled: form.is_active ? 'Yes' : 'No',
                            'Notification routing':
                                'Existing recipients retained',
                        }}
                    />
                </div>
            )}
        </SettingsWizard>
    );
}

export function TriageQueueDialog({
    open,
    ...props
}: {
    open: boolean;
    onClose: () => void;
    queue: TriageQueueData | null;
    allQueues: TriageQueueData[];
    sourceChoices: RoutingChoice[];
    roleChoices: RoutingChoice[];
}) {
    const actor = usePage<SharedData>().props.auth.user.id;
    return open ? (
        <TriageQueueBody
            key={`${actor}:${props.queue?.id ?? 'new'}`}
            open={open}
            {...props}
        />
    ) : null;
}

function TriageQueueBody({
    open,
    onClose,
    queue,
    allQueues,
    sourceChoices,
    roleChoices,
}: Parameters<typeof TriageQueueDialog>[0]) {
    const initial = {
        expected_version: queue?.version ?? '',
        name: queue?.name ?? '',
        code: queue?.code ?? '',
        tier: queue?.tier?.toString() ?? '1',
        description: queue?.description ?? '',
        handle_severities: queue?.handle_severities ?? [],
        handle_sources: queue?.handle_sources ?? [],
        assigned_roles: queue?.assigned_roles ?? [],
        auto_escalate_after_minutes:
            queue?.auto_escalate_after_minutes?.toString() ?? '',
        escalate_to_queue_id: queue?.escalate_to_queue_id?.toString() ?? '',
        is_active: queue?.is_active ?? true,
    };
    const wizard = useSettingsWizard(
        'queue',
        queue?.id,
        initial,
        onClose,
        QUEUE_STEPS,
        QUEUE_FIELDS,
        (values) => {
            const errors: Record<string, string> = {};
            requiredText(errors, 'name', values.name, 'Queue name', 255);
            requiredText(errors, 'code', values.code, 'Queue code', 50);
            boundedInteger(errors, 'tier', values.tier, 'Queue tier', 1, 5);
            boundedInteger(
                errors,
                'auto_escalate_after_minutes',
                values.auto_escalate_after_minutes,
                'Escalation delay',
                1,
                10080,
                true,
            );
            if (values.description.length > 500)
                errors.description =
                    'Keep the queue description to 500 characters or fewer.';
            if (
                values.auto_escalate_after_minutes &&
                !values.escalate_to_queue_id
            )
                errors.escalate_to_queue_id =
                    'Choose a destination queue for automatic escalation.';
            return errors;
        },
    );
    const { form, setForm, errors } = wizard;
    const destinations = catalog(
        allQueues.filter((row) => row.id !== queue?.id && row.is_active),
    );
    const submit = (event: FormEvent) =>
        wizard.submit(
            event,
            () => ({
                ...form,
                tier: Number(form.tier),
                description: form.description || null,
                auto_escalate_after_minutes: form.auto_escalate_after_minutes
                    ? Number(form.auto_escalate_after_minutes)
                    : null,
                escalate_to_queue_id: form.escalate_to_queue_id
                    ? Number(form.escalate_to_queue_id)
                    : null,
                // Existing named candidates and alert-type restrictions are not replaced by this form.
            }),
            queue
                ? `/control-room/settings/queues/${queue.id}`
                : '/control-room/settings/queues',
            !!queue,
        );
    return (
        <SettingsWizard
            open={open}
            title={queue ? 'Edit triage queue' : 'Create triage queue'}
            description="Configure which responses enter this queue and how they escalate."
            steps={QUEUE_STEPS}
            wizard={wizard}
            submit={submit}
            currentSaved={
                <SettingsReview
                    readOnly
                    title="Current saved queue"
                    step={0}
                    wizard={wizard}
                    rows={{
                        Name: initial.name,
                        Code: initial.code,
                        Tier: initial.tier,
                        Description: initial.description,
                        Severities:
                            initial.handle_severities.join(', ') ||
                            'All severities',
                        Sources: describeChoices(
                            initial.handle_sources,
                            sourceChoices,
                            'All sources',
                        ),
                        Roles: describeChoices(
                            initial.assigned_roles,
                            roleChoices,
                            'No role preference',
                        ),
                        'Named candidates': `${queue?.assigned_users.length ?? 0} retained`,
                        'Alert types':
                            queue?.handle_alert_types.join(', ') || 'All types',
                        'Escalation delay':
                            initial.auto_escalate_after_minutes || 'Disabled',
                        Destination: labelFor(
                            initial.escalate_to_queue_id,
                            destinations,
                            'No destination',
                        ),
                        Enabled: initial.is_active ? 'Yes' : 'No',
                    }}
                />
            }
        >
            {wizard.step === 0 && (
                <>
                    <div className="grid gap-4 sm:grid-cols-2">
                        {(['name', 'code'] as const).map((name) => (
                            <SettingsField
                                key={name}
                                name={name}
                                label={
                                    name === 'name'
                                        ? 'Queue name'
                                        : 'Queue code'
                                }
                                errors={errors}
                            >
                                {(props) => (
                                    <Input
                                        {...props}
                                        required
                                        value={form[name]}
                                        onChange={(event) =>
                                            setForm({
                                                ...form,
                                                [name]: event.target.value,
                                            })
                                        }
                                    />
                                )}
                            </SettingsField>
                        ))}
                    </div>
                    <SettingsField
                        name="tier"
                        label="Queue tier"
                        errors={errors}
                    >
                        {(props) => (
                            <Input
                                {...props}
                                type="number"
                                min={1}
                                max={5}
                                required
                                value={form.tier}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        tier: event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                    <SettingsField
                        name="description"
                        label="Queue description"
                        errors={errors}
                    >
                        {(props) => (
                            <Textarea
                                {...props}
                                rows={3}
                                value={form.description}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        description: event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                </>
            )}
            {wizard.step === 1 && (
                <>
                    <SettingsField
                        name="handle_severities"
                        label="Handle severities"
                        errors={errors}
                        hint="Leave all clear to accept every severity."
                    >
                        {(props) => (
                            <div
                                id={props.id}
                                role="group"
                                aria-label="Handle severities"
                                className="grid grid-cols-2 gap-3 sm:grid-cols-3"
                            >
                                {SEVERITIES.filter(
                                    (choice) => choice.value,
                                ).map((choice) => (
                                    <label
                                        key={choice.value}
                                        className="frontline-tap flex cursor-pointer items-center gap-2 text-sm"
                                    >
                                        <Checkbox
                                            aria-label={`Handle ${choice.label.toLowerCase()} severity`}
                                            checked={form.handle_severities.includes(
                                                choice.value,
                                            )}
                                            onCheckedChange={(checked) =>
                                                setForm({
                                                    ...form,
                                                    handle_severities: checked
                                                        ? [
                                                              ...form.handle_severities,
                                                              choice.value,
                                                          ]
                                                        : form.handle_severities.filter(
                                                              (value) =>
                                                                  value !==
                                                                  choice.value,
                                                          ),
                                                })
                                            }
                                        />
                                        {choice.label}
                                    </label>
                                ))}
                            </div>
                        )}
                    </SettingsField>
                    <SettingsField
                        name="handle_sources"
                        label="Handle sources"
                        errors={errors}
                    >
                        {(props) => (
                            <SettingsChoice
                                {...props}
                                label="Handled sources"
                                multiple
                                choices={sourceChoices}
                                selected={form.handle_sources}
                                emptyLabel="All sources"
                                onChange={(values) =>
                                    setForm({ ...form, handle_sources: values })
                                }
                            />
                        )}
                    </SettingsField>
                    <SettingsField
                        name="assigned_roles"
                        label="Candidate roles"
                        errors={errors}
                        hint="Roles suggest candidates. Automatic ownership still requires current response access, approved site and actual Control Room duty."
                    >
                        {(props) => (
                            <SettingsChoice
                                {...props}
                                label="Candidate roles"
                                multiple
                                choices={roleChoices}
                                selected={form.assigned_roles}
                                emptyLabel="No role preference"
                                onChange={(values) =>
                                    setForm({ ...form, assigned_roles: values })
                                }
                            />
                        )}
                    </SettingsField>
                    <p className="text-sm text-muted-foreground">
                        Existing alert-type restrictions (
                        {queue?.handle_alert_types.length ?? 0}) and named
                        candidates ({queue?.assigned_users.length ?? 0}) are
                        retained.
                    </p>
                </>
            )}
            {wizard.step === 2 && (
                <>
                    <SettingsField
                        name="auto_escalate_after_minutes"
                        label="Auto-escalate after (minutes)"
                        errors={errors}
                        hint="Leave blank to disable automatic escalation."
                    >
                        {(props) => (
                            <Input
                                {...props}
                                type="number"
                                min={1}
                                max={10080}
                                value={form.auto_escalate_after_minutes}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        auto_escalate_after_minutes:
                                            event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                    <SettingsField
                        name="escalate_to_queue_id"
                        label="Escalation queue"
                        errors={errors}
                    >
                        {(props) => (
                            <SettingsChoice
                                {...props}
                                label="Escalation queue"
                                choices={destinations}
                                selected={
                                    form.escalate_to_queue_id
                                        ? [form.escalate_to_queue_id]
                                        : []
                                }
                                emptyLabel="No destination"
                                onChange={(values) =>
                                    setForm({
                                        ...form,
                                        escalate_to_queue_id: values[0] ?? '',
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                    <Toggle
                        id="queue-enabled"
                        label="Queue enabled"
                        checked={form.is_active}
                        onChange={(value) =>
                            setForm({ ...form, is_active: value })
                        }
                    />
                </>
            )}
            {wizard.step === 3 && (
                <div className="grid gap-4 sm:grid-cols-2">
                    <SettingsReview
                        title="Details"
                        step={0}
                        wizard={wizard}
                        rows={{
                            Name: form.name,
                            Code: form.code,
                            Tier: form.tier,
                            Description: form.description,
                        }}
                    />
                    <SettingsReview
                        title="Routing"
                        step={1}
                        wizard={wizard}
                        rows={{
                            Severities:
                                form.handle_severities.join(', ') ||
                                'All severities',
                            Sources: describeChoices(
                                form.handle_sources,
                                sourceChoices,
                                'All sources',
                            ),
                            Roles: describeChoices(
                                form.assigned_roles,
                                roleChoices,
                                'No role preference',
                            ),
                            'Alert types':
                                queue?.handle_alert_types.join(', ') ||
                                'All types',
                            'Named candidates': `${queue?.assigned_users.length ?? 0} retained`,
                        }}
                    />
                    <SettingsReview
                        title="Escalation"
                        step={2}
                        wizard={wizard}
                        rows={{
                            Delay: form.auto_escalate_after_minutes
                                ? `${form.auto_escalate_after_minutes} minutes`
                                : 'Disabled',
                            Destination: labelFor(
                                form.escalate_to_queue_id,
                                destinations,
                                'No destination',
                            ),
                            Enabled: form.is_active ? 'Yes' : 'No',
                        }}
                    />
                </div>
            )}
        </SettingsWizard>
    );
}

function MaintenanceTimestamp({
    name,
    label,
    date,
    time,
    offset,
    error,
    onChange,
}: {
    name: string;
    label: string;
    date: string;
    time: string;
    offset: string;
    error?: string;
    onChange: (date: string, time: string, offset: string) => void;
}) {
    const offsets = date && time ? workerTimeOffsets(`${date}T${time}`) : [];
    return (
        <fieldset data-field={name} className="space-y-2">
            <legend className="text-sm font-medium">
                {label} · {WORKER_TIMEZONE}
            </legend>
            <div className="grid gap-3 sm:grid-cols-2">
                <DatePicker
                    compact
                    id={`maintenance-${name}-date`}
                    label={`${label} date`}
                    value={date}
                    onChange={(value) => onChange(value, time, '')}
                    invalid={!!error}
                    describedBy={error ? `${name}-error` : undefined}
                    timeZone={WORKER_TIMEZONE}
                />
                <TimePicker
                    compact
                    id={`maintenance-${name}-time`}
                    label={`${label} time`}
                    value={time}
                    onChange={(value) => onChange(date, value, '')}
                    invalid={!!error}
                    describedBy={error ? `${name}-error` : undefined}
                    timezone={WORKER_TIMEZONE}
                />
            </div>
            {offsets.length > 1 && (
                <SettingsChoice
                    id={`maintenance-${name}-occurrence`}
                    label={`${label} occurrence`}
                    selected={offset ? [offset] : []}
                    choices={offsets.map((value, index) => ({
                        value,
                        label: `${index === 0 ? 'First' : 'Second'} occurrence (UTC${value})`,
                    }))}
                    onChange={(values) => onChange(date, time, values[0] ?? '')}
                    emptyLabel="Choose an occurrence"
                    aria-invalid={!!error || undefined}
                    aria-describedby={error ? `${name}-error` : undefined}
                />
            )}
            {error && (
                <p
                    id={`${name}-error`}
                    className="text-sm text-status-critical"
                >
                    {error}
                </p>
            )}
        </fieldset>
    );
}

export function MaintenanceWindowDialog({
    open,
    ...props
}: {
    open: boolean;
    onClose: () => void;
    window: MaintenanceWindowData | null;
    signalSources: SignalSourceOption[];
    sites: SiteOption[];
    canScheduleAllSites: boolean;
}) {
    const actor = usePage<SharedData>().props.auth.user.id;
    return open ? (
        <MaintenanceWindowBody
            key={`${actor}:${props.window?.id ?? 'new'}`}
            open={open}
            {...props}
        />
    ) : null;
}

function MaintenanceWindowBody({
    open,
    onClose,
    window: record,
    signalSources,
    sites,
    canScheduleAllSites,
}: Parameters<typeof MaintenanceWindowDialog>[0]) {
    const start = toDatetimeLocal(record?.starts_at);
    const end = toDatetimeLocal(record?.ends_at);
    const initial = {
        expected_version: record?.version ?? '',
        name: record?.name ?? '',
        description: record?.description ?? '',
        signal_source_id: record?.signal_source_id?.toString() ?? '',
        site_id: record?.site_id?.toString() ?? '',
        starts_date: start.slice(0, 10),
        starts_time: start.slice(11),
        starts_offset: record ? workerTimeOffset(record.starts_at) : '',
        ends_date: end.slice(0, 10),
        ends_time: end.slice(11),
        ends_offset: record ? workerTimeOffset(record.ends_at) : '',
    };
    const wizard = useSettingsWizard(
        'maintenance',
        record?.id,
        initial,
        onClose,
        WINDOW_STEPS,
        WINDOW_FIELDS,
        (values) => {
            const errors: Record<string, string> = {};
            requiredText(
                errors,
                'name',
                values.name,
                'Maintenance window name',
                255,
            );
            if (!values.site_id && !canScheduleAllSites)
                errors.site_id = 'Choose an approved site for this window.';
            if (values.description.length > 1000)
                errors.description =
                    'Keep the description to 1000 characters or fewer.';
            const starts = maintenanceInstant(
                values.starts_date,
                values.starts_time,
                values.starts_offset,
            );
            const ends = maintenanceInstant(
                values.ends_date,
                values.ends_time,
                values.ends_offset,
            );
            if (starts.error) errors.starts_at = starts.error;
            if (ends.error) errors.ends_at = ends.error;
            if (starts.iso && !record && Date.parse(starts.iso) < Date.now())
                errors.starts_at = 'Choose a start time that has not passed.';
            if (
                starts.iso &&
                ends.iso &&
                Date.parse(ends.iso) <= Date.parse(starts.iso)
            )
                errors.ends_at = 'The end must be after the start.';
            return errors;
        },
    );
    const { form, setForm, errors } = wizard;
    const sources = catalog(signalSources);
    const siteChoices = catalog(sites);
    const starts = maintenanceInstant(
        form.starts_date,
        form.starts_time,
        form.starts_offset,
    );
    const ends = maintenanceInstant(
        form.ends_date,
        form.ends_time,
        form.ends_offset,
    );
    const submit = (event: FormEvent) =>
        wizard.submit(
            event,
            () => ({
                name: form.name,
                description: form.description || null,
                ...(record ? { expected_version: form.expected_version } : {}),
                signal_source_id: form.signal_source_id
                    ? Number(form.signal_source_id)
                    : null,
                site_id: form.site_id ? Number(form.site_id) : null,
                starts_at: starts.iso,
                ends_at: ends.iso,
            }),
            record
                ? `/control-room/settings/maintenance/${record.id}`
                : '/control-room/settings/maintenance',
            !!record,
        );
    return (
        <SettingsWizard
            open={open}
            title={
                record
                    ? 'Edit maintenance window'
                    : 'Schedule maintenance window'
            }
            description="Review when matching rules may suppress signals for this source and site."
            steps={WINDOW_STEPS}
            wizard={wizard}
            submit={submit}
            currentSaved={
                <SettingsReview
                    readOnly
                    title="Current saved maintenance"
                    step={0}
                    wizard={wizard}
                    rows={{
                        Name: initial.name,
                        Description: initial.description,
                        Source: labelFor(
                            initial.signal_source_id,
                            sources,
                            'All sources',
                        ),
                        Site: labelFor(
                            initial.site_id,
                            siteChoices,
                            'All sites',
                        ),
                        Starts: formatDateTime(record?.starts_at),
                        Ends: formatDateTime(record?.ends_at),
                        Status: record?.status,
                        Timezone: WORKER_TIMEZONE,
                    }}
                />
            }
        >
            {wizard.step === 0 && (
                <>
                    <SettingsField
                        name="name"
                        label="Maintenance window name"
                        errors={errors}
                    >
                        {(props) => (
                            <Input
                                {...props}
                                required
                                value={form.name}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        name: event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                    <SettingsField
                        name="description"
                        label="Description"
                        errors={errors}
                    >
                        {(props) => (
                            <Textarea
                                {...props}
                                rows={3}
                                value={form.description}
                                onChange={(event) =>
                                    setForm({
                                        ...form,
                                        description: event.target.value,
                                    })
                                }
                            />
                        )}
                    </SettingsField>
                    <div className="grid gap-4 sm:grid-cols-2">
                        <SettingsField
                            name="signal_source_id"
                            label="Signal source"
                            errors={errors}
                        >
                            {(props) => (
                                <SettingsChoice
                                    {...props}
                                    label="Signal source"
                                    choices={sources}
                                    selected={
                                        form.signal_source_id
                                            ? [form.signal_source_id]
                                            : []
                                    }
                                    emptyLabel="All sources"
                                    onChange={(values) =>
                                        setForm({
                                            ...form,
                                            signal_source_id: values[0] ?? '',
                                        })
                                    }
                                />
                            )}
                        </SettingsField>
                        <SettingsField
                            name="site_id"
                            label="Site"
                            errors={errors}
                        >
                            {(props) => (
                                <SettingsChoice
                                    {...props}
                                    label="Site"
                                    choices={siteChoices}
                                    selected={
                                        form.site_id ? [form.site_id] : []
                                    }
                                    emptyLabel={
                                        canScheduleAllSites
                                            ? 'All sites'
                                            : 'Choose an approved site'
                                    }
                                    onChange={(values) =>
                                        setForm({
                                            ...form,
                                            site_id: values[0] ?? '',
                                        })
                                    }
                                />
                            )}
                        </SettingsField>
                    </div>
                </>
            )}
            {wizard.step === 1 && (
                <>
                    <MaintenanceTimestamp
                        name="starts_at"
                        label="Starts"
                        date={form.starts_date}
                        time={form.starts_time}
                        offset={form.starts_offset}
                        error={errors.starts_at}
                        onChange={(date, time, offset) =>
                            setForm({
                                ...form,
                                starts_date: date,
                                starts_time: time,
                                starts_offset: offset,
                            })
                        }
                    />
                    <MaintenanceTimestamp
                        name="ends_at"
                        label="Ends"
                        date={form.ends_date}
                        time={form.ends_time}
                        offset={form.ends_offset}
                        error={errors.ends_at}
                        onChange={(date, time, offset) =>
                            setForm({
                                ...form,
                                ends_date: date,
                                ends_time: time,
                                ends_offset: offset,
                            })
                        }
                    />
                </>
            )}
            {wizard.step === 2 && (
                <>
                    <div className="grid gap-4 sm:grid-cols-2">
                        <SettingsReview
                            title="Scope"
                            step={0}
                            wizard={wizard}
                            rows={{
                                Name: form.name,
                                Description: form.description,
                                Source: labelFor(
                                    form.signal_source_id,
                                    sources,
                                    'All sources',
                                ),
                                Site: labelFor(
                                    form.site_id,
                                    siteChoices,
                                    canScheduleAllSites
                                        ? 'All sites'
                                        : 'Choose an approved site',
                                ),
                            }}
                        />
                        <SettingsReview
                            title="Interval"
                            step={1}
                            wizard={wizard}
                            rows={{
                                Starts: starts.iso
                                    ? formatDateTime(starts.iso)
                                    : 'Choose a valid start',
                                Ends: ends.iso
                                    ? formatDateTime(ends.iso)
                                    : 'Choose a valid end',
                                Timezone: WORKER_TIMEZONE,
                                'Start occurrence': starts.iso
                                    ? `UTC${workerTimeOffset(starts.iso)}`
                                    : null,
                                'End occurrence': ends.iso
                                    ? `UTC${workerTimeOffset(ends.iso)}`
                                    : null,
                            }}
                        />
                    </div>
                    <p className="text-sm text-muted-foreground">
                        Maintenance applies only to matching rules that allow
                        suppression. Scheduling a window does not close active
                        responses or confirm recovery.
                    </p>
                </>
            )}
        </SettingsWizard>
    );
}

export function DeleteConfirmDialog(props: {
    open: boolean;
    onClose: () => void;
    onConfirm: () => void;
    title: string;
    description: string;
}) {
    return <ConfirmDialog {...props} confirmText="Delete" frontline />;
}
