import type { WorkspaceRoute } from '@/components/command-centre/workspace-strip';
import type { ControlRoomHeroMetricGroup } from '@/components/control-room/control-room-workspace-hero';
import {
    PageHeader,
    PageHeaderMeterBig,
    PageHeaderMeterBlock,
    PageHeaderMeterCaption,
    PageHeaderRail,
    PageHeaderSearchTrigger,
    PageHeaderStatusChip,
} from '@/components/page';
import {
    Command,
    CommandEmpty,
    CommandInput,
    CommandItem,
    CommandList,
} from '@/components/ui/command';
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogTitle,
} from '@/components/ui/dialog';
import {
    controlRoomViews,
    controlRoomViewValue,
    type ControlRoomNavCapabilities,
} from '@/lib/control-room-navigation';
import { cn } from '@/lib/utils';
import { router, usePage } from '@inertiajs/react';
import type { LucideIcon } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';

export type ControlRoomSearchItem = {
    key: string;
    label: string;
    href: string;
    keywords?: string[];
};

export function CommandCentrePage({
    current,
    icon,
    title,
    description,
    status = 'Control Room workspace',
    freshness,
    actions,
    footer,
    metricGroups = [],
    children,
    className,
    meters,
    filters,
    rail,
    search,
    searchItems,
    profile = false,
    backHref,
}: {
    variant?: 'full' | 'compact';
    current: string;
    icon: LucideIcon;
    title: string;
    description: string;
    status?: string;
    freshness?: string;
    actions?: ReactNode;
    /** Legacy decorative workflow is intentionally retired; response sources own their actual branches. */
    workflow?: ReactNode;
    footer?: ReactNode;
    metricGroups?: readonly ControlRoomHeroMetricGroup[];
    badges?: Partial<Record<WorkspaceRoute, ReactNode>>;
    children: ReactNode;
    className?: string;
    meters?: ReactNode;
    filters?: ReactNode;
    rail?: ReactNode;
    search?: ReactNode;
    searchItems?: ControlRoomSearchItem[];
    profile?: boolean;
    backHref?: string;
}) {
    const page = usePage<{
        [key: string]: unknown;
        auth?: { can?: ControlRoomNavCapabilities };
    }>();
    const views = controlRoomViews(current, page.props.auth?.can);
    const findItems: ControlRoomSearchItem[] =
        searchItems ??
        views.map((view) => ({
            key: view.key,
            label: view.label,
            href: view.key,
        }));
    const value = controlRoomViewValue(
        page.url || current,
        views.map((view) => view.key),
    );
    const [findOpen, setFindOpen] = useState(false);
    const navigate = (href: string) =>
        router.visit(href, {
            preserveState: true,
            preserveScroll: true,
            onFinish: () => {
                const id = new URL(href, window.location.origin).hash.slice(1);
                if (id)
                    document
                        .getElementById(decodeURIComponent(id))
                        ?.scrollIntoView({ block: 'center' });
            },
        });
    useEffect(() => {
        if (search) return;
        const find = (event: KeyboardEvent) => {
            const target = event.target as HTMLElement | null;
            if (
                event.key !== '/' ||
                event.ctrlKey ||
                event.metaKey ||
                event.altKey ||
                target?.closest(
                    'input, textarea, select, [contenteditable="true"], [role="dialog"]',
                )
            )
                return;
            event.preventDefault();
            setFindOpen(true);
        };
        window.addEventListener('keydown', find);
        return () => window.removeEventListener('keydown', find);
    }, [search]);

    return (
        <div className={cn('min-w-0 space-y-5', className)}>
            <PageHeader
                variant={profile ? 'profile' : 'index'}
                backHref={backHref}
                icon={icon}
                title={title}
                titleChip={
                    <PageHeaderStatusChip variant="neutral">
                        {status}
                    </PageHeaderStatusChip>
                }
                subline={
                    freshness ? (
                        <>
                            {description} · {freshness}
                        </>
                    ) : (
                        description
                    )
                }
                actions={
                    <>
                        {search ?? (
                            <PageHeaderSearchTrigger
                                placeholder={
                                    searchItems
                                        ? 'Search ' + title.toLowerCase() + '…'
                                        : 'Find a ' +
                                          title.toLowerCase() +
                                          ' view…'
                                }
                                onOpen={() => setFindOpen(true)}
                            />
                        )}
                        {actions}
                    </>
                }
                meters={
                    meters ??
                    metricGroups
                        .flatMap((group) => group.metrics)
                        .flatMap((metric) =>
                            metric.href
                                ? [
                                      <PageHeaderMeterBlock
                                          key={metric.label}
                                          label={metric.label}
                                          tone={
                                              metric.tone === 'neutral'
                                                  ? 'brand'
                                                  : metric.tone
                                          }
                                          href={metric.href}
                                          ariaLabel={
                                              'View ' +
                                              metric.label.toLowerCase()
                                          }
                                      >
                                          <PageHeaderMeterBig>
                                              {metric.value}
                                          </PageHeaderMeterBig>
                                          <PageHeaderMeterCaption>
                                              {metric.caption}
                                          </PageHeaderMeterCaption>
                                      </PageHeaderMeterBlock>,
                                  ]
                                : [],
                        )
                }
                filters={filters ?? footer}
                rail={
                    rail ??
                    (views.length > 0 ? (
                        <PageHeaderRail
                            items={views}
                            value={value}
                            onSelect={navigate}
                            ariaLabel={title + ' views'}
                        />
                    ) : undefined)
                }
            />
            {children}
            <Dialog open={findOpen} onOpenChange={setFindOpen}>
                <DialogContent
                    style={{
                        width: 'min(92vw, 480px)',
                        maxWidth: 'min(92vw, 480px)',
                    }}
                >
                    <DialogTitle>
                        {searchItems
                            ? 'Search ' + title.toLowerCase()
                            : 'Find a view'}
                    </DialogTitle>
                    <DialogDescription>
                        {searchItems
                            ? 'Find records in the current permitted results.'
                            : 'Open a permitted view in this Control Room destination.'}
                    </DialogDescription>
                    <Command>
                        <CommandInput
                            placeholder={
                                searchItems
                                    ? 'Search records…'
                                    : 'Search views…'
                            }
                        />
                        <CommandList>
                            <CommandEmpty>
                                {searchItems
                                    ? 'No matching records in these results.'
                                    : 'No matching views.'}
                            </CommandEmpty>
                            {findItems.map((item) => (
                                <CommandItem
                                    key={item.key}
                                    value={item.label + ' ' + item.key}
                                    keywords={item.keywords}
                                    onSelect={() => {
                                        setFindOpen(false);
                                        navigate(item.href);
                                    }}
                                >
                                    {item.label}
                                </CommandItem>
                            ))}
                        </CommandList>
                    </Command>
                </DialogContent>
            </Dialog>
        </div>
    );
}
