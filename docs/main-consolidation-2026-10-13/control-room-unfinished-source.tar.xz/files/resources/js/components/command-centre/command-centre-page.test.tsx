import { render, screen } from '@testing-library/react';
import { Activity, Clock3 } from 'lucide-react';
import type React from 'react';
import { describe, expect, it, vi } from 'vitest';
import { CommandCentrePage } from './command-centre-page';

const { page } = vi.hoisted(() => ({
    page: {
        url: '/control-room/reports',
        props: { auth: { can: { controlRoom: { viewAny: true } } } },
    },
}));

vi.mock('@inertiajs/react', () => ({
    usePage: () => page,
    router: { visit: vi.fn() },
    Link: ({
        href,
        children,
        preserveState: _state,
        preserveScroll: _scroll,
        ...props
    }: {
        href: string;
        children: React.ReactNode;
        preserveState?: boolean;
        preserveScroll?: boolean;
    }) => (
        <a href={href} {...props}>
            {children}
        </a>
    ),
}));

describe('CommandCentrePage', () => {
    it('connects the shared header, scoped controls and permitted views', () => {
        render(
            <CommandCentrePage
                current="/control-room/reports"
                icon={Activity}
                title="Reports"
                description="Review Control Room performance."
                status="Reporting workspace"
                freshness="Updated 2 minutes ago"
                actions={<button type="button">Export report</button>}
                footer={<div>Site filter</div>}
                metricGroups={[
                    {
                        title: 'Workload',
                        icon: Clock3,
                        metrics: [
                            {
                                label: 'Open',
                                value: '18',
                                caption: 'Actionable now',
                                tone: 'warning',
                                href: '/control-room/alerts?lens=active',
                            },
                            {
                                label: 'Breached',
                                value: '3',
                                caption: 'Past response target',
                                tone: 'critical',
                                href: '/control-room/sla/breaches',
                            },
                        ],
                    },
                ]}
            >
                <div>Report content</div>
            </CommandCentrePage>,
        );
        expect(
            screen.getByRole('heading', { level: 1, name: 'Reports' }),
        ).toBeInTheDocument();
        expect(
            screen.getByText(
                /Review Control Room performance.*Updated 2 minutes ago/,
            ),
        ).toBeInTheDocument();
        expect(
            screen.getByRole('button', { name: 'Export report' }),
        ).toBeInTheDocument();
        expect(screen.getByRole('link', { name: 'View open' })).toHaveAttribute(
            'href',
            '/control-room/alerts?lens=active',
        );
        expect(
            screen.getByRole('link', { name: 'View breached' }),
        ).toHaveAttribute('href', '/control-room/sla/breaches');
        expect(screen.getByText('Site filter')).toBeInTheDocument();
        expect(
            screen.getByRole('tablist', { name: 'Reports views' }),
        ).toBeInTheDocument();
        expect(screen.getByRole('tab', { name: /Overview/ })).toHaveAttribute(
            'aria-selected',
            'true',
        );
        expect(screen.getByText('Report content')).toBeInTheDocument();
    });

    it('does not advertise a meter without an actual destination', () => {
        render(
            <CommandCentrePage
                current="/control-room/reports"
                icon={Activity}
                title="Reports"
                description="Review response performance."
                metricGroups={[
                    {
                        title: 'Legacy count',
                        icon: Clock3,
                        metrics: [
                            {
                                label: 'Unlinked metric',
                                value: '999',
                                caption: 'Missing destination',
                                tone: 'neutral',
                            },
                        ],
                    },
                ]}
            >
                <div>Report details</div>
            </CommandCentrePage>,
        );
        expect(screen.queryByText('Unlinked metric')).not.toBeInTheDocument();
        expect(screen.queryByText('999')).not.toBeInTheDocument();
    });
});
