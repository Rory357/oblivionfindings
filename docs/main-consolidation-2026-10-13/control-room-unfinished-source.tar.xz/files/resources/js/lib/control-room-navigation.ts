import {
    Activity,
    ArrowUpCircle,
    Bell,
    BookOpen,
    Clock,
    FileText,
    ListTodo,
    Map,
    MessageSquare,
    RadioTower,
    Send,
    Settings,
    Smartphone,
    Target,
} from 'lucide-react';

export type ControlRoomNavCapabilities = {
    controlRoom?: {
        viewAny?: boolean;
        alertsView?: boolean;
        alertsManage?: boolean;
        alertsCreate?: boolean;
        reportsView?: boolean;
    };
    messages?: { send?: boolean; viewAny?: boolean };
};

/** Six entry points retain the existing permitted routes and their local views. */
export function controlRoomDestinations(can: ControlRoomNavCapabilities = {}) {
    const read = Boolean(can.controlRoom?.viewAny);
    const manage = Boolean(can.controlRoom?.alertsManage);
    const response = read || manage || Boolean(can.controlRoom?.alertsView);
    return [
        { title: 'Live response', href: read ? '/control-room' : '/control-room/alerts', icon: Bell, allowed: response },
        { title: 'Monitoring', href: '/control-room/map', icon: Map, allowed: read },
        { title: 'Communications', href: '/control-room/broadcast', icon: MessageSquare, allowed: read },
        { title: 'Duty handover', href: '/control-room/shifts', icon: Clock, allowed: read },
        { title: 'Reports', href: '/control-room/reports', icon: FileText, allowed: read || Boolean(can.controlRoom?.reportsView) },
        { title: 'Settings', href: manage ? '/control-room/settings' : '/control-room/playbooks', icon: Settings, allowed: read || manage },
    ].filter((destination) => destination.allowed)
        .map(({ title, href, icon }) => ({ title, href, icon }));
}

function destinationForPath(url: string): string | undefined {
    const path = url.split(/[?#]/)[0].replace(/\/+$/, '') || '/';
    if (path !== '/control-room' && !path.startsWith('/control-room/')) return undefined;
    if (/^\/control-room\/(map|devices)(\/|$)/.test(path)) return 'monitoring';
    if (/^\/control-room\/(broadcast|messaging)(\/|$)/.test(path)) return 'communications';
    if (/^\/control-room\/shifts(\/|$)/.test(path)) return 'duty';
    if (/^\/control-room\/(reports|stats|sla\/breaches|sla-breaches)(\/|$)/.test(path)) return 'reports';
    if (/^\/control-room\/(settings|playbooks|sla)(\/|$)/.test(path)) return 'settings';
    return 'response';
}

/** The sidebar's generic longest-prefix rule cannot identify sibling legacy views. */
export function controlRoomPrimaryLinkActive(currentPath: string, itemPath: string): boolean | undefined {
    const item = destinationForPath(itemPath);
    if (item === undefined) return undefined;
    return destinationForPath(currentPath) === item;
}

export function controlRoomViews(
    current: string,
    can: ControlRoomNavCapabilities = {},
) {
    const path = current.split('?')[0];
    const read = Boolean(can.controlRoom?.viewAny);
    const manage = Boolean(can.controlRoom?.alertsManage);
    if (
        path.startsWith('/control-room/map') ||
        path.startsWith('/control-room/devices')
    ) {
        return [
            {
                key: '/control-room/map',
                label: 'Map',
                icon: Map,
                allowed: read,
            },
            {
                key: '/control-room/devices',
                label: 'Signals',
                icon: Smartphone,
                allowed: read,
            },
        ].filter((item) => item.allowed);
    }
    if (
        path.startsWith('/control-room/broadcast') ||
        path.startsWith('/control-room/messaging')
    ) {
        return [
            {
                key: '/control-room/broadcast',
                label: 'Broadcasts',
                icon: Send,
                allowed: read,
            },
            {
                key: '/control-room/messaging',
                label: 'Response conversations',
                icon: MessageSquare,
                allowed: read,
            },
        ].filter((item) => item.allowed);
    }
    if (
        path.startsWith('/control-room/reports') ||
        path.startsWith('/control-room/stats') ||
        path.startsWith('/control-room/sla/breaches')
    ) {
        return [
            {
                key: '/control-room/reports',
                label: 'Overview',
                icon: FileText,
                allowed: read || Boolean(can.controlRoom?.reportsView),
            },
            {
                key: '/control-room/stats',
                label: 'Response performance',
                icon: Activity,
                allowed: read,
            },
            {
                key: '/control-room/sla/breaches',
                label: 'Target breaches',
                icon: Target,
                allowed: read,
            },
        ].filter((item) => item.allowed);
    }
    if (
        path.startsWith('/control-room/settings') ||
        path.startsWith('/control-room/sla') ||
        path.startsWith('/control-room/playbooks')
    ) {
        return [
            {
                key: '/control-room/settings?tab=rules',
                label: 'Routing',
                icon: RadioTower,
                allowed: manage,
            },
            {
                key: '/control-room/settings?tab=queues',
                label: 'Queues',
                icon: ListTodo,
                allowed: manage,
            },
            {
                key: '/control-room/sla',
                label: 'Response targets',
                icon: Target,
                allowed: read,
            },
            {
                key: '/control-room/playbooks',
                label: 'Procedures',
                icon: BookOpen,
                allowed: read,
            },
            {
                key: '/control-room/settings?tab=sources',
                label: 'Sources',
                icon: RadioTower,
                allowed: manage,
            },
            {
                key: '/control-room/settings?tab=maintenance',
                label: 'Maintenance',
                icon: Clock,
                allowed: manage,
            },
            {
                key: '/control-room/settings?tab=signal-outbox',
                label: 'Recovery',
                icon: Activity,
                allowed: manage,
            },
            {
                key: '/control-room/settings?tab=ticket-options',
                label: 'Response options',
                icon: Settings,
                allowed: manage,
            },
        ].filter((item) => item.allowed);
    }
    if (path.startsWith('/control-room/shifts'))
        return read
            ? [
                  {
                      key: '/control-room/shifts',
                      label: 'Duty handover',
                      icon: Clock,
                  },
              ]
            : [];

    return [
        {
            key: read ? '/control-room' : '/control-room/alerts',
            label: 'Active',
            icon: Bell,
            allowed: read || Boolean(can.controlRoom?.alertsView || manage),
        },
        {
            key: '/control-room/my-tasks',
            label: 'My work',
            icon: ListTodo,
            allowed: read,
        },
        {
            key: '/control-room/escalations',
            label: 'Escalated',
            icon: ArrowUpCircle,
            allowed: read,
        },
        {
            key: '/control-room/alerts?lens=snoozed',
            label: 'Waiting',
            icon: Clock,
            allowed: read || Boolean(can.controlRoom?.alertsView || manage),
        },
        {
            key: '/control-room/alerts?lens=history',
            label: 'History',
            icon: FileText,
            allowed: read || Boolean(can.controlRoom?.alertsView || manage),
        },
    ].filter((item) => item.allowed);
}

export function controlRoomViewValue(url: string, keys: string[]): string {
    const current = new URL(url, 'https://control-room.invalid');
    const match = [...keys]
        .sort(
            (left, right) =>
                new URL(right, current.origin).searchParams.size -
                new URL(left, current.origin).searchParams.size,
        )
        .find((key) => {
            const candidate = new URL(key, current.origin);
            return (
                candidate.pathname === current.pathname &&
                [...candidate.searchParams].every(
                    ([name, value]) => current.searchParams.get(name) === value,
                )
            );
        });
    if (match) return match;
    const path = current.pathname;
    return (
        keys.find((key) => path.startsWith(`${key.split('?')[0]}/`)) ??
        keys[0] ??
        ''
    );
}
