import { describe, expect, it } from 'vitest';
import {
    controlRoomDestinations,
    controlRoomPrimaryLinkActive,
    controlRoomViews,
    controlRoomViewValue,
} from './control-room-navigation';

describe('Control Room permitted local views', () => {
    it('preserves narrow alert readership without advertising dashboard-only routes', () => {
        expect(controlRoomDestinations({ controlRoom: { alertsView: true } }).map(({ title, href }) => [title, href])).toEqual([['Live response', '/control-room/alerts']]);
        expect(controlRoomDestinations({ controlRoom: { reportsView: true } }).map(({ title, href }) => [title, href])).toEqual([['Reports', '/control-room/reports']]);
        expect(controlRoomDestinations()).toEqual([]);
        const views = controlRoomViews('/control-room/alerts', {
            controlRoom: { alertsView: true },
        });
        expect(views.map((view) => view.label)).toEqual([
            'Active',
            'Waiting',
            'History',
        ]);
        expect(
            controlRoomViewValue(
                '/control-room/alerts?lens=history&site_id=4',
                views.map((view) => view.key),
            ),
        ).toBe('/control-room/alerts?lens=history');
        expect(
            controlRoomViewValue(
                '/control-room/alerts?lens=snoozed',
                views.map((view) => view.key),
            ),
        ).toBe('/control-room/alerts?lens=snoozed');
    });

    it('keeps readable procedures available without administration rights', () => {
        expect(controlRoomDestinations({ controlRoom: { viewAny: true } }).map(({ title }) => title)).toEqual(['Live response', 'Monitoring', 'Communications', 'Duty handover', 'Reports', 'Settings']);
        expect(controlRoomDestinations({ controlRoom: { viewAny: true } }).find(({ title }) => title === 'Settings')?.href).toBe('/control-room/playbooks');
        expect(controlRoomDestinations({ controlRoom: { alertsManage: true } }).map(({ title, href }) => [title, href])).toEqual([['Live response', '/control-room/alerts'], ['Settings', '/control-room/settings']]);
        expect(
            controlRoomViews('/control-room/playbooks', {
                controlRoom: { viewAny: true },
            }).map((view) => view.label),
        ).toEqual(['Response targets', 'Procedures']);
        expect(
            controlRoomViews('/control-room/settings', {
                controlRoom: { alertsManage: true },
            }).map((view) => view.label),
        ).not.toContain('Procedures');
    });

    it('uses the actual Communications route capability', () => {
        expect(controlRoomDestinations({ messages: { send: true } })).toEqual([]);
        expect(
            controlRoomViews('/control-room/broadcast', {
                controlRoom: { viewAny: true },
            }).map((view) => view.label),
        ).toEqual(['Broadcasts', 'Response conversations']);
        expect(
            controlRoomViews('/control-room/messaging', {
                messages: { send: true },
                controlRoom: { alertsManage: true },
            }),
        ).toEqual([]);
    });

    it('retains the source destination on a permanent record URL', () => {
        for (const [path, destination] of [
            ['/control-room/alerts/9', '/control-room'],
            ['/control-room/my-tasks', '/control-room'],
            ['/control-room/escalations', '/control-room'],
            ['/control-room/incidents', '/control-room'],
            ['/control-room/integration-alerts', '/control-room'],
            ['/control-room/devices/9', '/control-room/map'],
            ['/control-room/broadcast/receipt-9', '/control-room/broadcast'],
            ['/control-room/messaging', '/control-room/broadcast'],
            ['/control-room/shifts/9/handover', '/control-room/shifts'],
            ['/control-room/stats', '/control-room/reports'],
            ['/control-room/stats#stats-timings', '/control-room/reports'],
            ['/control-room/sla/breaches', '/control-room/reports'],
            ['/control-room/sla-breaches', '/control-room/reports'],
            ['/control-room/playbooks/9', '/control-room/settings'],
            ['/control-room/sla', '/control-room/settings'],
        ]) {
            expect(controlRoomPrimaryLinkActive(path, destination)).toBe(true);
            if (destination !== '/control-room') expect(controlRoomPrimaryLinkActive(path, '/control-room')).toBe(false);
        }
        expect(controlRoomPrimaryLinkActive('/control-room/devices/9', '/control-room/playbooks')).toBe(false);
        expect(controlRoomPrimaryLinkActive('/operations/rostering', '/control-room')).toBe(false);
        expect(controlRoomPrimaryLinkActive('/control-room', '/dashboard')).toBeUndefined();
        const views = controlRoomViews('/control-room/devices/9', {
            controlRoom: { viewAny: true },
        });
        expect(
            controlRoomViewValue(
                '/control-room/devices/9?return_to=%2Fcontrol-room%2Fdevices',
                views.map((view) => view.key),
            ),
        ).toBe('/control-room/devices');
    });
});
