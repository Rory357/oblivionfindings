<?php

namespace App\Models\ControlRoom;

use Illuminate\Database\Eloquent\Model;

/** Immutable receipt/history; changes append a new alert-scoped revision. */
class AlertReportingDecision extends Model
{
    protected static function booted(): void
    {
        static::updating(fn () => throw new \DomainException('Reporting decisions are immutable. Append a new revision.'));
        static::deleting(fn () => throw new \DomainException('Reporting decision history cannot be deleted.'));
    }

    public $timestamps = false;

    protected $table = 'control_room_alert_reporting_decisions';

    protected $guarded = ['id'];

    protected $casts = ['revision' => 'integer', 'decided_at' => 'datetime'];
}
