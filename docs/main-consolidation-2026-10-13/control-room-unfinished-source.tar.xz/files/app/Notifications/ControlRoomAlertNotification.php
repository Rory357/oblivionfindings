<?php

namespace App\Notifications;

use App\Models\ControlRoomAlert;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use Illuminate\Bus\Queueable;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Arr;

class ControlRoomAlertNotification extends Notification
{
    use Queueable;

    public function __construct(
        protected ControlRoomAlert $alert,
        protected array $extraContext = [],
    ) {}

    public function via(object $notifiable): array
    {
        return ['database'];
    }

    public function afterSending(object $notifiable, string $channel, mixed $response): void
    {
        if ($channel === 'database' && (! $response instanceof DatabaseNotification
            || ! $response->exists || $response->getKey() === null
            || ! $notifiable->notifications()->whereKey($response->getKey())->exists())) {
            throw new \RuntimeException('Control Room database notification was not persisted.');
        }
    }

    public function toArray(object $notifiable): array
    {
        $payload = array_merge([
            'type' => 'control_room_alert',
            'alert_id' => $this->alert->id,
            'severity' => $this->alert->severity,
            'status' => $this->alert->status,
            'alert_type' => $this->alert->alert_type,
            'source' => $this->alert->source,
            'triggered_at' => $this->alert->triggered_at?->toISOString(),
            'escalation_level' => $this->alert->escalation_level,
        ], $this->extraContext);
        if (app(ControlRoomGovernanceReadService::class)->isInjuryAlert($this->alert)) {
            return Arr::only($payload, ['type', 'alert_id', 'severity', 'status', 'alert_type', 'source',
                'triggered_at', 'escalation_level', 'routing_generation', 'queue_id', 'signal_rule_id',
                'source_authority_signature', 'source_privacy_signature', 'from_queue', 'to_queue', 'breach_types']);
        }

        return $payload;
    }
}
