<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Services\ControlRoom\ControlRoomDatabaseNotificationAccessService;
use App\Services\Medication\Alerts\MedicationAlertAttendance;
use Illuminate\Http\Request;
use Illuminate\Notifications\DatabaseNotification;
use Throwable;

class NotificationInboxController extends Controller
{
    public function __construct(
        private readonly ControlRoomDatabaseNotificationAccessService $notifications,
    ) {}

    public function markRead(Request $request, string $notification)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $this->notifications->mutate($user, $notification,
            otherAttendance: fn ($notice, $current) => $this->attend($notice, $current, MedicationAlertAttendance::OPENED));

        // Keep UX snappy when called from header dropdown
        return back()->with('success', 'Notification marked as read.');
    }

    public function markAllRead(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $this->notifications->markAllRead($user);

        return back()->with('success', 'All notifications marked as read.');
    }

    public function acknowledge(Request $request, string $notification)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $acknowledged = $this->notifications->mutate($user, $notification, acknowledge: true,
            otherAttendance: fn ($notice, $current) => $this->attend($notice, $current, MedicationAlertAttendance::ACKNOWLEDGED));
        if (! $acknowledged) {
            return back()->with('info', 'No acknowledgement required for this notification.');
        }

        return back()->with('success', 'Notification acknowledged.');
    }

    /**
     * A medication alert's shared "attended" record (P11 B2 chunk 3). Never
     * stops the bell action itself.
     */
    private function attend(DatabaseNotification $notification, User $user, string $how): void
    {
        try {
            app(MedicationAlertAttendance::class)->fromNotification($notification, $user, $how);
        } catch (Throwable $exception) {
            report($exception);
        }
    }
}
