<?php

namespace App\Http\Controllers\ControlRoom;

use App\Http\Controllers\Controller;
use App\Models\ControlRoomAlert;
use App\Services\ControlRoom\AlertReportingService;
use Illuminate\Http\Request;

final class ControlRoomReportingDecisionController extends Controller
{
    public function __invoke(Request $request, ControlRoomAlert $alert, AlertReportingService $reporting)
    {
        $input = $request->validate([
            'state' => ['required', 'in:required,not_required'],
            'reason' => ['required', 'string', 'max:5000'],
            'expected_revision' => ['required', 'integer', 'min:0'],
            'command_id' => ['required', 'uuid'],
        ]);
        $receipt = $reporting->decide($alert, $request->user(), $input);
        if ($request->expectsJson()) {
            return response()->json([
                'decision' => [
                    'revision' => $receipt->revision, 'state' => $receipt->state,
                    'decided_at' => $receipt->decided_at->toIso8601String(),
                ],
                'reporting' => $reporting->present($alert->refresh(), $request->user()),
            ]);
        }

        return back()->with('success', 'Reporting decision recorded.');
    }
}
