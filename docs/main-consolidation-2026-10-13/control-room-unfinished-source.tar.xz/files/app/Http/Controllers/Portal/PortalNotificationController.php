<?php

namespace App\Http\Controllers\Portal;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\ControlRoom\ControlRoomDatabaseNotificationAccessService;
use App\Services\HealthSafety\HealthSafetyReadContext;
use Illuminate\Http\Request;

class PortalNotificationController extends Controller
{
    public function __construct(
        private readonly ControlRoomDatabaseNotificationAccessService $notifications,
    ) {}

    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $filter = $request->input('filter', 'all');

        $props = $this->notifications->withCurrentViewer($user, function (User $current, HealthSafetyReadContext $context) use ($filter): array {
            $page = $this->notifications->visibleQuery($current, $context, $filter === 'unread')->orderByDesc('created_at')->paginate(30);
            $data = $this->notifications->projectedData($page->items(), $current, $context);

            return [
                'notifications' => $page->through(fn ($notification) => [
                    'id' => $notification->id, 'type' => class_basename($notification->type),
                    'data' => $data->get($notification->id), 'read_at' => $notification->read_at?->toISOString(),
                    'created_at' => $notification->created_at?->toISOString(),
                ])->toArray(),
                'filter' => $filter,
                'unreadCount' => $this->notifications->visibleQuery($current, $context, true)->count(),
            ];
        });

        return inertia('portal/notifications', $props);
    }

    public function markRead(Request $request, $notificationId)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $this->notifications->mutate($user, (string) $notificationId);

        return redirect()->back();
    }

    public function markAllRead(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $this->notifications->markAllRead($user);

        return redirect()->back();
    }
}
