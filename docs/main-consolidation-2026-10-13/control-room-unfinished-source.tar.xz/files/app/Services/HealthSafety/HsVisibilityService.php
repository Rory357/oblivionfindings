<?php

namespace App\Services\HealthSafety;

use App\Models\ControlRoomAlert;
use App\Models\HsCorrectiveAction;
use App\Models\HsEvent;
use App\Models\User;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use App\Services\UserSiteAccessService;
use Symfony\Component\HttpKernel\Exception\HttpException;

/**
 * Read-only service for surfacing H&S data in non-H&S contexts.
 *
 * Used by Control Room, module pages, and anywhere that needs a
 * lightweight, shaped H&S summary without depending on H&S internals.
 *
 * All methods are strictly read-only. No mutations. No side effects.
 */
class HsVisibilityService
{
    private const PROJECTION_PERMISSIONS = ['compliance.view'];

    public function __construct(private readonly HsEventAccessService $access) {}

    /** Compatibility read entrypoint: current module admission precedes canonical source projection. */
    public function forControlRoomAlert(ControlRoomAlert $alert, ?User $viewer = null): ?array
    {
        if ($viewer === null) {
            return null;
        }

        return app(ControlRoomGovernanceReadService::class)->withCurrentViewer($viewer,
            function (User $current, HealthSafetyReadContext $context) use ($alert): ?array {
                $record = app(ControlRoomGovernanceReadService::class)->forAlerts([$alert], $current, $context)->get((int) $alert->id);
                $identity = $record['hs_event'] === null ? null : (new HsEvent)->setRawAttributes(['id' => $record['hs_event']['id']]);
                $summary = $this->forEvent($identity, $current, readContext: $context);
                if (($record['injury_access'] ?? 'absent') !== 'absent' && is_array($summary)) {
                    unset($summary['handover']['notes']);
                }

                return $summary;
            });
    }

    /**
     * Shape an already resolved canonical event for another module.
     *
     * Restricted readers retain only the workflow dependency. Do not load or
     * serialize people, references, decisions or investigation detail for them.
     * The optional projector receives the current event and detached workflow
     * facts inside the same active read callback; its result must be scalar.
     */
    public function forEvent(?HsEvent $hsEvent, User $viewer, ?callable $projection = null, ?HealthSafetyReadContext $readContext = null): ?array
    {
        $readContext?->assertViewer($viewer);
        $permissions = [...FirstAidAccessService::PERMISSIONS, ...RestraintAccessService::PERMISSIONS,
            ...InjuryAccessService::PERMISSIONS, ...self::PROJECTION_PERMISSIONS];
        $readContext?->consumeSourceViewer($permissions, fn () => null);
        if (! $hsEvent) {
            return null;
        }

        // The caller supplies identity only. Neither loaded relations nor copied
        // facts are evidence for the source that exists at this read boundary.
        try {
            $consume = function (HealthSafetyReadContext $context) use ($hsEvent, $viewer, $projection): array {
                $candidates = $context->applyEventSiteScope(HsEvent::query()->whereKey($hsEvent->id), UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);
                $current = $this->access->applyReadableScope(clone $candidates, $viewer, $context, $candidates)->first();
                if (! $current) {
                    // Independent workflow visibility still requires current
                    // staff and the canonical approved Site boundary.
                    $dependency = $context->consumeViewer(FirstAidAccessService::PERMISSIONS,
                        fn () => $context->applyEventSiteScope(HsEvent::query()->whereKey($hsEvent->id),
                            UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS)
                            ->first(['id', 'status', 'handover_status']));

                    return ['access' => 'restricted', 'status' => $dependency?->status,
                        'handover' => ['status' => $dependency?->handover_status]];
                }

                // An optional scalar projector is consumed here, never later.
                // within() rejects a returned model, builder or authority object.
                if ($projection) {
                    $canManage = false;
                    try {
                        $canManage = $context->consumeViewer(FirstAidAccessService::PERMISSIONS,
                            fn (User $actor): bool => $actor->canDo('hazards.manage'));
                    } catch (HttpException $error) {
                        if ($error->getStatusCode() !== 403) {
                            throw $error;
                        }
                    }
                    $facts = ['present' => true, 'access' => 'readable', 'status' => $current->status,
                        'handover_status' => $current->handover_status,
                        'has_completed_action' => $context->query($current->correctiveActions()->getQuery())
                            ->where('status', HsCorrectiveAction::STATUS_COMPLETED)->exists(),
                        'can_manage' => $canManage];

                    return $context->consumeSourceViewer(self::PROJECTION_PERMISSIONS,
                        fn (User $actor): array => $projection($current, $facts, $actor, $context));
                }

                return $this->summary($current);
            };

            return $readContext === null ? HealthSafetyReadContext::within($viewer, $permissions, $consume) : $consume($readContext);
        } catch (HttpException $error) {
            if (! in_array($error->getStatusCode(), [403, 404], true)) {
                throw $error;
            }

            return ['access' => 'restricted', 'status' => null, 'handover' => ['status' => null]];
        }
    }

    /** Summary and current workflow facts from one active, source-authorised read. */
    public function summaryWithWorkflowFacts(?HsEvent $hsEvent, User $viewer, ?callable $detailProjection = null, ?HealthSafetyReadContext $readContext = null): array
    {
        $projection = $this->forEvent($hsEvent, $viewer, function (HsEvent $current, array $facts, User $actor, HealthSafetyReadContext $context) use ($detailProjection): array {
            $result = ['summary' => $this->summary($current), 'workflow_facts' => $facts];
            if ($detailProjection !== null) {
                $result['source_detail'] = $detailProjection($current, $actor, $context);
            }

            return $result;
        }, $readContext);
        if (array_key_exists('workflow_facts', $projection ?? [])) {
            return $projection;
        }

        // Denied reads retain an uncertain linked reference, never an absent or
        // completed case. These are only the freshly scoped dependency scalars.
        $result = ['summary' => $projection, 'workflow_facts' => [
            'present' => $hsEvent !== null,
            'access' => $hsEvent === null ? 'absent' : (($projection['status'] ?? null) === null ? 'unavailable' : 'restricted'),
            'status' => $projection['status'] ?? null,
            'handover_status' => $projection['handover']['status'] ?? null,
            'has_completed_action' => null, 'can_manage' => false,
        ]];
        if ($detailProjection !== null) {
            $result['source_detail'] = null;
        }

        return $result;
    }

    private function summary(HsEvent $hsEvent): array
    {
        $hsEvent->loadMissing(['owner:id,name', 'acceptedBy:id,name']);
        $hsEvent->loadCount([
            'investigations',
            'correctiveActions',
            'openCorrectiveActions',
        ]);

        $activeInvestigation = $hsEvent->activeInvestigation;

        return [
            'access' => 'readable',
            'id' => $hsEvent->id,
            'reference_number' => $hsEvent->reference_number,
            'event_category' => $hsEvent->event_category,
            'severity' => $hsEvent->severity,
            'status' => $hsEvent->status,
            'reported_at' => $hsEvent->reported_at?->toIso8601String(),
            'worksafe_notifiable' => $hsEvent->worksafe_notifiable,
            'worksafe_status' => $hsEvent->worksafe_status,
            'worksafe_reference' => $hsEvent->worksafe_reference,
            'worksafe_notified_at' => $hsEvent->worksafe_notified_at?->toIso8601String(),
            'worksafe_acknowledged_at' => $hsEvent->worksafe_acknowledged_at?->toIso8601String(),
            'handover' => [
                'status' => $hsEvent->handover_status,
                'owner' => $hsEvent->owner ? [
                    'id' => $hsEvent->owner->id,
                    'name' => $hsEvent->owner->name,
                ] : null,
                'accepted_by' => $hsEvent->acceptedBy ? [
                    'id' => $hsEvent->acceptedBy->id,
                    'name' => $hsEvent->acceptedBy->name,
                ] : null,
                'accepted_at' => $hsEvent->accepted_at?->toIso8601String(),
                'notes' => $hsEvent->acceptance_notes,
            ],
            'investigation_required' => $hsEvent->investigation_required,
            'investigation' => $activeInvestigation ? [
                'reference_number' => $activeInvestigation->reference_number,
                'status' => $activeInvestigation->status,
                'lead_investigator_name' => $activeInvestigation->leadInvestigator?->name,
                'is_overdue' => $activeInvestigation->isOverdue(),
            ] : null,
            'total_corrective_actions' => $hsEvent->corrective_actions_count ?? 0,
            'open_corrective_actions' => $hsEvent->open_corrective_actions_count ?? 0,
            'href' => "/health-safety/events/{$hsEvent->id}",
        ];
    }
}
