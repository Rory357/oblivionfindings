<?php

namespace App\Services\HealthSafety;

use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\Site;
use App\Models\User;
use App\Models\WorkplaceInjury;
use App\Services\CurrentAuthorizationReads;
use Carbon\CarbonImmutable;
use Illuminate\Database\Eloquent\Builder;
use Symfony\Component\HttpKernel\Exception\HttpExceptionInterface;

/** Purpose-fixed factual injury projections. No private recovery data or authority escapes. */
final class InjurySourceProjectionService
{
    public function __construct(private readonly InjuryAccessService $access) {}

    /** Complete provider candidate set; TaskItem objects are constructed only after this callback returns. */
    public function taskRows(User $viewer, array $filters = [], ?HealthSafetyReadContext $context = null): array
    {
        try {
            return $this->within($viewer, $context, function (User $current, CurrentAuthorizationReads $reads, array $sites) use ($filters): array {
                $query = $this->access->readableQuery($current, $reads, $sites)
                    ->select(InjuryAccessService::FACTUAL_COLUMNS)
                    ->when(isset($filters['id']), fn (Builder $query) => $query->whereKey((int) $filters['id']))
                    ->orderByDesc('injury_date')->orderByDesc('id')->limit(300);
                if (empty($filters['include_done'])) {
                    $query->whereNotIn('status', ['recovered', 'closed']);
                }
                $injuries = $query->get();
                $proofs = [];
                $injuries = $injuries->filter(function (WorkplaceInjury $injury) use ($current, $reads, $sites, &$proofs): bool {
                    $proofs[(int) $injury->id] = $this->access->factualSourceProof($injury, $current, $reads, $sites);
                    return $proofs[(int) $injury->id]['attribution_state'] !== 'repair_required';
                });
                if ($injuries->isEmpty()) {
                    return [];
                }
                $people = $reads->query(User::query())->whereIn('id', $injuries->pluck('user_id')->unique()->all())
                    ->get(['id', 'name'])->mapWithKeys(fn (User $user): array => [(int) $user->id => ['id' => (int) $user->id, 'name' => $user->name]])->all();
                $locations = $reads->query(Site::query())->whereIn('id', $injuries->pluck('site_id')->unique()->all())
                    ->get(['id', 'name'])->mapWithKeys(fn (Site $site): array => [(int) $site->id => ['id' => (int) $site->id, 'name' => $site->name]])->all();
                $rows = [];
                foreach ($injuries as $injury) {
                    $fact = $this->facts($injury, $current, $reads, $sites, $people, $locations, $proofs[(int) $injury->id]);
                    if ($fact !== null) {
                        $rows[] = $fact;
                    }
                }
                return $rows;
            });
        } catch (HttpExceptionInterface $denial) {
            if (! in_array($denial->getStatusCode(), [403, 404], true)) {
                throw $denial;
            }
            return [];
        }
    }

    public function forInjury(int $id, User $viewer, ?HealthSafetyReadContext $context = null): ?array
    {
        try {
            return $this->within($viewer, $context, function (User $current, CurrentAuthorizationReads $reads, array $sites) use ($id): ?array {
                $row = $this->access->readableQuery($current, $reads, $sites)->select(InjuryAccessService::FACTUAL_COLUMNS)->whereKey($id)->first();
                return $row ? $this->facts($row, $current, $reads, $sites) : null;
            });
        } catch (HttpExceptionInterface $denial) {
            if (! in_array($denial->getStatusCode(), [403, 404], true)) {
                throw $denial;
            }
            return null;
        }
    }

    /** The consumer still applies canonical operational access. This method grants no alert view or command. */
    public function forAlert(ControlRoomAlert $alert, User $viewer, ?HealthSafetyReadContext $context = null): array
    {
        try {
            return $this->within($viewer, $context, function (User $current, CurrentAuthorizationReads $reads, array $sites) use ($alert): array {
                // Read identity keys only; never hydrate copied clinical/narrative context for this proof.
                $row = $reads->query(ControlRoomAlert::query())->whereKey($alert->id)
                    ->select(['id', 'source', 'alert_type', 'site_id', 'client_id'])
                    ->selectRaw("JSON_UNQUOTE(JSON_EXTRACT(context, '$.workplace_injury_id')) as injury_identity")
                    ->selectRaw("JSON_UNQUOTE(JSON_EXTRACT(context, '$.site_id')) as source_site_identity")
                    ->selectRaw("JSON_UNQUOTE(JSON_EXTRACT(context, '$.user_id')) as worker_identity")->first();
                if (! $row) {
                    return ['access' => 'restricted', 'source' => null];
                }
                $injuryId = $this->positiveId($row->injury_identity);
                if ($row->alert_type !== 'operations.workplace_injury' && $injuryId === null) {
                    return ['access' => 'absent', 'source' => null, 'ignored' => true];
                }
                if ($row->source !== 'operations' || $row->alert_type !== 'operations.workplace_injury'
                    || $injuryId === null || $row->client_id !== null) {
                    return ['access' => 'restricted', 'source' => null];
                }
                $injury = $this->access->readableQuery($current, $reads, $sites)->select(InjuryAccessService::FACTUAL_COLUMNS)->whereKey($injuryId)->first();
                if (! $injury) {
                    $exists = $reads->query(WorkplaceInjury::query())->whereKey($injuryId)->exists();
                    return ['access' => $exists ? 'restricted' : 'unavailable', 'source' => null];
                }
                if ($this->positiveId($row->site_id) !== (int) $injury->site_id
                    || $this->positiveId($row->source_site_identity) !== (int) $injury->site_id
                    || $this->positiveId($row->worker_identity) !== (int) $injury->user_id) {
                    return ['access' => 'restricted', 'source' => null];
                }
                $fact = $this->facts($injury, $current, $reads, $sites);
                return $fact === null
                    ? ['access' => 'unavailable', 'source' => null, 'integrity' => 'repair_required']
                    : ['access' => 'readable', 'source' => $fact];
            });
        } catch (HttpExceptionInterface $denial) {
            if (! in_array($denial->getStatusCode(), [403, 404], true)) {
                throw $denial;
            }
            return ['access' => 'restricted', 'source' => null];
        }
    }

    /** Materialise only the independent caller candidates; final SQL correlation/denial stays with the caller. */
    public function readableHsEventIdsInContext(User $viewer, Builder $sourceCandidates, HealthSafetyReadContext $context): array
    {
        return $this->within($viewer, $context, function (User $current, CurrentAuthorizationReads $reads, array $sites) use ($sourceCandidates): array {
            $types = array_unique([WorkplaceInjury::class, (new WorkplaceInjury)->getMorphClass()]);
            $query = $reads->query(clone $sourceCandidates)->whereIn('hs_events.source_type', $types)
                ->where('hs_events.event_category', HsEvent::CATEGORY_INJURY)
                ->select(['hs_events.id', 'hs_events.source_id', 'hs_events.site_id', 'hs_events.staff_id',
                    'hs_events.client_id', 'hs_events.asset_id']);
            $ids = [];
            $query->chunkById(200, function ($events) use ($current, $reads, $sites, &$ids): void {
                $sources = $this->access->readableQuery($current, $reads, $sites)->select(InjuryAccessService::FACTUAL_COLUMNS)
                    ->whereIn('id', $events->pluck('source_id')->unique()->all())->get()->keyBy('id');
                $workerIds = $reads->query(User::query())->whereIn('id', $sources->pluck('user_id')->unique()->all())
                    ->pluck('id')->map(fn ($id): int => (int) $id)->all();
                $siteIds = $reads->query(Site::query())->whereIn('id', $sources->pluck('site_id')->unique()->all())
                    ->pluck('id')->map(fn ($id): int => (int) $id)->all();
                $proofs = [];
                foreach ($events as $event) {
                    $source = $sources->get((int) $event->source_id);
                    if ($source && $this->positiveId($event->site_id) === (int) $source->site_id
                        && $this->positiveId($event->staff_id) === (int) $source->user_id
                        && $event->client_id === null && $event->asset_id === null) {
                        $proof = $proofs[(int) $source->id] ??= $this->access->factualSourceProof($source, $current, $reads, $sites);
                        if ($proof['attribution_state'] !== 'repair_required'
                            && in_array((int) $source->user_id, $workerIds, true)
                            && in_array((int) $source->site_id, $siteIds, true)) {
                            $ids[] = (int) $event->id;
                        }
                    }
                }
            }, 'hs_events.id', 'id');
            return array_values(array_unique($ids));
        });
    }

    private function within(User $viewer, ?HealthSafetyReadContext $context, callable $operation): mixed
    {
        if ($context !== null) {
            $context->assertViewer($viewer);
            return $this->access->withReadContext($context, $operation);
        }
        return $this->access->withCurrentViewer($viewer, $operation);
    }

    private function facts(WorkplaceInjury $row, User $current, CurrentAuthorizationReads $reads, array $sites,
        ?array $people = null, ?array $locations = null, ?array $proof = null): ?array
    {
        // Every caller supplied a scoped current-locking factual SELECT in this active callback.
        // Prepared proof/labels are private callback-local scalar evidence, never shared or cached.
        $reads->assertActive();
        if ((int) $row->site_id < 1 || (int) $row->user_id < 1) {
            return null;
        }
        $proof ??= $this->access->factualSourceProof($row, $current, $reads, $sites);
        if ($proof['attribution_state'] === 'repair_required') {
            return null;
        }
        $worker = $people === null
            ? $reads->query(User::query())->whereKey($row->user_id)->first(['id', 'name'])?->only(['id', 'name'])
            : ($people[(int) $row->user_id] ?? null);
        $site = $locations === null
            ? $reads->query(Site::query())->whereKey($row->site_id)->first(['id', 'name'])?->only(['id', 'name'])
            : ($locations[(int) $row->site_id] ?? null);
        if (! $worker || ! $site) {
            return null;
        }
        $coordinator = null;
        if ($row->coordinator_user_id !== null) {
            try {
                $person = $this->access->currentStaff((int) $row->coordinator_user_id, (int) $row->site_id,
                    $current, $reads, $sites, true);
                $coordinator = ['id' => (int) $person->id, 'name' => $person->name];
            } catch (HttpExceptionInterface $denial) {
                if (! in_array($denial->getStatusCode(), [403, 404], true)) {
                    throw $denial;
                }
            }
        }
        return ['id' => (int) $row->id, 'reference' => $row->reference_number, 'status' => $row->status,
            'severity' => $row->severity, 'injury_type' => $row->injury_type, 'body_part_affected' => $row->body_part_affected,
            'description' => $row->description, 'injury_date' => $row->injury_date?->toISOString(),
            'worker' => ['id' => (int) $worker['id'], 'name' => $worker['name']],
            'site' => ['id' => (int) $site['id'], 'name' => $site['name']], 'coordinator' => $coordinator,
            'review_date' => $row->next_review_date?->toDateString(),
            'due_at' => $row->next_review_date === null ? null
                : CarbonImmutable::parse($row->next_review_date->toDateString(), 'Pacific/Auckland')->endOfDay()->toIso8601String(),
            'created_at' => $row->created_at?->toIso8601String(), 'source_revision' => $proof['source_revision'],
            'source_version_id' => $proof['source_version_id'],
            'attribution_state' => $proof['attribution_state'], 'medical_access' => 'excluded',
            'href' => '/health-safety/injuries/'.$row->id];
    }

    private function positiveId(mixed $value): ?int
    {
        if (! is_int($value) && (! is_string($value) || ! preg_match('/^[1-9][0-9]*$/D', $value))) {
            return null;
        }
        $id = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1]]);
        return $id === false ? null : $id;
    }
}
