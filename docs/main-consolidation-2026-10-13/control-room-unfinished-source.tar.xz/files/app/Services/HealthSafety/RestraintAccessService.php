<?php

namespace App\Services\HealthSafety;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Domain\Hr\Services\HrCurrentStaffService;
use App\Models\BehaviourSupportPlan;
use App\Models\BehaviourSupportPlanVersion;
use App\Models\Client;
use App\Models\ClientIncident;
use App\Models\RespiteBooking;
use App\Models\RespiteBookingRequest;
use App\Models\RespiteStay;
use App\Models\RestraintEvent;
use App\Models\Site;
use App\Models\User;
use App\Policies\ClientPolicy;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\CurrentAuthorizationReads;
use App\Services\Incidents\IncidentAccessService;
use App\Services\Respite\RespiteStayScope;
use App\Services\UserSiteAccessService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** Current operation authority and exact confidential source tuples, never a tenant boundary. */
final class RestraintAccessService
{
    public const PERMISSIONS = ['hazards.view', 'restraints.view', 'restraints.create', 'restraints.review', 'restraints.manage', 'restraints.approve', 'respite.stays.manage', 'respite.viewAny', 'healthSafety.viewAllSites', 'clients.viewAny', 'clients.viewAssigned', 'clinical.accessAllSites', 'sites.viewAll', 'sites.view', 'incidents.viewAny', 'incidents.viewAssigned', 'incidents.update', 'incidents.create', 'incidents.submit', 'hr.cases.view', 'medications.controlled.view', 'controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.tasks.view'];

    public function __construct(private readonly UserSiteAccessService $sites, private readonly AuthorizationEvidenceLockService $authorization, private readonly HrCurrentStaffService $staff, private readonly ClientPolicy $clients, private readonly RespiteStayScope $stays, private readonly IncidentAccessService $incidents) {}

    public function withReadContext(HealthSafetyReadContext $context, callable $operation): mixed
    {
        return $context->consumeViewer(self::PERMISSIONS, $operation);
    }

    public function withCurrentViewer(User $viewer, callable $operation): mixed
    {
        return DB::transaction(fn () => CurrentAuthorizationReads::within(function ($reads) use ($viewer, $operation) {
            $current = $this->authorization->lockForUserWithoutWaiting($viewer, self::PERMISSIONS);
            abort_unless($reads->query($this->staff->currentUsersQuery())->whereKey($current->id)->exists(), 403);
            $current->setRelation('hrEmployeeProfile', $reads->query(HrEmployeeProfile::query())->where('user_id', $current->id)->first());
            $sites = $this->sites->accessibleSiteIds($current, UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS, $reads);
            abort_unless($sites !== [], 403);

            return $operation($current, $reads, $sites);
        }));
    }

    public function assertOperation(User $current, string $operation): void
    {
        $allowed = match ($operation) {
            'view', 'export' => $current->canDo('restraints.view'),
            'workspace', 'review', 'link_incident', 'correct', 'assign_review', 'add_observation', 'add_debrief', 'add_followup', 'update_followup' => $current->canDo('restraints.review') || $current->canDo('restraints.manage'),
            'capture', 'create', 'add_evidence' => $current->canDo('restraints.create') || $current->canDo('restraints.manage'),
            'respite_capture' => $current->canDo('respite.stays.manage'),
            'approve' => $current->canDo('restraints.approve'),
            'manage', 'edit', 'update', 'activate', 'submit_review', 'archive', 'remove_evidence' => $current->canDo('restraints.manage'),
            'complete_followup' => $current->canDo('restraints.view') || $current->canDo('restraints.review') || $current->canDo('restraints.manage'),
            default => false,
        };
        abort_unless($allowed, 403);
    }

    public function assertClient(Client $client, User $current, CurrentAuthorizationReads $reads, array $sites, string $operation = 'capture'): Client
    {
        $reads->assertActive();
        $this->assertOperation($current, $operation);
        $fresh = $reads->query(Client::query())->find($client->id);
        abort_unless($fresh && $this->clients->viewFromCurrentEvidence($current, $fresh, $reads), 403);
        $this->site((int) $fresh->site_id, $reads, $sites);

        return $fresh;
    }

    /** Preserves original recorded Site AND current Client read after a move. */
    private function context(int $clientId, ?int $siteId, ?int $stayId, ?int $schema, User $current, CurrentAuthorizationReads $reads, array $sites): array
    {
        $reads->assertActive();
        $client = $reads->query(Client::query())->find($clientId);
        abort_unless($client && $this->clients->viewFromCurrentEvidence($current, $client, $reads), 403);
        $this->site((int) $client->site_id, $reads, $sites);
        if ($siteId === null) {
            // Historical null Site remains uncertain and only the named global bypass can read it.
            abort_unless($schema === null && $current->canDo('healthSafety.viewAllSites'), 403);
        } else {
            $this->site($siteId, $reads, $sites);
        }
        $stay = null;
        if ($stayId !== null) {
            $stay = $this->assertStay($stayId, $clientId, $siteId, $current, $reads, $sites);
        }

        return [$client, $stay];
    }

    public function assertStay(int $stayId, int $clientId, ?int $siteId, User $current, CurrentAuthorizationReads $reads, array $sites): RespiteStay
    {
        $reads->assertActive();
        $stay = $reads->query(RespiteStay::query())->find($stayId);
        abort_unless($stay && (int) $stay->client_id === $clientId, 403);
        $booking = $reads->query(RespiteBooking::query())->where('client_id', $clientId)->find($stay->booking_id);
        abort_unless($booking, 403);
        if ($booking->booking_request_id) {
            abort_unless($reads->query(RespiteBookingRequest::withTrashed())->where('client_id', $clientId)->whereKey($booking->booking_request_id)->exists(), 403);
        }
        $request = Request::create('/');
        $request->setUserResolver(fn () => $current);
        $resolved = $this->stays->resolveAuthorizedHealthSafetyStay($request, $stayId, false, $reads);
        abort_unless($siteId !== null && $this->stays->siteId($resolved) === $siteId && in_array($siteId, $sites, true), 403);

        return $resolved;
    }

    public function assertEvent(RestraintEvent $event, User $current, CurrentAuthorizationReads $reads, array $sites, string $operation = 'view'): void
    {
        $this->assertOperation($current, $operation);
        if ($event->source_schema_version !== null) {
            abort_unless((int) $event->source_schema_version === 1 && (int) $event->recorded_client_id === (int) $event->client_id && $event->recorded_site_id !== null && (int) $event->recorded_site_id === (int) $event->site_id && $event->recorded_stay_id === $event->stay_id, 403);
        }
        [$client, $stay] = $this->context((int) $event->client_id, $event->site_id === null ? null : (int) $event->site_id, $event->stay_id === null ? null : (int) $event->stay_id, $event->source_schema_version, $current, $reads, $sites);
        if ($event->behaviour_support_plan_id) {
            $plan = $reads->query(BehaviourSupportPlan::withTrashed())->find($event->behaviour_support_plan_id);
            abort_unless($plan && (int) $plan->client_id === (int) $event->client_id, 403);
            if ($event->behaviour_support_plan_version_id) {
                $version = $reads->query(BehaviourSupportPlanVersion::query())->where('behaviour_support_plan_id', $plan->id)->find($event->behaviour_support_plan_version_id);
                abort_unless($version && (int) $version->client_id === (int) $event->client_id && (int) $version->site_id === (int) $event->site_id && ($version->stay_id === null || (int) $version->stay_id === (int) $event->stay_id), 403);
            }
        } else {
            abort_unless($event->behaviour_support_plan_version_id === null, 403);
        }
        $event->setRelation('client', $client)->setRelation('stay', $stay);
    }

    public function assertPlan(BehaviourSupportPlan $plan, User $current, CurrentAuthorizationReads $reads, array $sites, string $operation = 'view'): void
    {
        $this->assertOperation($current, $operation);
        abort_unless($plan->source_schema_version === null || (int) $plan->source_schema_version === 1, 403);
        $client = $reads->query(Client::query())->find($plan->client_id);
        abort_unless($client, 403);
        $site = $plan->source_schema_version === null ? $client->site_id : $plan->source_site_id;
        [$client, $stay] = $this->context((int) $plan->client_id, $site === null ? null : (int) $site, $plan->source_stay_id === null ? null : (int) $plan->source_stay_id, $plan->source_schema_version, $current, $reads, $sites);
        $plan->setRelation('client', $client)->setRelation('sourceStay', $stay);
    }

    public function assertVersion(BehaviourSupportPlanVersion $version, BehaviourSupportPlan $plan, User $current, CurrentAuthorizationReads $reads, array $sites): void
    {
        abort_unless(($plan->source_schema_version === null || (int) $plan->source_schema_version === 1) && (int) $version->behaviour_support_plan_id === (int) $plan->id && (int) $version->client_id === (int) $plan->client_id, 403);
        $this->context((int) $version->client_id, (int) $version->site_id, $version->stay_id === null ? null : (int) $version->stay_id, 1, $current, $reads, $sites);
        if ($plan->source_schema_version !== null) {
            abort_unless((int) $version->site_id === (int) $plan->source_site_id && $version->stay_id === $plan->source_stay_id, 403);
        }
    }

    public function eligibleStaff(int $id, int $siteId, CurrentAuthorizationReads $reads, array $requiredPermissions = []): User
    {
        $person = $reads->query($this->staff->currentUsersQuery())->find($id);
        abort_unless($person, 403);
        $person = $this->authorization->lockForUserWithoutWaiting($person, self::PERMISSIONS);
        $person->setRelation('hrEmployeeProfile', $reads->query(HrEmployeeProfile::query())->where('user_id', $id)->first());
        abort_unless(in_array($siteId, $this->sites->accessibleSiteIds($person, [], $reads), true), 403);
        abort_unless($requiredPermissions === [] || collect($requiredPermissions)->contains(fn ($key) => $person->canDo($key)), 403);

        return $person;
    }

    public function assertStaffId(int $id, User $current, CurrentAuthorizationReads $reads, array $sites, string $operation, RestraintEvent|Client $source): User
    {
        $siteId = (int) ($source instanceof Client ? $source->site_id : $source->site_id);
        abort_unless(in_array($siteId, $sites, true), 403);
        $person = $this->eligibleStaff($id, $siteId, $reads);
        if (in_array($operation, ['review_owner', 'followup_owner', 'reviewer'], true)) {
            abort_unless($person->canDo('restraints.review') || $person->canDo('restraints.manage'), 403);
            $source instanceof Client
                ? $this->assertClient($source, $person, $reads, $this->sites->accessibleSiteIds($person, [], $reads), 'review')
                : $this->assertEvent($source, $person, $reads, $this->sites->accessibleSiteIds($person, [], $reads), 'review');
        }

        return $person;
    }

    public function assertIncident(RestraintEvent $event, ClientIncident $incident, User $current, CurrentAuthorizationReads $reads, bool $link = true): void
    {
        $sites = $this->sites->accessibleSiteIds($current, UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS, $reads);
        $this->assertEvent($event, $current, $reads, $sites, 'link_incident');
        $fresh = $reads->query(ClientIncident::query())->find($incident->id);
        abort_unless($fresh && (int) $fresh->client_id === (int) $event->client_id && $fresh->site_id !== null && (int) $fresh->site_id === (int) $event->site_id && ($fresh->respite_stay_id === null ? null : (int) $fresh->respite_stay_id) === ($event->stay_id === null ? null : (int) $event->stay_id), 404);
        abort_unless($this->incidents->canView($current, $fresh, $reads), 403);
        if ($link) {
            abort_unless($current->canDo('incidents.update') && $fresh->status !== 'closed' && ($current->canDo('incidents.viewAny') || $fresh->isEditableByReporter($current)), 403);
        }
    }

    public function commandCan(RestraintEvent|BehaviourSupportPlan $source, User $viewer): array
    {
        $flags = ['view', 'workspace', 'create', 'edit', 'review', 'approve', 'activate', 'submit_review', 'archive', 'link_incident', 'add_evidence'];
        try {
            return $this->withCurrentViewer($viewer, function ($current, $reads, $sites) use ($source, $flags) {
                $fresh = $source instanceof RestraintEvent ? $reads->query(RestraintEvent::withTrashed())->findOrFail($source->id) : $reads->query(BehaviourSupportPlan::withTrashed())->findOrFail($source->id);
                $result = [];
                foreach ($flags as $flag) {
                    try {
                        $fresh instanceof RestraintEvent ? $this->assertEvent($fresh, $current, $reads, $sites, $flag) : $this->assertPlan($fresh, $current, $reads, $sites, $flag);
                        $result[$flag] = in_array($flag, ['view', 'workspace'], true) || (! $fresh->trashed() && (! $fresh instanceof BehaviourSupportPlan || $fresh->status !== 'archived'));
                    } catch (HttpException $error) {
                        if (! in_array($error->getStatusCode(), [403, 404], true)) {
                            throw $error;
                        }
                        $result[$flag] = false;
                    }
                }

                return $result;
            });
        } catch (HttpException $error) {
            if (! in_array($error->getStatusCode(), [403, 404], true)) {
                throw $error;
            }

            return array_fill_keys($flags, false);
        }
    }

    private function site(int $id, CurrentAuthorizationReads $reads, array $sites): Site
    {
        $site = $reads->query(Site::query())->active()->notArchived()->whereNull('archived_at')->whereIn('id', $sites)->find($id);
        abort_unless($site, 403);

        return $site;
    }
}
