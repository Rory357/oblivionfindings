<?php

namespace App\Services\ControlRoom;

use App\Models\ClientIncident;
use App\Models\ControlRoom\AlertReportingDecision;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\User;
use App\Models\WorkplaceInjury;
use App\Services\AuditLogger;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\Incidents\IncidentJourneyService;
use App\Services\UserSiteAccessService;
use App\Support\Journeys\JourneyGate;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

/** Canonical reporting state and append-only attributed decisions, independent of governance closure. */
final class AlertReportingService
{
    public function __construct(
        private readonly AlertReportingPolicy $policy,
        private readonly IncidentJourneyService $journeys,
        private readonly ControlRoomAlertAccessService $access,
        private readonly ControlRoomGovernanceReadService $governance,
        private readonly UserSiteAccessService $sites,
    ) {}

    /** The caller must already have obtained this alert through the canonical readable scope. */
    public function present(ControlRoomAlert $alert, User $viewer, ?HealthSafetyReadContext $context = null): array
    {
        return $this->forAlerts([$alert], $viewer, null, $context)->get((int) $alert->id);
    }

    /** @return Collection<int, array<string, mixed>> */
    public function forAlerts(iterable $alerts, User $viewer, ?Collection $governance = null, ?HealthSafetyReadContext $context = null): Collection
    {
        return $this->reviewForAlerts($alerts, $viewer, $governance, $context)->pluck('reporting', 'id');
    }

    /** Internal projections for matching counts; never serialize raw source models. */
    public function reviewForAlerts(iterable $alerts, User $viewer, ?Collection $governance = null, ?HealthSafetyReadContext $context = null): Collection
    {
        if ($context === null) {
            return collect($this->governance->withCurrentViewer($viewer,
                fn (User $current, HealthSafetyReadContext $reads): array => $this->reviewForAlerts($alerts, $current, null, $reads)->all()));
        }
        $context->assertViewer($viewer);
        $viewer = $this->governance->withCurrentViewer($viewer, fn (User $current): User => $current, $context);
        $alerts = collect($alerts)->keyBy(fn (ControlRoomAlert $alert): int => (int) $alert->id);
        if ($alerts->isEmpty()) {
            return collect();
        }
        if ($governance === null || $alerts->keys()->diff($governance->keys())->isNotEmpty()
            || $governance->contains(fn (array $record, int $id): bool => ! $this->governance->isCurrentRecord($record, $context, $id))) {
            $governance = $this->governance->forAlerts($alerts, $viewer, $context);
        }
        $alerts = $this->governance->currentAlerts($alerts, $viewer, $context)->keyBy('id');
        $bases = $context->consumeSourceViewer(ControlRoomGovernanceReadService::PERMISSIONS,
            fn (User $current, $reads): Collection => $this->policy->forAlerts($alerts, $reads));
        $latestIds = AlertReportingDecision::query()->whereIn('alert_id', $alerts->keys())
            ->selectRaw('MAX(id)')->groupBy('alert_id');
        $decisions = $context->query(AlertReportingDecision::query()->whereIn('id', $latestIds))->get()->keyBy('alert_id');
        $canManage = $this->access->capabilitiesForScopedAlert($viewer)['manage'];
        $actorIds = $canManage ? $decisions->pluck('actor_user_id')->filter()->unique() : collect();
        $actors = $actorIds->isEmpty() ? collect() : $context->query(User::query()->whereIn('id', $actorIds))->get(['id', 'name'])->keyBy('id');
        $sourceReports = $bases->flatMap(fn (array $basis): array => $basis['source_reports']);
        $reportIds = $sourceReports->pluck('incident_id')->filter()->unique();
        $reports = $reportIds->isEmpty() ? collect() : $context->query(ClientIncident::query()->whereIn('id', $reportIds))
            ->get(['id', 'client_id', 'site_id', 'status'])->keyBy('id');
        $injuryIds = $sourceReports->where('kind', 'workplace_injury')->pluck('source_id')->unique();
        $readableInjuries = collect();
        if ($injuryIds->isNotEmpty()) {
            $readableInjuries = $governance->where('injury_access', 'readable')->pluck('injury_source.id')->filter()->flip();
        }

        return $alerts->map(function (ControlRoomAlert $alert) use ($viewer, $governance, $bases, $decisions, $actors, $reports, $readableInjuries): array {
            $basis = $bases->get((int) $alert->id);
            $decision = $decisions->get((int) $alert->id);
            $record = $governance->get((int) $alert->id);
            $available = $this->classificationAvailable($record);
            $required = $basis['required'] || ($decision?->state === 'required'
                && hash_equals($basis['source_signature'], $decision->source_signature));
            $reported = $available && $this->reportingComplete($basis, $record, $reports);

            return [
                'id' => (int) $alert->id,
                'reporting' => $this->projection($alert, $viewer, $basis, $decision, $record, $actors, $readableInjuries),
                'required_outstanding' => $required && ! $reported,
                'classification_available' => $available,
            ];
        });
    }

    private function projection(ControlRoomAlert $alert, User $viewer, array $basis, ?AlertReportingDecision $decision, array $record, Collection $actors, Collection $readableInjuries): array
    {
        $linked = $this->linked($basis, $record);
        $state = $this->state($linked, $basis, $decision);
        $capabilities = $this->access->capabilitiesForScopedAlert($viewer);
        $canManage = $capabilities['manage'];
        $available = $this->classificationAvailable($record);
        $canReadReason = $canManage && in_array($record['incident_access'], ['absent', 'readable'], true)
            && in_array($record['health_safety_access'], ['absent', 'readable'], true)
            && ($record['injury_access'] ?? 'absent') === 'absent';
        $validDecision = $decision !== null && hash_equals($basis['source_signature'], $decision->source_signature);
        if ($validDecision && ! $basis['required'] && ! $linked) {
            $basis['code'] = 'operator_reporting_decision';
            $basis['explanation'] = $state === 'required'
                ? 'An accountable reporting decision requires an applicable report.'
                : 'An accountable reporting decision records that no additional report is required.';
            if ($state === 'required' && $basis['report_target'] === null) {
                $basis['code'] = 'reporting_route_unavailable';
                $basis['explanation'] = 'The accountable reporting obligation remains open. The response owner must arrange the applicable source reporting route; no supported-person incident form is available for this response.';
            }
        }
        if (! $available) {
            $state = $basis['required'] || ($validDecision && $decision->state === 'required') ? 'required' : 'decision_needed';
            $basis['code'] = 'canonical_reporting_unavailable';
            $basis['explanation'] = 'The canonical reporting link needs repair. Reporting completion cannot be established, and no requirement has been waived.';
        }

        $applicableTarget = $basis['required'] || $linked || ($validDecision && $decision->state === 'required');
        $canCreate = $available && $applicableTarget && ! $linked && $record['incident_access'] === 'absent'
            && $capabilities['create_incident'] && $alert->isActionable()
            && $basis['report_target'] === 'client_incident' && ! in_array($basis['code'], [
                'source_reporting_review_unavailable', 'medication_error_incident_required',
                'medication_error_reporting_review', 'source_reporting_review',
            ], true);

        return [
            'state' => $state,
            'basis' => ['code' => $basis['code'], 'explanation' => $basis['explanation'], 'policy' => $basis['policy']],
            'decision' => $decision === null ? null : [
                'revision' => $decision->revision,
                'decided_at' => $decision->decided_at->toIso8601String(),
                // Reasons may contain source facts. Ordinary readers get the safe basis only.
                'reason' => $canReadReason ? $decision->reason : null,
                'actor' => $canReadReason && $decision->actor_user_id !== null
                    ? $actors->get($decision->actor_user_id)?->only(['id', 'name'])
                    : null,
            ],
            'revision' => $decision?->revision ?? 0,
            'canDecide' => $available && ! $linked && ! $basis['required'] && $basis['canDecide'] && $canManage && $alert->isActionable(),
            'canCreate' => $canCreate,
            'target' => $available && $applicableTarget ? $this->target($basis, $record, $readableInjuries, $canCreate) : null,
        ];
    }

    private function classificationAvailable(array $record): bool
    {
        return $record['incident_access'] !== 'unavailable' && $record['health_safety_access'] !== 'unavailable'
            && in_array($record['injury_access'] ?? 'absent', ['absent', 'readable'], true);
    }

    private function target(array $basis, array $record, Collection $readableInjuries, bool $canCreate): ?array
    {
        if ($basis['report_target'] === 'client_incident') {
            $readable = $record['incident_access'] === 'readable';

            return ['kind' => 'client_incident', 'label' => 'Incident report',
                'access' => $readable || $canCreate ? 'readable' : 'restricted',
                'href' => $readable ? '/incidents/'.data_get($record, 'incident.id') : null,
                'recorded' => $record['incident'] !== null];
        }
        if ($basis['report_target'] === 'workplace_injury') {
            $source = collect($basis['source_reports'])->firstWhere('kind', 'workplace_injury');
            $readable = $source !== null && $readableInjuries->has($source['source_id']);

            return ['kind' => 'workplace_injury', 'label' => 'Staff injury report',
                'access' => $readable ? 'readable' : 'restricted',
                'href' => $readable ? '/health-safety/injuries/'.$source['source_id'] : null,
                'recorded' => $source !== null];
        }

        return null;
    }

    /** Only actual applicable reporting obligations block operational resolution. */
    public function resolutionRequirement(ControlRoomAlert $alert, bool $lockSource = false): ?array
    {
        $basis = $this->policy->forAlert($alert, $lockSource);
        $decision = $this->latestDecision($alert);
        $humanRequired = $decision !== null && $decision->state === 'required'
            && hash_equals($basis['source_signature'], $decision->source_signature);
        if (! $basis['required'] && ! $humanRequired) {
            return null;
        }
        // A linked draft is still an outstanding actual reporting obligation.
        // Incident/governance closure remains an independent canonical gate.
        $record = $this->journeys->governanceRecordsForAlert($alert);
        if ($lockSource && $record['hs_event'] !== null) {
            $record['hs_event'] = HsEvent::query()
                ->whereKey($record['hs_event']->id)->lockForUpdate()->first();
        }
        $ids = collect($basis['source_reports'])->pluck('incident_id')->filter()->unique();
        $reports = $ids->isEmpty() ? collect() : ClientIncident::query()->whereIn('id', $ids)->orderBy('id')
            ->when($lockSource, fn ($query) => $query->lockForUpdate())->get(['id', 'client_id', 'site_id', 'status'])->keyBy('id');
        if ($this->reportingComplete($basis, $record, $reports)) {
            return null;
        }

        return [
            'key' => 'required_incident_reporting', 'complete' => false,
            'label' => $basis['report_target'] === null
                ? 'Arrange the applicable source reporting route and complete the required report before resolving this response.'
                : 'Complete the applicable required reporting before resolving this response.',
            'href' => '/control-room/alerts/'.$alert->id,
        ];
    }

    private function linked(array $basis, array $record): bool
    {
        if ($basis['report_target'] === 'client_incident') {
            return $record['incident'] !== null;
        }
        if ($basis['report_target'] !== 'workplace_injury') {
            return false;
        }

        return collect($basis['source_reports'])->contains(fn (array $source): bool => ($source['kind'] ?? null) === 'workplace_injury'
            && $this->staffReportMatches($source, $record['hs_event']));
    }

    private function reportingComplete(array $basis, array $record, Collection $reports): bool
    {
        if ($basis['source_reports'] === []) {
            return $basis['report_target'] === 'client_incident'
                && $record['incident'] !== null && data_get($record, 'incident.status') !== 'draft';
        }

        return collect($basis['source_reports'])->every(function (array $source) use ($record, $reports): bool {
            if (($source['kind'] ?? null) === 'workplace_injury') {
                return $this->staffReportMatches($source, $record['hs_event'])
                && in_array($source['status'], ['reported', 'under_treatment', 'return_to_work', 'recovered', 'closed'], true);
            }
            $report = $reports->get($source['incident_id']);

            return $report !== null && $report->status !== 'draft'
                && (int) $report->client_id === (int) $source['client_id']
                && (int) $report->site_id === (int) $source['site_id'];
        });
    }

    private function staffReportMatches(array $source, HsEvent|array|null $event): bool
    {
        return $event !== null && in_array(data_get($event, 'source_type'), array_unique([WorkplaceInjury::class, (new WorkplaceInjury)->getMorphClass()]), true)
            && (int) data_get($event, 'source_id') === $source['source_id'] && data_get($event, 'client_id') === null
            && (int) data_get($event, 'staff_id') === $source['staff_id'] && (int) data_get($event, 'site_id') === $source['site_id'];
    }

    /** Reuses the actual canonical gate; it never guesses from a visible incident ID. */
    public function completion(ControlRoomAlert $alert, User $viewer, JourneyGate $gate): array
    {
        $canManage = $this->access->capabilitiesForScopedAlert($viewer)['manage'];
        $blockers = collect($gate->requirements)->where('complete', false)
            ->map(fn (array $requirement): array => ['key' => $requirement['key'], 'label' => $requirement['label']])->values()->all();
        if (! $canManage) {
            $blockers[] = ['key' => 'response_authority', 'label' => 'An authorised response operator must resolve this response.'];
        }

        return [
            'canResolve' => $canManage && $gate->allowed,
            'blockers' => $blockers,
            'nextAction' => $blockers === [] ? null : [
                'key' => $blockers[0]['key'], 'label' => $blockers[0]['label'],
                'href' => $canManage ? '/control-room/alerts/'.$alert->id : null,
            ],
        ];
    }

    /** Returns the original immutable receipt on replay, even after later decisions. */
    public function decide(ControlRoomAlert $alert, User $actor, array $input): AlertReportingDecision
    {
        $input = Validator::make($input, [
            'state' => ['required', 'in:required,not_required'],
            'reason' => ['required', 'string', 'max:5000'],
            'expected_revision' => ['required', 'integer', 'min:0'],
            'command_id' => ['required', 'uuid'],
        ])->validate();
        $state = (string) ($input['state'] ?? '');
        $reason = trim((string) ($input['reason'] ?? ''));
        if (! in_array($state, ['required', 'not_required'], true) || $reason === '') {
            throw ValidationException::withMessages(['reason' => 'Choose a reporting decision and record its basis.']);
        }
        $commandHash = hash('sha256', json_encode([
            'actor_id' => (int) $actor->id, 'state' => $state, 'reason' => $reason,
            'expected_revision' => (int) $input['expected_revision'],
        ], JSON_THROW_ON_ERROR));

        return DB::transaction(function () use ($alert, $actor, $input, $state, $reason, $commandHash): AlertReportingDecision {
            $locked = ControlRoomAlert::query()->whereKey($alert->id)->lockForUpdate()->firstOrFail();
            $currentActor = User::query()->findOrFail($actor->id);
            abort_unless($this->access->canView($locked, $currentActor), 403);
            $replay = AlertReportingDecision::query()->where('alert_id', $locked->id)
                ->where('command_id', $input['command_id'])->first();
            if ($replay !== null) {
                abort_unless(hash_equals($replay->command_hash, $commandHash), 409, 'This command identity belongs to a different reporting decision.');

                return $replay;
            }
            abort_unless($this->access->canManage($locked, $currentActor), 403);
            abort_unless($locked->isActionable(), 409, 'This response no longer accepts reporting decisions.');
            $basis = $this->policy->forAlert($locked, lockSource: true);
            abort_unless($basis['canDecide'] && ! $basis['required'], 422, 'Use the canonical source reporting workflow. A mandatory requirement cannot be waived here.');
            $canonical = $this->journeys->governanceRecordsForAlert($locked);
            abort_if($canonical['incident'] !== null, 409, 'A canonical incident is already linked.');
            $latest = $this->latestDecision($locked);
            abort_unless(($latest?->revision ?? 0) === (int) $input['expected_revision'], 409, 'Reporting changed. Review the current decision before saving.');
            $receipt = AlertReportingDecision::query()->create([
                'alert_id' => $locked->id, 'revision' => ($latest?->revision ?? 0) + 1,
                'command_id' => $input['command_id'], 'command_hash' => $commandHash,
                'state' => $state, 'reason' => $reason, 'actor_user_id' => $currentActor->id,
                'source_signature' => $basis['source_signature'], 'decided_at' => now(),
            ]);
            AuditLogger::logOrFail('controlRoom.alert.reportingDecided', $locked, [
                'actor_id' => $currentActor->id, 'decision_id' => $receipt->id,
                'revision' => $receipt->revision, 'state' => $state,
                'basis_code' => $basis['code'], 'command_id' => $input['command_id'],
            ]);

            return $receipt;
        }, 3);
    }

    private function latestDecision(ControlRoomAlert $alert): ?AlertReportingDecision
    {
        return AlertReportingDecision::query()->where('alert_id', $alert->id)->orderByDesc('revision')->first();
    }

    private function state(bool $linked, array $basis, ?AlertReportingDecision $decision): string
    {
        if ($linked) {
            return 'linked';
        }
        if ($basis['required']) {
            return 'required';
        }
        if ($decision !== null && hash_equals($basis['source_signature'], $decision->source_signature)) {
            return $decision->state;
        }

        return 'decision_needed';
    }
}
