<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\OperatorNote;
use App\Services\HealthSafety\HealthSafetyReadContext;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Builder as QueryBuilder;

/** A reference is only a candidate for independently verified persisted operator text. */
final class ControlRoomOperatorRootNoteService
{
    public function verifiedIds(Builder $candidates, HealthSafetyReadContext $context): array
    {
        $context->assertActive();

        return $this->applyVerifiedScope(clone $candidates, $context)
            ->setEagerLoads([])->reorder()->pluck('control_room_alerts.id')->map(fn ($id): int => (int) $id)->all();
    }

    /** Equivalent exact row proof for both materialization and copied-note search/count. */
    public function applyVerifiedScope(Builder $query, HealthSafetyReadContext $context): Builder
    {
        $current = $context->consumeSourceViewer(ControlRoomGovernanceReadService::PERMISSIONS, fn ($current) => $current);
        app(ControlRoomAlertAccessService::class)->applyVisibleScope($query, $current);
        $origin = "JSON_EXTRACT(control_room_alerts.context, '$.root_note_origin";
        $query->whereRaw("JSON_TYPE({$origin}.version')) = 'INTEGER'")
            ->where('control_room_alerts.context->root_note_origin->version', 1)
            ->where('control_room_alerts.context->root_note_origin->source', 'operator_note');
        foreach (['operator_note_id', 'alert_id', 'actor_user_id'] as $field) {
            $query->whereRaw("JSON_TYPE({$origin}.{$field}')) IN ('INTEGER', 'STRING')")
                ->whereRaw("JSON_UNQUOTE({$origin}.{$field}')) REGEXP '^[1-9][0-9]{0,17}$'");
        }

        return $context->query($query->whereRaw("CAST(JSON_UNQUOTE({$origin}.alert_id')) AS UNSIGNED) = control_room_alerts.id")
            ->whereExists(function (QueryBuilder $notes) use ($origin): void {
                $notes->selectRaw('1')->from('control_room_operator_notes as root_operator_note')
                    ->whereRaw("root_operator_note.id = CAST(JSON_UNQUOTE({$origin}.operator_note_id')) AS UNSIGNED)")
                    ->whereColumn('root_operator_note.alert_id', 'control_room_alerts.id')
                    ->whereRaw("root_operator_note.user_id = CAST(JSON_UNQUOTE({$origin}.actor_user_id')) AS UNSIGNED)")
                    ->where('root_operator_note.type', OperatorNote::TYPE_DECISION)
                    ->where('root_operator_note.purpose', OperatorNote::PURPOSE_GENERAL)
                    ->whereRaw('CAST(root_operator_note.content AS BINARY) = CAST(control_room_alerts.notes AS BINARY)')
                    ->whereRaw("CAST(JSON_UNQUOTE({$origin}.text_sha256')) AS BINARY) = CAST(SHA2(control_room_alerts.notes, 256) AS BINARY)")
                    ->whereExists(fn (QueryBuilder $actor) => $actor->selectRaw('1')->from('users as root_note_actor')
                        ->whereColumn('root_note_actor.id', 'root_operator_note.user_id'));
            }));
    }
}
