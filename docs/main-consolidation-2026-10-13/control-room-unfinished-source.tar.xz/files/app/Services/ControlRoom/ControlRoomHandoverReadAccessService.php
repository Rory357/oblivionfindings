<?php

namespace App\Services\ControlRoom;

use App\Models\AuditLog;
use App\Models\ControlRoom\Shift;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;

/** The existing saved-handover participant/report-reader boundary, shared by entry points. */
final class ControlRoomHandoverReadAccessService
{
    public function canViewSavedSnapshot(Shift $shift, User $user): bool
    {
        if ($user->canDo('reports.viewAny')) {
            return true;
        }

        $participantIds = collect([
            ...$shift->memberUserIds(),
            $shift->handed_over_to_user_id,
        ])->filter(fn ($id): bool => is_numeric($id))
            ->map(fn ($id): int => (int) $id)->unique();
        if ($participantIds->contains($user->id)) {
            return true;
        }

        return AuditLog::query()->where('action', 'controlRoom.shift.handoverPrepared')
            ->where('auditable_type', $shift->getMorphClass())->where('auditable_id', $shift->id)
            ->where('user_id', $user->id)->exists();
    }

    /** Entry links disclose no saved content; the record GET rechecks all references/source access. */
    public function historyLinks(User $viewer, array $ids): array
    {
        return app(ControlRoomGovernanceReadService::class)->withCurrentViewer($viewer,
            function (User $current, HealthSafetyReadContext $context) use ($ids): array {
                if (! $current->canDo('controlRoom.alerts.manage')) {
                    return [];
                }
                $links = [];
                foreach ($context->query(Shift::query()->whereKey($ids)->where('status', 'completed')
                    ->where('handover_status', Shift::HANDOVER_ACCEPTED))->get() as $shift) {
                    if ($this->canViewSavedSnapshot($shift, $current)) {
                        $links[(int) $shift->id] = "/control-room/shifts/{$shift->id}/handover";
                    }
                }

                return $links;
            });
    }
}
