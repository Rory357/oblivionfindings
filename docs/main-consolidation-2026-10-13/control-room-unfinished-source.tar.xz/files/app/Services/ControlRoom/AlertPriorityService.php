<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\AlertSla;
use App\Models\ControlRoomAlert;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

class AlertPriorityService
{
    /** @var array<string, int> */
    private const LEVEL_RANK = [
        'critical' => 0, 'urgent' => 0, 'high' => 1,
        'medium' => 2, 'normal' => 2, 'low' => 3,
    ];

    public function apply(Builder $query): Builder
    {
        return $this->applyOrder($query, 'worklist_sla', false);
    }

    public function applyEscalation(Builder $query): Builder
    {
        return $this->applyOrder($query, 'escalation_sla', true);
    }

    /**
     * Immediate risk always precedes a missed target. Explicit priority can
     * raise source risk, never downgrade it. Configured deadlines order equally
     * risky work; a completed late milestone remains historical evidence.
     */
    private function applyOrder(Builder $query, string $sla, bool $escalation): Builder
    {
        $table = $query->getModel()->getTable();
        $actionable = "{$table}.status IN ('open', 'ack', 'triaging', 'confirmed')";
        $severity = $this->rankSql("LOWER(TRIM({$table}.severity))");
        $priority = $this->rankSql("LOWER(TRIM({$table}.priority))");
        $risk = "CASE WHEN {$priority} < {$severity} THEN {$priority} ELSE {$severity} END";
        $applicable = "{$actionable} AND {$sla}.sla_definition_id IS NOT NULL AND ({$sla}.ended_as IS NULL OR {$sla}.ended_as NOT IN ('reconciled_no_match', 'dismissed'))";
        $deadlines = ["COALESCE(CASE WHEN {$actionable} THEN {$table}.due_at END, '9999-12-31 23:59:59')"];
        $overdue = ["({$actionable} AND {$table}.due_at < ?)"];
        foreach ($this->milestones() as [$deadline, $completed]) {
            $pending = "{$applicable} AND {$sla}.{$completed} IS NULL";
            $deadlines[] = "COALESCE(CASE WHEN {$pending} THEN {$sla}.{$deadline} END, '9999-12-31 23:59:59')";
            $overdue[] = "({$pending} AND {$sla}.{$deadline} < ?)";
        }
        $nextDeadline = 'LEAST('.implode(',', $deadlines).')';
        $currentBreach = 'CASE WHEN ('.implode(' OR ', $overdue).') THEN 0 ELSE 1 END';
        $now = now();

        $query->leftJoin('control_room_alert_sla as '.$sla, $sla.'.alert_id', '=', $table.'.id')
            ->orderByRaw($risk)
            ->orderByRaw($currentBreach, array_fill(0, count($overdue), $now));

        if ($escalation) {
            $query->orderByDesc('worklist_queue.tier');
        }
        $query->orderByDesc($table.'.escalation_level')
            ->orderByRaw("CASE WHEN {$nextDeadline} = '9999-12-31 23:59:59' THEN 1 ELSE 0 END")
            ->orderByRaw($nextDeadline.' ASC');
        if ($escalation) {
            $query->orderByRaw('CASE WHEN current_queue_entry.entered_queue_at IS NULL THEN 1 ELSE 0 END')
                ->orderBy('current_queue_entry.entered_queue_at');
        }

        return $query->orderBy($table.'.triggered_at')->orderBy($table.'.id');
    }

    private function rankSql(string $value): string
    {
        return "CASE {$value} WHEN 'critical' THEN 0 WHEN 'urgent' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 WHEN 'normal' THEN 2 WHEN 'low' THEN 3 ELSE 4 END";
    }

    /** @param Collection<int, ControlRoomAlert> $alerts @return Collection<int, ControlRoomAlert> */
    public function sortActionable(Collection $alerts): Collection
    {
        return $alerts
            ->filter(fn (ControlRoomAlert $alert) => $alert->isActionable() && ! $alert->isSnoozed())
            ->sort(fn (ControlRoomAlert $left, ControlRoomAlert $right) => $this->sortKey($left) <=> $this->sortKey($right))
            ->values();
    }

    /** @return array{level: string, rank: int, reason: string} */
    public function describe(ControlRoomAlert $alert): array
    {
        $severity = strtolower(trim((string) $alert->severity));
        $explicit = strtolower(trim((string) $alert->priority));
        $usesPriority = (self::LEVEL_RANK[$explicit] ?? 4) < (self::LEVEL_RANK[$severity] ?? 4);
        $level = $usesPriority ? $explicit : ($severity ?: 'unknown');
        $reason = $usesPriority ? ucfirst($level).' priority' : ($severity ? ucfirst($level).' severity' : 'Priority not set');
        if ($this->currentDeadlineBreached($alert)) {
            $reason .= ' · Current response target overdue';
        } elseif ($this->sla($alert)?->isBreached()) {
            $reason .= ' · Previous response target missed';
        }

        return ['level' => $level, 'rank' => self::LEVEL_RANK[$level] ?? 4, 'reason' => $reason];
    }

    public function currentDeadlineBreached(ControlRoomAlert $alert): bool
    {
        return $this->nextDeadline($alert)?->lt(now()) ?? false;
    }

    public function nextDeadline(ControlRoomAlert $alert): ?Carbon
    {
        if (! $alert->isActionable()) {
            return null;
        }
        $candidates = collect([$alert->due_at]);
        $sla = $this->sla($alert);
        if ($sla instanceof AlertSla && $sla->isApplicable()) {
            foreach ($this->milestones() as [$deadline, $completed]) {
                if ($sla->{$completed} === null && $sla->{$deadline} !== null) {
                    $candidates->push($sla->{$deadline});
                }
            }
        }

        return $candidates->filter()
            ->map(fn ($value) => $value instanceof Carbon ? $value : Carbon::parse($value))
            ->sortBy(fn (Carbon $value) => $value->getTimestamp())->first();
    }

    /** @return array<int, int> */
    private function sortKey(ControlRoomAlert $alert): array
    {
        $description = $this->describe($alert);
        $deadline = $this->nextDeadline($alert);

        return [
            $description['rank'],
            $this->currentDeadlineBreached($alert) ? 0 : 1,
            -((int) $alert->escalation_level),
            $deadline === null ? 1 : 0,
            $deadline?->getTimestamp() ?? PHP_INT_MAX,
            $alert->triggered_at?->getTimestamp() ?? PHP_INT_MAX,
            (int) $alert->getKey(),
        ];
    }

    /** @return list<array{string, string}> */
    private function milestones(): array
    {
        return [
            ['acknowledge_deadline', 'acknowledged_at'],
            ['response_deadline', 'responded_at'],
            ['resolution_deadline', 'resolved_at'],
        ];
    }

    private function sla(ControlRoomAlert $alert): ?AlertSla
    {
        $sla = $alert->relationLoaded('sla') ? $alert->sla : null;
        if (! $sla instanceof AlertSla) {
            return null;
        }
        if (! $sla->relationLoaded('alert')) {
            $sla->setRelation('alert', $alert);
        }

        return $sla;
    }
}
