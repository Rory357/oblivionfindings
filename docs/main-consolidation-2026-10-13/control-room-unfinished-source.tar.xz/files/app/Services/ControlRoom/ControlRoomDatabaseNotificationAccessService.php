<?php

namespace App\Services\ControlRoom;

use App\Domain\Governance\Services\BoardPackAccessService;
use App\Domain\Hr\Services\HrCurrentStaffService;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Notifications\ControlRoomAlertNotification;
use App\Services\CurrentAuthorizationReads;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\Medication\Alerts\MedicationBellOrder;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Notifications\DatabaseNotification;
use Illuminate\Support\Collection;
use RuntimeException;

/** Current CR authority for persisted notices; other notification policies remain canonical. */
final class ControlRoomDatabaseNotificationAccessService
{
    // Shared consumers must retain every existing Board Pack/Medication permission.
    // The supported catalogue marker prepares evidence; it grants no capability.
    private const PERMISSIONS = ['*', ...ControlRoomGovernanceReadService::PERMISSIONS];

    public function __construct(
        private readonly BoardPackAccessService $boardPacks,
        private readonly ControlRoomAlertAccessService $alerts,
        private readonly ControlRoomGovernanceReadService $governance,
    ) {}

    /** A reader without CR access can still materialize independently permitted notifications. */
    public function withCurrentViewer(User $viewer, callable $operation, ?HealthSafetyReadContext $context = null): mixed
    {
        if ($context === null) {
            return HealthSafetyReadContext::within($viewer, self::PERMISSIONS,
                fn (HealthSafetyReadContext $current) => $this->withCurrentViewer($viewer, $operation, $current));
        }
        $context->assertViewer($viewer);

        return $context->consumeSourceViewer(self::PERMISSIONS,
            fn (User $current) => $operation($current, $context));
    }

    /** Apply before any count/order/limit; a stored class/type/ID is never access authority. */
    public function visibleQuery(User $viewer, HealthSafetyReadContext $context, bool $unreadOnly = false): MorphMany
    {
        $context->assertViewer($viewer);

        return $context->consumeSourceViewer(self::PERMISSIONS,
            function (User $current, CurrentAuthorizationReads $reads) use ($context, $unreadOnly): MorphMany {
                $query = $this->boardPacks->visibleNotificationQuery($current, $unreadOnly);
                $permitted = $current->approved_at !== null && ! $current->isExternalClinicianAccount()
                    && $reads->query(app(HrCurrentStaffService::class)->currentUsersQuery())->whereKey($current->id)->exists();
                $alertIds = $this->alerts->applyReadableScope(ControlRoomAlert::query(), $current)->select('control_room_alerts.id');
                if (! $permitted) {
                    $alertIds->whereRaw('1 = 0');
                }
                $query->where(function (Builder $notices) use ($alertIds): void {
                    $notices->where(fn (Builder $ordinary) => self::applyOtherTypesScope($ordinary))
                        ->orWhere(function (Builder $controlRoom) use ($alertIds): void {
                            $controlRoom->where('type', ControlRoomAlertNotification::class)
                                ->where('data->type', 'control_room_alert')
                                ->whereRaw("JSON_TYPE(JSON_EXTRACT(data, '$.alert_id')) IN ('INTEGER', 'STRING')")
                                ->whereRaw("JSON_UNQUOTE(JSON_EXTRACT(data, '$.alert_id')) REGEXP '^[1-9][0-9]{0,17}$'")
                                ->whereIn('data->alert_id', $alertIds);
                        });
                });
                $context->query($query->getQuery());

                return $query;
            });
    }

    /** Generic workflow jobs may not redistribute CR class/semantic rows. */
    public static function applyOtherTypesScope(Builder $query): Builder
    {
        return $query->where('type', '!=', ControlRoomAlertNotification::class)
            ->where(fn (Builder $type) => $type->whereNull('data->type')->orWhere('data->type', '!=', 'control_room_alert'));
    }

    /** Project only the materialized page, inside the same current read as its count and limits. */
    public function projectedData(iterable $notifications, User $viewer, HealthSafetyReadContext $context): Collection
    {
        $context->assertViewer($viewer);
        $ids = collect($notifications)->map(fn (DatabaseNotification $notice): string => (string) $notice->id)->unique()->values();
        $notifications = $ids->isEmpty() ? collect() : $this->visibleQuery($viewer, $context)->whereKey($ids)->get();
        abort_unless($notifications->count() === $ids->count(), 404);
        $controlRoom = $notifications->filter(fn (DatabaseNotification $notice): bool => $this->isControlRoom($notice));
        $current = $context->consumeSourceViewer(self::PERMISSIONS, fn (User $current): User => $current);
        $alerts = $controlRoom->isEmpty() ? collect() : $context->query($this->alerts
            ->applyReadableScope(ControlRoomAlert::query()->whereKey($controlRoom->map(fn ($notice) => data_get($notice->data, 'alert_id'))), $current))->get()->keyBy('id');
        $records = $alerts->isEmpty() ? collect() : $this->governance->forAlerts($alerts, $current, $context);

        return $notifications->mapWithKeys(function (DatabaseNotification $notice) use ($alerts, $records, $context): array {
            if (! $this->isControlRoom($notice)) {
                return [$notice->id => $notice->data];
            }
            $alert = $alerts->get((int) data_get($notice->data, 'alert_id'));
            abort_unless($notice->type === ControlRoomAlertNotification::class
                && data_get($notice->data, 'type') === 'control_room_alert' && $alert !== null, 404);
            $record = $records->get((int) $alert->id);
            abort_unless(is_array($record) && $this->governance->isCurrentRecord($record, $context, (int) $alert->id), 404);
            // Always derive operational fields from the canonical row. Historical copies never enter the allowlist.
            $title = $this->governance->isInjuryAlert($alert) ? 'Workplace injury response'
                : (($record['restraint_access'] ?? 'absent') !== 'absent' ? 'Restraint response' : 'Control Room response');

            return [$notice->id => [
                'type' => 'control_room_alert', 'alert_id' => (int) $alert->id,
                'title' => $title, 'severity' => $alert->severity, 'status' => $alert->status,
                'alert_type' => $alert->alert_type, 'source' => $alert->source,
                'triggered_at' => $alert->triggered_at?->toISOString(), 'escalation_level' => (int) $alert->escalation_level,
                'url' => '/control-room/alerts/'.$alert->id,
                'ack_required' => data_get($notice->data, 'ack_required') === true,
            ]];
        });
    }

    public function header(User $viewer): array
    {
        return $this->withCurrentViewer($viewer, function (User $current, HealthSafetyReadContext $context): array {
            $count = $this->visibleQuery($current, $context, true)->count();
            $notices = app(MedicationBellOrder::class)->apply($this->visibleQuery($current, $context))
                ->latest()->limit(8)->get(['id', 'type', 'data', 'read_at', 'acknowledged_at', 'escalation_count', 'created_at']);
            $data = $this->projectedData($notices, $current, $context);

            return ['unread_count' => $count, 'items' => $notices->map(fn ($notice): array => [
                'id' => $notice->id, 'type' => $notice->type, 'data' => $data->get($notice->id),
                'read_at' => $notice->read_at?->toISOString(), 'acknowledged_at' => $notice->acknowledged_at?->toISOString(),
                'escalation_count' => (int) ($notice->escalation_count ?? 0), 'created_at' => $notice->created_at?->toISOString(),
            ])->values()->all()];
        });
    }

    /** Revalidate recipient, type and current alert scope at the actual mutation. No alert acknowledgement. */
    public function mutate(User $viewer, string $id, bool $acknowledge = false, ?callable $otherAttendance = null): bool
    {
        return $this->withCurrentViewer($viewer, function (User $current, HealthSafetyReadContext $context) use ($id, $acknowledge, $otherAttendance): bool {
            $notice = $this->visibleQuery($current, $context)->whereKey($id)->firstOrFail();
            $data = $this->projectedData([$notice], $current, $context)->get($notice->id);
            if ($acknowledge && ! (bool) data_get($data, 'ack_required', false)) {
                return false;
            }
            $field = $acknowledge ? 'acknowledged_at' : 'read_at';
            if ($notice->{$field} === null && ! $notice->forceFill([$field => now()])->save()) {
                throw new RuntimeException('Notification action was not persisted.');
            }
            if (! $this->isControlRoom($notice) && $otherAttendance !== null) {
                $otherAttendance($notice, $current);
            }

            return true;
        });
    }

    public function markAllRead(User $viewer): void
    {
        $this->withCurrentViewer($viewer, function (User $current, HealthSafetyReadContext $context): void {
            $this->visibleQuery($current, $context, true)->update(['read_at' => now()]);
        });
    }

    private function isControlRoom(DatabaseNotification $notice): bool
    {
        return $notice->type === ControlRoomAlertNotification::class || data_get($notice->data, 'type') === 'control_room_alert';
    }
}
