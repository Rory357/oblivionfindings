<?php

namespace App\Services\ControlRoom;

use App\Models\Client;
use App\Models\ControlRoom\TriageQueue;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\Site;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\HealthSafety\HsEventAccessService;
use App\Services\Incidents\IncidentAccessService;
use App\Services\Medication\MedicationSignalService;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class AlertWorklistQuery
{
    /** @var list<string> */
    private const BYPASS_PERMISSIONS = ['reports.viewAny'];

    public function __construct(
        private readonly UserSiteAccessService $siteAccess,
        private readonly AlertPriorityService $priority,
        private readonly ControlRoomAlertAccessService $alertAccess,
        private readonly IncidentAccessService $incidentAccess,
        private readonly HsEventAccessService $hsAccess,
        private readonly ControlRoomSourceContentService $sourceContent,
        private readonly ControlRoomGovernanceReadService $governance,
        private readonly AlertReportingService $reporting,
    ) {}

    /** @param array<string, mixed> $filters */
    public function forUser(User $user, array $filters = [], ?HealthSafetyReadContext $context = null): Builder
    {
        if ($context === null) {
            throw new \LogicException('Materialise the worklist inside its current prepared callback.');
        }
        $context->assertViewer($user);
        $user = $this->governance->withCurrentViewer($user, fn (User $current): User => $current, $context);
        $query = $this->visibleAlerts($user)
            ->select('control_room_alerts.*')
            ->with([
                'site:id,name,tenant_id',
                'client:id,first_name,last_name,site_id,organization_id',
                'client.site:id,name,tenant_id',
                'assignedTo' => function ($assignee) use ($user): void {
                    $query = $assignee->getQuery();
                    $query->select(['users.id', 'users.name', 'users.email']);
                    $this->siteAccess->applyControlRoomAssigneeScope($query, $user, self::BYPASS_PERMISSIONS);
                },
                'queue:id,name,tier',
                'sla',
                'playbookRun:id,playbook_id,status,current_step,completed_steps,total_steps',
                'playbookRun.playbook:id,name,code',
                'clientIncident:id,reference_number,control_room_alert_id,hs_event_id,status,severity,site_id',
                'hsEvent:id,reference_number,control_room_alert_id,handover_status,owner_user_id,status,severity,worksafe_notifiable,worksafe_status',
            ]);

        $this->applyLens($query, (string) ($filters['lens'] ?? 'active'), $user);

        if (filled($filters['site_id'] ?? null)) {
            $this->siteAccess->applyAlertSiteScopeForSiteIds($query, [(int) $filters['site_id']]);
        }

        if (array_key_exists('ids', $filters)) {
            $ids = collect(is_array($filters['ids']) ? $filters['ids'] : [])
                ->filter(fn ($id): bool => is_numeric($id))
                ->map(fn ($id): int => (int) $id)
                ->unique()
                ->values()
                ->all();
            $query->whereIn('control_room_alerts.id', $ids);
        }

        $query
            ->when(filled($filters['severity'] ?? null), fn (Builder $q) => $q->where('control_room_alerts.severity', $filters['severity']))
            ->when(filled($filters['source'] ?? null), fn (Builder $q) => $q->where('control_room_alerts.source', $filters['source']))
            ->when(in_array($filters['status'] ?? null, ControlRoomAlert::VALID_STATUSES, true), fn (Builder $q) => $q->where('control_room_alerts.status', $filters['status']))
            ->when(filled($filters['queue_id'] ?? null), fn (Builder $q) => $q->where('control_room_alerts.queue_id', (int) $filters['queue_id']))
            ->when(is_numeric($filters['assigned_to'] ?? null), fn (Builder $q) => $q->where('control_room_alerts.assigned_to_user_id', (int) $filters['assigned_to']))
            ->when(filled($filters['escalation_level'] ?? null), fn (Builder $q) => $q->where('control_room_alerts.escalation_level', '>=', (int) $filters['escalation_level']))
            ->when(filled($filters['date_from'] ?? null), fn (Builder $q) => $q->whereDate('control_room_alerts.triggered_at', '>=', $filters['date_from']))
            ->when(filled($filters['date_to'] ?? null), fn (Builder $q) => $q->whereDate('control_room_alerts.triggered_at', '<=', $filters['date_to']));
        if (($filters['assigned_to'] ?? null) === 'unassigned') {
            $query->whereNull('control_room_alerts.assigned_to_user_id');
        }
        if (($filters['assigned_to'] ?? null) === 'me') {
            $query->where('control_room_alerts.assigned_to_user_id', $user->id);
        }
        $this->applyWorkflowFilters($query, $user, $filters, $context);
        $query->when(filled($filters['q'] ?? null), function (Builder $q) use ($filters, $user, $context): void {
            $term = '%'.trim((string) $filters['q']).'%';
            $alertCandidates = (clone $q)->setEagerLoads([])->reorder()->select('control_room_alerts.id');
            $notesCandidates = (clone $alertCandidates)->select('control_room_alerts.*')->where('control_room_alerts.notes', 'like', $term);
            $eventCandidates = $context->applyEventSiteScope(HsEvent::query()
                ->whereIn('hs_events.control_room_alert_id', clone $alertCandidates)
                ->where('hs_events.reference_number', 'like', $term), UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);
            $q->where(function (Builder $search) use ($term, $user, $context, $notesCandidates, $eventCandidates): void {
                $search->where('control_room_alerts.reference_number', 'like', $term)
                    ->orWhere('control_room_alerts.alert_type', 'like', $term)
                    ->orWhere(fn (Builder $notes) => $this->sourceContent->applyReadableNotes($notes, $user, $context, $notesCandidates)
                        ->where('control_room_alerts.notes', 'like', $term))
                    ->orWhereHas('clientIncident', function (Builder $incident) use ($term, $user): void {
                        $this->incidentAccess->apply($incident, $user)->where('reference_number', 'like', $term);
                    })
                    ->orWhereHas('hsEvent', function (Builder $event) use ($term, $user, $context, $eventCandidates): void {
                        $this->hsAccess->applyReadableScope($event, $user, $context, $eventCandidates)->where('reference_number', 'like', $term);
                    });
            });
        });

        return $context->query($this->priority->apply($query));
    }

    /** The consumer must finish counts/pages/projections before this callback returns. */
    public function materialize(User $viewer, array $filters, callable $consumer, ?HealthSafetyReadContext $context = null): mixed
    {
        return $this->governance->withCurrentViewer($viewer,
            fn (User $current, HealthSafetyReadContext $reads) => $consumer($this->forUser($current, $filters, $reads), $current, $reads), $context);
    }

    /** Discovery only: the caller's canonical alert scope must already apply. */
    public function withWorkflowEvidence(Builder $query): Builder
    {
        return $query->where(function (Builder $candidates): void {
            $candidates->where('control_room_alerts.status', ControlRoomAlert::STATUS_CONFIRMED)
                ->orWhere('control_room_alerts.source', 'incident')
                ->orWhere('control_room_alerts.alert_type', 'operations.workplace_injury')
                ->orWhereNotNull('control_room_alerts.context->incident_id')
                ->orWhereNotNull('control_room_alerts.context->normalized_data->incident_id')
                ->orWhereHas('clientIncident')->orWhereHas('hsEvent')
                ->orWhereExists(DB::table('control_room_alert_reporting_decisions')->selectRaw('1')
                    ->whereColumn('alert_id', 'control_room_alerts.id'))
                ->orWhereExists(DB::table('control_room_signals')->selectRaw('1')
                    ->where('signal_type_code', MedicationSignalService::TYPE_ERROR)
                    ->where(function ($source): void {
                        $source->whereColumn('alert_id', 'control_room_alerts.id')
                            ->orWhereColumn('correlated_alert_id', 'control_room_alerts.id')
                            ->orWhereColumn('id', 'control_room_alerts.origin_signal_id');
                    }));
        });
    }

    /** Canonical source predicates run before pagination, in bounded batches. */
    private function applyWorkflowFilters(Builder $query, User $user, array $filters, HealthSafetyReadContext $context): void
    {
        $reporting = $filters['reporting'] ?? null;
        $handover = ($filters['lens'] ?? null) === 'safety_handover' ? 'awaiting_acceptance' : ($filters['handover_state'] ?? null);
        if ($reporting === '') {
            $reporting = null;
        }
        if ($handover === '') {
            $handover = null;
        }
        if (! in_array($reporting, ['required', 'decision_needed', 'not_required', 'linked'], true)
            && ! in_array($handover, ['awaiting_acceptance', 'accepted_in_progress', 'governance_open', 'unavailable'], true)) {
            return;
        }
        $matched = [];
        $invert = $reporting === 'decision_needed' && $handover === null;
        $context->query($this->withWorkflowEvidence(clone $query))->setEagerLoads([])->reorder()->chunkById(500, function ($alerts) use ($user, $context, $reporting, $handover, $invert, &$matched): void {
            $records = $this->governance->forAlerts($alerts, $user, $context);
            $reviews = $reporting === null ? collect() : $this->reporting->reviewForAlerts($alerts, $user, $records, $context);
            foreach ($alerts as $alert) {
                $record = $records->get((int) $alert->id);
                $event = $record['hs_event'];
                $available = $record['incident_access'] !== 'unavailable' && $record['health_safety_access'] !== 'unavailable';
                $review = $reviews->get((int) $alert->id);
                $reportMatches = match ($reporting) {
                    'required' => $review['required_outstanding'],
                    'decision_needed', 'not_required', 'linked' => $available && $review['reporting']['state'] === $reporting,
                    default => true,
                };
                $handoverMatches = match ($handover) {
                    'unavailable' => ! $available,
                    'awaiting_acceptance' => $available && data_get($event, 'handover_status') === 'awaiting_acceptance',
                    'accepted_in_progress' => $available && data_get($event, 'handover_status') === 'accepted' && data_get($event, 'status') !== 'closed',
                    'governance_open' => $available && in_array($alert->status, ControlRoomAlert::TERMINAL_STATUSES, true)
                        && $event !== null && data_get($event, 'status') !== 'closed',
                    default => true,
                };
                if ($invert ? ! ($reportMatches && $handoverMatches) : $reportMatches && $handoverMatches) {
                    $matched[] = (int) $alert->id;
                }
            }
        }, 'control_room_alerts.id', 'id');
        $invert ? $query->whereNotIn('control_room_alerts.id', $matched) : $query->whereIn('control_room_alerts.id', $matched);
    }

    /**
     * Build every adjacent alert-list dataset from the same actor and Site
     * boundary as {@see forUser()}. Creation datasets are deliberately absent
     * unless the actor can create alerts; an empty picker is still a dataset.
     *
     * @return array<string, mixed>
     */
    public function viewContextFor(User $user, array $filters = [], ?HealthSafetyReadContext $readContext = null): array
    {
        if ($readContext === null) {
            return $this->governance->withCurrentViewer($user,
                fn (User $current, HealthSafetyReadContext $reads): array => $this->viewContextFor($current, $filters, $reads));
        }
        $user = $this->governance->withCurrentViewer($user, fn (User $current): User => $current, $readContext);
        $statsBase = $this->forUser($user, [...$filters, 'lens' => 'all_records'], $readContext)->setEagerLoads([])->reorder();

        // These counts intentionally mirror the existing worklist lenses.
        // The five live tabs exclude currently-snoozed alerts, while snoozed
        // and history retain their dedicated counts.
        $stats = [
            'total' => (clone $statsBase)->actionable()->notSnoozed()->count(),
            'open' => (clone $statsBase)->notSnoozed()->where('status', 'open')->count(),
            'critical' => (clone $statsBase)->notSnoozed()->where('severity', 'critical')->actionable()->count(),
            'in_triage' => (clone $statsBase)->notSnoozed()->where('control_room_alerts.status', 'triaging')->count(),
            'assigned_to_me' => (clone $statsBase)->notSnoozed()->where('assigned_to_user_id', $user->id)->actionable()->count(),
            'unassigned' => (clone $statsBase)->notSnoozed()->whereNull('assigned_to_user_id')->actionable()->count(),
            'snoozed' => (clone $statsBase)->snoozed()->count(),
            'history' => (clone $statsBase)->whereIn('status', ControlRoomAlert::TERMINAL_STATUSES)->count(),
            'sla_breached' => (clone $statsBase)->actionable()->notSnoozed()
                ->where(function (Builder $overdue): void {
                    $overdue->where('control_room_alerts.due_at', '<', now())
                        ->orWhereHas('sla', function (Builder $sla): void {
                            $sla->whereNotNull('sla_definition_id')->where(function (Builder $applicable): void {
                                $applicable->whereNull('ended_as')->orWhereNotIn('ended_as', ['dismissed', 'reconciled_no_match']);
                            })->where(function (Builder $deadline): void {
                                foreach (['acknowledge' => 'acknowledged', 'response' => 'responded', 'resolution' => 'resolved'] as $target => $completed) {
                                    $deadline->orWhere(fn (Builder $pending) => $pending->whereNull($completed.'_at')->where($target.'_deadline', '<', now()));
                                }
                            });
                        });
                })
                ->count(),
        ];

        $queueAlertIds = $this->forUser($user, [...$filters, 'lens' => 'active', 'queue_id' => null], $readContext)
            ->setEagerLoads([])->reorder()->select('control_room_alerts.id');
        $queues = TriageQueue::active()
            ->withCount(['alerts as active_alert_count' => function (Builder $query) use ($queueAlertIds): void {
                $query->whereIn('control_room_alerts.id', clone $queueAlertIds);
            }])
            ->orderBy('tier')
            ->get(['id', 'name', 'tier', 'code'])
            ->map(fn (TriageQueue $queue): array => [
                'id' => $queue->id,
                'name' => $queue->name,
                'tier' => $queue->tier,
                'active_alerts' => $queue->active_alert_count,
            ]);

        $can = [
            'manage' => $user->canDo('controlRoom.alerts.manage'),
            'assign' => $user->canDo('controlRoom.alerts.assign'),
            'create' => $user->canDo('controlRoom.alerts.create'),
        ];

        $latestAlert = $this->visibleAlerts($user)->actionable();
        $context = [
            'stats' => $stats,
            'queues' => $queues->all(),
            'staff' => $this->assignableStaff($user)->toArray(),
            'can' => $can,
            'latest_alert_at' => $latestAlert->max('updated_at'),
            'source_options' => $this->sourceOptionsFor($user, $filters, $readContext)->all(),
        ];

        if (! $can['create']) {
            return $context;
        }

        $clients = Client::query()->orderBy('first_name');
        $this->siteAccess->applyClientScope($clients, $user, self::BYPASS_PERMISSIONS);

        $sites = Site::query()->orderBy('name');
        $this->siteAccess->applySiteScope($sites, $user, self::BYPASS_PERMISSIONS);

        return array_merge($context, [
            'clients' => $clients
                ->get(['id', 'first_name', 'last_name', 'site_id'])
                ->map(fn (Client $client): array => [
                    'id' => $client->id,
                    'name' => trim($client->first_name.' '.$client->last_name),
                    'site_id' => $client->site_id,
                ])->all(),
            'sites' => $sites->get(['id', 'name'])->toArray(),
        ]);
    }

    /** Actual source facets from the same permitted records and other filters. */
    public function sourceOptionsFor(User $user, array $filters = [], ?HealthSafetyReadContext $context = null): Collection
    {
        if ($context === null) {
            return collect($this->governance->withCurrentViewer($user,
                fn (User $current, HealthSafetyReadContext $reads): array => $this->sourceOptionsFor($current, $filters, $reads)->all()));
        }
        unset($filters['source']);

        return $this->forUser($user, $filters, $context)->setEagerLoads([])->reorder()->select('control_room_alerts.source')
            ->whereNotNull('control_room_alerts.source')->where('control_room_alerts.source', '!=', '')
            ->distinct()->orderBy('control_room_alerts.source')->pluck('control_room_alerts.source')
            ->map(fn (string $source): array => ['key' => $source, 'label' => Str::headline($source)])->values();
    }

    private function visibleAlerts(User $user): Builder
    {
        return $this->applyVisibleAlertScope(ControlRoomAlert::query(), $user);
    }

    private function applyVisibleAlertScope(Builder $query, User $user): Builder
    {
        return $this->alertAccess->applyVisibleScope($query, $user);
    }

    private function assignableStaff(User $user): Collection
    {
        if (! $user->canDo('controlRoom.alerts.assign') && ! $user->canDo('controlRoom.alerts.manage')) {
            return collect();
        }

        $staff = User::query()->staff()->orderBy('name');
        $this->siteAccess->applyControlRoomAssigneeScope(
            $staff,
            $user,
            self::BYPASS_PERMISSIONS,
        );

        return $staff->get(['id', 'name', 'email']);
    }

    private function applyLens(Builder $query, string $lens, User $user): void
    {
        match ($lens) {
            'history' => $query->whereIn('control_room_alerts.status', ControlRoomAlert::TERMINAL_STATUSES),
            'snoozed' => $query->snoozed(),
            'all_active' => $query->actionable(),
            'all_records' => $query,
            'my_queue' => $query->actionable()->notSnoozed()->where('control_room_alerts.assigned_to_user_id', $user->id),
            'safety_handover' => $query->actionable()->notSnoozed(),
            default => $query->actionable()->notSnoozed(),
        };
    }
}
