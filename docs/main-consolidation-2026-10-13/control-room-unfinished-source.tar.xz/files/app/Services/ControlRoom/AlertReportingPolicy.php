<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\Signal;
use App\Models\ControlRoomAlert;
use App\Models\MedicationError;
use App\Models\WorkplaceInjury;
use App\Services\CurrentAuthorizationReads;
use App\Services\Medication\MedicationErrorWorkflow;
use App\Services\Medication\MedicationSignalService;
use Illuminate\Support\Collection;

/** Read actual source obligations; labels and untrusted context never supply policy. */
final class AlertReportingPolicy
{
    public function __construct(private readonly MedicationErrorWorkflow $medicationErrors) {}

    /** @return array{required: bool, canDecide: bool, code: string, explanation: string, policy: array|null, source_signature: string} */
    public function forAlert(ControlRoomAlert $alert, bool $lockSource = false): array
    {
        $sources = Signal::query()->where(function ($query) use ($alert): void {
            $query->where('alert_id', $alert->id)->orWhere('correlated_alert_id', $alert->id);
            if ($alert->origin_signal_id !== null) {
                $query->orWhereKey($alert->origin_signal_id);
            }
        })
            ->when($lockSource, fn ($query) => $query->lockForUpdate())
            ->with(['signalSource' => fn ($query) => $query->when($lockSource, fn ($source) => $source->lockForUpdate())])->orderBy('id')->get();

        return $this->evaluate($alert, $sources, $this->errorsForSources($sources, $lockSource), $this->injuriesForAlerts(collect([$alert]), $lockSource));
    }

    /** Fresh request-local batches; no policy or authority survives a request. */
    public function forAlerts(iterable $alerts, ?CurrentAuthorizationReads $reads = null): Collection
    {
        $alerts = collect($alerts)->keyBy(fn (ControlRoomAlert $alert): int => (int) $alert->id);
        if ($alerts->isEmpty()) {
            return collect();
        }
        $originOwners = $alerts->filter(fn (ControlRoomAlert $alert): bool => $alert->origin_signal_id !== null)
            ->groupBy(fn (ControlRoomAlert $alert): int => (int) $alert->origin_signal_id);
        $sourceQuery = Signal::query()->where(function ($query) use ($alerts, $originOwners): void {
            $query->whereIn('alert_id', $alerts->keys())->orWhereIn('correlated_alert_id', $alerts->keys());
            if ($originOwners->isNotEmpty()) {
                $query->orWhereIn('id', $originOwners->keys());
            }
        })->with(['signalSource' => fn ($relation) => $reads?->query($relation->getQuery())])->orderBy('id');
        $sources = ($reads ? $reads->query($sourceQuery) : $sourceQuery)->get();
        $errors = $this->errorsForSources($sources, reads: $reads);
        $injuries = $this->injuriesForAlerts($alerts, reads: $reads);
        $byAlert = collect();
        foreach ($sources as $source) {
            $owners = collect([$source->alert_id, $source->correlated_alert_id])
                ->merge($originOwners->get((int) $source->id, collect())->pluck('id'))->filter()->unique();
            foreach ($owners as $owner) {
                if (! $alerts->has((int) $owner)) {
                    continue;
                }
                if (! $byAlert->has((int) $owner)) {
                    $byAlert->put((int) $owner, collect());
                }
                $byAlert->get((int) $owner)->push($source);
            }
        }

        return $alerts->map(fn (ControlRoomAlert $alert): array => $this->evaluate(
            $alert, $byAlert->get((int) $alert->id, collect()), $errors, $injuries,
        ));
    }

    private function errorsForSources(Collection $sources, bool $lockSource = false, ?CurrentAuthorizationReads $reads = null): Collection
    {
        $ids = $sources->where('signal_type_code', MedicationSignalService::TYPE_ERROR)
            ->map(fn (Signal $source): ?int => $this->errorId(data_get($source->normalized_data, 'medication_error_id')))
            ->filter()->unique()->values();

        $query = MedicationError::withTrashed()->whereIn('id', $ids)
            ->orderBy('id')->when($lockSource, fn ($query) => $query->lockForUpdate());

        return $ids->isEmpty() ? collect() : ($reads ? $reads->query($query) : $query)->get()->keyBy('id');
    }

    private function errorId(mixed $id): ?int
    {
        return (is_int($id) || (is_string($id) && ctype_digit($id))) && (int) $id > 0 ? (int) $id : null;
    }

    private function injuriesForAlerts(Collection $alerts, bool $lockSource = false, ?CurrentAuthorizationReads $reads = null): Collection
    {
        $ids = $alerts->filter(fn (ControlRoomAlert $alert): bool => $alert->source === 'operations' && $alert->alert_type === 'operations.workplace_injury')
            ->map(fn (ControlRoomAlert $alert): ?int => $this->errorId(data_get($alert->context, 'workplace_injury_id')))
            ->filter()->unique()->values();

        $query = WorkplaceInjury::withTrashed()->whereIn('id', $ids)
            ->orderBy('id')->when($lockSource, fn ($query) => $query->lockForUpdate());

        // Reporting obligation metadata does not require private medical/recovery columns.
        return $ids->isEmpty() ? collect() : ($reads ? $reads->query($query) : $query)
            ->get(['id', 'user_id', 'site_id', 'status', 'updated_at'])->keyBy('id');
    }

    private function evaluate(ControlRoomAlert $alert, Collection $sources, Collection $errors, Collection $injuries): array
    {
        $signature = [
            'source' => $alert->source, 'alert_type' => $alert->alert_type,
            'origin_signal_id' => $alert->origin_signal_id,
            'site_id' => $alert->site_id, 'client_id' => $alert->client_id,
        ];
        $basis = [
            'required' => false, 'canDecide' => true,
            'code' => 'reporting_policy_unknown',
            'explanation' => 'No applicable incident requirement has been established. Continue the operational response and review reporting when appropriate.',
            'policy' => null,
            'source_reports' => [],
            'report_target' => $alert->client_id !== null ? 'client_incident' : null,
        ];

        // The canonical emitter binds this source error to one signal/alert.
        // A claimed error ID without that origin and client/Site tuple is not policy.
        $errorSources = $sources->where('signal_type_code', MedicationSignalService::TYPE_ERROR);
        foreach ($errorSources as $source) {
            $errorId = data_get($source->normalized_data, 'medication_error_id');
            $error = $errors->get($this->errorId($errorId));
            $canonical = $error !== null
                && $source->signalSource?->vendor === 'internal'
                && $source->signalSource?->slug === 'medication'
                && ((int) $source->alert_id === (int) $alert->id || (int) $source->correlated_alert_id === (int) $alert->id)
                && (int) $source->client_id === (int) $alert->client_id
                && (int) $error->client_id === (int) $alert->client_id
                && $alert->site_id !== null
                && (int) $source->site_id === (int) $alert->site_id;
            $basis['canDecide'] = false; // Clinical facts and authority remain in Medication.
            if ($canonical) {
                $required = $this->medicationErrors->incidentRequired($error);
                $basis['required'] = $basis['required'] || $required;
                $basis['code'] = $basis['required'] ? 'medication_error_incident_required' : 'medication_error_reporting_review';
                $basis['explanation'] = $basis['required']
                    ? 'The canonical medication error requires an incident. Complete its reporting in Medication.'
                    : 'Review reporting in the canonical medication error. An optional report is not an automatic H&S handover requirement.';
                $basis['policy'] = ['reference' => 'MedicationErrorWorkflow::incidentRequired', 'version' => null];
                $signature['medication_errors'][$source->id] = [
                    $error->id, $error->report_source, $error->reached_client, $error->harm_level,
                    $error->client_incident_id, $error->updated_at?->toIso8601String(),
                ];
                if ($required) {
                    // Each canonical source must satisfy its own report tuple.
                    // The incident from another correlated source cannot substitute.
                    $basis['source_reports'][] = [
                        'kind' => 'client_incident',
                        'incident_id' => $error->client_incident_id,
                        'client_id' => $error->client_id, 'site_id' => $source->site_id,
                    ];
                }
            } else {
                $signature['unverified_medication_sources'][$source->id] = [
                    $source->signal_source_id, $source->alert_id, $source->correlated_alert_id,
                    $source->client_id, $source->site_id, $errorId,
                ];
                if (! $basis['required']) {
                    $basis['code'] = 'source_reporting_review_unavailable';
                    $basis['explanation'] = 'The canonical source reporting requirement could not be verified. Review or repair the source link; no requirement has been waived.';
                }
            }
        }
        if ($alert->source === 'operations' && $alert->alert_type === 'operations.workplace_injury') {
            $injuryId = $this->errorId(data_get($alert->context, 'workplace_injury_id'));
            $injury = $injuries->get($injuryId);
            $canonical = $injury !== null && $alert->client_id === null && $injury->site_id !== null
                && (int) $injury->site_id === (int) $alert->site_id && $injury->user_id !== null;
            $basis['canDecide'] = false;
            $basis['report_target'] = $canonical ? 'workplace_injury' : null;
            if ($canonical) {
                $basis['required'] = true;
                $basis['code'] = 'workplace_injury_report_required';
                $basis['explanation'] = 'The canonical staff injury report and its H&S projection are required. H&S acceptance and governance closure remain separate.';
                $basis['policy'] = ['reference' => 'WorkplaceInjuryJourneyService::synchronize', 'version' => null];
                $basis['source_reports'][] = ['kind' => 'workplace_injury', 'source_id' => (int) $injury->id,
                    'staff_id' => (int) $injury->user_id, 'site_id' => (int) $injury->site_id, 'status' => $injury->status];
                $signature['workplace_injury'] = [$injury->id, $injury->user_id, $injury->site_id, $injury->status, $injury->updated_at?->toIso8601String()];
            } else {
                $basis['code'] = 'source_reporting_review_unavailable';
                $basis['explanation'] = 'The canonical staff injury report could not be verified. Repair the source link; no reporting requirement has been waived.';
                $signature['unverified_workplace_injury'] = $injuryId;
            }
        }
        if ($alert->status === ControlRoomAlert::STATUS_CONFIRMED && ! $basis['required']) {
            // Confirm is the existing command that creates a report atomically.
            // A broken confirmed tuple is a repair obligation, not an optional decision.
            $basis = [
                'required' => true, 'canDecide' => false,
                'code' => 'confirmed_detection_report',
                'explanation' => 'Confirmed detection requires its canonical incident report. Repair the reporting link before completion.',
                'policy' => ['reference' => 'SensorIncidentBridgeService::confirm', 'version' => null],
                'source_reports' => [],
                'report_target' => 'client_incident',
            ];
            $signature['confirmed'] = true;
        } elseif ($errorSources->isEmpty() && (app(ControlRoomAlertAccessService::class)->isMedicationAlert($alert)
            || $alert->source === 'safeguarding')) {
            // Classification restricts who may decide; it never invents an obligation.
            $basis['canDecide'] = false;
            $basis['code'] = 'source_reporting_review';
            $basis['explanation'] = 'Review reporting in the authorised source workflow while continuing the operational response.';
        }

        $signature['policy_basis'] = [$basis['required'], $basis['canDecide'], $basis['code']];

        return [...$basis, 'source_signature' => hash('sha256', json_encode($signature, JSON_THROW_ON_ERROR))];
    }
}
