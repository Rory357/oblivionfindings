<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\Communication;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoom\SignalRule;
use App\Models\ControlRoom\SlaDefinition;
use App\Models\ControlRoom\TriageQueue;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Notifications\ControlRoomAlertNotification;
use App\Services\CurrentAuthorizationReads;
use App\Services\NotificationService;
use Illuminate\Contracts\Notifications\Dispatcher;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

/**
 * Central notification service for Control Room alerts.
 *
 * All operational notifications related to CR alerts must flow through this service.
 * This is the ONLY place where escalation-driven notifications originate.
 *
 * Notifications are a CONSEQUENCE of alert state changes (creation, escalation,
 * SLA breach, queue movement) — they do NOT drive escalation.
 */
class ControlRoomNotificationService
{
    private const OUTBOX_TEMPLATE_PREFIX = 'control-room-alert-notification-v2:';

    private const MAX_OUTBOX_ATTEMPTS = 3;

    public function __construct(
        private readonly Dispatcher $dispatcher,
        private readonly ControlRoomAlertAccessService $alertAccess,
        private readonly ControlRoomRecipientEligibilityService $eligibility,
    ) {}

    /**
     * Notify on initial alert creation.
     */
    public function notifyAlert(ControlRoomAlert $alert, ?SignalRule $rule, ?TriageQueue $queue): void
    {
        $users = $this->authorizedRecipients(
            $alert,
            $this->resolveUsers($alert, $rule, $queue),
        );
        if ($users->isEmpty()) {
            return;
        }

        $this->sendToUsers($alert, $users, 'notification');
    }

    /**
     * Stage initial alert notifications as a transactional outbox.
     *
     * @return Collection<int, Communication>
     */
    public function stageAlertNotifications(
        ControlRoomAlert $alert,
        ?SignalRule $rule,
        ?TriageQueue $queue,
    ): Collection {
        return DB::transaction(fn () => $this->stageAlertNotificationsWithinTransaction($alert, $rule, $queue), 3);
    }

    private function stageAlertNotificationsWithinTransaction(
        ControlRoomAlert $alert,
        ?SignalRule $rule,
        ?TriageQueue $queue,
    ): Collection {
        // Callers may retain a preloaded response across a source correction or completion.
        $alert = ControlRoomAlert::query()->findOrFail($alert->id);
        if (! $alert->isActionable()) {
            Communication::query()->where('alert_id', $alert->id)->whereNotNull('delivery_key')
                ->where('purpose', 'notification')->where('channel', 'in_app')
                ->whereIn('status', ['pending', 'failed'])->whereNull('superseded_at')
                ->update(['superseded_at' => now(), 'status_detail' => 'Response is no longer active. Initial notice was not sent.']);

            return collect();
        }
        $users = $this->authorizedRecipients(
            $alert,
            $this->resolveUsers($alert, $rule, $queue),
        );
        $generation = $this->routingGeneration($alert, $rule, $queue, $users);
        $template = self::OUTBOX_TEMPLATE_PREFIX.$generation;
        $snapshot = $this->notificationSnapshot($alert, $rule, $queue, $generation);
        $content = $this->buildContent($alert, 'notification', []);

        $communications = $users
            ->map(fn (User $user) => $this->eligibility->withCurrentEligible($alert, $user,
                function (User $current, ControlRoomAlert $currentAlert, CurrentAuthorizationReads $reads, array $injury) use ($content, $generation, $snapshot, $template): int {
                    if (! hash_equals($snapshot['source_authority_signature'], $this->sourceAuthoritySignature($currentAlert))) {
                        throw new \RuntimeException('Source authority changed while notification routing was staged. Retry current routing.');
                    }
                    $snapshot = $this->projectSnapshot($snapshot, $injury);
                    $deliveryKey = hash('sha256', implode('|', [
                        'control-room-alert-notification-v2',
                        $currentAlert->id,
                        $generation,
                        $current->id,
                    ]));

                    $communication = Communication::query()->firstOrCreate(
                        ['delivery_key' => $deliveryKey],
                        [
                            'alert_id' => $currentAlert->id,
                            'channel' => 'in_app',
                            'direction' => 'outbound',
                            'purpose' => 'notification',
                            'target_user_id' => $current->id,
                            'content' => $content,
                            'notification_payload' => $snapshot,
                            'template_used' => $template,
                            'status' => 'pending',
                            'initiated_by_user_id' => null,
                        ],
                    );

                    $communication = $this->persistedCommunication($communication);
                    if ($communication->delivery_key !== $deliveryKey
                        || (int) $communication->alert_id !== (int) $currentAlert->id
                        || $communication->channel !== 'in_app'
                        || $communication->direction !== 'outbound'
                        || $communication->purpose !== 'notification'
                        || (int) $communication->target_user_id !== (int) $current->id
                        || $communication->template_used !== $template
                    ) {
                        throw new \DomainException('Notification routing does not match its persisted communication.');
                    }

                    if (! is_array($communication->notification_payload)
                        || (($injury['access'] ?? 'absent') !== 'absent' && $communication->status !== 'sent'
                            && $communication->notification_payload !== $snapshot)) {
                        if (! $communication->forceFill([
                            'content' => $content,
                            'notification_payload' => $snapshot,
                        ])->save()) {
                            throw new \RuntimeException('Notification routing payload was not persisted.');
                        }
                        $communication = $this->persistedCommunication($communication);
                        if ($communication->notification_payload !== $snapshot) {
                            throw new \RuntimeException('Notification routing payload was not persisted.');
                        }
                    }

                    if ($communication->superseded_at !== null
                        && in_array($communication->status, ['pending', 'failed'], true)
                    ) {
                        if (! $communication->forceFill([
                            'superseded_at' => null,
                            'status_detail' => null,
                        ])->save()) {
                            throw new \RuntimeException('Notification routing revival was not persisted.');
                        }
                        $communication = $this->persistedCommunication($communication);
                        if ($communication->superseded_at !== null || $communication->status_detail !== null) {
                            throw new \RuntimeException('Notification routing revival was not persisted.');
                        }
                    }

                    return (int) $this->persistedCommunication($communication)->id;
                }))
            ->filter()
            ->map(fn (int $id): Communication => $this->persistedCommunication(Communication::query()->findOrFail($id)))
            ->values();

        Communication::query()
            ->where('alert_id', $alert->id)
            ->whereNotNull('delivery_key')
            ->where('purpose', 'notification')
            ->where('channel', 'in_app')
            ->whereIn('status', ['pending', 'failed'])
            ->whereNull('superseded_at')
            ->where(function ($query) use ($template): void {
                $query->whereNull('template_used')
                    ->orWhere('template_used', '!=', $template);
            })
            ->update([
                'superseded_at' => now(),
                'status_detail' => "Superseded by routing generation {$generation}",
            ]);

        $this->recordRoutingOutcome($alert, $communications->count());

        return $communications;
    }

    private function recordRoutingOutcome(ControlRoomAlert $alert, int $eligibleCount): void
    {
        DB::transaction(function () use ($alert, $eligibleCount): void {
            $current = ControlRoomAlert::query()->whereKey($alert->id)->lockForUpdate()->firstOrFail();
            $state = $eligibleCount > 0 ? 'eligible_recipients_found' : 'no_eligible_recipients';
            if (data_get($current->context, 'notification_routing.state') === $state
                && data_get($current->context, 'notification_routing.eligible_recipients') === $eligibleCount) {
                return;
            }
            $current->forceFill(['context' => [...($current->context ?? []), 'notification_routing' => [
                'state' => $state, 'eligible_recipients' => $eligibleCount, 'checked_at' => now()->toIso8601String(),
            ]]]);
            if (! $current->save()) {
                throw new \RuntimeException('Notification routing outcome was not persisted.');
            }
        }, 3);
    }

    /**
     * Deliver one persisted row under its lock. The database notification and
     * terminal outbox state share this transaction and any caller transaction.
     *
     * @return list<int> Current-generation outbox rows that should be dispatched
     */
    public function deliverStagedNotification(Communication $communication): array
    {
        return DB::transaction(fn () => $this->deliverPersistedNotification($this->persistedCommunication($communication)), 3);
    }

    private function deliverPersistedNotification(Communication $communication): array
    {
        if ($communication->superseded_at !== null
            || (int) $communication->retry_count >= self::MAX_OUTBOX_ATTEMPTS
            || ! in_array($communication->status, ['pending', 'failed'], true)
        ) {
            return [];
        }

        if ($communication->purpose !== 'notification'
            || $communication->channel !== 'in_app'
            || $communication->target_user_id === null
        ) {
            throw new \DomainException('Communication is not a staged Control Room alert notification.');
        }

        $alert = ControlRoomAlert::query()->findOrFail($communication->alert_id);
        if (! $alert->isActionable()) {
            if (! $communication->forceFill(['superseded_at' => now(),
                'status_detail' => 'Response is no longer active. Initial notice was not sent.'])->save()) {
                throw new \RuntimeException('Completed notification supersession was not persisted.');
            }
            if ($this->persistedCommunication($communication)->superseded_at === null) {
                throw new \RuntimeException('Completed notification supersession was not persisted.');
            }

            return [];
        }
        $snapshot = [];
        if (str_starts_with((string) $communication->template_used, self::OUTBOX_TEMPLATE_PREFIX)) {
            $snapshot = $communication->notification_payload;
            if (! is_array($snapshot)) {
                $snapshot = json_decode((string) $communication->content, true);
            }
            if (! is_array($snapshot)) {
                throw new \DomainException('Staged Control Room alert notification snapshot is invalid.');
            }

            $rule = isset($snapshot['signal_rule_id'])
                ? SignalRule::query()->find($snapshot['signal_rule_id'])
                : null;
            $queue = $alert->queue_id === null
                ? null
                : TriageQueue::query()->find($alert->queue_id);
            $currentUsers = $this->authorizedRecipients(
                $alert,
                $this->resolveUsers($alert, $rule, $queue),
            );
            $currentGeneration = $this->routingGeneration($alert, $rule, $queue, $currentUsers);
            $currentTemplate = self::OUTBOX_TEMPLATE_PREFIX.$currentGeneration;

            if ($communication->template_used !== $currentTemplate
                || ! $currentUsers->contains(
                    fn (User $candidate): bool => (int) $candidate->id === (int) $communication->target_user_id,
                )
            ) {
                return $this->stageAlertNotifications($alert, $rule, $queue)
                    ->filter(fn (Communication $current): bool => $current->superseded_at === null
                        && (int) $current->retry_count < self::MAX_OUTBOX_ATTEMPTS
                        && in_array($current->status, ['pending', 'failed'], true)
                        && (int) $current->id !== (int) $communication->id)
                    ->pluck('id')
                    ->map(fn (int|string $id): int => (int) $id)
                    ->unique()
                    ->values()
                    ->all();
            }
        }

        // Refresh recipient-purpose evidence before the final send boundary. A changed
        // factual source/access revision must not leave every retry tied to an old proof.
        $freshSnapshot = $this->currentNotificationSnapshot($alert, (int) $communication->target_user_id, $snapshot);
        if (is_array($freshSnapshot) && $freshSnapshot !== $snapshot) {
            if (! $communication->forceFill(['notification_payload' => $freshSnapshot,
                'content' => $this->buildContent($alert, 'notification', $freshSnapshot)])->save()) {
                throw new \RuntimeException('Notification current source projection was not persisted.');
            }
            $communication = $this->persistedCommunication($communication);
            if ($communication->notification_payload !== $freshSnapshot) {
                throw new \RuntimeException('Notification current source projection was not persisted.');
            }
            $snapshot = $freshSnapshot;
        }
        $delivered = $this->eligibility->withCurrentEligible($alert, (int) $communication->target_user_id,
            function (User $current, ControlRoomAlert $currentAlert, CurrentAuthorizationReads $reads, array $injury) use ($communication, $snapshot): bool {
                if (! $currentAlert->isActionable()) {
                    return false;
                }
                if (isset($snapshot['source_authority_signature'])
                    && ! hash_equals($snapshot['source_authority_signature'], $this->sourceAuthoritySignature($currentAlert))) {
                    return false;
                }
                if ($this->projectSnapshot($snapshot, $injury) !== $snapshot) {
                    return false;
                }
                $this->dispatcher->send($current, new ControlRoomAlertNotification($currentAlert, $snapshot));
                if (! $communication->forceFill([
                    'status' => 'sent', 'status_detail' => null, 'sent_at' => now(),
                ])->save()) {
                    throw new \RuntimeException('Notification sent state was not persisted.');
                }
                $persisted = $this->persistedCommunication($communication);
                if ($persisted->status !== 'sent' || $persisted->sent_at === null || $persisted->status_detail !== null) {
                    throw new \RuntimeException('Notification sent state was not persisted.');
                }

                return true;
            });
        if ($delivered !== true) {
            $this->retainChangedRoutingIntent($communication);

            return [];
        }

        return [];
    }

    private function persistedCommunication(Communication $communication): Communication
    {
        if (! $communication->exists || $communication->getKey() === null) {
            throw new \RuntimeException('Notification communication was not persisted.');
        }

        $persisted = Communication::query()->whereKey($communication->getKey())->lockForUpdate()->first();
        if ($persisted === null) {
            throw new \RuntimeException('Notification communication was not persisted.');
        }

        return $persisted;
    }

    private function currentNotificationSnapshot(ControlRoomAlert $alert, int $recipientId, array $snapshot): ?array
    {
        return $this->eligibility->withCurrentEligible($alert, $recipientId,
            fn (User $current, ControlRoomAlert $fresh, CurrentAuthorizationReads $reads, array $injury): array => $this->projectSnapshot($snapshot, $injury));
    }

    /** Keep the existing recovery sweep's durable work when the final current proof differs from discovery. */
    private function retainChangedRoutingIntent(Communication $communication): void
    {
        DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($communication): void {
            $alert = $reads->query(ControlRoomAlert::query())->whereKey($communication->alert_id)->first();
            if ($alert === null || ! $alert->isActionable()) {
                if (! $communication->forceFill(['superseded_at' => now(),
                    'status_detail' => 'Response is no longer active. Initial notice was not sent.'])->save()) {
                    throw new \RuntimeException('Changed notification routing intent was not persisted.');
                }
                if ($this->persistedCommunication($communication)->superseded_at === null) {
                    throw new \RuntimeException('Changed notification routing intent was not persisted.');
                }

                return;
            }

            $attempt = (int) $communication->retry_count + 1;
            $retryable = $attempt < self::MAX_OUTBOX_ATTEMPTS;
            if (! $communication->forceFill([
                'status' => 'failed', 'retry_count' => $attempt,
                'status_detail' => $retryable
                    ? 'Current routing changed before delivery. A fresh routing check is pending; this notice was not sent.'
                    : 'Routing kept changing before delivery. This notice was not sent; review current recipients and delivery failures.',
            ])->save()) {
                throw new \RuntimeException('Changed notification routing intent was not persisted.');
            }
            $persisted = $this->persistedCommunication($communication);
            if ($persisted->status !== 'failed' || (int) $persisted->retry_count !== $attempt) {
                throw new \RuntimeException('Changed notification routing intent was not persisted.');
            }
            $alert->forceFill(['context' => [...($alert->context ?? []), 'notification_routing' => [
                'state' => $retryable ? 'routing_retry_pending' : 'routing_requires_review',
                'pending_communication_id' => (int) $communication->id,
                'checked_at' => now()->toIso8601String(),
            ]]]);
            if (! $alert->save()) {
                throw new \RuntimeException('Changed notification routing intent was not persisted.');
            }
        }), 3);
    }

    private function routingGeneration(
        ControlRoomAlert $alert,
        ?SignalRule $rule,
        ?TriageQueue $queue,
        Collection $users,
    ): string {
        return hash('sha256', json_encode([
            'version' => 2,
            'alert_id' => (int) $alert->id,
            'severity' => $alert->severity,
            'alert_type' => $alert->alert_type,
            'source' => $alert->source,
            'source_authority_signature' => $this->sourceAuthoritySignature($alert),
            'queue_id' => $queue?->id,
            'signal_rule_id' => $rule?->id,
            'recipient_ids' => $users
                ->pluck('id')
                ->map(fn (int|string $id): int => (int) $id)
                ->sort()
                ->values()
                ->all(),
        ], JSON_THROW_ON_ERROR));
    }

    private function notificationSnapshot(
        ControlRoomAlert $alert,
        ?SignalRule $rule,
        ?TriageQueue $queue,
        string $generation,
    ): array {
        return [
            'type' => 'control_room_alert',
            'alert_id' => (int) $alert->id,
            'severity' => $alert->severity,
            'status' => $alert->status,
            'alert_type' => $alert->alert_type,
            'source' => $alert->source,
            'triggered_at' => $alert->triggered_at?->toISOString(),
            'escalation_level' => $alert->escalation_level,
            'routing_generation' => $generation,
            'queue_id' => $queue?->id,
            'signal_rule_id' => $rule?->id,
            'source_authority_signature' => $this->sourceAuthoritySignature($alert),
        ];
    }

    private function sourceAuthoritySignature(ControlRoomAlert $alert): string
    {
        return hash('sha256', json_encode([
            $alert->source, $alert->alert_type, $alert->severity, $alert->queue_id,
            $alert->status, (int) $alert->escalation_level, $alert->triggered_at?->toISOString(),
            $alert->client_id, $alert->site_id, $alert->origin_signal_id,
            data_get($alert->context, 'normalized_data.controlled_drug'),
            data_get($alert->context, 'restraint_event_id'), data_get($alert->context, 'normalized_data.restraint_event_id'),
            data_get($alert->context, 'workplace_injury_id'), data_get($alert->context, 'user_id'),
            data_get($alert->context, 'normalized_data.workplace_injury_id'),
        ], JSON_THROW_ON_ERROR));
    }

    /** Purpose-fixed injury facts are proof input only, never copied medical message content. */
    private function projectSnapshot(array $snapshot, array $injury): array
    {
        if (($injury['access'] ?? 'absent') === 'absent') {
            return $snapshot;
        }
        $safe = Arr::only($snapshot, ['type', 'alert_id', 'severity', 'status', 'alert_type', 'source',
            'triggered_at', 'escalation_level', 'routing_generation', 'queue_id', 'signal_rule_id', 'source_authority_signature',
            'from_queue', 'to_queue', 'breach_types']);
        $safe['source_privacy_signature'] = hash('sha256', json_encode($injury, JSON_THROW_ON_ERROR));

        return $safe;
    }

    /**
     * Notify on SLA breach escalation.
     *
     * Sends notifications to the roles defined in the SlaDefinition's
     * breach_notify_roles, plus the alert's current queue assigned roles.
     */
    public function notifySlaBreachEscalation(
        ControlRoomAlert $alert,
        SlaDefinition $slaDefinition,
        array $breachTypes,
    ): void {
        $roles = collect($slaDefinition->breach_notify_roles ?? []);

        // Also notify the current queue's assigned roles
        if ($alert->queue_id) {
            $queue = TriageQueue::find($alert->queue_id);
            if ($queue?->assigned_roles) {
                $roles = $roles->merge($queue->assigned_roles);
            }
        }

        $users = $this->authorizedRecipients(
            $alert,
            $this->resolveUsersByRoles($alert, $roles->unique()->values()->toArray()),
        );
        if ($users->isEmpty()) {
            return;
        }

        $breachLabel = implode(', ', $breachTypes);

        $this->sendToUsers($alert, $users, 'escalation', [
            'escalation_reason' => "SLA breach: {$breachLabel}",
            'breach_types' => $breachTypes,
            'escalation_level' => $alert->escalation_level,
        ]);
    }

    /**
     * Notify on queue auto-escalation.
     *
     * Sends notifications to the target queue's assigned roles.
     */
    public function notifyQueueEscalation(
        ControlRoomAlert $alert,
        TriageQueue $fromQueue,
        TriageQueue $toQueue,
    ): void {
        $roles = collect($toQueue->assigned_roles ?? []);
        $users = $this->authorizedRecipients(
            $alert,
            $this->resolveUsersByRoles($alert, $roles->unique()->values()->toArray()),
        );
        if ($users->isEmpty()) {
            return;
        }

        $this->sendToUsers($alert, $users, 'escalation', [
            'escalation_reason' => "Auto-escalated from {$fromQueue->name} to {$toQueue->name}",
            'from_queue' => $fromQueue->name,
            'to_queue' => $toQueue->name,
            'escalation_level' => $alert->escalation_level,
        ]);
    }

    /**
     * Send notifications to a set of users and log as Communication records.
     */
    protected function sendToUsers(
        ControlRoomAlert $alert,
        Collection $users,
        string $purpose,
        array $extraContext = [],
    ): void {
        foreach ($this->authorizedRecipients($alert, $users) as $user) {
            $this->eligibility->withCurrentEligible($alert, $user, function (User $current, ControlRoomAlert $currentAlert, CurrentAuthorizationReads $reads, array $injury) use ($purpose, $extraContext): void {
                $safeContext = $this->projectSnapshot($extraContext, $injury);
                $current->notify(new ControlRoomAlertNotification($currentAlert, $safeContext));

                $communication = Communication::create([
                    'alert_id' => $currentAlert->id,
                    'channel' => 'in_app',
                    'direction' => 'outbound',
                    'purpose' => $purpose,
                    'target_user_id' => $current->id,
                    'content' => $this->buildContent($currentAlert, $purpose, $safeContext),
                    'status' => 'sent',
                    'sent_at' => now(),
                    'initiated_by_user_id' => null,
                ]);
                $persisted = $this->persistedCommunication($communication);
                if ($persisted->status !== 'sent' || $persisted->sent_at === null) {
                    throw new \RuntimeException('Notification sent state was not persisted.');
                }
            });
        }
    }

    /**
     * Build human-readable content for Communication log.
     */
    protected function buildContent(ControlRoomAlert $alert, string $purpose, array $context): string
    {
        $base = "Alert {$alert->alert_type} ({$alert->severity})";
        if (app(ControlRoomGovernanceReadService::class)->isInjuryAlert($alert)) {
            return "Workplace injury response ({$alert->severity})";
        }

        if ($purpose === 'escalation' && isset($context['escalation_reason'])) {
            return "{$base} — {$context['escalation_reason']}";
        }

        return $base;
    }

    /**
     * Resolve users from a SignalRule and/or TriageQueue: explicitly named
     * users, plus the role holders who may open this alert.
     */
    protected function resolveUsers(ControlRoomAlert $alert, ?SignalRule $rule, ?TriageQueue $queue): Collection
    {
        $userIds = collect($rule?->notify_users ?? [])
            ->merge($queue?->assigned_users ?? [])
            ->push($alert->assigned_to_user_id)
            ->filter(fn ($id): bool => is_numeric($id) && (int) $id > 0)
            ->unique()
            ->values();
        $roles = collect($rule?->notify_roles ?? [])
            ->merge($queue?->assigned_roles ?? []);

        $named = $userIds->isEmpty()
            ? collect()
            : User::query()->whereIn('id', $userIds)->get(['id', 'name', 'email']);

        $configured = $named
            ->merge($this->resolveUsersByRoles($alert, $roles->all()))
            ->unique('id')
            ->values();
        if ($this->authorizedRecipients($alert, $configured)->isNotEmpty()) {
            return $configured;
        }

        $dutyIds = Shift::query()->current()->get()->flatMap(fn (Shift $shift): array => $shift->memberUserIds())->unique();
        $duty = $dutyIds->isEmpty() ? collect() : User::query()->whereIn('id', $dutyIds)->get(['id', 'name', 'email']);

        return $configured->merge($duty)->merge($this->resolveUsersByRoles($alert, ['managers_core']))->unique('id')->values();
    }

    /**
     * Resolve role routing to the role holders who may open this alert.
     *
     * Routing fields hold role-group names (the seeded signal rules use
     * 'managers_core' and 'coordinators', which are not role names) or
     * literal role names (Settings and the SLA page), so both resolve.
     */
    protected function resolveUsersByRoles(ControlRoomAlert $alert, array $roleNames): Collection
    {
        $names = collect($roleNames)
            ->filter(fn (mixed $name): bool => is_string($name) && $name !== '')
            ->unique()
            ->values();
        if ($names->isEmpty()) {
            return collect();
        }

        $groups = app(NotificationService::class);
        $userIds = User::query()
            ->whereHas('roles', fn ($rq) => $rq->whereIn('name', $names))
            ->pluck('id');
        foreach ($names as $name) {
            $userIds = $userIds->merge($groups->resolveRoleGroupUserIds($name));
        }

        if ($userIds->isEmpty()) {
            return collect();
        }

        return User::query()
            ->whereIn('id', $userIds->unique()->values())
            ->get(['id', 'name', 'email'])
            ->values();
    }

    /**
     * Configuration nominates candidates; current staff, canonical alert and
     * confidential source authority determine eligibility for every source.
     */
    private function authorizedRecipients(ControlRoomAlert $alert, Collection $users): Collection
    {
        return $users
            ->unique('id')
            ->filter(fn (User $user): bool => $this->eligibility->withCurrentEligible($alert, $user, fn (): bool => true) === true)
            ->values();
    }
}
