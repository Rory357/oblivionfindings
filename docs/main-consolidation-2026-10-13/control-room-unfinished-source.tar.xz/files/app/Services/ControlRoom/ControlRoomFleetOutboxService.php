<?php

namespace App\Services\ControlRoom;

use App\Domain\Monitoring\Services\CanonicalDeviceSiteResolver;
use App\Domain\SecurityDevices\Models\Device;
use App\Domain\SecurityDevices\Models\DeviceAssetLink;
use App\Domain\SecurityDevices\Models\DeviceAssignment;
use App\Domain\SecurityDevices\Services\PersonalTrackingPrivacyService;
use App\Domain\SecurityDevices\Services\SecurityDevicesAccessService;
use App\Jobs\DispatchFleetSignalOutbox;
use App\Models\Asset;
use App\Models\FleetSignal;
use App\Models\FleetSignalOutbox;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\Consents\CurrentConsentEvidence;
use App\Services\CurrentAuthorizationReads;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use RuntimeException;
use Throwable;
use UnexpectedValueException;

/** Fleet recovery consumes canonical source policies; CR management never grants source visibility. */
final class ControlRoomFleetOutboxService
{
    private const FAILED = ['failed', 'dead_letter', 'unroutable'];

    public function __construct(
        private readonly AuthorizationEvidenceLockService $authorization,
        private readonly SecurityDevicesAccessService $sources,
        private readonly CanonicalDeviceSiteResolver $sites,
        private readonly PersonalTrackingPrivacyService $privacy,
    ) {}

    /** Bounded source-scoped discovery followed by current source disclosure, without a global failure total. */
    public function forSettings(User $viewer): array
    {
        return DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($viewer): array {
            $actor = $this->actor($viewer);
            $candidates = $reads->query(FleetSignalOutbox::query()
                ->whereIn('status', self::FAILED)
                ->whereIn('fleet_signal_id', $this->signalCandidates($actor, $reads)->select('fleet_signals.id'))
                ->latest('last_attempt_at')->latest('id')->limit(501))->get();
            $rows = collect();
            foreach ($candidates->take(500) as $outbox) {
                $signal = $this->readableSignal($outbox, $actor, $reads);
                if ($signal !== null) {
                    $rows->push($this->row($outbox, $signal));
                }
                if ($rows->count() === 100) {
                    break;
                }
            }

            return ['rows' => $rows, 'limited' => $candidates->count() > 500 || $rows->count() === 100];
        }));
    }

    /** The locked row is the durable retry intent; a replay of pending/processing/sent work never enqueues twice. */
    public function retry(Request $request, FleetSignalOutbox $hint): string
    {
        return DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($request, $hint): string {
            abort_unless($request->user(), 403);
            $actor = $this->actor($request->user());
            $outbox = FleetSignalOutbox::query()->whereKey($hint->id)->lockForUpdate()->firstOrFail();
            $signal = $this->readableSignal($outbox, $actor, $reads);
            abort_unless($signal !== null, 404);
            if (in_array($outbox->status, ['pending', 'processing', 'sent'], true)) {
                return $outbox->status;
            }
            abort_unless(in_array($outbox->status, self::FAILED, true), 422, 'Only failed signal deliveries can be retried.');
            abort_if($outbox->last_attempt_at && $outbox->last_attempt_at->gt(now()->subMinutes(5)), 429,
                'This signal delivery was attempted recently. Please wait before retrying it again.');
            $previousStatus = $outbox->status;
            $previousError = $outbox->last_error;
            if (! $outbox->forceFill(['status' => 'pending', 'last_error' => null])->save()) {
                throw new RuntimeException('The signal retry could not be saved. The original delivery has been kept.');
            }
            AuditLogger::logOrFail('controlRoom.signalOutbox.retry', $outbox, [
                'outbox_id' => $outbox->id, 'fleet_signal_id' => $signal->id,
                'previous_status' => $previousStatus, 'retried_by' => $actor->id,
            ], $request);
            DB::afterCommit(function () use ($outbox, $previousStatus, $previousError): void {
                try {
                    DispatchFleetSignalOutbox::dispatch($outbox->id);
                } catch (Throwable $exception) {
                    // Retain visible failed work if the enqueue failed before a worker claimed it.
                    DB::transaction(function () use ($outbox, $previousStatus, $previousError): void {
                        $current = FleetSignalOutbox::query()->whereKey($outbox->id)->lockForUpdate()->first();
                        if ($current?->status === 'pending' && ! $current->forceFill([
                            'status' => $previousStatus, 'last_error' => $previousError,
                        ])->save()) {
                            throw new RuntimeException('The failed signal enqueue could not be recorded.');
                        }
                    });
                    Log::warning('Control Room Fleet retry enqueue failed', ['outbox_id' => $outbox->id, 'exception_type' => $exception::class]);
                    throw new RuntimeException('The signal retry could not be queued. Review the saved delivery before retrying.', 0, $exception);
                }
            });

            return 'queued';
        }), 3);
    }

    private function actor(User $viewer): User
    {
        // Source policies use their existing grants; hydrate the full current catalogue rather than a cached partial viewer.
        $actor = $this->authorization->lockForUserWithoutWaiting($viewer, ['*']);
        abort_unless($actor->canDo('controlRoom.alerts.manage'), 403);

        return $actor;
    }

    private function signalCandidates(User $actor, CurrentAuthorizationReads $reads, ?int $deviceId = null): Builder
    {
        $sources = $this->sources->forCurrentEvidence($reads, $deviceId ?? 0);
        $signals = FleetSignal::query();
        if (! ($actor->canDo('fleet.viewAny') || $actor->canDo('assets.viewAny') || $actor->canDo('assets.viewAssigned'))) {
            return $signals->whereRaw('1 = 0');
        }
        $assets = Asset::query()->where(fn (Builder $scope) => $scope
            ->whereIn('assets.id', $sources->accessibleAssets($actor)->select('assets.id'))
            ->orWhereIn('assets.id', $sources->siteScopedVehiclesForFleet($actor)->select('assets.id')));
        $signals->whereIn('asset_id', $assets->select('assets.id'));
        $sources->applyTemporalEventCustodyScope($signals, $actor, 'fleet_signals.device_id', 'fleet_signals.occurred_at');

        return $signals;
    }

    /** Every private/current model remains inside the same guarded operation; none is returned as authority. */
    private function readableSignal(FleetSignalOutbox $outbox, User $actor, CurrentAuthorizationReads $reads): ?FleetSignal
    {
        $hint = $reads->query(FleetSignal::query())->whereKey($outbox->fleet_signal_id)->first();
        if ($hint === null || (int) $hint->device_id < 1 || (int) $hint->asset_id < 1) {
            return null;
        }
        $signal = $reads->query($this->signalCandidates($actor, $reads, (int) $hint->device_id))->whereKey($hint->id)->first();
        if ($signal === null) {
            return null;
        }
        $sources = $this->sources->forCurrentEvidence($reads, (int) $signal->device_id);
        $asset = $reads->query(Asset::query())->whereKey($signal->asset_id)->first();
        $device = $reads->query($sources->visibleDevices($actor))->whereKey($signal->device_id)->first();
        if ($asset === null || ! $device instanceof Device || ! $reads->query(DeviceAssetLink::query())
            ->forDevice((int) $device->id)->forAsset((int) $asset->id)->active()->where('linked_at', '<=', now())->exists()) {
            return null;
        }
        try {
            $siteId = $this->sites->forCurrentEvidence($reads)->resolveForContext((int) $device->id);
            if (! in_array($siteId, $sources->accessibleSiteIds($actor), true)) {
                return null;
            }
            if ($asset->client_id === null) {
                return $sources->assignableVehicle($actor, (int) $asset->id) !== null ? $signal : null;
            }
            if (! ($actor->canDo('fleet.viewAny') || $actor->canDo('assets.viewAny')) || ! $actor->canDo('assets.telemetry.view')) {
                return null;
            }
            $client = $sources->assignableClient($actor, (int) $asset->client_id);
            if ($client === null || (int) $client->site_id !== $siteId) {
                return null;
            }
            // Match the existing Fleet resident-location route's latest current Client assignment, not an older convenient consent.
            $assignment = $reads->query(DeviceAssignment::query())->current()
                ->where('assignable_type', DeviceAssignment::TARGET_CLIENT)->where('assignable_id', $client->id)
                ->latest('assigned_at')->latest('id')->first();
            if ($assignment === null || (int) $assignment->device_id !== (int) $device->id || ! $assignment->consent_id) {
                return null;
            }
            $evidence = CurrentConsentEvidence::lock((int) $assignment->consent_id);

            return $this->privacy->assignmentAuthorisesResidentLocationFromCurrentEvidence($assignment, $device, $evidence, $client)
                ? $signal : null;
        } catch (UnexpectedValueException|ModelNotFoundException) {
            return null;
        }
    }

    private function row(FleetSignalOutbox $outbox, FleetSignal $signal): array
    {
        return ['id' => $outbox->id, 'status' => $outbox->status, 'attempts' => $outbox->attempts,
            'last_attempt_at' => $outbox->last_attempt_at?->toISOString(),
            'last_error' => match ($outbox->status) {
                'dead_letter' => 'Repeated delivery attempts failed. Review the source record before retrying.',
                'unroutable' => 'This signal could not be routed to a response. Review its source record.',
                default => 'Delivery failed. Review the source record before retrying.',
            },
            'created_at' => $outbox->created_at?->toISOString(), 'updated_at' => $outbox->updated_at?->toISOString(),
            'can_retry' => ! $outbox->last_attempt_at || $outbox->last_attempt_at->lte(now()->subMinutes(5)),
            'signal' => $signal->only(['id', 'asset_id', 'device_id', 'signal_type', 'severity_hint'])
                + ['occurred_at' => $signal->occurred_at?->toISOString()]];
    }
}
