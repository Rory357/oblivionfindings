<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\Shift;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;

/** Compatibility entry point; all note admission is shared with prepared/live duty. */
final class ControlRoomAcceptedHandoverNoteService
{
    public function project(Shift $outgoing, array $saved, User $viewer, HealthSafetyReadContext $context): array
    {
        return app(ControlRoomOperatorNoteReadService::class)->saved($outgoing, $saved, $viewer, $context);
    }
}
