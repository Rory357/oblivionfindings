<?php

namespace App\Services\ControlRoom;

use App\Services\AuditLogger;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\CurrentAuthorizationReads;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Exceptions\HttpResponseException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Compare the complete persisted configuration under its write lock, including fields hidden by an editor. */
final class ControlRoomSettingsRevisionService
{
    public function __construct(private readonly AuthorizationEvidenceLockService $authorization) {}

    public function version(Model $record): string
    {
        if ($record->getRawOriginal('settings_revision') === null) {
            throw new \LogicException('Control Room settings revision schema is unavailable.');
        }
        $configuration = array_intersect_key($record->getRawOriginal(), array_flip($record->getFillable()));
        ksort($configuration);

        return hash('sha256', json_encode([
            'table' => $record->getTable(), 'id' => (int) $record->getKey(),
            'revision' => (int) $record->getRawOriginal('settings_revision'),
            'updated_at' => $record->getRawOriginal('updated_at'), 'configuration' => $configuration,
        ], JSON_THROW_ON_ERROR));
    }

    /** Validation and source/site authorization execute against the locked current row. No authority model escapes. */
    public function update(Request $request, Model $record, string $action, callable $validate, ?callable $authorize = null): void
    {
        $this->withCurrentVersion($request, $record, function (Model $current, $actor, CurrentAuthorizationReads $reads, string $version) use ($request, $action, $validate): void {
            $current->fill($validate($current, $actor, $reads));
            $changed = array_keys($current->getDirty());
            $current->forceFill(['settings_revision' => (int) $current->getRawOriginal('settings_revision') + 1]);
            if (! $current->save()) {
                throw new \RuntimeException('The setting could not be saved. Your draft has been kept.');
            }
            // Audit the database's canonical numeric/JSON representation, matching later read tokens.
            $current->refresh();
            AuditLogger::logOrFail($action, $current, [
                'changed_fields' => $changed, 'previous_version' => $version, 'version' => $this->version($current),
            ], $request);
        }, $authorize);
    }

    public function delete(Request $request, Model $record, string $action): void
    {
        $this->withCurrentVersion($request, $record, function (Model $current, $actor, CurrentAuthorizationReads $reads, string $version) use ($request, $action): void {
            if (! $current->delete()) {
                throw new \RuntimeException('The setting could not be deleted. The saved setting has been kept.');
            }
            AuditLogger::logOrFail($action, $current, ['previous_version' => $version], $request);
        });
    }

    private function withCurrentVersion(Request $request, Model $record, callable $operation, ?callable $authorize = null): void
    {
        DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($request, $record, $operation, $authorize): void {
            abort_unless($request->user(), 403);
            $actor = $this->authorization->lockForUserWithoutWaiting($request->user(), [
                'controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage', 'reports.viewAny', 'medications.controlled.view',
            ]);
            abort_unless($actor->canDo('controlRoom.alerts.manage'), 403);
            $current = $record->newQuery()->whereKey($record->getKey())->lockForUpdate()->firstOrFail();
            if ($authorize !== null) {
                $authorize($current, $actor, $reads);
            }
            $input = $request->validate(['expected_version' => ['required', 'string', 'size:64', 'regex:/^[a-f0-9]{64}$/']]);
            $version = $this->version($current);
            if (! hash_equals($version, $input['expected_version'])) {
                $this->conflict($request, $current);
            }
            $operation($current, $actor, $reads, $version);
        }), 3);
    }

    private function conflict(Request $request, Model $current): never
    {
        $message = 'This setting changed after you opened it. Your draft has been kept. Review the current saved values before saving again.';
        if ($request->expectsJson() && ! $request->header('X-Inertia')) {
            throw new HttpResponseException(response()->json([
                'code' => 'settings_conflict', 'message' => $message,
                'errors' => ['save_conflict' => [$message]],
                'current' => [...$current->only($current->getFillable()), 'version' => $this->version($current)],
            ], 409));
        }

        // Inertia receives the validation redirect and freshly scoped Settings props, retaining its remembered draft.
        throw ValidationException::withMessages(['save_conflict' => $message])->status(409);
    }
}
