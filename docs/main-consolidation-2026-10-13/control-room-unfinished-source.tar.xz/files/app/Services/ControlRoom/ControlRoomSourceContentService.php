<?php

namespace App\Services\ControlRoom;

use App\Models\ClientIncident;
use App\Models\ControlRoomAlert;
use App\Models\RestraintEvent;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\HealthSafety\InjurySourceProjectionService;
use App\Services\HealthSafety\RestraintAccessService;
use App\Services\Incidents\IncidentAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** Read-only disclosure of incident material copied into an operational record. */
final class ControlRoomSourceContentService
{
    private const INJURY_COPY_KEYS = ['workplace_injury_id', 'injury_id', 'user_id', 'site_id', 'injury_type',
        'injury_severity', 'body_part_affected', 'injury_date', 'worksafe_notifiable', 'description', 'title', 'summary',
        'immediate_treatment', 'medical_treatment_type', 'acc_claim_number', 'source_version_id', 'source_revision',
        'source_schema_version', 'related_incident_id', 'recovery', 'medical', 'assessment', 'source_id', 'source_type',
        'notes', 'capacity_assessments', 'return_to_work_plans', 'modified_duties', 'attachments', 'restrictions'];

    public function __construct(private readonly IncidentAccessService $incidents) {}

    public const RESTRICTED = 'Incident details restricted';

    public const UNAVAILABLE = 'Incident details unavailable';

    /** Canonical H&S source reader; the shared current module callback owns its evidence. */
    public function restraintForAlert(ControlRoomAlert $alert, User $viewer, ?HealthSafetyReadContext $context = null): array
    {
        $raw = is_array($alert->context) ? $alert->context : [];
        if (! $this->isRestraintAlert($alert)) {
            return ['restraint_access' => 'absent', 'restraint_source' => null];
        }
        $result = ['restraint_access' => 'unavailable', 'restraint_source' => null];
        $id = $this->positiveId($raw['restraint_event_id'] ?? null);
        $context?->assertViewer($viewer);
        if ($id === null) {
            return $result;
        }
        $access = app(RestraintAccessService::class);
        try {
            $consume = function ($current, $reads, $sites) use ($access, $alert, $id): array {
                $freshAlert = $reads->query(ControlRoomAlert::query())->find($alert->id);
                $source = $reads->query(RestraintEvent::query())->find($id);
                if (! $freshAlert || ! $source || $this->positiveId($freshAlert->context['restraint_event_id'] ?? null) !== $id
                    || (int) $freshAlert->client_id !== (int) $source->client_id
                    || ($freshAlert->site_id === null ? null : (int) $freshAlert->site_id) !== ($source->site_id === null ? null : (int) $source->site_id)) {
                    return ['restraint_access' => 'unavailable', 'restraint_source' => null];
                }
                $access->assertEvent($source, $current, $reads, $sites, 'view');

                return ['restraint_access' => 'readable', 'restraint_source' => ['id' => (int) $source->id, 'href' => '/health-safety/restraints/events/'.$source->id]];
            };

            return $context ? $access->withReadContext($context, $consume) : $access->withCurrentViewer($viewer, $consume);
        } catch (HttpException $error) {
            if (! in_array($error->getStatusCode(), [403, 404], true)) {
                throw $error;
            }

            return ['restraint_access' => 'restricted', 'restraint_source' => null];
        }
    }

    private function isRestraintAlert(ControlRoomAlert $alert): bool
    {
        return $alert->alert_type === 'operations.restraint_event'
            || array_key_exists('restraint_event_id', is_array($alert->context) ? $alert->context : [])
            || array_key_exists('restraint_event_id', (array) data_get($alert->context, 'normalized_data', []));
    }

    /**
     * The canonical records and access states are supplied once per list by
     * ControlRoomGovernanceReadService. This projector performs no queries.
     */
    public function present(ControlRoomAlert $alert, array $governance, array $context): array
    {
        $raw = is_array($alert->context) ? $alert->context : [];
        $restraintOrigin = $this->isRestraintAlert($alert);
        if ($restraintOrigin) {
            $context = Arr::except($context, ['restraint_event_id', 'restraint_id', 'source_revision', 'creation_source_revision',
                'source_deliveries', 'delivery_id', 'source_id', 'source_type', 'provenance', 'description', 'title', 'summary',
                'trigger_description', 'restraint_description', 'de_escalation_attempted', 'person_response', 'post_incident_support',
                'injury_details', 'staff_involved', 'authorised_by', 'within_support_plan', 'behaviour_support_plan_id',
                'behaviour_support_plan_version_id', 'plan_authorization_snapshot', 'normalized_data', 'signal_payload',
                'restraint_type', 'duration_minutes', 'started_at', 'ended_at', 'occurred_at', 'review_notes', 'reviewed_by', 'reviewed_at',
                'lessons_learned', 'deviation_reason', 'injury_occurred', 'monitoring', 'observations', 'debrief', 'followups',
                'creation_key', 'creation_fingerprint', 'command_key', 'idempotency_key', 'actor_snapshot', 'staff_id', 'creator_id', 'created_by']);
            $context['restraint_content_access'] = $governance['restraint_access'] ?? 'unavailable';
            $context['restraint_source'] = ($governance['restraint_access'] ?? null) === 'readable' ? ($governance['restraint_source'] ?? null) : null;
        }
        $injuryOrigin = $alert->alert_type === 'operations.workplace_injury'
            || array_key_exists('workplace_injury_id', $raw)
            || array_key_exists('workplace_injury_id', (array) data_get($raw, 'normalized_data', []));
        $injuryAccess = $governance['injury_access'] ?? 'unavailable';
        if ($injuryOrigin) {
            $context = Arr::except($context, [...self::INJURY_COPY_KEYS, 'normalized_data', 'signal_payload',
                'coordinator_snapshot', 'provenance']);
            $context = $this->injuryCopies($context);
            $context['injury_content_access'] = $injuryAccess;
            // The purpose-fixed canonical facade excludes private medical/recovery material.
            if ($injuryAccess === 'readable' && is_array($governance['injury_source'] ?? null)) {
                $fact = $governance['injury_source'];
                $context += ['workplace_injury_id' => $fact['id'], 'injury_type' => $fact['injury_type'],
                    'body_part_affected' => $fact['body_part_affected'], 'injury_severity' => $fact['severity'],
                    'injury_date' => $fact['injury_date'], 'description' => $fact['description']];
            }
        }
        $incidentOrigin = $alert->source === 'incident'
            || data_get($raw, 'provenance.source') === 'incident_journey'
            || ($raw['incident_source_type'] ?? null) === 'client_incident';
        $rootAccess = $this->incidentAccess($this->entryIncidentId($raw), $governance);
        if ($incidentOrigin && $rootAccess !== 'readable') {
            $context = Arr::except($context, [
                'incident_id', 'incident_type', 'type', 'shift_id', 'occurred_at',
                'description', 'title', 'summary', 'reported_by', 'reason', 'provenance',
                'incident_source_type', 'incident_source_id',
            ]);
            $context['incident_content_access'] = $rootAccess;
        }

        if (data_get($raw, 'normalized_data.incident_id') !== null
            && $this->incidentAccess(data_get($raw, 'normalized_data.incident_id'), $governance) !== 'readable') {
            unset($context['normalized_data'], $context['signal_payload']);
            $context['incident_content_access'] = $this->incidentAccess(data_get($raw, 'normalized_data.incident_id'), $governance);
        }

        foreach (['resolution', 'journey_attention'] as $key) {
            if (is_array($context[$key] ?? null) && $this->isIncidentEntry($context[$key])) {
                $context[$key] = $this->entry($context[$key], $governance);
            }
        }
        foreach (['resolution_history', 'operational_reopen_history'] as $key) {
            if (is_array($context[$key] ?? null)) {
                $context[$key] = array_map(fn ($entry) => is_array($entry) && $this->isIncidentEntry($entry)
                    ? $this->entry($entry, $governance) : $entry, $context[$key]);
            }
        }
        if (is_array($context['activity_log'] ?? null)) {
            $context['activity_log'] = array_map(function ($entry) use ($raw, $governance) {
                if (! is_array($entry) || ($entry['transition'] ?? null) !== 'incident_reopen') {
                    return $entry;
                }
                $sourceId = $entry['incident_id'] ?? null;
                if ($sourceId === null) {
                    // Older activity copies did not record the source ID. Only
                    // an exact matching source-history entry can establish it.
                    $matches = collect($raw['operational_reopen_history'] ?? [])->filter(fn ($history) => is_array($history)
                        && ($history['reason'] ?? null) === ($entry['content'] ?? null)
                        && $this->sameInstant($history['reopened_at'] ?? null, $entry['created_at'] ?? null)
                        && ($history['actor_id'] ?? null) === ($entry['user_id'] ?? null));
                    $ids = $matches->pluck('incident_id')->map(fn ($id) => $this->positiveId($id))->unique();
                    $sourceId = $ids->count() === 1 ? $ids->first() : null;
                }

                return $this->entry($entry + ['incident_id' => $sourceId], $governance);
            }, $context['activity_log']);
        }
        $context = $this->references($context, $governance);
        unset($context['notes_provenance'], $context['root_note_origin']);

        $notesSourceIds = $this->noteSourceIds($alert);
        $notesAccess = $this->combinedAccess($notesSourceIds, $governance);
        $notes = $notesAccess === 'readable' ? $alert->notes : null;
        if ($restraintOrigin && ! is_array($raw['source_deliveries'] ?? null) && ($governance['restraint_access'] ?? null) !== 'readable') {
            $notesAccess = $governance['restraint_access'] ?? 'unavailable';
            $notes = null;
        }
        if ($injuryOrigin) {
            // An originless legacy note is not proved factual merely because the source is readable.
            $provedFactual = $injuryAccess === 'readable' && $alert->notes === data_get($governance, 'injury_source.description');
            $notesAccess = $provedFactual ? 'readable' : ($injuryAccess === 'readable' ? 'unavailable' : $injuryAccess);
            $notes = $notesAccess === 'readable' ? $alert->notes : null;
        }
        if (array_key_exists('root_note_origin', $raw)) {
            $independent = ($governance['operator_root_note_readable'] ?? false) === true;
            $notesAccess = $independent ? 'readable' : 'unavailable';
            $notes = $independent ? $alert->notes : null;
            $notesSourceIds = $independent ? [] : $notesSourceIds;
        }
        $candidates = [
            [$context['title'] ?? null, $incidentOrigin],
            [$context['summary'] ?? null, $incidentOrigin],
            [$context['description'] ?? null, $incidentOrigin],
            [data_get($context, 'normalized_data.title'), data_get($raw, 'normalized_data.incident_id') !== null],
            [data_get($context, 'normalized_data.description'), data_get($raw, 'normalized_data.incident_id') !== null],
            [$notes, $notesSourceIds !== []],
        ];
        $summary = Str::headline((string) $alert->alert_type);
        $origin = ['type' => 'alert'];
        foreach ($candidates as [$candidate, $fromIncident]) {
            if (is_string($candidate) && trim($candidate) !== '') {
                $summary = Str::limit(trim($candidate), 160);
                $origin = $fromIncident
                    ? ['type' => 'incident', 'incident_id' => data_get($governance, 'incident.id')]
                    : ['type' => 'alert'];
                if ($injuryOrigin && $candidate === ($context['description'] ?? null)) {
                    $origin = ['type' => 'injury', 'injury_id' => data_get($governance, 'injury_source.id')];
                }
                break;
            }
        }

        $resolverVisible = data_get($raw, 'resolution.source') !== 'incident_lifecycle_signal'
            || $this->incidentAccess(data_get($raw, 'resolution.incident_id'), $governance) === 'readable';
        $acknowledgerFromIncident = data_get($raw, 'resolution.acknowledged_from_incident')
            ?? ($alert->acknowledged_by_user_id !== null
                && $alert->acknowledged_by_user_id === ($alert->resolved_by_user_id ?? data_get($raw, 'resolution.incident_lifecycle_actor_user_id'))
                && $this->sameInstant($alert->acknowledged_at?->toIso8601String(), data_get($raw, 'resolution.resolved_at')));

        return ['context' => $context, 'notes' => $notes, 'notes_access' => $notesAccess,
            'source_creator_visible' => (! $incidentOrigin || $rootAccess === 'readable') && (! $injuryOrigin || $injuryAccess === 'readable')
                && (! $restraintOrigin || ($governance['restraint_access'] ?? null) === 'readable'),
            'source_resolver_visible' => $resolverVisible,
            'source_acknowledger_visible' => $resolverVisible || ! $acknowledgerFromIncident,
            'summary' => $summary, 'summary_origin' => $origin];
    }

    /** Keep SQL search/count/pagination on the same side of the copied-note boundary. */
    public function applyReadableNotes(Builder $query, User $viewer, ?HealthSafetyReadContext $context = null, ?Builder $sourceCandidates = null): Builder
    {
        if ($context === null || $sourceCandidates === null) {
            throw new \LogicException('Copied-note search requires an active prepared context and independent candidates.');
        }
        $context->assertViewer($viewer);
        $viewer = $context->consumeSourceViewer(ControlRoomGovernanceReadService::PERMISSIONS, fn (User $current): User => $current);

        return $context->query($query->where(function (Builder $notes) use ($viewer, $context, $sourceCandidates): void {
            $notes->where(fn (Builder $operator) => app(ControlRoomOperatorRootNoteService::class)->applyVerifiedScope($operator, $context))
                ->orWhere(function (Builder $legacy) use ($viewer, $context, $sourceCandidates): void {
                    $legacy->whereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.root_note_origin') = 0");
                    $this->applyReadableSourceNotes($legacy, $viewer, $context, $sourceCandidates);
                });
        }));
    }

    private function applyReadableSourceNotes(Builder $query, User $viewer, HealthSafetyReadContext $context, Builder $sourceCandidates): Builder
    {
        $this->applyReadableRestraintNotes($query, $viewer, $context, $sourceCandidates);
        $injuryIds = [];
        $candidates = $context->query(clone $sourceCandidates)->where(function (Builder $injuries): void {
            $injuries->where('control_room_alerts.alert_type', 'operations.workplace_injury')
                ->orWhereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.workplace_injury_id', '$.normalized_data.workplace_injury_id') = 1");
        })->setEagerLoads([])->reorder();
        $candidates->chunkById(500, function ($alerts) use ($viewer, $context, &$injuryIds): void {
            foreach ($alerts as $alert) {
                $proof = app(InjurySourceProjectionService::class)->forAlert($alert, $viewer, $context);
                if ($proof['access'] === 'readable' && $alert->notes === data_get($proof, 'source.description')) {
                    $injuryIds[] = (int) $alert->id;
                }
            }
        }, 'control_room_alerts.id', 'id');
        $query->where(function (Builder $injuries) use ($injuryIds): void {
            $injuries->where(function (Builder $ordinary): void {
                $ordinary->where('control_room_alerts.alert_type', '!=', 'operations.workplace_injury')
                    ->whereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.workplace_injury_id', '$.normalized_data.workplace_injury_id') = 0");
            })->orWhereIn('control_room_alerts.id', $injuryIds);
        });
        $readable = $this->incidents->apply(ClientIncident::query(), $viewer)->select('client_incidents.id')
            ->where(function (Builder $source): void {
                $source->whereColumn('client_incidents.control_room_alert_id', 'control_room_alerts.id')
                    ->orWhere(function (Builder $legacy): void {
                        $legacy->whereNull('client_incidents.control_room_alert_id')
                            ->whereRaw("client_incidents.id = CAST(JSON_UNQUOTE(JSON_EXTRACT(control_room_alerts.context, '$.incident_id')) AS UNSIGNED)")
                            ->whereNotExists(fn (QueryBuilder $direct) => $direct->selectRaw('1')
                                ->from('client_incidents as direct_incident')
                                ->whereColumn('direct_incident.control_room_alert_id', 'control_room_alerts.id'));
                    });
            });
        $copies = <<<'SQL'
JSON_TABLE(
    JSON_MERGE_PRESERVE(
        CASE WHEN JSON_TYPE(JSON_EXTRACT(control_room_alerts.context, '$.resolution_history')) = 'ARRAY'
            THEN JSON_EXTRACT(control_room_alerts.context, '$.resolution_history') ELSE JSON_ARRAY() END,
        JSON_ARRAY(JSON_EXTRACT(control_room_alerts.context, '$.resolution'), JSON_EXTRACT(control_room_alerts.context, '$.notes_provenance'))
    ), '$[*]' COLUMNS (
        source VARCHAR(80) PATH '$.source' NULL ON EMPTY NULL ON ERROR,
        incident_id BIGINT PATH '$.incident_id' NULL ON EMPTY NULL ON ERROR,
        reason LONGTEXT PATH '$.reason' NULL ON EMPTY NULL ON ERROR,
        text_sha256 VARCHAR(64) PATH '$.text_sha256' NULL ON EMPTY NULL ON ERROR
    )
) AS copied_note
SQL;

        return $query->whereNotExists(function (QueryBuilder $hidden) use ($copies, $readable): void {
            $hidden->selectRaw('1')->fromRaw($copies)
                ->where('copied_note.source', 'incident_lifecycle_signal')
                ->where(function (QueryBuilder $matches): void {
                    $matches->where(function (QueryBuilder $reason): void {
                        $reason->whereNotNull('copied_note.reason')->where('copied_note.reason', '!=', '')
                            ->whereRaw('LOCATE(CAST(copied_note.reason AS BINARY), CAST(control_room_alerts.notes AS BINARY)) > 0');
                    })->orWhereRaw('copied_note.text_sha256 = SHA2(control_room_alerts.notes, 256)');
                })->where(fn (QueryBuilder $denied) => $denied->whereNull('copied_note.incident_id')
                ->orWhereNotIn('copied_note.incident_id', $readable->toBase()));
        })->whereNot(function (Builder $unknown): void {
            $unknown->where('control_room_alerts.source', 'compliance')
                ->where('control_room_alerts.alert_type', 'Incident Reported')
                ->where('control_room_alerts.notes', 'like', 'New incident reported - %');
        });
    }

    private function applyReadableRestraintNotes(Builder $query, User $viewer, HealthSafetyReadContext $context, Builder $sourceCandidates): void
    {
        $ids = [];
        $context->query(clone $sourceCandidates)->setEagerLoads([])->reorder()
            ->where(fn (Builder $source) => $source->where('control_room_alerts.alert_type', 'operations.restraint_event')
                ->orWhereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.restraint_event_id', '$.normalized_data.restraint_event_id') = 1"))
            ->chunkById(500, function ($alerts) use ($viewer, $context, &$ids): void {
                foreach ($alerts as $alert) {
                    if ($this->restraintForAlert($alert, $viewer, $context)['restraint_access'] === 'readable') {
                        $ids[] = (int) $alert->id;
                    }
                }
            }, 'control_room_alerts.id', 'id');
        $query->where(fn (Builder $notes) => $notes
            ->where(fn (Builder $ordinary) => $ordinary->where('control_room_alerts.alert_type', '!=', 'operations.restraint_event')
                ->whereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.restraint_event_id', '$.normalized_data.restraint_event_id') = 0"))
            // Canonical source command deliveries never populate the root operational note.
            ->orWhereRaw("JSON_TYPE(JSON_EXTRACT(control_room_alerts.context, '$.source_deliveries')) = 'ARRAY'")
            ->orWhereIn('control_room_alerts.id', $ids));
    }

    /** @return list<int|null> Empty means independently authored operational notes. */
    public function noteSourceIds(ControlRoomAlert $alert): array
    {
        if (! is_string($alert->notes) || $alert->notes === '') {
            return [];
        }
        $context = is_array($alert->context) ? $alert->context : [];
        $copies = [($context['resolution'] ?? null), ...array_values(is_array($context['resolution_history'] ?? null) ? $context['resolution_history'] : [])];
        $ids = [];
        foreach ($copies as $copy) {
            if (is_array($copy) && ($copy['source'] ?? null) === 'incident_lifecycle_signal'
                && is_string($copy['reason'] ?? null) && $copy['reason'] !== ''
                && str_contains($alert->notes, $copy['reason'])) {
                $ids[] = $this->positiveId($copy['incident_id'] ?? null);
            }
        }
        $provenance = $context['notes_provenance'] ?? null;
        if (is_array($provenance) && ($provenance['source'] ?? null) === 'incident_lifecycle_signal'
            && hash_equals((string) ($provenance['text_sha256'] ?? ''), hash('sha256', $alert->notes))) {
            $ids[] = $this->positiveId($provenance['incident_id'] ?? null);
        }
        if ($alert->source === 'compliance' && $alert->alert_type === 'Incident Reported'
            && str_starts_with($alert->notes, 'New incident reported - ')) {
            // This legacy writer accepted any Model, so a numeric ID alone
            // cannot prove that it was a ClientIncident rather than another source.
            $ids[] = null;
        }

        return array_values(array_unique($ids, SORT_REGULAR));
    }

    /** Source-owned notification logs are re-projected; independent conversations retain their content. */
    public function communication(array $row, array $governance): array
    {
        if (($governance['injury_access'] ?? 'absent') !== 'absent'
            && in_array($row['purpose'] ?? null, ['notification', 'escalation'], true)) {
            $row['content'] = 'Workplace injury response — open the alert for current response work.';
        }
        if (($governance['restraint_access'] ?? 'absent') !== 'absent'
            && ($governance['restraint_access'] ?? null) !== 'readable'
            && in_array($row['purpose'] ?? null, ['notification', 'escalation'], true)) {
            $row['content'] = 'Restraint response — open the alert for current response work.';
        }

        return $row;
    }

    public function audit(array $row, array $governance, array $context = []): array
    {
        if (($governance['injury_access'] ?? 'absent') !== 'absent') {
            $row['meta'] = $this->injuryCopies(is_array($row['meta'] ?? null) ? $row['meta'] : []);
        }
        $meta = is_array($row['meta'] ?? null) ? $row['meta'] : [];
        if (array_key_exists('restraint_event_id', $meta) || ($row['action'] ?? null) === 'control_room.restraint_source_accepted') {
            $row['meta'] = Arr::only($meta, ['from', 'to', 'status', 'previous_status', 'new_status']);
            $row['meta']['restraint_content_access'] = $governance['restraint_access'] ?? 'unavailable';
            if (($governance['restraint_access'] ?? null) !== 'readable') {
                $row['user'] = null;
            }

            return $row;
        }
        if (! isset($meta['incident_id']) && ($meta['resolution_source'] ?? null) === 'incident_lifecycle_signal') {
            $matches = collect($context['resolution_history'] ?? [])->filter(fn ($entry) => is_array($entry)
                && ($entry['source'] ?? null) === 'incident_lifecycle_signal'
                && isset($meta['transitioned_at'])
                && $this->sameInstant($entry['resolved_at'] ?? null, $meta['transitioned_at']));
            $ids = $matches->pluck('incident_id')->map(fn ($id) => $this->positiveId($id))->unique();
            $meta['incident_id'] = $ids->count() === 1 ? $ids->first() : null;
        }
        if ($this->isIncidentEntry($meta)
            || ($meta['resolution_source'] ?? null) === 'incident_lifecycle_signal'
            || in_array($row['action'] ?? null, ['controlRoom.alert.reopenForIncident', 'controlRoom.alert.reopenFromIncidentSignal'], true)) {
            $access = $this->incidentAccess($this->entryIncidentId($meta), $governance);
            $row['meta'] = $this->entry($meta, $governance);
            if ($access !== 'readable') {
                $row['user'] = null;
            }
        } else {
            $row['meta'] = $this->references($meta, $governance);
        }

        return $row;
    }

    public function snapshotSummary(array $row, ?ControlRoomAlert $alert, array $governance): array
    {
        $injuryCopy = ($row['summary_origin']['type'] ?? null) === 'injury'
            || ($alert !== null && ($alert->alert_type === 'operations.workplace_injury'
                || array_key_exists('workplace_injury_id', is_array($alert->context) ? $alert->context : [])
                || array_key_exists('workplace_injury_id', (array) data_get($alert->context, 'normalized_data', []))));
        if ($injuryCopy) {
            // Historic text may contain private treatment/recovery material even for a factual reader.
            $fact = ($governance['injury_access'] ?? null) === 'readable' ? ($governance['injury_source'] ?? null) : null;
            $row['summary'] = is_array($fact) ? Str::limit((string) $fact['description'], 160) : 'Workplace injury response';
            $row['summary_origin'] = ['type' => 'withheld'];
            if (array_key_exists('notes', $row)) {
                $row['notes'] = null;
            }

            return $row;
        }
        if (($row['summary_origin']['type'] ?? null) === 'restraint'
            || ($alert !== null && $this->isRestraintAlert($alert))) {
            $row['summary'] = 'Restraint response';
            $row['summary_origin'] = ['type' => 'withheld'];
            if (array_key_exists('notes', $row)) {
                $row['notes'] = null;
            }

            return $row;
        }
        if (! array_key_exists('summary', $row)) {
            return $row;
        }
        $origin = $row['summary_origin'] ?? null;
        if (($origin['type'] ?? null) === 'alert' || ($origin['type'] ?? null) === 'withheld') {
            return $row;
        }
        $access = ($origin['type'] ?? null) === 'incident'
            ? $this->incidentAccess($origin['incident_id'] ?? null, $governance)
            : 'unavailable';
        if ($access === 'readable') {
            return $row;
        }
        if ($origin === null && $alert !== null
            && ($governance['incident_access'] ?? 'unavailable') === 'absent'
            && ($governance['health_safety_access'] ?? 'unavailable') === 'absent'
            && $this->noteSourceIds($alert) === [] && $alert->source !== 'incident') {
            return $row;
        }
        $row['summary'] = $access === 'restricted' ? self::RESTRICTED : 'Saved summary details unavailable';
        $row['summary_origin'] = ['type' => 'withheld'];

        return $row;
    }

    private function entry(array $entry, array $governance): array
    {
        $access = $this->incidentAccess($this->entryIncidentId($entry), $governance);
        if ($access === 'readable') {
            return $this->references($entry, $governance);
        }
        $minimal = Arr::only($entry, ['type', 'transition', 'resolved_at', 'reopened_at', 'created_at',
            'from_status', 'to_status', 'requires_operational_reopen']);
        $minimal['access'] = $access;
        foreach (['reason', 'content'] as $key) {
            if (array_key_exists($key, $entry)) {
                $minimal[$key] = $access === 'restricted' ? self::RESTRICTED : self::UNAVAILABLE;
            }
        }

        return $minimal;
    }

    private function references(array $data, array $governance): array
    {
        if ((array_key_exists('incident_id', $data) || ($data['incident_source_type'] ?? null) === 'client_incident')
            && $this->incidentAccess($this->entryIncidentId($data), $governance) !== 'readable') {
            $data = Arr::except($data, ['incident_id', 'incident_reference', 'incident_reference_number', 'incident_source_type', 'incident_source_id']);
        }
        if (array_key_exists('hs_event_id', $data)
            && (($governance['health_safety_access'] ?? null) !== 'readable'
                || $this->positiveId($data['hs_event_id']) !== data_get($governance, 'hs_event.id'))) {
            $data = Arr::except($data, ['hs_event_id', 'hs_event_reference', 'health_safety_reference']);
        }

        return $data;
    }

    private function isIncidentEntry(array $entry): bool
    {
        return array_key_exists('incident_id', $entry)
            || ($entry['incident_source_type'] ?? null) === 'client_incident'
            || ($entry['source'] ?? null) === 'incident_lifecycle_signal'
            || ($entry['type'] ?? null) === 'incident_reopened';
    }

    private function combinedAccess(array $ids, array $governance): string
    {
        $access = array_map(fn ($id) => $this->incidentAccess($id, $governance), $ids);

        return in_array('unavailable', $access, true) ? 'unavailable'
            : (in_array('restricted', $access, true) ? 'restricted' : 'readable');
    }

    private function entryIncidentId(array $entry): ?int
    {
        if (($entry['incident_source_type'] ?? null) === 'client_incident') {
            $id = $this->positiveId($entry['incident_source_id'] ?? null);
            if (array_key_exists('incident_id', $entry) && $this->positiveId($entry['incident_id']) !== $id) {
                return null;
            }

            return $id;
        }

        return $this->positiveId($entry['incident_id'] ?? null);
    }

    private function incidentAccess(mixed $id, array $governance): string
    {
        $id = $this->positiveId($id);
        if ($id === null || $id !== data_get($governance, 'incident.id')) {
            return 'unavailable';
        }

        return ($governance['incident_access'] ?? null) === 'readable' ? 'readable' : 'restricted';
    }

    private function injuryCopies(array $value): array
    {
        $copiedText = isset($value['workplace_injury_id']) || ($value['alert_type'] ?? null) === 'operations.workplace_injury'
            || in_array($value['source'] ?? null, ['workplace_injury', 'injury_source', 'workplace_injury_source'], true)
            || in_array($value['source_type'] ?? null, ['App\\Models\\WorkplaceInjury', 'workplace_injury'], true);
        $value = Arr::except($value, $copiedText ? self::INJURY_COPY_KEYS : [
            'workplace_injury_id', 'injury_id', 'injury_type', 'injury_severity', 'body_part_affected', 'injury_date',
            'immediate_treatment', 'medical_treatment_type', 'acc_claim_number', 'source_version_id', 'source_revision',
            'source_schema_version', 'recovery', 'medical', 'assessment', 'capacity_assessments', 'return_to_work_plans',
            'modified_duties', 'restrictions', 'coordinator_snapshot']);
        if ($copiedText) {
            $value = Arr::except($value, ['content', 'reason', 'user_name', 'worker', 'person', 'subject']);
        }
        foreach ($value as $key => $nested) {
            if (is_array($nested)) {
                $value[$key] = $this->injuryCopies($nested);
            }
        }

        return $value;
    }

    private function positiveId(mixed $id): ?int
    {
        return filter_var($id, FILTER_VALIDATE_INT) !== false && (int) $id > 0 ? (int) $id : null;
    }

    private function sameInstant(mixed $left, mixed $right): bool
    {
        if (! is_string($left) || trim($left) === '' || ! is_string($right) || trim($right) === '') {
            return false;
        }
        try {
            return Carbon::parse($left)->equalTo(Carbon::parse($right));
        } catch (\Throwable) {
            return false;
        }
    }
}
