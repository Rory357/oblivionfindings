<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\Shift;
use App\Services\HealthSafety\HealthSafetyReadContext;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

/** Read-only integrity proof for an already accepted transfer; never rebuilds or repairs it. */
final class ControlRoomAcceptedHandoverHistoryService
{
    public const UNAVAILABLE_MESSAGE = 'The saved handover or acceptance details are incomplete or inconsistent. Ask a Control Room administrator to review this record.';

    public function __construct(private readonly ControlRoomPreparedHandoverSnapshotService $preparedSnapshots) {}

    /** @return array{snapshot: array<string, mixed>, acceptance: array<string, mixed>} */
    public function validated(Shift $outgoing, HealthSafetyReadContext $context): array
    {
        if ($outgoing->status !== 'completed' || $outgoing->handover_status !== Shift::HANDOVER_ACCEPTED) {
            $this->unavailable();
        }
        // This is the same canonical prepared payload accepted by the command,
        // not a newly calculated live workload or a replacement historical snapshot.
        $snapshot = $this->preparedSnapshots->validated($outgoing);
        $raw = $outgoing->handover_snapshot;
        $actor = $raw['accepted_by'] ?? null;
        if (! is_array($actor) || ! is_string($actor['name'] ?? null) || trim($actor['name']) === '') {
            $this->unavailable();
        }
        $actorId = $this->id($actor['id'] ?? null);
        $incomingId = $this->id(data_get($raw, 'incoming_shift.id'));
        $acceptedAt = $this->timestamp($raw['accepted_at'] ?? null);
        $preparedAt = $this->timestamp($snapshot['prepared_at']);
        $this->timestamp($snapshot['criteria_at']);
        $this->timestamp($snapshot['next_expected_shift_at']);
        $this->timestamp($snapshot['carry_forward_acknowledged_at']);
        if ($actorId !== (int) $outgoing->handed_over_to_user_id
            || $actorId !== $snapshot['incoming_shift']['lead']['id'] || $incomingId === (int) $outgoing->id
            || $outgoing->handover_version < 1
            || $outgoing->starts_at === null
            || ! $outgoing->ends_at?->equalTo($acceptedAt)
            || ! $outgoing->handed_over_at?->equalTo($acceptedAt)
            || ! $outgoing->handover_accepted_at?->equalTo($acceptedAt)
            || $acceptedAt->lessThan($preparedAt)
            || $acceptedAt->lessThan($outgoing->starts_at)) {
            $this->unavailable();
        }
        $incoming = $context->query(Shift::query()->whereKey($incomingId))->first();
        if ($incoming === null || ! $incoming->starts_at?->equalTo($acceptedAt)
            || (int) $incoming->shift_lead_user_id !== $actorId) {
            $this->unavailable();
        }
        $audits = DB::table('audit_logs')->where('action', 'controlRoom.shift.handoverAccepted')
            ->where('auditable_type', $outgoing->getMorphClass())->where('auditable_id', $outgoing->id)
            ->get(['user_id', 'meta']);
        $matching = $audits->filter(function ($audit) use ($outgoing, $incomingId, $actorId): bool {
            $meta = json_decode($audit->meta ?? 'null', true);

            return is_array($meta) && (int) $audit->user_id === $actorId
                && ($meta['actor_id'] ?? null) === $actorId
                && ($meta['outgoing_shift_id'] ?? null) === (int) $outgoing->id
                && ($meta['incoming_shift_id'] ?? null) === $incomingId
                && ($meta['incoming_lead_user_id'] ?? null) === $actorId
                && ($meta['handover_version'] ?? null) === $outgoing->handover_version;
        });
        if ($matching->count() !== 1) {
            $this->unavailable();
        }

        return ['snapshot' => $snapshot, 'acceptance' => [
            'accepted_by' => ['id' => $actorId, 'name' => $actor['name']],
            'accepted_at' => $raw['accepted_at'],
            'handover_version' => $outgoing->handover_version,
            'outgoing_duty' => ['id' => (int) $outgoing->id, 'name' => $outgoing->name,
                'href' => "/control-room/shifts/{$outgoing->id}/handover"],
            'incoming_duty' => ['id' => $incomingId, 'name' => $snapshot['incoming_shift']['name'],
                'href' => "/control-room/shifts/{$incomingId}/handover"],
        ]];
    }

    private function id(mixed $value): int
    {
        if ((is_int($value) && $value > 0) || (is_string($value) && preg_match('/\A[1-9][0-9]{0,17}\z/D', $value))) {
            return (int) $value;
        }
        $this->unavailable();
    }

    private function timestamp(mixed $value): Carbon
    {
        if (! is_string($value) || ! preg_match('/\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})\z/D', $value)) {
            $this->unavailable();
        }
        try {
            $parsed = Carbon::parse($value);
            if ($parsed->format('Y-m-d\TH:i:s') !== substr($value, 0, 19)) {
                $this->unavailable();
            }

            return $parsed;
        } catch (\Throwable) {
            $this->unavailable();
        }
    }

    private function unavailable(): never
    {
        throw ValidationException::withMessages(['handover' => self::UNAVAILABLE_MESSAGE]);
    }
}
