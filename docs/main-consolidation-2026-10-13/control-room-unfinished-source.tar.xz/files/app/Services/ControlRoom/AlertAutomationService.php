<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\PlaybookRun;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoom\TriageQueue;
use App\Models\ControlRoomAlert;
use App\Models\Site;
use App\Models\User;
use App\Services\AuditLogger;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * Safe automation for Control Room alerts.
 *
 * Handles automatic actions that ASSIST operators without replacing them:
 * - Auto-assignment based on queue roles or site primary contact
 * - Auto-starting playbook runs so operators see actionable steps immediately
 * - Escalation-driven watcher addition for management visibility
 *
 * SAFETY RULES:
 * - NEVER auto-resolves or auto-closes alerts
 * - NEVER hides problems
 * - Every automated action is logged to audit trail
 * - Operators can always override automated decisions
 */
class AlertAutomationService
{
    public function __construct(private readonly ControlRoomRecipientEligibilityService $eligibility) {}

    /**
     * Run post-creation automation on a new alert.
     *
     * Called after alert creation + queue + SLA + playbook attachment.
     * Order: auto-assign → auto-start playbook.
     */
    public function onAlertCreated(ControlRoomAlert $alert): void
    {
        $this->autoAssign($alert);
        $this->autoStartPlaybook($alert);
    }

    /**
     * Run post-escalation automation.
     *
     * Called after escalation level is incremented.
     */
    public function onAlertEscalated(ControlRoomAlert $alert, int $previousLevel): void
    {
        // At escalation level 2+, add relevant managers as watchers for visibility
        if ($alert->escalation_level >= 2) {
            $this->addEscalationWatchers($alert);
        }
    }

    /**
     * Auto-assign an alert to the most appropriate available user.
     *
     * Assignment priority (first match wins):
     * 1. Queue has assigned_users → pick by explicit list order (queue config order)
     * 2. Queue has assigned_roles → pick user with matching role, prefer same site
     * 3. Alert has site_id → pick site's primary contact
     * 4. Leave unassigned (operator will manually assign)
     *
     * Does NOT reassign if already assigned.
     */
    public function autoAssign(ControlRoomAlert $alert): void
    {
        DB::transaction(function () use ($alert): void {
            $locked = ControlRoomAlert::query()->whereKey($alert->id)->lockForUpdate()->firstOrFail();
            if ($locked->assigned_to_user_id !== null || ! $locked->isActionable()) {
                return;
            }
            $queue = $locked->queue_id === null ? null : TriageQueue::query()->whereKey($locked->queue_id)->lock('for share nowait')->first();
            $duty = Shift::query()->current()->orderBy('id')->lock('for share nowait')->first();
            $dutyIds = $duty?->memberUserIds() ?? [];
            $contactId = $locked->site_id === null ? null : Site::query()->whereKey($locked->site_id)->value('primary_contact_user_id');
            $candidates = collect();
            foreach ($queue?->assigned_users ?? [] as $id) {
                if (is_numeric($id)) {
                    $candidates->push(['id' => (int) $id, 'reason' => 'queue_user']);
                }
            }
            $roleIds = empty($queue?->assigned_roles) ? collect() : User::query()->whereIn('id', $dutyIds)
                ->whereHas('roles', fn ($roles) => $roles->whereIn('name', $queue->assigned_roles))->orderBy('id')->pluck('id');
            foreach ($roleIds->sortBy(fn ($id): int => (int) $id === (int) $contactId ? 0 : 1) as $id) {
                $candidates->push(['id' => (int) $id, 'reason' => 'queue_role']);
            }
            if ($contactId !== null) {
                $candidates->push(['id' => (int) $contactId, 'reason' => 'site_primary_contact']);
            }
            foreach ($dutyIds as $id) {
                $candidates->push(['id' => $id, 'reason' => 'current_duty_fallback']);
            }
            foreach ($candidates->unique(fn (array $candidate): string => $candidate['id'].':'.$candidate['reason']) as $candidate) {
                $assigned = $this->eligibility->withCurrentEligible($locked, $candidate['id'], function (User $current) use ($locked, $candidate, $queue): bool {
                    if ($candidate['reason'] === 'queue_role' && ! $current->roles->pluck('name')->intersect($queue->assigned_roles)->isNotEmpty()) {
                        return false;
                    }
                    $at = now();
                    $locked->forceFill([
                        'assigned_to_user_id' => $current->id, 'assigned_at' => $at,
                        'context' => [...($locked->context ?? []), 'auto_assigned' => true,
                            'auto_assign_reason' => $candidate['reason'], 'auto_assign_at' => $at->toIso8601String(),
                            'assignment_routing' => ['state' => 'assigned', 'checked_at' => $at->toIso8601String()]],
                    ]);
                    if (! $locked->save()) {
                        throw new \RuntimeException('Automatic ownership was not persisted.');
                    }
                    AuditLogger::logOrFail('controlRoom.alert.autoAssigned', $locked, [
                        'alert_id' => $locked->id, 'assigned_to' => $current->id, 'reason' => $candidate['reason'],
                    ]);

                    return true;
                }, owner: true);
                if ($assigned === true) {
                    return;
                }
            }
            $locked->forceFill(['context' => [...($locked->context ?? []), 'assignment_routing' => [
                'state' => 'no_eligible_on_duty_owner', 'checked_at' => now()->toIso8601String(), 'fallback' => 'manual_triage',
            ]]]);
            if (! $locked->save()) {
                throw new \RuntimeException('Unassigned response routing was not persisted.');
            }
        }, 3);
        $alert->refresh();
    }

    /**
     * Auto-start a playbook run if one is attached and pending.
     *
     * Initialises run steps and sets the first step to in_progress.
     * This saves operators from having to manually click "Start Playbook"
     * before they can begin following the SOP steps.
     *
     * Uses PlaybookRun::initialiseSteps() to avoid duplicating step creation
     * logic between here and the manual start path.
     */
    public function autoStartPlaybook(ControlRoomAlert $alert): void
    {
        if (! $alert->playbook_run_id) {
            return;
        }

        $run = PlaybookRun::with('playbook.steps')->find($alert->playbook_run_id);

        if (! $run || $run->status !== 'pending') {
            return; // Already started, completed, or cancelled
        }

        // Auto-start without a user (system-initiated)
        $run->update([
            'status' => 'in_progress',
            'started_at' => now(),
            // started_by_user_id intentionally null — system-initiated
        ]);

        $run->initialiseSteps();

        AuditLogger::log('controlRoom.playbook.autoStarted', $alert, [
            'alert_id' => $alert->id,
            'playbook_run_id' => $run->id,
            'playbook_name' => $run->playbook->name,
            'total_steps' => $run->total_steps,
        ]);

        Log::info('AlertAutomation: playbook auto-started', [
            'alert_id' => $alert->id,
            'playbook_run_id' => $run->id,
            'playbook' => $run->playbook->name,
        ]);
    }

    /**
     * Add escalation watchers to increase visibility at higher escalation levels.
     *
     * At level 2+, adds managers as watchers. If the alert has a site_id,
     * prefers the site's primary contact. Always includes admin/provider_manager
     * roles as a baseline.
     */
    protected function addEscalationWatchers(ControlRoomAlert $alert): void
    {
        DB::transaction(function () use ($alert): void {
            $locked = ControlRoomAlert::query()->whereKey($alert->id)->lockForUpdate()->firstOrFail();
            $this->addEligibleWatchers($locked);
        }, 3);
    }

    private function addEligibleWatchers(ControlRoomAlert $alert): void
    {
        $watcherUserIds = collect();

        // Site primary contact gets visibility on their site's escalated alerts
        if ($alert->site_id) {
            $site = Site::find($alert->site_id);
            if ($site?->primary_contact_user_id) {
                $watcherUserIds->push($site->primary_contact_user_id);
            }
        }

        // Admin/provider_manager always get visibility on escalated alerts
        $managerIds = User::whereHas('roles', fn ($q) => $q->whereIn('name', ['admin', 'provider_manager'])
        )
            ->pluck('id');

        $watcherUserIds = $watcherUserIds->merge($managerIds)->unique();

        if ($watcherUserIds->isEmpty()) {
            return;
        }

        $existingWatcherIds = $alert->watchers()->pluck('user_id');
        $newWatcherIds = $watcherUserIds->diff($existingWatcherIds);

        $addedIds = collect();
        foreach ($newWatcherIds as $userId) {
            $added = $this->eligibility->withCurrentEligible($alert, (int) $userId, function (User $current, ControlRoomAlert $fresh): bool {
                $fresh->watchers()->firstOrCreate(['user_id' => $current->id], ['added_by_user_id' => null]);

                return true;
            });
            if ($added === true) {
                $addedIds->push((int) $userId);
            }
        }

        if ($addedIds->isNotEmpty()) {
            AuditLogger::logOrFail('controlRoom.alert.autoWatchers', $alert, [
                'alert_id' => $alert->id,
                'escalation_level' => $alert->escalation_level,
                'watchers_added' => $addedIds->count(),
                'includes_site_contact' => $alert->site_id && $addedIds->contains(
                    Site::find($alert->site_id)?->primary_contact_user_id
                ),
            ]);
        }
    }
}
