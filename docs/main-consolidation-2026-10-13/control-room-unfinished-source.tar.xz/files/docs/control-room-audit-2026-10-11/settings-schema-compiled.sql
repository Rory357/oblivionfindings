alter table `control_room_signal_rules` add `settings_revision` bigint unsigned not null default '1';
alter table `control_room_triage_queues` add `settings_revision` bigint unsigned not null default '1';
alter table `control_room_maintenance_windows` add `settings_revision` bigint unsigned not null default '1';
alter table `control_room_signal_rules` drop `settings_revision`;
alter table `control_room_triage_queues` drop `settings_revision`;
alter table `control_room_maintenance_windows` drop `settings_revision`;
