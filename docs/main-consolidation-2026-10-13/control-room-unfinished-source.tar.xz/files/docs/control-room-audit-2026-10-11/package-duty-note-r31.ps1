$ErrorActionPreference = 'Stop'
$crRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$crDocs = Join-Path $crRoot 'docs/control-room-audit-2026-10-11'
$crBefore = Join-Path $crDocs 'duty-note-before-r31'
$crOutput = Join-Path $crDocs 'duty-note-source-increment-r31.json'
$crUtf8 = [Text.UTF8Encoding]::new($false)
if (Test-Path -LiteralPath $crOutput) { throw 'Preserve earlier source receipt.' }
function Get-CrHash([string] $Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Get-CrTextHash([string] $Value) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($crUtf8.GetBytes($Value))) }
function Get-CrMethod([string] $Text, [string] $Name) {
    $matches = [regex]::Matches($Text, '(?ms)^    (?:public|private|protected) function ' + [regex]::Escape($Name) + '\(.*?(?=^    (?:public|private|protected) function |\z)')
    if ($matches.Count -ne 1) { throw "Ambiguous method $Name" }
    $matches[0].Value
}
$crR29 = Get-Content -LiteralPath (Join-Path $crDocs 'accepted-note-source-increment-r29.json') -Raw | ConvertFrom-Json
$crOriginalPins = Get-Content -LiteralPath (Join-Path $crDocs 'duty-note-before-r31.json') -Raw | ConvertFrom-Json
foreach ($pin in $crOriginalPins) { if ((Get-CrHash (Join-Path $crBefore $pin.path)) -ne $pin.sha256) { throw 'Predecessor changed.' } }
$crPaths = @($crR29.productPins.path) + @('app/Services/ControlRoom/ControlRoomOperatorNoteReadService.php', 'resources/js/pages/control-room/shifts.tsx', 'resources/js/pages/control-room/shifts.test.tsx')
$crProductPins = @($crPaths | Sort-Object -Unique | ForEach-Object {
    $oldPath = Join-Path $crBefore $_
    @{ path = $_; sha256 = Get-CrHash (Join-Path $crRoot $_); r31BeforeSha256 = $(if (Test-Path -LiteralPath $oldPath) { Get-CrHash $oldPath } else { $null }) }
})
$crStable = @($crR29.productPins | Where-Object { (Get-CrHash (Join-Path $crRoot $_.path)) -eq $_.sha256 } | ForEach-Object { @{ path = $_.path; sha256 = $_.sha256 } })
if ($crProductPins.Count -ne 17 -or $crStable.Count -ne 7) { throw 'Unexpected source scope drift.' }
$crOldRead = [IO.File]::ReadAllText((Join-Path $crBefore 'app/Services/ControlRoom/ControlRoomAcceptedHandoverNoteService.php'))
$crNewRead = [IO.File]::ReadAllText((Join-Path $crRoot 'app/Services/ControlRoom/ControlRoomOperatorNoteReadService.php'))
$crVerifiedBefore = Get-CrMethod $crOldRead 'verified'
$crVerifiedCurrent = Get-CrMethod $crNewRead 'verified'
$crOldCommand = [IO.File]::ReadAllText((Join-Path $crBefore 'app/Services/ControlRoom/ControlRoomShiftHandoverService.php'))
$crNewCommand = [IO.File]::ReadAllText((Join-Path $crRoot 'app/Services/ControlRoom/ControlRoomShiftHandoverService.php'))
$crAcceptBefore = Get-CrMethod $crOldCommand 'accept'
$crAcceptCurrent = Get-CrMethod $crNewCommand 'accept'
$crEol = $(if ($crAcceptCurrent.Contains("`r`n")) { "`r`n" } else { "`n" })
$crAcceptRestored = $crAcceptCurrent.Replace('            $this->assertNotesReadable($locked, $snapshot, $actor);' + $crEol + $crEol, '')
$crAcceptRestored = $crAcceptRestored.Replace('            $result = $this->assertPersistedNotesReadable($locked, $snapshot, $actor);' + $crEol + $crEol, '')
$crAcceptRestored = $crAcceptRestored.Replace('            return $result;', '            return $locked->fresh();')
$crProof = [ordered]@{
    sharedVerifiedMethodByteExactFromReviewedR29 = $crVerifiedBefore -ceq $crVerifiedCurrent
    sharedVerifiedMethodSha256 = Get-CrTextHash $crVerifiedCurrent
    acceptanceOutsideTwoNewNoteChecksAndVerifiedReturnByteExact = $crAcceptRestored -ceq $crAcceptBefore
    acceptanceBeforeSpanSha256 = Get-CrTextHash $crAcceptBefore
    acceptanceCurrentSpanSha256 = Get-CrTextHash $crAcceptCurrent
    stableR29ProductPins = $crStable
    predecessorPinsMatched = $crOriginalPins.Count
    finalCommandCheck = 'After normal save/audit/model/read callbacks: validate persisted selected IDs/copies, shared current admission, final raw locked snapshot unchanged check; return already read model, no following model retrieval or normal write.'
    trackedWhitespaceExit = 0
}
if (!$crProof.sharedVerifiedMethodByteExactFromReviewedR29 -or !$crProof.acceptanceOutsideTwoNewNoteChecksAndVerifiedReturnByteExact) { throw 'Unexpected predicate/acceptance delta.' }
$crHistory = [IO.File]::ReadAllText((Join-Path $crRoot 'tests/Feature/ControlRoom/ControlRoomAcceptedHandoverHistoryTest.php'))
if ([regex]::Matches($crHistory, '(?m)^    public function test_').Count -ne 24) { throw 'Native declaration inventory changed.' }
$crFrontImagePath = Join-Path $crDocs 'owned-frontend-inputs-r32.json'
$crFrontImage = Get-Content -LiteralPath $crFrontImagePath -Raw | ConvertFrom-Json
foreach ($pin in $crFrontImage.sourcePins) { if ((Get-CrHash $pin.path) -ne $pin.sha256) { throw 'Final frontend image drift.' } }
$crSyntaxImagePath = Join-Path $crDocs 'accepted-note-syntax-r33-inputs.json'
$crSyntaxImage = Get-Content -LiteralPath $crSyntaxImagePath -Raw | ConvertFrom-Json
foreach ($pin in $crSyntaxImage.pins) { if ((Get-CrHash $pin.path) -ne $pin.sha256) { throw 'Final syntax image drift.' } }
$crComponentPath = 'test-results/control-room-owned-component-a-r32-20261012/result.json'
$crComponent = Get-Content -LiteralPath (Join-Path $crRoot $crComponentPath) -Raw | ConvertFrom-Json
$crSyntax = Get-Content -LiteralPath (Join-Path $crDocs 'accepted-note-syntax-r33-result.json') -Raw | ConvertFrom-Json
$crEvidence = @(
    'docs/control-room-audit-2026-10-11/duty-note-before-r31.json',
    'docs/control-room-audit-2026-10-11/owned-frontend-inputs-r32.json',
    'docs/control-room-audit-2026-10-11/run-owned-frontend-r32.ps1',
    'docs/control-room-audit-2026-10-11/owned-frontend-r32.vitest.config.ts',
    'docs/control-room-audit-2026-10-11/accepted-note-syntax-r33-inputs.json',
    'docs/control-room-audit-2026-10-11/run-note-syntax-r33.ps1',
    'docs/control-room-audit-2026-10-11/accepted-note-syntax-r33-result.json',
    $crComponentPath,
    'vendor/inertiajs/inertia-laravel/src/ResponseFactory.php',
    'vendor/inertiajs/inertia-laravel/src/Response.php',
    'docs/control-room-audit-2026-10-11/package-duty-note-r31.ps1'
)
$crPayload = [ordered]@{
    recordedAtUtc = [DateTime]::UtcNow.ToString('o'); candidate = $crRoot; revision = 'R31 adjacent prepared/live note correction; final R32 frontend/R33 syntax inputs'
    branch = 'codex/control-room-delivery'; base = 'ce50e22f5b5b85fdd1bf42a8401ec31015deae80'
    status = 'CANDIDATE_SOURCE_ONLY; parent independent review/runtime/privacy acceptance pending'
    parentFinding = 'Prepared handover snapshot and active-duty note transports still used current alert scope alone and released unsafe copied notes despite accepted-history protection.'
    currentProductPins = $crProductPins; minimalChangedOrNewProductCount = 10; sourceProofs = $crProof
    implementation = @{
        sharedAdmission = 'One ControlRoomOperatorNoteReadService reuses the reviewed R29 original-context/actor/digest/time/audit/current-scope verifier for saved, current duty and command projections. Accepted service is a compatibility delegate. No source-policy fork.'
        readPaths = 'Prepared saved notes, active handover notes, duty dashboard and accepted history now use the shared admission. Unsafe text and IDs withheld; top-level and saved collections align. Current duty/work retained. No historical backfill or present-association inference.'
        client = 'Only noteProjection drives note bodies in active/prepared/accepted views; old raw copies have no fallback. Unavailable reason shown and prepared acceptance hold explained.'
        partialRefresh = 'Handover shift/noteProjection/pinnedNotes/followupNotes/snapshotIssue and duty notes/noteProjection are mandatory Inertia AlwaysProps. Autosave and duty refresh include the fresh projection. Installed AlwaysProp source pinned; no shared middleware edit.'
        command = 'Preparation verifies every selected note for outgoing and incoming viewers, rejection is explicit. Acceptance retains prior role/version/active/Site/snapshot guards and adds original-note admission before writes and after audit. Final persisted inventory/current context/raw snapshot checked; unsafe copies never silently pruned into a successful transition.'
        legacy = 'Existing legacy unknown copies stay unavailable. Selected unknown/unsafe notes block prepare/accept with review validation; independently permitted active urgent work remains accessible. H&S source-copy API and same-text source-writer invalidation still pending owner.'
    }
    authoredTests = @{
        nativeWholeFileDeclarations = 24; prospectiveCases = 65; nativeRun = $false
        providers = @{ invalidHistory = 13; noteReassociation = 6; noteCollections = 3; adjacentNoteChangesRows = 9; adjacentNoteChangesConsumers = 2; draftAndPreparedRows = 2; draftAndPreparedConsumers = 1; handoverLateMutationRows = 6 }
        additions = '23 prospective controls: actual persisted draft/prepare HTTP fixtures; prepared/active/draft GET reassociation and source withdrawal with pinned/follow-up/both; no GET writes; prepare/accept rejection no command writes; readable independent positives; source-audit origin/text/removal mutation transaction rollback; mandatory partial response replacement. Previous 38 controls retained. Legacy histories now explicitly simulated after actual commands rather than bypassing the new preparation guard.'
        frontendHandoverCases = 8; frontendDutyCases = 5; wholeFiniteSuites = 6; frontendQueueCases = 33; frontendNewCases = 2
        frontendControls = 'Admitted bodies once; withdrawal empties bodies while required work/current duty remains; raw remembered copies cannot restore content when projection is unavailable or absent.'
    }
    actualChecks = @{
        component = @{ started = $crComponent.started; state = $crComponent.state; issue = $crComponent.issue; actualCounts = $crComponent.actualTestTotal; afterReadComplete = $crComponent.afterReadComplete; freeMiB = $crComponent.resources[0].freeMiB; cpuPercent = $crComponent.resources[0].cpuPercent; heavyPeers = @($crComponent.resources[0].heavyPeerIds).Count; sourcePins = $crFrontImage.sourcePins.Count }
        syntax = @{ childrenStarted = $crSyntax.compilerChildrenStarted; state = $crSyntax.state; issue = $crSyntax.issue; grammarFilesChecked = @($crSyntax.syntax).Count; afterReadComplete = $crSyntax.afterReadComplete; freeMiB = $crSyntax.resources[0].freeMiB; cpuPercent = $crSyntax.resources[0].cpuPercent; heavyPeers = @($crSyntax.resources[0].heavyPeerIds).Count; finalPhpInputs = $crSyntaxImage.files.Count }
        runtimePassClaim = $false; formattingLintTypeNativeDatabaseBuildBrowser = 'UNRUN'; applicationMigrationExecuted = $false
    }
    automaticApproval = @{ broadStringRewriteRejected = $true; reason = 'Truncating from snapshotNotes to file end could delete unrelated methods.'; resolved = 'Explicit bounded apply_patch hunks changed only the reviewed note blocks; no truncating rewrite or bypass executed.'; unresolvedApprovalBlock = $false }
    evidencePins = @($crEvidence | ForEach-Object { @{ path = $_; sha256 = Get-CrHash (Join-Path $crRoot $_) } })
    overallAudit = 'INCOMPLETE'; mainApplicationChanges = $false; newMigrationRoleRouteGrant = $false; stagedCommittedPushed = $false; integratedDeployed = $false
}
[IO.File]::WriteAllText($crOutput, ($crPayload | ConvertTo-Json -Depth 18) + "`n", $crUtf8)
[pscustomobject]@{ receiptSha256 = Get-CrHash $crOutput; products = $crProductPins.Count; unchangedR29 = $crStable.Count; proofs = $crProof | Select-Object sharedVerifiedMethodByteExactFromReviewedR29,acceptanceOutsideTwoNewNoteChecksAndVerifiedReturnByteExact; component = $crPayload.actualChecks.component; syntax = $crPayload.actualChecks.syntax } | ConvertTo-Json -Depth 5
