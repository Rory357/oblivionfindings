<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Models\AuditLog;
use App\Models\ControlRoom\OperatorNote;
use App\Models\ControlRoomAlert;
use App\Models\Permission;
use App\Models\Site;
use App\Models\User;
use App\Services\ControlRoom\AlertWorkspaceService;
use App\Services\ControlRoom\ControlRoomAlertLifecycleService;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use App\Services\ControlRoom\ControlRoomSourceContentService;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use InvalidArgumentException;
use RuntimeException;
use Tests\TestCase;

/** Persisted operator-origin identity and checked writer regressions. Authored, runtime UNRUN. */
class ControlRoomOperatorRootNoteTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;

    private User $actor;

    private ControlRoomAlert $alert;

    protected function setUp(): void
    {
        parent::setUp();
        Queue::fake();
        $this->seed(RbacSeeder::class);
        $this->site = Site::factory()->create(['is_active' => true]);
        $this->actor = User::factory()->create(['role' => 'support_worker', 'approved_at' => now()]);
        HrEmployeeProfile::factory()->create(['user_id' => $this->actor->id, 'primary_site_id' => $this->site->id,
            'secondary_site_ids' => [], 'is_active' => true, 'start_date' => now('Pacific/Auckland')->subYear()->toDateString(), 'end_date' => null]);
        foreach (['controlRoom.alerts.view', 'controlRoom.alerts.manage'] as $key) {
            $this->actor->permissionOverrides()->attach(Permission::where('key', $key)->sole(), ['allowed' => true]);
        }
        $this->alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'source' => 'operations', 'alert_type' => 'operations.workplace_injury', 'site_id' => $this->site->id,
            'client_id' => null, 'status' => ControlRoomAlert::STATUS_TRIAGING, 'notes' => null,
            'context' => ['workplace_injury_id' => null],
        ]));
    }

    public function test_resolution_binds_actual_persisted_note_actor_alert_digest_and_activity(): void
    {
        $resolved = $this->resolve();
        $note = OperatorNote::where('alert_id', $this->alert->id)->sole();
        $this->assertSame('Independent operator response', $note->content);
        $this->assertSame($this->actor->id, $note->user_id);
        $this->assertSame(OperatorNote::TYPE_DECISION, $note->type);
        $expected = ['version' => 1, 'source' => 'operator_note', 'operator_note_id' => $note->id,
            'alert_id' => $resolved->id, 'actor_user_id' => $this->actor->id, 'text_sha256' => hash('sha256', $note->content),
        ];
        foreach ($expected as $key => $value) {
            $this->assertSame($value, $resolved->context['root_note_origin'][$key]);
        }
        $this->assertSame($note->id, collect($resolved->context['activity_log'])->last()['operator_note_id']);
        $this->assertTrue(AuditLog::where('action', 'controlRoom.alert.resolve')->where('auditable_id', $resolved->id)->exists());
    }

    public function test_proved_independent_root_is_visible_and_searchable_when_medical_source_is_unavailable(): void
    {
        $this->resolve();
        $workspace = $this->workspace();
        $this->assertSame('Independent operator response', $workspace['alert']['notes']);
        $this->assertSame('readable', $workspace['alert']['notes_access']);
        $this->assertArrayNotHasKey('root_note_origin', $workspace['alert']['context']);
        $this->assertSame([$this->alert->id], $this->search('Independent operator response'));
    }

    public function test_marker_without_persisted_note_does_not_authorize_text_or_search(): void
    {
        $this->alert->updateQuietly(['notes' => 'PRIVATE-FORGED-ORIGIN', 'context' => $this->alert->context + ['root_note_origin' => [
            'version' => 1, 'source' => 'operator_note', 'operator_note_id' => 999999, 'alert_id' => $this->alert->id,
            'actor_user_id' => $this->actor->id, 'text_sha256' => hash('sha256', 'PRIVATE-FORGED-ORIGIN'),
        ]]]);
        $this->assertWithheld('PRIVATE-FORGED-ORIGIN');
    }

    public function test_edited_or_missing_actual_note_invalidates_origin_even_if_marker_is_unchanged(): void
    {
        $this->resolve();
        $note = OperatorNote::where('alert_id', $this->alert->id)->sole();
        $note->update(['content' => 'Edited typed note']);
        $this->assertWithheld('Independent operator response');
        $note->delete();
        $this->assertWithheld('Independent operator response');
    }

    public function test_wrong_alert_actor_or_note_classification_cannot_supply_origin(): void
    {
        $this->resolve();
        $note = OperatorNote::where('alert_id', $this->alert->id)->sole();
        $other = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create(['site_id' => $this->site->id]));
        $note->update(['alert_id' => $other->id]);
        $this->assertWithheld('Independent operator response');
        $note->update(['alert_id' => $this->alert->id, 'user_id' => User::factory()->create()->id]);
        $this->assertWithheld('Independent operator response');
        $note->update(['user_id' => $this->actor->id, 'type' => OperatorNote::TYPE_NOTE]);
        $this->assertWithheld('Independent operator response');
    }

    public function test_changed_text_source_overwrite_cannot_borrow_old_operator_origin(): void
    {
        $this->resolve();
        $this->alert->updateQuietly(['notes' => 'PRIVATE-SOURCE-REPLACEMENT']);
        $this->assertWithheld('PRIVATE-SOURCE-REPLACEMENT');
    }

    public function test_same_text_source_ownership_requires_atomic_operator_origin_invalidation(): void
    {
        $this->resolve();
        // Source-writer contract fixture only. Canonical H&S writer implementation is owner-owned/pending.
        DB::transaction(function (): void {
            $locked = ControlRoomAlert::whereKey($this->alert->id)->lockForUpdate()->sole();
            $context = $locked->context;
            unset($context['root_note_origin']);
            $locked->updateQuietly(['notes' => 'Independent operator response', 'context' => $context]);
        });
        $this->assertWithheld('Independent operator response');
        $this->assertSame(1, OperatorNote::where('alert_id', $this->alert->id)->count());
    }

    public function test_existing_nonnull_source_root_and_empty_string_are_never_reclassified(): void
    {
        foreach (['PRIVATE-LEGACY-SOURCE', ''] as $text) {
            $this->alert->updateQuietly(['status' => ControlRoomAlert::STATUS_TRIAGING, 'notes' => $text]);
            $resolved = $this->resolve();
            $this->assertSame($text, $resolved->notes);
            $this->assertArrayNotHasKey('root_note_origin', $resolved->context);
            $this->assertNull($this->workspace()['alert']['notes']);
        }
    }

    public function test_note_creation_event_veto_rolls_back_resolution_and_retry_has_one_note(): void
    {
        $veto = true;
        OperatorNote::creating(function () use (&$veto) {
            return ! $veto;
        });
        $this->assertRollback(fn () => $this->resolve());
        $veto = false;
        $this->resolve();
        $this->assertSame(1, OperatorNote::where('alert_id', $this->alert->id)->count());
        try {
            $this->resolve();
            $this->fail('A terminal retry must not create another operator note.');
        } catch (InvalidArgumentException) {
            $this->assertSame(1, OperatorNote::where('alert_id', $this->alert->id)->count());
        }
    }

    public function test_alert_save_event_veto_rolls_back_note_activity_reference_and_audit(): void
    {
        $veto = true;
        $id = $this->alert->id;
        ControlRoomAlert::saving(fn ($alert) => ! ($veto && $alert->id === $id && $alert->status === ControlRoomAlert::STATUS_RESOLVED));
        $this->assertRollback(fn () => $this->resolve());
    }

    public function test_mandatory_audit_save_veto_rolls_back_note_activity_reference_and_status(): void
    {
        AuditLog::creating(fn ($audit) => $audit->action !== 'controlRoom.alert.resolve');
        $this->assertRollback(fn () => $this->resolve());
    }

    public function test_typed_note_append_save_veto_leaves_no_orphan_note_or_activity(): void
    {
        $id = $this->alert->id;
        ControlRoomAlert::saving(fn ($alert) => $alert->id !== $id);
        $this->assertRollback(fn () => app(ControlRoomAlertLifecycleService::class)->appendOperatorNote(
            $this->alert, $this->actor, 'Independent typed note', 'operator_note'));
    }

    public function test_operator_origin_does_not_bypass_current_alert_site_in_search(): void
    {
        $this->resolve();
        $this->actor->hrEmployeeProfile->update(['primary_site_id' => Site::factory()->create(['is_active' => true])->id]);
        $this->assertSame([], $this->search('Independent operator response'));
    }

    private function resolve(): ControlRoomAlert
    {
        return app(ControlRoomAlertLifecycleService::class)->resolve($this->alert, $this->actor, 'Independent operator response', 'controlled');
    }

    private function workspace(): array
    {
        return app(AlertWorkspaceService::class)->build($this->actor, $this->alert->id);
    }

    private function search(string $text): array
    {
        return app(ControlRoomGovernanceReadService::class)->withCurrentViewer($this->actor,
            function ($current, $context) use ($text): array {
                $candidates = ControlRoomAlert::query()->whereKey($this->alert->id);

                return $context->query(app(ControlRoomSourceContentService::class)->applyReadableNotes(
                    clone $candidates, $current, $context, $candidates))->where('notes', 'like', '%'.$text.'%')->pluck('id')->all();
            });
    }

    private function assertWithheld(string $text): void
    {
        $this->assertNull($this->workspace()['alert']['notes']);
        $this->assertSame([], $this->search($text));
    }

    private function assertRollback(callable $write): void
    {
        $before = $this->alert->fresh()->getRawOriginal();
        try {
            $write();
            $this->fail('The vetoed command must fail visibly.');
        } catch (RuntimeException) {
            $this->assertSame($before, $this->alert->fresh()->getRawOriginal());
            $this->assertSame(0, OperatorNote::where('alert_id', $this->alert->id)->count());
            $this->assertSame(0, AuditLog::where('action', 'controlRoom.alert.resolve')->where('auditable_id', $this->alert->id)->count());
        }
    }
}
