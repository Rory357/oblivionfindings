$ErrorActionPreference = 'Stop'
$crRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$crDocs = Join-Path $crRoot 'docs/control-room-audit-2026-10-11'
$crBefore = Join-Path $crDocs 'note-baseline-before-r34'
$crOutput = Join-Path $crDocs 'note-baseline-source-increment-r34.json'
$crUtf8 = [Text.UTF8Encoding]::new($false)
if (Test-Path -LiteralPath $crOutput) { throw 'Preserve earlier source receipt.' }
function Get-CrHash([string] $Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Get-CrTextHash([string] $Value) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($crUtf8.GetBytes($Value))) }
function Get-CrMethod([string] $Text, [string] $Name) {
    $matches = [regex]::Matches($Text, '(?ms)^    (?:public|private|protected) function ' + [regex]::Escape($Name) + '\(.*?(?=^    (?:public|private|protected) function |\z)')
    if ($matches.Count -ne 1) { throw "Ambiguous method: $Name" }
    $matches[0].Value
}
$crParentReceiptPath = Join-Path $crDocs 'duty-note-source-increment-r31b.json'
$crParentReceipt = Get-Content -LiteralPath $crParentReceiptPath -Raw | ConvertFrom-Json
$crBeforePins = Get-Content -LiteralPath (Join-Path $crDocs 'note-baseline-before-r34.json') -Raw | ConvertFrom-Json
foreach ($pin in $crBeforePins) { if ((Get-CrHash (Join-Path $crBefore $pin.path)) -ne $pin.sha256) { throw 'Reviewed predecessor changed.' } }
$crProducts = @($crParentReceipt.currentProductPins | ForEach-Object {
    @{ path = $_.path; sha256 = Get-CrHash (Join-Path $crRoot $_.path); r31bSha256 = $_.sha256 }
})
$crChanged = @($crProducts | Where-Object { $_.sha256 -ne $_.r31bSha256 })
if ($crProducts.Count -ne 17 -or $crChanged.Count -ne 2) { throw 'Unexpected product scope drift.' }
$crCommandPath = 'app/Services/ControlRoom/ControlRoomShiftHandoverService.php'
$crOld = [IO.File]::ReadAllText((Join-Path $crBefore $crCommandPath))
$crCurrent = [IO.File]::ReadAllText((Join-Path $crRoot $crCommandPath))
$crEol = $(if ($crCurrent.Contains("`r`n")) { "`r`n" } else { "`n" })
$crRestored = $crCurrent.Replace('            $noteSeal = $this->selectedNoteSeal($snapshot);' + $crEol, '')
$crRestored = $crRestored.Replace('assertPersistedNotesReadable($locked, $noteSeal,', 'assertPersistedNotesReadable($locked, $snapshot,')
$crPrepareSame = (Get-CrMethod $crOld 'prepare') -ceq (Get-CrMethod $crRestored 'prepare')
$crAcceptSame = (Get-CrMethod $crOld 'accept') -ceq (Get-CrMethod $crRestored 'accept')
$crOldStart = $crOld.IndexOf('    private function assertPersistedNotesReadable(')
$crOldEnd = $crOld.IndexOf('    private function assertVersion(', $crOldStart)
$crNewStart = $crRestored.IndexOf('    private function assertPersistedNotesReadable(')
$crNewEnd = $crRestored.IndexOf('    private function assertVersion(', $crNewStart)
if ($crOldStart -lt 0 -or $crOldEnd -lt $crOldStart -or $crNewStart -lt 0 -or $crNewEnd -lt $crNewStart) { throw 'Comparison helper spans not found.' }
$crRestored = $crRestored.Substring(0, $crNewStart) + $crOld.Substring($crOldStart, $crOldEnd - $crOldStart) + $crRestored.Substring($crNewEnd)
$crOtherCommandSame = $crRestored -ceq $crOld
if (!$crPrepareSame -or !$crAcceptSame -or !$crOtherCommandSame) { throw 'Unexpected unrelated command delta.' }
$crHistory = [IO.File]::ReadAllText((Join-Path $crRoot 'tests/Feature/ControlRoom/ControlRoomAcceptedHandoverHistoryTest.php'))
if ([regex]::Matches($crHistory, '(?m)^    public function test_').Count -ne 25) { throw 'Native declaration inventory changed.' }
$crSyntax = Get-Content -LiteralPath (Join-Path $crDocs 'accepted-note-syntax-r34-result.json') -Raw | ConvertFrom-Json
$crSyntaxImage = Get-Content -LiteralPath (Join-Path $crDocs 'accepted-note-syntax-r34-inputs.json') -Raw | ConvertFrom-Json
foreach ($pin in $crSyntaxImage.pins) { if ((Get-CrHash $pin.path) -ne $pin.sha256) { throw 'Final syntax input drift.' } }
$crFrontImage = Get-Content -LiteralPath (Join-Path $crDocs 'owned-frontend-inputs-r32.json') -Raw | ConvertFrom-Json
foreach ($pin in $crFrontImage.sourcePins) { if ((Get-CrHash $pin.path) -ne $pin.sha256) { throw 'Unchanged frontend input drift.' } }
$crEvidence = @(
    'docs/control-room-audit-2026-10-11/note-baseline-before-r34.json',
    'docs/control-room-audit-2026-10-11/run-note-syntax-r34.ps1',
    'docs/control-room-audit-2026-10-11/accepted-note-syntax-r34-inputs.json',
    'docs/control-room-audit-2026-10-11/accepted-note-syntax-r34-result.json',
    'docs/control-room-audit-2026-10-11/duty-note-source-increment-r31b.json',
    'docs/control-room-audit-2026-10-11/owned-frontend-inputs-r32.json',
    'test-results/control-room-owned-component-a-r32-20261012/result.json',
    'docs/control-room-audit-2026-10-11/package-note-baseline-r34.ps1'
)
$crPayload = [ordered]@{
    atUtc = [DateTime]::UtcNow.ToString('o'); candidate = $crRoot; revision = 'R34 original complete selected-note baseline correction'
    branch = 'codex/control-room-delivery'; base = 'ce50e22f5b5b85fdd1bf42a8401ec31015deae80'
    status = 'CANDIDATE_SOURCE_ONLY; parent review/runtime/privacy acceptance pending'
    parentFinding = 'R31b compared saved collection IDs then relearned content/origin/metadata from fresh(). A coherent note+both copies+digest rewrite, or metadata-only rewrite, could preserve IDs and commit changed reviewed work.'
    currentProductPins = $crProducts; changedProducts = $crChanged; unchangedProductCount = 15; predecessorsMatched = $crBeforePins.Count
    implementation = @{
        originalBaseline = 'Before transition save/audit, seal complete pinned_notes/followup_notes/note_alert_ids into a dedicated immutable string. Includes every saved field: text, IDs, type/purpose, flags/deadlines, actor display, created time and complete origin.'
        persistedChecks = 'First fresh raw snapshot and final raw locked snapshot both compare against that original pre-write seal. Neither expected value nor tuple contents are relearned from fresh(). Existing current canonical note admission and whole-snapshot consistency remain additional checks.'
        normalisation = 'Only JSON representation: object member order, whitespace and escaping. Preserve arrays vs objects, list/copy order, every field/value, exact text, scalar types including numeric fraction distinctions. Missing/non-list selected collections and references reject.'
        finalBoundary = 'All normal model/read/audit callbacks precede the final raw original-seal check. Return already read model; no following model retrieval or normal write.'
        unchanged = 'Shared CR reader/private source boundary, controllers/AlwaysProps/no-raw-fallback frontend, original provenance migration/model/writer/lifecycle and unrelated transition guards unchanged. No backfill, grant or H&S policy fork.'
    }
    commandProofs = @{
        prepareOutsideSealCaptureAndPassingByteExact = $crPrepareSame
        acceptOutsideSealCaptureAndPassingByteExact = $crAcceptSame
        wholeServiceOutsideSealCapturePassingAndFinalHelperRegionByteExact = $crOtherCommandSame
        commandBeforeSha256 = Get-CrHash (Join-Path $crBefore $crCommandPath)
        commandCurrentSha256 = Get-CrHash (Join-Path $crRoot $crCommandPath)
        finalHelperSpanSha256 = Get-CrTextHash (Get-CrMethod $crCurrent 'assertPersistedNotesReadable')
        trackedWhitespaceExit = 0
    }
    authoredControls = @{
        nativeWholeFileDeclarations = 25; prospectiveWholeFileCases = 75; previousCasesRetained = 65; newProspectiveCases = 10; nativeRun = $false
        lateMutationProviderRows = 14; stages = @('prepare', 'accept')
        oldLateKindsRetained = @('origin', 'copy_text', 'remove_copy')
        newLateKinds = @('coherent_text', 'copy_flags', 'copy_deadline', 'copy_actor_display')
        coherent = 'Successful reached AuditLog::created callback changes OperatorNote.content/origin digest and BOTH saved copies/content/digests while retaining IDs/actor/type/time/Site/person/audit. Whole shift/note/audit state must roll back.'
        metadata = 'Both copies flags, deadline or actor display change independently under same IDs; whole transition must roll back.'
        positives = 'Prior ordinary actual-command/readable independent positives retained; two reached prepare/accept callback positives reorder only JSON object keys without changing any note values. No executed assertion or rollback pass claimed.'
        frontendWholeSuiteCount = 6; frontendAuthoredCases = 33; frontendSourceChanged = $false; frontendComponentRun = $false
    }
    actualChecks = @{
        syntax = @{ state = $crSyntax.state; childrenStarted = $crSyntax.compilerChildrenStarted; grammarFilesChecked = @($crSyntax.syntax).Count; afterReadComplete = $crSyntax.afterReadComplete; issue = $crSyntax.issue; freeMiB = $crSyntax.resources[0].freeMiB; cpuPercent = $crSyntax.resources[0].cpuPercent; heavyPeers = @($crSyntax.resources[0].heavyPeerIds).Count; finalPhpInputs = $crSyntaxImage.files.Count }
        unchangedFrontendImagePinsMatched = $crFrontImage.sourcePins.Count
        frontendResult = 'Prior R32 component held before child; unchanged whole six-suite/33-case source queue retained. Not repeated without source change or new admission evidence.'
        formattingLintTypeNativeDatabaseBuildBrowser = 'UNRUN'; applicationMigrationExecuted = $false; runtimeAcceptance = $false
    }
    evidencePins = @($crEvidence | ForEach-Object { @{ path = $_; sha256 = Get-CrHash (Join-Path $crRoot $_) } })
    hsSourceCopyApiAndSameTextWriterInvalidation = 'PENDING H&S owner; prior parent routing retained; no competing predicate or present-context backfill'
    overallAudit = 'INCOMPLETE'; mainApplicationChanged = $false; newMigrationRoleRoute = $false; stagedCommittedPushed = $false; integratedDeployed = $false
}
[IO.File]::WriteAllText($crOutput, ($crPayload | ConvertTo-Json -Depth 17) + "`n", $crUtf8)
[pscustomobject]@{ receiptSha256 = Get-CrHash $crOutput; changedProducts = $crChanged.Count; unchangedProducts = 15; prepareProof = $crPrepareSame; acceptProof = $crAcceptSame; otherCommandProof = $crOtherCommandSame; syntax = $crPayload.actualChecks.syntax } | ConvertTo-Json -Depth 4
