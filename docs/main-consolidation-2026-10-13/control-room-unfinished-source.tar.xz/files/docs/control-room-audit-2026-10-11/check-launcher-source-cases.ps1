# Synthetic source guards only. Never dot-source a runtime launcher or probe resources.
$ErrorActionPreference = 'Stop'
$taskDirectory = $PSScriptRoot
$taskTokens = $null; $taskErrors = $null
$frontendAst = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $taskDirectory 'run-front-end-checks.ps1'),[ref]$taskTokens,[ref]$taskErrors)
if (@($taskErrors).Count) { throw 'Frontend source does not parse.' }
$resourceAst = [System.Management.Automation.Language.Parser]::ParseFile((Join-Path $taskDirectory 'control-room-resource-proof.ps1'),[ref]$taskTokens,[ref]$taskErrors)
if (@($taskErrors).Count) { throw 'Resource integration source does not parse.' }
$definitions = @($frontendAst.FindAll({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in @('Compare-Inputs','Read-BoundInputs')},$true) | ForEach-Object { $_.Extent.Text })
$definitions += @($resourceAst.FindAll({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -eq 'Assert-ControlRoomResourceProof'},$true) | ForEach-Object { $_.Extent.Text })
if ($definitions.Count -ne 3) { throw 'Exactly the three reviewed pure guards are required.' }
$moduleSource = ($definitions -join "`n") + @'

$ExpectedReadinessSha256 = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
$readyPath = 'fixture-only'
function Get-FileHash { [pscustomobject]@{Hash=$script:fixtureReadinessHash} }
function Read-Inputs { $script:fixtureInputs }
Export-ModuleMember -Function @()
'@
$guardModule = New-Module -ScriptBlock ([scriptblock]::Create($moduleSource))
$pins = @([pscustomobject]@{path='resources/js/pages/control-room/settings.tsx';sha256='original-owned'},
    [pscustomobject]@{path='vitest.config.ts';sha256='original-config'})
$inputCases = @(
    @{name='exact reviewed inputs';inputs=$pins;readyHash=('a'*64);allow=$true},
    @{name='owned edit during preflight';inputs=@([pscustomobject]@{path=$pins[0].path;sha256='later-owned-edit'},$pins[1]);readyHash=('a'*64);allow=$false},
    @{name='unowned config edit';inputs=@($pins[0],[pscustomobject]@{path=$pins[1].path;sha256='changed-config'});readyHash=('a'*64);allow=$false},
    @{name='input removal';inputs=@($pins[0]);readyHash=('a'*64);allow=$false},
    @{name='input addition';inputs=@($pins+[pscustomobject]@{path='resources/js/later.ts';sha256='new'});readyHash=('a'*64);allow=$false},
    @{name='reviewed receipt replacement';inputs=$pins;readyHash=('b'*64);allow=$false},
    @{name='post-format baseline drift';inputs=@([pscustomobject]@{path=$pins[0].path;sha256='later-test-edit'},$pins[1]);readyHash=('a'*64);allow=$false}
)
$results = @()
foreach ($case in $inputCases) {
    $allowed = & $guardModule {
        param($fixture,$expected)
        $script:fixtureInputs = $fixture.inputs; $script:fixtureReadinessHash = $fixture.readyHash
        try { $null = @(Read-BoundInputs $expected 'synthetic-child-boundary'); $true } catch { $false }
    } $case $pins
    $results += [pscustomobject]@{case=$case.name;pass=($allowed -eq $case.allow)}
}
$valid = @{sampleValid=$true;freeMiB=4096;cpuPercent=0;heavyNodeIds=@();competingNativeIds=@();unknownProcessIds=@()}
$resourceCases = @(
    @{name='exact lower memory and zero CPU boundary';changes=@{};allow=$true},
    @{name='null CPU';changes=@{cpuPercent=$null};allow=$false},
    @{name='null memory';changes=@{freeMiB=$null};allow=$false},
    @{name='invalid observed sample';changes=@{sampleValid=$false};allow=$false},
    @{name='missing observed validity';changes=@{sampleValid=$null};allow=$false},
    @{name='below memory reserve';changes=@{freeMiB=4095};allow=$false},
    @{name='CPU limit reached';changes=@{cpuPercent=85};allow=$false},
    @{name='heavy Node job';changes=@{heavyNodeIds=@(123)};allow=$false},
    @{name='native client or test job';changes=@{competingNativeIds=@(124)};allow=$false},
    @{name='unknown Node including arbitrary eval';changes=@{unknownProcessIds=@(125)};allow=$false}
)
foreach ($case in $resourceCases) {
    $proof = $valid.Clone(); foreach ($key in $case.changes.Keys) { $proof[$key] = $case.changes[$key] }
    $allowed = & $guardModule {param($proof) try { Assert-ControlRoomResourceProof ([pscustomobject]$proof); $true } catch { $false }} $proof
    $results += [pscustomobject]@{case=$case.name;pass=($allowed -eq $case.allow)}
}
$receipt = [pscustomobject]@{sourceOnly=$true;syntheticCases=$results;caseCount=$results.Count;
    passed=@($results | Where-Object pass).Count;failed=@($results | Where-Object { -not $_.pass }).Count;
    resourceProbePerformed=$false;runtimeChildrenStarted=0;applicationStarted=$false;databaseOpened=$false;
    frontendRunnerSha256=(Get-FileHash -LiteralPath (Join-Path $taskDirectory 'run-front-end-checks.ps1') -Algorithm SHA256).Hash;
    resourceIntegrationSha256=(Get-FileHash -LiteralPath (Join-Path $taskDirectory 'control-room-resource-proof.ps1') -Algorithm SHA256).Hash}
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskDirectory 'launcher-source-cases.json')
Write-Output "Synthetic source guards: $($receipt.passed)/$($receipt.caseCount), failed=$($receipt.failed). No resource probe or runtime child."
if ($receipt.failed) { exit 1 }
exit 0
