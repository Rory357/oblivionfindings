import { CommandCentrePage } from '@/components/command-centre/command-centre-page';
import PageShell from '@/components/page-shell';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import AppLayout from '@/layouts/app-layout';
import {
    ALERT_SEVERITY_VOCAB,
    ALERT_STATUS_VOCAB,
    vocabularyFor,
} from '@/lib/control-room-vocab';
import { Head, router, usePage } from '@inertiajs/react';
import {
    BarChart3,
    Download,
} from 'lucide-react';

interface Props {
    period: string;
    stats: {
        total_alerts: number;
        resolved_alerts: number;
        cohort_resolved_alerts: number;
        resolution_rate: number;
        avg_resolution_hours: number | null;
        escalated_count: number;
        escalation_rate: number;
    };
    by_severity: Record<string, number>;
    by_status: Record<string, number>;
    by_source: Record<string, number>;
    by_alert_type: Record<string, number>;
    daily_trend: { date: string; count: number }[];
    response_time_by_severity: Record<string, number>;
    top_assignees: { user: string; count: number }[];
}

const severityColors: Record<string, string> = {
    critical: 'bg-status-critical',
    high: 'bg-status-warning',
    medium: 'bg-status-warning',
    low: 'bg-status-info',
};

const statusColors: Record<string, string> = {
    open: 'bg-status-critical',
    ack: 'bg-status-warning',
    triaging: 'bg-status-info',
    resolved: 'bg-status-success',
    closed: 'bg-muted',
};

export default function ControlRoomReports({
    period,
    stats,
    by_severity,
    by_status,
    by_source,
    by_alert_type,
    daily_trend,
    response_time_by_severity,
    top_assignees,
}: Props) {
    const currentQuery = new URL(usePage().url, 'https://control-room.invalid').searchParams;
    const sectionHref = (section: string) => `/control-room/reports?${currentQuery.toString()}#${section}`;
    const handlePeriodChange = (newPeriod: string) => {
        const query = new URLSearchParams(currentQuery);
        query.set('period', newPeriod);
        query.delete('date_from');
        query.delete('date_to');
        query.delete('page');
        router.get(
            `/control-room/reports?${query.toString()}`,
            {},
            { preserveState: true, preserveScroll: true },
        );
    };

    const handleExport = () => {
        window.location.href = `/control-room/reports/export?${currentQuery.toString()}`;
    };

    const maxTrend = Math.max(...daily_trend.map((d) => d.count), 1);

    return (
        <AppLayout
            breadcrumbs={[
                { title: 'Home', href: '/dashboard' },
                { title: 'Control Room', href: '/control-room' },
                { title: 'Reports', href: '#' },
            ]}
        >
            <Head title="Control Room Reports" />
            <PageShell>
                <CommandCentrePage
                    variant="compact"
                    current="/control-room/reports"
                    icon={BarChart3}
                    title="Reports"
                    description="Review and export accountable Control Room activity and performance."
                    status="Reporting workspace"
                    freshness={`Period: ${period}`}
                    metricGroups={[{
                        title: 'Response performance', icon: BarChart3, metrics: [
                            { label: 'Raised', value: String(stats.total_alerts), caption: 'in the selected period', tone: 'neutral', href: sectionHref('report-volume') },
                            { label: 'Resolution rate', value: `${stats.resolution_rate}%`, caption: `${stats.cohort_resolved_alerts} of the responses raised`, tone: 'success', href: sectionHref('report-status') },
                            { label: 'Resolved', value: String(stats.resolved_alerts), caption: 'resolution recorded in this period', tone: 'success', href: sectionHref('report-outcomes') },
                            { label: 'Average resolution', value: stats.avg_resolution_hours === null ? '—' : `${stats.avg_resolution_hours}h`, caption: stats.avg_resolution_hours === null ? 'No measured timings' : 'recorded response timings', tone: 'neutral', href: sectionHref('report-outcomes') },
                            { label: 'Escalation rate', value: `${stats.escalation_rate}%`, caption: `${stats.escalated_count} responses raised in this period`, tone: 'warning', href: sectionHref('report-outcomes') },
                        ],
                    }]}
                    actions={<Button variant="outline" size="sm" onClick={handleExport} className="border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground hover:bg-primary-foreground/20 hover:text-primary-foreground"><Download className="mr-2 h-4 w-4" />Export CSV</Button>}
                    filters={<div className="flex items-center gap-2"><span className="text-xs text-primary-foreground/80">Period</span>
                            <Select
                                value={period}
                                onValueChange={handlePeriodChange}
                            >
                                <SelectTrigger aria-label="Report period" className="w-32 border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground backdrop-blur-sm hover:bg-primary-foreground/20">
                                    <SelectValue />
                                </SelectTrigger>
                                <SelectContent>
{period === 'custom' && <SelectItem value="custom">Custom dates</SelectItem>}
                                    <SelectItem value="7d">
                                        Last 7 days
                                    </SelectItem>
                                    <SelectItem value="30d">
                                        Last 30 days
                                    </SelectItem>
                                    <SelectItem value="90d">
                                        Last 90 days
                                    </SelectItem>
                                    <SelectItem value="1y">
                                        Last year
                                    </SelectItem>
                                </SelectContent>
                            </Select>
                    </div>}
                >
                    <Card id="report-outcomes">
                        <CardHeader><CardTitle>Recorded outcomes</CardTitle></CardHeader>
                        <CardContent className="space-y-2 text-sm text-muted-foreground">
                            <p>{stats.resolved_alerts} responses were resolved during this period, including responses raised earlier.</p>
                            <p>{stats.cohort_resolved_alerts} of the {stats.total_alerts} responses raised during this period now have a resolved or closed outcome ({stats.resolution_rate}%).</p>
                            <p>{stats.escalated_count} responses raised during this period were escalated ({stats.escalation_rate}%).</p>
                            <p>Average recorded resolution time: {stats.avg_resolution_hours === null ? 'Not measured' : `${stats.avg_resolution_hours} hours`}. A response outcome does not establish source reporting or safety governance completion.</p>
                        </CardContent>
                    </Card>

                    {/* Charts Row */}
                    <div className="mt-6 grid gap-4 lg:grid-cols-2">
                        {/* Daily Trend */}
                        <Card id="report-volume">
                            <CardHeader>
                                <CardTitle>Daily Alert Trend</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {daily_trend.length > 0 ? (
                                    <div className="flex h-40 items-end gap-1">
                                        {daily_trend
                                            .slice(-30)
                                            .map((day, i) => (
                                                <div
                                                    key={i}
                                                    className="group relative flex-1"
                                                >
                                                    <div
                                                        className="w-full rounded-t bg-primary transition-all hover:bg-primary/80"
                                                        style={{
                                                            height: `${(day.count / maxTrend) * 100}%`,
                                                            minHeight:
                                                                day.count > 0
                                                                    ? '4px'
                                                                    : '0',
                                                        }}
                                                    />
                                                    <div className="absolute bottom-full left-1/2 mb-1 hidden -translate-x-1/2 rounded bg-popover px-2 py-1 text-xs shadow-md group-hover:block">
                                                        {day.date}: {day.count}
                                                    </div>
                                                </div>
                                            ))}
                                    </div>
                                ) : (
                                    <p className="text-sm text-muted-foreground">
                                        No data available
                                    </p>
                                )}
                            </CardContent>
                        </Card>

                        {/* By Severity */}
                        <Card>
                            <CardHeader>
                                <CardTitle>By Severity</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {['critical', 'high', 'medium', 'low'].map(
                                        (sev) => {
                                            const count = by_severity[sev] || 0;
                                            const pct =
                                                stats.total_alerts > 0
                                                    ? (count /
                                                          stats.total_alerts) *
                                                      100
                                                    : 0;
                                            return (
                                                <div key={sev}>
                                                    <div className="mb-1 flex justify-between text-sm">
                                                        <span>
                                                            {
                                                                vocabularyFor(
                                                                    ALERT_SEVERITY_VOCAB,
                                                                    sev,
                                                                ).label
                                                            }
                                                        </span>
                                                        <span className="text-muted-foreground">
                                                            {count} (
                                                            {pct.toFixed(1)}
                                                            %)
                                                        </span>
                                                    </div>
                                                    <div className="h-2 rounded-full bg-muted">
                                                        <div
                                                            className={`h-full rounded-full ${severityColors[sev]}`}
                                                            style={{
                                                                width: `${pct}%`,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            );
                                        },
                                    )}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Second Row */}
                    <div className="mt-4 grid gap-4 lg:grid-cols-3">
                        {/* By Status */}
                        <Card id="report-status">
                            <CardHeader>
                                <CardTitle>By Status</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {Object.entries(by_status).map(
                                        ([status, count]) => (
                                            <div
                                                key={status}
                                                className="flex items-center justify-between"
                                            >
                                                <div className="flex items-center gap-2">
                                                    <div
                                                        className={`h-3 w-3 rounded-full ${statusColors[status] || 'bg-muted'}`}
                                                    />
                                                    <span className="text-sm">
                                                        {
                                                            vocabularyFor(
                                                                ALERT_STATUS_VOCAB,
                                                                status,
                                                            ).label
                                                        }
                                                    </span>
                                                </div>
                                                <span className="text-sm font-medium">
                                                    {count}
                                                </span>
                                            </div>
                                        ),
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* By Source */}
                        <Card>
                            <CardHeader>
                                <CardTitle>By Source</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {Object.entries(by_source).map(
                                        ([source, count]) => (
                                            <div
                                                key={source}
                                                className="flex items-center justify-between"
                                            >
                                                <span className="text-sm">
                                                    {source.replace('_', ' ')}
                                                </span>
                                                <span className="text-sm font-medium">
                                                    {count}
                                                </span>
                                            </div>
                                        ),
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Top Alert Types */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Top Alert Types</CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-2">
                                    {Object.entries(by_alert_type)
                                        .slice(0, 5)
                                        .map(([type, count]) => (
                                            <div
                                                key={type}
                                                className="flex items-center justify-between"
                                            >
                                                <span className="truncate text-sm">
                                                    {type}
                                                </span>
                                                <span className="ml-2 text-sm font-medium">
                                                    {count}
                                                </span>
                                            </div>
                                        ))}
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Third Row */}
                    <div className="mt-4 grid gap-4 lg:grid-cols-2">
                        {/* Response Time by Severity */}
                        <Card>
                            <CardHeader>
                                <CardTitle>
                                    Avg Response Time by Severity (minutes)
                                </CardTitle>
                            </CardHeader>
                            <CardContent>
                                <div className="space-y-3">
                                    {['critical', 'high', 'medium', 'low'].map(
                                        (sev) => {
                                            const mins =
                                                response_time_by_severity[
                                                    sev
                                                ] || 0;
                                            return (
                                                <div
                                                    key={sev}
                                                    className="flex items-center justify-between"
                                                >
                                                    <span className="capitalize">
                                                        {sev}
                                                    </span>
                                                    <span className="font-medium">
                                                        {mins > 0
                                                            ? `${Math.round(mins)} min`
                                                            : '-'}
                                                    </span>
                                                </div>
                                            );
                                        },
                                    )}
                                </div>
                            </CardContent>
                        </Card>

                        {/* Top Assignees */}
                        <Card>
                            <CardHeader>
                                <CardTitle>Top Assignees</CardTitle>
                            </CardHeader>
                            <CardContent>
                                {top_assignees.length > 0 ? (
                                    <div className="space-y-2">
                                        {top_assignees.map((a, i) => (
                                            <div
                                                key={i}
                                                className="flex items-center justify-between"
                                            >
                                                <span className="text-sm">
                                                    {a.user}
                                                </span>
                                                <span className="text-sm font-medium">
                                                    {a.count} alerts
                                                </span>
                                            </div>
                                        ))}
                                    </div>
                                ) : (
                                    <p className="text-sm text-muted-foreground">
                                        No assignments in this period
                                    </p>
                                )}
                            </CardContent>
                        </Card>
                    </div>
                </CommandCentrePage>
            </PageShell>
        </AppLayout>
    );
}
