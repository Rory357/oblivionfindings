<?php

require __DIR__.'/../../vendor/autoload.php';

use Illuminate\Database\MySqlConnection;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Compile the actual migration with MySQL grammar; any attempted connection fails.
$connection = new MySqlConnection(static fn () => throw new LogicException('Offline schema check cannot connect.'),
    'offline_compile_only', '', ['driver' => 'mysql', 'version' => '8.0.36', 'charset' => 'utf8mb4', 'collation' => 'utf8mb4_unicode_ci']);
$connection->useDefaultSchemaGrammar();
$capture = new class($connection)
{
    public array $sql = [];

    public function __construct(private readonly MySqlConnection $connection) {}

    public function table(string $name, Closure $callback): void
    {
        $blueprint = new Blueprint($this->connection, $name);
        $callback($blueprint);
        array_push($this->sql, ...$blueprint->toSql());
    }
};
Schema::swap($capture);
$migration = require __DIR__.'/../../database/migrations/2026_10_11_160000_add_control_room_settings_revisions.php';
$migration->up();
$up = $capture->sql;
$capture->sql = [];
$migration->down();
$down = $capture->sql;
$tables = ['control_room_signal_rules', 'control_room_triage_queues', 'control_room_maintenance_windows'];
if (count($up) !== 3 || count($down) !== 3) {
    throw new LogicException('Expected three additions and three reversals.');
}
foreach ($tables as $index => $table) {
    if (! str_contains($up[$index], "alter table `{$table}` add `settings_revision` bigint unsigned not null default '1'")) {
        throw new LogicException('Settings revisions must be persisted and start at one.');
    }
    if (! str_contains($down[$index], "alter table `{$table}` drop `settings_revision`")) {
        throw new LogicException('Missing reversal.');
    }
}
preg_match_all('/`([^`]+)`/', implode("\n", [...$up, ...$down]), $matches);
$identifiers = array_values(array_unique($matches[1]));
$overlong = array_values(array_filter($identifiers, static fn (string $identifier): bool => strlen($identifier) > 64));
$receipt = ['connectionOpened' => false, 'up' => $up, 'down' => $down, 'statementsCompiled' => count($up) + count($down),
    'maximumIdentifierLength' => max(array_map('strlen', $identifiers)), 'overlong' => $overlong,
    'migrationSha256' => hash_file('sha256', __DIR__.'/../../database/migrations/2026_10_11_160000_add_control_room_settings_revisions.php')];
file_put_contents(__DIR__.'/settings-schema-compiled.sql', implode(";\n", [...$up, ...$down]).";\n");
file_put_contents(__DIR__.'/settings-schema-identifiers.json', json_encode($receipt, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
echo json_encode($receipt, JSON_THROW_ON_ERROR).PHP_EOL;
exit($overlong === [] ? 0 : 1);
