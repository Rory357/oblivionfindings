import { CommandCentrePage } from '@/components/command-centre/command-centre-page';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import {
    Select,
    SelectContent,
    SelectItem,
    SelectTrigger,
    SelectValue,
} from '@/components/ui/select';
import AppLayout from '@/layouts/app-layout';
import { formatRelative, formatTime } from '@/lib/datetime';
import { Head, Link, router } from '@inertiajs/react';
import 'leaflet/dist/leaflet.css';
import {
    Activity,
    AlertTriangle,
    Map,
    MapPin,
    Radio,
    RefreshCw,
    ShieldAlert,
    ShieldCheck,
    Wifi,
    WifiOff,
} from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';

// ── Types ────────────────────────────────────────────────────────────────────

interface MapDevice {
    id: number;
    device_uid: string | null;
    name: string;
    type: string;
    type_label: string;
    status: string;
    health_status: string | null;
    latitude: number;
    longitude: number;
    battery_level: number | null;
    last_seen_at: string | null;
    position_source: string;
    context_label: string | null;
    manufacturer: string | null;
    model: string | null;
    site_id: number | null;
    identity_source: 'canonical';
    privacy_state: string | null;
    privacy_basis: string | null;
    detail_url: string;
}

interface MapSite {
    id: number;
    name: string;
    address: string;
    latitude: number;
    longitude: number;
}

interface GeofenceShape {
    lat?: number;
    lon?: number;
    radius_m?: number;
    center?: { lat?: number; lng?: number };
    points?: { lat: number; lng: number }[];
}

interface MapGeofence {
    id: number;
    name: string;
    type: string;
    shape: GeofenceShape;
    breach_type: string;
    site_id: number | null;
}

interface MapAlert {
    id: number;
    alert_type: string;
    severity: string;
    status: string;
    triggered_at: string | null;
    device_id: number | null;
    site_id: number | null;
    latitude: number | null;
    longitude: number | null;
    detail_url: string;
}

interface SiteOption {
    id: number;
    name: string;
}

interface Stats {
    total_devices: number;
    online: number;
    offline: number;
    active_alerts: number;
    location_restricted: number;
}

interface LocationBoundary {
    position_access: boolean;
    title: string;
    description: string;
    canonical_url: string | null;
}

interface Props {
    devices: MapDevice[];
    sites: MapSite[];
    geofences: MapGeofence[];
    alerts: MapAlert[];
    all_sites: SiteOption[];
    stats: Stats;
    location_boundary: LocationBoundary;
    filters: Record<string, string | null>;
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function isRecentlySeen(lastSeen: string | null, minutes: number = 5): boolean {
    if (!lastSeen) return false;
    const diff = Date.now() - new Date(lastSeen).getTime();
    return diff < minutes * 60 * 1000;
}

export function escapeMapHtml(value: unknown): string {
    return String(value ?? '').replace(/[&<>"']/g, (character) => {
        const entities: Record<string, string> = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;',
        };

        return entities[character];
    });
}

export function mapDeviceActivityLabel(device: {
    status: string;
    last_seen_at: string | null;
}): string {
    if (device.status === 'offline') return 'Offline';
    if (device.status === 'unknown') return 'Status unknown';

    return isRecentlySeen(device.last_seen_at, 5)
        ? 'Recently updated'
        : 'Reporting';
}

// ── Pulse animation CSS ─────────────────────────────────────────────────────

const pulseStyle = `
@keyframes pulse-ring {
    0% { transform: scale(0.5); opacity: 1; }
    100% { transform: scale(2.5); opacity: 0; }
}
.leaflet-alert-pulse {
    width: 20px;
    height: 20px;
    position: relative;
}
.leaflet-alert-pulse::before {
    content: '';
    position: absolute;
    inset: 0;
    border-radius: 50%;
    background: rgba(239, 68, 68, 0.4);
    animation: pulse-ring 1.5s ease-out infinite;
}
.leaflet-alert-pulse-dot {
    width: 12px;
    height: 12px;
    background: #ef4444;
    border-radius: 50%;
    border: 2px solid #fff;
    position: absolute;
    top: 4px;
    left: 4px;
    box-shadow: 0 0 6px rgba(239, 68, 68, 0.6);
}
`;

// ── Component ────────────────────────────────────────────────────────────────

export default function ControlRoomMap({
    devices,
    sites,
    geofences,
    alerts,
    all_sites,
    stats,
    location_boundary,
    filters,
}: Props) {
    const mapRef = useRef<HTMLDivElement>(null);
    const mapInstanceRef = useRef<L.Map | null>(null);
    const layerGroupRef = useRef<L.LayerGroup | null>(null);
    const [isMapReady, setIsMapReady] = useState(false);
    const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());

    // ── Filters ──────────────────────────────────────────────────────────────

    const applyFilter = useCallback(
        (key: string, value: string) => {
            const newFilters = {
                ...filters,
                [key]: value === 'all' ? undefined : value,
            };
            // Clean undefined values
            Object.keys(newFilters).forEach((k) => {
                if (!newFilters[k]) delete newFilters[k];
            });
            router.get('/control-room/map', newFilters, {
                preserveState: true,
                preserveScroll: true,
            });
        },
        [filters],
    );

    const clearFilters = useCallback(() => {
        router.get('/control-room/map', {}, { preserveState: true });
    }, []);

    const manualRefresh = useCallback(() => {
        router.reload({ only: ['devices', 'alerts', 'stats'] });
        setLastRefreshed(new Date());
    }, []);

    const hasFilters = Object.values(filters).some((v) => v);

    // ── Map initialization ───────────────────────────────────────────────────

    useEffect(() => {
        let mounted = true;

        async function initMap() {
            const leaflet = await import('leaflet');
            const L = (leaflet as any).default ?? leaflet;

            if (!mounted || !mapRef.current || mapInstanceRef.current) return;

            const map = L.map(mapRef.current, {
                center: [-41.2865, 174.7762],
                zoom: 6,
                zoomControl: true,
                attributionControl: true,
            });

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 19,
            }).addTo(map);

            const layerGroup = L.layerGroup().addTo(map);

            mapInstanceRef.current = map;
            layerGroupRef.current = layerGroup;

            if (mounted) {
                setIsMapReady(true);
            }
        }

        initMap();

        return () => {
            mounted = false;
            if (mapInstanceRef.current) {
                mapInstanceRef.current.remove();
                mapInstanceRef.current = null;
                layerGroupRef.current = null;
                setIsMapReady(false);
            }
        };
    }, []);

    // ── Render markers ───────────────────────────────────────────────────────

    useEffect(() => {
        if (!isMapReady || !mapInstanceRef.current || !layerGroupRef.current)
            return;

        async function renderMarkers() {
            const leaflet = await import('leaflet');
            const L =
                'default' in leaflet
                    ? ((leaflet as Record<string, unknown>)
                          .default as typeof leaflet)
                    : leaflet;
            const map = mapInstanceRef.current!;
            const layers = layerGroupRef.current!;

            layers.clearLayers();

            const bounds: L.LatLngExpression[] = [];

            // ── Geofence overlays ────────────────────────────────────────────

            geofences.forEach((gf) => {
                if (!gf.shape) return;

                const circleLatitude = gf.shape.lat ?? gf.shape.center?.lat;
                const circleLongitude = gf.shape.lon ?? gf.shape.center?.lng;

                if (
                    gf.type === 'circle' &&
                    circleLatitude !== undefined &&
                    circleLongitude !== undefined &&
                    gf.shape.radius_m
                ) {
                    L.circle([circleLatitude, circleLongitude], {
                        radius: gf.shape.radius_m,
                        color: '#6366f1',
                        fillColor: '#6366f1',
                        fillOpacity: 0.08,
                        weight: 1.5,
                        dashArray: '5, 5',
                    })
                        .bindPopup(
                            `<div class="text-sm"><strong>${escapeMapHtml(gf.name)}</strong><br/>` +
                                `Type: ${escapeMapHtml(gf.breach_type)}<br/>` +
                                `Radius: ${gf.shape.radius_m}m</div>`,
                        )
                        .addTo(layers);
                } else if (
                    gf.type === 'polygon' &&
                    gf.shape.points &&
                    gf.shape.points.length > 2
                ) {
                    const points: L.LatLngExpression[] = gf.shape.points.map(
                        (p) => [p.lat, p.lng],
                    );
                    L.polygon(points, {
                        color: '#6366f1',
                        fillColor: '#6366f1',
                        fillOpacity: 0.08,
                        weight: 1.5,
                        dashArray: '5, 5',
                    })
                        .bindPopup(
                            `<div class="text-sm"><strong>${escapeMapHtml(gf.name)}</strong><br/>` +
                                `Type: ${escapeMapHtml(gf.breach_type)}</div>`,
                        )
                        .addTo(layers);
                }
            });

            // ── Site markers ─────────────────────────────────────────────────

            sites.forEach((site) => {
                const siteIcon = L.divIcon({
                    className: '',
                    html: `<div style="
                        width: 28px; height: 28px; border-radius: 50%;
                        background: #f97316; border: 3px solid #fff;
                        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
                        display: flex; align-items: center; justify-content: center;
                    "><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg></div>`,
                    iconSize: [28, 28],
                    iconAnchor: [14, 14],
                    popupAnchor: [0, -16],
                });

                const marker = L.marker([site.latitude, site.longitude], {
                    icon: siteIcon,
                })
                    .bindPopup(
                        `<div class="text-sm">` +
                            `<strong>${escapeMapHtml(site.name)}</strong><br/>` +
                            `<span style="color:#666">${escapeMapHtml(site.address)}</span>` +
                            `</div>`,
                    )
                    .addTo(layers);

                bounds.push([site.latitude, site.longitude]);
            });

            // ── Device markers ───────────────────────────────────────────────

            devices.forEach((device) => {
                let color = '#6b7280'; // gray default
                const label = mapDeviceActivityLabel(device);

                if (device.type === 'personal_tracker') {
                    color = '#8b5cf6'; // purple
                } else if (device.type === 'asset_tracker') {
                    color = '#0f766e'; // teal
                } else if (
                    device.status === 'online' &&
                    isRecentlySeen(device.last_seen_at, 5)
                ) {
                    color = '#3b82f6'; // blue - recently updated
                } else if (device.status === 'online') {
                    color = '#22c55e'; // green
                } else if (device.status === 'offline') {
                    color = '#ef4444'; // red offline
                }

                const deviceIcon = L.divIcon({
                    className: '',
                    html: `<div style="
                        width: 22px; height: 22px; border-radius: 50%;
                        background: ${color}; border: 2.5px solid #fff;
                        box-shadow: 0 2px 6px rgba(0,0,0,0.3);
                    "></div>`,
                    iconSize: [22, 22],
                    iconAnchor: [11, 11],
                    popupAnchor: [0, -14],
                });

                const batteryStr =
                    device.battery_level !== null
                        ? `${device.battery_level}%`
                        : 'N/A';

                const popupContent =
                    `<div class="text-sm" style="min-width:180px">` +
                    `<strong>${escapeMapHtml(device.name || device.device_uid)}</strong><br/>` +
                    `<span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:${color};margin-right:4px;vertical-align:middle"></span>` +
                    `<span style="color:#666">${escapeMapHtml(label)}</span><br/>` +
                    `<span style="color:#666">Type: ${escapeMapHtml(device.type_label)}</span><br/>` +
                    `<span style="color:#666">Battery: ${batteryStr}</span><br/>` +
                    `<span style="color:#666">Last reported: ${escapeMapHtml(formatRelative(device.last_seen_at))}</span>` +
                    (device.context_label
                        ? `<br/><span style="color:#666">Context: ${escapeMapHtml(device.context_label)}</span>`
                        : '') +
                    (device.manufacturer
                        ? `<br/><span style="color:#888;font-size:11px">${escapeMapHtml(device.manufacturer)}${device.model ? ` ${escapeMapHtml(device.model)}` : ''}</span>`
                        : '') +
                    `<br/><a href="${escapeMapHtml(device.detail_url)}" style="display:inline-block;margin-top:6px;font-weight:600;color:#2563eb">Open canonical device →</a>` +
                    `</div>`;

                L.marker([device.latitude, device.longitude], {
                    icon: deviceIcon,
                })
                    .bindPopup(popupContent)
                    .addTo(layers);

                bounds.push([device.latitude, device.longitude]);
            });

            // ── Alert markers (pulsing red) ──────────────────────────────────

            const alertsWithLocation = alerts.filter(
                (a) => a.latitude !== null && a.longitude !== null,
            );

            alertsWithLocation.forEach((alert) => {
                const alertIcon = L.divIcon({
                    className: '',
                    html: `<div class="leaflet-alert-pulse"><div class="leaflet-alert-pulse-dot"></div></div>`,
                    iconSize: [20, 20],
                    iconAnchor: [10, 10],
                    popupAnchor: [0, -12],
                });

                const popupContent =
                    `<div class="text-sm" style="min-width:180px">` +
                    `<strong style="color:#ef4444">${escapeMapHtml(alert.alert_type)}</strong><br/>` +
                    `<span style="color:#666">Severity: ${escapeMapHtml(alert.severity)}</span><br/>` +
                    `<span style="color:#666">Status: ${escapeMapHtml(alert.status)}</span><br/>` +
                    `<span style="color:#666">Triggered: ${escapeMapHtml(formatRelative(alert.triggered_at))}</span>` +
                    `<br/><a href="${escapeMapHtml(alert.detail_url)}" style="display:inline-block;margin-top:6px;font-weight:600;color:#2563eb">Open alert →</a>` +
                    `</div>`;

                L.marker([alert.latitude!, alert.longitude!], {
                    icon: alertIcon,
                })
                    .bindPopup(popupContent)
                    .addTo(layers);

                bounds.push([alert.latitude!, alert.longitude!]);
            });

            // ── Fit bounds ───────────────────────────────────────────────────

            if (bounds.length > 1) {
                map.fitBounds(L.latLngBounds(bounds), {
                    padding: [40, 40],
                    maxZoom: 14,
                });
            } else if (bounds.length === 1) {
                map.setView(bounds[0] as L.LatLngExpression, 13);
            }
        }

        renderMarkers();
    }, [isMapReady, devices, sites, geofences, alerts]);

    // ── Auto-refresh every 30 seconds ────────────────────────────────────────

    useEffect(() => {
        const interval = setInterval(() => {
            if (document.hidden) return;
            router.reload({ only: ['devices', 'alerts', 'stats'] });
            setLastRefreshed(new Date());
        }, 30000);

        return () => clearInterval(interval);
    }, []);

    // ── Render ───────────────────────────────────────────────────────────────

    return (
        <AppLayout
            breadcrumbs={[
                { title: 'Home', href: '/dashboard' },
                { title: 'Control Room', href: '/control-room' },
                { title: 'Live Map', href: '/control-room/map' },
            ]}
        >
            <Head title="Live Map — Control Room" />

            {/* Inject pulse animation CSS */}
            <style dangerouslySetInnerHTML={{ __html: pulseStyle }} />

            <div className="w-full space-y-4 p-4">
                <CommandCentrePage
                    variant="compact"
                    current="/control-room/map"
                    icon={Map}
                    title="Live map"
                    description="Latest governed positions for personal safety, Fleet and asset trackers."
                    status="Governed location workspace"
                    freshness={`Updated ${formatTime(lastRefreshed)}`}
                    actions={
                        <Button
                            variant="outline"
                            size="sm"
                            onClick={manualRefresh}
                            className="frontline-tap border-primary-foreground/30 bg-primary-foreground/10 text-primary-foreground backdrop-blur-sm hover:bg-primary-foreground/20 hover:text-primary-foreground"
                        >
                            <RefreshCw className="mr-2 h-4 w-4" />
                            Refresh
                        </Button>
                    }
                >
                    <Card
                        className={
                            location_boundary.position_access
                                ? 'border-status-info/30 bg-status-info-bg/40'
                                : 'border-status-warning/30 bg-status-warning-bg/40'
                        }
                    >
                        <CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
                            <div className="flex min-w-0 items-start gap-3">
                                {location_boundary.position_access ? (
                                    <ShieldCheck className="mt-0.5 h-5 w-5 shrink-0 text-status-info" />
                                ) : (
                                    <ShieldAlert className="mt-0.5 h-5 w-5 shrink-0 text-status-warning" />
                                )}
                                <div className="min-w-0">
                                    <p className="text-sm font-semibold">
                                        {location_boundary.title}
                                    </p>
                                    <p className="mt-1 text-sm text-muted-foreground">
                                        {location_boundary.description}
                                    </p>
                                </div>
                            </div>
                            {location_boundary.canonical_url && (
                                <Button
                                    asChild
                                    variant="outline"
                                    size="sm"
                                    className="frontline-tap shrink-0"
                                >
                                    <Link
                                        href={location_boundary.canonical_url}
                                    >
                                        Open Tracking
                                    </Link>
                                </Button>
                            )}
                        </CardContent>
                    </Card>

                    {/* Stats Bar */}
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-5">
                        <Card>
                            <CardContent className="flex items-center gap-3 p-4">
                                <div className="rounded-lg bg-status-info-bg p-2">
                                    <Radio className="h-5 w-5 text-status-info" />
                                </div>
                                <div>
                                    <p className="text-xs text-muted-foreground">
                                        Positions available
                                    </p>
                                    <p className="text-2xl font-bold">
                                        {stats.total_devices}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardContent className="flex items-center gap-3 p-4">
                                <div className="rounded-lg bg-status-success-bg p-2">
                                    <Wifi className="h-5 w-5 text-status-success" />
                                </div>
                                <div>
                                    <p className="text-xs text-muted-foreground">
                                        Reporting
                                    </p>
                                    <p className="text-2xl font-bold text-status-success">
                                        {stats.online}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardContent className="flex items-center gap-3 p-4">
                                <div className="rounded-lg bg-status-critical-bg p-2">
                                    <WifiOff className="h-5 w-5 text-status-critical" />
                                </div>
                                <div>
                                    <p className="text-xs text-muted-foreground">
                                        Offline
                                    </p>
                                    <p className="text-2xl font-bold text-status-critical">
                                        {stats.offline}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardContent className="flex items-center gap-3 p-4">
                                <div className="rounded-lg bg-status-warning-bg p-2">
                                    <AlertTriangle className="h-5 w-5 text-status-warning" />
                                </div>
                                <div>
                                    <p className="text-xs text-muted-foreground">
                                        Active Alerts
                                    </p>
                                    <p className="text-2xl font-bold text-status-warning">
                                        {stats.active_alerts}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                        <Card>
                            <CardContent className="flex items-center gap-3 p-4">
                                <div className="rounded-lg bg-status-warning-bg p-2">
                                    <ShieldAlert className="h-5 w-5 text-status-warning" />
                                </div>
                                <div>
                                    <p className="text-xs text-muted-foreground">
                                        Location restricted
                                    </p>
                                    <p className="text-2xl font-bold text-status-warning">
                                        {stats.location_restricted}
                                    </p>
                                </div>
                            </CardContent>
                        </Card>
                    </div>

                    {/* Map + Sidebar Layout */}
                    <div className="flex flex-col gap-4 lg:flex-row">
                        {/* Sidebar Filters */}
                        <div className="w-full shrink-0 space-y-4 lg:w-64">
                            <Card>
                                <CardContent className="space-y-4 p-4">
                                    <h3 className="text-sm font-semibold">
                                        Filters
                                    </h3>

                                    <div className="space-y-1">
                                        <label className="text-xs text-muted-foreground">
                                            Site
                                        </label>
                                        <Select
                                            value={filters.site_id || 'all'}
                                            onValueChange={(v) =>
                                                applyFilter('site_id', v)
                                            }
                                        >
                                            <SelectTrigger className="frontline-tap w-full">
                                                <SelectValue placeholder="All sites" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="all">
                                                    All sites
                                                </SelectItem>
                                                {all_sites.map((s) => (
                                                    <SelectItem
                                                        key={s.id}
                                                        value={s.id.toString()}
                                                    >
                                                        {s.name}
                                                    </SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-xs text-muted-foreground">
                                            Device Type
                                        </label>
                                        <Select
                                            value={filters.type || 'all'}
                                            onValueChange={(v) =>
                                                applyFilter('type', v)
                                            }
                                        >
                                            <SelectTrigger className="frontline-tap w-full">
                                                <SelectValue placeholder="All Types" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="all">
                                                    All trackers
                                                </SelectItem>
                                                <SelectItem value="vehicle_tracker">
                                                    Fleet tracker
                                                </SelectItem>
                                                <SelectItem value="personal_tracker">
                                                    Personal safety tracker
                                                </SelectItem>
                                                <SelectItem value="asset_tracker">
                                                    Asset tracker
                                                </SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-xs text-muted-foreground">
                                            Status
                                        </label>
                                        <Select
                                            value={filters.status || 'all'}
                                            onValueChange={(v) =>
                                                applyFilter('status', v)
                                            }
                                        >
                                            <SelectTrigger className="frontline-tap w-full">
                                                <SelectValue placeholder="All Statuses" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="all">
                                                    All
                                                </SelectItem>
                                                <SelectItem value="online">
                                                    Online
                                                </SelectItem>
                                                <SelectItem value="offline">
                                                    Offline
                                                </SelectItem>
                                                <SelectItem value="unknown">
                                                    Status unknown
                                                </SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    <div className="space-y-1">
                                        <label className="text-xs text-muted-foreground">
                                            Alert Only
                                        </label>
                                        <Select
                                            value={filters.alert_only || '0'}
                                            onValueChange={(v) =>
                                                applyFilter('alert_only', v)
                                            }
                                        >
                                            <SelectTrigger className="frontline-tap w-full">
                                                <SelectValue placeholder="No" />
                                            </SelectTrigger>
                                            <SelectContent>
                                                <SelectItem value="0">
                                                    Show all
                                                </SelectItem>
                                                <SelectItem value="1">
                                                    Alerts Only
                                                </SelectItem>
                                            </SelectContent>
                                        </Select>
                                    </div>

                                    {hasFilters && (
                                        <Button
                                            variant="ghost"
                                            size="sm"
                                            className="frontline-tap w-full"
                                            onClick={clearFilters}
                                        >
                                            Clear filters
                                        </Button>
                                    )}
                                </CardContent>
                            </Card>

                            {/* Legend */}
                            <Card>
                                <CardContent className="space-y-2 p-4">
                                    <h3 className="text-sm font-semibold">
                                        Legend
                                    </h3>
                                    <div className="space-y-1.5 text-xs">
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block h-3 w-3 rounded-full bg-status-success" />
                                            <span>
                                                Fleet tracker — reporting
                                            </span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block h-3 w-3 rounded-full bg-status-info" />
                                            <span>
                                                Fleet tracker — recently updated
                                            </span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block h-3 w-3 rounded-full bg-status-critical" />
                                            <span>Tracker — offline</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block h-3 w-3 rounded-full bg-primary" />
                                            <span>Personal safety tracker</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block h-3 w-3 rounded-full bg-category-fleet" />
                                            <span>Asset tracker</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="inline-block h-3 w-3 rounded-full bg-status-warning" />
                                            <span>Site</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span className="relative inline-block h-3 w-3">
                                                <span className="absolute inset-0 animate-ping rounded-full bg-status-critical opacity-75" />
                                                <span className="inline-block h-3 w-3 rounded-full bg-status-critical" />
                                            </span>
                                            <span>Active Alert</span>
                                        </div>
                                        <div className="flex items-center gap-2">
                                            <span
                                                className="inline-block h-3 w-6 rounded border border-primary bg-primary/10 opacity-60"
                                                style={{
                                                    borderStyle: 'dashed',
                                                }}
                                            />
                                            <span>Geofence</span>
                                        </div>
                                    </div>
                                </CardContent>
                            </Card>

                            {/* Device List */}
                            <Card>
                                <CardContent className="p-4">
                                    <h3 className="mb-2 text-sm font-semibold">
                                        Governed positions ({devices.length})
                                    </h3>
                                    <div className="max-h-64 space-y-1 overflow-y-auto">
                                        {devices.length === 0 && (
                                            <p className="py-2 text-xs text-muted-foreground">
                                                No tracker positions are
                                                available under the current
                                                Site, source-permission and
                                                privacy rules.
                                            </p>
                                        )}
                                        {devices.map((d) => (
                                            <Button
                                                key={d.id}
                                                type="button"
                                                variant="ghost"
                                                className="frontline-tap h-auto w-full justify-start gap-2 rounded px-2 py-1.5 text-left text-xs"
                                                onClick={() => {
                                                    if (
                                                        mapInstanceRef.current
                                                    ) {
                                                        mapInstanceRef.current.setView(
                                                            [
                                                                d.latitude,
                                                                d.longitude,
                                                            ],
                                                            16,
                                                        );
                                                    }
                                                }}
                                            >
                                                <span
                                                    aria-hidden="true"
                                                    className={`inline-block h-2.5 w-2.5 shrink-0 rounded-full ${
                                                        d.type ===
                                                        'personal_tracker'
                                                            ? 'bg-primary'
                                                            : d.type ===
                                                                'asset_tracker'
                                                              ? 'bg-category-fleet'
                                                              : d.status ===
                                                                  'online'
                                                                ? isRecentlySeen(
                                                                      d.last_seen_at,
                                                                      5,
                                                                  )
                                                                    ? 'bg-status-info'
                                                                    : 'bg-status-success'
                                                                : 'bg-status-critical'
                                                    }`}
                                                />
                                                <span className="min-w-0 flex-1">
                                                    <span className="block truncate">
                                                        {d.name || d.device_uid}
                                                    </span>
                                                    <span className="block truncate text-[11px] text-muted-foreground">
                                                        {d.type_label} ·{' '}
                                                        {mapDeviceActivityLabel(
                                                            d,
                                                        )}
                                                    </span>
                                                </span>
                                                {d.battery_level !== null &&
                                                    d.battery_level <= 20 && (
                                                        <Badge
                                                            variant="destructive"
                                                            className="shrink-0 px-1 text-[10px]"
                                                        >
                                                            {d.battery_level}%
                                                        </Badge>
                                                    )}
                                            </Button>
                                        ))}
                                    </div>
                                </CardContent>
                            </Card>
                        </div>

                        {/* Map Container */}
                        <div className="flex-1">
                            <Card className="overflow-hidden">
                                <CardContent className="p-0">
                                    <div
                                        ref={mapRef}
                                        className="min-h-[600px] w-full lg:min-h-[700px]"
                                        style={{ zIndex: 0 }}
                                    />
                                </CardContent>
                            </Card>
                            <div className="mt-2 flex items-center justify-between text-xs text-muted-foreground">
                                <div className="flex items-center gap-1">
                                    <Activity className="h-3 w-3" />
                                    <span>
                                        Refreshes every 30 seconds · Last:{' '}
                                        {formatTime(lastRefreshed)}
                                    </span>
                                </div>
                                <div className="flex items-center gap-1">
                                    <MapPin className="h-3 w-3" />
                                    <span>
                                        {devices.length} governed positions,{' '}
                                        {sites.length} sites, {alerts.length}{' '}
                                        alerts
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                </CommandCentrePage>
            </div>
        </AppLayout>
    );
}
