<?php

// Read-only absence proof for the exact owned native namespace, before/after testing.
$base = 'oblivion_cr_delivery_test_priority_20261011';
$settings = [];
$config = simplexml_load_file(__DIR__.'/../../phpunit.xml');
foreach ($config->php->env as $value) {
    $settings[(string) $value['name']] = (string) $value['value'];
}
$read = static fn (string $key, string $default = ''): string => getenv($key) !== false
    ? (string) getenv($key) : ($settings[$key] ?? $default);
$connection = new PDO('mysql:host='.$read('DB_HOST', '127.0.0.1').';port='.$read('DB_PORT', '3306').';charset=utf8mb4',
    $read('DB_USERNAME'), $read('DB_PASSWORD'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
$pattern = '^'.preg_quote($base, '/').'(?:_[0-9]+)?$';
$schemas = $connection->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME REGEXP :pattern');
$schemas->execute(['pattern' => $pattern]);
$remaining = $schemas->fetchAll(PDO::FETCH_COLUMN);
$sessions = $connection->prepare('SELECT COUNT(*) FROM information_schema.PROCESSLIST WHERE DB REGEXP :pattern');
$sessions->execute(['pattern' => $pattern]);
$connections = (int) $sessions->fetchColumn();
$receipt = ['databaseBase' => $base, 'schemasRemaining' => $remaining, 'connectionsRemaining' => $connections,
    'phase' => $argv[2] ?? 'cleanup', 'readOnly' => true, 'complete' => $remaining === [] && $connections === 0];
file_put_contents($argv[1], json_encode($receipt, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
echo json_encode($receipt, JSON_THROW_ON_ERROR).PHP_EOL;
exit($receipt['complete'] ? 0 : 77);
