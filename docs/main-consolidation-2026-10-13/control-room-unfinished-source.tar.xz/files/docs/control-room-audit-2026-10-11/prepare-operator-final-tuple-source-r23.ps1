$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$mainRoot = 'C:\Users\steph\Herd\oblivionfindings'
$receiptRelative = 'docs/control-room-audit-2026-10-11'
$receiptRoot = Join-Path $taskRoot $receiptRelative
$phpPath = 'C:\Users\steph\.config\herd\bin\php84\php.exe'
$utf8 = [System.Text.UTF8Encoding]::new($false)
$changedPaths = @('app/Services/ControlRoom/ControlRoomAlertLifecycleService.php', 'tests/Feature/ControlRoom/ControlRoomOperatorRootNoteTest.php')
function Get-Pin([string] $path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
function Write-Receipt([string] $name, $value) { [IO.File]::WriteAllText((Join-Path $receiptRoot $name), ($value | ConvertTo-Json -Depth 50) + "`n", $utf8) }
$r22Path = Join-Path $receiptRoot 'hs-read-integration-source-candidate-r22.json'
$r22Hash = Get-Pin $r22Path
if ($r22Hash -ne 'CDCE6EEE69CB806C59314BC8C35EFEA07000452DD4E6B0A907D6BC8AF322EC0B') { throw 'R22 historical package changed.' }
$r22 = Get-Content -LiteralPath $r22Path -Raw | ConvertFrom-Json
$before = Get-Content -LiteralPath (Join-Path $receiptRoot 'operator-final-tuple-before-r23.json') -Raw | ConvertFrom-Json
foreach ($file in $before.files) {
    if ((Get-Pin $file.backup) -ne $file.sha256) { throw "R22 backup changed: $($file.path)" }
}
$unaffected = @()
$drift = @()
$allocatedPinEntries = 0
foreach ($section in @('selectedExactDependencies', 'composedOwnedFiles', 'preservedSharedFoundations', 'completeCrQueuedSuites', 'completeSharedNotificationQueuedSuites', 'sourceReceipts')) {
    foreach ($file in $r22.$section) {
        $expected = if ($file.currentSha256) { $file.currentSha256 } else { $file.sha256 }
        $actual = Get-Pin (Join-Path $taskRoot $file.path)
        if ($file.path -notin $changedPaths) {
            $unaffected += [pscustomobject]@{ section = $section; path = $file.path; expected = $expected; actual = $actual }
            if ($actual -ne $expected) { $drift += $file.path }
        } else {
            $allocatedPinEntries++
        }
    }
}
if ($unaffected.Count -ne 162 -or $allocatedPinEntries -ne 3 -or $drift.Count -ne 0) { throw 'Unexpected drift outside the two allocated R23 source files.' }
$lifecycleBefore = [IO.File]::ReadAllText($before.files[0].backup)
$lifecycleAfter = [IO.File]::ReadAllText((Join-Path $taskRoot $changedPaths[0]))
$outsidePattern = '(?ms)^    public function resolve\(.*?^    \}|^    public function appendOperatorNote\(.*?(?=^    public function cancelTask\()'
$outsideUnchanged = [regex]::Replace($lifecycleBefore, $outsidePattern, '') -ceq [regex]::Replace($lifecycleAfter, $outsidePattern, '')
$autoPattern = '(?ms)^    public function resolveAutomatically\(.*?^    \}'
$automaticUnchanged = [regex]::Match($lifecycleBefore, $autoPattern).Value -ceq [regex]::Match($lifecycleAfter, $autoPattern).Value
if (-not $outsideUnchanged -or -not $automaticUnchanged) { throw 'Unexpected change outside human operator writer/helper spans.' }
$testBefore = [IO.File]::ReadAllText($before.files[1].backup)
$testAfter = [IO.File]::ReadAllText((Join-Path $taskRoot $changedPaths[1]))
$testPattern = '(?ms)^    public function (test_[a-z0-9_]+)\(.*?^    \}'
$priorMethods = [regex]::Matches($testBefore, $testPattern)
$currentMethods = [regex]::Matches($testAfter, $testPattern)
$currentByName = @{}
foreach ($method in $currentMethods) { $currentByName[$method.Groups[1].Value] = $method.Value }
$changedPriorMethods = @()
foreach ($method in $priorMethods) {
    if ($currentByName[$method.Groups[1].Value] -cne $method.Value) { $changedPriorMethods += $method.Groups[1].Value }
}
if ($priorMethods.Count -ne 13 -or $currentMethods.Count -ne 20 -or $changedPriorMethods.Count -ne 0) { throw 'Prior whole-suite test declarations changed unexpectedly.' }
$checks = @()
Push-Location $taskRoot
try {
    foreach ($path in $changedPaths) {
        $input = Get-Pin (Join-Path $taskRoot $path)
        $syntaxOutput = & $phpPath -d memory_limit=64M -l (Join-Path $taskRoot $path) 2>&1
        $syntaxExit = $LASTEXITCODE
        $checks += [pscustomobject]@{ path = $path; before = $input; syntaxExit = $syntaxExit; syntaxOutput = ($syntaxOutput -join "`n") }
    }
    $styleOutput = & $phpPath -d memory_limit=128M vendor/bin/pint --test --format=json @changedPaths 2>&1
    $styleExit = $LASTEXITCODE
    $whitespaceOutput = & git diff --check 2>&1
    $whitespaceExit = $LASTEXITCODE
    $patchLines = @()
    foreach ($file in $before.files) {
        $diffLines = & git diff --no-index -- $file.backup (Join-Path $taskRoot $file.path)
        if ($LASTEXITCODE -ne 1) { throw "Expected one changed file in R23 diff: $($file.path)" }
        foreach ($line in $diffLines) {
            if ($line.StartsWith('diff --git ')) { $patchLines += "diff --git a/$($file.path) b/$($file.path)" }
            elseif ($line.StartsWith('--- ')) { $patchLines += "--- a/$($file.path)" }
            elseif ($line.StartsWith('+++ ')) { $patchLines += "+++ b/$($file.path)" }
            else { $patchLines += $line }
        }
    }
    $patchPath = Join-Path $receiptRoot 'operator-final-tuple-r23.patch'
    [IO.File]::WriteAllText($patchPath, ($patchLines -join "`n") + "`n", $utf8)
    $reverseOutput = & git apply --reverse --check -- $patchPath 2>&1
    $reverseExit = $LASTEXITCODE
} finally { Pop-Location }
$inputDrift = @()
foreach ($check in $checks) {
    $after = Get-Pin (Join-Path $taskRoot $check.path)
    $check | Add-Member -NotePropertyName after -NotePropertyValue $after
    if ($after -ne $check.before) { $inputDrift += $check.path }
}
$mainPins = @()
$oldChecks = Get-Content -LiteralPath (Join-Path $receiptRoot 'inbox-note-source-checks-r22.json') -Raw | ConvertFrom-Json
foreach ($pin in $oldChecks.mainPins) {
    $actual = Get-Pin (Join-Path $mainRoot $pin.path)
    $mainPins += [pscustomobject]@{ path = $pin.path; r22MainSha256 = $pin.mainAfterSha256; currentMainSha256 = $actual; unchangedSinceR22 = $actual -eq $pin.mainAfterSha256 }
}
$receipt = [ordered]@{
    kind = 'R23 two-file human operator writer source successor; no framework/database/native-input freeze'
    preparedAtUtc = [DateTime]::UtcNow.ToString('o')
    historicalR22PackageSha256 = $r22Hash
    changedPaths = $changedPaths
    syntaxMemory = '64M'; syntax = $checks; syntaxFailures = @($checks | Where-Object syntaxExit -ne 0).Count
    styleMemory = '128M'; styleExit = $styleExit; styleOutput = ($styleOutput -join "`n")
    inputDrift = $inputDrift; diffWhitespaceExit = $whitespaceExit; diffWhitespaceOutput = ($whitespaceOutput -join "`n")
    patchPath = "$receiptRelative/operator-final-tuple-r23.patch"; patchSha256 = Get-Pin $patchPath
    reverseApplyCheckExit = $reverseExit; reverseApplyCheckOutput = ($reverseOutput -join "`n")
    r22UnaffectedPinsBeforeMetadataRefresh = $unaffected; unaffectedCount = $unaffected.Count; unaffectedDrift = $drift
    changedPinEntries = $allocatedPinEntries; distinctChangedFiles = $changedPaths.Count
    automaticSourceResolutionSpanUnchanged = $automaticUnchanged; outsideHumanOperatorWriterHelpersUnchanged = $outsideUnchanged
    retainedTestDeclarations = $priorMethods.Count; changedPriorTestMethods = $changedPriorMethods; wholeOperatorTestDeclarations = $currentMethods.Count
    addedTestDeclarations = $currentMethods.Count - $priorMethods.Count
    authoredLateMutationProviderRows = 27; providerConsumers = 2; providerExecution = 'UNRUN; source-authored rows are not executed cases'
    mainSharedPinsReadOnly = $mainPins; mainWritten = $false
    finalVerification = 'Read-only raw alert/full context/note/audit verification after every normal note/alert/SLA/audit write; no subsequent normal write or retrieved-model callback'
    scope = 'Only human resolve, appendOperatorNote and their private integrity helpers; automatic/source writer and global AuditLogger unchanged'
    runtime = 'UNRUN'; frameworkBoot = $false; database = $false; node = $false; browser = $false; processProbe = $false; runtimeAdmissionChanged = $false
}
Write-Receipt 'operator-final-tuple-source-checks-r23.json' $receipt
if ($receipt.syntaxFailures -ne 0 -or $styleExit -ne 0 -or $inputDrift.Count -ne 0 -or $whitespaceExit -ne 0 -or $reverseExit -ne 0) { throw 'An allocated source check failed; inspect receipt before packaging.' }
[pscustomobject]@{ sourceReceiptSha256 = Get-Pin (Join-Path $receiptRoot 'operator-final-tuple-source-checks-r23.json'); patchSha256 = $receipt.patchSha256; syntaxFailures = $receipt.syntaxFailures; styleExit = $styleExit; whitespaceExit = $whitespaceExit; reverseCheck = $reverseExit; inputDrift = $inputDrift.Count; unaffectedPins = $unaffected.Count; unaffectedDrift = $drift.Count; outsideAllocatedSpansUnchanged = $outsideUnchanged; automaticSpanUnchanged = $automaticUnchanged; retainedDeclarations = $priorMethods.Count; wholeDeclarations = $currentMethods.Count; runtime = 'UNRUN' } | ConvertTo-Json
