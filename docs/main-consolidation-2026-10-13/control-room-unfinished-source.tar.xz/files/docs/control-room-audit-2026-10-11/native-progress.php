<?php

// One read-only diagnostic for the already-running process, never application data.
$pid = $argv[1] ?? '';
if (! ctype_digit($pid)) exit(2);
$settings = [];
$config = simplexml_load_file(__DIR__.'/../../phpunit.xml');
foreach ($config->php->env as $value) $settings[(string) $value['name']] = (string) $value['value'];
$read = static fn (string $key, string $default = ''): string => getenv($key) !== false
    ? (string) getenv($key) : ($settings[$key] ?? $default);
$connection = new PDO('mysql:host='.$read('DB_HOST', '127.0.0.1').';port='.$read('DB_PORT', '3306').';charset=utf8mb4',
    $read('DB_USERNAME'), $read('DB_PASSWORD'), [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_TIMEOUT => 3]);
$schemas = $connection->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME REGEXP :suffix');
$schemas->execute(['suffix' => '_'.$pid.'$']);
$activity = $connection->prepare('SELECT DB, COMMAND, TIME, STATE FROM information_schema.PROCESSLIST WHERE DB REGEXP :suffix');
$activity->execute(['suffix' => '_'.$pid.'$']);
echo json_encode(['pid' => (int) $pid, 'schemas' => $schemas->fetchAll(PDO::FETCH_COLUMN),
    'activity' => $activity->fetchAll(PDO::FETCH_ASSOC), 'readOnly' => true], JSON_THROW_ON_ERROR).PHP_EOL;
