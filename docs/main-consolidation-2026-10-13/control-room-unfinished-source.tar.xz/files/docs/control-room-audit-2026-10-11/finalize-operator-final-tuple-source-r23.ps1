$ErrorActionPreference = 'Stop'
$taskRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$receiptRelative = 'docs/control-room-audit-2026-10-11'
$receiptRoot = Join-Path $taskRoot $receiptRelative
$utf8 = [System.Text.UTF8Encoding]::new($false)
function Get-Pin([string] $path) { (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash }
function Write-Receipt([string] $name, $value) { [IO.File]::WriteAllText((Join-Path $receiptRoot $name), ($value | ConvertTo-Json -Depth 70) + "`n", $utf8) }
$r22Path = Join-Path $receiptRoot 'hs-read-integration-source-candidate-r22.json'
if ((Get-Pin $r22Path) -ne 'CDCE6EEE69CB806C59314BC8C35EFEA07000452DD4E6B0A907D6BC8AF322EC0B') { throw 'R22 package changed.' }
$package = Get-Content -LiteralPath $r22Path -Raw | ConvertFrom-Json
$checks = Get-Content -LiteralPath (Join-Path $receiptRoot 'operator-final-tuple-source-checks-r23.json') -Raw | ConvertFrom-Json
if ($checks.syntaxFailures -ne 0 -or $checks.styleExit -ne 0 -or $checks.inputDrift.Count -ne 0 -or $checks.diffWhitespaceExit -ne 0 -or $checks.reverseApplyCheckExit -ne 0) { throw 'R23 source checks are not clean.' }
foreach ($check in $checks.syntax) {
    if ((Get-Pin (Join-Path $taskRoot $check.path)) -ne $check.after) { throw "Checked source changed: $($check.path)" }
}
$r22Archives = [ordered]@{
    'DELIVERY-STATUS-r22.txt' = 'DCE58780249FB1F21706B759A45155381C525B8C30D67A21A33A88BEEE32C937'
    'HS-READ-INTEGRATION-SEAMS-r22.txt' = '164354E6BA55846ACBD7578979C858CFE0C1B910DF0D570ECB4E4451B99C02ED'
    'hs-read-integration-source-candidate-r22.json' = 'CDCE6EEE69CB806C59314BC8C35EFEA07000452DD4E6B0A907D6BC8AF322EC0B'
    'inbox-note-package-pin-check-r22.json' = '5A82DCF8DB4DC3EB66A843B76CE6F9FEC0359E0A38757162039E0A62B8491C96'
}
foreach ($entry in $r22Archives.GetEnumerator()) {
    if ((Get-Pin (Join-Path $receiptRoot $entry.Key)) -ne $entry.Value) { throw "R22 archive changed: $($entry.Key)" }
}
$dispatchArchive = Join-Path $receiptRoot 'coordinator-report-dispatch-r22.json'
if (-not (Test-Path -LiteralPath $dispatchArchive)) {
    $dispatchCurrent = Join-Path $receiptRoot 'coordinator-report-dispatch.json'
    if ((Get-Pin $dispatchCurrent) -ne 'EF125F3F83A522BC967B9BD510BF96BB039614F15A0AE19B2BA2CCAD548B10C2') { throw 'Unexpected current report receipt before R22 archive.' }
    Copy-Item -LiteralPath $dispatchCurrent -Destination $dispatchArchive
}
if ((Get-Pin $dispatchArchive) -ne 'EF125F3F83A522BC967B9BD510BF96BB039614F15A0AE19B2BA2CCAD548B10C2') { throw 'R22 dispatch archive changed.' }
$package.preparedAt = [DateTime]::UtcNow.ToString('o')
$package.kind = 'R23 narrow final operator-write source successor to reviewed R22; source-only semantic proposal, not runtime acceptance'
foreach ($check in $checks.syntax) {
    foreach ($file in $package.composedOwnedFiles | Where-Object path -eq $check.path) {
        $file | Add-Member -NotePropertyName r22Sha256 -NotePropertyValue $file.currentSha256 -Force
        $file.currentSha256 = $check.after
        $file.syntaxExit = $check.syntaxExit
        $file.native = 'UNRUN'
        $file | Add-Member -NotePropertyName latestSourceReceipt -NotePropertyValue "$receiptRelative/operator-final-tuple-source-checks-r23.json" -Force
    }
}
$wholeTest = $package.completeCrQueuedSuites | Where-Object path -eq $checks.changedPaths[1]
$wholeTest | Add-Member -NotePropertyName r22Sha256 -NotePropertyValue $wholeTest.sha256 -Force
$wholeTest.sha256 = $checks.syntax[1].after
$wholeTest.declaredMethods = $checks.wholeOperatorTestDeclarations
$wholeTest.runtime = 'UNRUN'
$wholeTest | Add-Member -NotePropertyName retainedDeclarations -NotePropertyValue 13 -Force
$wholeTest | Add-Member -NotePropertyName additiveDeclarations -NotePropertyValue 7 -Force
$wholeTest | Add-Member -NotePropertyName lateMutationProviderRows -NotePropertyValue 27 -Force
$wholeTest | Add-Member -NotePropertyName providerConsumers -NotePropertyValue 2 -Force
$wholeTest.kind = 'Complete file; source declarations/provider rows are not executed cases; prior13 test methods byte-exact retained'
$package | Add-Member -NotePropertyName historicalR22Execution -NotePropertyValue $package.execution -Force
$package.execution = [pscustomobject]@{
    syntaxFiles = 2; syntaxFailures = 0; styleFiles = 2; styleExit = 0; diffCheckExit = 0; sourceInputDrift = 0; patchReverseApplyCheckExit = 0
    sourceReceipt = "$receiptRelative/operator-final-tuple-source-checks-r23.json"
    previousReceipt = "$receiptRelative/inbox-note-source-checks-r22.json"
    retainedRecipientMethods = 26; retainedCurrentSourceMethods = 29; newNotificationMethods = 18; newOperatorMethods = 20; retainedOperatorMethods = 13; additiveOperatorMethods = 7
    sharedMyTasksStyle = 'Historical R22 same six pre-existing categories; unchanged source; not rerun in R23'
    sharedNotificationMainPatch = 'Historical R22 check; exact six-hunk proposal unchanged and unapplied'
    framework = 'UNRUN'; database = 'UNRUN'; migrations = 'UNRUN'; native = 'UNRUN'; node = 'UNRUN'; browser = 'UNRUN'; resourceOrProcessProbe = 'NONE'
    runtimeHold = 'Coordinator managed-host/classifier hold unchanged; no admission inferred'
}
$package | Add-Member -NotePropertyName allocatedFinalOperatorCheckpoint -NotePropertyValue $checks -Force
$package | Add-Member -NotePropertyName historicalR22Package -NotePropertyValue ([pscustomobject]@{ path = "$receiptRelative/hs-read-integration-source-candidate-r22.json"; sha256 = Get-Pin $r22Path; finalBeforeMetadataUnaffectedEntries = 162; allocatedEntries = 3; distinctChangedFiles = 2; drift = 0; archivedSeamsAndStatusExact = $true }) -Force
$package.newCompleteDeclaredMethods = 38
$package.completion = 'Narrow R23 operator writer source proposal ready for coordinator semantic review; all runtime/native/whole workflow acceptance pending; overall approved audit incomplete'
$package.consumingBoundaries[-1] = 'Persisted operator-root-note proof for display/search; human resolve/append final literal alert/context/note/audit verification after normal writes; automatic source-resolution span unchanged'
foreach ($file in $package.sourceReceipts) {
    if ($file.path -eq "$receiptRelative/HS-READ-INTEGRATION-SEAMS.txt") {
        $file | Add-Member -NotePropertyName r22Sha256 -NotePropertyValue $file.sha256 -Force
        $file.sha256 = Get-Pin (Join-Path $taskRoot $file.path)
    }
}
$newReceipts = @(
    'hs-read-integration-source-candidate-r22.json', 'HS-READ-INTEGRATION-SEAMS-r22.txt', 'DELIVERY-STATUS-r22.txt',
    'inbox-note-package-pin-check-r22.json', 'coordinator-report-dispatch-r22.json',
    'operator-final-tuple-before-r23.json', 'operator-final-tuple-style-r23.json', 'operator-final-tuple-source-checks-r23.json',
    'operator-final-tuple-r23.patch', 'prepare-operator-final-tuple-source-r23.ps1', 'finalize-operator-final-tuple-source-r23.ps1',
    'operator-final-tuple-before-files/app/Services/ControlRoom/ControlRoomAlertLifecycleService.php',
    'operator-final-tuple-before-files/tests/Feature/ControlRoom/ControlRoomOperatorRootNoteTest.php', 'DELIVERY-STATUS.txt'
)
foreach ($name in $newReceipts) {
    $relative = "$receiptRelative/$name"
    if (@($package.sourceReceipts | Where-Object path -eq $relative).Count -ne 0) { throw "Duplicate receipt: $relative" }
    $package.sourceReceipts += [pscustomobject]@{ path = $relative; sha256 = Get-Pin (Join-Path $taskRoot $relative) }
}
$counts = [ordered]@{}
$drift = @()
$compared = 0
foreach ($section in @('selectedExactDependencies', 'composedOwnedFiles', 'preservedSharedFoundations', 'completeCrQueuedSuites', 'completeSharedNotificationQueuedSuites', 'sourceReceipts')) {
    $counts[$section] = @($package.$section).Count
    foreach ($file in $package.$section) {
        $expected = if ($file.currentSha256) { $file.currentSha256 } else { $file.sha256 }
        $actual = Get-Pin (Join-Path $taskRoot $file.path)
        $compared++
        if ($expected -ne $actual) { $drift += [pscustomobject]@{ section = $section; path = $file.path; expected = $expected; actual = $actual } }
    }
}
if ($drift.Count -ne 0) { throw 'R23 package closure drift detected before publication.' }
Write-Receipt 'hs-read-integration-source-candidate.json' $package
Copy-Item -LiteralPath (Join-Path $receiptRoot 'hs-read-integration-source-candidate.json') -Destination (Join-Path $receiptRoot 'hs-read-integration-source-candidate-r23.json')
$packageHash = Get-Pin (Join-Path $receiptRoot 'hs-read-integration-source-candidate.json')
$pinReceipt = [ordered]@{
    kind = 'R23 exact source package pin comparison; no runtime/native-input freeze'
    checkedAtUtc = [DateTime]::UtcNow.ToString('o'); manifestSha256 = $packageHash; r23ArchiveSha256 = Get-Pin (Join-Path $receiptRoot 'hs-read-integration-source-candidate-r23.json')
    counts = $counts; compared = $compared; drift = $drift
    beforeMetadataR22UnaffectedEntries = 162; allocatedR22Entries = 3; distinctChangedFiles = 2
    sourceChecksSha256 = Get-Pin (Join-Path $receiptRoot 'operator-final-tuple-source-checks-r23.json')
    patchSha256 = Get-Pin (Join-Path $receiptRoot 'operator-final-tuple-r23.patch')
    seamsSha256 = Get-Pin (Join-Path $receiptRoot 'HS-READ-INTEGRATION-SEAMS.txt'); statusSha256 = Get-Pin (Join-Path $receiptRoot 'DELIVERY-STATUS.txt')
    historicalR22ArchivePins = $r22Archives; r22DispatchSha256 = Get-Pin $dispatchArchive
    runtime = 'UNRUN'; runtimeAdmissionChanged = $false; mainWritten = $false; overallAudit = 'INCOMPLETE'
}
Write-Receipt 'operator-final-tuple-package-pin-check-r23.json' $pinReceipt
[pscustomobject]@{ manifestSha256 = $packageHash; counts = $counts; compared = $compared; drift = $drift.Count; packagePinReceiptSha256 = Get-Pin (Join-Path $receiptRoot 'operator-final-tuple-package-pin-check-r23.json'); seamsSha256 = $pinReceipt.seamsSha256; statusSha256 = $pinReceipt.statusSha256; runtime = 'UNRUN'; overall = 'INCOMPLETE' } | ConvertTo-Json -Depth 5
