UNAPPLIED R44 — CR-COPY-ORIGIN-01 source correction, 13 October 2026 NZ

This successor preserves immutable R41 manifest 0BABF79888F40932CFE713FD78C23289637D828232B4936F0C9C45A94D4068D7 and its complete dependency/acceptance limits. Only the copied-note reader and whole native class change. The other three owned files are byte-exact; all canonical dependencies and source policies remain unchanged.

The copied branch now conjoins absence of root_note_origin on the ACTUAL Notes SELECT. Its final same-query exists clone retains that same condition. Discovery metadata alone is no longer sufficient when a competing operator-origin marker is added after discovery.

Two real native cases were added: a Query Builder JSON update injects conflict immediately before the actual Notes SELECT, asserting zero Notes model hydration plus blank CSV cell/retained operational row; a retrieved-model hook adds conflict after the permitted body read, asserting exactly one actual hydration followed by withheld final Notes/retained row. All original 18 methods/provider rows are byte-exact; whole successor has20 declarations, ALL UNRUN.

Exact inverse source proofs restore R41 reader after removing one conjunct and the whole R41 native class after removing only the two added methods. Read-only patch application and whitespace checks pass. One two-file standalone syntax admission held BEFORE child at1537MiB/CPU22/two heavy peers; zero compiled files, after-read complete. No grammar/SQL/native/privacy/performance/browser/workflow pass or writer activation. Product remains unchanged. Source review is pending; all R41 integration/all-reader/current-authority/dependency/runtime gates remain.

