<?php

namespace App\Services\ControlRoom;

use App\Models\AuditLog;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Services\CurrentAuthorizationReads;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\Incidents\IncidentIndependenceBindingSql;
use App\Services\Incidents\IncidentSavedCopyService;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Builder as QueryBuilder;

/** Own destination admission around the canonical incident field-copy predicate. Never infer a legacy origin. */
final class ControlRoomCopiedAlertNoteService
{
    public const ACTION = 'controlRoom.alert.sourceNoteCopied';
    public const ORIGIN_KEYS = ['copy_uuid', 'source_family', 'source_version', 'target_family', 'target_key', 'field'];
    public const TARGET_COLUMNS = ['id', 'site_id', 'client_id', 'asset_id', 'source', 'alert_type'];

    public function metadata(Builder $query): Builder
    {
        return $query->selectRaw(app(UserSiteAccessService::class)->alertEffectiveSiteExpression($query).' as note_effective_site_id')
            ->selectRaw("JSON_EXTRACT(control_room_alerts.context, '$.root_note_origin') as root_origin")
            ->selectRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.root_note_origin') as root_origin_present")
            ->selectRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.saved_incident_copy', '$.saved_incident_copy_audit_id') as copy_origin_present")
            ->selectRaw("JSON_EXTRACT(control_room_alerts.context, '$.saved_incident_copy') as copy_origin")
            ->selectRaw("JSON_EXTRACT(control_room_alerts.context, '$.saved_incident_copy_audit_id') as copy_audit_id")
            ->selectRaw($this->originFingerprint('root_note_origin').' as root_origin_fp')
            ->selectRaw($this->originFingerprint('saved_incident_copy').' as copy_origin_fp');
    }

    /** Scope is rebuilt by the actual owner inside the same prepared callback; it is not a source grant. */
    public function forExport(ControlRoomAlert $metadata, callable $independentScope, User $current,
        HealthSafetyReadContext $context, CurrentAuthorizationReads $reads, Builder $originalAuthority): array
    {
        $context->assertViewer($current);
        $unavailable = ['notes_access' => 'unavailable', 'notes' => null];
        $target = $this->target($metadata);
        $base = function () use ($independentScope, $target, $metadata, $reads, $originalAuthority): Builder {
            $query = $this->sameTarget($independentScope(), $target)->setEagerLoads([])->reorder();
            $query->whereRaw(app(UserSiteAccessService::class)->alertEffectiveSiteExpression($query).' <=> ?', [$metadata->getRawOriginal('note_effective_site_id')]);
            return $reads->query($query->whereIn('control_room_alerts.id',
                (clone $originalAuthority)->setEagerLoads([])->reorder()->select('control_room_alerts.id')));
        };
        $root = $this->decode($metadata->getRawOriginal('root_origin'));
        $origin = $this->decode($metadata->getRawOriginal('copy_origin'));
        // Conflicting source and operator ownership never becomes an independently certified note.
        if ((int) $metadata->getRawOriginal('root_origin_present') === 1) {
            if (! is_array($root) || (int) $metadata->getRawOriginal('copy_origin_present') === 1) { return $unavailable; }
            $query = app(ControlRoomOperatorRootNoteService::class)->applyVerifiedScope($base(), $context)
                ->whereRaw($this->originFingerprint('root_note_origin').' = ?', [$metadata->getRawOriginal('root_origin_fp')])
                ->whereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.saved_incident_copy', '$.saved_incident_copy_audit_id') = 0");
            $row = $reads->query($query)->first(['control_room_alerts.id', 'control_room_alerts.notes']);
            if ($row === null || ! is_string($row->getRawOriginal('notes'))) { return $unavailable; }
            $text = $row->getRawOriginal('notes');
            if (! $reads->query((clone $query)->whereRaw('BINARY control_room_alerts.notes = BINARY ?', [$text]))->exists()) {
                return $unavailable;
            }
            return ['notes_access' => 'readable', 'notes' => $text];
        }
        if (! $this->validOrigin($origin, (int) $metadata->id)) { return $unavailable; }
        $auditId = $this->decode($metadata->getRawOriginal('copy_audit_id'));
        if (! is_int($auditId) || $auditId < 1) { return $unavailable; }
        // Identity/receipt metadata only. Neither query selects root notes or a source narrative.
        $receipt = $reads->query(AuditLog::query()->whereKey($auditId))
            ->select(['id', 'user_id', 'action', 'auditable_type', 'auditable_id', 'meta'])
            ->selectRaw(IncidentIndependenceBindingSql::fingerprint('audit', 'audit_logs').' as receipt_fp')->first();
        if ($receipt === null || $receipt->action !== self::ACTION || $receipt->auditable_type !== $metadata->getMorphClass()
            || (int) $receipt->auditable_id !== (int) $metadata->id || (int) $receipt->user_id < 1
            || ! $this->same($receipt->meta['origin'] ?? null, $origin)
            || ! $this->same($receipt->meta['target'] ?? null, $target)
            || count($receipt->meta) !== 4 || ! array_key_exists('actor_id', $receipt->meta)
            || $receipt->meta['actor_id'] !== (int) $receipt->user_id
            || ! is_string($receipt->meta['text_sha256'] ?? null)
            || preg_match('/\A[a-f0-9]{64}\z/D', $receipt->meta['text_sha256']) !== 1) { return $unavailable; }
        $receiptFingerprint = $receipt->getRawOriginal('receipt_fp');
        $textDigest = $receipt->meta['text_sha256'];
        $actorId = (int) $receipt->user_id;
        $result = app(IncidentSavedCopyService::class)->consumeProjectedCopy($context, $origin,
            function (array $copy, CurrentAuthorizationReads $sameReads, Builder $protectedCopy)
                use ($base, $origin, $target, $metadata, $auditId, $receiptFingerprint, $textDigest, $actorId, $unavailable): array {
                if (! hash_equals($textDigest, hash('sha256', $copy['text']))) { return $unavailable; }
                $protectedCopy = $this->correlateSource($protectedCopy, $target);
                $query = $base()->whereRaw($this->originFingerprint('saved_incident_copy').' = ?', [$metadata->getRawOriginal('copy_origin_fp')])
                    ->whereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.root_note_origin') = 0")
                    ->where('control_room_alerts.context->saved_incident_copy_audit_id', $auditId)
                    ->whereRaw('BINARY control_room_alerts.notes = BINARY ?', [$copy['text']])
                    ->whereExists((clone $protectedCopy)->reorder()->select('incident_saved_copies.id')->toBase())
                    ->whereExists(fn (QueryBuilder $audit) => $audit->selectRaw('1')->from('audit_logs as accepted_note_audit')
                        ->where('accepted_note_audit.id', $auditId)
                        ->whereRaw(IncidentIndependenceBindingSql::fingerprint('audit', 'accepted_note_audit').' = ?', [$receiptFingerprint]))
                    ->whereNotExists(fn (QueryBuilder $other) => $other->selectRaw('1')->from('audit_logs as other_note_claim')
                        ->where('other_note_claim.meta->origin->copy_uuid', $origin['copy_uuid'])->where('other_note_claim.id', '!=', $auditId))
                    ->whereExists(fn (QueryBuilder $actor) => $actor->selectRaw('1')->from('users as note_copy_actor')->where('note_copy_actor.id', $actorId));
                // Supplied source proof is on this ACTUAL destination SELECT through the SAME reads.
                $row = $sameReads->query($query)->first(['control_room_alerts.id', 'control_room_alerts.notes']);
                if ($row === null || $row->getRawOriginal('notes') !== $copy['text']
                    || ! $sameReads->query(clone $query)->exists()) { return $unavailable; }
                return ['notes_access' => 'readable', 'notes' => $copy['text']];
            });

        return $result['available'] ? $result['result'] : $unavailable;
    }

    public function target(ControlRoomAlert $metadata): array
    {
        $target = [];
        foreach (self::TARGET_COLUMNS as $column) {
            $value = $metadata->getRawOriginal($column);
            $target[$column] = $value === null ? null : (in_array($column, ['source', 'alert_type'], true) ? $value : (int) $value);
        }
        return $target;
    }

    public function sameTarget(Builder $query, array $target): Builder
    {
        foreach (self::TARGET_COLUMNS as $column) {
            $value = $target[$column];
            if ($value === null) { $query->whereNull('control_room_alerts.'.$column); }
            elseif (is_string($value)) { $query->whereRaw('BINARY control_room_alerts.'.$column.' = BINARY ?', [$value]); }
            else { $query->where('control_room_alerts.'.$column, $value); }
        }
        return $query;
    }

    /** Compare the accepted source tuple with the ORIGINAL destination tuple; never infer origin from a current FK. */
    public function correlateSource(Builder $protectedCopy, array $target): Builder
    {
        foreach (['site_id', 'client_id'] as $column) {
            $target[$column] === null
                ? $protectedCopy->whereNull('incident_saved_copies.source_tuple->'.$column)
                : $protectedCopy->where('incident_saved_copies.source_tuple->'.$column, $target[$column]);
        }
        return $protectedCopy;
    }

    public function validOrigin(mixed $origin, int $alertId): bool
    {
        return is_array($origin) && count($origin) === count(self::ORIGIN_KEYS)
            && array_diff(self::ORIGIN_KEYS, array_keys($origin)) === []
            && ($origin['source_family'] ?? null) === 'client_incident'
            && ($origin['target_family'] ?? null) === IncidentSavedCopyService::ALERT_NOTES_TARGET
            && ($origin['target_key'] ?? null) === (string) $alertId;
    }

    public function same(mixed $left, mixed $right): bool
    {
        return $this->canonical($left) === $this->canonical($right);
    }

    private function canonical(mixed $value): mixed
    {
        if (! is_array($value)) { return $value; }
        if (! array_is_list($value)) { ksort($value); }
        foreach ($value as $key => $nested) { $value[$key] = $this->canonical($nested); }
        return $value;
    }

    private function decode(mixed $value): mixed
    {
        return is_string($value) ? json_decode($value, true) : null;
    }

    private function originFingerprint(string $key): string
    {
        return "SHA2(CAST(JSON_EXTRACT(control_room_alerts.context, '$.".$key."') AS CHAR CHARACTER SET utf8mb4), 256)";
    }
}
