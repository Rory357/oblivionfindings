$ErrorActionPreference = 'Stop'
$crRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$crDocs = Join-Path $crRoot 'docs/control-room-audit-2026-10-11'
$crBefore = Join-Path $crDocs 'accepted-note-before-r29'
$crReceipt = Join-Path $crDocs 'accepted-note-source-increment-r29.json'
$crUtf8 = [Text.UTF8Encoding]::new($false)
if (Test-Path -LiteralPath $crReceipt) { throw 'Preserve earlier source receipt.' }
function Get-CrHash([string] $Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Get-CrTextHash([string] $Value) { [Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($crUtf8.GetBytes($Value))) }
function Read-CrSource([string] $Path) { [IO.File]::ReadAllText($Path) }
function Get-CrMethodSpan([string] $Text, [string] $Name) {
    $pattern = '(?ms)^    (?:public|private|protected) function ' + [regex]::Escape($Name) + '\(.*?(?=^    (?:public|private|protected) function |\z)'
    $matches = [regex]::Matches($Text, $pattern)
    if ($matches.Count -ne 1) { throw "Method span ambiguous: $Name" }
    $matches[0].Value
}
$crProductPaths = @(
    'database/migrations/2026_10_12_230000_add_control_room_operator_note_origin.php',
    'app/Models/ControlRoom/OperatorNote.php',
    'app/Services/ControlRoom/ControlRoomOperatorNoteOriginService.php',
    'app/Services/ControlRoom/ControlRoomAcceptedHandoverNoteService.php',
    'app/Services/ControlRoom/ControlRoomAlertLifecycleService.php',
    'app/Services/ControlRoom/ControlRoomShiftHandoverService.php',
    'app/Services/ControlRoom/ControlRoomPreparedHandoverSnapshotService.php',
    'app/Http/Controllers/ControlRoom/ControlRoomShiftController.php',
    'app/Http/Controllers/ControlRoom/ControlRoomHandoverController.php',
    'resources/js/pages/control-room/shifts/handover.tsx',
    'resources/js/pages/control-room/shifts/accepted-handover-history.tsx',
    'resources/js/pages/control-room/shifts/handover.test.tsx',
    'tests/Feature/ControlRoom/ControlRoomAcceptedHandoverHistoryTest.php',
    'tests/Feature/ControlRoom/ControlRoomOperatorRootNoteTest.php'
)
$crPins = @($crProductPaths | ForEach-Object {
    $beforePath = Join-Path $crBefore $_
    @{ path = $_; sha256 = Get-CrHash (Join-Path $crRoot $_); beforeSha256 = $(if (Test-Path -LiteralPath $beforePath) { Get-CrHash $beforePath } else { $null }) }
})
$crOriginalPins = Get-Content -LiteralPath (Join-Path $crDocs 'accepted-note-before-r29.json') -Raw | ConvertFrom-Json
foreach ($pin in $crOriginalPins) { if ((Get-CrHash (Join-Path $crBefore $pin.path)) -ne $pin.sha256) { throw 'Historical source image changed.' } }
$crShiftPath = 'app/Services/ControlRoom/ControlRoomShiftHandoverService.php'
$crShiftBefore = Read-CrSource (Join-Path $crBefore $crShiftPath)
$crShiftCurrent = Read-CrSource (Join-Path $crRoot $crShiftPath)
$crAcceptBefore = Get-CrMethodSpan $crShiftBefore 'accept'
$crAcceptCurrent = Get-CrMethodSpan $crShiftCurrent 'accept'
$crShiftRestored = [regex]::Replace($crShiftCurrent, "(?m)^ {16}'(purpose|operator_origin)' => [^\r\n]+\r?\n", '')
$crValidatorPath = 'app/Services/ControlRoom/ControlRoomPreparedHandoverSnapshotService.php'
$crValidatorBefore = Read-CrSource (Join-Path $crBefore $crValidatorPath)
$crValidatorCurrent = Read-CrSource (Join-Path $crRoot $crValidatorPath)
$crNotesBefore = Get-CrMethodSpan $crValidatorBefore 'notes'
$crNotesCurrent = Get-CrMethodSpan $crValidatorCurrent 'notes'
$crValidatorRestored = $crValidatorCurrent.Replace($crNotesCurrent, $crNotesBefore)
$crLifecyclePath = 'app/Services/ControlRoom/ControlRoomAlertLifecycleService.php'
$crAutoBefore = Get-CrMethodSpan (Read-CrSource (Join-Path $crBefore $crLifecyclePath)) 'resolveAutomatically'
$crAutoCurrent = Get-CrMethodSpan (Read-CrSource (Join-Path $crRoot $crLifecyclePath)) 'resolveAutomatically'
$crHistoryTest = Read-CrSource (Join-Path $crRoot 'tests/Feature/ControlRoom/ControlRoomAcceptedHandoverHistoryTest.php')
$crDeclared = [regex]::Matches($crHistoryTest, '(?m)^    public function test_').Count
if ($crDeclared -ne 19) { throw 'History-test inventory changed.' }
$crProofs = [ordered]@{
    acceptanceCommandSpanByteExact = $crAcceptBefore -ceq $crAcceptCurrent
    acceptanceSpanSha256 = Get-CrTextHash $crAcceptCurrent
    handoverServiceOtherThanTwoSavedNoteFieldsByteExact = $crShiftRestored -ceq $crShiftBefore
    handoverBeforeSha256 = Get-CrHash (Join-Path $crBefore $crShiftPath)
    preparedValidatorOutsideNotesMethodByteExact = $crValidatorRestored -ceq $crValidatorBefore
    preparedValidatorBeforeSha256 = Get-CrHash (Join-Path $crBefore $crValidatorPath)
    automaticResolveSpanByteExact = $crAutoBefore -ceq $crAutoCurrent
    automaticResolveSpanSha256 = Get-CrTextHash $crAutoCurrent
    historicalBeforePinsMatched = $crOriginalPins.Count
    trackedWhitespaceCheckExit = 0
}
foreach ($key in @('acceptanceCommandSpanByteExact', 'handoverServiceOtherThanTwoSavedNoteFieldsByteExact', 'preparedValidatorOutsideNotesMethodByteExact', 'automaticResolveSpanByteExact')) {
    if (!$crProofs[$key]) { throw "Unexpected command delta: $key" }
}
$crEvidencePaths = @(
    'docs/control-room-audit-2026-10-11/accepted-note-before-r29.json',
    'docs/control-room-audit-2026-10-11/run-note-syntax-r29.ps1',
    'docs/control-room-audit-2026-10-11/accepted-note-syntax-r29-inputs.json',
    'docs/control-room-audit-2026-10-11/accepted-note-syntax-r29-result.json',
    'docs/control-room-audit-2026-10-11/owned-frontend-inputs-r30.json',
    'docs/control-room-audit-2026-10-11/owned-frontend-r30.vitest.config.ts',
    'docs/control-room-audit-2026-10-11/run-owned-frontend-r30.ps1',
    'test-results/control-room-owned-component-a-r30-20261012/result.json',
    'docs/control-room-audit-2026-10-11/package-note-source-r29.ps1'
)
$crComponent = Get-Content -LiteralPath (Join-Path $crRoot 'test-results/control-room-owned-component-a-r30-20261012/result.json') -Raw | ConvertFrom-Json
$crSyntax = Get-Content -LiteralPath (Join-Path $crDocs 'accepted-note-syntax-r29-result.json') -Raw | ConvertFrom-Json
$crPayload = [ordered]@{
    atUtc = [DateTime]::UtcNow.ToString('o'); revision = 'R29 copied-note source correction; R30 finite component image'
    candidate = $crRoot; branch = 'codex/control-room-delivery'; base = 'ce50e22f5b5b85fdd1bf42a8401ec31015deae80'
    status = 'CANDIDATE_SOURCE_ONLY; coordinator independent review and runtime acceptance pending'
    precedingFinding = 'R26 gated only required-alert Site/person tuples. note_alert_ids could release old pinned/follow-up text after reassociation or source withdrawal. R26 was not source-cleared.'
    productPins = $crPins; commandProofs = $crProofs
    provenance = @{
        newIndependentOperatorNotes = 'Captured before normal writes/callbacks: literal alert/duty/Site/person/actor/type/purpose/text digest. Mandatory creation audit and final raw persisted tuple are checked in the note transaction.'
        legacy = 'Nullable origin, no migration backfill or present-context inference. Missing/unknown/source-owned origin withheld.'
        readAdmission = 'Persisted saved copy, actual note/actor/audit, immutable origin and current canonical alert scope must match. Read only; no replacement with current content. Source-owned copies require the H&S owner seam.'
        output = 'Required/carry work retains its gate. Note-only denial withholds only notes; both transported collections are filtered. Unique verified notes drive Notes total and body, no raw fallback. Origin and raw note_alert_ids removed.'
        schema = 'Nullable JSON operator_origin on existing CR operator-note table. Migration SOURCE ONLY, UNAPPLIED.'
    }
    authoredTests = @{
        nativeHistoryWholeFileDeclarations = 19; invalidHistoryRows = 13; noteReassociationRows = 6; privateCopyCollectionRows = 3
        prospectiveHistoryCases = 38; nativeHistoryRun = $false
        nativeOperatorRootDeclarations = 20; lateMutationRowsPerProvider = 28; nativeOperatorRootRun = $false
        frontendHandoverWholeFileCases = 7; finiteQueueWholeFiles = 6; finiteQueueAuthoredCases = 31
        cases = 'Actual persisted notes and HTTP draft/prepare/accept; pinned/follow-up/both Site/person reassociation; private withdrawal/unknown origin; safe independent positive; Site withdrawal; missing origin; changed text; conflicting duplicate copies; no GET command writes; late audit origin rollback; frontend unavailable count/body parity and no raw fallback.'
    }
    actualChecks = @{
        component = @{ state = $crComponent.state; childStarted = $crComponent.started; issue = $crComponent.issue; actualCounts = $crComponent.actualTestTotal; afterReadComplete = $crComponent.afterReadComplete; freeMiB = $crComponent.resources[0].freeMiB; cpuPercent = $crComponent.resources[0].cpuPercent; heavyPeerCount = @($crComponent.resources[0].heavyPeerIds).Count }
        syntax = @{ state = $crSyntax.state; childrenStarted = $crSyntax.compilerChildrenStarted; issue = $crSyntax.issue; filesChecked = @($crSyntax.syntax).Count; afterReadComplete = $crSyntax.afterReadComplete; freeMiB = $crSyntax.resources[0].freeMiB; cpuPercent = $crSyntax.resources[0].cpuPercent; heavyPeerCount = @($crSyntax.resources[0].heavyPeerIds).Count }
        formattingLintTypeNativeDatabaseBuildBrowser = 'UNRUN'; applicationMigrationExecuted = $false; runtimePassClaim = $false
    }
    hsOwnedSeamRequest = @{
        owner = 'H&S canonical source/policy owner, coordinated through Audit control room workflows'
        proposedInput = 'Immutable canonical source family/record/version, original Site/person/actor ownership and copy provenance; current viewer and canonical read context.'
        proposedOutput = 'Canonical current source/policy admission plus safe saved-copy DTO or unavailable decision. No current association backfill, role grants or competing CR source predicate.'
        absentSeamBehaviour = 'Source-owned/unknown copied notes remain unavailable; verified independent CR operator text may remain readable in its unchanged admitted context.'
    }
    evidencePins = @($crEvidencePaths | ForEach-Object { @{ path = $_; sha256 = Get-CrHash (Join-Path $crRoot $_) } })
    overallAudit = 'INCOMPLETE'; mainApplicationChanges = $false; stagedCommittedPushed = $false; integratedDeployed = $false
}
[IO.File]::WriteAllText($crReceipt, ($crPayload | ConvertTo-Json -Depth 18) + "`n", $crUtf8)
[pscustomobject]@{ receiptSha256 = Get-CrHash $crReceipt; productCount = $crPins.Count; proofs = $crProofs; componentStarted = $crComponent.started; syntaxChildren = $crSyntax.compilerChildrenStarted } | ConvertTo-Json -Depth 4
