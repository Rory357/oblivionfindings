$ErrorActionPreference = 'Stop'
$taskRoot = 'C:/Users/steph/.codex/worktrees/control-room-delivery/oblivionfindings'
$taskMain = 'C:/Users/steph/Herd/oblivionfindings'
$taskDir = "$taskRoot/docs/control-room-audit-2026-10-11"
$taskPhp = 'C:/Users/steph/.config/herd/bin/php84/php.exe'
$taskOwned = @(
    'app/Services/ControlRoom/ControlRoomDatabaseNotificationAccessService.php',
    'app/Services/ControlRoom/ControlRoomOperatorRootNoteService.php',
    'app/Services/ControlRoom/ControlRoomAlertLifecycleService.php',
    'app/Services/ControlRoom/ControlRoomSourceContentService.php',
    'app/Services/ControlRoom/ControlRoomGovernanceReadService.php',
    'tests/Feature/ControlRoom/ControlRoomDatabaseNotificationReadTest.php',
    'tests/Feature/ControlRoom/ControlRoomOperatorRootNoteTest.php'
)
$taskShared = @(
    'app/Http/Controllers/MyTasksController.php',
    'app/Http/Controllers/NotificationInboxController.php',
    'app/Http/Controllers/Portal/PortalNotificationController.php',
    'app/Http/Middleware/HandleInertiaRequests.php',
    'routes/portal.php',
    'app/Console/Commands/EscalatePendingNotifications.php'
)
function Get-TaskHash([string] $taskPath) { (Get-FileHash -LiteralPath $taskPath -Algorithm SHA256).Hash }
function Write-TaskJson([string] $taskPath, $taskValue) {
    [System.IO.File]::WriteAllText($taskPath, ($taskValue | ConvertTo-Json -Depth 18), [System.Text.UTF8Encoding]::new($false))
}
$taskSyntax = @(foreach ($taskPath in ($taskOwned + $taskShared)) {
    $taskFull = Join-Path $taskRoot $taskPath
    $taskBefore = Get-TaskHash $taskFull
    $taskOutput = & $taskPhp -d memory_limit=64M -l $taskFull 2>&1
    [pscustomobject]@{path=$taskPath; before=$taskBefore; after=(Get-TaskHash $taskFull); exit=$LASTEXITCODE; output=($taskOutput | Out-String).Trim()}
})
$taskCleanStyle = $taskOwned + @($taskShared | Where-Object { $_ -ne 'app/Http/Controllers/MyTasksController.php' })
$taskStyle = & $taskPhp -d memory_limit=128M "$taskRoot/vendor/bin/pint" --test @taskCleanStyle --format=json 2>&1
$taskStyleExit = $LASTEXITCODE
$taskBaseline = & $taskPhp -d memory_limit=128M "$taskRoot/vendor/bin/pint" --test "$taskDir/inbox-note-before-files/app/Http/Controllers/MyTasksController.php" --format=json 2>&1
$taskBaselineExit = $LASTEXITCODE
$taskMyTasks = & $taskPhp -d memory_limit=128M "$taskRoot/vendor/bin/pint" --test app/Http/Controllers/MyTasksController.php --format=json 2>&1
$taskMyTasksExit = $LASTEXITCODE
$taskBaselineCategories = (($taskBaseline | Out-String) | ConvertFrom-Json).files[0].fixers
$taskCurrentCategories = (($taskMyTasks | Out-String) | ConvertFrom-Json).files[0].fixers
$taskStyleDrift = @(Compare-Object $taskBaselineCategories $taskCurrentCategories)

$taskPatchLines = @()
$taskMainPins = @(foreach ($taskPath in $taskShared) {
    $taskBefore = "$taskDir/inbox-note-before-files/$taskPath"
    $taskCurrent = "$taskRoot/$taskPath"
    $taskDelta = & git diff --no-index -- $taskBefore $taskCurrent 2>&1
    if ($LASTEXITCODE -gt 1) { throw "Cannot prepare narrow source delta: $taskPath" }
    $taskPatchLines += @($taskDelta | ForEach-Object { ([string] $_).Replace($taskBefore, $taskPath).Replace($taskCurrent, $taskPath) })
    [pscustomobject]@{path=$taskPath; mainBeforeSha256=(Get-TaskHash (Join-Path $taskMain $taskPath)); candidateBeforeSha256=(Get-TaskHash $taskBefore); candidateSha256=(Get-TaskHash $taskCurrent)}
})
$taskPatchPath = "$taskDir/inbox-note-main-integration.patch"
[System.IO.File]::WriteAllText($taskPatchPath, (($taskPatchLines -join "`n") + "`n"), [System.Text.UTF8Encoding]::new($false))
$taskApplyOutput = & git -C $taskMain apply --check -- $taskPatchPath 2>&1
$taskApplyExit = $LASTEXITCODE
foreach ($taskPin in $taskMainPins) {
    $taskPin | Add-Member mainAfterSha256 (Get-TaskHash (Join-Path $taskMain $taskPin.path))
}
$taskAutoBefore = Get-Content -LiteralPath "$taskDir/inbox-note-before-files/app/Services/ControlRoom/ControlRoomAlertLifecycleService.php" -Raw
$taskAutoAfter = Get-Content -LiteralPath "$taskRoot/app/Services/ControlRoom/ControlRoomAlertLifecycleService.php" -Raw
function Get-TaskAutomaticSpan([string] $taskText) {
    $taskStart = $taskText.IndexOf('    public function resolveAutomatically(')
    $taskEnd = $taskText.IndexOf('    public function appendOperatorNote(', $taskStart)
    if ($taskStart -lt 0 -or $taskEnd -lt 0) { throw 'Missing automatic-resolution source span.' }
    $taskText.Substring($taskStart, $taskEnd - $taskStart)
}
$taskAutomaticUnchanged = (Get-TaskAutomaticSpan $taskAutoBefore) -ceq (Get-TaskAutomaticSpan $taskAutoAfter)
$taskWhitespace = & git -C $taskRoot diff --check 2>&1
$taskWhitespaceExit = $LASTEXITCODE
$taskReceipt = [pscustomobject]@{
    kind='R22 allocated notification/operator PHP source checks only; not a runtime/native-input freeze'
    preparedAt=(Get-Date).ToUniversalTime().ToString('o')
    syntaxMemory='64M'; syntax=$taskSyntax; styleMemory='128M'; cleanStylePaths=$taskCleanStyle; styleExit=$taskStyleExit; styleOutput=($taskStyle | Out-String).Trim()
    sharedMyTasksBaselineExit=$taskBaselineExit; sharedMyTasksCurrentExit=$taskMyTasksExit; unchangedBaselineStyleCategories=$taskBaselineCategories; styleCategoryDrift=$taskStyleDrift
    mainPatchPath='docs/control-room-audit-2026-10-11/inbox-note-main-integration.patch'; mainPatchSha256=(Get-TaskHash $taskPatchPath)
    mainApplyCheckExit=$taskApplyExit; mainApplyCheckOutput=($taskApplyOutput | Out-String).Trim(); mainPins=$taskMainPins; mainWritten=$false
    automaticSourceResolutionSpanUnchanged=$taskAutomaticUnchanged; diffWhitespaceExit=$taskWhitespaceExit; diffWhitespaceOutput=($taskWhitespace | Out-String).Trim()
    runtime='UNRUN'; frameworkBoot=$false; database=$false; node=$false; browser=$false; processProbe=$false; runtimeAdmissionChanged=$false
}
Write-TaskJson "$taskDir/inbox-note-source-checks-r22.json" $taskReceipt
if (@($taskSyntax | Where-Object { $_.exit -ne 0 -or $_.before -ne $_.after }).Count -or $taskStyleExit -ne 0 -or $taskStyleDrift.Count -or $taskApplyExit -ne 0 -or -not $taskAutomaticUnchanged -or $taskWhitespaceExit -ne 0 -or @($taskMainPins | Where-Object { $_.mainBeforeSha256 -ne $_.mainAfterSha256 }).Count) { throw 'The R22 source checkpoint failed; inspect the preserved receipt.' }

$taskManifest = Get-Content -LiteralPath "$taskDir/hs-read-integration-source-candidate-r21.json" -Raw | ConvertFrom-Json
$taskManifest.preparedAt = $taskReceipt.preparedAt
$taskManifest.kind = 'CR R22 allocated notification and operator-root-note candidate; shared/main proposal only; no combined privacy/runtime acceptance'
foreach ($taskEntry in $taskManifest.composedOwnedFiles) { $taskEntry.currentSha256 = Get-TaskHash (Join-Path $taskRoot $taskEntry.path) }
$taskBeforePins = Get-Content -LiteralPath "$taskDir/inbox-note-before.json" -Raw | ConvertFrom-Json
$taskNewPaths = @($taskOwned + $taskShared | Where-Object { $_ -notin $taskManifest.composedOwnedFiles.path })
$taskManifest.composedOwnedFiles = @($taskManifest.composedOwnedFiles) + @(foreach ($taskPath in $taskNewPaths) {
    $taskBeforePin = @($taskBeforePins | Where-Object path -eq $taskPath)[0]
    [pscustomobject]@{path=$taskPath; mode=$(if ($taskPath -in $taskShared) {'minimal_shared_integration_candidate'} else {'allocated_cr_operator_notification_source'}); beforeSha256=$taskBeforePin.sha256; currentSha256=(Get-TaskHash (Join-Path $taskRoot $taskPath)); backup=$taskBeforePin.beforeBackup; syntaxExit=0; native='UNRUN'}
})
foreach ($taskEntry in $taskManifest.completeCrQueuedSuites) { $taskEntry.sha256 = Get-TaskHash (Join-Path $taskRoot $taskEntry.path) }
$taskManifest.completeCrQueuedSuites = @($taskManifest.completeCrQueuedSuites) + @(foreach ($taskPath in ($taskOwned | Where-Object { $_.StartsWith('tests/') })) {
    [pscustomobject]@{path=$taskPath; sha256=(Get-TaskHash (Join-Path $taskRoot $taskPath)); declaredMethods=[regex]::Matches((Get-Content -LiteralPath (Join-Path $taskRoot $taskPath) -Raw), 'public function test_').Count; runtime='UNRUN'; kind='Complete file; declarations are not executed runtime cases'}
})
$taskAffectedSuites = @('tests/Feature/MyDayNotificationsDigestTest.php','tests/Feature/Emar/MedicationNotificationPrivacyTest.php','tests/Feature/Governance/GovernanceBoardPackReaderTest.php','tests/Feature/Governance/GovernanceBoardPacksTest.php')
$taskManifest | Add-Member completeSharedNotificationQueuedSuites @(foreach ($taskPath in $taskAffectedSuites) { [pscustomobject]@{path=$taskPath; sha256=(Get-TaskHash (Join-Path $taskRoot $taskPath)); runtime='UNRUN'; completeFile=$true} })
$taskOwnedPaths = @(Get-Content -LiteralPath "$taskDir/hs-read-owned-check-paths.json" -Raw | ConvertFrom-Json)
Write-TaskJson "$taskDir/hs-read-owned-check-paths.json" @($taskOwnedPaths + @($taskOwned | Where-Object { $_ -notin $taskOwnedPaths }))
$taskExtraReceipts = @('inbox-note-before.json','OPERATOR-ROOT-NOTE-CONTRACT.txt','DATABASE-NOTIFICATION-CONSUMER-INVENTORY.txt','inbox-note-source-format-r22.json','inbox-note-source-style-r22.json','inbox-note-source-checks-r22.json','inbox-note-main-integration.patch','HS-READ-INTEGRATION-SEAMS-r21.txt','hs-read-integration-source-candidate-r21.json','prepare-inbox-note-source-r22.ps1')
foreach ($taskEntry in $taskManifest.sourceReceipts) { $taskEntry.sha256 = Get-TaskHash (Join-Path $taskRoot $taskEntry.path) }
$taskManifest.sourceReceipts = @($taskManifest.sourceReceipts) + @(foreach ($taskFile in $taskExtraReceipts) { [pscustomobject]@{path="docs/control-room-audit-2026-10-11/$taskFile";sha256=(Get-TaskHash "$taskDir/$taskFile")} })
$taskManifest.remainingSeams = @('MAIN/shared semantic assembly remains owner-reviewed and unapplied.', 'Canonical H&S source-writer operator-origin invalidation on all ownership writes, including identical text, is pending.', 'Chemical-exposure canonical envelope/context/indirect provenance API is pending H&S; no competing predicate.', 'All complete native/full HTTP/type/component/build/browser acceptance and query ceilings remain UNRUN/unadmitted.')
$taskManifest | Add-Member allocatedInboxOperatorCheckpoint $taskReceipt
$taskManifest | Add-Member newCompleteDeclaredMethods 31
$taskManifest | Add-Member sourceWriterSameTextTestStatus 'CR contract fixture only; actual canonical H&S writer gate pending'
$taskManifest.consumingBoundaries = @($taskManifest.consumingBoundaries) + @('All actual DatabaseNotification header/page/count/digest/direct-action consumers via CR-only current adapter; generic workflow redistribution excludes CR semantic copies', 'Persisted operator-root-note proof for presentation/search and checked human resolve/append writer; automatic source-resolution span unchanged')
$taskManifest.execution = [pscustomobject]@{syntaxFiles=13;syntaxFailures=0;styleFiles=12;styleExit=0;sharedMyTasksStyle='Same six pre-existing baseline categories; no new category';diffCheckExit=0;sourceInputDrift=0;mainApplyCheckExit=0;previousReceipt='docs/control-room-audit-2026-10-11/current-source-checks-r21.json';retainedRecipientMethods=26;retainedCurrentSourceMethods=29;newNotificationMethods=18;newOperatorMethods=13;framework='UNRUN';database='UNRUN';migrations='UNRUN';native='UNRUN';node='UNRUN';browser='UNRUN';resourceOrProcessProbe='NONE';runtimeHold='Coordinator managed-host/classifier hold unchanged; no admission inferred'}
# The preparer itself is a source receipt; refresh its pin after all source edits.
foreach ($taskEntry in $taskManifest.sourceReceipts) { $taskEntry.sha256 = Get-TaskHash (Join-Path $taskRoot $taskEntry.path) }
Write-TaskJson "$taskDir/hs-read-integration-source-candidate.json" $taskManifest
[pscustomobject]@{manifestSha256=(Get-TaskHash "$taskDir/hs-read-integration-source-candidate.json");receiptSha256=(Get-TaskHash "$taskDir/inbox-note-source-checks-r22.json");seamsSha256=(Get-TaskHash "$taskDir/HS-READ-INTEGRATION-SEAMS.txt");selected=@($taskManifest.selectedExactDependencies).Count;composed=@($taskManifest.composedOwnedFiles).Count;crWholeSuites=@($taskManifest.completeCrQueuedSuites).Count;sharedWholeSuites=@($taskManifest.completeSharedNotificationQueuedSuites).Count;sourceReceipts=@($taskManifest.sourceReceipts).Count;syntaxCount=$taskSyntax.Count;styleCheckedCount=$taskCleanStyle.Count;mainPatchExit=$taskApplyExit;automaticSourceSpanUnchanged=$taskAutomaticUnchanged;runtime='UNRUN'} | ConvertTo-Json -Compress
