import path from 'node:path';
import { fileURLToPath } from 'node:url';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vitest/config';
import { nodeModulesFsAllow } from '../../build/node-modules-fs-allow';

// Mirrors the actual candidate vitest.config.ts aliases/plugin/environment/setup.
// The isolated runner loader is ESM; do not import its __dirname-based bundled
// config or write Vite's configuration bundle into the shared dependency junction.
const candidate = fileURLToPath(new URL('../../', import.meta.url));

export default defineConfig({
    plugins: [react()],
    resolve: { alias: { '@': path.resolve(candidate, 'resources/js') } },
    server: { fs: { allow: nodeModulesFsAllow(candidate) } },
    cacheDir: path.join(candidate, 'test-results/control-room-owned-cache-r32'),
    test: {
        environment: 'jsdom',
        globals: true,
        setupFiles: [path.join(candidate, 'resources/js/test/setup.ts')],
        include: [
            'resources/js/components/command-centre/command-centre-page.test.tsx',
            'resources/js/lib/control-room-navigation.test.ts',
            'resources/js/pages/control-room/_settings-dialogs.test.tsx',
            'resources/js/pages/control-room/_settings-time.test.ts',
            'resources/js/pages/control-room/shifts/handover.test.tsx',
            'resources/js/pages/control-room/shifts.test.tsx',
        ],
        pool: 'forks',
        maxWorkers: 1,
        fileParallelism: false,
    },
});
