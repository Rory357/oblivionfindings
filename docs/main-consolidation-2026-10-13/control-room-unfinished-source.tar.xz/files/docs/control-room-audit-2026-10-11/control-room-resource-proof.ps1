# Resource integration only. Classification remains the unchanged reviewed H&S helper.
$controlRoomClassifierPath = 'C:\Users\steph\.codex\worktrees\health-safety-workspace\oblivionfindings\.playwright-cli\hs-process-classifier.ps1'
$controlRoomClassifierSha256 = '19B90A2B70EF320A0FD639AA8752111A16E88513AC9FB98198AC84596D232DEC'
$controlRoomToolServicePins = @(
    [pscustomobject]@{path='C:\Users\steph\AppData\Local\OpenAI\Codex\runtimes\cua_node\cfb32733c877621e\bin\node.exe';sha256='F625B617FB283319F73FF5B7560802B1765809DF6A97A9B5D17733909421EF44'},
    [pscustomobject]@{path='C:\Users\steph\AppData\Local\OpenAI\Codex\runtimes\cua_node\cfb32733c877621e\bin\node_modules\@oai\cua-repl\bin\cua-repl.mjs';sha256='992174A5E637645AEB444ADFDB1BAE688E997BB84D7DB07532F68E358E60F278'},
    [pscustomobject]@{path='C:\Users\steph\AppData\Local\OpenAI\Codex\bin\2e5e00daee91c61d\codex.exe';sha256='D13914CED6C7AF174D8D638DB938284231227312104B06A25E9608C632A7DAEC'},
    [pscustomobject]@{path='C:\Users\steph\AppData\Local\OpenAI\Codex\runtimes\cua_node\cfb32733c877621e\bin\node_modules\@oai\cua-repl\package.json';sha256='6121F17C24853DBBE1F05509B77EA7319C6761664156121BCBA327E627961FD0'},
    [pscustomobject]@{path='C:\Users\steph\AppData\Local\OpenAI\Codex\runtimes\cua_node\cfb32733c877621e\bin\node_modules\@oai\cua-repl\dist\lib\js\oai_js_cua_repl\src\launch.js';sha256='3E52A41F4DA41D35BE8CC3723FE97251711087A998C1ED7F2CFDF7E20B50FC2B'}
)
function Get-ControlRoomResourceInputPaths {
    @($controlRoomClassifierPath) + @($controlRoomToolServicePins | ForEach-Object path)
}
function Assert-ControlRoomClassifier {
    if ((Get-FileHash -LiteralPath $controlRoomClassifierPath -Algorithm SHA256).Hash -ne $controlRoomClassifierSha256) {
        throw 'Reviewed shared classifier changed; no child.'
    }
}
function Get-ControlRoomToolServiceIdentity {
    $valid = $true
    foreach ($pin in $controlRoomToolServicePins) {
        try { if ((Get-FileHash -LiteralPath $pin.path -Algorithm SHA256).Hash -ne $pin.sha256) { $valid = $false } }
        catch { $valid = $false }
    }
    [pscustomobject]@{hashes_valid=$valid;node_path=$controlRoomToolServicePins[0].path;entry_path=$controlRoomToolServicePins[1].path;codex_path=$controlRoomToolServicePins[2].path}
}
function Get-ControlRoomResourceProof {
    try {
        Assert-ControlRoomClassifier
        . $controlRoomClassifierPath
        $os = @(Get-CimInstance Win32_OperatingSystem -ErrorAction Stop)
        $processors = @(Get-CimInstance Win32_Processor -ErrorAction Stop)
        $observed = @(Get-CimInstance Win32_Process -ErrorAction Stop)
        $freeKiB = [uint64]0
        if ($os.Count -ne 1 -or -not [uint64]::TryParse([string]$os[0].FreePhysicalMemory,[ref]$freeKiB) -or $freeKiB -eq 0 -or $processors.Count -eq 0 -or $observed.Count -eq 0) {
            throw 'Unknown memory, CPU or process sample.'
        }
        foreach ($processor in $processors) {
            $load = 0
            if ($null -eq $processor.LoadPercentage -or -not [int]::TryParse([string]$processor.LoadPercentage,[ref]$load) -or $load -lt 0 -or $load -gt 100) {
                throw 'Unknown CPU sample.'
            }
        }
        $identity = Get-ControlRoomToolServiceIdentity
        if (-not $identity.hashes_valid) { throw 'Reviewed installed tool service identity changed.' }
        $classification = Get-ProcessClassification $observed $identity
        [pscustomobject]@{time=[DateTime]::UtcNow.ToString('o');sampleValid=$true;freeMiB=([double]$freeKiB/1024);
            cpuPercent=[double]($processors | Measure-Object LoadPercentage -Average).Average;
            heavyNodeIds=@($classification.heavyNodeIds);competingNativeIds=@($classification.competingNativeIds);
            unknownProcessIds=@($classification.unknownIds);previewServerIds=@($classification.previewServerIds);
            toolServiceIds=@($classification.toolServiceIds);classifierSha256=$controlRoomClassifierSha256;processCommands='Never serialized'}
    } catch {
        [pscustomobject]@{time=[DateTime]::UtcNow.ToString('o');sampleValid=$false;freeMiB=$null;cpuPercent=$null;
            heavyNodeIds=@();competingNativeIds=@();unknownProcessIds=@();previewServerIds=@();toolServiceIds=@();
            classifierSha256=$controlRoomClassifierSha256;reason='Unknown resource/process identity; HOLD, no child.'}
    }
}
function Assert-ControlRoomResourceProof($proof) {
    if (-not $proof.sampleValid -or $null -eq $proof.freeMiB -or $null -eq $proof.cpuPercent -or
        $proof.freeMiB -lt 4096 -or $proof.cpuPercent -ge 85 -or @($proof.heavyNodeIds).Count -gt 0 -or
        @($proof.competingNativeIds).Count -gt 0 -or @($proof.unknownProcessIds).Count -gt 0) {
        throw 'HELD: fresh memory, CPU or shared process classification does not permit a child.'
    }
}
