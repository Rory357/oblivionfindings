<?php

namespace App\Services\ControlRoom;

use App\Models\ClientIncident;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\User;
use App\Services\CurrentAuthorizationReads;
use App\Services\HealthSafety\FirstAidAccessService;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\HealthSafety\HsEventAccessService;
use App\Services\HealthSafety\InjuryAccessService;
use App\Services\HealthSafety\InjurySourceProjectionService;
use App\Services\HealthSafety\RestraintAccessService;
use App\Services\Incidents\IncidentAccessService;
use App\Services\Incidents\IncidentJourneyService;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

/** Request-local canonical source context. Never serialize the raw models. */
final class ControlRoomGovernanceReadService
{
    public const PERMISSIONS = [...FirstAidAccessService::PERMISSIONS, ...RestraintAccessService::PERMISSIONS,
        ...InjuryAccessService::PERMISSIONS, 'reports.viewAny', 'controlRoom.alerts.assign', 'controlRoom.alerts.escalate',
        'controlRoom.alerts.create', 'controlRoom.handovers.override', 'compliance.view',
        'securityDevices.devices.view', 'securityDevices.devices.viewAllSites', 'securityDevices.devices.viewUnassigned',
        'staff.viewAny', 'fleet.viewAny', 'fleet.manage', 'fleet.bookings.approve', 'assets.viewAny', 'assets.viewAssigned',
        'it.view', 'it.manage'];

    private static ?\WeakMap $readTokens = null;

    private static ?\WeakMap $currentAlerts = null;

    public function __construct(
        private readonly IncidentJourneyService $journeys,
        private readonly IncidentAccessService $incidents,
        private readonly HsEventAccessService $healthSafety,
        private readonly ControlRoomSourceContentService $sourceContent,
        private readonly ControlRoomAlertAccessService $alertsAccess,
        private readonly InjurySourceProjectionService $injuries,
    ) {}

    /** Module admission is independent of source authority; the outer callback returns detached values only. */
    public function withCurrentViewer(User $viewer, callable $operation, ?HealthSafetyReadContext $context = null): mixed
    {
        if ($context === null) {
            return HealthSafetyReadContext::within($viewer, self::PERMISSIONS,
                fn (HealthSafetyReadContext $current) => $this->withCurrentViewer($viewer, $operation, $current));
        }
        $context->assertViewer($viewer);

        return $context->consumeSourceViewer(self::PERMISSIONS,
            function (User $current, CurrentAuthorizationReads $reads) use ($operation, $context) {
                abort_unless($this->alertsAccess->canList($current), 403);

                return $operation($current, $context, $reads);
            });
    }

    /**
     * @param  iterable<ControlRoomAlert>  $alerts
     * @return Collection<int, array<string, mixed>> Detached source facts; access flags never authorize a later command.
     */
    public function forAlerts(iterable $alerts, User $viewer, ?HealthSafetyReadContext $context = null): Collection
    {
        if ($context === null) {
            return collect($this->withCurrentViewer($viewer,
                fn (User $current, HealthSafetyReadContext $reads): array => $this->forAlerts($alerts, $current, $reads)->all()));
        }
        $context->assertViewer($viewer);

        return $this->withCurrentViewer($viewer, function (User $current, HealthSafetyReadContext $context, CurrentAuthorizationReads $reads) use ($alerts): Collection {
            $alerts = new EloquentCollection(collect($alerts)->values()->all());
            if ($alerts->isEmpty()) {
                return collect();
            }
            $alerts = $this->currentAlerts($alerts, $current, $context);
            $alerts->loadMissing([
                'site:id,name', 'client:id,first_name,last_name,site_id', 'client.site:id,name',
                'asset.client.site', 'fleetSignal.asset.client.site', 'device',
            ]);
            $records = $this->journeys->governanceRecordsForAlerts($alerts, $reads);
            $incidentIds = $records->pluck('incident.id')->filter()->unique()->values();
            $eventIds = $records->pluck('hs_event.id')->filter()->unique()->values();
            $readableIncidentIds = $incidentIds->isEmpty() ? collect() : $this->incidents
                ->apply(ClientIncident::query()->whereIn('id', $incidentIds), $current, $reads)
                ->pluck('id')->flip();
            $eventCandidates = $context->applyEventSiteScope(HsEvent::query()->whereIn('id', $eventIds),
                UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);
            $readableEventIds = $eventIds->isEmpty() ? collect() : $this->healthSafety
                ->applyReadableScope(clone $eventCandidates, $current, $context, $eventCandidates)
                ->pluck('id')->flip();
            $readableEvents = new EloquentCollection($records->pluck('hs_event')->filter(
                fn (?HsEvent $event): bool => $event !== null && $readableEventIds->has($event->id),
            )->unique('id')->values()->all());
            $readableEvents->loadMissing(['owner:id,name', 'acceptedBy:id,name']);

            return $records->map(function (array $record, int $id) use ($alerts, $current, $context, $readableIncidentIds, $readableEventIds): array {
                $alert = $alerts->find($id);
                $injury = $this->isInjuryAlert($alert)
                    ? $this->injuries->forAlert($alert, $current, $context)
                    : ['access' => 'absent', 'source' => null];
                $restraint = $this->sourceContent->restraintForAlert($alert, $current, $context);
                if ($this->isInjuryAlert($alert) && $injury['access'] === 'absent') {
                    $injury = ['access' => 'unavailable', 'source' => null];
                }
                $unavailable = ($record['integrity'] ?? null) === 'unavailable';
                $incidentAccess = $unavailable ? 'unavailable' : ($record['incident'] === null ? 'absent'
                    : ($readableIncidentIds->has($record['incident']->id) ? 'readable' : 'restricted'));
                $eventAccess = $unavailable ? 'unavailable' : ($record['hs_event'] === null ? 'absent'
                    : ($readableEventIds->has($record['hs_event']->id) ? 'readable' : 'restricted'));

                return [
                    'alert_id' => $id,
                    'incident' => $record['incident']?->only(['id', 'reference_number', 'status', 'client_id', 'site_id', 'hs_event_id']),
                    'hs_event' => $record['hs_event']?->only(['id', 'reference_number', 'status', 'handover_status',
                        'source_type', 'source_id', 'client_id', 'site_id', 'staff_id', 'event_category']),
                    'incident_access' => $incidentAccess, 'health_safety_access' => $eventAccess,
                    'incident_detail' => $incidentAccess === 'readable' ? [
                        'severity' => $record['incident']->severity, 'title' => $record['incident']->title,
                        'occurred_at' => $record['incident']->occurred_at?->toIso8601String(),
                    ] : null,
                    'hs_detail' => $eventAccess === 'readable' ? [
                        'severity' => $record['hs_event']->severity,
                        'owner' => $record['hs_event']->owner?->only(['id', 'name']),
                        'accepted_by' => $record['hs_event']->acceptedBy?->only(['id', 'name']),
                        'accepted_at' => $record['hs_event']->accepted_at?->toIso8601String(),
                    ] : null,
                    'integrity' => $unavailable ? 'unavailable' : 'available',
                    'injury_access' => $injury['access'], 'injury_source' => $injury['source'],
                    'workflow_changed_at' => $unavailable ? [] : $this->workflowTimestamps($record),
                    '_read_context' => $this->readToken($context),
                ] + $restraint;
            });
        }, $context);
    }

    public function isInjuryAlert(ControlRoomAlert $alert): bool
    {
        return $alert->alert_type === 'operations.workplace_injury'
            || array_key_exists('workplace_injury_id', is_array($alert->context) ? $alert->context : [])
            || array_key_exists('workplace_injury_id', (array) data_get($alert->context, 'normalized_data', []));
    }

    /** Internal current operational rows only. The outer read callback rejects a live model result. */
    public function currentAlerts(iterable $alerts, User $viewer, HealthSafetyReadContext $context): EloquentCollection
    {
        $viewer = $this->withCurrentViewer($viewer, fn (User $current): User => $current, $context);
        $ids = collect($alerts)->map(fn (ControlRoomAlert $alert): int => (int) $alert->id)->unique()->values();
        self::$currentAlerts ??= new \WeakMap;
        $cached = self::$currentAlerts[$context] ?? new EloquentCollection;
        $missing = $ids->diff($cached->modelKeys());
        if ($missing->isNotEmpty()) {
            $fresh = $context->query($this->alertsAccess->applyVisibleScope(ControlRoomAlert::query()->whereKey($missing), $viewer))->get();
            abort_unless($fresh->count() === $missing->count(), 404);
            $cached = $cached->merge($fresh)->keyBy('id');
            self::$currentAlerts[$context] = $cached;
        }

        return new EloquentCollection($ids->map(fn (int $id) => $cached->get($id))->all());
    }

    /** Operational change criteria only; no copied descriptions, source actors or private medical fields. */
    private function workflowTimestamps(array $record): array
    {
        $timestamps = [];
        foreach (['incident' => ['created_at', 'submitted_at', 'reviewed_at', 'investigation_started_at',
            'investigation_completed_at', 'reopened_at', 'closed_at'],
            'hs_event' => ['created_at', 'accepted_at', 'worksafe_decided_at', 'worksafe_notified_at',
                'worksafe_acknowledged_at', 'closed_at']] as $key => $fields) {
            foreach ($fields as $field) {
                $value = $record[$key]?->getAttribute($field);
                if ($value !== null) {
                    $timestamps[] = (string) $value;
                }
            }
        }
        foreach ($record['hs_event']?->correctiveActions ?? [] as $action) {
            foreach (['completed_at', 'verified_at', 'closed_at'] as $field) {
                if ($action->{$field} !== null) {
                    $timestamps[] = (string) $action->{$field};
                }
            }
        }

        return $timestamps;
    }

    /** A batch may be reused only inside the callback that locked and projected it. */
    public function isCurrentRecord(array $record, HealthSafetyReadContext $context, ?int $alertId = null): bool
    {
        return ($record['_read_context'] ?? null) === $this->readToken($context)
            && ($alertId === null || ($record['alert_id'] ?? null) === $alertId);
    }

    private function readToken(HealthSafetyReadContext $context): string
    {
        $context->assertActive();
        self::$readTokens ??= new \WeakMap;

        return self::$readTokens[$context] ??= (string) Str::uuid();
    }

    /**
     * Re-check saved references against the current reader and canonical source.
     * Retain historical workflow facts without replacing the saved snapshot.
     *
     * @param  array<string, mixed>  $snapshot  A validated handover snapshot.
     * @return array<string, mixed>
     */
    public function forSnapshotViewer(array $snapshot, User $viewer, ?HealthSafetyReadContext $context = null): array
    {
        if ($context === null) {
            return $this->withCurrentViewer($viewer, fn (User $current, HealthSafetyReadContext $reads): array => $this->forSnapshotViewer($snapshot, $current, $reads));
        }
        $context->assertViewer($viewer);
        $viewer = $this->withCurrentViewer($viewer, fn (User $current): User => $current, $context);
        $alerts = $context->query($this->alertsAccess->applyVisibleScope(ControlRoomAlert::query()
            ->whereIn('id', collect($snapshot['alerts'])->pluck('id')), $viewer))->get()->keyBy('id');
        $records = $this->forAlerts($alerts, $viewer, $context);
        $snapshot['alerts'] = collect($snapshot['alerts'])->map(function (array $row) use ($records, $alerts): array {
            $record = $records->get((int) $row['id']);
            $row = $this->sourceContent->snapshotSummary($row, $alerts->get((int) $row['id']), $record ?? []);
            foreach (['incident' => ['incident', 'INC-'], 'health_safety' => ['hs_event', 'HS-']] as $domain => [$key, $prefix]) {
                $referenceKey = $domain.'_reference';
                $accessKey = $domain.'_access';
                $savedReference = $row['journey'][$referenceKey] ?? null;
                $savedAccess = $row['journey'][$accessKey] ?? null;
                $source = $record[$key] ?? null;
                $currentAccess = $record[$accessKey] ?? 'unavailable';
                $currentReference = $source ? (data_get($source, 'reference_number') ?: $prefix.data_get($source, 'id')) : null;

                if ($savedReference !== null && $currentAccess === 'readable' && $savedReference === $currentReference) {
                    $row['journey'][$accessKey] = 'readable';

                    continue;
                }

                $row['journey'][$referenceKey] = null;
                $row['journey'][$accessKey] = match (true) {
                    $savedAccess === 'absent' && $savedReference === null => 'absent',
                    $currentAccess === 'restricted' => 'restricted',
                    default => 'unavailable',
                };
            }

            return $row;
        })->values()->all();

        return $snapshot;
    }
}
