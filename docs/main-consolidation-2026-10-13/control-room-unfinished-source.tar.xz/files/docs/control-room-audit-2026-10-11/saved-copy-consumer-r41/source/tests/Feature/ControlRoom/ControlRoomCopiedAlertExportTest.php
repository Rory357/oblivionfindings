<?php

namespace Tests\Feature\ControlRoom;

use App\Models\AuditLog;
use App\Models\Client;
use App\Models\ControlRoomAlert;
use App\Models\IncidentSavedCopy;
use App\Services\ControlRoom\ControlRoomAlertLifecycleService;
use App\Services\ControlRoom\ControlRoomIncidentNoteCopyWriter as Writer;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use Illuminate\Support\Str;
use LogicException;
use PHPUnit\Framework\Attributes\DataProvider;
use Tests\Feature\Incidents\IncidentIndependenceTestCase;

/** Real prospective writer and HTTP CSV consumer. Whole class UNRUN; no fixture-only privacy certification. */
final class ControlRoomCopiedAlertExportTest extends IncidentIndependenceTestCase
{
    protected function setUp(): void
    {
        parent::setUp(); Queue::fake();
        foreach (['controlRoom.reports.view', 'controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage'] as $key) {
            $this->allow($this->manager, $key);
        }
    }

    private function fixture(string $text = 'Exact private source field', string $field = 'description'): array
    {
        $root = $this->incident([$field => $text]);
        $alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'client_id' => $root->client_id, 'source' => 'incident',
            'alert_type' => 'incident.synthetic', 'notes' => null, 'triggered_at' => now(), 'context' => [],
        ]));
        $uuid = (string) Str::uuid();
        $accepted = app(Writer::class)->copyField($this->manager, (int) $alert->id, (int) $root->id, $uuid, $field);
        return ['root' => $root, 'alert' => $alert, 'uuid' => $uuid, 'accepted' => $accepted, 'text' => $text, 'field' => $field];
    }

    private function export(): array
    {
        $response = $this->actingAs($this->manager)->get('/control-room/reports/export?period=30d')->assertOk();
        $stream = fopen('php://temp', 'r+'); fwrite($stream, $response->getContent()); rewind($stream);
        fgetcsv($stream, null, ',', '"', ''); $rows = [];
        while (($row = fgetcsv($stream, null, ',', '"', '')) !== false) { $rows[] = $row; }
        fclose($stream);
        return collect($rows)->keyBy(fn ($row) => (int) $row[0])->all();
    }

    private function unavailable(array $fixture): void
    {
        $rows = $this->export();
        $this->assertArrayHasKey($fixture['alert']->id, $rows, 'Operational row must survive source-only denial.');
        $this->assertSame('', $rows[$fixture['alert']->id][12]);
        $this->assertSame($fixture['alert']->source, $rows[$fixture['alert']->id][1]);
    }

    public function test_exact_field_is_verified_in_full_then_truncated_and_encoded_for_csv(): void
    {
        $fixture = $this->fixture(str_repeat('x', 205).'"Original suffix"');
        $rows = $this->export();
        $this->assertSame(str_repeat('x', 200), $rows[$fixture['alert']->id][12]);
        $this->assertSame(1, AuditLog::where('meta->copy_uuid', $fixture['uuid'])->count(), 'CR receipt must not duplicate the source root UUID claim.');
        $this->assertSame(1, AuditLog::where('meta->origin->copy_uuid', $fixture['uuid'])->count());
    }

    public function test_csv_character_limit_does_not_split_a_multibyte_source_character(): void
    {
        $f = $this->fixture(str_repeat('α', 199).'🙂Original remainder');
        $this->assertSame(str_repeat('α', 199).'🙂', $this->export()[$f['alert']->id][12]);
    }

    public function test_verified_multiline_and_quoted_source_text_round_trips_through_csv_encoding(): void
    {
        $f = $this->fixture("First line\nQuoted \"detail\"");
        $this->assertSame($f['text'], $this->export()[$f['alert']->id][12]);
    }

    public function test_both_supported_fields_are_prospective_and_no_old_note_is_backfilled(): void
    {
        $first = $this->fixture('Original action', 'immediate_action_taken');
        $legacy = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'source' => 'incident', 'notes' => 'Unproved legacy copy', 'triggered_at' => now(),
            'context' => ['incident_id' => $first['root']->id],
        ]));
        $rows = $this->export();
        $this->assertSame('Original action', $rows[$first['alert']->id][12]);
        $this->assertSame('', $rows[$legacy->id][12]);
        $this->assertArrayNotHasKey('saved_incident_copy', $legacy->fresh()->context);
    }

    public function test_replay_retains_original_destination_receipt_without_rewriting_notes(): void
    {
        $f = $this->fixture();
        $this->assertSame($f['accepted'], app(Writer::class)->copyField($this->manager, $f['alert']->id, $f['root']->id, $f['uuid'], $f['field']));
        $this->assertSame(1, AuditLog::where('meta->origin->copy_uuid', $f['uuid'])->count());
    }

    public function test_source_and_target_client_mismatch_rolls_back_without_creating_copy_provenance(): void
    {
        $root = $this->incident(); $other = Client::factory()->create(['site_id' => $this->site->id]);
        $alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'client_id' => $other->id, 'source' => 'incident', 'notes' => null, 'context' => [],
        ]));
        $sourceCount = IncidentSavedCopy::count(); $auditCount = AuditLog::count();
        try { app(Writer::class)->copyField($this->manager, $alert->id, $root->id, (string) Str::uuid(), 'description'); $this->fail('Separate readable Clients do not establish copy correlation.'); }
        catch (LogicException) {
            $this->assertNull($alert->fresh()->notes); $this->assertSame([], $alert->fresh()->context);
            $this->assertSame($sourceCount, IncidentSavedCopy::count()); $this->assertSame($auditCount, AuditLog::count());
        }
    }

    #[DataProvider('composites')]
    public function test_prefix_suffix_case_and_trailing_bytes_are_not_certified_field_copies(string $kind): void
    {
        $f = $this->fixture();
        $text = match ($kind) { 'prefix' => 'Reported: '.$f['text'], 'suffix' => $f['text'].' Fleet handoff',
            'case' => strtoupper($f['text']), 'space' => $f['text'].' ' };
        DB::table('control_room_alerts')->where('id', $f['alert']->id)->update(['notes' => $text]);
        $this->unavailable($f);
    }

    public static function composites(): array
    { return ['prefix' => ['prefix'], 'suffix' => ['suffix'], 'case' => ['case'], 'trailing byte' => ['space']]; }

    public function test_a_matching_csv_prefix_does_not_authenticate_a_different_full_note(): void
    {
        $f = $this->fixture(str_repeat('z', 200).'Original secret suffix');
        DB::table('control_room_alerts')->where('id', $f['alert']->id)->update(['notes' => str_repeat('z', 200).'Different suffix']);
        $this->unavailable($f);
    }

    public function test_source_permission_withdrawal_retains_the_operational_row_and_can_restore_the_copy(): void
    {
        $f = $this->fixture();
        $this->allow($this->manager, 'incidents.viewAny', false); $this->allow($this->manager, 'incidents.viewAssigned', false);
        $this->unavailable($f);
        $this->allow($this->manager, 'incidents.viewAny');
        $this->assertSame($f['text'], $this->export()[$f['alert']->id][12]);
    }

    public function test_proved_operator_text_survives_without_an_incident_read_prerequisite(): void
    {
        $alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'client_id' => null, 'source' => 'operations', 'alert_type' => 'operations.synthetic',
            'status' => ControlRoomAlert::STATUS_TRIAGING, 'notes' => null, 'context' => [], 'triggered_at' => now(),
        ]));
        app(ControlRoomAlertLifecycleService::class)->resolve($alert, $this->manager, 'Independent operator response', 'controlled');
        $this->allow($this->manager, 'incidents.viewAny', false); $this->allow($this->manager, 'incidents.viewAssigned', false);
        $this->assertSame('Independent operator response', $this->export()[$alert->id][12]);
    }

    public function test_source_overwrite_invalidates_operator_ownership_even_for_identical_text(): void
    {
        $root = $this->incident(['description' => 'Identical bytes']);
        $alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'client_id' => $root->client_id, 'source' => 'operations', 'alert_type' => 'operations.synthetic',
            'status' => ControlRoomAlert::STATUS_TRIAGING, 'notes' => null, 'context' => [], 'triggered_at' => now(),
        ]));
        app(ControlRoomAlertLifecycleService::class)->resolve($alert, $this->manager, 'Identical bytes', 'controlled');
        $this->assertArrayHasKey('root_note_origin', $alert->fresh()->context);
        app(Writer::class)->copyField($this->manager, $alert->id, $root->id, (string) Str::uuid(), 'description');
        $this->assertArrayNotHasKey('root_note_origin', $alert->fresh()->context);
        $this->allow($this->manager, 'incidents.viewAny', false); $this->allow($this->manager, 'incidents.viewAssigned', false);
        $this->unavailable(['alert' => $alert]);
    }

    private function beforeNotes(callable $mutate, callable $consume): void
    {
        $state = (object) ['armed' => true, 'fired' => false, 'hydrated' => 0];
        $dispatcher = Model::getEventDispatcher(); Model::setEventDispatcher(clone $dispatcher);
        ControlRoomAlert::retrieved(function ($row) use ($state): void {
            if ($state->fired && array_key_exists('notes', $row->getAttributes())) { $state->hydrated++; }
        });
        DB::connection()->beforeExecuting(function ($sql) use ($state, $mutate): void {
            if (! $state->armed || ! preg_match('/\Aselect (.*?) from /is', $sql, $match)
                || ! str_contains($match[1], '`control_room_alerts`.`notes`')) { return; }
            $state->armed = false; $state->fired = true; $mutate();
        });
        try { $consume(); $this->assertTrue($state->fired); $this->assertSame(0, $state->hydrated); }
        finally { $state->armed = false; Model::setEventDispatcher($dispatcher); }
    }

    public function test_actual_first_destination_notes_select_refuses_late_source_denial_before_hydration(): void
    {
        $f = $this->fixture();
        $this->beforeNotes(fn () => $this->allow($this->manager, 'incidents.viewAny', false), fn () => $this->unavailable($f));
    }

    public function test_actual_notes_select_refuses_changed_original_target_and_destination_receipt(): void
    {
        $f = $this->fixture(); $client = Client::factory()->create(['site_id' => $this->site->id]);
        $this->beforeNotes(fn () => DB::table('control_room_alerts')->where('id', $f['alert']->id)->update(['client_id' => $client->id]), fn () => $this->unavailable($f));
        DB::table('control_room_alerts')->where('id', $f['alert']->id)->update(['client_id' => $f['root']->client_id]);
        $this->beforeNotes(fn () => DB::table('audit_logs')->where('id', $f['accepted']['audit_id'])->update(['action' => 'reclassified']), fn () => $this->unavailable($f));
    }

    public function test_late_report_authority_denial_withholds_export_and_does_not_hydrate_notes(): void
    {
        $this->fixture();
        $this->beforeNotes(function (): void {
            $this->allow($this->manager, 'controlRoom.reports.view', false); $this->allow($this->manager, 'controlRoom.viewAny', false);
        }, fn () => $this->actingAs($this->manager)->get('/control-room/reports/export?period=30d')->assertForbidden());
    }

    public function test_final_destination_receipt_mutation_cannot_relearn_a_new_accepted_origin(): void
    {
        $f = $this->fixture(); $armed = true;
        $dispatcher = Model::getEventDispatcher(); Model::setEventDispatcher(clone $dispatcher);
        ControlRoomAlert::retrieved(function ($row) use (&$armed, $f): void {
            if (! $armed || ! array_key_exists('notes', $row->getAttributes())) { return; }
            $armed = false; DB::table('audit_logs')->where('id', $f['accepted']['audit_id'])->update(['action' => 'changed after body']);
        });
        try { $this->unavailable($f); $this->assertFalse($armed); }
        finally { $armed = false; Model::setEventDispatcher($dispatcher); }
    }

    public function test_changed_original_receipt_replay_rolls_back_instead_of_repairing_from_current_text(): void
    {
        $f = $this->fixture(); DB::table('audit_logs')->where('id', $f['accepted']['audit_id'])->update(['action' => 'reclassified']);
        $before = (array) DB::table('control_room_alerts')->where('id', $f['alert']->id)->first();
        try { app(Writer::class)->copyField($this->manager, $f['alert']->id, $f['root']->id, $f['uuid'], $f['field']); $this->fail('Original receipt must not be rebuilt.'); }
        catch (LogicException) { $this->assertSame($before, (array) DB::table('control_room_alerts')->where('id', $f['alert']->id)->first()); }
    }

    public function test_removed_destination_receipt_is_not_recreated_from_a_retained_source_identity(): void
    {
        $f = $this->fixture(); DB::table('audit_logs')->where('id', $f['accepted']['audit_id'])->delete();
        $before = (array) DB::table('control_room_alerts')->where('id', $f['alert']->id)->first();
        try { app(Writer::class)->copyField($this->manager, $f['alert']->id, $f['root']->id, $f['uuid'], $f['field']); $this->fail('Missing destination acceptance must not be inferred.'); }
        catch (LogicException) {
            $this->assertSame($before, (array) DB::table('control_room_alerts')->where('id', $f['alert']->id)->first());
            $this->assertSame(0, AuditLog::where('meta->origin->copy_uuid', $f['uuid'])->count());
        }
    }

    public function test_same_text_replacement_of_the_original_origin_after_update_rolls_back(): void
    {
        $f = $this->fixture('Equal source bytes');
        $before = (array) DB::table('control_room_alerts')->where('id', $f['alert']->id)->first();
        $sourceCount = IncidentSavedCopy::count(); $auditCount = AuditLog::count();
        $state = (object) ['armed' => true, 'fired' => false];
        DB::listen(function ($event) use ($state, $f, $before): void {
            if (! $state->armed || ! str_starts_with($event->sql, 'update `control_room_alerts` set `notes`')) { return; }
            $state->armed = false; $state->fired = true;
            DB::table('control_room_alerts')->where('id', $f['alert']->id)->update(['context' => $before['context']]);
        });
        try {
            app(Writer::class)->copyField($this->manager, $f['alert']->id, $f['root']->id, (string) Str::uuid(), $f['field']);
            $this->fail('Equal note text must not authenticate substituted original metadata.');
        } catch (LogicException) {
            $this->assertTrue($state->fired); $this->assertSame($before, (array) DB::table('control_room_alerts')->where('id', $f['alert']->id)->first());
            $this->assertSame($sourceCount, IncidentSavedCopy::count()); $this->assertSame($auditCount, AuditLog::count());
        } finally { $state->armed = false; }
    }
}
