<?php

namespace App\Http\Controllers\ControlRoom;

use App\Http\Controllers\Controller;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\CurrentAuthorizationReads;
use App\Services\ControlRoom\ControlRoomAlertAccessService;
use App\Services\ControlRoom\ControlRoomCopiedAlertNoteService;
use App\Services\ControlRoom\ControlRoomIncidentNoteCopyWriter;
use App\Services\ControlRoom\ControlRoomNoteReadEvidence;
use App\Services\ControlRoom\ControlRoomReportService;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\UserSiteAccessService;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Inertia\Inertia;

class ControlRoomReportController extends Controller
{
    public function __construct(
        protected ControlRoomReportService $reportService,
    ) {}

    /**
     * Main reports dashboard — overview with all metric groups.
     */
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $this->canViewReports($user), 403);

        [$from, $to, $period] = $this->resolveDateRange($request);
        $siteId = $request->filled('site_id') ? (int) $request->input('site_id') : null;
        $reportSiteScope = $this->reportSiteScope($user, $siteId);
        $sla = $this->reportService->slaCompliance($from, $to, $reportSiteScope, $user);
        $volume = $this->reportService->alertVolume($from, $to, $reportSiteScope, $user);
        $escalation = $this->reportService->escalationAnalysis($from, $to, $reportSiteScope, $user);
        $workload = $this->reportService->workloadDistribution($from, $to, $reportSiteScope, $user);
        $playbooks = $this->reportService->playbookPerformance($from, $to, $reportSiteScope, $user);

        AuditLogger::log('controlRoom.reports.view', null, ['period' => $period]);

        return Inertia::render('control-room/reports', [
            'period' => $period,
            'site_id' => $siteId,
            'sla' => $sla,
            'volume' => $volume,
            'escalation' => $escalation,
            'workload' => $workload,
            'playbooks' => $playbooks,
            'stats' => [
                'total_alerts' => $volume['total'],
                'resolved_alerts' => $volume['resolved_in_period'],
                'cohort_resolved_alerts' => $volume['resolved'],
                'resolution_rate' => $volume['resolution_rate'],
                'avg_resolution_hours' => $sla['avg_resolution_hours'],
                'escalated_count' => $escalation['escalated'],
                'escalation_rate' => $escalation['escalation_rate'],
            ],
            'by_severity' => $volume['by_severity'] ?? [],
            'by_status' => $this->statusBreakdown($from, $to, $user, $siteId),
            'by_source' => $volume['by_source'] ?? [],
            'by_alert_type' => $volume['top_alert_types'] ?? [],
            'daily_trend' => $volume['daily_trend'] ?? [],
            'response_time_by_severity' => collect($sla['by_severity'])
                ->mapWithKeys(fn (array $row, string $severity) => [$severity => $row['avg_response_minutes']])
                ->all(),
            'top_assignees' => collect($workload['handled_per_user'] ?? [])
                ->map(fn (array $row) => [
                    'user' => $row['user'],
                    'count' => $row['alerts_handled'],
                ])
                ->values()
                ->all(),
        ]);
    }

    /**
     * SLA compliance report endpoint.
     */
    public function sla(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $this->canViewReports($user), 403);

        [$from, $to] = $this->resolveDateRange($request);
        $siteId = $request->filled('site_id') ? (int) $request->input('site_id') : null;

        return response()->json($this->reportService->slaCompliance(
            $from,
            $to,
            $this->reportSiteScope($user, $siteId),
            $user,
        ));
    }

    /**
     * Alert volume report endpoint.
     */
    public function alerts(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $this->canViewReports($user), 403);

        [$from, $to] = $this->resolveDateRange($request);
        $siteId = $request->filled('site_id') ? (int) $request->input('site_id') : null;

        return response()->json($this->reportService->alertVolume(
            $from,
            $to,
            $this->reportSiteScope($user, $siteId),
            $user,
        ));
    }

    /**
     * Workload distribution report endpoint.
     */
    public function workload(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $this->canViewReports($user), 403);

        [$from, $to] = $this->resolveDateRange($request);
        $siteId = $request->filled('site_id') ? (int) $request->input('site_id') : null;

        return response()->json($this->reportService->workloadDistribution(
            $from,
            $to,
            $this->reportSiteScope($user, $siteId),
            $user,
        ));
    }

    /**
     * Summary endpoint — compact KPIs for dashboard widgets.
     */
    public function summary(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $this->canViewReports($user), 403);

        [$from, $to] = $this->resolveDateRange($request);
        $siteId = $request->filled('site_id') ? (int) $request->input('site_id') : null;
        $reportSiteScope = $this->reportSiteScope($user, $siteId);

        $sla = $this->reportService->slaCompliance($from, $to, $reportSiteScope, $user);
        $volume = $this->reportService->alertVolume($from, $to, $reportSiteScope, $user);
        $escalation = $this->reportService->escalationAnalysis($from, $to, $reportSiteScope, $user);

        return response()->json([
            'total_alerts' => $volume['total'],
            'open_alerts' => $volume['open'],
            'resolution_rate' => $volume['resolution_rate'],
            'sla_compliance' => $sla['compliance_pct'],
            'avg_acknowledge_minutes' => $sla['avg_acknowledge_minutes'],
            'avg_resolution_hours' => $sla['avg_resolution_hours'],
            'escalation_rate' => $escalation['escalation_rate'],
            'sla_breached' => $sla['sla_breached'],
        ]);
    }

    /**
     * CSV export — full alert data for the period.
     */
    public function export(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $this->canViewReports($user), 403);

        [$from, $to, $period] = $this->resolveDateRange($request);
        $siteId = $request->filled('site_id') ? (int) $request->input('site_id') : null;

        $export = HealthSafetyReadContext::within($user, ControlRoomIncidentNoteCopyWriter::PERMISSIONS,
            fn (HealthSafetyReadContext $context): array => $context->consumeSourceViewer(
                ControlRoomNoteReadEvidence::PERMISSIONS, function (User $current, CurrentAuthorizationReads $reads)
                    use ($context, $from, $to, $siteId): array {
                        abort_unless($this->canViewReports($current), 403);
                        $scope = fn () => ControlRoomAlert::where('triggered_at', '>=', $from)
                            ->where('triggered_at', '<=', $to)
                            ->tap(fn ($query) => $this->applyReportAlertScope($query, $current, $siteId));
                        $authority = app(ControlRoomNoteReadEvidence::class)->protect($scope(), $current, $reads, ControlRoomNoteReadEvidence::PERMISSIONS);
                        $notes = app(ControlRoomCopiedAlertNoteService::class);
                        $alerts = $reads->query($notes->metadata((clone $authority)->select([
                            ...ControlRoomCopiedAlertNoteService::TARGET_COLUMNS, 'severity', 'status',
                            'assigned_to_user_id', 'resolved_by_user_id', 'triggered_at', 'acknowledged_at', 'resolved_at', 'escalation_level',
                        ])))->with(['asset:id,name,asset_tag', 'assignedTo:id,name', 'resolvedBy:id,name'])
                            ->orderByDesc('triggered_at')->get();

                        $csv = "ID,Source,Type,Severity,Status,Asset,Assigned To,Triggered At,Acknowledged At,Resolved At,Resolution Time (hrs),Escalation Level,Notes\n";

                        foreach ($alerts as $alert) {
                            $projection = $notes->forExport($alert, $scope, $current, $context, $reads, $authority);
                            $resolutionHours = '';
                            if ($alert->triggered_at && $alert->resolved_at) {
                                $resolutionHours = round($alert->triggered_at->diffInMinutes($alert->resolved_at) / 60, 1);
                            }

                            $csv .= implode(',', [
                                $alert->id,
                                '"'.str_replace('"', '""', $alert->source ?? '').'"',
                                '"'.str_replace('"', '""', $alert->alert_type ?? '').'"',
                                $alert->severity ?? '',
                                $alert->status ?? '',
                                '"'.str_replace('"', '""', $alert->asset?->name ?? '').'"',
                                '"'.str_replace('"', '""', $alert->assignedTo?->name ?? '').'"',
                                $alert->triggered_at?->toDateTimeString() ?? '',
                                $alert->acknowledged_at?->toDateTimeString() ?? '',
                                $alert->resolved_at?->toDateTimeString() ?? '',
                                $resolutionHours,
                                $alert->escalation_level ?? 0,
                                '"'.str_replace('"', '""', mb_substr($projection['notes'] ?? '', 0, 200, 'UTF-8')).'"',
                            ])."\n";
                        }

                        // Source-note denial does not remove independently permitted operational rows.
                        // A changed destination capability/Site tuple still withholds the entire detached export.
                        $ids = $alerts->modelKeys();
                        abort_unless($reads->query((clone $authority)->whereKey($ids))->count() === count($ids), 403);
                        return ['csv' => $csv, 'count' => count($ids)];
        }));

        AuditLogger::log('controlRoom.reports.export', null, [
            'period' => $period,
            'count' => $export['count'],
        ]);

        return response($export['csv'], 200, [
            'Content-Type' => 'text/csv',
            'Content-Disposition' => 'attachment; filename="control-room-alerts-'.now()->format('Y-m-d').'.csv"',
        ]);
    }

    protected function applyReportAlertScope($query, $user, ?int $siteId): void
    {
        $siteAccess = app(UserSiteAccessService::class);
        $siteAccess->applyAlertScope($query, $user, $this->alertBypassPermissions());
        app(ControlRoomAlertAccessService::class)
            ->applyControlledMedicationContentScope($query, $user);

        if ($siteId) {
            $siteAccess->applyAlertSiteScopeForSiteIds($query, [$siteId]);
        }
    }

    protected function reportSiteScope($user, ?int $siteId): int|array|null
    {
        $siteAccess = app(UserSiteAccessService::class);
        $bypassPermissions = $this->alertBypassPermissions();

        if ($siteId) {
            $siteAccess->assertCanAccessSiteId(
                $user,
                $siteId,
                $bypassPermissions,
                'You are not authorized to access Control Room reports for that site.',
            );

            return $siteId;
        }

        if ($siteAccess->canBypass($user, $bypassPermissions)) {
            return null;
        }

        return $siteAccess->accessibleSiteIds($user, $bypassPermissions);
    }

    protected function alertBypassPermissions(): array
    {
        return ['reports.viewAny'];
    }

    protected function canViewReports($user): bool
    {
        return $user->canDo('controlRoom.reports.view') || $user->canDo('controlRoom.viewAny');
    }

    protected function statusBreakdown(Carbon $from, Carbon $to, $user, ?int $siteId): array
    {
        $query = ControlRoomAlert::query()
            ->where('triggered_at', '>=', $from)
            ->where('triggered_at', '<=', $to);

        $this->applyReportAlertScope($query, $user, $siteId);

        return $query
            ->selectRaw('status, COUNT(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status')
            ->toArray();
    }

    /**
     * Resolve date range from request.
     *
     * @return array{0: Carbon, 1: Carbon, 2: string}
     */
    protected function resolveDateRange(Request $request): array
    {
        // Explicit date range takes priority
        if ($request->filled('date_from') && $request->filled('date_to')) {
            return [
                Carbon::parse($request->input('date_from'))->startOfDay(),
                Carbon::parse($request->input('date_to'))->endOfDay(),
                'custom',
            ];
        }

        $requestedPeriod = (string) $request->input('period', '30d');
        $period = in_array($requestedPeriod, ['7d', '30d', '90d', '1y'], true)
            ? $requestedPeriod
            : '30d';
        $to = now();
        $from = match ($period) {
            '7d' => now()->subDays(7),
            '30d' => now()->subDays(30),
            '90d' => now()->subDays(90),
            '1y' => now()->subYear(),
        };

        return [$from, $to, $period];
    }
}
