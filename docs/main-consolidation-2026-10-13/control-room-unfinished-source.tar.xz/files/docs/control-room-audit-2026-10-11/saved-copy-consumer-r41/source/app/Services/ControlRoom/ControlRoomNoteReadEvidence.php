<?php

namespace App\Services\ControlRoom;

use App\Models\User;
use App\Services\CurrentAuthorizationReads;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Database\Query\Expression;
use Illuminate\Database\Grammar;
use Illuminate\Support\Facades\DB;
use LogicException;

/** Destination stale-evidence refusal only. Canonical CR capability/Site services decide access. */
final class ControlRoomNoteReadEvidence
{
    public const PERMISSIONS = ['controlRoom.reports.view', 'controlRoom.viewAny', 'controlRoom.alerts.view',
        'controlRoom.alerts.manage', 'reports.viewAny', 'medications.controlled.view'];

    public function protect(Builder $query, User $current, CurrentAuthorizationReads $reads, array $keys): Builder
    {
        $reads->assertActive();
        if (! $current->relationLoaded('roles') || ! $current->relationLoaded('permissionOverrides')
            || ! $current->roles->every(fn ($role) => $role->relationLoaded('permissions'))
            || ! $current->relationLoaded('hrEmployeeProfile')) {
            throw new LogicException('Destination notes require the original prepared actor evidence.');
        }
        $this->set($query, DB::table('users')->where('id', $current->id),
            [array_intersect_key($current->getRawOriginal(), array_flip(['id', 'role', 'approved_at', 'external_clinical_account']))]);
        $roles = []; $assignments = []; $grants = []; $overrides = []; $used = [];
        foreach ($current->roles as $role) {
            $roles[] = ['id' => (int) $role->id, 'name' => $role->getRawOriginal('name')];
            $assignments[] = ['role_id' => (int) $role->id, 'user_id' => (int) $current->id];
            foreach ($role->permissions as $permission) {
                if (! in_array($permission->key, $keys, true)) { continue; }
                $used[(int) $permission->id] = ['id' => (int) $permission->id, 'key' => $permission->key];
                $grants[] = ['role_id' => (int) $role->id, 'permission_id' => (int) $permission->id];
            }
        }
        foreach ($current->permissionOverrides as $permission) {
            if (! in_array($permission->key, $keys, true)) { continue; }
            $used[(int) $permission->id] = ['id' => (int) $permission->id, 'key' => $permission->key];
            $overrides[] = ['permission_id' => (int) $permission->id, 'user_id' => (int) $current->id,
                'allowed' => (int) (bool) $permission->pivot->allowed];
        }
        $definitions = $reads->query(DB::table('permissions')->whereIn('key', $keys))->get(['id', 'key'])
            ->map(fn ($row) => (array) $row)->all();
        $this->set($query, DB::table('permissions')->whereIn('key', $keys), $definitions);
        foreach ($used as $row) {
            $query->whereExists($this->row(DB::table('permissions')->where('id', $row['id']), $row)->selectRaw('1'));
        }
        $permissionIds = array_values(array_unique([...array_column($definitions, 'id'), ...array_keys($used)]));
        $roleIds = array_column($roles, 'id');
        $this->set($query, DB::table('role_user')->where('user_id', $current->id), $assignments);
        $this->set($query, DB::table('roles')->whereIn('id', $roleIds), $roles);
        $this->set($query, DB::table('role_permission')->whereIn('role_id', $roleIds)->whereIn('permission_id', $permissionIds), $grants);
        $this->set($query, DB::table('permission_user')->where('user_id', $current->id)->whereIn('permission_id', $permissionIds), $overrides);
        $profile = $current->hrEmployeeProfile;
        $profileRows = $profile === null ? [] : [array_intersect_key($profile->getRawOriginal(),
            array_flip(['id', 'user_id', 'primary_site_id', 'secondary_site_ids', 'is_active', 'start_date', 'end_date', 'deleted_at']))];
        $this->set($query, DB::table('hr_employee_profiles')->where('user_id', $current->id)->whereNull('deleted_at'), $profileRows);
        // Retain the canonical destination Site calculation. Equality is scoped per actual row,
        // so an unrelated Site change does not make every permitted operational row disappear.
        $siteAccess = app(UserSiteAccessService::class);
        $siteIds = $siteAccess->accessibleSiteIds($current, ['reports.viewAny'], $reads);
        $sites = $reads->query(DB::table('sites')->whereIn('id', $siteIds))
            ->get(['id', 'is_active', 'archived', 'archived_at', 'deleted_at'])->map(fn ($row) => (array) $row)->all();
        $effectiveSite = $siteAccess->alertEffectiveSiteExpression($query);
        $query->where(function (Builder $siteGuard) use ($sites, $effectiveSite): void {
            // The independently authorized outer scope continues to decide null-Site admission.
            $siteGuard->whereRaw($effectiveSite.' IS NULL');
            foreach ($sites as $site) {
                $siteGuard->orWhere(fn (Builder $bound) => $bound->whereRaw($effectiveSite.' = ?', [$site['id']])
                    ->whereExists($this->row(DB::table('sites')->where('id', $site['id']), $site)->selectRaw('1')));
            }
        });
        $worker = config('app.worker_timezone'); $fallback = config('app.timezone', 'UTC');
        $zone = (string) ($worker ?: $fallback); $day = now($zone)->toDateString();
        $query->whereRaw(new class($reads, $worker, $fallback, $zone, $day) extends Expression {
            public function __construct(private readonly CurrentAuthorizationReads $reads, private readonly mixed $worker,
                private readonly mixed $fallback, private readonly string $zone, private readonly string $day)
            { parent::__construct('1 = 1'); }
            public function getValue(Grammar $grammar)
            {
                $this->reads->assertActive();
                if (config('app.worker_timezone') !== $this->worker || config('app.timezone', 'UTC') !== $this->fallback
                    || now($this->zone)->toDateString() !== $this->day) {
                    throw new LogicException('Destination authorization date evidence changed.');
                }
                return parent::getValue($grammar);
            }
        });

        return $reads->query($query);
    }

    private function set(Builder $guard, QueryBuilder $selector, array $rows): void
    {
        foreach ($rows as $row) { $guard->whereExists($this->row(clone $selector, $row)->selectRaw('1')); }
        $extra = clone $selector;
        foreach ($rows as $row) { $extra->whereNot(fn (QueryBuilder $match) => $this->row($match, $row)); }
        $guard->whereNotExists($extra->selectRaw('1'));
    }

    private function row(QueryBuilder $query, array $values): QueryBuilder
    {
        foreach ($values as $column => $value) {
            if ($value === null) { $query->whereNull($column); }
            elseif (is_string($value)) { $query->whereRaw('BINARY '.$query->getGrammar()->wrap($column).' = BINARY ?', [$value]); }
            else { $query->where($column, $value); }
        }
        return $query;
    }
}
