<?php

namespace App\Services\ControlRoom;

use App\Models\AuditLog;
use App\Models\ControlRoomAlert;
use App\Models\IncidentSavedCopy;
use App\Models\User;
use App\Services\AuditLogger;
use App\Services\CurrentAuthorizationReads;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\Incidents\IncidentIndependenceBindingSql;
use App\Services\Incidents\IncidentSavedCopyService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use LogicException;

/** Prospective server command only. UNWIRED until all root-note consumers adopt the copied-origin guard. */
final class ControlRoomIncidentNoteCopyWriter
{
    public const PERMISSIONS = [...ControlRoomGovernanceReadService::PERMISSIONS, ...IncidentSavedCopyService::PERMISSIONS,
        'controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage', 'controlRoom.reports.view', 'medications.controlled.view'];

    public function copyField(User $actor, int $alertId, int $incidentId, string $copyUuid, string $field): array
    {
        return HealthSafetyReadContext::within($actor, self::PERMISSIONS, function (HealthSafetyReadContext $context)
            use ($actor, $alertId, $incidentId, $copyUuid, $field): array {
            $context->assertViewer($actor);
            return $context->consumeSourceViewer(self::PERMISSIONS, function (User $current, CurrentAuthorizationReads $reads)
                use ($context, $alertId, $incidentId, $copyUuid, $field): array {
                $access = app(ControlRoomAlertAccessService::class);
                abort_unless($current->canDo('controlRoom.alerts.manage'), 403);
                $query = $access->applyReadableScope(ControlRoomAlert::query()->whereKey($alertId), $current);
                $query = app(ControlRoomNoteReadEvidence::class)->protect($query, $current, $reads, ControlRoomNoteReadEvidence::PERMISSIONS);
                // No notes or full context hydration before source admission. Existing unrelated JSON is retained by SQL.
                $notes = app(ControlRoomCopiedAlertNoteService::class);
                $targetRow = $reads->query($notes->metadata((clone $query)->select(ControlRoomCopiedAlertNoteService::TARGET_COLUMNS)))->first();
                abort_if($targetRow === null, 404);
                $target = $notes->target($targetRow);
                $query = $notes->sameTarget($query, $target);
                $claims = $reads->query(AuditLog::query()->where('meta->origin->copy_uuid', $copyUuid))
                    ->select(['id', 'user_id', 'action', 'auditable_type', 'auditable_id', 'meta'])
                    ->selectRaw(IncidentIndependenceBindingSql::fingerprint('audit', 'audit_logs').' as accepted_receipt_fp')->get();
                $knownSourceIdentity = $reads->query(IncidentSavedCopy::query()->where('copy_uuid', $copyUuid))->exists();
                if ($claims->isEmpty() && $knownSourceIdentity) {
                    throw new LogicException('A retained source identity cannot recreate a missing destination acceptance.');
                }
                if ($claims->isNotEmpty() && ($claims->count() !== 1
                    || $claims->sole()->action !== ControlRoomCopiedAlertNoteService::ACTION
                    || $claims->sole()->auditable_type !== $targetRow->getMorphClass()
                    || (int) $claims->sole()->auditable_id !== $alertId || (int) $claims->sole()->user_id !== (int) $current->id
                    || ! $notes->same($claims->sole()->meta['target'] ?? null, $target))) {
                    throw new LogicException('Original destination copy identity changed.');
                }
                $copies = app(IncidentSavedCopyService::class);
                $captured = $copies->capture($context, $incidentId, $copyUuid,
                    IncidentSavedCopyService::ALERT_NOTES_TARGET, (string) $alertId, $field);
                $origin = array_intersect_key($captured, array_flip(ControlRoomCopiedAlertNoteService::ORIGIN_KEYS));
                $meta = ['origin' => $origin, 'target' => $target,
                    'text_sha256' => hash('sha256', $captured['copy']['text']), 'actor_id' => (int) $current->id];
                // CR claims use nested origin.copy_uuid, keeping the source's sole root-level UUID capture claim intact.
                if ($claims->isNotEmpty()) {
                    if ($claims->count() !== 1 || $claims->sole()->action !== ControlRoomCopiedAlertNoteService::ACTION
                        || $claims->sole()->auditable_type !== $targetRow->getMorphClass()
                        || (int) $claims->sole()->auditable_id !== $alertId || (int) $claims->sole()->user_id !== (int) $current->id
                        || ! $notes->same($claims->sole()->meta, $meta)) {
                        throw new LogicException('Original destination copy identity changed.');
                    }
                    $originalOriginJson = json_encode($origin, JSON_THROW_ON_ERROR);
                    $originalAuditId = (int) $claims->sole()->id;
                    $originalReceiptFp = $claims->sole()->getRawOriginal('accepted_receipt_fp');
                    $replay = (clone $query)
                        ->whereRaw("BINARY CAST(JSON_EXTRACT(control_room_alerts.context, '$.saved_incident_copy') AS CHAR) = BINARY CAST(CAST(? AS JSON) AS CHAR)", [$originalOriginJson])
                        ->where('control_room_alerts.context->saved_incident_copy_audit_id', $originalAuditId)
                        ->whereExists(fn ($receipt) => $receipt->selectRaw('1')->from('audit_logs as replay_original_receipt')
                            ->where('replay_original_receipt.id', $originalAuditId)
                            ->whereRaw(IncidentIndependenceBindingSql::fingerprint('audit', 'replay_original_receipt').' = ?', [$originalReceiptFp]));
                    $metadata = $notes->metadata((clone $replay)->select(ControlRoomCopiedAlertNoteService::TARGET_COLUMNS))->first();
                    if ($metadata === null) { throw new LogicException('Original destination is no longer readable.'); }
                    $read = $notes->forExport($metadata, fn (): Builder => clone $replay, $current, $context, $reads, $replay);
                    if ($read['notes'] !== $captured['copy']['text']) { throw new LogicException('Original destination copy requires repair.'); }
                    if (! $reads->query((clone $replay)->whereRaw('BINARY control_room_alerts.notes = BINARY ?', [$captured['copy']['text']]))->exists()) {
                        throw new LogicException('Original replay acceptance changed after materialisation.');
                    }
                    return ['alert_id' => $alertId, 'copy_uuid' => $copyUuid, 'audit_id' => (int) $claims->sole()->id];
                }
                $request = clone request(); $request->setUserResolver(fn () => $current);
                AuditLogger::logOrFail(ControlRoomCopiedAlertNoteService::ACTION, $targetRow, $meta, $request);
                $audit = $reads->query(AuditLog::query()->where('meta->origin->copy_uuid', $copyUuid))
                    ->select(['id', 'user_id', 'action', 'auditable_type', 'auditable_id', 'meta'])
                    ->selectRaw(IncidentIndependenceBindingSql::fingerprint('audit', 'audit_logs').' as original_receipt_fp')->sole();
                if ($audit->action !== ControlRoomCopiedAlertNoteService::ACTION || (int) $audit->user_id !== (int) $current->id
                    || $audit->auditable_type !== $targetRow->getMorphClass() || (int) $audit->auditable_id !== $alertId
                    || ! $notes->same($audit->meta, $meta)) { throw new LogicException('Destination copy audit was not persisted exactly.'); }
                $auditId = (int) $audit->id;
                $originalReceiptFingerprint = $audit->getRawOriginal('original_receipt_fp');
                $originJson = json_encode($origin, JSON_THROW_ON_ERROR);
                $result = $copies->consumeProjectedCopy($context, $origin,
                    function (array $copy, CurrentAuthorizationReads $sameReads, Builder $protectedCopy)
                        use ($query, $target, $originJson, $auditId, $originalReceiptFingerprint, $context, $current, $notes, $meta, $alertId, $copyUuid): array {
                        if (! hash_equals($meta['text_sha256'], hash('sha256', $copy['text']))) {
                            throw new LogicException('The source field changed before destination acceptance.');
                        }
                        $protectedCopy = $notes->correlateSource($protectedCopy, $target);
                        $write = (clone $query)->whereExists((clone $protectedCopy)->reorder()->select('incident_saved_copies.id')->toBase());
                        $write->whereExists(fn ($receipt) => $receipt->selectRaw('1')->from('audit_logs as original_write_receipt')
                            ->where('original_write_receipt.id', $auditId)
                            ->whereRaw(IncidentIndependenceBindingSql::fingerprint('audit', 'original_write_receipt').' = ?', [$originalReceiptFingerprint]));
                        // Always invalidate operator/source ownership on overwrite, including identical note bytes.
                        $contextSql = "JSON_SET(JSON_REMOVE(COALESCE(context, JSON_OBJECT()), '$.root_note_origin', '$.notes_provenance'), "
                            ."'$.saved_incident_copy', CAST(? AS JSON), '$.saved_incident_copy_audit_id', ?)";
                        $base = $sameReads->query($write->toBase());
                        // Query Builder supports a bound scalar subquery as an update value.
                        // Both JSON metadata and source text use ordinary value bindings.
                        $contextValue = DB::query()->selectRaw($contextSql, [$originJson, $auditId]);
                        $changed = $base->update(['notes' => $copy['text'], 'context' => $contextValue, 'updated_at' => now()]);
                        if ($changed !== 1) { throw new LogicException('Destination copy was not accepted.'); }
                        $accepted = (clone $write)
                            ->whereRaw("BINARY CAST(JSON_EXTRACT(control_room_alerts.context, '$.saved_incident_copy') AS CHAR) = BINARY CAST(CAST(? AS JSON) AS CHAR)", [$originJson])
                            ->where('control_room_alerts.context->saved_incident_copy_audit_id', $auditId)
                            ->whereRaw("JSON_CONTAINS_PATH(COALESCE(control_room_alerts.context, JSON_OBJECT()), 'one', '$.root_note_origin', '$.notes_provenance') = 0");
                        $metadata = $notes->metadata((clone $accepted)->select(ControlRoomCopiedAlertNoteService::TARGET_COLUMNS))->first();
                        if ($metadata === null) { throw new LogicException('Destination identity changed after writing.'); }
                        $projected = $notes->forExport($metadata, fn (): Builder => clone $accepted, $current, $context, $sameReads, $accepted);
                        if ($projected['notes'] !== $copy['text']) { throw new LogicException('Destination copy did not survive its original acceptance.'); }
                        if (! $sameReads->query((clone $accepted)->whereRaw('BINARY control_room_alerts.notes = BINARY ?', [$copy['text']]))->exists()) {
                            throw new LogicException('Original destination acceptance changed after materialisation.');
                        }
                        return ['alert_id' => $alertId, 'copy_uuid' => $copyUuid, 'audit_id' => $auditId];
                    });
                if (! $result['available']) { throw new LogicException('Original source proof changed during destination acceptance.'); }
                return $result['result'];
            });
        });
    }
}
