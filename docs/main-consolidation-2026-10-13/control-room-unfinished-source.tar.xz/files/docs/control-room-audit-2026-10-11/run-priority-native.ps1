$ErrorActionPreference = 'Stop'
$candidatePath = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
Set-Location -LiteralPath $candidatePath
. (Join-Path $candidatePath 'docs/control-room-audit-2026-10-11/control-room-resource-proof.ps1')
$gate = [Threading.Mutex]::new($false, 'Local\OblivionWorkforceMainIntegrationNativeGate')
$gateHeld = $false
$priorEnvironment = @{}
foreach ($name in @('APP_ENV','APP_BASE_PATH','LARAVEL_STORAGE_PATH','CACHE_STORE','SESSION_DRIVER','QUEUE_CONNECTION','MAIL_MAILER','BROADCAST_CONNECTION','DB_CONNECTION','DB_DATABASE','DB_HOST','DB_PORT','DB_USERNAME','DB_PASSWORD','MYSQL_TEST_SCHEMA_REQUIRE_NATIVE','MYSQL_TEST_SCHEMA_PATH')) {
    $priorEnvironment[$name] = [Environment]::GetEnvironmentVariable($name,'Process')
}
try {
    try { $gateHeld = $gate.WaitOne(0) } catch [Threading.AbandonedMutexException] { $gateHeld = $true }
    if (-not $gateHeld) { Write-Output 'HELD: shared verification gate is occupied; no child or schema launched.'; exit 75 }
$runStamp = (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss')
$evidencePath = Join-Path $candidatePath ('test-results/control-room-priority-native-' + $runStamp)
New-Item -ItemType Directory -Path $evidencePath -Force | Out-Null
$samples = @()
for ($sample = 0; $sample -lt 2; $sample++) {
    $proof = Get-ControlRoomResourceProof
    $samples += $proof
    Assert-ControlRoomResourceProof $proof
    if ($sample -eq 0) { Start-Sleep -Seconds 2 }
}
$pins = @('composer.json','composer.lock', 'vendor/composer/installed.json','vendor/composer/autoload_real.php','vendor/composer/autoload_static.php',
    'C:\Users\steph\.config\herd\bin\php84\php.exe','phpunit.xml', 'database/schema/mysql-schema.sql', 'bootstrap/app.php', 'bootstrap/providers.php',
    'docs/control-room-audit-2026-10-11/run-priority-native.ps1', 'docs/control-room-audit-2026-10-11/verify-native-cleanup.php',
    'docs/control-room-audit-2026-10-11/control-room-resource-proof.ps1') + @(Get-ControlRoomResourceInputPaths) +
    @(Get-ChildItem -LiteralPath @('app', 'routes', 'tests', 'database/migrations', 'database/seeders', 'database/factories', 'config') -Recurse -File -Filter '*.php' |
        ForEach-Object { [System.IO.Path]::GetRelativePath($candidatePath, $_.FullName) } | Sort-Object)
$before = @($pins | ForEach-Object { [pscustomobject]@{ path = $_; hash = (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash } })
$samples | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $evidencePath 'admission.json')
$before | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $evidencePath 'source-before.json')
# A URL, socket, cached configuration or process token can override the PID
# namespace even when DB_DATABASE is set. Hold before any connection/child.
$unsafeEnvironment = @('DB_URL','DB_SOCKET','APP_CONFIG_CACHE','TEST_TOKEN','PARALLEL_PROCESS','PROCESS_TOKEN') |
    Where-Object { -not [string]::IsNullOrEmpty([Environment]::GetEnvironmentVariable($_,'Process')) }
$unsafeFiles = @('.env','.env.testing','bootstrap/cache/config.php') | Where-Object { Test-Path -LiteralPath $_ }
if (@($unsafeEnvironment).Count -gt 0 -or @($unsafeFiles).Count -gt 0) {
    [pscustomobject]@{runtimeStarted=$false;databaseOpened=$false;environmentOverrideNames=@($unsafeEnvironment);configurationFiles=@($unsafeFiles)} |
        ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $evidencePath 'environment-held.json')
    Write-Output 'HELD: an environment/configuration override requires an explicit isolated native configuration. No child or connection launched.'
    exit 75
}
$nativeConfig = [xml](Get-Content -LiteralPath 'phpunit.xml' -Raw)
foreach ($name in @('DB_URL','DB_SOCKET','APP_CONFIG_CACHE','TEST_TOKEN','PARALLEL_PROCESS','PROCESS_TOKEN')) {
    foreach ($entry in $nativeConfig.SelectNodes("/phpunit/php/env[@name='$name']")) {
        if (-not [string]::IsNullOrEmpty($entry.GetAttribute('value'))) {
            throw 'HELD: original test configuration contains a connection/cache/token override.'
        }
    }
}
$nativeTuple = @{}
foreach ($name in @('DB_HOST','DB_PORT','DB_USERNAME','DB_PASSWORD')) {
    $entries = $nativeConfig.SelectNodes("/phpunit/php/env[@name='$name']")
    if ($entries.Count -ne 1) { throw 'HELD: original test connection is missing or ambiguous.' }
    $nativeTuple[$name] = $entries[0].GetAttribute('value')
}
if ($nativeTuple.DB_HOST -notin @('127.0.0.1','localhost','::1') -or
    $nativeTuple.DB_PORT -notmatch '^\d+$' -or [int]$nativeTuple.DB_PORT -lt 1 -or [int]$nativeTuple.DB_PORT -gt 65535) {
    throw 'HELD: the approved native connection must be local.'
}
$databaseEntry = $nativeConfig.SelectSingleNode("/phpunit/php/env[@name='DB_DATABASE']")
if ($null -eq $databaseEntry -or $databaseEntry.GetAttribute('force') -eq 'true') {
    throw 'HELD: original configuration would override the isolated database base.'
}
foreach ($name in $nativeTuple.Keys) { [Environment]::SetEnvironmentVariable($name,$nativeTuple[$name],'Process') }
$env:APP_ENV = 'testing'
$env:APP_BASE_PATH = $candidatePath
$env:LARAVEL_STORAGE_PATH = Join-Path $candidatePath 'storage'
$env:CACHE_STORE = 'array'
$env:SESSION_DRIVER = 'array'
$env:QUEUE_CONNECTION = 'sync'
$env:MAIL_MAILER = 'array'
$env:BROADCAST_CONNECTION = 'null'
$env:DB_CONNECTION = 'mysql'
$env:DB_DATABASE = 'oblivion_cr_delivery_test_priority_20261011'
$env:MYSQL_TEST_SCHEMA_REQUIRE_NATIVE = 'true'
$env:MYSQL_TEST_SCHEMA_PATH = Join-Path $candidatePath 'database/schema/mysql-schema.sql'
& 'C:\Users\steph\.config\herd\bin\php84\php.exe' -d memory_limit=128M 'docs/control-room-audit-2026-10-11/verify-native-cleanup.php' `
    (Join-Path $evidencePath 'namespace-before.json') 'prelaunch'
if ($LASTEXITCODE -ne 0) { Write-Output 'HELD: isolated native schema namespace is not absent. No test/import child launched.'; exit 75 }
& 'C:\Users\steph\.config\herd\bin\php84\php.exe' -d memory_limit=1024M 'vendor/bin/pest' `
    'tests/Unit/ControlRoom/AlertPriorityServiceTest.php' `
    'tests/Feature/ControlRoom/ControlRoomDeskTest.php' `
    'tests/Feature/ControlRoom/ControlRoomEscalationControllerTest.php' `
    --do-not-cache-result --log-junit (Join-Path $evidencePath 'junit.xml') *> (Join-Path $evidencePath 'output.log')
$resultExit = $LASTEXITCODE
& 'C:\Users\steph\.config\herd\bin\php84\php.exe' -d memory_limit=128M 'docs/control-room-audit-2026-10-11/verify-native-cleanup.php' `
    (Join-Path $evidencePath 'cleanup.json')
$cleanupExit = $LASTEXITCODE
$after = @($pins | ForEach-Object { [pscustomobject]@{ path = $_; hash = (Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash } })
$beforeByPath = @{}
foreach ($pin in $before) { $beforeByPath[$pin.path] = $pin.hash }
$drift = @($after | Where-Object { $beforeByPath[$_.path] -ne $_.hash })
[pscustomobject]@{
    exitCode = $resultExit; cleanupExitCode = $cleanupExit; admission = $samples; before = $before; after = $after; drift = $drift
    databaseBase = $env:DB_DATABASE; importer = 'existing Tests/TestCase native-only importer and PID cleanup'
    schema = $env:MYSQL_TEST_SCHEMA_PATH; terminal = (Get-Date).ToUniversalTime().ToString('o')
} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $evidencePath 'receipt.json')
Get-Content -LiteralPath (Join-Path $evidencePath 'output.log') -Tail 45
if ($drift.Count -gt 0) { Write-Output 'Verification source drift detected'; exit 76 }
if ($cleanupExit -ne 0) { exit $cleanupExit }
exit $resultExit
} finally {
    try {
        foreach ($name in $priorEnvironment.Keys) { [Environment]::SetEnvironmentVariable($name,$priorEnvironment[$name],'Process') }
    } finally {
        try { if ($gateHeld) { $gate.ReleaseMutex() } } finally { $gate.Dispose() }
    }
}
