param(
    [switch] $Prepare,
    [ValidateSet('format', 'lint', 'component')] [string] $Phase = 'format',
    [ValidatePattern('^[a-z0-9-]{1,40}$')] [string] $Attempt = 'a',
    [string] $ExpectedInputsSha256
)
$ErrorActionPreference = 'Stop'
$crRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$crMain = 'C:\Users\steph\Herd\oblivionfindings'
$crDeps = 'C:\Users\steph\.codex\worktrees\workforce-improvements\oblivionfindings\node_modules'
$crNode = 'C:\Program Files\nodejs\node.exe'
$crDocs = Join-Path $crRoot 'docs/control-room-audit-2026-10-11'
$crInputsPath = Join-Path $crDocs 'owned-frontend-inputs-r31.json'
$crConfig = Join-Path $crDocs 'owned-frontend-r31.vitest.config.ts'
$crClassifier = 'C:\Users\steph\.codex\worktrees\health-safety-workspace\oblivionfindings\.playwright-cli\hs-process-classifier.ps1'
$crClassifierSha = '19B90A2B70EF320A0FD639AA8752111A16E88513AC9FB98198AC84596D232DEC'
$crUtf8 = [Text.UTF8Encoding]::new($false)
function Get-CrHash([string] $Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Write-CrJson([string] $Path, $Value) { [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 30) + "`n", $crUtf8) }
function Assert-CrDependencyLink {
    $link = Get-Item -LiteralPath (Join-Path $crRoot 'node_modules')
    $targets = @($link.Target)
    if ($link.LinkType -ne 'Junction' -or $targets.Count -ne 1 -or $targets[0] -ne $crDeps -or (Get-Item -LiteralPath $crDeps).LinkType) { throw 'Unexpected dependency junction or physical target.' }
}
Assert-CrDependencyLink
$crOldReady = Get-Content -LiteralPath (Join-Path $crDocs 'frontend-readiness.json') -Raw | ConvertFrom-Json
$crTargets = @('resources/js/pages/control-room/shifts/accepted-handover-history.tsx') + @($crOldReady.ownedFormatAndLintPaths) + @('resources/js/pages/control-room/shifts/handover.tsx', 'resources/js/pages/control-room/shifts/handover.test.tsx', 'resources/js/pages/control-room/shifts.test.tsx')
$crTests = @($crOldReady.completeTestFiles.path) + @('resources/js/pages/control-room/shifts/handover.test.tsx', 'resources/js/pages/control-room/shifts.test.tsx')
if ($crTargets.Count -ne 30 -or $crTests.Count -ne 6) { throw 'Existing exact owned frontend inventory changed.' }
if ($Prepare) {
    if (Test-Path -LiteralPath $crInputsPath) { throw 'Preserve earlier source input image; create a named successor after any source repair.' }
    $paths = @($PSCommandPath, $crConfig, $crClassifier, $crNode) + @($crTargets | ForEach-Object { Join-Path $crRoot $_ })
    foreach ($pin in $crOldReady.inputs) {
        if (-not [IO.Path]::IsPathRooted($pin.path)) { $paths += Join-Path $crRoot $pin.path }
        elseif ($pin.path.StartsWith($crDeps, [StringComparison]::OrdinalIgnoreCase)) { $paths += $pin.path }
    }
    # Reuse the reviewed finite runtime import inventories as file lists, taking
    # fresh bytes from THIS dependency installation. No peer runner is executed.
    foreach ($inventory in @('timesheet-post-lint-runtime-inputs-20261012.json', 'timesheet-owned-eslint-runtime-pins-20261012.json')) {
        $inventoryPath = Join-Path $crMain "test-results/$inventory"
        $runtime = Get-Content -LiteralPath $inventoryPath -Raw | ConvertFrom-Json -AsHashtable
        foreach ($path in $runtime.inputs.Keys) {
            $marker = [regex]::Match($path, '(?i)[\\/]node_modules[\\/](.*)$')
            if ($marker.Success) { $paths += Join-Path $crDeps $marker.Groups[1].Value }
        }
        $paths += $inventoryPath
    }
    $paths += Join-Path $crMain 'docs/control-room-audit-2026-10-11/APPROVED-SCOPE.txt'
    # Current policy is recorded, not a mutable peer-source freeze during a job.
    $pins = @($paths | Sort-Object -Unique | ForEach-Object { [pscustomobject]@{ path = $_; sha256 = Get-CrHash $_ } })
    Write-CrJson $crInputsPath ([ordered]@{
        preparedAtUtc = [DateTime]::UtcNow.ToString('o'); candidate = $crRoot; dependencyRoot = $crDeps; sourcePins = $pins
        targets = $crTargets; wholeTestFiles = $crTests; expectedAuthoredCases = 33
        policyReadSha256 = Get-CrHash (Join-Path $crMain 'docs/control-room-audit-2026-10-11/COORDINATION-STATUS.txt')
        scope = 'Finite candidate-only no-DB formatter check/lint/component; historical frontend failures retained; no shared source application'
        classifierSha256 = $crClassifierSha; maxHeapMainMiB = 512; maxHeapSingleWorkerMiB = 512; maxCombinedHeapMiB = 1024
        deadlineSeconds = 60; unknownHostsClassifiedIdle = $false; phpDatabaseBuildBrowser = $false
    })
    [pscustomobject]@{ prepared = $true; inputCount = $pins.Count; inputsSha256 = Get-CrHash $crInputsPath; nodeStarted = $false } | ConvertTo-Json
    exit 0
}
if ($ExpectedInputsSha256 -notmatch '^[A-Fa-f0-9]{64}$' -or (Get-CrHash $crInputsPath) -ne $ExpectedInputsSha256) { throw 'Reviewed finite input image mismatch; no child.' }
$crImage = Get-Content -LiteralPath $crInputsPath -Raw | ConvertFrom-Json
function Test-CrPins {
    Assert-CrDependencyLink
    if ((Get-CrHash $crInputsPath) -ne $ExpectedInputsSha256) { throw 'Input image changed.' }
    foreach ($pin in $crImage.sourcePins) { if ((Get-CrHash $pin.path) -ne $pin.sha256) { throw "Input changed: $($pin.path)" } }
    if (Test-Path -LiteralPath (Join-Path $crRoot 'eslint-suppressions.json')) { throw 'Unreviewed ESLint suppression file.' }
}
Test-CrPins
$crClassifierBytes = [IO.File]::ReadAllBytes($crClassifier)
if ([Convert]::ToHexString([Security.Cryptography.SHA256]::HashData($crClassifierBytes)) -ne $crClassifierSha) { throw 'Reviewed pure heavy-first classifier changed.' }
. ([ScriptBlock]::Create([Text.Encoding]::UTF8.GetString($crClassifierBytes)))
$crOut = Join-Path $crRoot "test-results/control-room-owned-$Phase-$Attempt-20261012"
if (Test-Path -LiteralPath $crOut) { throw 'Earlier attempt evidence must remain intact.' }
New-Item -ItemType Directory -Path $crOut | Out-Null
$crGate = [Threading.Mutex]::new($false, 'Local\OblivionWorkforceMainIntegrationNativeGate')
$crHeld = $false; $crStarted = $false; $crChild = $null; $crExit = $null; $crIssue = $null; $crAfter = $false; $crOwnClosed = $false; $crStreamsClosed = $false
$crSamples = @(); $crOwnRows = @(); $crStdout = $null; $crStderr = $null; $crReport = $null
function Read-CrAdmission {
    $os = @(Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10)
    $cpu = @(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
    $rows = @(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    if ($os.Count -ne 1 -or !$os[0].FreePhysicalMemory -or $cpu.Count -ne 1 -or $null -eq $cpu[0].PercentProcessorTime -or $cpu[0].PercentProcessorTime -lt 0 -or $cpu[0].PercentProcessorTime -gt 100 -or $rows.Count -eq 0 -or
        @($rows | Group-Object ProcessId | Where-Object Count -ne 1).Count -gt 0 -or
        @($rows | Where-Object { $null -eq $_.ProcessId -or !$_.Name -or ($_.Name -in @('node.exe', 'php.exe', 'php-cgi.exe', 'mysql.exe') -and !$_.CommandLine) }).Count -gt 0) { throw 'Incomplete/invalid current process or resource observations.' }
    $ownIds = @()
    if ($crStarted -and !$crChild.HasExited) {
        $ownIds = @($crChild.Id)
        $rootRow = $rows | Where-Object ProcessId -eq $crChild.Id
        if (@($rootRow).Count -ne 1 -or !$rootRow.CreationDate -or $rootRow.ExecutablePath -ne $crNode) { throw 'Own child identity observation incomplete.' }
        do {
            $more = @($rows | Where-Object { $_.ParentProcessId -in $ownIds -and $_.ProcessId -notin $ownIds -and $_.CreationDate -ge $rootRow.CreationDate } | ForEach-Object ProcessId)
            $ownIds += $more
        } while ($more.Count -gt 0)
        $script:crOwnRows += @($rows | Where-Object ProcessId -in $ownIds | ForEach-Object { @{ pid = $_.ProcessId; parent = $_.ParentProcessId; name = $_.Name; executable = $_.ExecutablePath; birthUtc = $_.CreationDate.ToUniversalTime().ToString('o') } })
    }
    $peers = @($rows | Where-Object ProcessId -notin $ownIds)
    $classification = Get-ProcessClassification -ObservedProcesses $peers -ToolServiceIdentity $null
    $unknownNative = @($peers | Where-Object { $_.ProcessId -in $classification.unknownIds -and $_.Name -ne 'node.exe' } | ForEach-Object ProcessId)
    $heavy = @($classification.heavyNodeIds) + @($classification.competingNativeIds) + $unknownNative
    $sample = [ordered]@{
        utc = [DateTime]::UtcNow.ToString('o'); valid = $true; freeMiB = [math]::Floor($os[0].FreePhysicalMemory / 1024); cpuPercent = [int]$cpu[0].PercentProcessorTime
        completeProcessCount = $rows.Count; nodeCount = @($rows | Where-Object Name -eq 'node.exe').Count; heavyPeerIds = $heavy
        unknownNodeObservations = @($peers | Where-Object { $_.Name -eq 'node.exe' -and $_.ProcessId -in $classification.unknownIds } | ForEach-Object {
            @{ pid = $_.ProcessId; parent = $_.ParentProcessId; executable = $_.ExecutablePath; birthUtc = $(if ($_.CreationDate) { $_.CreationDate.ToUniversalTime().ToString('o') } else { $null }); classification = 'UNKNOWN' }
        }); unknownHostsClassifiedIdle = $false; ownDescendantIds = $ownIds
    }
    $script:crSamples += $sample
    if ($sample.freeMiB -lt 4096 -or $sample.cpuPercent -ge 70 -or $heavy.Count -gt 0) { throw 'Current finite-job capacity/heavy-peer admission held.' }
}
try {
    try { $crHeld = $crGate.WaitOne(0) } catch [Threading.AbandonedMutexException] { $crHeld = $true }
    if (!$crHeld) { throw 'Shared mutex busy; priority remains with the next naturally safe Workforce window.' }
    Read-CrAdmission
    Start-Sleep -Milliseconds 500
    Read-CrAdmission
    Test-CrPins
    # Repeat capacity immediately after file reads, directly before launch.
    Read-CrAdmission
    $info = [Diagnostics.ProcessStartInfo]::new()
    $info.FileName = $crNode; $info.WorkingDirectory = $crRoot; $info.UseShellExecute = $false; $info.CreateNoWindow = $true
    $info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
    $info.Environment['NODE_OPTIONS'] = '--max-old-space-size=512'
    $arguments = switch ($Phase) {
        'format' { @('--max-old-space-size=512', (Join-Path $crDeps 'prettier/bin/prettier.cjs'), '--check') + $crTargets }
        'lint' { @('--max-old-space-size=512', (Join-Path $crDeps 'eslint/bin/eslint.js'), '--config', (Join-Path $crRoot 'eslint.config.js'), '--concurrency=off', '--no-cache', '--max-warnings=0', '--format=json', '--output-file', (Join-Path $crOut 'eslint.json')) + $crTargets }
        'component' { @('--max-old-space-size=512', (Join-Path $crDeps 'vitest/vitest.mjs'), 'run', '--config', $crConfig, '--configLoader', 'runner', '--pool=forks', '--maxWorkers=1', '--no-file-parallelism', '--reporter=default', '--reporter=json', '--outputFile', (Join-Path $crOut 'vitest.json')) + $crTests }
    }
    foreach ($argument in $arguments) { $info.ArgumentList.Add($argument) }
    $crChild = [Diagnostics.Process]::new(); $crChild.StartInfo = $info
    if (!$crChild.Start()) { throw 'Own finite child did not start.' }
    $crStarted = $true
    $crStdout = $crChild.StandardOutput.ReadToEndAsync(); $crStderr = $crChild.StandardError.ReadToEndAsync()
    $timer = [Diagnostics.Stopwatch]::StartNew(); $lastObservation = 0
    while (!$crChild.WaitForExit(1000)) {
        if ($timer.Elapsed.TotalSeconds -ge 60) { throw 'Own job exceeded cooperative 60-second deadline.' }
        if ($timer.Elapsed.TotalSeconds - $lastObservation -ge 3) { Read-CrAdmission; $lastObservation = $timer.Elapsed.TotalSeconds }
    }
    $crExit = $crChild.ExitCode
    if ($Phase -ne 'format') {
        $reportFile = if ($Phase -eq 'lint') { 'eslint.json' } else { 'vitest.json' }
        $crReport = Get-Content -LiteralPath (Join-Path $crOut $reportFile) -Raw | ConvertFrom-Json
        if ($Phase -eq 'lint' -and @($crReport).Count -ne $crTargets.Count) { throw 'Incomplete exact owned lint report.' }
        if ($Phase -eq 'component' -and ($crReport.numTotalTests -ne 33 -or @($crReport.testResults).Count -ne 6)) { throw 'Incomplete six-whole-suite report; retain actual counts.' }
    }
    if ($crExit -ne 0) { throw 'Actual owned check failed; retain complete logs and report.' }
} catch { $crIssue = $_.Exception.Message }
finally {
    try {
        if ($crStarted -and !$crChild.HasExited) {
            # Only the held Process object launched above and its own children.
            $crChild.Kill($true)
            if (!$crChild.WaitForExit(10000)) { throw 'Own child exit not confirmed.' }
        }
        $crOwnClosed = !$crStarted -or $crChild.HasExited
        if ($crStarted -and $crOwnClosed) {
            $crStreamsClosed = $crStdout.Wait(3000) -and $crStderr.Wait(3000)
            if (!$crStreamsClosed) { throw 'Own output streams not completely closed.' }
            [IO.File]::WriteAllText((Join-Path $crOut 'stdout.log'), $crStdout.Result, $crUtf8)
            [IO.File]::WriteAllText((Join-Path $crOut 'stderr.log'), $crStderr.Result, $crUtf8)
        }
        Test-CrPins; $crAfter = $true
    } catch { $crIssue = $_.Exception.Message }
    finally {
        if ($crHeld) { $crGate.ReleaseMutex() }
        $crGate.Dispose()
        if ($crChild) { $crChild.Dispose() }
    }
}
$result = [ordered]@{
    state = $(if ($crStarted -and $crExit -eq 0 -and !$crIssue -and $crAfter -and $crOwnClosed -and $crStreamsClosed) { 'ACTUAL_OWNED_CHECK_PASSED' } else { 'HELD_OR_FAILED' })
    phase = $Phase; attempt = $Attempt; started = $crStarted; issue = $crIssue; actualExit = $crExit; inputImageSha256 = $ExpectedInputsSha256
    resources = $crSamples; ownChildObservations = $crOwnRows; afterReadComplete = $crAfter; ownChildExitConfirmed = $crOwnClosed; outputStreamsClosed = $crStreamsClosed
    sourcePinCount = $crImage.sourcePins.Count; exactOwnedPaths = $crTargets; wholeComponentFiles = $crTests
    actualTestTotal = $(if ($Phase -eq 'component' -and $crReport) { $crReport.numTotalTests } else { $null })
    actualTestPassed = $(if ($Phase -eq 'component' -and $crReport) { $crReport.numPassedTests } else { $null })
    actualTestFailed = $(if ($Phase -eq 'component' -and $crReport) { $crReport.numFailedTests } else { $null })
    maximumCombinedHeapMiB = 1024; deadlineSeconds = 60; singleWorker = $true; fileParallelism = $false
    unknownHostsClassifiedIdle = $false; phpDatabaseBuildBrowser = $false; runtimeFullAcceptance = $false; overallAudit = 'INCOMPLETE'
}
Write-CrJson (Join-Path $crOut 'result.json') $result
([pscustomobject]$result) | Select-Object state,phase,started,issue,actualExit,sourcePinCount,afterReadComplete,actualTestTotal,actualTestPassed,actualTestFailed | ConvertTo-Json
exit $(if ($result.state -eq 'ACTUAL_OWNED_CHECK_PASSED') { 0 } else { 1 })
