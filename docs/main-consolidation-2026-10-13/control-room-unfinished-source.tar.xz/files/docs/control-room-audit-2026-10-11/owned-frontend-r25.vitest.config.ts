import path from 'node:path';
import base from '../../vitest.config';

// Use the candidate's actual aliases, setup and jsdom environment. Keep every
// cache in this candidate, away from the read-only shared dependency junction.
export default {
    ...base,
    cacheDir: path.resolve(__dirname, '../../test-results/control-room-owned-cache'),
    test: {
        ...base.test,
        include: [
            'resources/js/components/command-centre/command-centre-page.test.tsx',
            'resources/js/lib/control-room-navigation.test.ts',
            'resources/js/pages/control-room/_settings-dialogs.test.tsx',
            'resources/js/pages/control-room/_settings-time.test.ts', 
            'resources/js/pages/control-room/shifts/handover.test.tsx',
            'resources/js/pages/control-room/shifts.test.tsx',
        ],
        pool: 'forks',
        maxWorkers: 1,
        fileParallelism: false,
    },
};
