<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoom\OperatorNote;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

/** Projects saved copies only from proven CR independent-note origin; no H&S source policy. */
final class ControlRoomAcceptedHandoverNoteService
{
    public function project(Shift $outgoing, array $saved, User $viewer, HealthSafetyReadContext $context): array
    {
        $context->assertViewer($viewer);
        $entries = collect([...$saved['pinned_notes'], ...$saved['followup_notes']])->groupBy('id');
        if ($entries->isEmpty()) {
            return ['notes' => [], 'status' => 'available', 'message' => null];
        }
        $rawEntries = collect([...($outgoing->handover_snapshot['pinned_notes'] ?? []),
            ...($outgoing->handover_snapshot['followup_notes'] ?? [])])->groupBy('id');
        $notes = $context->query(OperatorNote::query()->whereKey($entries->keys()->all())
            ->where('shift_id', $outgoing->id))->get()->keyBy('id');
        $alertIds = $entries->flatten(1)->pluck('alert_id')->filter()->unique()->values()->all();
        $readableIds = $alertIds === [] ? []
            : app(ControlRoomHandoverScopeService::class)->visibleAlertIds($viewer, $alertIds, $context)->all();
        $alerts = $context->query(ControlRoomAlert::query()->whereKey($readableIds))->get(['id', 'site_id', 'client_id'])->keyBy('id');
        $actors = $context->query(User::query()->whereKey($notes->pluck('user_id')->unique()->all()))->pluck('id')->map(fn ($id) => (int) $id)->all();
        $audits = DB::table('audit_logs')->where('action', 'controlRoom.shift.noteAdded')
            ->where('auditable_type', $outgoing->getMorphClass())->where('auditable_id', $outgoing->id)
            ->whereIn('meta->note_id', $entries->keys()->all())->get(['action', 'auditable_type', 'auditable_id', 'user_id', 'meta']);
        $available = [];
        $unavailable = false;
        foreach ($entries as $id => $copies) {
            $copy = $copies->first();
            $rawCopies = $rawEntries->get($id);
            $note = $notes->get($id);
            if ($copies->contains(fn ($candidate) => $candidate !== $copy)
                || $rawCopies === null || $rawCopies->count() !== $copies->count()
                || $rawCopies->contains(fn ($candidate) => $candidate !== $rawCopies->first())
                || $note === null || ! in_array((int) $note->user_id, $actors, true)
                || ! $this->verified($note, $copy, $rawCopies->first(), $outgoing, $alerts, $audits)) {
                $unavailable = true;
                continue;
            }
            // Preserve the saved content/flags/time. Do not substitute today's note.
            unset($copy['operator_origin']);
            $available[] = $copy;
        }

        return [
            'notes' => $available,
            'status' => $unavailable ? ($available === [] ? 'unavailable' : 'partially_available') : 'available',
            // No withheld IDs, actors, source text or private-family counts escape.
            'message' => $unavailable
                ? 'Some saved notes are unavailable because their original context or current access cannot be verified.'
                : null,
        ];
    }

    private function verified(OperatorNote $note, array $copy, array $raw, Shift $outgoing, $alerts, $audits): bool
    {
        $origin = $raw['operator_origin'] ?? null;
        $keys = ['version', 'source', 'alert_id', 'shift_id', 'site_id', 'client_id', 'user_id', 'type', 'purpose', 'text_sha256'];
        if (! is_array($origin) || count($origin) !== count($keys) || array_diff($keys, array_keys($origin)) !== []
            || $origin['version'] !== 1 || $origin['source'] !== 'independent_operator'
            || ! app(ControlRoomOperatorNoteOriginService::class)->sameOrigin($origin, $note->operator_origin)
            || $origin['shift_id'] !== (int) $outgoing->id
            || $origin['user_id'] !== (int) $note->user_id || $origin['user_id'] !== data_get($copy, 'user.id')
            || $origin['type'] !== $note->type || $origin['type'] !== $copy['type']
            || $origin['purpose'] !== $note->purpose || $origin['purpose'] !== ($raw['purpose'] ?? null)
            || $note->content !== $copy['content'] || $origin['text_sha256'] !== hash('sha256', $copy['content'])
            || $origin['alert_id'] !== ($note->alert_id === null ? null : (int) $note->alert_id)
            || $origin['alert_id'] !== $copy['alert_id']) {
            return false;
        }
        if (! is_string($copy['created_at']) || ! preg_match('/\A\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})\z/D', $copy['created_at'])) {
            return false;
        }
        try {
            if (! $note->created_at?->equalTo(Carbon::parse($copy['created_at']))) {
                return false;
            }
        } catch (\Throwable) {
            return false;
        }
        if ($origin['alert_id'] === null) {
            if ($origin['site_id'] !== null || $origin['client_id'] !== null) {
                return false;
            }
        } else {
            $alert = $alerts->get($origin['alert_id']);
            if ($alert === null || $origin['site_id'] !== ($alert->site_id === null ? null : (int) $alert->site_id)
                || $origin['client_id'] !== ($alert->client_id === null ? null : (int) $alert->client_id)) {
                return false;
            }
        }

        return $audits->filter(function ($audit) use ($note, $outgoing, $origin): bool {
            $meta = json_decode($audit->meta, true);

            return $audit->action === 'controlRoom.shift.noteAdded' && (int) $audit->user_id === $origin['user_id']
                && $audit->auditable_type === $outgoing->getMorphClass() && (int) $audit->auditable_id === (int) $outgoing->id
                && data_get($meta, 'note_id') === (int) $note->id && data_get($meta, 'note_type') === $origin['type'];
        })->count() === 1;
    }
}
