<?php

namespace Tests\Feature\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Models\AuditLog;
use App\Models\Client;
use App\Models\ControlRoom\OperatorNote;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoomAlert;
use App\Models\Permission;
use App\Models\Role;
use App\Models\Site;
use App\Models\User;
use App\Models\WorkplaceInjury;
use App\Services\ControlRoom\ControlRoomHandoverScopeService;
use Database\Seeders\RbacSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Queue;
use PHPUnit\Framework\Attributes\DataProvider;
use RuntimeException;
use Tests\TestCase;

/** Actual command/HTTP acceptance and read-only history regressions; authored, native UNRUN. */
class ControlRoomAcceptedHandoverHistoryTest extends TestCase
{
    use RefreshDatabase;

    private Site $site;

    private User $outgoing;

    private User $incoming;

    private ControlRoomAlert $alert;

    private ?OperatorNote $savedNote = null;

    private ?ControlRoomAlert $noteAlert = null;

    protected function setUp(): void
    {
        parent::setUp();
        Queue::fake();
        $this->travelTo(now()->startOfSecond());
        $this->seed(RbacSeeder::class);
        $this->site = Site::factory()->create(['is_active' => true]);
        $this->outgoing = $this->coordinator();
        $this->incoming = $this->coordinator();
        $this->alert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'client_id' => null,
            'source' => 'manual', 'alert_type' => 'operator_call',
            'status' => ControlRoomAlert::STATUS_OPEN, 'severity' => 'high',
            'reference_number' => 'CR-SAVED-HISTORY', 'context' => [],
        ]));
    }

    public function test_actual_acceptance_keeps_direct_reload_and_history_entry_read_only_without_rebuilding(): void
    {
        $shift = $this->acceptHandover();
        $saved = $shift->handover_snapshot;
        $incomingId = data_get($saved, 'incoming_shift.id');
        $acceptedName = data_get($saved, 'accepted_by.name');
        $this->incoming->update(['name' => 'Current renamed user']);
        $this->alert->updateQuietly(['severity' => 'low']);
        $newWork = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
            'site_id' => $this->site->id, 'client_id' => null, 'source' => 'manual', 'alert_type' => 'operator_call',
            'reference_number' => 'CR-NEW-LIVE-WORK', 'severity' => 'critical',
        ]));
        $before = $this->commandRows();
        for ($reload = 0; $reload < 2; $reload++) {
            $this->actingAs($this->incoming)->get($this->url($shift))->assertOk()
                ->assertInertia(fn ($page) => $page->component('control-room/shifts/handover')
                    ->where('readOnly', true)->where('shift.can_prepare', false)->where('shift.can_accept', false)
                    ->where('shift.draft', [])->has('staff', 0)->has('eligibleLeads', 0)
                    ->where('acceptance.accepted_by.name', $acceptedName)
                    ->where('acceptance.accepted_at', $saved['accepted_at'])
                    ->where('acceptance.outgoing_duty.id', $shift->id)->where('acceptance.incoming_duty.id', $incomingId)
                    ->where('shift.handover_snapshot.alerts.0.severity', 'high')
                    ->where('shift.handover_snapshot.alerts.0.id', $this->alert->id)
                    ->where('shift.handover_snapshot.handover_notes', 'Original saved outgoing context')
                    ->has('requiredAlerts', 1)->where('snapshotIssue', null));
        }
        $this->get('/control-room/shifts')->assertOk()->assertInertia(fn ($page) => $page
            ->where('recentShifts.0.actions.history_href', $this->url($shift)));
        $this->assertEquals($before, $this->commandRows(), 'GET/reload/history entry must write no command rows.');
        $this->assertSame($saved, $shift->fresh()->handover_snapshot);
        $this->assertNotContains($newWork->id, data_get($shift->fresh()->handover_snapshot, 'required_alert_ids'));
        $this->assertSame(2, Shift::count());
    }

    public function test_revoke_manage_permission_denies_the_saved_url(): void
    {
        $shift = $this->acceptHandover();
        $this->permission($this->incoming, 'controlRoom.alerts.manage', false);
        $before = $this->commandRows();
        $this->actingAs($this->incoming)->get($this->url($shift))->assertForbidden();
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_original_history_still_opens_after_the_incoming_duty_is_itself_actually_handed_over(): void
    {
        $original = $this->acceptHandover();
        $incomingDuty = Shift::findOrFail(data_get($original->handover_snapshot, 'incoming_shift.id'));
        $nextLead = $this->coordinator();
        $scope = app(ControlRoomHandoverScopeService::class)->build($incomingDuty, $this->incoming);
        $ids = collect($scope['required_alerts'])->pluck('id')->all();
        $this->actingAs($this->incoming)->from($this->url($incomingDuty))->patch($this->url($incomingDuty).'/draft', [
            'handover_notes' => 'Later saved context', 'incoming_shift_name' => 'Later duty',
            'incoming_lead_user_id' => $nextLead->id, 'incoming_team_members' => [],
            'reviewed_alert_ids' => $ids, 'priority_alert_ids' => [], 'carry_forward_acknowledged' => true,
            'carry_forward_signature' => $scope['carry_forward']['signature'], 'expected_version' => $incomingDuty->handover_version,
        ])->assertSessionHasNoErrors();
        $incomingDuty->refresh();
        $this->post($this->url($incomingDuty), ['incoming_lead_user_id' => $nextLead->id,
            'reviewed_alert_ids' => $ids, 'expected_version' => $incomingDuty->handover_version])->assertSessionHasNoErrors();
        $incomingDuty->refresh();
        $this->actingAs($nextLead)->post("/control-room/shifts/{$incomingDuty->id}/accept-handover", [
            'expected_version' => $incomingDuty->handover_version,
        ])->assertSessionHasNoErrors();
        $this->assertSame('completed', $incomingDuty->fresh()->status);
        $before = $this->commandRows();
        $this->actingAs($this->outgoing)->get($this->url($original))->assertOk()->assertInertia(fn ($page) => $page
            ->where('readOnly', true)->where('acceptance.incoming_duty.id', $incomingDuty->id)
            ->where('acceptance.incoming_duty.name', 'Saved incoming duty')
            ->where('shift.handover_snapshot.handover_notes', 'Original saved outgoing context'));
        $this->assertEquals($before, $this->commandRows());
        $this->assertSame(3, Shift::count());
    }

    public function test_uninvolved_manager_is_denied_and_has_no_history_entry_link(): void
    {
        $shift = $this->acceptHandover();
        $other = $this->coordinator();
        $this->permission($other, 'reports.viewAny', false);
        $this->actingAs($other)->get($this->url($shift))->assertForbidden();
        $this->get('/control-room/shifts')->assertOk()->assertInertia(fn ($page) => $page
            ->where('recentShifts.0.actions.history_href', null));
    }

    public function test_site_revocation_denies_copies_and_counts_before_history_is_returned(): void
    {
        $shift = $this->acceptHandover();
        $otherSite = Site::factory()->create(['is_active' => true]);
        $this->incoming->hrEmployeeProfile->update(['primary_site_id' => $otherSite->id, 'secondary_site_ids' => []]);
        $before = $this->commandRows();
        $this->actingAs($this->incoming)->get($this->url($shift))->assertForbidden();
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_moving_live_alert_to_a_new_readable_site_does_not_authorize_saved_old_site_details(): void
    {
        $shift = $this->acceptHandover();
        $otherSite = Site::factory()->create(['is_active' => true]);
        $this->alert->updateQuietly(['site_id' => $otherSite->id]);
        $this->incoming->hrEmployeeProfile->update(['primary_site_id' => $otherSite->id, 'secondary_site_ids' => []]);
        $this->actingAs($this->incoming)->get($this->url($shift))->assertForbidden();
    }

    public function test_a_new_current_person_is_not_silently_substituted_into_saved_history(): void
    {
        $shift = $this->acceptHandover();
        $person = Client::factory()->create(['site_id' => $this->site->id]);
        $this->alert->updateQuietly(['client_id' => $person->id]);
        $this->actingAs($this->incoming)->get($this->url($shift))->assertForbidden();
    }

    public function test_source_denial_withholds_private_saved_summary_without_destroying_independent_transfer_history(): void
    {
        $shift = $this->acceptHandover();
        $injury = WorkplaceInjury::withoutEvents(fn () => WorkplaceInjury::factory()->create([
            'user_id' => $this->outgoing->id, 'site_id' => $this->site->id, 'created_by' => $this->outgoing->id,
            'source_schema_version' => 0, 'source_revision' => 0,
            'description' => 'PRIVATE-CURRENT-INJURY', 'immediate_treatment' => 'PRIVATE-TREATMENT',
        ]));
        $this->alert->updateQuietly(['source' => 'operations', 'alert_type' => 'operations.workplace_injury',
            'context' => ['workplace_injury_id' => $injury->id, 'site_id' => $this->site->id, 'user_id' => $this->outgoing->id]]);
        $raw = $shift->handover_snapshot;
        $raw['alerts'][0]['summary'] = 'PRIVATE-HISTORIC-COPY';
        $shift->updateQuietly(['handover_snapshot' => $raw]);
        $this->permission($this->incoming, 'hazards.view', false);
        $before = $this->commandRows();
        $this->actingAs($this->incoming)->get($this->url($shift))->assertOk()->assertDontSee('PRIVATE-')
            ->assertInertia(fn ($page) => $page->where('readOnly', true)
                ->where('shift.handover_snapshot.alerts.0.summary', 'Workplace injury response')
                ->where('acceptance.incoming_duty.id', data_get($raw, 'incoming_shift.id')));
        $this->assertEquals($before, $this->commandRows());
        $this->assertSame('PRIVATE-HISTORIC-COPY', data_get($shift->fresh()->handover_snapshot, 'alerts.0.summary'));
    }

    public static function invalidHistory(): array
    {
        return array_map(fn ($value) => [$value], [
            'snapshot', 'actor', 'actor_id', 'accepted_time', 'relative_time',
            'root_time', 'root_status', 'incoming_id', 'incoming_row', 'audit', 'audit_version',
            'prepared_relative_time', 'criteria_time',
        ]);
    }

    #[DataProvider('invalidHistory')]
    public function test_incomplete_or_inconsistent_persisted_history_remains_unavailable_without_repair(string $mutation): void
    {
        $shift = $this->acceptHandover();
        $snapshot = $shift->handover_snapshot;
        if ($mutation === 'snapshot') {
            $snapshot = null;
        } elseif ($mutation === 'actor') {
            unset($snapshot['accepted_by']);
        } elseif ($mutation === 'actor_id') {
            $snapshot['accepted_by']['id'] = $this->outgoing->id;
        } elseif ($mutation === 'accepted_time') {
            unset($snapshot['accepted_at']);
        } elseif ($mutation === 'relative_time') {
            $snapshot['accepted_at'] = 'tomorrow';
        } elseif ($mutation === 'incoming_id') {
            unset($snapshot['incoming_shift']['id']);
        } elseif ($mutation === 'incoming_row') {
            $snapshot['incoming_shift']['id'] = $shift->id;
        } elseif ($mutation === 'prepared_relative_time') {
            $snapshot['prepared_at'] = 'now';
        } elseif ($mutation === 'criteria_time') {
            $snapshot['criteria_at'] = '';
        }
        $changes = ['handover_snapshot' => $snapshot];
        if ($mutation === 'root_time') {
            $changes['handover_accepted_at'] = null;
        } elseif ($mutation === 'root_status') {
            $changes['status'] = 'active';
        }
        $shift->updateQuietly($changes);
        if ($mutation === 'audit') {
            $this->acceptanceAudit($shift)->delete();
        } elseif ($mutation === 'audit_version') {
            $audit = $this->acceptanceAudit($shift)->sole();
            $meta = json_decode($audit->meta, true);
            $meta['handover_version']++;
            $this->acceptanceAudit($shift)->update(['meta' => json_encode($meta)]);
        }
        $before = $this->commandRows();
        $this->actingAs($this->incoming)->get($this->url($shift))->assertOk()
            ->assertInertia(fn ($page) => $page->where('readOnly', true)->where('acceptance', null)
                ->where('shift.can_prepare', false)->where('shift.can_accept', false)->where('shift.draft', [])
                ->where('shift.handover_snapshot', null)->where('openAlertsCount', null)
                ->has('requiredAlerts', 0)->has('pinnedNotes', 0)->has('followupNotes', 0)->has('staff', 0)
                ->where('snapshotIssue', fn ($message) => is_string($message) && $message !== ''));
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_delayed_draft_prepare_and_repeated_accept_cannot_change_the_accepted_record(): void
    {
        $shift = $this->acceptHandover();
        $before = $this->commandRows();
        foreach ([$shift->handover_version - 1, $shift->handover_version] as $version) {
            $this->actingAs($this->outgoing)->from($this->url($shift))->patch($this->url($shift).'/draft', [
                'handover_notes' => 'Delayed draft must not replace accepted history', 'incoming_shift_name' => 'Another duty',
                'incoming_lead_user_id' => $this->incoming->id, 'reviewed_alert_ids' => [$this->alert->id],
                'priority_alert_ids' => [], 'incoming_team_members' => [], 'expected_version' => $version,
            ])->assertSessionHasErrors();
            $this->post($this->url($shift), ['incoming_lead_user_id' => $this->incoming->id,
                'reviewed_alert_ids' => [$this->alert->id], 'expected_version' => $version])->assertSessionHasErrors();
        }
        $this->actingAs($this->incoming)->post("/control-room/shifts/{$shift->id}/accept-handover", [
            'expected_version' => $shift->handover_version - 1,
        ])->assertSessionHasNoErrors();
        $this->assertEquals($before, $this->commandRows());
        $this->assertSame(2, Shift::count());
        $this->assertSame(1, $this->acceptanceAudit($shift)->count());
    }

    public function test_a_verified_independent_note_only_copy_is_readable_once_when_pinned_and_followed_up(): void
    {
        $shift = $this->acceptHandover(['pinned' => true, 'followup' => true]);
        $this->assertNotContains($this->noteAlert->id, $shift->handover_snapshot['required_alert_ids']);
        $this->assertSame([$this->noteAlert->id], $shift->handover_snapshot['note_alert_ids']);
        $this->assertSame(1, $this->savedNote->operator_origin['version']);
        $before = $this->commandRows();
        $this->actingAs($this->incoming)->get($this->url($shift))->assertOk()->assertInertia(fn ($page) => $page
            ->where('readOnly', true)->has('noteProjection.notes', 1)
            ->where('noteProjection.notes.0.id', $this->savedNote->id)
            ->where('noteProjection.notes.0.content', 'Independent saved note-only response')
            ->where('noteProjection.status', 'available')
            ->has('pinnedNotes', 1)->has('followupNotes', 1));
        $this->assertEquals($before, $this->commandRows());
    }

    public static function noteReassociation(): array
    {
        $rows = [];
        foreach (['site', 'person'] as $association) {
            foreach (['pinned', 'followup', 'both'] as $collection) {
                $rows[$association.' '.$collection] = [$association, $collection];
            }
        }

        return $rows;
    }

    #[DataProvider('noteReassociation')]
    public function test_persisted_note_only_copies_are_withheld_after_original_context_reassociation(string $association, string $collection): void
    {
        $shift = $this->acceptHandover(['pinned' => $collection !== 'followup', 'followup' => $collection !== 'pinned']);
        if ($association === 'site') {
            $newSite = Site::factory()->create(['is_active' => true]);
            $this->incoming->hrEmployeeProfile->update(['secondary_site_ids' => [$newSite->id]]);
            $this->noteAlert->updateQuietly(['site_id' => $newSite->id]);
        } else {
            $this->noteAlert->updateQuietly(['client_id' => Client::factory()->create(['site_id' => $this->site->id])->id]);
        }
        $before = $this->commandRows();
        $this->assertNoteUnavailable($shift);
        $this->assertEquals($before, $this->commandRows());
        $this->assertSame('Independent saved note-only response', data_get($shift->fresh()->handover_snapshot,
            ($collection === 'followup' ? 'followup_notes' : 'pinned_notes').'.0.content'));
    }

    public static function noteCollections(): array
    {
        return ['pinned' => [true, false], 'followup' => [false, true], 'both' => [true, true]];
    }

    #[DataProvider('noteCollections')]
    public function test_a_private_source_note_copy_with_unknown_original_provenance_stays_unavailable_after_withdrawal(bool $pinned, bool $followup): void
    {
        $shift = $this->acceptHandover(['legacy' => true, 'injury' => true, 'pinned' => $pinned, 'followup' => $followup]);
        $this->assertNull($this->savedNote->operator_origin);
        $this->permission($this->incoming, 'hazards.view', false);
        $before = $this->commandRows();
        $this->assertNoteUnavailable($shift, 'PRIVATE-SAVED-SOURCE-NOTE');
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_note_only_site_access_withdrawal_hides_the_copy_without_hiding_independent_acceptance(): void
    {
        $shift = $this->acceptHandover(['separate_site' => true, 'pinned' => true, 'followup' => true]);
        $this->assertNotSame($this->site->id, $this->noteAlert->site_id);
        $this->incoming->hrEmployeeProfile->update(['secondary_site_ids' => []]);
        $before = $this->commandRows();
        $this->assertNoteUnavailable($shift);
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_verified_independent_operator_text_survives_private_source_withdrawal_in_its_unchanged_context(): void
    {
        $shift = $this->acceptHandover(['injury' => true, 'pinned' => true, 'followup' => true]);
        $this->permission($this->incoming, 'hazards.view', false);
        $before = $this->commandRows();
        $this->actingAs($this->incoming)->get($this->url($shift))->assertOk()->assertDontSee('PRIVATE-')
            ->assertInertia(fn ($page) => $page->has('noteProjection.notes', 1)
                ->where('noteProjection.notes.0.content', 'Independent saved note-only response')
                ->where('noteProjection.status', 'available'));
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_missing_saved_origin_is_not_backfilled_from_the_present_note_context(): void
    {
        $shift = $this->acceptHandover(['pinned' => true]);
        $snapshot = $shift->handover_snapshot;
        unset($snapshot['pinned_notes'][0]['operator_origin']);
        $shift->updateQuietly(['handover_snapshot' => $snapshot]);
        $before = $this->commandRows();
        $this->assertNoteUnavailable($shift);
        $this->assertEquals($before, $this->commandRows());
        $this->assertArrayNotHasKey('operator_origin', $shift->fresh()->handover_snapshot['pinned_notes'][0]);
    }

    public function test_changed_current_note_is_not_substituted_for_the_saved_copy(): void
    {
        $shift = $this->acceptHandover(['pinned' => true, 'followup' => true]);
        $this->savedNote->updateQuietly(['content' => 'PRIVATE-LATER-CONTENT']);
        $before = $this->commandRows();
        $this->assertNoteUnavailable($shift);
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_conflicting_saved_copies_of_the_same_note_are_not_released_as_two_independent_notes(): void
    {
        $shift = $this->acceptHandover(['pinned' => true, 'followup' => true]);
        $snapshot = $shift->handover_snapshot;
        $snapshot['followup_notes'][0]['content'] = 'PRIVATE-CONFLICTING-COPY';
        $shift->updateQuietly(['handover_snapshot' => $snapshot]);
        $before = $this->commandRows();
        $this->assertNoteUnavailable($shift);
        $this->assertEquals($before, $this->commandRows());
    }

    public function test_note_origin_changed_by_successful_late_audit_callback_rolls_back_the_whole_note_command(): void
    {
        $shift = Shift::create(['name' => 'Writer origin check', 'starts_at' => now()->subHour(),
            'status' => 'active', 'shift_lead_user_id' => $this->outgoing->id]);
        $before = $this->commandRows();
        $reached = 0;
        AuditLog::created(function ($audit) use (&$reached) {
            if ($audit->action === 'controlRoom.shift.noteAdded') {
                $reached++;
                DB::table('control_room_operator_notes')->where('id', data_get($audit->meta, 'note_id'))->update(['operator_origin' => null]);
            }
            return true;
        });
        $this->withoutExceptionHandling();
        try {
            $this->actingAs($this->outgoing)->post("/control-room/shifts/{$shift->id}/note", [
                'type' => 'note', 'content' => 'Literal independently authored text', 'is_pinned' => true,
            ]);
            $this->fail('Changing the sealed origin must reject the note command.');
        } catch (RuntimeException) {
            $this->assertSame(1, $reached, 'The actual successful late audit callback must be reached.');
            $this->assertEquals($before, $this->commandRows());
        }
    }

    private function assertNoteUnavailable(Shift $shift, string $copy = 'Independent saved note-only response'): void
    {
        $this->actingAs($this->incoming)->get($this->url($shift))->assertOk()->assertDontSee($copy)
            ->assertDontSee('PRIVATE-')->assertInertia(fn ($page) => $page
                ->where('readOnly', true)->where('acceptance.outgoing_duty.id', $shift->id)
                ->has('noteProjection.notes', 0)->where('noteProjection.status', 'unavailable')
                ->has('pinnedNotes', 0)->has('followupNotes', 0)
                ->has('shift.handover_snapshot.pinned_notes', 0)->has('shift.handover_snapshot.followup_notes', 0));
    }

    private function acceptHandover(?array $noteSpec = null): Shift
    {
        $shift = Shift::create(['name' => 'Outgoing duty record', 'starts_at' => now()->subHours(4),
            'status' => 'active', 'shift_lead_user_id' => $this->outgoing->id, 'team_members' => []]);
        $shift->refresh();
        if ($noteSpec !== null) {
            $spec = array_replace(['pinned' => true, 'followup' => false, 'legacy' => false, 'injury' => false, 'separate_site' => false], $noteSpec);
            $noteSite = $spec['separate_site'] ? Site::factory()->create(['is_active' => true]) : $this->site;
            if ($spec['separate_site']) {
                foreach ([$this->outgoing, $this->incoming] as $member) {
                    $member->hrEmployeeProfile->update(['secondary_site_ids' => [$noteSite->id]]);
                }
            }
            $context = [];
            if ($spec['injury']) {
                $injury = WorkplaceInjury::withoutEvents(fn () => WorkplaceInjury::factory()->create([
                    'user_id' => $this->outgoing->id, 'site_id' => $this->site->id, 'created_by' => $this->outgoing->id,
                    'source_schema_version' => 0, 'source_revision' => 0,
                    'description' => 'PRIVATE-SOURCE-FACT', 'immediate_treatment' => 'PRIVATE-SOURCE-TREATMENT',
                ]));
                $context = ['workplace_injury_id' => $injury->id, 'site_id' => $this->site->id, 'user_id' => $this->outgoing->id];
            }
            $this->noteAlert = ControlRoomAlert::withoutEvents(fn () => ControlRoomAlert::factory()->create([
                'source' => $spec['injury'] ? 'operations' : 'manual',
                'alert_type' => $spec['injury'] ? 'operations.workplace_injury' : 'operator_call',
                'status' => ControlRoomAlert::STATUS_RESOLVED, 'site_id' => $noteSite->id, 'client_id' => null,
                'context' => $context, 'reference_number' => 'CR-NOTE-ONLY',
            ]));
            $content = $spec['legacy'] ? 'PRIVATE-SAVED-SOURCE-NOTE' : 'Independent saved note-only response';
            $payload = ['type' => 'note', 'content' => $content, 'alert_id' => $this->noteAlert->id,
                'is_pinned' => $spec['pinned'], 'requires_followup' => $spec['followup'],
                'followup_at' => $spec['followup'] ? now()->addHour()->toIso8601String() : null];
            if ($spec['legacy']) {
                // Persisted historical producer copy with unknown origin; never a mocked reader.
                OperatorNote::create($payload + ['shift_id' => $shift->id, 'user_id' => $this->outgoing->id,
                    'purpose' => OperatorNote::PURPOSE_GENERAL]);
            } else {
                $this->actingAs($this->outgoing)->post("/control-room/shifts/{$shift->id}/note", $payload)->assertSessionHasNoErrors();
            }
            $this->savedNote = OperatorNote::where('shift_id', $shift->id)->sole();
        }
        $scope = app(ControlRoomHandoverScopeService::class)->build($shift, $this->outgoing);
        $ids = collect($scope['required_alerts'])->pluck('id')->all();
        $this->assertContains($this->alert->id, $ids, 'The actual prepared scope must contain the persisted work.');
        $this->actingAs($this->outgoing)->from($this->url($shift))->patch($this->url($shift).'/draft', [
            'handover_notes' => 'Original saved outgoing context', 'incoming_shift_name' => 'Saved incoming duty',
            'incoming_lead_user_id' => $this->incoming->id, 'incoming_team_members' => [],
            'reviewed_alert_ids' => $ids, 'priority_alert_ids' => [],
            'carry_forward_acknowledged' => true, 'carry_forward_signature' => $scope['carry_forward']['signature'],
            'expected_version' => $shift->handover_version,
        ])->assertSessionHasNoErrors();
        $shift->refresh();
        $this->post($this->url($shift), ['incoming_lead_user_id' => $this->incoming->id,
            'reviewed_alert_ids' => $ids, 'expected_version' => $shift->handover_version])->assertSessionHasNoErrors();
        $shift->refresh();
        $this->assertSame(Shift::HANDOVER_PREPARED, $shift->handover_status);
        $this->actingAs($this->incoming)->post("/control-room/shifts/{$shift->id}/accept-handover", [
            'expected_version' => $shift->handover_version,
        ])->assertSessionHasNoErrors();
        $shift->refresh();
        $this->assertSame(Shift::HANDOVER_ACCEPTED, $shift->handover_status);
        $this->assertSame('completed', $shift->status);
        $this->assertSame(2, Shift::count());

        return $shift;
    }

    private function coordinator(): User
    {
        $user = User::factory()->create(['role' => 'coordinator', 'approved_at' => now()]);
        $user->roles()->attach(Role::where('name', 'coordinator')->sole());
        HrEmployeeProfile::factory()->create(['user_id' => $user->id, 'primary_site_id' => $this->site->id,
            'secondary_site_ids' => [], 'is_active' => true, 'start_date' => now('Pacific/Auckland')->subYear()->toDateString(), 'end_date' => null]);
        $this->assertTrue($user->canDo('controlRoom.viewAny'));
        $this->assertTrue($user->canDo('controlRoom.alerts.manage'));

        return $user;
    }

    private function permission(User $user, string $key, bool $allowed): void
    {
        $user->permissionOverrides()->syncWithoutDetaching([Permission::where('key', $key)->sole()->id => ['allowed' => $allowed]]);
        $user->unsetRelation('permissionOverrides')->unsetRelation('roles');
    }

    private function acceptanceAudit(Shift $shift)
    {
        return DB::table('audit_logs')->where('action', 'controlRoom.shift.handoverAccepted')
            ->where('auditable_type', $shift->getMorphClass())->where('auditable_id', $shift->id);
    }

    private function commandRows(): array
    {
        $rows = [];
        foreach (['control_room_shifts', 'control_room_operator_notes', 'audit_logs'] as $table) {
            $rows[$table] = DB::table($table)->orderBy('id')->get()->all();
        }

        return $rows;
    }

    private function url(Shift $shift): string
    {
        return "/control-room/shifts/{$shift->id}/handover";
    }
}
