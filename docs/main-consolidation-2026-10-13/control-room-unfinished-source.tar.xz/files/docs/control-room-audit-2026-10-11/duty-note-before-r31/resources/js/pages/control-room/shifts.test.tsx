import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import type { ComponentProps, ReactNode } from 'react';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import ControlRoomShifts from './shifts';

const fixture = vi.hoisted(() => ({
    canPlan: false,
    router: { post: vi.fn(), reload: vi.fn(), visit: vi.fn() },
}));

vi.mock('@inertiajs/react', () => ({
    Head: () => null,
    usePage: () => ({
        url: '/control-room/shifts',
        props: {
            auth: {
                can: {
                    controlRoom: { viewAny: true },
                    rostering: { viewAny: fixture.canPlan },
                },
            },
        },
    }),
    Link: ({ href, children, ...props }: { href: string; children: ReactNode }) => (
        <a href={href} {...props}>{children}</a>
    ),
    router: fixture.router,
}));

vi.mock('@/layouts/app-layout', () => ({
    default: ({ children }: { children: ReactNode }) => <>{children}</>,
}));

const base: ComponentProps<typeof ControlRoomShifts> = {
    activeShift: null,
    notes: [],
    recentShifts: [],
    openAlertsCount: 12,
    criticalAlertsCount: 2,
    staff: [],
    eligibleLeads: [],
    can: { manage: false },
};

beforeEach(() => { fixture.canPlan = false; vi.clearAllMocks(); });
afterEach(cleanup);

describe('actual Control Room duty header', () => {
    it('links current counts to their actual scope and exposes planned staffing only with its own permission', () => {
        fixture.canPlan = true;
        render(<ControlRoomShifts {...base} activeShift={{
            id: 7,
            name: 'Current response desk',
            starts_at: '2026-10-12T02:00:00Z',
            ends_at: null,
            status: 'active',
            shift_lead: { id: 8, name: 'Duty lead' },
            team_members: [],
            open_alerts_at_start: 11,
            alerts_created: 4,
            alerts_resolved: 3,
            alerts_escalated: 1,
            handover_status: 'none',
            handover_version: 1,
            handover_prepared_at: null,
            incoming_lead: null,
            actions: { can_open_handover: false, can_add_note: false, can_copy_summary: false },
        }} />);

        expect(screen.getByRole('heading', { level: 1, name: 'Duty handover' })).toBeInTheDocument();
        expect(screen.getByRole('link', { name: 'View open now' })).toHaveAttribute('href', '/control-room/shifts#duty-response-summary');
        expect(screen.getByRole('link', { name: 'View critical' })).toHaveAttribute('href', '/control-room/shifts#duty-response-summary');
        expect(screen.getByRole('link', { name: 'View resolved' })).toHaveAttribute('href', '/control-room/shifts#current-duty-summary');
        expect(screen.getByRole('link', { name: 'View resolved' })).toHaveTextContent('3');
        expect(screen.getByRole('link', { name: 'View escalated' })).toHaveTextContent('1');
        expect(document.getElementById('duty-response-summary')).toHaveTextContent('12 open alerts, including waiting alerts; 2 are critical.');
        expect(document.getElementById('current-duty-summary')).toHaveTextContent('3 resolved');
        expect(screen.getByRole('link', { name: 'Plan staffing' })).toHaveAttribute('href', '/operations/rostering');
        expect(fixture.router.post).not.toHaveBeenCalled();
    });

    it('keeps missing duty counters unavailable and does not offer staffing planning to a duty reader', () => {
        render(<ControlRoomShifts {...base} />);
        expect(screen.queryByRole('link', { name: 'Plan staffing' })).not.toBeInTheDocument();
        expect(screen.getByRole('link', { name: 'View resolved' })).toHaveTextContent('—');
        expect(screen.getByRole('link', { name: 'View escalated' })).toHaveTextContent('—');
        expect(document.getElementById('current-duty-summary')).toHaveTextContent('No active duty');
        expect(screen.getByRole('link', { name: 'Review waiting alerts' })).toHaveAttribute('href', '/control-room/alerts?lens=snoozed');
        expect(screen.queryByRole('button', { name: 'Start duty' })).not.toBeInTheDocument();
        expect(fixture.router.post).not.toHaveBeenCalled();
    });

    it('exposes the existing accepted-history URL only with current manage authority and a server-admitted link', () => {
        const recent: ComponentProps<typeof ControlRoomShifts>['recentShifts'] = [{
            id: 7, name: 'Accepted outgoing duty', starts_at: '2026-10-12T01:00:00Z', ends_at: '2026-10-12T02:00:00Z',
            status: 'completed', shift_lead: null, alerts_created: 4, alerts_resolved: 3, alerts_escalated: 1, duration_minutes: 60,
            actions: { can_copy_summary: false, history_href: '/control-room/shifts/7/handover' },
        }];
        const view = render(<ControlRoomShifts {...base} recentShifts={recent} />);
        expect(screen.queryByRole('link', { name: 'View accepted handover' })).not.toBeInTheDocument();
        view.rerender(<ControlRoomShifts {...base} can={{ manage: true }} recentShifts={recent} />);
        expect(screen.getByRole('link', { name: 'View accepted handover' })).toHaveAttribute('href', '/control-room/shifts/7/handover');
        expect(fixture.router.post).not.toHaveBeenCalled();
    });

    it('opens a single existing start-duty form from the empty-state action', () => {
        render(<ControlRoomShifts {...base} can={{ manage: true }} />);
        const actions = screen.getAllByRole('button', { name: 'Start duty' });
        fireEvent.click(actions[actions.length - 1]);
        expect(screen.getAllByRole('dialog')).toHaveLength(1);
        expect(fixture.router.post).not.toHaveBeenCalled();
    });
});
