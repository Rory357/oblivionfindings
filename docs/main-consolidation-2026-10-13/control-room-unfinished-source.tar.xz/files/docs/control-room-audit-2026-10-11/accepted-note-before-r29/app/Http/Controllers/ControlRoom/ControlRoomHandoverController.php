<?php

namespace App\Http\Controllers\ControlRoom;

use App\Http\Controllers\Controller;
use App\Models\ControlRoom\OperatorNote;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Services\ControlRoom\ControlRoomAlertAccessService;
use App\Services\ControlRoom\ControlRoomAcceptedHandoverHistoryService;
use App\Services\ControlRoom\ControlRoomGovernanceReadService;
use App\Services\ControlRoom\ControlRoomHandoverScopeService;
use App\Services\ControlRoom\ControlRoomHandoverReadAccessService;
use App\Services\ControlRoom\ControlRoomPreparedHandoverSnapshotService;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\UserSiteAccessService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;

class ControlRoomHandoverController extends Controller
{
    public function show(
        Request $request,
        Shift $shift,
        ControlRoomAlertAccessService $alertAccess,
        ControlRoomHandoverScopeService $handoverScope,
        ControlRoomPreparedHandoverSnapshotService $preparedSnapshots,
    ) {
        $viewer = $request->user();
        abort_unless($viewer, 403);
        $props = app(ControlRoomGovernanceReadService::class)->withCurrentViewer($viewer,
            fn (User $current, HealthSafetyReadContext $context): array => $this->showProperties($shift, $alertAccess, $handoverScope, $preparedSnapshots, $current, $context));

        return Inertia::render('control-room/shifts/handover', $props);
    }

    private function showProperties(
        Shift $shift,
        ControlRoomAlertAccessService $alertAccess,
        ControlRoomHandoverScopeService $handoverScope,
        ControlRoomPreparedHandoverSnapshotService $preparedSnapshots,
        User $user,
        HealthSafetyReadContext $context,
    ): array {
        abort_unless($user->canDo('controlRoom.alerts.manage'), 403);
        $shift = $context->query(Shift::query()->whereKey($shift->id))->firstOrFail();
        if ($shift->handover_status === Shift::HANDOVER_ACCEPTED) {
            abort_unless($this->canViewPreparedSnapshot($shift, $user), 403);

            return $this->acceptedHistoryProperties($shift, $handoverScope, $user, $context);
        }
        abort_unless($shift->status === 'active', 404, 'Only active shifts can be handed over.');

        $siteAccess = app(UserSiteAccessService::class);
        $shiftLead = $shift->shiftLead;
        $teamMembers = $shift->getTeamMemberUsers();
        $snapshot = $shift->handover_snapshot;
        $snapshotIssue = null;
        if ($shift->handover_status === Shift::HANDOVER_PREPARED) {
            abort_unless($this->canViewPreparedSnapshot($shift, $user), 403);
            try {
                $snapshot = $preparedSnapshots->validated($shift);
                if (! $this->canViewPreparedSnapshotContent($snapshot, $user, $handoverScope, $context)) {
                    $snapshot = null;
                    $snapshotIssue = 'Your current access no longer covers every alert included in this handover.';
                } else {
                    $snapshot = app(ControlRoomGovernanceReadService::class)->forSnapshotViewer($snapshot, $user, $context);
                }
            } catch (ValidationException $exception) {
                $snapshot = null;
                $snapshotIssue = (string) collect($exception->errors())->flatten()->first();
            }
        }
        $draft = data_get($snapshot, 'draft', []);
        $isStale = $shift->isHandoverStale();
        $canOverride = $shift->handover_status === Shift::HANDOVER_NONE
            && $isStale
            && (int) $shift->shift_lead_user_id !== $user->id
            && $user->canDo('controlRoom.handovers.override');

        $shiftData = [
            'id' => $shift->id,
            'name' => $shift->name,
            'starts_at' => $shift->starts_at->toISOString(),
            'ends_at' => $shift->ends_at?->toISOString(),
            'status' => $shift->status,
            'shift_lead' => $shiftLead ? [
                'id' => $shiftLead->id,
                'name' => $shiftLead->name,
            ] : null,
            'team_members' => $teamMembers->map(fn (User $member) => [
                'id' => $member->id,
                'name' => $member->name,
            ])->values()->all(),
            'open_alerts_at_start' => $shift->open_alerts_at_start ?? 0,
            'alerts_created' => $shift->alerts_created ?? 0,
            'alerts_resolved' => $shift->alerts_resolved ?? 0,
            'alerts_escalated' => $shift->alerts_escalated ?? 0,
            'duration_minutes' => $shift->getDuration(),
            'handover_status' => $shift->handover_status,
            'handover_version' => $shift->handover_version,
            'handover_prepared_at' => $shift->handover_prepared_at?->toISOString(),
            'handover_snapshot' => $snapshot,
            'draft' => is_array($draft) ? $draft : [],
            'incoming_lead' => $shift->handedOverTo ? [
                'id' => $shift->handedOverTo->id,
                'name' => $shift->handedOverTo->name,
            ] : null,
            'is_stale' => $isStale,
            'stale_after_hours' => $shift->handoverStaleAfterHours(),
            'can_override' => $canOverride,
            'can_prepare' => $shift->handover_status === Shift::HANDOVER_NONE
                && (
                    (int) $shift->shift_lead_user_id === $user->id
                    || $canOverride
                ),
            'can_accept' => $shift->handover_status === Shift::HANDOVER_PREPARED
                && (int) $shift->handed_over_to_user_id === $user->id
                && $snapshotIssue === null,
        ];

        $hasPreparedScope = $shift->handover_status === Shift::HANDOVER_PREPARED
            && $snapshotIssue === null
            && is_array($snapshot)
            && is_array(data_get($snapshot, 'alerts'))
            && is_array(data_get($snapshot, 'carry_forward'));
        $scope = match (true) {
            $hasPreparedScope => [
                'criteria_at' => data_get($snapshot, 'criteria_at'),
                'criteria' => data_get($snapshot, 'criteria', []),
                'required_alerts' => data_get($snapshot, 'alerts', []),
                'carry_forward' => data_get($snapshot, 'carry_forward'),
            ],
            $snapshotIssue !== null => $this->emptyScope($shift),
            default => $handoverScope->build($shift, $user, $context),
        };
        $requiredAlerts = collect($scope['required_alerts']);
        $carryForward = $scope['carry_forward'];
        $openAlertsCount = $requiredAlerts->count() + (int) $carryForward['total'];

        $pinnedNotes = $snapshotIssue === null
            ? $this->notes(
                $shift,
                $user,
                $alertAccess,
                fn ($query) => $query->where('is_pinned', true),
            )
            : [];
        $followupNotes = $snapshotIssue === null
            ? $this->notes(
                $shift,
                $user,
                $alertAccess,
                fn ($query) => $query->where('requires_followup', true)->orderBy('followup_at'),
            )
            : [];

        $staff = User::staff()
            ->tap(fn ($query) => $siteAccess->applyStaffScope($query, $user, $this->alertBypassPermissions()))
            ->with(['roles.permissions:id,key', 'permissionOverrides:id,key'])
            ->select(['id', 'name'])
            ->orderBy('name')
            ->get();
        $eligibleLeads = $staff
            ->filter(fn (User $candidate) => $candidate->canDo('controlRoom.alerts.manage'))
            ->map(fn (User $candidate) => ['id' => $candidate->id, 'name' => $candidate->name])
            ->values()
            ->all();

        return [
            'shift' => $shiftData,
            'openAlertsCount' => $openAlertsCount,
            'requiredAlerts' => $requiredAlerts->values()->all(),
            'handoverCriteriaAt' => $scope['criteria_at'],
            'handoverCriteria' => $scope['criteria'],
            'carryForward' => $carryForward,
            'pinnedNotes' => $pinnedNotes,
            'followupNotes' => $followupNotes,
            'staff' => $staff->map(fn (User $candidate) => [
                'id' => $candidate->id,
                'name' => $candidate->name,
            ])->values()->all(),
            'eligibleLeads' => $eligibleLeads,
            'snapshotIssue' => $snapshotIssue,
        ];
    }

    /** Accepted GET never calls the live scope, notes, staff, draft or transition writers. */
    private function acceptedHistoryProperties(
        Shift $shift,
        ControlRoomHandoverScopeService $handoverScope,
        User $viewer,
        HealthSafetyReadContext $context,
    ): array {
        $snapshot = null;
        $acceptance = null;
        $issue = null;
        try {
            $saved = app(ControlRoomAcceptedHandoverHistoryService::class)->validated($shift, $context);
            abort_unless($this->canViewPreparedSnapshotContent($saved['snapshot'], $viewer, $handoverScope, $context), 403);
            // A readable current alert is not authority to disclose a different
            // person or Site retained by the historical row after reassociation.
            $references = $context->query(ControlRoomAlert::query()->whereKey(
                collect($saved['snapshot']['alerts'])->pluck('id')->all(),
            ))->get(['id', 'site_id', 'client_id'])->keyBy('id');
            foreach ($saved['snapshot']['alerts'] as $row) {
                $current = $references->get($row['id']);
                abort_unless($current !== null
                    && ($current->site_id === null ? null : (int) $current->site_id) === data_get($row, 'site.id')
                    && ($current->client_id === null ? null : (int) $current->client_id) === data_get($row, 'person.id'), 403);
            }
            // Preserve saved workflow facts; canonical shaping may only withhold or
            // reproject private source copies for this current reader. Never persist it.
            $snapshot = app(ControlRoomGovernanceReadService::class)->forSnapshotViewer($saved['snapshot'], $viewer, $context);
            $acceptance = $saved['acceptance'];
        } catch (ValidationException) {
            $issue = ControlRoomAcceptedHandoverHistoryService::UNAVAILABLE_MESSAGE;
        }

        return [
            'readOnly' => true,
            'acceptance' => $acceptance,
            'snapshotIssue' => $issue,
            'shift' => [
                'id' => (int) $shift->id, 'name' => $shift->name, 'status' => $shift->status,
                'handover_status' => Shift::HANDOVER_ACCEPTED, 'handover_version' => $shift->handover_version,
                'handover_snapshot' => $snapshot, 'draft' => [],
                'can_prepare' => false, 'can_accept' => false, 'can_override' => false,
            ],
            'openAlertsCount' => $snapshot === null ? null : count($snapshot['alerts']) + $snapshot['carry_forward']['total'],
            'requiredAlerts' => $snapshot['alerts'] ?? [],
            'handoverCriteriaAt' => $snapshot['criteria_at'] ?? null,
            'handoverCriteria' => $snapshot['criteria'] ?? [],
            'carryForward' => $snapshot['carry_forward'] ?? null,
            'pinnedNotes' => $snapshot['pinned_notes'] ?? [],
            'followupNotes' => $snapshot['followup_notes'] ?? [],
            'staff' => [], 'eligibleLeads' => [],
            'displayBasis' => 'Saved work and acceptance; source copies shaped by current access',
        ];
    }

    /** @return list<array<string, mixed>> */
    private function notes(
        Shift $shift,
        User $viewer,
        ControlRoomAlertAccessService $alertAccess,
        callable $scope,
    ): array {
        return OperatorNote::query()
            ->where('shift_id', $shift->id)
            ->where(function ($notes) use ($viewer, $alertAccess): void {
                $notes->whereNull('alert_id')
                    ->orWhereHas('alert', function ($alerts) use ($viewer, $alertAccess): void {
                        $alertAccess->applyReadableScope($alerts, $viewer);
                    });
            })
            ->tap($scope)
            ->with('user:id,name')
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (OperatorNote $note) => [
                'id' => $note->id,
                'type' => $note->type,
                'content' => $note->content,
                'is_pinned' => $note->is_pinned,
                'requires_followup' => $note->requires_followup,
                'followup_at' => $note->followup_at?->toISOString(),
                'user' => $note->user ? ['id' => $note->user->id, 'name' => $note->user->name] : null,
                'created_at' => $note->created_at->toISOString(),
            ])
            ->all();
    }

    /** @return list<string> */
    protected function alertBypassPermissions(): array
    {
        return ['reports.viewAny'];
    }

    private function canViewPreparedSnapshot(Shift $shift, User $user): bool
    {
        return app(ControlRoomHandoverReadAccessService::class)->canViewSavedSnapshot($shift, $user);
    }

    /** @param array<string, mixed> $snapshot */
    private function canViewPreparedSnapshotContent(
        array $snapshot,
        User $user,
        ControlRoomHandoverScopeService $handoverScope,
        HealthSafetyReadContext $context,
    ): bool {
        $snapshotAlertIds = collect($snapshot['required_alert_ids'])
            ->merge($snapshot['carry_forward_alert_ids'])
            ->merge($snapshot['note_alert_ids'])
            ->map(fn ($id): int => (int) $id)
            ->unique()
            ->sort()
            ->values()
            ->all();
        $visibleAlertIds = $handoverScope
            ->visibleAlertIds($user, $snapshotAlertIds, $context)
            ->sort()
            ->values()
            ->all();

        return $visibleAlertIds === $snapshotAlertIds;
    }

    /** @return array<string, mixed> */
    private function emptyScope(Shift $shift): array
    {
        return [
            'criteria_at' => $shift->handover_prepared_at?->toIso8601String()
                ?? now()->toIso8601String(),
            'criteria' => [],
            'required_alerts' => [],
            'carry_forward' => [
                'total' => 0,
                'by_severity' => [
                    'critical' => 0,
                    'high' => 0,
                    'medium' => 0,
                    'low' => 0,
                ],
                'by_queue' => [],
                'oldest_created_at' => null,
                'breached_count' => 0,
                'href' => '/control-room/alerts?lens=active&handover=carry-forward',
                'signature' => hash('sha256', '[]'),
            ],
        ];
    }
}
