import { CommandCentrePage } from '@/components/command-centre/command-centre-page';
import PageShell from '@/components/page-shell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import AppLayout from '@/layouts/app-layout';
import { formatDateTime } from '@/lib/datetime';
import { Head, Link } from '@inertiajs/react';
import { AlertTriangle, ShieldCheck } from 'lucide-react';
import type { HandoverSnapshot } from './handover';

export type SavedHandoverAcceptance = {
    accepted_by: { id: number; name: string };
    accepted_at: string;
    handover_version: number;
    outgoing_duty: { id: number; name: string; href: string };
    incoming_duty: { id: number; name: string; href: string };
};

/** This component contains no draft state, effects, form or transition callback. */
export function AcceptedHandoverHistory({ shift, acceptance, snapshotIssue }: {
    shift: { id: number; name: string; handover_snapshot: HandoverSnapshot | null };
    acceptance: SavedHandoverAcceptance | null;
    snapshotIssue: string | null;
}) {
    const snapshot = shift.handover_snapshot;
    const available = snapshot !== null && acceptance !== null && !snapshotIssue;
    const recordHref = `/control-room/shifts/${shift.id}/handover`;
    return (
        <AppLayout breadcrumbs={[
            { title: 'Home', href: '/dashboard' },
            { title: 'Control Room', href: '/control-room' },
            { title: 'Duty handover', href: '/control-room/shifts' },
            { title: 'Accepted handover history', href: recordHref },
        ]}>
            <Head title={`Accepted handover history - ${shift.name}`} />
            <PageShell>
                <CommandCentrePage profile current={recordHref} icon={ShieldCheck}
                    title="Accepted handover history"
                    status={available ? 'Read-only accepted transfer' : 'Saved transfer details unavailable'}
                    description={shift.name + ' · Saved work and transfer; source details reflect your current access.'}
                    backHref="/control-room/shifts"
                    metricGroups={available ? [{ title: 'Saved handover', icon: ShieldCheck, metrics: [
                        { label: 'Required work', value: String(snapshot.alerts?.length ?? 0), caption: 'saved reviewed records', tone: 'neutral', href: recordHref + '#accepted-required-work' },
                        { label: 'Carried forward', value: String(snapshot.carry_forward?.total ?? 0), caption: 'saved acknowledged summary', tone: 'neutral', href: recordHref + '#accepted-carry-forward' },
                        { label: 'Priority records', value: String(snapshot.priority_alert_ids?.length ?? 0), caption: 'marked in the saved handover', tone: 'neutral', href: recordHref + '#accepted-required-work' },
                        { label: 'Notes', value: String((snapshot.pinned_notes?.length ?? 0) + (snapshot.followup_notes?.length ?? 0)), caption: 'saved notes', tone: 'neutral', href: recordHref + '#accepted-context' },
                    ] }] : []}
                >
                    {available ? <>
                        <Card>
                            <CardHeader><CardTitle>Recorded acceptance</CardTitle></CardHeader>
                            <CardContent className="space-y-3 text-sm">
                                <p>Accepted by <strong>{acceptance.accepted_by.name}</strong> on {formatDateTime(acceptance.accepted_at)}.</p>
                                <p>Outgoing duty #{acceptance.outgoing_duty.id} · {acceptance.outgoing_duty.name}.</p>
                                <p>Incoming duty #{acceptance.incoming_duty.id} · {acceptance.incoming_duty.name}.</p>
                                <Link href={acceptance.incoming_duty.href} className="frontline-focus underline">Open incoming duty record</Link>
                                <p className="text-muted-foreground">This is the saved transfer. Opening it does not start another duty or change who accepted it.</p>
                            </CardContent>
                        </Card>
                        <Card id="accepted-carry-forward">
                            <CardHeader><CardTitle>Saved carry-forward summary</CardTitle></CardHeader>
                            <CardContent className="space-y-2 text-sm">
                                <p>{snapshot.carry_forward?.total ?? 0} unchanged alerts were included in the acknowledged handover summary.</p>
                                <p>Scope recorded {formatDateTime(snapshot.criteria_at)}. These are saved workload figures, not today&apos;s live counts.</p>
                            </CardContent>
                        </Card>
                        <section id="accepted-required-work" aria-labelledby="accepted-work-title" className="space-y-3">
                            <h2 id="accepted-work-title" className="text-section-title">Saved reviewed work</h2>
                            {(snapshot.alerts ?? []).map((alert) => <Card key={alert.id}>
                                <CardContent className="space-y-2 py-4 text-sm">
                                    <Link href={alert.href} className="frontline-focus font-medium underline">{alert.reference_number ?? `Alert ${alert.id}`}</Link>
                                    <p>{alert.summary}</p>
                                    <p className="text-muted-foreground">Saved severity: {alert.severity}. {alert.site?.name ?? 'Site not recorded'}.</p>
                                    <p>{alert.handover_reasons.map((reason) => reason.label).join(' · ')}</p>
                                </CardContent>
                            </Card>)}
                            {(snapshot.alerts?.length ?? 0) === 0 && <p className="text-sm text-muted-foreground">No individually reviewed records were included.</p>}
                        </section>
                        <Card id="accepted-context">
                            <CardHeader><CardTitle>Saved outgoing context and notes</CardTitle></CardHeader>
                            <CardContent className="space-y-3 text-sm">
                                <p className="whitespace-pre-wrap">{snapshot.handover_notes || 'No additional outgoing context.'}</p>
                                {[...(snapshot.pinned_notes ?? []), ...(snapshot.followup_notes ?? [])].map((note, index) => <p key={`${note.id}-${index}`} className="whitespace-pre-wrap">{note.content}</p>)}
                            </CardContent>
                        </Card>
                    </> : <Card className="border-status-warning/30 bg-status-warning-bg">
                        <CardHeader><CardTitle className="flex items-center gap-2"><AlertTriangle className="h-5 w-5" />Saved transfer details unavailable</CardTitle></CardHeader>
                        <CardContent className="text-sm">
                            <p>{snapshotIssue || 'The saved acceptance details could not be verified. Ask a Control Room administrator to review this record.'}</p>
                        </CardContent>
                    </Card>}
                </CommandCentrePage>
            </PageShell>
        </AppLayout>
    );
}
