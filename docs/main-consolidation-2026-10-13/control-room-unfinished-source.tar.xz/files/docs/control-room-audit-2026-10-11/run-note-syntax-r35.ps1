param([switch] $Prepare, [string] $ExpectedInputsSha256)
$ErrorActionPreference = 'Stop'
$crRoot = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$crDocs = Join-Path $crRoot 'docs/control-room-audit-2026-10-11'
$crPhp = 'C:\Users\steph\.config\herd\bin\php84\php.exe'
$crClassifier = 'C:\Users\steph\.codex\worktrees\health-safety-workspace\oblivionfindings\.playwright-cli\hs-process-classifier.ps1'
$crClassifierSha = '19B90A2B70EF320A0FD639AA8752111A16E88513AC9FB98198AC84596D232DEC'
$crInputs = Join-Path $crDocs 'accepted-note-syntax-r35-inputs.json'
$crResult = Join-Path $crDocs 'accepted-note-syntax-r35-result.json'
$crUtf8 = [Text.UTF8Encoding]::new($false)
$crFiles = @(
    'app/Http/Controllers/ControlRoom/ControlRoomReportController.php',
    'app/Services/ControlRoom/ControlRoomReportService.php',
    'tests/Feature/ControlRoom/ControlRoomReportControllerTest.php'
)
function Get-CrHash([string] $Path) { (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash }
function Write-CrJson([string] $Path, $Value) { [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 15) + "`n", $crUtf8) }
if ($Prepare) {
    if (Test-Path -LiteralPath $crInputs) { throw 'Preserve original source image.' }
    $paths = @($PSCommandPath, $crPhp, $crClassifier) + @($crFiles | ForEach-Object { Join-Path $crRoot $_ })
    Write-CrJson $crInputs ([ordered]@{
        atUtc = [DateTime]::UtcNow.ToString('o'); files = $crFiles
        pins = @($paths | ForEach-Object { @{ path = $_; sha256 = Get-CrHash $_ } })
        maxMemoryMiB = 64; deadlineSeconds = 60; bootstrapApplication = $false; phpIniLoaded = $false
    })
    [pscustomobject]@{ prepared = $true; hash = Get-CrHash $crInputs; childStarted = $false } | ConvertTo-Json
    exit 0
}
if (Test-Path -LiteralPath $crResult) { throw 'Preserve original attempt result.' }
if ($ExpectedInputsSha256 -notmatch '^[A-Fa-f0-9]{64}$' -or (Get-CrHash $crInputs) -ne $ExpectedInputsSha256) { throw 'Input image mismatch.' }
$crImage = Get-Content -LiteralPath $crInputs -Raw | ConvertFrom-Json
function Test-CrPins {
    if ((Get-CrHash $crInputs) -ne $ExpectedInputsSha256) { throw 'Source image changed.' }
    foreach ($pin in $crImage.pins) { if ((Get-CrHash $pin.path) -ne $pin.sha256) { throw "Source changed: $($pin.path)" } }
}
Test-CrPins
if ((Get-CrHash $crClassifier) -ne $crClassifierSha) { throw 'Pure heavy-first classifier changed.' }
. ([ScriptBlock]::Create([IO.File]::ReadAllText($crClassifier)))
$crGate = [Threading.Mutex]::new($false, 'Local\OblivionWorkforceMainIntegrationNativeGate')
$crHeld = $false; $crChild = $null; $crIssue = $null; $crAfter = $false; $crStarted = 0
$crSamples = @(); $crChecks = @(); $crOwnClosed = $true; $crStreamsClosed = $true
function Read-CrAdmission {
    $os = @(Get-CimInstance Win32_OperatingSystem -OperationTimeoutSec 10)
    $cpu = @(Get-CimInstance Win32_PerfFormattedData_PerfOS_Processor -Filter "Name='_Total'" -OperationTimeoutSec 10)
    $rows = @(Get-CimInstance Win32_Process -OperationTimeoutSec 10)
    if ($os.Count -ne 1 -or !$os[0].FreePhysicalMemory -or $cpu.Count -ne 1 -or $null -eq $cpu[0].PercentProcessorTime -or $cpu[0].PercentProcessorTime -lt 0 -or $cpu[0].PercentProcessorTime -gt 100 -or $rows.Count -eq 0 -or
        @($rows | Group-Object ProcessId | Where-Object Count -ne 1).Count -gt 0 -or
        @($rows | Where-Object { $null -eq $_.ProcessId -or !$_.Name -or ($_.Name -in @('node.exe', 'php.exe', 'php-cgi.exe', 'mysql.exe') -and !$_.CommandLine) }).Count -gt 0) { throw 'Incomplete resource/process observations.' }
    $classification = Get-ProcessClassification -ObservedProcesses $rows -ToolServiceIdentity $null
    $unknownNative = @($rows | Where-Object { $_.ProcessId -in $classification.unknownIds -and $_.Name -ne 'node.exe' } | ForEach-Object ProcessId)
    $heavy = @($classification.heavyNodeIds) + @($classification.competingNativeIds) + $unknownNative
    $sample = [ordered]@{
        atUtc = [DateTime]::UtcNow.ToString('o'); freeMiB = [math]::Floor($os[0].FreePhysicalMemory / 1024)
        cpuPercent = [int]$cpu[0].PercentProcessorTime; processCount = $rows.Count; heavyPeerIds = $heavy
        unknownNodeIds = @($rows | Where-Object { $_.Name -eq 'node.exe' -and $_.ProcessId -in $classification.unknownIds } | ForEach-Object ProcessId)
        observationsComplete = $true; unknownHostsClassifiedIdle = $false
    }
    $script:crSamples += $sample
    if ($sample.freeMiB -lt 4096 -or $sample.cpuPercent -ge 70 -or $heavy.Count -gt 0) { throw 'Finite source compiler capacity/heavy-peer admission held before child.' }
}
try {
    try { $crHeld = $crGate.WaitOne(0) } catch [Threading.AbandonedMutexException] { $crHeld = $true }
    if (!$crHeld) { throw 'Shared mutex busy.' }
    Read-CrAdmission
    Start-Sleep -Milliseconds 500
    Read-CrAdmission
    $timer = [Diagnostics.Stopwatch]::StartNew()
    foreach ($file in $crFiles) {
        Test-CrPins
        Read-CrAdmission
        if ($timer.Elapsed.TotalSeconds -ge 60) { throw 'Cooperative total deadline reached.' }
        $info = [Diagnostics.ProcessStartInfo]::new()
        $info.FileName = $crPhp; $info.WorkingDirectory = $crRoot; $info.UseShellExecute = $false; $info.CreateNoWindow = $true
        $info.RedirectStandardOutput = $true; $info.RedirectStandardError = $true
        foreach ($argument in @('-n', '-d', 'memory_limit=64M', '-l', (Join-Path $crRoot $file))) { $info.ArgumentList.Add($argument) }
        $crChild = [Diagnostics.Process]::new(); $crChild.StartInfo = $info
        if (!$crChild.Start()) { throw 'Own compiler failed to start.' }
        $crStarted++; $crOwnClosed = $false; $crStreamsClosed = $false
        $out = $crChild.StandardOutput.ReadToEndAsync(); $err = $crChild.StandardError.ReadToEndAsync()
        if (!$crChild.WaitForExit([int][math]::Max(1, 60000 - $timer.ElapsedMilliseconds))) { throw 'Own compiler exceeded total deadline.' }
        $crOwnClosed = $true
        $crStreamsClosed = $out.Wait(3000) -and $err.Wait(3000)
        if (!$crStreamsClosed) { throw 'Own compiler streams incomplete.' }
        $crChecks += @{ path = $file; pid = $crChild.Id; executable = $crPhp; actualExit = $crChild.ExitCode; stdout = $out.Result; stderr = $err.Result; ownExitConfirmed = $true }
        if ($crChild.ExitCode -ne 0) { throw 'Actual source grammar check failed.' }
        $crChild.Dispose(); $crChild = $null
    }
} catch { $crIssue = $_.Exception.Message }
finally {
    try {
        if ($crChild) {
            if (!$crChild.HasExited) { $crChild.Kill($true); if (!$crChild.WaitForExit(10000)) { throw 'Own compiler exit not confirmed.' } }
            $crOwnClosed = $true
            if (!$crStreamsClosed) {
                $crStreamsClosed = $out.Wait(3000) -and $err.Wait(3000)
                if (!$crStreamsClosed) { throw 'Own compiler stream closure not confirmed.' }
                $crChecks += @{ aborted = $true; pid = $crChild.Id; stdout = $out.Result; stderr = $err.Result; ownExitConfirmed = $true }
            }
            $crChild.Dispose()
        }
        Test-CrPins; $crAfter = $true
    } catch { $crIssue = $_.Exception.Message }
    finally { if ($crHeld) { $crGate.ReleaseMutex() }; $crGate.Dispose() }
}
$result = [ordered]@{
    atUtc = [DateTime]::UtcNow.ToString('o'); state = $(if (!$crIssue -and $crChecks.Count -eq $crFiles.Count -and $crAfter) { 'SOURCE_GRAMMAR_PASSED' } else { 'HELD_OR_FAILED' })
    sourceImageSha256 = $ExpectedInputsSha256; issue = $crIssue; compilerChildrenStarted = $crStarted; syntax = $crChecks
    resources = $crSamples; afterReadComplete = $crAfter; ownChildExitConfirmed = $crOwnClosed; streamsClosed = $crStreamsClosed
    memoryMiB = 64; deadlineSeconds = 60; oneChildAtATime = $true; unknownHostsClassifiedIdle = $false
    applicationDatabaseMigrationNativeTestsStarted = $false; runtimeAcceptance = $false
}
Write-CrJson $crResult $result
[pscustomobject]$result | Select-Object state,issue,compilerChildrenStarted,afterReadComplete | ConvertTo-Json
exit $(if ($result.state -eq 'SOURCE_GRAMMAR_PASSED') { 0 } else { 1 })
