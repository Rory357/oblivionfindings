<?php

namespace App\Services\ControlRoom;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Domain\Hr\Services\HrCurrentStaffService;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoomAlert;
use App\Models\RestraintEvent;
use App\Models\User;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\CurrentAuthorizationReads;
use App\Services\HealthSafety\RestraintAccessService;
use App\Services\UserSiteAccessService;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** Eligibility authorizes the operation inside its current evidence callback. */
final class ControlRoomRecipientEligibilityService
{
    private const PERMISSIONS = ['controlRoom.viewAny', 'controlRoom.alerts.view', 'controlRoom.alerts.manage',
        'controlRoom.alerts.assign', 'reports.viewAny', 'medications.controlled.view'];

    public function __construct(
        private readonly HrCurrentStaffService $staff,
        private readonly AuthorizationEvidenceLockService $authorization,
        private readonly UserSiteAccessService $sites,
        private readonly ControlRoomAlertAccessService $alerts,
    ) {}

    /** Denied recipients return null; delivery/write failures still propagate. */
    public function withCurrentEligible(ControlRoomAlert $alert, User|int $recipient, callable $operation, bool $owner = false): mixed
    {
        return DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($alert, $recipient, $operation, $owner) {
            try {
                $current = $this->authorization->lockForUserWithoutWaiting($recipient, self::PERMISSIONS);
                if (! $reads->query($this->staff->currentUsersQuery())->whereKey($current->id)->exists()) {
                    return null;
                }
                $current->setRelation('hrEmployeeProfile', $reads->query(HrEmployeeProfile::query())->where('user_id', $current->id)->first());
                if (! $this->alerts->canRead($current)) {
                    return null;
                }
                $siteIds = $this->sites->accessibleSiteIds($current, ['reports.viewAny'], $reads);
                $visible = ControlRoomAlert::query()->whereKey($alert->id);
                $effectiveSite = $this->sites->alertEffectiveSiteExpression($visible);
                $this->sites->applyAlertSiteScopeForSiteIds($visible, $siteIds);
                if ($current->canDo('reports.viewAny') && ! $this->alerts->isMedicationAlert($alert)) {
                    // Preserve the explicit organisational fallback for a source
                    // whose effective Site is genuinely unavailable.
                    $visible = ControlRoomAlert::query()->whereKey($alert->id)->where(function ($scope) use ($siteIds, $effectiveSite): void {
                        $scope->whereIn(DB::raw($effectiveSite), $siteIds)->orWhereRaw($effectiveSite.' IS NULL');
                    });
                }
                $this->alerts->applyControlledMedicationContentScope($visible, $current);
                $fresh = $reads->query($visible)->first();
                if ($fresh === null) {
                    return null;
                }
                if ($owner) {
                    if (! $current->canDo('controlRoom.alerts.manage') || ! $fresh->isActionable()) {
                        return null;
                    }
                    $duty = $reads->query(Shift::query()->current())->orderBy('id')->first();
                    if ($duty === null || ! in_array((int) $current->id, $duty->memberUserIds(), true)) {
                        return null;
                    }
                }
            } catch (HttpException $exception) {
                if (in_array($exception->getStatusCode(), [403, 404], true)) {
                    return null;
                }
                throw $exception;
            }

            return $this->withSourceAuthority($fresh, $current, fn () => $operation($current, $fresh, $reads));
        }), 3);
    }

    private function withSourceAuthority(ControlRoomAlert $alert, User $current, callable $operation): mixed
    {
        $eventId = data_get($alert->context, 'restraint_event_id') ?? data_get($alert->context, 'normalized_data.restraint_event_id');
        $protected = $alert->alert_type === 'operations.restraint_event' || $eventId !== null;
        if (! $protected) {
            return $operation();
        }
        if (! is_numeric($eventId) || (int) $eventId < 1) {
            return null;
        }

        // This canonical source service arrives in the bounded H&S dependency
        // package. A missing dependency must fail visibly, never grant access.
        $operationStarted = false;
        try {
            return app(RestraintAccessService::class)->withCurrentViewer($current, function ($sourceViewer, CurrentAuthorizationReads $sourceReads, array $siteIds) use ($alert, $eventId, $operation, &$operationStarted) {
                try {
                    $event = $sourceReads->query(RestraintEvent::query())->find((int) $eventId);
                    if ($event === null || (int) $event->client_id !== (int) $alert->client_id
                        || $event->site_id !== $alert->site_id) {
                        return null;
                    }
                    app(RestraintAccessService::class)->assertEvent($event, $sourceViewer, $sourceReads, $siteIds, 'view');
                } catch (HttpException $exception) {
                    if (in_array($exception->getStatusCode(), [403, 404], true)) {
                        return null;
                    }
                    throw $exception;
                }

                $operationStarted = true;

                return $operation();
            });
        } catch (HttpException $exception) {
            if (! $operationStarted && in_array($exception->getStatusCode(), [403, 404], true)) {
                return null;
            }
            throw $exception;
        }
    }
}
