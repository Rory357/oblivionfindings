<?php

namespace App\Services\HealthSafety;

use App\Models\FirstAidRecord;
use App\Models\HsEvent;
use App\Models\User;
use App\Services\CurrentAuthorizationReads;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Builder;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** The same read boundary for a direct H&S event and its linked projections.
 * Source scopes are consumed and materialized inside the caller transaction.
 */
final class HsEventAccessService
{
    public function __construct(private readonly UserSiteAccessService $sites) {}

    public function applyReadableScope(Builder $query, User $viewer, ?HealthSafetyReadContext $context = null): Builder
    {
        if ($context !== null) {
            $context->assertViewer($viewer);

            return $context->consumeSourceViewer(FirstAidAccessService::PERMISSIONS, function ($current) use ($query, $context) {
                if (! $current->canDo('hazards.view')) {
                    return $context->query($query->whereRaw('1 = 0'));
                }
                $context->applyEventSiteScope($query, UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);

                return $this->applyFirstAidSourceScope($query, $current, $context);
            });
        }
        if (! $viewer->canDo('hazards.view')) {
            return $query->whereRaw('1 = 0');
        }

        $this->sites->applyHsEventScope(
            $query,
            $viewer,
            UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS,
        );

        return $this->applyFirstAidSourceScope($query, $viewer, $context);
    }

    /** Intersect only treatment-derived reviews; every other source keeps its existing policy. */
    public function applyFirstAidSourceScope(Builder $query, ?User $viewer, ?HealthSafetyReadContext $context = null): Builder
    {
        $types = array_unique([FirstAidRecord::class, (new FirstAidRecord)->getMorphClass()]);
        if ($context !== null) {
            if ($viewer === null) {
                return $context->query($query->where(fn (Builder $source) => $source->whereNull('hs_events.source_type')->orWhereNotIn('hs_events.source_type', $types)));
            }
            $context->assertViewer($viewer);

            return $context->applyFirstAidEventScope($query, $types);
        }
        $ids = [];
        try {
            $access = app(FirstAidAccessService::class);
            if ($viewer !== null) {
                $ids = $access->withCurrentViewer($viewer, fn ($current, $reads, $sites) => $this->readFirstAidEventIds($current, $reads, $sites, $types));
            }
        } catch (HttpException $error) {
            if ($error->getStatusCode() !== 403) {
                throw $error;
            }
            $ids = [];
        }

        return $query->where(function (Builder $sources) use ($types, $ids): void {
            $sources->whereNull('hs_events.source_type')->orWhereNotIn('hs_events.source_type', $types)
                ->orWhereIn('hs_events.id', $ids);
        });
    }

    /** Exact treatment/event tuple, shared by fresh public reads and bounded context reads. */
    public function readFirstAidEventIds(User $current, CurrentAuthorizationReads $reads, array $sites, array $types, ?HealthSafetyReadContext $context = null): array
    {
        $reads->assertActive();
        $context?->assertViewer($current);
        $access = app(FirstAidAccessService::class);
        $sources = $access->readableQuery($current, $reads, $sites, true, $context)
            ->selectRaw('1')->whereColumn('first_aid_records.id', 'hs_events.source_id')
            ->whereColumn('first_aid_records.site_id', 'hs_events.site_id')
            ->where(function (Builder $subject): void {
                $subject->where(function (Builder $client): void {
                    $client->where('treated_person_type', 'client')->whereColumn('first_aid_records.client_id', 'hs_events.client_id')->whereNull('hs_events.staff_id');
                })->orWhere(function (Builder $staff): void {
                    $staff->where('treated_person_type', 'staff')->whereNull('hs_events.client_id')->where(function (Builder $identity): void {
                        $identity->whereColumn('first_aid_records.treated_person_id', 'hs_events.staff_id')
                            ->orWhere(fn (Builder $unlinked) => $unlinked->whereNull('first_aid_records.treated_person_id')->whereNull('hs_events.staff_id'));
                    });
                })->orWhere(function (Builder $other): void {
                    $other->whereIn('treated_person_type', ['visitor', 'contractor'])->whereNull('hs_events.client_id')->whereNull('hs_events.staff_id');
                });
            });

        return $reads->query(HsEvent::query())->whereIn('source_type', $types)->where('event_category', HsEvent::CATEGORY_INJURY)
            ->whereExists($sources->toBase())->pluck('hs_events.id')->all();
    }

    /** Preserve unrelated and orphan source rows while denying known treatment-derived work. */
    public function applyFirstAidChildSourceScope(Builder $query, string $eventColumn, ?User $viewer, ?HealthSafetyReadContext $context = null): Builder
    {
        $denied = $this->deniedFirstAidEvents($viewer, $context);

        $query->where(fn (Builder $source) => $source->whereNull($eventColumn)->orWhereNotIn($eventColumn, $denied));

        return $context !== null ? $context->query($query) : $query;
    }

    /** Both modern additional provenance and the retained legacy event attachment are binding. */
    public function applyFirstAidRiskSourceScope(Builder $query, ?User $viewer, ?HealthSafetyReadContext $context = null): Builder
    {
        $types = array_unique([HsEvent::class, (new HsEvent)->getMorphClass()]);
        $denied = $this->deniedFirstAidEvents($viewer, $context);
        $eventColumn = $query->qualifyColumn('hs_event_id');
        $query->where(fn (Builder $source) => $source->whereNull($eventColumn)->orWhereNotIn($eventColumn, clone $denied));

        $query->where(function (Builder $source) use ($query, $types, $denied): void {
            $source->whereNull($query->qualifyColumn('assessable_type'))
                ->orWhereNotIn($query->qualifyColumn('assessable_type'), $types)
                ->orWhereNotIn($query->qualifyColumn('assessable_id'), $denied);
        });

        return $context !== null ? $context->query($query) : $query;
    }

    private function deniedFirstAidEvents(?User $viewer, ?HealthSafetyReadContext $context = null): Builder
    {
        $types = array_unique([FirstAidRecord::class, (new FirstAidRecord)->getMorphClass()]);
        $allowed = $this->applyFirstAidSourceScope(HsEvent::query(), $viewer, $context)
            ->whereIn('hs_events.source_type', $types)->pluck('hs_events.id')->all();

        // Retained deleted event provenance cannot make a private source disappear from this guard.
        return HsEvent::withTrashed()->whereIn('hs_events.source_type', $types)
            ->whereNotIn('hs_events.id', $allowed)->select('hs_events.id')->lock('for share nowait');
    }

    public function canView(HsEvent $event, User $viewer, ?HealthSafetyReadContext $context = null): bool
    {
        return $this->applyReadableScope(HsEvent::query()->whereKey($event->id), $viewer, $context)->exists();
    }
}
