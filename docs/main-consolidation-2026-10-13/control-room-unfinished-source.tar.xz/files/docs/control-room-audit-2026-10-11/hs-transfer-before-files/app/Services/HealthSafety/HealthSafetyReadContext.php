<?php

namespace App\Services\HealthSafety;

use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Domain\Hr\Services\HrCurrentStaffService;
use App\Models\HsEvent;
use App\Models\User;
use App\Services\AuthorizationEvidenceLockService;
use App\Services\CurrentAuthorizationReads;
use App\Services\Tasks\TaskItem;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Support\Facades\DB;
use LogicException;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** Fresh locked evidence belongs to exactly one materializing read callback. */
final class HealthSafetyReadContext
{
    private bool $active = true;

    /** @var array<string, list<int>> */
    private array $siteIds = [];

    /** @var array<string, array{approved: list<int>, clients: list<int>}> */
    private array $firstAidSubjects = [];

    /** @var array<string, list<int>> */
    private array $firstAidEvents = [];

    private function __construct(
        private ?User $current,
        private readonly CurrentAuthorizationReads $reads,
        private readonly array $permissionKeys,
        private readonly bool $currentStaff,
    ) {}

    public static function within(User $viewer, array $permissionKeys, callable $consumer): mixed
    {
        return DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($viewer, $permissionKeys, $consumer) {
            $permissionKeys = array_values(array_unique($permissionKeys));
            $current = app(AuthorizationEvidenceLockService::class)->lockForUserWithoutWaiting($viewer, $permissionKeys);
            $currentStaff = $current->approved_at !== null && ! $current->isExternalClinicianAccount()
                && $reads->query(app(HrCurrentStaffService::class)->currentUsersQuery())->whereKey($current->id)->exists();
            $current->setRelation('hrEmployeeProfile', $reads->query(HrEmployeeProfile::query())->where('user_id', $current->id)->first());
            $context = new self($current, $reads, $permissionKeys, $currentStaff);
            try {
                $result = $consumer($context);
                self::assertMaterialized($result);

                return $result;
            } finally {
                $context->active = false;
                $context->current = null;
                $context->siteIds = $context->firstAidSubjects = $context->firstAidEvents = [];
            }
        }));
    }

    public function assertActive(): void
    {
        if (! $this->active || $this->current === null) {
            throw new LogicException('Health and Safety evidence has left its read callback.');
        }
        $this->reads->assertActive();
    }

    /** Execution remains bound to this callback, even if a caller captures the builder. */
    public function query(Builder $query): Builder
    {
        $this->assertActive();

        return $this->reads->query($query);
    }

    public function assertViewer(User $viewer): void
    {
        $this->assertActive();
        if ((int) $viewer->id !== (int) $this->current->id) {
            throw new LogicException('Health and Safety evidence belongs to another viewer.');
        }
    }

    /** Ordinary H&S sources retain their own policy instead of inheriting treatment eligibility. */
    public function consumeSourceViewer(array $requiredPermissionKeys, callable $operation): mixed
    {
        $this->assertActive();
        if (array_diff($requiredPermissionKeys, $this->permissionKeys) !== []) {
            throw new LogicException('The read callback did not prepare the required capabilities.');
        }

        return $operation($this->current, $this->reads);
    }

    /** Union preparation never grants a permission; each consuming operation still checks it. */
    public function consumeViewer(array $requiredPermissionKeys, callable $operation): mixed
    {
        return $this->consumeSourceViewer($requiredPermissionKeys, function ($current, $reads) use ($operation) {
            abort_unless($this->currentStaff, 403);
            $sites = $this->approvedSiteIds(UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);
            abort_unless($sites !== [], 403);

            return $operation($current, $reads, $sites);
        });
    }

    private function approvedSiteIds(array $bypassPermissions): array
    {
        $this->assertActive();
        sort($bypassPermissions);
        $key = json_encode($bypassPermissions, JSON_THROW_ON_ERROR);
        if (! array_key_exists($key, $this->siteIds)) {
            $this->siteIds[$key] = app(UserSiteAccessService::class)->accessibleSiteIds($this->current, $bypassPermissions, $this->reads);
        }

        return $this->siteIds[$key];
    }

    /** Canonical H&S Site/null-Site semantics, using this callback's fresh evidence. */
    public function applyEventSiteScope(Builder $query, array $bypassPermissions): Builder
    {
        return $this->consumeSourceViewer($bypassPermissions, function ($current) use ($query, $bypassPermissions) {
            $sites = $this->approvedSiteIds($bypassPermissions);
            $wide = app(UserSiteAccessService::class)->canBypass($current, $bypassPermissions);
            if ($sites === [] && ! $wide) {
                return $this->query($query->whereRaw('1 = 0'));
            }
            $query->where(function (Builder $scope) use ($sites, $wide): void {
                if ($sites !== []) {
                    $scope->whereIn('site_id', $sites);
                }
                if ($wide) {
                    $sites === [] ? $scope->whereNull('site_id') : $scope->orWhereNull('site_id');
                }
            });

            return $this->query($query);
        });
    }

    /** Subject identities remain private; the canonical query consumes them inside this callback. */
    public function withFirstAidSubjects(array $siteIds, bool $includeArchived, callable $operation): mixed
    {
        $this->assertActive();
        $approved = $this->approvedSiteIds(UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);
        if (array_diff($siteIds, $approved) !== []) {
            throw new LogicException('The source query requested Sites outside its read callback.');
        }
        sort($siteIds);
        // Archival changes the treatment query, never the active Site/readable Client universe.
        // Keep that option on the source query and its event whitelist, not subject preparation.
        $key = json_encode([$siteIds, UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS], JSON_THROW_ON_ERROR);
        if (! array_key_exists($key, $this->firstAidSubjects)) {
            $this->firstAidSubjects[$key] = $this->consumeViewer(FirstAidAccessService::PERMISSIONS,
                fn ($current, $reads) => app(FirstAidAccessService::class)->readableSubjects($current, $reads, $siteIds));
        }
        $this->assertActive();

        return $operation($this->firstAidSubjects[$key]['approved'], $this->firstAidSubjects[$key]['clients']);
    }

    public function applyFirstAidEventScope(Builder $query, array $sourceTypes): Builder
    {
        $this->assertActive();
        sort($sourceTypes);
        // The source reader deliberately includes archived treatment, and requires an exact injury tuple.
        $key = json_encode([$sourceTypes, true, HsEvent::CATEGORY_INJURY, UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS], JSON_THROW_ON_ERROR);
        if (! array_key_exists($key, $this->firstAidEvents)) {
            try {
                $this->firstAidEvents[$key] = $this->consumeViewer(FirstAidAccessService::PERMISSIONS,
                    fn ($current, $reads, $sites) => app(HsEventAccessService::class)->readFirstAidEventIds($current, $reads, $sites, $sourceTypes, $this));
            } catch (HttpException $error) {
                if ($error->getStatusCode() !== 403) {
                    throw $error;
                }
                $this->firstAidEvents[$key] = [];
            }
        }
        $this->assertActive();
        $ids = $this->firstAidEvents[$key];
        // A source inserted after this preparation stays excluded, including when ids is empty.
        $query->where(function (Builder $sources) use ($sourceTypes, $ids): void {
            $sources->whereNull('hs_events.source_type')->orWhereNotIn('hs_events.source_type', $sourceTypes)
                ->orWhereIn('hs_events.id', $ids);
        });

        return $this->reads->query($query);
    }

    private static function assertMaterialized(mixed $result): void
    {
        if ($result instanceof Model || $result instanceof Builder || $result instanceof QueryBuilder
            || $result instanceof self || $result instanceof CurrentAuthorizationReads) {
            throw new LogicException('Read callbacks may return only materialized source and task projections.');
        }
        if ($result instanceof TaskItem) {
            foreach (get_object_vars($result) as $value) {
                self::assertMaterialized($value);
            }
        } elseif (is_array($result)) {
            foreach ($result as $value) {
                self::assertMaterialized($value);
            }
        } elseif (is_object($result)) {
            throw new LogicException('Read callbacks may not return authority objects.');
        }
    }
}
