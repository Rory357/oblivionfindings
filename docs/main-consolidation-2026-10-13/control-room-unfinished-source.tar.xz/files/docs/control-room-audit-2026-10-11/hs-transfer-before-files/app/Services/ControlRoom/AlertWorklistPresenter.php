<?php

namespace App\Services\ControlRoom;

use App\Models\ControlRoomAlert;
use App\Models\User;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

class AlertWorklistPresenter
{
    public function __construct(
        private readonly AlertPriorityService $priority,
        private readonly ControlRoomAlertProvenanceService $provenance,
        private readonly ControlRoomAlertAccessService $access,
        private readonly ControlRoomGovernanceReadService $governance,
        private readonly ControlRoomSourceContentService $sourceContent,
        private readonly AlertReportingService $reporting,
    ) {}

    /** @param iterable<ControlRoomAlert> $alerts */
    public function governanceForAlerts(iterable $alerts, User $viewer): Collection
    {
        $alerts = collect($alerts);
        $governance = $this->governance->forAlerts($alerts, $viewer);
        $reporting = $this->reporting->forAlerts($alerts, $viewer, $governance);

        return $governance->map(fn (array $record, int $id): array => $record + ['reporting' => $reporting->get($id)]);
    }

    public function reportingForAlerts(iterable $alerts, User $viewer, ?Collection $governance = null): Collection
    {
        return $this->reporting->forAlerts($alerts, $viewer, $governance);
    }

    /** @return array<string, mixed> */
    public function present(
        ControlRoomAlert $alert,
        User $viewer,
        ?bool $canManageAlerts = null,
        ?array $governance = null,
        ?array $reporting = null,
    ): array {
        $alert->loadMissing([
            'site:id,name',
            'client:id,first_name,last_name,site_id,organization_id',
            'client.site:id,name,tenant_id',
            'sla',
            'queue:id,name,tier',
            'playbookRun.playbook:id,name',
        ]);

        $client = $this->provenance->safeClient($alert);
        $assignee = $alert->relationLoaded('assignedTo')
            ? $alert->assignedTo
            : $this->provenance->safeAssignedTo($alert, $viewer);
        $context = $this->provenance->sanitiseContextForRead($alert);
        $site = $alert->site ?? $client?->site;
        $deadline = $this->priority->nextDeadline($alert);
        $slaStatus = $alert->sla?->getStatus();
        $governance ??= $this->governanceForAlerts([$alert], $viewer)->get((int) $alert->id);
        $incident = $governance['incident'];
        $event = $governance['hs_event'];
        $sourceContent = $this->sourceContent->present($alert, $governance, $context);
        $reporting ??= $governance['reporting'] ?? $this->reportingForAlerts([$alert], $viewer, collect([(int) $alert->id => $governance]))->get((int) $alert->id);

        return [
            'id' => $alert->id,
            'reference_number' => $alert->reference_number ?: null,
            'summary' => $sourceContent['summary'],
            'summary_origin' => $sourceContent['summary_origin'],
            'source' => [
                'key' => $alert->source,
                'label' => Str::headline((string) $alert->source),
            ],
            'status' => $alert->status,
            'severity' => $alert->severity,
            'reporting' => $reporting,
            'priority' => $this->priority->describe($alert),
            'playbook' => $alert->playbookRun ? [
                'name' => $alert->playbookRun->playbook?->name,
                'status' => $alert->playbookRun->status,
                'completed_steps' => (int) $alert->playbookRun->completed_steps,
                'total_steps' => (int) $alert->playbookRun->total_steps,
            ] : null,
            'triggered_at' => $alert->triggered_at?->toIso8601String(),
            'next_deadline_at' => $deadline?->toIso8601String(),
            'sla' => [
                'status' => $slaStatus,
                'next_deadline_at' => $deadline?->toIso8601String(),
            ],
            'site' => $site ? ['id' => $site->id, 'name' => $site->name] : null,
            'person' => $client ? [
                'id' => $client->id,
                'name' => trim($client->first_name.' '.$client->last_name),
            ] : null,
            'assignee' => $assignee ? ['id' => $assignee->id, 'name' => $assignee->name] : null,
            'queue' => $alert->queue ? ['id' => $alert->queue->id, 'name' => $alert->queue->name] : null,
            'journey' => [
                'incident_access' => $governance['incident_access'],
                'health_safety_access' => $governance['health_safety_access'],
                'incident_reference' => $governance['incident_access'] === 'readable'
                    ? ($incident->reference_number ?: 'INC-'.$incident->id) : null,
                'health_safety_reference' => $governance['health_safety_access'] === 'readable'
                    ? ($event->reference_number ?: 'HS-'.$event->id) : null,
                'handover_status' => $event?->handover_status,
            ],
            'next_action' => ($canManageAlerts ?? $viewer->canDo('controlRoom.alerts.manage'))
                ? ['label' => 'Continue response', 'href' => '/control-room/alerts/'.$alert->id]
                : ['label' => 'View alert', 'href' => '/control-room/alerts/'.$alert->id],
            'actions' => $this->actions($alert, $viewer, $governance, $reporting),
            'href' => '/control-room/alerts/'.$alert->id,
        ];
    }

    /** @return array<string, bool|string|null> */
    private function actions(ControlRoomAlert $alert, User $viewer, array $governance, array $reporting): array
    {
        $capabilities = $this->access->capabilitiesForScopedAlert($viewer);
        $actionable = $alert->isActionable();
        $canViewIncident = $governance['incident_access'] === 'readable';
        $canViewHealthSafety = $governance['health_safety_access'] === 'readable';

        return [
            'can_claim' => $actionable
                && $capabilities['assign']
                && $alert->assigned_to_user_id === null,
            'can_acknowledge' => $actionable
                && $capabilities['manage']
                && $alert->status === ControlRoomAlert::STATUS_OPEN,
            'can_move_queue' => $actionable && $capabilities['manage'],
            'can_escalate' => $actionable && $capabilities['escalate'],
            'can_create_incident' => $reporting['canCreate'],
            'can_snooze' => $actionable
                && $capabilities['manage']
                && ! $alert->isSnoozed()
                && $alert->severity !== 'critical',
            'can_unsnooze' => $actionable
                && $capabilities['manage']
                && $alert->isSnoozed(),
            'can_copy_reference' => true,
            'incident_href' => $canViewIncident
                ? '/incidents/'.$governance['incident']->id
                : null,
            'health_safety_href' => $canViewHealthSafety
                ? '/health-safety/events/'.$governance['hs_event']->id
                : null,
        ];
    }
}
