<?php

namespace App\Services\ControlRoom;

use App\Models\ClientIncident;
use App\Models\ControlRoomAlert;
use App\Models\User;
use App\Services\Incidents\IncidentAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;

/** Read-only disclosure of incident material copied into an operational record. */
final class ControlRoomSourceContentService
{
    public function __construct(private readonly IncidentAccessService $incidents) {}

    public const RESTRICTED = 'Incident details restricted';

    public const UNAVAILABLE = 'Incident details unavailable';

    /**
     * The canonical records and access states are supplied once per list by
     * ControlRoomGovernanceReadService. This projector performs no queries.
     */
    public function present(ControlRoomAlert $alert, array $governance, array $context): array
    {
        $raw = is_array($alert->context) ? $alert->context : [];
        $incidentOrigin = $alert->source === 'incident'
            || data_get($raw, 'provenance.source') === 'incident_journey'
            || ($raw['incident_source_type'] ?? null) === 'client_incident';
        $rootAccess = $this->incidentAccess($this->entryIncidentId($raw), $governance);
        if ($incidentOrigin && $rootAccess !== 'readable') {
            $context = Arr::except($context, [
                'incident_id', 'incident_type', 'type', 'shift_id', 'occurred_at',
                'description', 'title', 'summary', 'reported_by', 'reason', 'provenance',
                'incident_source_type', 'incident_source_id',
            ]);
            $context['incident_content_access'] = $rootAccess;
        }

        if (data_get($raw, 'normalized_data.incident_id') !== null
            && $this->incidentAccess(data_get($raw, 'normalized_data.incident_id'), $governance) !== 'readable') {
            unset($context['normalized_data'], $context['signal_payload']);
            $context['incident_content_access'] = $this->incidentAccess(data_get($raw, 'normalized_data.incident_id'), $governance);
        }

        foreach (['resolution', 'journey_attention'] as $key) {
            if (is_array($context[$key] ?? null) && $this->isIncidentEntry($context[$key])) {
                $context[$key] = $this->entry($context[$key], $governance);
            }
        }
        foreach (['resolution_history', 'operational_reopen_history'] as $key) {
            if (is_array($context[$key] ?? null)) {
                $context[$key] = array_map(fn ($entry) => is_array($entry) && $this->isIncidentEntry($entry)
                    ? $this->entry($entry, $governance) : $entry, $context[$key]);
            }
        }
        if (is_array($context['activity_log'] ?? null)) {
            $context['activity_log'] = array_map(function ($entry) use ($raw, $governance) {
                if (! is_array($entry) || ($entry['transition'] ?? null) !== 'incident_reopen') {
                    return $entry;
                }
                $sourceId = $entry['incident_id'] ?? null;
                if ($sourceId === null) {
                    // Older activity copies did not record the source ID. Only
                    // an exact matching source-history entry can establish it.
                    $matches = collect($raw['operational_reopen_history'] ?? [])->filter(fn ($history) => is_array($history)
                        && ($history['reason'] ?? null) === ($entry['content'] ?? null)
                        && $this->sameInstant($history['reopened_at'] ?? null, $entry['created_at'] ?? null)
                        && ($history['actor_id'] ?? null) === ($entry['user_id'] ?? null));
                    $ids = $matches->pluck('incident_id')->map(fn ($id) => $this->positiveId($id))->unique();
                    $sourceId = $ids->count() === 1 ? $ids->first() : null;
                }

                return $this->entry($entry + ['incident_id' => $sourceId], $governance);
            }, $context['activity_log']);
        }
        $context = $this->references($context, $governance);
        unset($context['notes_provenance']);

        $notesSourceIds = $this->noteSourceIds($alert);
        $notesAccess = $this->combinedAccess($notesSourceIds, $governance);
        $notes = $notesAccess === 'readable' ? $alert->notes : null;
        $candidates = [
            [$context['title'] ?? null, $incidentOrigin],
            [$context['summary'] ?? null, $incidentOrigin],
            [$context['description'] ?? null, $incidentOrigin],
            [data_get($context, 'normalized_data.title'), data_get($raw, 'normalized_data.incident_id') !== null],
            [data_get($context, 'normalized_data.description'), data_get($raw, 'normalized_data.incident_id') !== null],
            [$notes, $notesSourceIds !== []],
        ];
        $summary = Str::headline((string) $alert->alert_type);
        $origin = ['type' => 'alert'];
        foreach ($candidates as [$candidate, $fromIncident]) {
            if (is_string($candidate) && trim($candidate) !== '') {
                $summary = Str::limit(trim($candidate), 160);
                $origin = $fromIncident
                    ? ['type' => 'incident', 'incident_id' => ($governance['incident'] ?? null)?->id]
                    : ['type' => 'alert'];
                break;
            }
        }

        $resolverVisible = data_get($raw, 'resolution.source') !== 'incident_lifecycle_signal'
            || $this->incidentAccess(data_get($raw, 'resolution.incident_id'), $governance) === 'readable';
        $acknowledgerFromIncident = data_get($raw, 'resolution.acknowledged_from_incident')
            ?? ($alert->acknowledged_by_user_id !== null
                && $alert->acknowledged_by_user_id === ($alert->resolved_by_user_id ?? data_get($raw, 'resolution.incident_lifecycle_actor_user_id'))
                && $this->sameInstant($alert->acknowledged_at?->toIso8601String(), data_get($raw, 'resolution.resolved_at')));

        return ['context' => $context, 'notes' => $notes, 'notes_access' => $notesAccess,
            'source_creator_visible' => ! $incidentOrigin || $rootAccess === 'readable',
            'source_resolver_visible' => $resolverVisible,
            'source_acknowledger_visible' => $resolverVisible || ! $acknowledgerFromIncident,
            'summary' => $summary, 'summary_origin' => $origin];
    }

    /** Keep SQL search/count/pagination on the same side of the copied-note boundary. */
    public function applyReadableNotes(Builder $query, User $viewer): Builder
    {
        $readable = $this->incidents->apply(ClientIncident::query(), $viewer)->select('client_incidents.id')
            ->where(function (Builder $source): void {
                $source->whereColumn('client_incidents.control_room_alert_id', 'control_room_alerts.id')
                    ->orWhere(function (Builder $legacy): void {
                        $legacy->whereNull('client_incidents.control_room_alert_id')
                            ->whereRaw("client_incidents.id = CAST(JSON_UNQUOTE(JSON_EXTRACT(control_room_alerts.context, '$.incident_id')) AS UNSIGNED)")
                            ->whereNotExists(fn (QueryBuilder $direct) => $direct->selectRaw('1')
                                ->from('client_incidents as direct_incident')
                                ->whereColumn('direct_incident.control_room_alert_id', 'control_room_alerts.id'));
                    });
            });
        $copies = <<<'SQL'
JSON_TABLE(
    JSON_MERGE_PRESERVE(
        CASE WHEN JSON_TYPE(JSON_EXTRACT(control_room_alerts.context, '$.resolution_history')) = 'ARRAY'
            THEN JSON_EXTRACT(control_room_alerts.context, '$.resolution_history') ELSE JSON_ARRAY() END,
        JSON_ARRAY(JSON_EXTRACT(control_room_alerts.context, '$.resolution'), JSON_EXTRACT(control_room_alerts.context, '$.notes_provenance'))
    ), '$[*]' COLUMNS (
        source VARCHAR(80) PATH '$.source' NULL ON EMPTY NULL ON ERROR,
        incident_id BIGINT PATH '$.incident_id' NULL ON EMPTY NULL ON ERROR,
        reason LONGTEXT PATH '$.reason' NULL ON EMPTY NULL ON ERROR,
        text_sha256 VARCHAR(64) PATH '$.text_sha256' NULL ON EMPTY NULL ON ERROR
    )
) AS copied_note
SQL;

        return $query->whereNotExists(function (QueryBuilder $hidden) use ($copies, $readable): void {
            $hidden->selectRaw('1')->fromRaw($copies)
                ->where('copied_note.source', 'incident_lifecycle_signal')
                ->where(function (QueryBuilder $matches): void {
                    $matches->where(function (QueryBuilder $reason): void {
                        $reason->whereNotNull('copied_note.reason')->where('copied_note.reason', '!=', '')
                            ->whereRaw('LOCATE(CAST(copied_note.reason AS BINARY), CAST(control_room_alerts.notes AS BINARY)) > 0');
                    })->orWhereRaw('copied_note.text_sha256 = SHA2(control_room_alerts.notes, 256)');
                })->where(fn (QueryBuilder $denied) => $denied->whereNull('copied_note.incident_id')
                ->orWhereNotIn('copied_note.incident_id', $readable->toBase()));
        })->whereNot(function (Builder $unknown): void {
            $unknown->where('control_room_alerts.source', 'compliance')
                ->where('control_room_alerts.alert_type', 'Incident Reported')
                ->where('control_room_alerts.notes', 'like', 'New incident reported - %');
        });
    }

    /** @return list<int|null> Empty means independently authored operational notes. */
    public function noteSourceIds(ControlRoomAlert $alert): array
    {
        if (! is_string($alert->notes) || $alert->notes === '') {
            return [];
        }
        $context = is_array($alert->context) ? $alert->context : [];
        $copies = [($context['resolution'] ?? null), ...array_values(is_array($context['resolution_history'] ?? null) ? $context['resolution_history'] : [])];
        $ids = [];
        foreach ($copies as $copy) {
            if (is_array($copy) && ($copy['source'] ?? null) === 'incident_lifecycle_signal'
                && is_string($copy['reason'] ?? null) && $copy['reason'] !== ''
                && str_contains($alert->notes, $copy['reason'])) {
                $ids[] = $this->positiveId($copy['incident_id'] ?? null);
            }
        }
        $provenance = $context['notes_provenance'] ?? null;
        if (is_array($provenance) && ($provenance['source'] ?? null) === 'incident_lifecycle_signal'
            && hash_equals((string) ($provenance['text_sha256'] ?? ''), hash('sha256', $alert->notes))) {
            $ids[] = $this->positiveId($provenance['incident_id'] ?? null);
        }
        if ($alert->source === 'compliance' && $alert->alert_type === 'Incident Reported'
            && str_starts_with($alert->notes, 'New incident reported - ')) {
            // This legacy writer accepted any Model, so a numeric ID alone
            // cannot prove that it was a ClientIncident rather than another source.
            $ids[] = null;
        }

        return array_values(array_unique($ids, SORT_REGULAR));
    }

    public function audit(array $row, array $governance, array $context = []): array
    {
        $meta = is_array($row['meta'] ?? null) ? $row['meta'] : [];
        if (! isset($meta['incident_id']) && ($meta['resolution_source'] ?? null) === 'incident_lifecycle_signal') {
            $matches = collect($context['resolution_history'] ?? [])->filter(fn ($entry) => is_array($entry)
                && ($entry['source'] ?? null) === 'incident_lifecycle_signal'
                && isset($meta['transitioned_at'])
                && $this->sameInstant($entry['resolved_at'] ?? null, $meta['transitioned_at']));
            $ids = $matches->pluck('incident_id')->map(fn ($id) => $this->positiveId($id))->unique();
            $meta['incident_id'] = $ids->count() === 1 ? $ids->first() : null;
        }
        if ($this->isIncidentEntry($meta)
            || ($meta['resolution_source'] ?? null) === 'incident_lifecycle_signal'
            || in_array($row['action'] ?? null, ['controlRoom.alert.reopenForIncident', 'controlRoom.alert.reopenFromIncidentSignal'], true)) {
            $access = $this->incidentAccess($this->entryIncidentId($meta), $governance);
            $row['meta'] = $this->entry($meta, $governance);
            if ($access !== 'readable') {
                $row['user'] = null;
            }
        } else {
            $row['meta'] = $this->references($meta, $governance);
        }

        return $row;
    }

    public function snapshotSummary(array $row, ?ControlRoomAlert $alert, array $governance): array
    {
        if (! array_key_exists('summary', $row)) {
            return $row;
        }
        $origin = $row['summary_origin'] ?? null;
        if (($origin['type'] ?? null) === 'alert' || ($origin['type'] ?? null) === 'withheld') {
            return $row;
        }
        $access = ($origin['type'] ?? null) === 'incident'
            ? $this->incidentAccess($origin['incident_id'] ?? null, $governance)
            : 'unavailable';
        if ($access === 'readable') {
            return $row;
        }
        if ($origin === null && $alert !== null
            && ($governance['incident_access'] ?? 'unavailable') === 'absent'
            && ($governance['health_safety_access'] ?? 'unavailable') === 'absent'
            && $this->noteSourceIds($alert) === [] && $alert->source !== 'incident') {
            return $row;
        }
        $row['summary'] = $access === 'restricted' ? self::RESTRICTED : 'Saved summary details unavailable';
        $row['summary_origin'] = ['type' => 'withheld'];

        return $row;
    }

    private function entry(array $entry, array $governance): array
    {
        $access = $this->incidentAccess($this->entryIncidentId($entry), $governance);
        if ($access === 'readable') {
            return $this->references($entry, $governance);
        }
        $minimal = Arr::only($entry, ['type', 'transition', 'resolved_at', 'reopened_at', 'created_at',
            'from_status', 'to_status', 'requires_operational_reopen']);
        $minimal['access'] = $access;
        foreach (['reason', 'content'] as $key) {
            if (array_key_exists($key, $entry)) {
                $minimal[$key] = $access === 'restricted' ? self::RESTRICTED : self::UNAVAILABLE;
            }
        }

        return $minimal;
    }

    private function references(array $data, array $governance): array
    {
        if ((array_key_exists('incident_id', $data) || ($data['incident_source_type'] ?? null) === 'client_incident')
            && $this->incidentAccess($this->entryIncidentId($data), $governance) !== 'readable') {
            $data = Arr::except($data, ['incident_id', 'incident_reference', 'incident_reference_number', 'incident_source_type', 'incident_source_id']);
        }
        if (array_key_exists('hs_event_id', $data)
            && (($governance['health_safety_access'] ?? null) !== 'readable'
                || $this->positiveId($data['hs_event_id']) !== ($governance['hs_event'] ?? null)?->id)) {
            $data = Arr::except($data, ['hs_event_id', 'hs_event_reference', 'health_safety_reference']);
        }

        return $data;
    }

    private function isIncidentEntry(array $entry): bool
    {
        return array_key_exists('incident_id', $entry)
            || ($entry['incident_source_type'] ?? null) === 'client_incident'
            || ($entry['source'] ?? null) === 'incident_lifecycle_signal'
            || ($entry['type'] ?? null) === 'incident_reopened';
    }

    private function combinedAccess(array $ids, array $governance): string
    {
        $access = array_map(fn ($id) => $this->incidentAccess($id, $governance), $ids);

        return in_array('unavailable', $access, true) ? 'unavailable'
            : (in_array('restricted', $access, true) ? 'restricted' : 'readable');
    }

    private function entryIncidentId(array $entry): ?int
    {
        if (($entry['incident_source_type'] ?? null) === 'client_incident') {
            $id = $this->positiveId($entry['incident_source_id'] ?? null);
            if (array_key_exists('incident_id', $entry) && $this->positiveId($entry['incident_id']) !== $id) {
                return null;
            }

            return $id;
        }

        return $this->positiveId($entry['incident_id'] ?? null);
    }

    private function incidentAccess(mixed $id, array $governance): string
    {
        $id = $this->positiveId($id);
        if ($id === null || $id !== (($governance['incident'] ?? null)?->id)) {
            return 'unavailable';
        }

        return ($governance['incident_access'] ?? null) === 'readable' ? 'readable' : 'restricted';
    }

    private function positiveId(mixed $id): ?int
    {
        return filter_var($id, FILTER_VALIDATE_INT) !== false && (int) $id > 0 ? (int) $id : null;
    }

    private function sameInstant(mixed $left, mixed $right): bool
    {
        if (! is_string($left) || trim($left) === '' || ! is_string($right) || trim($right) === '') {
            return false;
        }
        try {
            return Carbon::parse($left)->equalTo(Carbon::parse($right));
        } catch (\Throwable) {
            return false;
        }
    }
}
