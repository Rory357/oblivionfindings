<?php

namespace App\Services\ControlRoom;

use App\Models\AuditLog;
use App\Models\ControlRoom\Shift;
use App\Models\ControlRoom\TriageQueue;
use App\Models\ControlRoomAlert;
use App\Models\Site;
use App\Models\User;
use App\Services\UserSiteAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class ControlRoomDeskService
{
    /** @var list<string> */
    private const BYPASS_PERMISSIONS = ['reports.viewAny'];

    /** @var list<string> */
    private const ACTIVE_STATUSES = [
        ControlRoomAlert::STATUS_OPEN,
        ControlRoomAlert::STATUS_ACK,
        ControlRoomAlert::STATUS_TRIAGING,
        ControlRoomAlert::STATUS_CONFIRMED,
    ];

    /** @var array<string, array<string, mixed>> */
    private array $liveSnapshots = [];

    public function __construct(
        private readonly AlertWorklistQuery $worklistQuery,
        private readonly AlertWorklistPresenter $worklistPresenter,
        private readonly ControlRoomAlertAccessService $alertAccess,
        private readonly UserSiteAccessService $siteAccess,
        private readonly ControlRoomReportService $reports,
        private readonly ControlRoomGovernanceReadService $governance,
        private readonly AlertReportingService $reporting,
    ) {}

    public function prepareViewerAccess(User $user): void
    {
        $user->loadMissing([
            'permissionOverrides:id,key',
            'roles.permissions:id,key',
            'hrEmployeeProfile',
        ]);
    }

    /**
     * @param  array<string, mixed>  $input
     * @return array{q: string, status: string, severity: string, source: string, queue_id: int|null, assigned_to: string, escalation_level: int|null, date_from: string, date_to: string, sort: string, dir: string, site_id: int|null, period: string}
     */
    public function filters(User $user, array $input): array
    {
        $this->prepareViewerAccess($user);

        $siteId = filled($input['site_id'] ?? null) ? (int) $input['site_id'] : null;
        if ($siteId !== null) {
            $this->siteAccess->assertCanAccessSiteId(
                $user,
                $siteId,
                self::BYPASS_PERMISSIONS,
                'You are not authorized to access the Control Room Desk for that site.',
            );
        }

        return [
            'q' => trim((string) ($input['q'] ?? $input['search'] ?? '')),
            'status' => $this->allowed((string) ($input['status'] ?? ''), [
                ...ControlRoomAlert::VALID_STATUSES,
                'all',
            ]),
            'severity' => $this->allowed((string) ($input['severity'] ?? ''), ['critical', 'high', 'medium', 'low', 'all']),
            'source' => trim((string) ($input['source'] ?? '')),
            'queue_id' => filled($input['queue_id'] ?? null) ? max(1, (int) $input['queue_id']) : null,
            'assigned_to' => trim((string) ($input['assigned_to'] ?? '')),
            'escalation_level' => filled($input['escalation_level'] ?? null)
                ? max(1, (int) $input['escalation_level'])
                : null,
            'date_from' => $this->dateFilter($input['date_from'] ?? null),
            'date_to' => $this->dateFilter($input['date_to'] ?? null),
            'sort' => $this->allowed((string) ($input['sort'] ?? ''), ['severity', 'triggered_at']),
            'dir' => $this->allowed((string) ($input['dir'] ?? ''), ['asc', 'desc']),
            'site_id' => $siteId,
            'period' => $this->allowed((string) ($input['period'] ?? '7d'), ['24h', '7d', '30d', '90d']) ?: '7d',
            'reporting' => $this->allowed((string) ($input['reporting'] ?? ''), ['required', 'decision_needed', 'not_required', 'linked']),
            'handover_state' => $this->allowed((string) ($input['handover_state'] ?? ''), ['awaiting_acceptance', 'accepted_in_progress', 'governance_open', 'unavailable']),
        ];
    }

    /** @param array<string, mixed> $input @return array<string, mixed> */
    public function live(User $user, array $input = []): array
    {
        $filters = $this->filters($user, $input);
        $key = $user->id.':'.md5(serialize($filters));

        return $this->liveSnapshots[$key] ??= $this->buildLive($user, $filters);
    }

    /** @param array<string, mixed> $input @return array<string, mixed> */
    public function analytics(User $user, array $input = []): array
    {
        $filters = $this->filters($user, $input);
        [$from, $to] = $this->period($filters['period']);
        $siteScope = $this->reportSiteScope($user, $filters['site_id']);

        // Current source/privacy authority must be evaluated on every request.
        return [
            'period' => $filters['period'],
            'volume' => $this->reports->alertVolume($from, $to, $siteScope, $user),
            'sla' => $this->reports->slaCompliance($from, $to, $siteScope, $user),
            'escalation' => $this->reports->escalationAnalysis($from, $to, $siteScope, $user),
            'sla_daily_trend' => $this->reports->slaDailyTrend($from, $to, $siteScope, $user),
            'sites' => $this->reports->siteComparison($from, $to, $siteScope, $user),
            'cached_for_seconds' => 0,
        ];
    }

    /** @return array<int, array{id: int, name: string}> */
    public function sites(User $user): array
    {
        return Site::query()
            ->active()
            ->tap(fn (Builder $query) => $this->siteAccess->applySiteScope($query, $user, self::BYPASS_PERMISSIONS))
            ->orderBy('name')
            ->get(['id', 'name'])
            ->map(fn (Site $site) => ['id' => $site->id, 'name' => $site->name])
            ->all();
    }

    /** @return array<int, array{id: int, name: string}> */
    public function staff(User $user): array
    {
        return User::query()
            ->staff()
            ->tap(fn (Builder $query) => $this->siteAccess->applyControlRoomAssigneeScope($query, $user, self::BYPASS_PERMISSIONS))
            ->orderBy('name')
            ->get(['id', 'name'])
            ->map(fn (User $staff) => ['id' => $staff->id, 'name' => $staff->name])
            ->all();
    }

    /** @param array<string, mixed> $filters @return array<string, mixed> */
    private function buildLive(User $user, array $filters): array
    {
        $aggregate = $this->aggregate($user, $filters);
        $worklist = $this->worklist($user, $filters);

        return [
            'hero' => $this->hero($aggregate),
            'worklist' => $worklist,
            'queues' => $this->queues($user, $filters),
            'handover' => [
                'needs_incident' => (int) $aggregate->needs_incident,
                'decision_needed' => (int) $aggregate->decision_needed,
                'awaiting_health_safety' => (int) $aggregate->awaiting_health_safety,
                'accepted_in_progress' => (int) $aggregate->accepted_in_progress,
                'operational_complete_governance_open' => (int) $aggregate->operational_complete_governance_open,
                'coverage' => [
                    'state' => $aggregate->workflow_unavailable > 0 ? 'incomplete' : 'complete',
                    'unavailable' => (int) $aggregate->workflow_unavailable,
                    'href' => '/control-room?'.http_build_query([...$filters, 'reporting' => '', 'handover_state' => 'unavailable']),
                ],
            ],
            'activity' => $this->activity($user, $filters),
            'freshness' => [
                'updated_at' => now()->toIso8601String(),
                'stale_after_seconds' => 90,
            ],
            'stats' => $this->legacyStats($aggregate),
            'by_source' => $this->bySource($user, $filters),
            'source_options' => array_map(fn (string $source): array => ['key' => $source, 'label' => Str::headline($source)], array_keys($this->bySource($user, [...$filters, 'source' => '']))),
            'active_shift' => $this->activeShift($user),
        ];
    }

    /** @return array<string, int> */
    private function bySource(User $user, array $filters): array
    {
        $query = $this->matchingQuery($user, $filters)->setEagerLoads([])->reorder();

        return $query
            ->select('control_room_alerts.source', DB::raw('COUNT(*) as aggregate'))
            ->groupBy('control_room_alerts.source')
            ->pluck('aggregate', 'source')
            ->map(fn ($count) => (int) $count)
            ->all();
    }

    /** @return array{name: string, lead_name: string|null, started_at: string|null}|null */
    private function activeShift(User $user): ?array
    {
        $shift = Shift::query()
            ->with('shiftLead:id,name')
            ->current()
            ->latest('starts_at')
            ->first();

        return $shift ? [
            'name' => $shift->name,
            'lead_name' => $shift->shiftLead?->name,
            'started_at' => $shift->starts_at?->toIso8601String(),
        ] : null;
    }

    /** @param array<string, mixed> $filters @return array<string, mixed> */
    private function matchingQuery(User $user, array $filters, ?string $lens = null): Builder
    {
        $status = $filters['status'];
        $lens ??= filled($filters['handover_state']) ? 'all_records'
            : (in_array($status, ControlRoomAlert::TERMINAL_STATUSES, true) ? 'history' : 'active');
        $assignedTo = $filters['assigned_to'] === 'me'
            ? $user->id
            : (is_numeric($filters['assigned_to']) ? (int) $filters['assigned_to'] : null);

        $query = $this->worklistQuery->forUser($user, array_filter([
            'lens' => $lens,
            'site_id' => $filters['site_id'],
            'severity' => $filters['severity'] === 'all' ? null : $filters['severity'],
            'source' => $filters['source'] === 'all' ? null : $filters['source'],
            'queue_id' => $filters['queue_id'],
            'assigned_to' => $assignedTo,
            'escalation_level' => $filters['escalation_level'],
            'date_from' => $filters['date_from'],
            'date_to' => $filters['date_to'],
            'q' => $filters['q'],
            'reporting' => $filters['reporting'],
            'handover_state' => $filters['handover_state'],
        ], fn ($value) => $value !== null && $value !== ''));

        if ($status !== '' && $status !== 'all') {
            $query->where('control_room_alerts.status', $status);
        }
        if ($filters['assigned_to'] === 'unassigned') {
            $query->whereNull('control_room_alerts.assigned_to_user_id');
        }

        return $query;
    }

    private function worklist(User $user, array $filters): array
    {
        $query = $this->matchingQuery($user, $filters);

        /** @var LengthAwarePaginator $paginator */
        $paginator = $query->paginate(25)->withQueryString();
        $governance = $this->worklistPresenter->governanceForAlerts($paginator->getCollection(), $user);
        $rows = $paginator->getCollection()
            ->map(function (ControlRoomAlert $alert) use ($user, $governance): array {
                $row = $this->worklistPresenter->present($alert, $user, governance: $governance->get((int) $alert->id));
                $row['alert_type'] = $alert->alert_type;
                $row['sla_status'] = match ($row['sla']['status']) {
                    'resolved' => 'on_track',
                    'not_applicable' => null,
                    default => $row['sla']['status'],
                };
                $row['assigned_to'] = $row['assignee'];
                $row['client_name'] = $row['person']['name'] ?? null;

                return $row;
            })
            ->values();

        return [
            'data' => $rows,
            'links' => $paginator->linkCollection()->toArray(),
            'meta' => [
                'current_page' => $paginator->currentPage(),
                'last_page' => $paginator->lastPage(),
                'per_page' => $paginator->perPage(),
                'total' => $paginator->total(),
            ],
        ];
    }

    private function aggregate(User $user, array $filters): object
    {
        $query = $this->matchingQuery($user, $filters, 'all_records')->setEagerLoads([])->reorder()->select([]);

        $active = "'".implode("','", self::ACTIVE_STATUSES)."'";
        $unsnoozed = '(control_room_alerts.snoozed_until IS NULL OR control_room_alerts.snoozed_until <= ?)';
        $now = now();
        $responseAverage = DB::connection()->getDriverName() === 'sqlite'
            ? "AVG(CASE WHEN desk_sla.responded_at >= ? AND desk_sla.responded_at >= control_room_alerts.triggered_at THEN (strftime('%s', desk_sla.responded_at) - strftime('%s', control_room_alerts.triggered_at)) / 60.0 END)"
            : 'AVG(CASE WHEN desk_sla.responded_at >= ? AND desk_sla.responded_at >= control_room_alerts.triggered_at THEN TIMESTAMPDIFF(SECOND, control_room_alerts.triggered_at, desk_sla.responded_at) / 60.0 END)';

        $aggregate = $query
            ->leftJoin('control_room_alert_sla as desk_sla', 'desk_sla.alert_id', '=', 'control_room_alerts.id')
            ->selectRaw('COUNT(control_room_alerts.id) as total')
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status = 'open' THEN 1 ELSE 0 END) as open_count")
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status = 'ack' THEN 1 ELSE 0 END) as acknowledged_count")
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status = 'triaging' THEN 1 ELSE 0 END) as triaging_count")
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status = 'resolved' THEN 1 ELSE 0 END) as resolved_count")
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status = 'closed' THEN 1 ELSE 0 END) as closed_count")
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} THEN 1 ELSE 0 END) as active_count", [$now])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} AND control_room_alerts.severity = 'critical' THEN 1 ELSE 0 END) as critical_count", [$now])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} AND control_room_alerts.severity = 'high' THEN 1 ELSE 0 END) as high_count", [$now])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} AND control_room_alerts.escalation_level > 0 THEN 1 ELSE 0 END) as escalated_count", [$now])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} AND control_room_alerts.assigned_to_user_id IS NULL THEN 1 ELSE 0 END) as unassigned_count", [$now])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} AND control_room_alerts.assigned_to_user_id = ? THEN 1 ELSE 0 END) as my_alerts_count", [$now, $user->id])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} AND (control_room_alerts.due_at < ? OR (desk_sla.sla_definition_id IS NOT NULL AND (desk_sla.ended_as IS NULL OR desk_sla.ended_as NOT IN ('dismissed', 'reconciled_no_match')) AND ((desk_sla.acknowledged_at IS NULL AND desk_sla.acknowledge_deadline < ?) OR (desk_sla.responded_at IS NULL AND desk_sla.response_deadline < ?) OR (desk_sla.resolved_at IS NULL AND desk_sla.resolution_deadline < ?)))) THEN 1 ELSE 0 END) as sla_breached_count", [$now, $now, $now, $now, $now])
            ->selectRaw("MIN(CASE WHEN control_room_alerts.status IN ({$active}) AND {$unsnoozed} THEN control_room_alerts.triggered_at END) as oldest_open_at", [$now])
            ->selectRaw('SUM(CASE WHEN control_room_alerts.triggered_at >= ? THEN 1 ELSE 0 END) as alerts_24h', [now()->subDay()])
            ->selectRaw("SUM(CASE WHEN control_room_alerts.resolved_at >= ? AND control_room_alerts.resolved_at <= ? AND control_room_alerts.status IN ('resolved', 'closed') THEN 1 ELSE 0 END) as resolved_24h", [now()->subDay(), $now])
            ->selectRaw("{$responseAverage} as avg_response_minutes", [now()->subDay()])
            ->first();

        foreach ($this->workflowSummary($user, $filters) as $key => $count) {
            $aggregate->{$key} = $count;
        }

        return $aggregate;
    }

    private function workflowSummary(User $user, array $filters): array
    {
        $counts = ['needs_incident' => 0, 'decision_needed' => 0, 'awaiting_health_safety' => 0,
            'accepted_in_progress' => 0, 'operational_complete_governance_open' => 0, 'workflow_unavailable' => 0];
        $counts['workflow_unavailable'] = $this->matchingQuery($user,
            [...$filters, 'reporting' => '', 'handover_state' => 'unavailable'], 'all_records')->count();
        $base = $this->matchingQuery($user, $filters, 'all_records')->setEagerLoads([])->reorder();
        $counts['decision_needed'] = (clone $base)->actionable()->notSnoozed()->count();
        $this->worklistQuery->withWorkflowEvidence(clone $base)
            ->chunkById(500, function ($alerts) use ($user, &$counts): void {
                $records = $this->governance->forAlerts($alerts, $user);
                $reviews = $this->reporting->reviewForAlerts($alerts, $user, $records);
                foreach ($alerts as $alert) {
                    $record = $records->get((int) $alert->id);
                    $review = $reviews->get((int) $alert->id);
                    if (! $review['classification_available']) {
                        if ($alert->isActionable() && ! $alert->isSnoozed()) {
                            $counts['decision_needed']--;
                        }

                        continue;
                    }
                    if ($alert->isActionable() && ! $alert->isSnoozed()) {
                        $counts['needs_incident'] += (int) $review['required_outstanding'];
                        $counts['decision_needed'] -= (int) ($review['reporting']['state'] !== 'decision_needed');
                    }
                    $event = $record['hs_event'];
                    if ($event === null) {
                        continue;
                    }
                    $counts['awaiting_health_safety'] += (int) ($event->handover_status === 'awaiting_acceptance');
                    $counts['accepted_in_progress'] += (int) ($event->handover_status === 'accepted' && $event->status !== 'closed');
                    $counts['operational_complete_governance_open'] += (int) ($alert->isTerminal() && $event->status !== 'closed');
                }
            }, 'control_room_alerts.id', 'id');

        return $counts;
    }

    /** @return array<string, mixed> */
    private function hero(object $aggregate): array
    {
        return [
            'active' => (int) $aggregate->active_count,
            'critical' => (int) $aggregate->critical_count,
            'sla_breached' => (int) $aggregate->sla_breached_count,
            'unassigned' => (int) $aggregate->unassigned_count,
            'oldest_open_at' => $aggregate->oldest_open_at ? Carbon::parse($aggregate->oldest_open_at)->toIso8601String() : null,
            'last_24_hours' => [
                'alerts' => (int) $aggregate->alerts_24h,
                'resolved' => (int) $aggregate->resolved_24h,
                'avg_response_minutes' => $aggregate->avg_response_minutes === null
                    ? null
                    : round((float) $aggregate->avg_response_minutes, 1),
            ],
        ];
    }

    /** @return array<int, array<string, mixed>> */
    private function queues(User $user, array $filters): array
    {
        $visibleAlertIds = $this->matchingQuery($user, $filters)->setEagerLoads([])->reorder()->select('control_room_alerts.id');

        return TriageQueue::query()
            ->active()
            ->withCount([
                'alerts as active_count' => function (Builder $query) use ($visibleAlertIds): void {
                    $query->actionable()->notSnoozed();
                    $query->whereIn('control_room_alerts.id', clone $visibleAlertIds);
                },
                'alerts as critical_count' => function (Builder $query) use ($visibleAlertIds): void {
                    $query->actionable()->notSnoozed()->where('severity', 'critical');
                    $query->whereIn('control_room_alerts.id', clone $visibleAlertIds);
                },
            ])
            ->orderBy('tier')
            ->get(['id', 'name', 'tier'])
            ->map(fn (TriageQueue $queue) => [
                'id' => $queue->id,
                'name' => $queue->name,
                'tier' => (int) $queue->tier,
                'active' => (int) $queue->active_count,
                'critical' => (int) $queue->critical_count,
            ])
            ->all();
    }

    /** @return array<int, array<string, mixed>> */
    private function activity(User $user, array $filters): array
    {
        $visibleAlertIds = $this->matchingQuery($user, $filters)->setEagerLoads([])->reorder()->select('control_room_alerts.id');

        return AuditLog::query()
            ->leftJoin('users', 'users.id', '=', 'audit_logs.user_id')
            ->where('audit_logs.action', 'like', 'controlRoom.%')
            ->where('audit_logs.action', '!=', 'controlRoom.dashboard.view')
            ->where('audit_logs.auditable_type', (new ControlRoomAlert)->getMorphClass())
            ->whereIn('audit_logs.auditable_id', $visibleAlertIds)
            ->orderByDesc('audit_logs.created_at')
            ->limit(10)
            ->get([
                'audit_logs.id',
                'audit_logs.action',
                'audit_logs.auditable_id',
                'audit_logs.meta',
                'audit_logs.created_at',
                'users.name as actor_name',
            ])
            ->map(fn ($log) => [
                'id' => $log->id,
                'type' => $log->action,
                'alert_id' => (int) $log->auditable_id,
                'occurred_at' => Carbon::parse($log->created_at)->toIso8601String(),
                'actor_name' => $log->actor_name,
                'meta' => $this->safeActivityMeta(is_array($log->meta) ? $log->meta : json_decode((string) $log->meta, true)),
            ])
            ->all();
    }

    /** Dashboard activity is an operational summary, not a raw audit export. */
    private function safeActivityMeta(?array $meta): array
    {
        $safe = [];
        foreach (['from', 'to', 'status', 'previous_status', 'new_status'] as $key) {
            if (in_array($meta[$key] ?? null, ControlRoomAlert::VALID_STATUSES, true)) {
                $safe[$key] = $meta[$key];
            }
        }
        if (is_int($meta['escalation_level'] ?? null)) {
            $safe['escalation_level'] = $meta['escalation_level'];
        }
        if (in_array($meta['state'] ?? null, ['required', 'not_required'], true)) {
            $safe['state'] = $meta['state'];
        }

        return $safe;
    }

    /** @return array<string, int> */
    private function legacyStats(object $aggregate): array
    {
        return [
            'total' => (int) $aggregate->total,
            'open' => (int) $aggregate->open_count,
            'acknowledged' => (int) $aggregate->acknowledged_count,
            'triaging' => (int) $aggregate->triaging_count,
            'resolved' => (int) $aggregate->resolved_count,
            'closed' => (int) $aggregate->closed_count,
            'critical' => (int) $aggregate->critical_count,
            'high' => (int) $aggregate->high_count,
            'escalated' => (int) $aggregate->escalated_count,
            'unassigned' => (int) $aggregate->unassigned_count,
            'my_alerts' => (int) $aggregate->my_alerts_count,
        ];
    }

    private function scopeAlerts(Builder $query, User $user, ?int $siteId): void
    {
        $this->alertAccess->applyVisibleScope($query, $user);
        if ($siteId !== null) {
            $this->siteAccess->applyAlertSiteScopeForSiteIds($query, [$siteId]);
        }
    }

    /** @return array{0: Carbon, 1: Carbon} */
    private function period(string $period): array
    {
        $to = now();
        $from = match ($period) {
            '24h' => $to->copy()->subDay(),
            '30d' => $to->copy()->subDays(30),
            '90d' => $to->copy()->subDays(90),
            default => $to->copy()->subDays(7),
        };

        return [$from, $to];
    }

    private function reportSiteScope(User $user, ?int $siteId): int|array|null
    {
        if ($siteId !== null) {
            return $siteId;
        }
        if ($this->siteAccess->canBypass($user, self::BYPASS_PERMISSIONS)) {
            return null;
        }

        return $this->siteAccess->accessibleSiteIds($user, self::BYPASS_PERMISSIONS);
    }

    /** @param list<string> $allowed */
    private function allowed(string $value, array $allowed): string
    {
        return in_array($value, $allowed, true) ? $value : '';
    }

    private function dateFilter(mixed $value): string
    {
        $value = trim((string) $value);

        return preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) === 1 ? $value : '';
    }
}
