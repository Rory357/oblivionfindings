param([switch]$Prepare, [string]$ExpectedReadinessSha256)
$ErrorActionPreference = 'Stop'
$candidatePath = 'C:\Users\steph\.codex\worktrees\control-room-delivery\oblivionfindings'
$dependencyPath = 'C:\Users\steph\.codex\worktrees\workforce-improvements\oblivionfindings\node_modules'
$nodePath = 'C:\Program Files\nodejs\node.exe'
$readyPath = Join-Path $candidatePath 'docs/control-room-audit-2026-10-11/frontend-readiness.json'
Set-Location -LiteralPath $candidatePath
. (Join-Path $candidatePath 'docs/control-room-audit-2026-10-11/control-room-resource-proof.ps1')
$owned = @(
    'resources/js/components/app-sidebar.tsx',
    'resources/js/components/command-centre/command-centre-page.tsx',
    'resources/js/components/command-centre/command-centre-page.test.tsx',
    'resources/js/lib/control-room-navigation.ts', 'resources/js/lib/control-room-navigation.test.ts',
    'resources/js/pages/control-room/_settings-types.ts', 'resources/js/pages/control-room/_settings-wizard.tsx',
    'resources/js/pages/control-room/_settings-dialogs.tsx', 'resources/js/pages/control-room/_settings-dialogs.test.tsx',
    'resources/js/pages/control-room/_settings-time.ts', 'resources/js/pages/control-room/_settings-time.test.ts',
    'resources/js/pages/control-room/broadcast-show.tsx', 'resources/js/pages/control-room/broadcast.tsx',
    'resources/js/pages/control-room/devices/index.tsx', 'resources/js/pages/control-room/devices/show.tsx',
    'resources/js/pages/control-room/map.tsx', 'resources/js/pages/control-room/messaging.tsx',
    'resources/js/pages/control-room/playbooks/index.tsx', 'resources/js/pages/control-room/playbooks/show.tsx',
    'resources/js/pages/control-room/reports.tsx', 'resources/js/pages/control-room/settings.tsx',
    'resources/js/pages/control-room/shifts.tsx', 'resources/js/pages/control-room/sla/breaches.tsx',
    'resources/js/pages/control-room/sla/index.tsx', 'resources/js/pages/control-room/stats.tsx'
)
$tests = @(
    'resources/js/components/command-centre/command-centre-page.test.tsx',
    'resources/js/lib/control-room-navigation.test.ts',
    'resources/js/pages/control-room/_settings-dialogs.test.tsx',
    'resources/js/pages/control-room/_settings-time.test.ts'
)
function Assert-DependencyLink {
    $link = Get-Item -LiteralPath (Join-Path $candidatePath 'node_modules')
    $targets=@($link.Target)
    if ($link.LinkType -ne 'Junction' -or $targets.Count -ne 1 -or $targets[0] -ne $dependencyPath) { throw 'Unexpected candidate dependency link.' }
    if ((Get-Item -LiteralPath $dependencyPath).LinkType) { throw 'Dependency root must be the physical approved installation.' }
}
function Read-Inputs {
    Assert-DependencyLink
    $paths = @('package.json','package-lock.json','.prettierrc','eslint.config.js','tsconfig.json','vitest.config.ts',
        'build/node-modules-fs-allow.ts','docs/control-room-audit-2026-10-11/run-front-end-checks.ps1',
        'docs/control-room-audit-2026-10-11/control-room-resource-proof.ps1') +
        @(Get-ChildItem -LiteralPath 'resources' -Recurse -File | ForEach-Object { [IO.Path]::GetRelativePath($candidatePath,$_.FullName).Replace('\','/') } | Sort-Object) +
        @($nodePath) + @('.package-lock.json','prettier/bin/prettier.cjs','prettier/package.json','eslint/bin/eslint.js','eslint/package.json',
            'vitest/vitest.mjs','vitest/package.json','typescript/lib/typescript.js','typescript/package.json','vite/package.json',
            '@inertiajs/react/package.json','@inertiajs/react/dist/index.js','@inertiajs/react/dist/index.esm.js',
            '@inertiajs/core/package.json','@inertiajs/core/dist/index.js','@inertiajs/core/dist/index.esm.js','react/package.json','jsdom/package.json') | ForEach-Object {
                if ($_ -eq $nodePath -or $_ -like 'resources/*' -or $_ -like 'build/*' -or $_ -like 'docs/*' -or $_ -in @('package.json','package-lock.json','.prettierrc','eslint.config.js','tsconfig.json','vitest.config.ts')) { $_ }
                else { Join-Path $dependencyPath $_ }
            }
    Assert-ControlRoomClassifier
    $paths += @(Get-ControlRoomResourceInputPaths)
    @($paths | Sort-Object -Unique | ForEach-Object { [pscustomobject]@{ path=$_;sha256=(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash } })
}
function Read-BoundInputs($expected, [string]$phase) {
    if ((Get-FileHash -LiteralPath $readyPath -Algorithm SHA256).Hash -ne $ExpectedReadinessSha256) {
        throw "Reviewed readiness changed before $phase; no child."
    }
    $fresh = Read-Inputs
    if (@(Compare-Inputs $expected $fresh).Count -gt 0) { throw "Frozen inputs changed before $phase; no child." }
    $fresh
}
function Compare-Inputs($before,$after) {
    $old = @{}; foreach ($pin in $before) { $old[$pin.path]=$pin.sha256 }
    $new = @{}; foreach ($pin in $after) { $new[$pin.path]=$pin.sha256 }
    @(@($after | Where-Object { -not $old.ContainsKey($_.path) -or $old[$_.path] -ne $_.sha256 }) +
        @($before | Where-Object { -not $new.ContainsKey($_.path) }))
}
if ($Prepare) {
    $inputs = Read-Inputs
    $inventory = @($tests | ForEach-Object { [pscustomobject]@{path=$_;authoredCases=[regex]::Matches((Get-Content -LiteralPath $_ -Raw),'\b(?:it|test)\(').Count} })
    [pscustomobject]@{preparedAt=(Get-Date).ToUniversalTime().ToString('o');candidate=$candidatePath;dependencyRoot=$dependencyPath;
        sourceOnly=$true;runtimeStarted=$false;ownedFormatAndLintPaths=$owned;completeTestFiles=$inventory;expectedCaseTotal=20;
        memory=[pscustomobject]@{formatterMiB=512;linterMiB=512;vitestMainMiB=512;singleForkMiB=512;heapSumMiB=1024};inputs=$inputs} |
        ConvertTo-Json -Depth 6 | Set-Content -LiteralPath $readyPath
    Write-Output "Prepared source-only frontend package: $($owned.Count) owned paths, 4 whole test files / 20 authored cases, $($inputs.Count) inputs. No runtime launched."
    exit 0
}
if ($ExpectedReadinessSha256 -notmatch '^[A-Fa-f0-9]{64}$') { throw 'Exact coordinator-reviewed readiness hash required; no child.' }
$readinessHash=(Get-FileHash -LiteralPath $readyPath -Algorithm SHA256).Hash
if ($readinessHash -ne $ExpectedReadinessSha256) { throw 'Reviewed readiness hash mismatch; no child.' }
$ready = Get-Content -LiteralPath $readyPath -Raw | ConvertFrom-Json
$gate = [Threading.Mutex]::new($false,'Local\OblivionWorkforceMainIntegrationNativeGate')
$gateHeld = $false
$priorNodeOptions = $env:NODE_OPTIONS
$evidencePath = Join-Path $candidatePath ('test-results/control-room-frontend-' + (Get-Date).ToUniversalTime().ToString('yyyyMMdd-HHmmss'))
$samples = @(); $phases = @(); $initial = @(); $testBefore = @(); $formattedChanges = @(); $resultExit = 75
$launchBinding = $null
$afterReadComplete=$false; $verificationFailure=$null
try {
    try { $gateHeld=$gate.WaitOne(0) } catch [Threading.AbandonedMutexException] { $gateHeld=$true }
    if (-not $gateHeld) { Write-Output 'HELD: shared verification gate busy; no child launched.'; exit 75 }
    New-Item -ItemType Directory -Path $evidencePath | Out-Null
    for ($sample=0;$sample -lt 2;$sample++) {
        $proof = Get-ControlRoomResourceProof
        $samples += $proof
        Assert-ControlRoomResourceProof $proof
        if ($sample -eq 0) { Start-Sleep -Seconds 2 }
    }
    $initial = @(Read-BoundInputs $ready.inputs 'format-owned')
    $initial | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $evidencePath 'source-before-format.json')
    $launchBinding = [pscustomobject]@{time=[DateTime]::UtcNow.ToString('o');gateHeld=$gateHeld;
        readinessSha256=$readinessHash;inputCount=$initial.Count;comparedToReviewedReadiness=$true}
    $launchBinding | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $evidencePath 'launch-binding.json')
    $env:NODE_OPTIONS='--max-old-space-size=512'
    & $nodePath --max-old-space-size=512 (Join-Path $dependencyPath 'prettier/bin/prettier.cjs') --write @owned *> (Join-Path $evidencePath 'format.log')
    $phases += [pscustomobject]@{name='format-owned';exitCode=$LASTEXITCODE}; if ($LASTEXITCODE -ne 0) { $resultExit=$LASTEXITCODE; throw 'Owned formatting failed.' }
    $testBefore=Read-Inputs
    $formattedChanges=@(Compare-Inputs $initial $testBefore)
    if (@($formattedChanges | Where-Object path -notin $owned).Count -gt 0) { throw 'Formatting changed an input outside the exact owned files.' }
    $testBefore | ConvertTo-Json -Depth 3 | Set-Content -LiteralPath (Join-Path $evidencePath 'source-before-tests.json')
    $null = @(Read-BoundInputs $testBefore 'format-check')
    & $nodePath --max-old-space-size=512 (Join-Path $dependencyPath 'prettier/bin/prettier.cjs') --check @owned *> (Join-Path $evidencePath 'format-check.log')
    $phases += [pscustomobject]@{name='format-check';exitCode=$LASTEXITCODE}; if ($LASTEXITCODE -ne 0) { $resultExit=$LASTEXITCODE; throw 'Format verification failed.' }
    $null = @(Read-BoundInputs $testBefore 'lint-owned')
    & $nodePath --max-old-space-size=512 (Join-Path $dependencyPath 'eslint/bin/eslint.js') @owned --max-warnings=0 *> (Join-Path $evidencePath 'lint.log')
    $phases += [pscustomobject]@{name='lint-owned';exitCode=$LASTEXITCODE}; if ($LASTEXITCODE -ne 0) { $resultExit=$LASTEXITCODE; throw 'Owned lint failed.' }
    for ($sample=0;$sample -lt 2;$sample++) {
        $proof = Get-ControlRoomResourceProof
        $proof | Add-Member -NotePropertyName phase -NotePropertyValue 'before-tests'
        $samples += $proof
        Assert-ControlRoomResourceProof $proof
        if ($sample -eq 0) { Start-Sleep -Seconds 2 }
    }
    $null = @(Read-BoundInputs $testBefore 'four-complete-suites')
    & $nodePath --max-old-space-size=512 (Join-Path $dependencyPath 'vitest/vitest.mjs') run @tests --pool=forks --maxWorkers=1 --no-file-parallelism --reporter=default --reporter=json --outputFile (Join-Path $evidencePath 'vitest.json') *> (Join-Path $evidencePath 'vitest.log')
    $resultExit=$LASTEXITCODE; $phases += [pscustomobject]@{name='four-complete-suites';exitCode=$resultExit}
} finally {
    try {
        if (Test-Path -LiteralPath $evidencePath) {
            $after=@(); $drift=@()
            try {
                $after=Read-Inputs
                $drift=@(Compare-Inputs $(if ($testBefore.Count) { $testBefore } elseif ($initial.Count) { $initial } else { $ready.inputs }) $after)
                $afterReadComplete=$true
                if ($drift.Count -gt 0) { $resultExit=76 }
            } catch {
                $verificationFailure=$_.Exception.Message
                $resultExit=76
            }
            [pscustomobject]@{terminal=(Get-Date).ToUniversalTime().ToString('o');exitCode=$resultExit;admission=$samples;phases=$phases;
                readinessSha256=$readinessHash;launchBinding=$launchBinding;beforeFormat=$initial;formattedChanges=$formattedChanges;after=$after;drift=$drift;
                afterReadComplete=$afterReadComplete;verificationFailure=$verificationFailure;completeTestFiles=$ready.completeTestFiles;expectedCaseTotal=20;applicationOrDatabaseStarted=$false;buildOrBrowserStarted=$false} |
                ConvertTo-Json -Depth 7 | Set-Content -LiteralPath (Join-Path $evidencePath 'result.json')
            Write-Output "Frontend evidence: $evidencePath; phase count $($phases.Count); test exit $resultExit; drift $($drift.Count)."
        }
    } finally {
        $env:NODE_OPTIONS=$priorNodeOptions
        try { if ($gateHeld) { $gate.ReleaseMutex() } } finally { $gate.Dispose() }
    }
}
if ($drift.Count -gt 0) { exit 76 }
exit $resultExit
