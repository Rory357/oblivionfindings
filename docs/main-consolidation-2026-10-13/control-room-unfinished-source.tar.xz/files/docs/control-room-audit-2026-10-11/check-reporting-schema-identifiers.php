<?php

require __DIR__.'/../../vendor/autoload.php';

use Illuminate\Database\MySqlConnection;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

// Compile the real migration with Laravel's MySQL grammar. Never open a connection.
$connection = new MySqlConnection(static fn () => throw new LogicException('This identifier check must not connect.'),
    'offline_compile_only', '', ['driver' => 'mysql', 'version' => '8.0.36', 'charset' => 'utf8mb4', 'collation' => 'utf8mb4_unicode_ci']);
$connection->useDefaultSchemaGrammar();
$capture = new class($connection)
{
    public array $sql = [];

    public function __construct(private readonly MySqlConnection $connection) {}

    public function create(string $name, Closure $callback): void
    {
        $blueprint = new Blueprint($this->connection, $name);
        $blueprint->create();
        $callback($blueprint);
        $this->sql = $blueprint->toSql();
    }
};
Schema::swap($capture);
$migration = require __DIR__.'/../../database/migrations/2026_10_11_150000_create_control_room_alert_reporting_decisions.php';
$migration->up();
preg_match_all('/`([^`]+)`/', implode("\n", $capture->sql), $matches);
$identifiers = array_values(array_unique($matches[1]));
$overlong = array_values(array_filter($identifiers, static fn (string $name): bool => strlen($name) > 64));
$ddl = implode("\n", $capture->sql);
file_put_contents(__DIR__.'/reporting-schema-compiled.sql', $ddl);
foreach (['cr_reporting_alert_fk', 'cr_reporting_actor_fk', 'cr_reporting_revision_uq', 'cr_reporting_command_uq'] as $required) {
    if (! in_array($required, $identifiers, true)) throw new LogicException('An explicitly named constraint was not compiled.');
}
if (! preg_match('/unique[^\n]*`cr_reporting_revision_uq`\s*\(`alert_id`, `revision`\)/', $ddl)
    || ! preg_match('/unique[^\n]*`cr_reporting_command_uq`\s*\(`alert_id`, `command_id`\)/', $ddl)
    || ! str_contains($ddl, 'on delete restrict') || ! str_contains($ddl, 'on delete set null')) {
    throw new LogicException('The migration lost its uniqueness or ownership deletion semantics.');
}
$receipt = ['connectionOpened' => false, 'statementsCompiled' => count($capture->sql),
    'maximumIdentifierLength' => max(array_map('strlen', $identifiers)), 'overlong' => $overlong, 'identifiers' => $identifiers];
file_put_contents(__DIR__.'/reporting-schema-identifiers.json', json_encode($receipt, JSON_PRETTY_PRINT | JSON_THROW_ON_ERROR));
echo json_encode($receipt, JSON_THROW_ON_ERROR).PHP_EOL;
exit($overlong === [] ? 0 : 1);
