<?php

namespace App\Models;

use App\Models\Concerns\AuditableChanges;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class SafeWorkProcedure extends Model
{
    use AuditableChanges, HasFactory, SoftDeletes;

    protected $fillable = [
        'title',
        'reference_number',
        'category',
        'purpose',
        'scope',
        'hazards_addressed',
        'ppe_required',
        'steps',
        'emergency_procedures',
        'status',
        'previous_status',
        'current_version',
        'approved_by',
        'approved_at',
        'owner_id',
        'review_date',
        'review_frequency_months',
        'applicable_roles',
        'applicable_sites',
        'related_training',
        'created_by',
        'updated_by', 'published_version_id', 'published_review_date', 'lock_version',
    ];

    protected $casts = [
        'hazards_addressed' => 'array',
        'ppe_required' => 'array',
        'steps' => 'array',
        'emergency_procedures' => 'array',
        'applicable_roles' => 'array',
        'applicable_sites' => 'array',
        'related_training' => 'array',
        'approved_at' => 'datetime',
        'review_date' => 'date',
        'current_version' => 'integer', 'published_version_id' => 'integer', 'published_review_date' => 'date', 'lock_version' => 'integer',
        'review_frequency_months' => 'integer',
    ];

    /* ------------------------------------------------------------------ */
    /*  Relationships */
    /* ------------------------------------------------------------------ */

    public function approvedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'approved_by');
    }

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function versions(): HasMany
    {
        return $this->hasMany(SafeWorkProcedureVersion::class)->orderByDesc('version_number');
    }

    /**
     * Controlled-document library — reuses the shared polymorphic HsAttachment store
     * (private disk) rather than a bespoke table. Each file is version-stamped via
     * version_at_upload so the detail modal can flag superseded master documents.
     */
    public function attachments(): MorphMany
    {
        return $this->morphMany(HsAttachment::class, 'attachable')->latest();
    }

    /** Worker acknowledgements ("I have read & understood"), one per (procedure, user). */
    public function acknowledgements(): HasMany
    {
        return $this->hasMany(ProcedureAcknowledgement::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by');
    }

    /* ------------------------------------------------------------------ */
    /*  Cross-module resolution scopes */
    /* */
    /*  Reusable so Site profiles, HR staff / self-service and the client */
    /*  risk tab can surface the procedures that apply to them without */
    /*  re-implementing the JSON membership logic. An empty/absent */
    /*  applicable_* array means "applies organisation-wide / to all". */
    /* ------------------------------------------------------------------ */

    public function publishedVersion(): BelongsTo
    {
        return $this->belongsTo(SafeWorkProcedureVersion::class, 'published_version_id');
    }

    public function acknowledgementReceipts(): HasMany
    {
        return $this->hasMany(ProcedureAcknowledgementReceipt::class);
    }

    public function reviewRequests(): HasMany
    {
        return $this->hasMany(ProcedureReviewRequest::class);
    }

    public function publishedSnapshot(): array
    {
        return $this->publishedVersion?->content_snapshot ?? [];
    }

    public function publishedValue(string $field): mixed
    {
        return $this->publishedSnapshot()[$field] ?? null;
    }

    public function scopePublished(Builder $query): Builder
    {
        return $query->where('status', '!=', 'archived')->whereNotNull('published_version_id')->whereHas('publishedVersion', fn (Builder $version) => $version->whereColumn('safe_work_procedure_versions.safe_work_procedure_id', 'safe_work_procedures.id')->where(fn (Builder $approval) => $approval->where('provenance', 'legacy_current_capture')->orWhere(fn (Builder $controlled) => $controlled->where('provenance', 'controlled')->whereNotNull('approved_by')->whereNotNull('approved_at'))));
    }

    public function scopeApplicableToSite(Builder $query, int $siteId): Builder
    {
        return $query->published()->whereHas('publishedVersion', fn (Builder $version) => $version->where(function (Builder $scope) use ($siteId) {
            $scope->whereJsonContains('content_snapshot->applicable_sites', $siteId)->orWhereJsonLength('content_snapshot->applicable_sites', 0)->orWhereNull('content_snapshot->applicable_sites');
        }));
    }

    public function scopeApplicableToRoles(Builder $query, array $roleKeys): Builder
    {
        return $query->published()->whereHas('publishedVersion', fn (Builder $version) => $version->where(function (Builder $scope) use ($roleKeys) {
            $scope->whereJsonLength('content_snapshot->applicable_roles', 0)->orWhereNull('content_snapshot->applicable_roles');
            foreach ($roleKeys as $key) {
                $scope->orWhereJsonContains('content_snapshot->applicable_roles', $key);
            }
        }));
    }

    /**
     * SiteHazard.hazard_type → procedure category map. Only the CLEAN vocabulary
     * overlaps are mapped (the two taxonomies otherwise diverge — see the redesign
     * audit); unmapped hazard types intentionally surface no related procedure.
     */
    public const HAZARD_TYPE_CATEGORIES = [
        'manual_handling' => 'manual_handling',
        'fire' => 'fire_safety',
        'biological' => 'infection_control',
        'equipment' => 'equipment_use',
    ];

    /** Approved procedures that mitigate a given site-hazard type (clean overlaps only). */
    public function scopeMitigatingHazardType(Builder $query, ?string $hazardType): Builder
    {
        $category = self::HAZARD_TYPE_CATEGORIES[$hazardType] ?? null;

        // No clean taxonomy mapping → no related procedure (honest, not a guess).
        if ($category === null) {
            return $query->whereRaw('1 = 0');
        }

        return $query->published()->whereHas('publishedVersion', fn (Builder $version) => $version->where('content_snapshot->category', $category));
    }
}
