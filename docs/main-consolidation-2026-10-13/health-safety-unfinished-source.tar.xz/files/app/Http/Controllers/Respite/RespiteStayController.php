<?php

namespace App\Http\Controllers\Respite;

use App\Domain\Governance\Models\NotifiableIncident;
use App\Events\Respite\RespiteEvent;
use App\Http\Controllers\Controller;
use App\Models\ClientIncident;
use App\Models\ClientMedication;
use App\Models\DataBreachLog;
use App\Models\MedicationAllergy;
use App\Models\RespiteBooking;
use App\Models\RespiteComplaint;
use App\Models\RespiteMedicationReconciliation;
use App\Models\RespiteStay;
use App\Models\ServiceAgreement;
use App\Services\HealthSafety\RestraintService;
use App\Services\Incidents\IncidentJourneyService;
use App\Services\References\ReferenceNumberGenerator;
use App\Services\Respite\RespiteRestraintReadService;
use App\Services\Respite\RespiteShiftSync;
use App\Services\Respite\RespiteStateTransitionService;
use App\Services\Respite\RespiteStayScope;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class RespiteStayController extends Controller
{
    public function __construct(
        private readonly RespiteStayScope $stayScope,
        private readonly RespiteStateTransitionService $states,
    ) {}

    public function index(Request $request): Response
    {
        $stays = RespiteStay::query()
            ->with(['client', 'booking'])
            ->tap(fn ($query) => $this->stayScope->applyAccessibleStayScope($query, $request))
            ->latest()
            ->paginate(25);

        return Inertia::render('respite/stays/index', [
            'stays' => $stays,
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'booking_id' => 'required|integer|min:1',
            'client_id' => 'required|integer|min:1',
        ]);

        $stay = $this->states->transitionBooking(
            $request,
            (int) $validated['booking_id'],
            function (RespiteBooking $booking) use ($validated): RespiteStay {
                $this->states->assertStayAdmission(
                    $booking->status,
                    RespiteStay::withTrashed()
                        ->where('booking_id', $booking->id)
                        ->lockForUpdate()
                        ->first(['id']) !== null,
                );

                if ((int) $booking->client_id !== (int) $validated['client_id']) {
                    throw ValidationException::withMessages([
                        'client_id' => 'The stay client must match the respite booking client.',
                    ]);
                }

                return RespiteStay::create([
                    ...$validated,
                    'status' => 'admitted',
                    'created_by' => auth()->id(),
                    'actual_start' => now(),
                ]);
            },
        );

        event(new RespiteEvent('respite.stay.created', [
            'id' => $stay->id,
            'client_id' => $stay->client_id,
            'status' => $stay->status,
        ]));

        return redirect()
            ->route('respite.stays.show', $stay)
            ->with('success', 'Respite stay created.');
    }

    public function show(RespiteStay $stay): Response
    {
        $stay = $this->stayScope->resolveAuthorizedStay(request(), (int) $stay->id);
        $stay->load([
            'client',
            'booking.coordinator',
            'evidencePack',
            'handovers',
            'communications',
            'dailyNotes',
            'riskPlanActivations',
            'createdByUser',
        ]);
        $this->stayScope->assertStayRecords($stay);
        if ($stay->evidencePack) {
            $this->stayScope->assertEvidenceGraph($stay, $stay->evidencePack, null);
        }

        return Inertia::render('respite/stays/show', [
            'stay' => $stay,
            'restraints' => app(RespiteRestraintReadService::class)->forStay(request()->user(), $stay),
        ]);
    }

    public function checkIn(RespiteStay $stay): RedirectResponse
    {
        $request = request();
        $this->states->assertStayAccessible($request, (int) $stay->id);
        $validated = $request->validate([
            'med_rec_override_reason' => 'nullable|string|max:500',
            'anaphylaxis_acknowledged' => 'nullable|boolean',
            'epipen_location' => 'nullable|string|max:500',
            'anaphylaxis_escalation_note' => 'nullable|string|max:1000',
        ]);

        $stay = $this->states->transitionStay(
            $request,
            (int) $stay->id,
            function (RespiteStay $stay) use ($validated): RespiteStay {
                $booking = $stay->booking;
                $this->states->assertStayCheckIn($stay->status, $booking->status);

                $this->guardAnaphylaxisAcknowledgement($stay, $validated);
                $this->guardAdmissionMedicationReconciliation($stay, $validated['med_rec_override_reason'] ?? null);

                $stay->update([
                    'status' => 'active',
                    'actual_start' => $stay->actual_start ?? now(),
                    'updated_by' => auth()->id(),
                ]);
                $booking->update([
                    'status' => 'in_progress',
                    'updated_by' => auth()->id(),
                ]);
                app(RespiteShiftSync::class)->checkInStay($stay, $stay->actual_start, auth()->id());

                return $stay;
            },
        );

        event(new RespiteEvent('respite.stay.checked_in', [
            'id' => $stay->id,
            'client_id' => $stay->client_id,
            'status' => $stay->status,
        ]));

        return back()->with('success', 'Stay checked in.');
    }

    public function extend(Request $request, RespiteStay $stay): RedirectResponse
    {
        $this->states->assertStayAccessible($request, (int) $stay->id);

        $validated = $request->validate([
            'new_end' => 'required|date',
        ]);

        $stay = $this->states->transitionStay(
            $request,
            (int) $stay->id,
            function (RespiteStay $stay) use ($validated): RespiteStay {
                $booking = $stay->booking;
                $this->states->assertStayExtension($stay->status, $booking->status);

                $newEnd = Carbon::parse($validated['new_end']);
                $currentEnd = collect([$stay->actual_end, $booking->end_at])
                    ->filter()
                    ->map(fn ($end) => Carbon::parse($end))
                    ->sortByDesc(fn (Carbon $end) => $end->getTimestamp())
                    ->first();

                if (! $currentEnd || $newEnd->lte($currentEnd)) {
                    throw ValidationException::withMessages([
                        'new_end' => 'The new end must be after the current respite stay end.',
                    ]);
                }

                $stay->update([
                    'status' => 'extended',
                    'actual_end' => $newEnd,
                    'updated_by' => auth()->id(),
                ]);
                if ($booking->status === 'confirmed') {
                    $booking->update([
                        'status' => 'in_progress',
                        'updated_by' => auth()->id(),
                    ]);
                }
                app(RespiteShiftSync::class)->extendStay($stay, $newEnd);

                return $stay;
            },
        );

        event(new RespiteEvent('respite.stay.extended', [
            'id' => $stay->id,
            'client_id' => $stay->client_id,
            'status' => $stay->status,
        ]));

        return back()->with('success', 'Stay extended.');
    }

    public function recordBedHold(Request $request, RespiteStay $stay): RedirectResponse
    {
        $this->states->assertStayAccessible($request, (int) $stay->id);

        $validated = $request->validate([
            'bed_hold_status' => 'required|in:held,released,cancelled',
            'bed_hold_reason' => 'nullable|in:cultural_leave,whanau_visit,hospital_transfer,home_visit,other',
            'bed_hold_until' => 'nullable|date',
            'absence_record' => 'nullable|array',
        ]);

        $stay = $this->states->transitionStay(
            $request,
            (int) $stay->id,
            function (RespiteStay $stay) use ($validated): RespiteStay {
                $this->states->assertStayOperational(
                    $stay->status,
                    $stay->booking->status,
                    'record a bed hold',
                );

                $absenceRecords = $stay->absence_records ?? [];
                if (! empty($validated['absence_record'])) {
                    $absenceRecords[] = [
                        ...$validated['absence_record'],
                        'bed_hold_status' => $validated['bed_hold_status'],
                        'bed_hold_reason' => $validated['bed_hold_reason'] ?? null,
                        'recorded_by' => auth()->id(),
                        'recorded_at' => now()->toIso8601String(),
                    ];
                }

                $stay->update([
                    'bed_hold_status' => $validated['bed_hold_status'],
                    'bed_hold_reason' => $validated['bed_hold_reason'] ?? null,
                    'bed_hold_until' => $validated['bed_hold_until'] ?? null,
                    'absence_records' => $absenceRecords,
                    'updated_by' => auth()->id(),
                ]);

                return $stay;
            },
        );

        event(new RespiteEvent('respite.stay.bed_hold_recorded', [
            'id' => $stay->id,
            'client_id' => $stay->client_id,
            'status' => $validated['bed_hold_status'],
        ]));

        return back()->with('success', 'Bed hold updated.');
    }

    public function discharge(Request $request, RespiteStay $stay): RedirectResponse
    {
        $this->states->assertStayAccessible($request, (int) $stay->id);

        $validated = $request->validate([
            'discharge_summary' => 'required|string',
            'discharge_reason' => 'nullable|in:planned,early_by_family,clinical,incident,transferred_to_hospital',
            'discharge_medication_reconciliation' => 'nullable|array',
            'discharge_medication_reconciliation.medicines_returned_to' => 'nullable|string|max:255',
            'discharge_medication_reconciliation.count' => 'nullable|integer|min:0',
            'discharge_medication_reconciliation.received_by' => 'nullable|string|max:255',
            'discharge_medication_reconciliation.changed_during_stay' => 'nullable|boolean',
            'discharge_medication_reconciliation.gp_pharmacy_handover_sent' => 'nullable|boolean',
            'discharge_medication_reconciliation.whanau_briefing_acknowledged' => 'nullable|boolean',
        ]);

        $stay = $this->states->transitionStay(
            $request,
            (int) $stay->id,
            function (RespiteStay $stay) use ($validated): RespiteStay {
                $booking = $stay->booking;
                $this->states->assertStayDischarge($stay->status, $booking->status);

                $this->guardDischargeMedicationReconciliation($stay, $validated['discharge_medication_reconciliation'] ?? null);
                $this->guardDischargeCompliance($stay);

                $stay->update([
                    'status' => 'discharged',
                    'actual_end' => now(),
                    'discharge_summary' => $validated['discharge_summary'],
                    'discharge_reason' => $validated['discharge_reason'] ?? 'planned',
                    'discharge_medication_reconciliation' => $validated['discharge_medication_reconciliation'] ?? $stay->discharge_medication_reconciliation,
                    'updated_by' => auth()->id(),
                ]);
                $booking->update([
                    'status' => 'completed',
                    'updated_by' => auth()->id(),
                ]);
                app(RespiteShiftSync::class)->dischargeStay($stay, $validated['discharge_summary'], $stay->actual_end, auth()->id());
                $this->postFundingConsumption($stay);

                return $stay;
            },
        );

        event(new RespiteEvent('respite.stay.discharged', [
            'id' => $stay->id,
            'client_id' => $stay->client_id,
            'status' => $stay->status,
        ]));

        return back()->with('success', 'Stay discharged.');
    }

    public function storeMedicationReconciliation(Request $request, RespiteStay $stay): RedirectResponse
    {
        $stay->loadMissing('client', 'booking');
        $this->authorize('view', $stay->client);

        $validated = $request->validate([
            'type' => 'nullable|in:admission,discharge',
            'status' => 'required|in:not_started,in_progress,completed,overridden',
            'source' => 'nullable|string|max:255',
            'count_received' => 'nullable|integer|min:0',
            'discrepancies' => 'nullable|array',
            'first_dose_due_at' => 'nullable|date',
            'override_reason' => 'nullable|string|max:1000',
        ]);

        $type = $validated['type'] ?? 'admission';

        $reconciliation = RespiteMedicationReconciliation::updateOrCreate(
            ['stay_id' => $stay->id, 'type' => $type],
            [
                'status' => $validated['status'],
                'source' => $validated['source'] ?? null,
                'count_received' => $validated['count_received'] ?? null,
                'discrepancies' => $validated['discrepancies'] ?? null,
                'first_dose_due_at' => $validated['first_dose_due_at'] ?? null,
                'override_reason' => $validated['override_reason'] ?? null,
                'reconciled_by_user_id' => auth()->id(),
                'reconciled_at' => in_array($validated['status'], ['completed', 'overridden'], true) ? now() : null,
                'updated_by' => auth()->id(),
                'created_by' => auth()->id(),
            ]
        );

        if ($type === 'admission' && $reconciliation->status === 'completed') {
            $stay->booking?->update([
                'medications_reconciled' => true,
                'medications_reconciled_at' => $reconciliation->reconciled_at ?? now(),
                'medications_reconciled_by' => auth()->id(),
            ]);
        }

        event(new RespiteEvent('respite.stay.medication_reconciliation_recorded', [
            'id' => $reconciliation->id,
            'stay_id' => $stay->id,
            'client_id' => $stay->client_id,
            'type' => $type,
            'status' => $reconciliation->status,
        ]));

        return back()->with('success', 'Medication reconciliation recorded.');
    }

    public function recordRestraint(Request $request, RespiteStay $stay, RestraintService $commands): RedirectResponse
    {
        $accepted = DB::transaction(function () use ($request, $stay, $commands): array {
            $currentStay = $this->stayScope->resolveAuthorizedStay($request, (int) $stay->id, true);
            $input = $request->except('_token', '_method', 'return_to', 'section', 'action');
            if (! array_key_exists('client_id', $input)) {
                $input['client_id'] = (int) $currentStay->client_id;
            }
            $result = $commands->createForStay($request->user(), $currentStay, $input);
            $proof = $commands->confirmationForViewer($request->user(), $result);
            abort_unless($proof && $proof['event_id'] === $result['event_id'] && $proof['idempotency_key'] === $result['idempotency_key'] && $proof['version'] === $result['version'] && $proof['command'] === 'create', 403);
            $proof['replayed'] = $result['replayed'];

            return ['confirmation' => $proof, 'stay_id' => (int) $currentStay->id, 'client_id' => (int) $currentStay->client_id];
        });
        if (! $accepted['confirmation']['replayed']) {
            event(new RespiteEvent('respite.stay.restraint_recorded', ['id' => $accepted['confirmation']['event_id'], 'stay_id' => $accepted['stay_id'], 'client_id' => $accepted['client_id']]));
        }

        return back()->with('success', 'Restraint event recorded.')->with('restraint_confirmation', $accepted['confirmation']);
    }

    public function recordIncident(Request $request, RespiteStay $stay): RedirectResponse
    {
        $validated = $request->validate([
            'type' => 'required|string|max:255',
            'severity' => 'required|in:low,medium,high,critical',
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'occurred_at' => 'nullable|date',
            'immediate_action_taken' => [
                Rule::requiredIf(fn () => in_array($request->input('severity'), ['high', 'critical'], true)),
                'nullable',
                'string',
                'max:5000',
            ],
            'witnesses' => 'nullable|string',
            'is_notifiable' => 'nullable|boolean',
            'notification_authority' => 'nullable|in:worksafe,health_nz,privacy_commissioner,charities_services',
            'incident_type' => 'nullable|in:death,serious_harm,serious_injury,health_safety,privacy_breach',
        ]);

        $actor = $request->user();
        $incident = DB::transaction(function () use ($actor, $request, $stay, $validated): ClientIncident {
            $stay = $this->stayScope->resolveAuthorizedStay($request, (int) $stay->id, true);
            $siteId = $this->stayScope->siteId($stay);
            $incident = ClientIncident::create([
                'client_id' => $stay->client_id,
                'site_id' => $siteId,
                'reported_by' => $actor?->id,
                'respite_stay_id' => $stay->id,
                'type' => $validated['type'],
                'severity' => $validated['severity'],
                'status' => 'submitted',
                'submitted_at' => now(),
                'occurred_at' => $validated['occurred_at'] ?? now(),
                'title' => $validated['title'],
                'description' => $validated['description'],
                'requires_followup' => in_array($validated['severity'], ['high', 'critical'], true),
                'immediate_action_taken' => filled($validated['immediate_action_taken'] ?? null)
                    ? trim((string) $validated['immediate_action_taken'])
                    : null,
                'witnesses' => $validated['witnesses'] ?? null,
                'is_notifiable' => (bool) ($validated['is_notifiable'] ?? false),
                'metadata' => [
                    'source' => 'respite_stay',
                    'stay_id' => $stay->id,
                ],
            ]);

            if ($incident->is_notifiable) {
                NotifiableIncident::create([
                    'incident_type' => $validated['incident_type'] ?? 'health_safety',
                    'notification_authority' => $validated['notification_authority'] ?? 'health_nz',
                    'title' => $validated['title'],
                    'description' => $validated['description'],
                    'related_incident_id' => $incident->id,
                    'severity' => $validated['severity'],
                    'status' => 'pending',
                    'occurred_at' => $incident->occurred_at,
                    'discovered_at' => now(),
                    'notification_deadline' => now()->addDay(),
                    'submitted_by' => $actor?->id,
                    'evidence' => [
                        ['type' => 'respite_stay', 'id' => $stay->id],
                    ],
                ]);
            }

            if (($validated['incident_type'] ?? null) === 'privacy_breach') {
                DataBreachLog::create([
                    'breach_reference' => $this->nextBreachReference(),
                    'breach_type' => 'respite_stay',
                    'severity' => $validated['severity'],
                    'discovered_at' => $incident->occurred_at ?? now(),
                    'discovered_by_user_id' => $actor?->id,
                    'nature_of_breach' => $validated['title']."\n\n".$validated['description'],
                    'affected_data_categories' => ['health_information', 'respite_record'],
                    'approximate_individuals_affected' => 1,
                    'likely_consequences' => '',
                    'measures_taken' => $validated['immediate_action_taken'] ?? '',
                    'requires_authority_notification' => ($validated['notification_authority'] ?? null) === 'privacy_commissioner' || (bool) ($validated['is_notifiable'] ?? false),
                    'requires_subject_notification' => false,
                    'status' => 'discovered',
                    'created_by' => $actor?->id,
                ]);
            }

            return app(IncidentJourneyService::class)
                ->ensureForSubmittedIncident($incident, $actor)
                ->incident;
        }, 3);

        event(new RespiteEvent('respite.stay.incident_recorded', [
            'id' => $incident->id,
            'stay_id' => $incident->respite_stay_id,
            'client_id' => $incident->client_id,
        ]));

        return back()->with('success', 'Incident recorded.');
    }

    public function recordComplaint(Request $request, RespiteStay $stay): RedirectResponse
    {
        $stay->loadMissing('client');
        $this->authorize('view', $stay->client);

        $validated = $request->validate([
            'source' => 'required|in:client,whanau,staff,advocate,external,other',
            'received_at' => 'required|date',
            'nature' => 'required|string|max:255',
            'details' => 'nullable|string|max:5000',
            'acknowledged_at' => 'nullable|date',
            'resolution' => 'nullable|string|max:5000',
            'escalated_to_hdc' => 'nullable|in:no,offered,requested,submitted',
            'status' => 'nullable|in:open,acknowledged,resolved,escalated',
        ]);

        $complaint = RespiteComplaint::create([
            ...$validated,
            'stay_id' => $stay->id,
            'client_id' => $stay->client_id,
            'status' => $validated['status'] ?? (isset($validated['resolution']) ? 'resolved' : 'open'),
            'created_by' => auth()->id(),
        ]);

        event(new RespiteEvent('respite.stay.complaint_recorded', [
            'id' => $complaint->id,
            'stay_id' => $stay->id,
            'client_id' => $stay->client_id,
        ]));

        return back()->with('success', 'Complaint recorded.');
    }

    private function postFundingConsumption(?RespiteStay $stay): void
    {
        $booking = $stay?->booking;
        $agreement = $booking?->service_agreement_id
            ? ServiceAgreement::query()
                ->whereKey($booking->service_agreement_id)
                ->where('client_id', $booking->client_id)
                ->lockForUpdate()
                ->first()
            : null;

        if (! $booking || ! $agreement) {
            return;
        }

        $start = $stay->actual_start ?: $booking->start_at;
        $end = $stay->actual_end ?: now();

        if (! $start || ! $end) {
            return;
        }

        $nights = max(1, Carbon::parse($start)->startOfDay()->diffInDays(Carbon::parse($end)->startOfDay()));
        $hours = $nights * 24;
        $budget = 0.0;

        if ((float) $agreement->daily_rate > 0) {
            $budget = $nights * (float) $agreement->daily_rate;
        } elseif ((float) $agreement->hourly_rate > 0) {
            $budget = $hours * (float) $agreement->hourly_rate;
        }

        $updates = [
            'hours_used' => (float) ($agreement->hours_used ?? 0) + $hours,
            'budget_used' => (float) ($agreement->budget_used ?? 0) + $budget,
        ];

        if ($agreement->agreement_type === 'carer_support' || $agreement->funding_type === 'carer_support') {
            $updates['carer_support_days_used'] = (int) ($agreement->carer_support_days_used ?? 0) + $nights;
        }

        $agreement->forceFill($updates)->save();
    }

    private function nextBreachReference(): string
    {
        return app(ReferenceNumberGenerator::class)->next('BR');
    }

    /**
     * @param  array<string,mixed>  $validated
     */
    private function guardAnaphylaxisAcknowledgement(RespiteStay $stay, array $validated): void
    {
        $allergies = MedicationAllergy::query()
            ->where('client_id', $stay->client_id)
            ->where('severity', 'life_threatening')
            ->get(['id', 'allergen', 'reaction', 'severity']);

        if ($allergies->isEmpty()) {
            return;
        }

        if (! (bool) ($validated['anaphylaxis_acknowledged'] ?? false)) {
            throw ValidationException::withMessages([
                'anaphylaxis_acknowledgement' => 'Acknowledge life-threatening allergy controls, EpiPen location and escalation plan before check-in.',
            ]);
        }

        if (blank($validated['epipen_location'] ?? null)) {
            throw ValidationException::withMessages([
                'epipen_location' => 'Record where the EpiPen or emergency medication is stored before check-in.',
            ]);
        }

        if (blank($validated['anaphylaxis_escalation_note'] ?? null)) {
            throw ValidationException::withMessages([
                'anaphylaxis_escalation_note' => 'Record the escalation plan for a life-threatening allergy before check-in.',
            ]);
        }

        $riskScreen = $stay->admission_risk_screen ?? [];
        $riskScreen['anaphylaxis_acknowledgement'] = [
            'acknowledged' => true,
            'epipen_location' => $validated['epipen_location'],
            'escalation_note' => $validated['anaphylaxis_escalation_note'],
            'allergies' => $allergies
                ->map(fn (MedicationAllergy $allergy) => [
                    'id' => $allergy->id,
                    'allergen' => $allergy->allergen,
                    'reaction' => $allergy->reaction,
                    'severity' => $allergy->severity,
                ])
                ->values()
                ->all(),
            'recorded_by' => auth()->id(),
            'recorded_at' => now()->toIso8601String(),
        ];

        $stay->forceFill([
            'admission_risk_screen' => $riskScreen,
            'updated_by' => auth()->id(),
        ])->save();
    }

    private function guardAdmissionMedicationReconciliation(RespiteStay $stay, ?string $overrideReason): void
    {
        if (! $this->clientHasActiveMedications($stay->client_id)) {
            return;
        }

        $hasCompletedAdmissionMedRec = $stay->medicationReconciliations()
            ->where('type', 'admission')
            ->where('status', 'completed')
            ->exists();

        if ($hasCompletedAdmissionMedRec) {
            $stay->booking?->update([
                'medications_reconciled' => true,
                'medications_reconciled_at' => now(),
                'medications_reconciled_by' => auth()->id(),
            ]);

            return;
        }

        if (blank($overrideReason)) {
            throw ValidationException::withMessages([
                'medication_reconciliation' => 'Complete admission medication reconciliation or record an override reason before check-in.',
            ]);
        }

        RespiteMedicationReconciliation::updateOrCreate(
            ['stay_id' => $stay->id, 'type' => 'admission'],
            [
                'status' => 'overridden',
                'override_reason' => $overrideReason,
                'reconciled_by_user_id' => auth()->id(),
                'reconciled_at' => now(),
                'updated_by' => auth()->id(),
                'created_by' => auth()->id(),
            ]
        );
    }

    private function guardDischargeMedicationReconciliation(RespiteStay $stay, ?array $medRec): void
    {
        if (! $this->clientHasActiveMedications($stay->client_id)) {
            return;
        }

        if (! empty($medRec) && ! empty($medRec['medicines_returned_to']) && array_key_exists('count', $medRec)) {
            return;
        }

        throw ValidationException::withMessages([
            'discharge_medication_reconciliation' => 'Complete discharge medication reconciliation before transferring care back to whanau or another provider.',
        ]);
    }

    private function guardDischargeCompliance(RespiteStay $stay): void
    {
        $unreviewedRestraints = $stay->restraintEvents()
            ->whereNull('reviewed_at')
            ->exists();

        $openIncidents = $stay->incidents()
            ->whereNotIn('status', ['reviewed', 'closed'])
            ->exists();

        $incidentIds = $stay->incidents()->pluck('id');
        $pendingNotifiables = $incidentIds->isNotEmpty()
            && NotifiableIncident::whereIn('related_incident_id', $incidentIds)
                ->where('status', 'pending')
                ->exists();

        if ($unreviewedRestraints || $openIncidents || $pendingNotifiables) {
            throw ValidationException::withMessages([
                'compliance' => 'Resolve open incidents, unreviewed restraint, and pending notifiable-event notifications before discharge.',
            ]);
        }
    }

    private function clientHasActiveMedications(int $clientId): bool
    {
        return ClientMedication::query()
            ->where('client_id', $clientId)
            ->active()
            ->exists();
    }
}
