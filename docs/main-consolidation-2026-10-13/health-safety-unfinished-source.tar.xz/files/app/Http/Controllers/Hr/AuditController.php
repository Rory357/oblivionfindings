<?php

namespace App\Http\Controllers\Hr;

use App\Http\Controllers\Controller;
use App\Models\AuditLog;
use App\Models\User;
use App\Services\Audit\AuditLogViewService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class AuditController extends Controller
{
    public function __construct(private readonly AuditLogViewService $auditLogs) {}

    /**
     * Audit log viewer with filters.
     */
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);
        // Keep independent HR route authority; materialize() owns current audit.viewAny.

        $read = $this->auditLogs->materialize($user, function ($current, $context) use ($request): array {
            $filters = [
                'module' => 'hr',
                'user_id' => $request->integer('user_id') ?: null,
                'action' => $request->string('action')->trim()->value() ?: null,
                'date_from' => $request->string('date_from')->trim()->value() ?: null,
                'date_to' => $request->string('date_to')->trim()->value() ?: null,
            ];
            $modelType = $request->string('model_type')->trim()->value() ?: null;

            $logs = $this->auditLogs->query([...$filters, 'auditable_type' => $modelType], $current, $context)
                ->paginate(30)->withQueryString()
                ->through(fn (AuditLog $log): array => $this->legacyPageShape(
                    $this->auditLogs->present($log, $current, $context)))->toArray();
            $hrLogs = $this->auditLogs->query(['module' => 'hr'], $current, $context)->reorder();
            $modelTypes = (clone $hrLogs)->select('auditable_type')->whereNotNull('auditable_type')
                ->distinct()->pluck('auditable_type')->values()->all();
            $actions = (clone $hrLogs)->select('action')->distinct()->orderBy('action')->pluck('action')->values()->all();
            $users = $context->query(User::query()->whereIn('id', (clone $hrLogs)->select('user_id')
                ->distinct()->whereNotNull('user_id')))->select('id', 'name')->orderBy('name')->get()
                ->map(fn (User $person): array => ['id' => (int) $person->id, 'name' => $person->name])->all();
            return compact('logs', 'modelTypes', 'actions', 'users');
        });

        return Inertia::render('hr/settings/audit-log', [
            'logs' => Inertia::always($read['logs']),
            'actions' => Inertia::always($read['actions']),
            'modelTypes' => Inertia::always($read['modelTypes']),
            'users' => Inertia::always($read['users']),
            'filters' => [
                'user_id' => $request->query('user_id'),
                'action' => $request->query('action'),
                'model_type' => $request->query('model_type'),
                'date_from' => $request->query('date_from'),
                'date_to' => $request->query('date_to'),
            ],
        ]);
    }

    /**
     * Show audit trail for a specific record.
     */
    public function show(Request $request, string $type, int $id)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $logs = $this->auditLogs->materialize($user, fn ($current, $context): array => $this->auditLogs
            ->query(['module' => 'hr', 'auditable_type' => $type, 'auditable_id' => $id], $current, $context)
            ->get()->map(fn (AuditLog $log): array => $this->auditLogs->present($log, $current, $context))->all());

        return response()->json([
            'auditable_type' => $type,
            'auditable_id' => $id,
            'entries' => $logs,
        ]);
    }

    /** @param array<string, mixed> $event */
    private function legacyPageShape(array $event): array
    {
        return [
            'id' => $event['id'],
            'user_id' => $event['actor']['id'] ?? null,
            'action' => $event['action'],
            'auditable_type' => $event['subject_type'],
            'auditable_id' => $event['subject_id'],
            'old_values' => $event['properties']['before'],
            'new_values' => $event['properties']['after'],
            'created_at' => $event['created_at'],
            'user' => $event['actor'],
        ];
    }
}
