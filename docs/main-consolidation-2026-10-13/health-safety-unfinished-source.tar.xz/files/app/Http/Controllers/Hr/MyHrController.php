<?php

namespace App\Http\Controllers\Hr;

use App\Domain\Hr\Exceptions\AttendanceClockOutBlockedException;
use App\Domain\Hr\Models\HrAnnouncement;
use App\Domain\Hr\Models\HrAttendanceSession;
use App\Domain\Hr\Models\HrBenefitEnrollment;
use App\Domain\Hr\Models\HrCourseAssignment;
use App\Domain\Hr\Models\HrCourseEnrollment;
use App\Domain\Hr\Models\HrDevelopmentGoal;
use App\Domain\Hr\Models\HrDocument;
use App\Domain\Hr\Models\HrDocumentSignature;
use App\Domain\Hr\Models\HrEmployeeProfile;
use App\Domain\Hr\Models\HrEngagementSurvey;
use App\Domain\Hr\Models\HrExpenseClaim;
use App\Domain\Hr\Models\HrGoal;
use App\Domain\Hr\Models\HrKudos;
use App\Domain\Hr\Models\HrLeaveBalance;
use App\Domain\Hr\Models\HrLeaveRequest;
use App\Domain\Hr\Models\HrOnboardingChecklist;
use App\Domain\Hr\Models\HrOnboardingTask;
use App\Domain\Hr\Models\HrPayslip;
use App\Domain\Hr\Models\HrPerformanceReview;
use App\Domain\Hr\Models\HrPolicy;
use App\Domain\Hr\Models\HrPolicyAttestation;
use App\Domain\Hr\Models\HrStaffComplianceStatus;
use App\Domain\Hr\Models\HrSupervisionNote;
use App\Domain\Hr\Models\HrTimeEntry;
use App\Domain\Hr\Services\AnnouncementAudienceResolver;
use App\Domain\Hr\Services\AttendanceService;
use App\Domain\Hr\Services\CycleService;
use App\Domain\Hr\Services\EngagementService;
use App\Domain\Hr\Services\ESignatureService;
use App\Domain\Hr\Services\ExpenseService;
use App\Domain\Hr\Services\FeedService;
use App\Domain\Hr\Services\HrCurrentStaffService;
use App\Domain\Hr\Services\HrDocumentAccessService;
use App\Domain\Hr\Services\HrLeaveAccessService;
use App\Domain\Hr\Services\HrNotificationService;
use App\Domain\Hr\Services\HrPerformanceAccessService;
use App\Domain\Hr\Services\LeaveService;
use App\Domain\Hr\Services\OnboardingService;
use App\Domain\Hr\Services\PolicyAttestationService;
use App\Domain\Hr\Services\TimeTrackingService;
use App\Http\Controllers\Controller;
use App\Http\Controllers\Hr\Concerns\BuildsMyHrOverview;
use App\Http\Controllers\Hr\Concerns\BuildsMyHrShell;
use App\Http\Requests\Hr\StoreExpenseClaimRequest;
use App\Models\Shift;
use App\Models\User;
use App\Services\UserSiteAccessService;
use App\Support\HealthSafety\SafeWorkProcedurePresenter;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;
use Inertia\Inertia;

class MyHrController extends Controller
{
    use BuildsMyHrOverview, BuildsMyHrShell;

    public function __construct(
        private readonly LeaveService $leaveService,
        private readonly EngagementService $engagementService,
        private readonly TimeTrackingService $timeTrackingService,
        private readonly AttendanceService $attendanceService,
        private readonly ExpenseService $expenseService,
        private readonly FeedService $feedService,
        private readonly OnboardingService $onboardingService,
        private readonly AnnouncementAudienceResolver $announcementAudiences,
        private readonly HrCurrentStaffService $currentStaff,
        private readonly ESignatureService $signatureService,
        private readonly HrDocumentAccessService $documentAccess,
        private readonly HrLeaveAccessService $leaveAccess,
        private readonly HrPerformanceAccessService $performanceAccess,
        private readonly PolicyAttestationService $policyAttestations,
    ) {}

    private function currentMyHrUser(Request $request): User
    {
        $user = $request->user();
        abort_unless($user instanceof User && $this->currentStaff->isCurrent($user), 404);

        return $user;
    }

    public function sendKudos(Request $request)
    {
        $user = $request->user();
        abort_unless(
            $user
                && $user->canDo('hr.recognition.give')
                && $this->currentStaff->isCurrent($user),
            403,
        );
        $currentStaffRecipientRule = $this->currentStaff->recipientRule();

        $validated = $request->validate([
            'to_user_id' => ['required_without:to_user_ids', 'integer', 'exists:users,id', $currentStaffRecipientRule],
            'to_user_ids' => ['required_without:to_user_id', 'array', 'min:1'],
            'to_user_ids.*' => ['integer', 'exists:users,id', $currentStaffRecipientRule],
            'category' => ['required', 'string', Rule::in(array_keys(FeedService::KUDOS_CATEGORIES))],
            'impact' => ['nullable', 'string', Rule::in(array_keys(FeedService::KUDOS_IMPACTS))],
            'message' => ['required', 'string', 'max:2000'],
        ]);

        $recipientIds = $validated['to_user_ids'] ?? [$validated['to_user_id']];

        try {
            $this->feedService->sendKudosToMany(
                $user,
                $recipientIds,
                $validated['category'],
                $validated['message'],
                $validated['impact'] ?? null,
            );
        } catch (\Throwable $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }

        $count = count($recipientIds);

        return redirect()->back()->with('success', $count > 1 ? "Kudos sent to {$count} colleagues! 🎉" : 'Kudos sent! 🎉');
    }

    /**
     * The "Shout-outs" tab — the full received recognition spotlight (carousel +
     * reactions + reply thread) plus the shout-outs this employee has given (so
     * they can reply back and close the loop). Body reuses the same spotlight
     * components as the Overview.
     */
    public function shoutouts(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        return Inertia::render('hr/my/shoutouts', [
            'myHr' => $this->myHrShellProps($user),
            'received' => $this->myHrShoutouts($user, 'received'),
            'given' => $this->myHrShoutouts($user, 'given'),
        ]);
    }

    /**
     * Toggle an emoji reaction on a kudos for the current user (one of each
     * emoji per person — click again to remove). Open to any teammate in the
     * application since kudos live on the shared recognition feed.
     */
    public function reactKudos(Request $request, HrKudos $kudos)
    {
        $user = $this->currentMyHrUser($request);

        $kudos = HrKudos::query()->findOrFail($kudos->getKey());
        abort_unless($this->feedService->canViewKudos($kudos, $user), 404);
        abort_unless($user->canDo('hr.recognition.give'), 403);

        $validated = $request->validate([
            'emoji' => ['required', 'string', Rule::in(FeedService::REACTION_EMOJIS)],
        ]);

        $this->feedService->toggleReaction($kudos, $user->id, $validated['emoji']);

        return redirect()->back()->with('success', 'Reaction updated.');
    }

    /**
     * Post a reply on a kudos thread. Restricted to the two parties (giver +
     * receiver) so the conversation stays between them — "Say thanks" posts the
     * receiver's reply; the giver can write back from their given shout-outs.
     */
    public function replyKudos(Request $request, HrKudos $kudos)
    {
        $user = $this->currentMyHrUser($request);

        $kudos = HrKudos::query()->findOrFail($kudos->getKey());
        abort_unless($this->feedService->canViewKudos($kudos, $user), 404);
        abort_unless($user->canDo('hr.recognition.give'), 403);
        abort_unless(in_array($user->id, [$kudos->from_user_id, $kudos->to_user_id], true), 403);

        $validated = $request->validate([
            'body' => ['required', 'string', 'max:2000'],
        ]);

        $this->feedService->addReply($kudos, $user->id, $validated['body']);

        return redirect()->back()->with('success', 'Reply posted.');
    }

    public function index(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $profile = HrEmployeeProfile::query()
            ->where('user_id', $user->id)
            ->with('user:id,name,email,profile_photo_path')
            ->first();

        $pendingLeave = HrLeaveRequest::query()
            ->where('user_id', $user->id)
            ->where('status', 'pending')
            ->count();

        $leaveBalances = HrLeaveBalance::query()
            ->where('user_id', $user->id)
            ->where('year', now()->year)
            ->get();

        $complianceStatuses = HrStaffComplianceStatus::query()
            ->where('user_id', $user->id)
            ->with('requirement:id,code,name,category')
            ->get();

        $complianceSummary = [
            'compliant' => $complianceStatuses->where('status', 'compliant')->count(),
            'expiring_soon' => $complianceStatuses->where('status', 'expiring_soon')->count(),
            'expired' => $complianceStatuses->where('status', 'expired')->count(),
            'not_started' => $complianceStatuses->where('status', 'not_started')->count(),
        ];

        $policiesDue = HrPolicy::active()
            ->where('requires_attestation', true)
            ->whereDoesntHave('attestations', fn ($q) => $q->where('user_id', $user->id))
            ->count();

        $pendingReviews = HrPerformanceReview::where('employee_user_id', $user->id)
            ->whereIn('status', ['in_progress', 'completed', 'signed_off'])
            ->where(fn ($q) => $q->whereNull('employee_signed_off')->orWhere('employee_signed_off', false))
            ->count();

        $activeGoals = HrDevelopmentGoal::query()
            ->where('employee_user_id', $user->id)
            ->whereIn('status', ['not_started', 'in_progress', 'blocked'])
            ->count();

        $availableSurveys = HrEngagementSurvey::query()
            ->where('status', 'published')
            ->get()
            ->filter(fn (HrEngagementSurvey $survey) => $this->engagementService->isCurrentRecipient($survey, $user))
            ->count();

        // Timekeeping
        $activeClock = HrTimeEntry::query()
            ->forUser($user->id)
            ->active()
            ->first(['id', 'clock_in', 'notes']);

        $weeklySummary = $this->timeTrackingService->getWeeklySummary($user->id);

        $todayTotal = (float) HrTimeEntry::query()
            ->forUser($user->id)
            ->where('entry_date', now()->toDateString())
            ->whereNotNull('clock_out')
            ->sum('total_hours');

        // Latest payslip
        $latestPayslip = HrPayslip::where('user_id', $user->id)
            ->where('status', 'paid')
            ->orderByDesc('payment_date')
            ->first(['net_pay', 'payment_date']);

        // Expenses
        $pendingExpenses = HrExpenseClaim::query()
            ->where('user_id', $user->id)
            ->where('status', 'submitted')
            ->selectRaw('count(*) as count, coalesce(sum(total_amount), 0) as total')
            ->first();

        // Kudos received (last 30 days)
        $kudosReceived = HrKudos::query()
            ->where('to_user_id', $user->id)
            ->where('created_at', '>=', now()->subDays(30))
            ->count();

        // Announcements (active) for the "Around your team" card + "See all" modal.
        // The card surfaces unacknowledged ones first; the modal lists every active
        // notice with its body + an Acknowledge affordance (Seen ✓ once done).
        $announcements = HrAnnouncement::query()
            ->active()
            ->with(['creator:id,name', 'targets'])
            ->withExists(['acknowledgements as acknowledged' => fn ($q) => $q->where('user_id', $user->id)])
            ->orderByDesc('is_pinned')
            ->orderByDesc('published_at')
            ->lazy(100)
            ->filter(fn (HrAnnouncement $announcement) => (int) $announcement->created_by === (int) $user->id
                || $this->announcementAudiences->includesCurrentUser($announcement, $user))
            ->take(12)
            ->collect()
            ->map(fn (HrAnnouncement $a) => [
                'id' => $a->id,
                'title' => $a->title,
                'priority' => $a->priority,
                'content' => $a->content,
                'published_at' => $a->published_at?->toIso8601String(),
                'byline' => trim(implode(' · ', array_filter([
                    $a->creator?->name,
                    $a->published_at?->isoFormat('D MMM'),
                ]))),
                'acknowledged' => (bool) $a->acknowledged,
            ])
            ->values();

        $safeWorkProcedures = SafeWorkProcedurePresenter::applicableRows(
            $user, '/hr/my', null, $user,
        );

        return Inertia::render('hr/my/index', [
            'myHr' => $this->myHrShellProps($user),
            'overview' => $this->myHrOverviewProps($user),
            // "Getting started" — the new hire's own active onboarding checklist
            // (null once completed/cancelled, or when they never had one).
            'onboarding' => $this->myOnboardingChecklist($user->id, $profile?->id),
            'safeWorkProcedures' => $safeWorkProcedures,
            // Shaped for the Overview's hosted "Request leave" wizard (mirrors
            // the Leave tab's `balances` contract).
            'balances' => $leaveBalances->map(fn (HrLeaveBalance $b) => [
                'leave_type' => $b->leave_type,
                'entitlement_hours' => (float) $b->accrued_hours,
                'taken_hours' => (float) $b->used_hours,
                'remaining_hours' => (float) $b->balance_hours,
            ])->values(),
            'profile' => $profile,
            'pendingLeave' => $pendingLeave,
            'leaveBalances' => $leaveBalances,
            'complianceSummary' => $complianceSummary,
            'complianceStatuses' => $complianceStatuses,
            'policiesDue' => $policiesDue,
            'pendingReviews' => $pendingReviews,
            'activeGoals' => $activeGoals,
            'availableSurveys' => $availableSurveys,
            'activeClock' => $activeClock,
            'weeklySummary' => $weeklySummary,
            'todayTotal' => $todayTotal,
            'latestPayslip' => $latestPayslip,
            'pendingExpenses' => $pendingExpenses ? [
                'count' => (int) $pendingExpenses->count,
                'total' => (float) $pendingExpenses->total,
            ] : ['count' => 0, 'total' => 0],
            'kudosReceived' => $kudosReceived,
            'announcements' => $announcements,
            'canViewFeed' => $user->canDo('hr.announcements.view'),
            // Feeds the Overview's hosted "Request leave" wizard (tile picker +
            // calendar holiday highlight).
            'leaveTypes' => LeaveService::LEAVE_TYPES,
            'publicHolidays' => $this->leaveService->publicHolidayMap(),
        ]);
    }

    /* ------------------------------------------------------------------ */
    /*  Onboarding (Getting started — subject self-service) */
    /* ------------------------------------------------------------------ */

    /**
     * The employee's own ACTIVE onboarding checklist for the Overview's
     * "Getting started" card. Tasks the subject may complete themselves —
     * assigned to them, or unassigned and not requiring sign-off — carry
     * can_complete so the card can offer a "Mark done" affordance.
     *
     * @return array<string, mixed>|null
     */
    private function myOnboardingChecklist(int $userId, ?int $profileId): ?array
    {
        if (! $profileId) {
            return null;
        }

        $checklist = HrOnboardingChecklist::query()
            ->where('employee_profile_id', $profileId)
            ->whereIn('status', ['pending', 'in_progress'])
            ->with(['tasks' => fn ($q) => $q->orderBy('sort_order')->orderBy('id')])
            ->orderByDesc('id')
            ->first();

        if (! $checklist) {
            return null;
        }

        $progress = $this->onboardingService->getProgress($checklist);
        $today = now()->startOfDay();

        return [
            'id' => $checklist->id,
            'status' => $checklist->status,
            'due_date' => $checklist->due_date?->toDateString(),
            'progress' => [
                'total' => $progress['total'],
                'completed' => $progress['completed'],
                'percent' => $progress['percent'],
            ],
            'tasks' => $checklist->tasks->map(fn (HrOnboardingTask $t) => [
                'id' => $t->id,
                'title' => $t->title,
                'category' => $t->category,
                'due_date' => $t->due_date?->toDateString(),
                'status' => $t->status,
                'completed' => $t->status === 'completed',
                'overdue' => $t->status !== 'completed'
                    && $t->due_date !== null
                    && $t->due_date->lt($today),
                'sign_off_required' => (bool) $t->sign_off_required,
                'can_complete' => $t->status !== 'completed'
                    && $this->subjectMayCompleteTask($t, $userId),
            ])->values()->all(),
        ];
    }

    /**
     * The subject may complete their own tasks when the task is assigned to
     * them, or unassigned AND not a sign-off task (sign-offs stay with the
     * manager/HR flow in /hr/onboarding).
     */
    private function subjectMayCompleteTask(HrOnboardingTask $task, int $userId): bool
    {
        return (int) $task->assigned_to_user_id === $userId
            || ($task->assigned_to_user_id === null && ! $task->sign_off_required);
    }

    /**
     * Owner-gated: a new hire completes one of their own onboarding tasks from
     * the "Getting started" card. Runs through OnboardingService::completeTask
     * so dependency validation, checklist rollup and the completion webhook all
     * fire exactly as they do for the manager flow.
     */
    public function completeOnboardingTask(Request $request, HrOnboardingTask $task)
    {
        $user = $this->currentMyHrUser($request);

        $checklist = $task->checklist()->with('employeeProfile:id,user_id')->firstOrFail();

        // Owner-only: the checklist must belong to the requesting employee.
        abort_unless($checklist->employeeProfile?->user_id === $user->id, 403);
        abort_unless($this->subjectMayCompleteTask($task, $user->id), 403);

        $validated = $request->validate([
            'notes' => ['nullable', 'string', 'max:2000'],
        ]);

        try {
            $this->onboardingService->completeTask($task, $user->id, array_filter([
                'notes' => $validated['notes'] ?? null,
            ], fn ($v) => $v !== null));
        } catch (\LogicException $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }

        return redirect()->back()->with('success', "Nice — “{$task->title}” done.");
    }

    /* ------------------------------------------------------------------ */
    /*  Benefits (read-only self-service) */
    /* ------------------------------------------------------------------ */

    /**
     * The employee's own benefit enrolments (KiwiSaver, insurances…) —
     * read-only; changes go through HR (Compensation & Benefits hub).
     */
    public function benefits(Request $request)
    {
        $user = $this->currentMyHrUser($request);
        $this->performanceAccess->currentStaff($user, $user);

        $profileId = $this->performanceAccess
            ->applyCurrentProfileScope(HrEmployeeProfile::query(), $user)
            ->where('user_id', $user->id)
            ->value('id');

        $enrolments = $profileId
            ? HrBenefitEnrollment::query()
                ->where('employee_profile_id', $profileId)
                ->with('benefitPlan:id,name,type,provider,description')
                ->orderByDesc('enrollment_date')
                ->get()
                ->map(fn (HrBenefitEnrollment $e) => [
                    'id' => $e->id,
                    'plan_name' => $e->benefitPlan?->name ?? 'Benefit plan',
                    'plan_type' => $e->benefitPlan?->type ?? 'other',
                    'provider' => $e->benefitPlan?->provider,
                    'description' => $e->benefitPlan?->description,
                    'status' => $e->status,
                    'employee_contribution_rate' => $e->employee_contribution_rate !== null
                        ? (float) $e->employee_contribution_rate
                        : null,
                    'employer_contribution_rate' => $e->employer_contribution_rate !== null
                        ? (float) $e->employer_contribution_rate
                        : null,
                    'enrollment_date' => $e->enrollment_date?->toDateString(),
                    'opt_out_date' => $e->opt_out_date?->toDateString(),
                ])
                ->values()
            : collect();

        return Inertia::render('hr/my/benefits', [
            'myHr' => $this->myHrShellProps($user),
            'enrolments' => $enrolments,
        ]);
    }

    public function leave(Request $request)
    {
        $user = $this->currentMyHrUser($request);
        $this->leaveAccess->currentSubject($user, $user);

        $requests = HrLeaveRequest::query()
            ->where('user_id', $user->id)
            ->with('reviewer:id,name')
            ->orderByDesc('submitted_at')
            ->paginate(20)
            ->withQueryString();

        $requests->getCollection()->transform(fn ($r) => [
            'id' => $r->id,
            'leave_type' => $r->leave_type,
            'start_date' => $r->starts_at?->toDateString(),
            'end_date' => $r->ends_at?->toDateString(),
            'hours' => (float) $r->hours_requested,
            'status' => $r->status,
            'reason' => $r->reason,
            'created_at' => $r->submitted_at?->toDateString() ?? $r->created_at?->toDateString(),
        ]);

        $balances = HrLeaveBalance::query()
            ->where('user_id', $user->id)
            ->where('year', now()->year)
            ->get()
            ->map(fn ($b) => [
                'leave_type' => $b->leave_type,
                'entitlement_hours' => (float) $b->accrued_hours,
                'taken_hours' => (float) $b->used_hours,
                'remaining_hours' => (float) $b->balance_hours,
            ]);

        return Inertia::render('hr/my/leave', [
            'myHr' => $this->myHrShellProps($user),
            'whosOutWeek' => $this->myHrWhosOutByDay($user),
            'requests' => $requests,
            'balances' => $balances,
            'leaveTypes' => LeaveService::LEAVE_TYPES,
            'publicHolidays' => $this->leaveService->publicHolidayMap(),
        ]);
    }

    public function submitLeave(Request $request)
    {
        $user = $this->currentMyHrUser($request);
        $this->leaveAccess->currentSubject($user, $user);

        $validated = $request->validate([
            'leave_type' => ['required', 'string', Rule::in(LeaveService::LEAVE_TYPES)],
            'period' => ['nullable', Rule::in(['full_day', 'half_day_am', 'half_day_pm'])],
            'starts_at' => ['required', 'date', 'after_or_equal:today'],
            'ends_at' => ['required', 'date', 'after_or_equal:starts_at'],
            'hours_requested' => ['nullable', 'numeric', 'min:0.5', 'max:999'],
            'reason' => ['nullable', 'string', 'max:2000'],
            'supporting_doc' => ['nullable', 'file', 'mimes:pdf,jpg,jpeg,png,doc,docx', 'max:5120'],
        ]);

        if (in_array($validated['period'] ?? null, ['half_day_am', 'half_day_pm'], true)
            && $validated['starts_at'] !== $validated['ends_at']) {
            return redirect()->back()->with('error', 'A half-day can only be requested for a single day.');
        }

        $data = $validated;

        if ($request->hasFile('supporting_doc')) {
            $data['supporting_doc_path'] = $request->file('supporting_doc')
                ->store("leave/{$user->id}", 'private');
        }

        try {
            $this->leaveService->submitRequest($user, $data);
        } catch (\InvalidArgumentException $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }

        return redirect()->back()->with('success', 'Leave request submitted.');
    }

    /**
     * Read-only preview for the self-service request modal review step (handover §5.3).
     */
    public function previewLeave(Request $request)
    {
        $user = $this->currentMyHrUser($request);
        $this->leaveAccess->currentSubject($user, $user);

        $validated = $request->validate([
            'leave_type' => ['required', 'string', Rule::in(LeaveService::LEAVE_TYPES)],
            'period' => ['nullable', Rule::in(['full_day', 'half_day_am', 'half_day_pm'])],
            'starts_at' => ['required', 'date'],
            'ends_at' => ['required', 'date'],
        ]);

        try {
            $preview = $this->leaveService->previewRequest($user, $validated);
        } catch (\InvalidArgumentException $e) {
            return response()->json(['error' => $e->getMessage()], 422);
        }

        return response()->json($preview);
    }

    public function expenses(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $claims = HrExpenseClaim::query()
            ->where('user_id', $user->id)
            ->withCount('items')
            ->orderByDesc('created_at')
            ->paginate(20)
            ->withQueryString();

        $claims->through(fn (HrExpenseClaim $claim) => [
            'id' => $claim->id,
            'claim_number' => $claim->claim_number,
            'title' => $claim->title,
            'status' => $claim->status,
            'total_amount' => (float) $claim->total_amount,
            'currency' => $claim->currency,
            'items_count' => $claim->items_count,
            'submitted_at' => $claim->submitted_at?->toDateString(),
            'created_at' => $claim->created_at?->toDateString(),
        ]);

        return Inertia::render('hr/my/expenses', [
            'myHr' => $this->myHrShellProps($user),
            'claims' => $claims,
            'categories' => ExpenseService::CATEGORIES,
        ]);
    }

    public function submitExpense(StoreExpenseClaimRequest $request)
    {
        $user = $this->currentMyHrUser($request);

        try {
            $this->expenseService->createClaim($user, $request->validated());
        } catch (\Throwable $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }

        return redirect()->route('hr.my.expenses')->with('success', 'Expense claim created.');
    }

    /**
     * Send my own draft claim for approval — or resubmit one that was
     * rejected (the service clears the prior decision). Owner-gated.
     */
    public function submitExpenseClaim(Request $request, HrExpenseClaim $expenseClaim)
    {
        $user = $this->currentMyHrUser($request);
        abort_unless((int) $expenseClaim->user_id === (int) $user->id, 403);

        try {
            $this->expenseService->submitClaim($expenseClaim);
        } catch (\LogicException $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }

        return redirect()->back()->with('success', 'Expense claim submitted for approval.');
    }

    /**
     * Pull my own submitted claim back to draft before it's actioned —
     * it becomes editable again and can be resubmitted. Owner-gated.
     */
    public function withdrawExpenseClaim(Request $request, HrExpenseClaim $expenseClaim)
    {
        $user = $this->currentMyHrUser($request);
        abort_unless((int) $expenseClaim->user_id === (int) $user->id, 403);

        try {
            $this->expenseService->withdrawClaim($expenseClaim);
        } catch (\LogicException $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }

        return redirect()->back()->with('success', 'Expense claim withdrawn — it is back in draft and can be edited or resubmitted.');
    }

    public function cancelLeave(Request $request, HrLeaveRequest $leaveRequest)
    {
        $user = $this->currentMyHrUser($request);
        $this->leaveAccess->currentSubject($user, $user);
        abort_unless($leaveRequest->user_id === $user->id, 403);
        abort_unless(in_array($leaveRequest->status, ['pending', 'approved'], true), 422);

        try {
            $this->leaveService->cancelRequest($leaveRequest, $user);
        } catch (\LogicException $exception) {
            return redirect()->back()->withErrors(['leave_request' => $exception->getMessage()]);
        }

        return redirect()->back()->with('success', 'Leave request cancelled.');
    }

    public function training(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        // Active course assignments (my to-do list): everything not yet
        // completed or waived, soonest due first, with an explicit overdue flag.
        $assignments = HrCourseAssignment::query()
            ->where('user_id', $user->id)
            ->whereNotIn('status', ['completed', 'waived'])
            ->with('course:id,title,code,category,delivery_method,duration_hours')
            ->orderByRaw('due_at IS NULL, due_at')
            ->get()
            ->map(fn (HrCourseAssignment $a) => [
                'id' => $a->id,
                'course_id' => $a->course?->id,
                'course_title' => $a->course?->title ?? 'Training course',
                'course_category' => $a->course?->category,
                'delivery_method' => $a->course?->delivery_method,
                'due_date' => $a->due_at?->toDateString(),
                'status' => $a->effectiveStatus(),
                'overdue' => $a->effectiveStatus() === 'overdue',
                'assigned_at' => $a->assigned_at?->toDateString(),
            ])
            ->values();

        // In-progress enrolments not already represented by an active assignment
        // (assignments carry the due date, so they win the card).
        $assignedCourseTitles = $assignments->pluck('course_title')->all();
        $enrolments = HrCourseEnrollment::query()
            ->where('user_id', $user->id)
            ->whereIn('status', ['enrolled', 'in_progress'])
            ->with(['course:id,title,category,delivery_method', 'session:id,session_date'])
            ->orderBy('enrolled_at')
            ->get()
            ->map(fn (HrCourseEnrollment $e) => [
                'id' => $e->id,
                'course_id' => $e->course?->id,
                'course_title' => $e->course?->title ?? 'Training course',
                'course_category' => $e->course?->category,
                'delivery_method' => $e->course?->delivery_method,
                'session_date' => $e->session?->session_date?->toDateString(),
                'enrolled_at' => $e->enrolled_at?->toDateString(),
            ])
            ->reject(fn (array $e) => in_array($e['course_title'], $assignedCourseTitles, true))
            ->values();

        $complianceStatuses = HrStaffComplianceStatus::query()
            ->where('user_id', $user->id)
            ->with('requirement:id,code,name,category,description,validity_months,renewal_reminder_days,check_type')
            ->orderByRaw("FIELD(status, 'expired', 'non_compliant', 'expiring_soon', 'not_started', 'compliant')")
            ->get()
            ->map(function (HrStaffComplianceStatus $status) {
                $normalizedStatus = match ($status->status) {
                    'compliant' => 'compliant',
                    'expiring_soon' => 'expiring_soon',
                    'expired', 'non_compliant' => 'expired',
                    default => 'not_started',
                };

                $daysUntilExpiry = $status->expires_at
                    ? now()->startOfDay()->diffInDays($status->expires_at->startOfDay(), false)
                    : null;

                return [
                    'id' => $status->id,
                    'status' => $normalizedStatus,
                    'expiry_date' => optional($status->expires_at)->toDateString(),
                    'completed_at' => optional($status->valid_from)->toDateString(),
                    'days_until_expiry' => $daysUntilExpiry,
                    'evidence_type' => $status->evidence_type,
                    'requirement' => [
                        'id' => $status->requirement?->id,
                        'name' => $status->requirement?->name ?? 'Untitled requirement',
                        'category' => $status->requirement?->category ?? 'general',
                        'description' => $status->requirement?->description,
                        'validity_months' => $status->requirement?->validity_months,
                        'check_type' => $status->requirement?->check_type,
                    ],
                ];
            })
            ->values();

        return Inertia::render('hr/my/training', [
            'myHr' => $this->myHrShellProps($user),
            'assignments' => $assignments,
            'enrolments' => $enrolments,
            'complianceStatuses' => $complianceStatuses,
            'can' => [
                // Only surface the LMS catalog link to users who can open it
                // (the catalog route is gated hr.training.view|training.viewAny).
                'viewCatalog' => $user->canDo('hr.training.view') || $user->canDo('training.viewAny'),
            ],
        ]);
    }

    public function policies(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $attestByDays = (int) config('hr.policy_attestation_overdue_days', 7);

        $policies = HrPolicy::active()
            ->where('requires_attestation', true)
            ->with(['versions' => fn ($q) => $q->where('is_current', true)])
            ->orderBy('title')
            ->get()
            ->map(function ($policy) use ($user, $attestByDays) {
                $attestation = HrPolicyAttestation::where('policy_id', $policy->id)
                    ->where('user_id', $user->id)
                    ->orderByDesc('attested_at')
                    ->first();

                $currentVersion = $policy->versions->first();

                // Attested only counts against the CURRENT version — a new
                // version resets it (legacy rows with no version stamp pass).
                $attestedCurrent = $attestation !== null
                    && ($attestation->policy_version_id === null
                        || ! $currentVersion
                        || (int) $attestation->policy_version_id === (int) $currentVersion->id);

                // Periodic re-attestation: due again once the configured
                // frequency has elapsed since the last attestation.
                $reattestDueAt = null;
                if ($attestedCurrent && $policy->attestation_frequency_months && $attestation?->attested_at) {
                    $reattestDueAt = $attestation->attested_at->copy()->addMonths((int) $policy->attestation_frequency_months);
                    if ($reattestDueAt->isPast()) {
                        $attestedCurrent = false;
                    }
                }

                // "Attest by" for pending items: version publish date + grace
                // window (matches the reminder job), or the lapsed re-attest date.
                $attestBy = null;
                if (! $attestedCurrent) {
                    $publishedAt = $currentVersion?->effective_from ?? $currentVersion?->created_at;
                    $attestBy = $reattestDueAt?->isPast()
                        ? $reattestDueAt
                        : $publishedAt?->copy()->addDays($attestByDays);
                }

                $policy->my_attestation = $attestation;
                $policy->is_attested = $attestedCurrent;
                $policy->attest_by = $attestBy?->toDateString();
                $policy->attest_overdue = $attestBy !== null && $attestBy->isPast();

                return $policy;
            });

        return Inertia::render('hr/my/policies', [
            'myHr' => $this->myHrShellProps($user),
            'policies' => $policies,
        ]);
    }

    public function attestPolicy(Request $request, HrPolicy $policy)
    {
        $user = $this->currentMyHrUser($request);
        abort_unless($user->canDo('hr.policies.attest'), 403);
        $this->policyAttestations->attest(
            $user,
            $policy,
            $request->ip(),
            $request->userAgent(),
        );

        return redirect()->back()->with('success', 'Policy attestation recorded.');
    }

    public function profile(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $profile = HrEmployeeProfile::query()
            ->where('user_id', $user->id)
            ->with(['user:id,name,email', 'primarySite:id,name'])
            ->first();

        $primaryEmergencyContact = collect($profile?->emergency_contacts ?? [])->first();

        $profileData = $profile ? [
            'id' => $profile->id,
            'employee_number' => $profile->employee_number,
            'position_title' => $profile->position_title,
            'employment_type' => $profile->employment_type,
            'start_date' => optional($profile->start_date)->toDateString(),
            'end_date' => optional($profile->end_date)->toDateString(),
            'is_active' => (bool) $profile->is_active,
            'personal_email' => $profile->personal_email,
            'phone' => $profile->personal_phone,
            'home_address' => $profile->home_address,
            'emergency_contact_name' => $primaryEmergencyContact['name'] ?? null,
            'emergency_contact_phone' => $primaryEmergencyContact['phone'] ?? null,
            'emergency_contact_relationship' => $primaryEmergencyContact['relationship'] ?? null,
            'user' => $profile->user ? [
                'id' => $profile->user->id,
                'name' => $profile->user->name,
                'email' => $profile->user->email,
                'avatar' => $profile->user->profile_photo_path,
            ] : null,
            'primary_site' => $profile->primarySite ? [
                'id' => $profile->primarySite->id,
                'name' => $profile->primarySite->name,
            ] : null,
        ] : null;

        return Inertia::render('hr/my/profile', [
            'myHr' => $this->myHrShellProps($user),
            'profile' => $profileData,
        ]);
    }

    public function updateProfile(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $profile = HrEmployeeProfile::query()
            ->where('user_id', $user->id)
            ->firstOrFail();

        $validated = $request->validate([
            'personal_email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:50'],
            'personal_phone' => ['nullable', 'string', 'max:50'],
            'home_address' => ['nullable', 'string', 'max:1000'],
            'emergency_contact_name' => ['nullable', 'string', 'max:255'],
            'emergency_contact_phone' => ['nullable', 'string', 'max:50'],
            'emergency_contact_relationship' => ['nullable', 'string', 'max:100'],
            'emergency_contacts' => ['nullable', 'array'],
        ]);

        $phone = trim((string) ($validated['personal_phone'] ?? $validated['phone'] ?? ''));
        $phone = $phone !== '' ? $phone : null;

        $emergencyContacts = [];
        if (is_array($validated['emergency_contacts'] ?? null)) {
            $emergencyContacts = $validated['emergency_contacts'];
        }

        $name = trim((string) ($validated['emergency_contact_name'] ?? ''));
        $contactPhone = trim((string) ($validated['emergency_contact_phone'] ?? ''));
        $relationship = trim((string) ($validated['emergency_contact_relationship'] ?? ''));
        if ($name !== '' || $contactPhone !== '' || $relationship !== '') {
            $emergencyContacts = [[
                'name' => $name !== '' ? $name : null,
                'phone' => $contactPhone !== '' ? $contactPhone : null,
                'relationship' => $relationship !== '' ? $relationship : null,
            ]];
        }

        $profile->update([
            'personal_email' => $validated['personal_email'] ?? null,
            'personal_phone' => $phone,
            'home_address' => $validated['home_address'] ?? null,
            'emergency_contacts' => $emergencyContacts !== [] ? $emergencyContacts : null,
            'updated_by' => $user->id,
        ]);

        return redirect()->back()->with('success', 'Profile updated.');
    }

    /* ------------------------------------------------------------------ */
    /*  Staff Directory (phonebook) */
    /* ------------------------------------------------------------------ */

    /**
     * The all-staff "who is who" directory, surfaced as a My HR tab so every
     * staff member can look up a colleague's role, site and work contact.
     *
     * Work contact only — personal phone/email never appear here (those stay on
     * the person's own Profile tab and the manager-only People hub). Gated to
     * staff: the viewer must have an HR employee profile, so portal/family users
     * (who have none) get a 403 rather than the full staff roster.
     */
    public function directory(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $visibleStaffIds = app(UserSiteAccessService::class)
            ->applyStaffScope($this->currentStaff->currentUsersQuery()->select('users.id'), $user);

        $people = HrEmployeeProfile::query()
            ->whereIn('user_id', $visibleStaffIds)
            ->whereNotNull('user_id')
            ->with([
                'user:id,name',
                'primarySite:id,name',
                'departmentRelation:id,name',
            ])
            ->get()
            ->map(function (HrEmployeeProfile $p) use ($user) {
                $name = $p->preferred_name ?: $p->user?->name;
                if (! $name) {
                    return null;
                }

                return [
                    'id' => $p->id,
                    'name' => $name,
                    'initials' => $this->myHrInitials($name),
                    'role' => $p->position_title,
                    'department' => $p->departmentRelation?->name ?? $p->department,
                    'site' => $p->primarySite?->name,
                    // Work email only: the sign-in email can be personal, so
                    // someone without an HR work email shows no email here.
                    'email' => $p->work_email ?: null,
                    'phone' => $p->work_phone,
                    'avatar' => $p->profile_photo_path,
                    'is_first_aider' => (bool) $p->is_first_aider,
                    'is_fire_warden' => (bool) $p->is_fire_warden,
                    'is_self' => $p->user_id === $user->id,
                ];
            })
            ->filter()
            ->sortBy(fn ($p) => mb_strtolower($p['name']), SORT_NATURAL)
            ->values()
            ->all();

        return Inertia::render('hr/my/directory', [
            'myHr' => $this->myHrShellProps($user),
            'people' => $people,
        ]);
    }

    /* ------------------------------------------------------------------ */
    /*  Performance Reviews */
    /* ------------------------------------------------------------------ */

    public function reviews(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $reviews = HrPerformanceReview::where('employee_user_id', $user->id)
            ->whereIn('status', ['in_progress', 'completed', 'signed_off'])
            ->with('reviewer:id,name')
            ->orderByDesc('created_at')
            ->paginate(20)
            ->withQueryString();

        $reviews->through(fn (HrPerformanceReview $review) => [
            'id' => $review->id,
            'review_type' => $review->review_type,
            'review_period_start' => $review->review_period_start?->toDateString(),
            'review_period_end' => $review->review_period_end?->toDateString(),
            'status' => $review->status,
            'overall_rating' => $review->overall_rating,
            'strengths' => $review->strengths,
            'development_areas' => $review->development_areas,
            'goals' => $review->goals,
            'training_recommendations' => $review->training_recommendations,
            'employee_comments' => $review->employee_comments,
            'employee_signed_off' => (bool) $review->employee_signed_off,
            'employee_signed_off_at' => $review->employee_signed_off_at?->toDateTimeString(),
            'manager_signed_off' => (bool) $review->manager_signed_off,
            'next_review_date' => $review->next_review_date?->toDateString(),
            'reviewer' => $review->reviewer ? [
                'id' => $review->reviewer->id,
                'name' => $review->reviewer->name,
            ] : null,
        ]);

        return Inertia::render('hr/my/reviews', [
            'myHr' => $this->myHrShellProps($user),
            'reviews' => $reviews,
        ]);
    }

    public function updateReview(Request $request, HrPerformanceReview $review)
    {
        $user = $this->currentMyHrUser($request);

        $validated = $request->validate([
            'employee_comments' => ['nullable', 'string', 'max:5000'],
            'employee_signed_off' => ['nullable', 'boolean'],
        ]);

        $signingOff = DB::transaction(function () use ($review, $user, $validated): bool {
            $locked = $this->performanceAccess
                ->applyHistoricalSubjectScope(HrPerformanceReview::query(), $user)
                ->whereKey($review->getKey())
                ->where('employee_user_id', $user->id)
                ->whereIn('status', ['in_progress', 'completed', 'signed_off'])
                ->lockForUpdate()
                ->firstOrFail();
            abort_if($locked->employee_signed_off, 422, 'This acknowledgement is locked.');
            $data = ['employee_comments' => $validated['employee_comments'] ?? $locked->employee_comments];
            $signingOff = ! empty($validated['employee_signed_off']) && ! $locked->employee_signed_off;

            if ($signingOff) {
                abort_unless(
                    $locked->status === 'signed_off' && $locked->manager_signed_off,
                    422,
                    'Only a manager-signed review can be acknowledged.',
                );
                $data['employee_signed_off'] = true;
                $data['employee_signed_off_at'] = now();
            }

            $locked->update($data);

            return $signingOff;
        }, attempts: 1);

        if ($signingOff) {
            app(HrNotificationService::class)->notifyReviewSignedOff($review->fresh());
        }

        return redirect()->back()->with('success', 'Review updated.');
    }

    /* ------------------------------------------------------------------ */
    /*  Development Goals */
    /* ------------------------------------------------------------------ */

    public function goals(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $goals = HrDevelopmentGoal::query()
            ->where('employee_user_id', $user->id)
            ->with('manager:id,name')
            ->orderByRaw("CASE WHEN status IN ('in_progress','not_started','blocked') THEN 0 ELSE 1 END")
            ->orderBy('due_date')
            ->paginate(20)
            ->withQueryString();

        $goals->through(fn (HrDevelopmentGoal $goal) => [
            'id' => $goal->id,
            'title' => $goal->title,
            'description' => $goal->description,
            'category' => $goal->category,
            'competency_area' => $goal->competency_area,
            'target_level' => $goal->target_level,
            'current_level' => $goal->current_level,
            'status' => $goal->status,
            'progress_percent' => (int) $goal->progress_percent,
            'start_date' => $goal->start_date?->toDateString(),
            'due_date' => $goal->due_date?->toDateString(),
            'completed_at' => $goal->completed_at?->toDateString(),
            'review_notes' => $goal->review_notes,
            'manager' => $goal->manager ? [
                'id' => $goal->manager->id,
                'name' => $goal->manager->name,
            ] : null,
        ]);

        // My OKR objectives (HrGoal, owned by me, scoped to the current cycle
        // when one exists) with progress/RAG + the check-in affordance.
        $currentCycle = app(CycleService::class)->currentCycle();
        $objectives = HrGoal::query()
            ->where('user_id', $user->id)
            ->whereNotIn('status', ['completed', 'cancelled'])
            ->when($currentCycle, fn ($q) => $q->where(
                fn ($qq) => $qq->where('cycle_id', $currentCycle->id)->orWhereNull('cycle_id'),
            ))
            ->with([
                'cycle:id,name',
                'keyResults:id,goal_id,title,current_value,target_value,unit,confidence',
            ])
            ->orderBy('due_date')
            ->get()
            ->map(fn (HrGoal $g) => [
                'id' => $g->id,
                'title' => $g->title,
                'status' => $g->status,
                'confidence' => $g->confidence ?? 'on_track',
                'progress_percentage' => (int) $g->progress_percentage,
                'due_date' => $g->due_date?->toDateString(),
                'last_checkin_at' => $g->last_checkin_at?->toDateString(),
                'cycle' => $g->cycle?->name,
                'key_results' => $g->keyResults->map(fn ($kr) => [
                    'id' => $kr->id,
                    'title' => $kr->title,
                    'current_value' => $kr->current_value !== null ? (float) $kr->current_value : null,
                    'target_value' => $kr->target_value !== null ? (float) $kr->target_value : null,
                    'unit' => $kr->unit,
                ])->values(),
            ])
            ->values();

        return Inertia::render('hr/my/goals', [
            'myHr' => $this->myHrShellProps($user),
            'goals' => $goals,
            'objectives' => $objectives,
        ]);
    }

    public function updateGoal(Request $request, HrDevelopmentGoal $goal)
    {
        $user = $this->currentMyHrUser($request);
        $goal = HrDevelopmentGoal::query()
            ->whereKey($goal->getKey())
            ->where('employee_user_id', $user->id)
            ->firstOrFail();

        $validated = $request->validate([
            'status' => ['sometimes', 'string', Rule::in(['not_started', 'in_progress', 'blocked', 'completed'])],
            'progress_percent' => ['sometimes', 'integer', 'min:0', 'max:100'],
            'review_notes' => ['nullable', 'string', 'max:5000'],
            'current_level' => ['nullable', 'integer', 'min:1', 'max:5'],
        ]);

        $wasCompleted = $goal->status === 'completed';

        if (($validated['status'] ?? null) === 'completed') {
            $validated['completed_at'] = now();
            $validated['progress_percent'] = 100;
        }

        $goal->update($validated);

        // Employee completed their own development goal → tell the manager.
        if (($validated['status'] ?? null) === 'completed' && ! $wasCompleted) {
            app(HrNotificationService::class)->notifyDevelopmentGoalCompleted($goal->fresh(), $user->id);
        }

        return redirect()->back()->with('success', 'Goal updated.');
    }

    /* ------------------------------------------------------------------ */
    /*  Engagement Surveys */
    /* ------------------------------------------------------------------ */

    public function surveys(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $surveys = HrEngagementSurvey::query()
            ->where('status', 'published')
            ->with('questions')
            ->get()
            ->filter(fn (HrEngagementSurvey $survey) => $this->engagementService->isCurrentRecipient($survey, $user))
            ->map(function (HrEngagementSurvey $survey) use ($user) {
                $respondentHash = hash_hmac('sha256', $survey->id.':'.$user->id, (string) config('app.key'));

                $hasResponded = $survey->responses()
                    ->where(function ($query) use ($survey, $user, $respondentHash) {
                        if ($survey->is_anonymous) {
                            $query->where('respondent_hash', $respondentHash);
                        } else {
                            $query->where('user_id', $user->id);
                        }
                    })
                    ->exists();

                return [
                    'id' => $survey->id,
                    'title' => $survey->title,
                    'description' => $survey->description,
                    'is_anonymous' => $survey->is_anonymous,
                    'starts_at' => $survey->starts_at?->toDateString(),
                    'ends_at' => $survey->ends_at?->toDateString(),
                    'has_responded' => $hasResponded,
                    'questions' => $survey->questions->sortBy('sort_order')->values()->map(fn ($q) => [
                        'id' => $q->id,
                        'question_type' => $q->question_type,
                        'question_text' => $q->question_text,
                        'options' => $q->options,
                        'is_required' => $q->is_required,
                        'sort_order' => $q->sort_order,
                    ])->all(),
                ];
            })
            ->values();

        return Inertia::render('hr/my/surveys', [
            'myHr' => $this->myHrShellProps($user),
            'surveys' => $surveys,
        ]);
    }

    public function submitSurvey(Request $request, HrEngagementSurvey $survey)
    {
        $user = $this->currentMyHrUser($request);

        $survey = HrEngagementSurvey::query()->findOrFail($survey->getKey());
        abort_unless($this->engagementService->isCurrentRecipient($survey, $user), 404);

        $validated = $request->validate([
            'answers' => ['required', 'array'],
        ]);

        try {
            $this->engagementService->submitResponse($survey, $user, $validated['answers']);
        } catch (\InvalidArgumentException $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }

        return redirect()->back()->with('success', 'Survey response submitted.');
    }

    /* ------------------------------------------------------------------ */
    /*  Timekeeping (Self-Service) */
    /* ------------------------------------------------------------------ */

    public function time(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $activeClock = HrTimeEntry::query()
            ->forUser($user->id)
            ->active()
            ->with([
                'shift:id,client_id,service_context_id,starts_at,ends_at,shift_type,is_sleepover,is_on_call,expected_break_minutes,location',
                'shift.client:id,first_name,last_name',
                'shift.serviceContext:id,name',
            ])
            ->first(['id', 'clock_in', 'notes', 'shift_id']);

        $todayEntries = HrTimeEntry::query()
            ->forUser($user->id)
            ->where('entry_date', now()->toDateString())
            ->with(
                'shift:id,client_id,service_context_id,starts_at,ends_at,shift_type,is_sleepover,is_on_call,expected_break_minutes,location',
                'shift.client:id,first_name,last_name',
                'shift.serviceContext:id,name',
                'client:id,first_name,last_name'
            )
            ->orderBy('clock_in')
            ->get()
            ->map(fn ($entry) => [
                'id' => $entry->id,
                'entry_date' => $entry->entry_date->toDateString(),
                'clock_in' => $entry->clock_in->format('H:i'),
                'clock_out' => $entry->clock_out?->format('H:i'),
                'break_minutes' => $entry->break_minutes,
                'total_hours' => $entry->total_hours,
                'entry_type' => $entry->entry_type,
                'status' => $entry->status,
                'pay_type' => $entry->pay_type ?? 'standard',
                'notes' => $entry->notes,
                'shift' => $entry->shift ? [
                    'id' => $entry->shift->id,
                    'starts_at' => $entry->shift->starts_at?->format('H:i'),
                    'ends_at' => $entry->shift->ends_at?->format('H:i'),
                    'shift_type' => $entry->shift->shift_type ?? 'standard',
                    'is_sleepover' => (bool) $entry->shift->is_sleepover,
                    'is_on_call' => (bool) $entry->shift->is_on_call,
                    'expected_break_minutes' => $entry->shift->expected_break_minutes,
                    'location' => $entry->shift->location,
                    'service_context_name' => $entry->shift->serviceContext?->name,
                    'client_name' => trim(($entry->shift->client?->first_name ?? '').' '.($entry->shift->client?->last_name ?? '')),
                ] : null,
                'client_name' => $entry->client
                    ? trim(($entry->client->first_name ?? '').' '.($entry->client->last_name ?? ''))
                    : null,
            ]);

        $weeklySummary = $this->timeTrackingService->getWeeklySummary($user->id);

        // This week's roster (read-only from Operations) — 7 day columns.
        $weekStart = now()->startOfWeek();
        $weekEnd = now()->endOfWeek();
        $weekShifts = Shift::where('user_id', $user->id)
            ->visibleToFrontline()
            ->whereBetween('starts_at', [$weekStart, $weekEnd])
            ->with('client:id,first_name,last_name', 'serviceContext:id,name')
            ->orderBy('starts_at')
            ->get();

        $weekRoster = [];
        for ($i = 0; $i < 7; $i++) {
            $day = $weekStart->copy()->addDays($i);
            $dayShifts = $weekShifts
                ->filter(fn (Shift $s) => $s->starts_at && $s->starts_at->isSameDay($day))
                ->map(fn (Shift $s) => [
                    'id' => $s->id,
                    'service_context_id' => $s->service_context_id,
                    'site' => $s->serviceContext?->name ?? $s->location ?? 'Shift',
                    'client_name' => trim(($s->client?->first_name ?? '').' '.($s->client?->last_name ?? '')) ?: null,
                    'shift_type' => $s->shift_type ?? 'standard',
                    'time' => $s->starts_at->format('H:i').'–'.($s->ends_at?->format('H:i') ?? '—'),
                    'starts_at' => $s->starts_at->toIso8601String(),
                    'ends_at' => $s->ends_at?->toIso8601String(),
                ])
                ->values()
                ->all();

            $weekRoster[] = [
                'day' => $day->isoFormat('ddd'),
                'date' => $day->format('j'),
                'today' => $day->isSameDay(now()),
                'shifts' => $dayShifts,
            ];
        }

        // Upcoming shifts for the next 3 days
        $upcomingShifts = Shift::where('user_id', $user->id)
            ->visibleToFrontline()
            ->whereIn('status', ['draft', 'scheduled', 'in_progress'])
            ->where('starts_at', '>=', now())
            ->where('starts_at', '<=', now()->addDays(3))
            ->with('client:id,first_name,last_name', 'serviceContext:id,name')
            ->orderBy('starts_at')
            ->limit(10)
            ->get()
            ->map(fn ($shift) => [
                'id' => $shift->id,
                'starts_at' => $shift->starts_at?->format('Y-m-d H:i'),
                'ends_at' => $shift->ends_at?->format('Y-m-d H:i'),
                'shift_type' => $shift->shift_type ?? 'standard',
                'is_sleepover' => (bool) $shift->is_sleepover,
                'is_on_call' => (bool) $shift->is_on_call,
                'expected_break_minutes' => $shift->expected_break_minutes,
                'client_name' => trim(($shift->client?->first_name ?? '').' '.($shift->client?->last_name ?? '')),
                'location' => $shift->location,
                'service_context_name' => $shift->serviceContext?->name,
                'status' => $shift->status,
            ]);

        return Inertia::render('hr/my/time', [
            'myHr' => $this->myHrShellProps($user),
            'weekRoster' => $weekRoster,
            'activeClock' => $activeClock ? [
                'id' => $activeClock->id,
                'clock_in' => $activeClock->clock_in->format('Y-m-d H:i'),
                'notes' => $activeClock->notes,
                'shift' => $activeClock->shift ? [
                    'id' => $activeClock->shift->id,
                    'starts_at' => $activeClock->shift->starts_at?->format('H:i'),
                    'ends_at' => $activeClock->shift->ends_at?->format('H:i'),
                    'shift_type' => $activeClock->shift->shift_type ?? 'standard',
                    'is_sleepover' => (bool) $activeClock->shift->is_sleepover,
                    'is_on_call' => (bool) $activeClock->shift->is_on_call,
                    'expected_break_minutes' => $activeClock->shift->expected_break_minutes,
                    'location' => $activeClock->shift->location,
                    'service_context_name' => $activeClock->shift->serviceContext?->name,
                    'client_name' => trim(($activeClock->shift->client?->first_name ?? '').' '.($activeClock->shift->client?->last_name ?? '')),
                ] : null,
            ] : null,
            'todayEntries' => $todayEntries,
            'weeklySummary' => $weeklySummary,
            'upcomingShifts' => $upcomingShifts,
        ]);
    }

    public function clockIn(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $shift = $this->attendanceService->resolveSelfClockInShift(
            $user,
            $request->input('shift_id'),
        );

        $validated = $request->validate([
            'shift_id' => ['nullable', 'integer', 'min:1'],
            'notes' => ['nullable', 'string', 'max:500'],
        ]);
        $validated['shift_id'] = $shift?->id;

        // Guard against a second concurrent clock-in (which would leave two open
        // entries and a stuck "on shift" banner). One active clock at a time.
        $alreadyClockedIn = HrTimeEntry::query()
            ->forUser($user->id)
            ->active()
            ->exists();

        if ($alreadyClockedIn) {
            return redirect()->back()->with('error', 'You are already clocked in.');
        }

        try {
            $session = $this->attendanceService->clockIn($user, [
                'shift_id' => $validated['shift_id'] ?? null,
                'notes' => $validated['notes'] ?? null,
                'source' => 'self_service',
            ]);
        } catch (\LogicException $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }

        return redirect()->back()->with('success', 'Clocked in successfully.');
    }

    public function clockOut(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $validated = $request->validate([
            'break_minutes' => ['nullable', 'integer', 'min:0', 'max:240'],
            'mileage_km' => ['nullable', 'numeric', 'min:0', 'max:9999'],
            'notes' => ['nullable', 'string', 'max:500'],
        ]);

        $requestedBreak = (int) ($validated['break_minutes'] ?? 0);

        // Close the live attendance session if there is one (this also creates
        // the Operations timesheet). A stale/seeded time entry can be open with
        // no matching session — that's fine: we still close the time entry below
        // so the hero's live clock always clears (never a phantom "on shift").
        $session = null;
        $attendanceFailure = null;
        try {
            $session = $this->attendanceService->clockOut($user, null, [
                'break_minutes' => $requestedBreak,
                'notes' => $validated['notes'] ?? null,
                'mileage_km' => $validated['mileage_km'] ?? null,
            ]);
        } catch (AttendanceClockOutBlockedException $exception) {
            return redirect()->back()
                ->with('error', $exception->getMessage())
                ->with('clock_out_blockers', $exception->blockers());
        } catch (\LogicException $exception) {
            $attendanceFailure = $exception;
        }

        if ($session) {
            return redirect()->back()->with('success', 'Clocked out successfully.');
        }

        // Never turn an attendance projection/provenance failure into a direct
        // HrTimeEntry write. Only self-heal after an unlocked early check finds
        // no live session; closeOpenEntries repeats that check under the User
        // lock before touching a truly orphaned row.
        if (HrAttendanceSession::query()->where('user_id', $user->id)->open()->exists()) {
            return redirect()->back()->with(
                'error',
                $attendanceFailure?->getMessage() ?? 'The attendance session could not be clocked out.',
            );
        }

        try {
            $closed = $this->timeTrackingService->closeOpenEntries(
                $user,
                now(),
                $requestedBreak,
                $validated['mileage_km'] ?? null,
                $validated['notes'] ?? null,
            );
        } catch (\LogicException $exception) {
            return redirect()->back()->with('error', $exception->getMessage());
        }

        return $closed > 0
            ? redirect()->back()->with('success', 'Clocked out successfully.')
            : redirect()->back()->with('error', 'You are not currently clocked in.');
    }

    /** Download a single roster shift as a calendar (.ics) event. */
    public function shiftCalendar(Request $request, Shift $shift)
    {
        $user = $this->currentMyHrUser($request);
        $shift = Shift::query()
            ->visibleToFrontline()
            ->whereKey($shift->getKey())
            ->where('user_id', $user->id)
            ->firstOrFail();

        $start = $shift->starts_at?->copy()->utc();
        abort_unless($start, 404);
        $end = $shift->ends_at?->copy()->utc() ?? $start->copy()->addHours(8);

        $shift->loadMissing('serviceContext:id,name', 'client:id,first_name,last_name');
        $summary = $shift->serviceContext?->name ?? $shift->location ?? 'Shift';
        $client = trim(($shift->client?->first_name ?? '').' '.($shift->client?->last_name ?? ''));
        if ($client !== '') {
            $summary .= ' · '.$client;
        }
        $uid = 'shift-'.$shift->id.'@'.($request->getHost() ?: 'kauricare');
        $stamp = now()->utc()->format('Ymd\THis\Z');

        $lines = [
            'BEGIN:VCALENDAR',
            'VERSION:2.0',
            'PRODID:-//Kauri Care//My HR//EN',
            'BEGIN:VEVENT',
            'UID:'.$uid,
            'DTSTAMP:'.$stamp,
            'DTSTART:'.$start->format('Ymd\THis\Z'),
            'DTEND:'.$end->format('Ymd\THis\Z'),
            'SUMMARY:'.$this->icsEscape($summary),
        ];
        if ($shift->location) {
            $lines[] = 'LOCATION:'.$this->icsEscape($shift->location);
        }
        $lines[] = 'END:VEVENT';
        $lines[] = 'END:VCALENDAR';

        return response(implode("\r\n", $lines)."\r\n", 200, [
            'Content-Type' => 'text/calendar; charset=utf-8',
            'Content-Disposition' => 'attachment; filename="shift-'.$shift->id.'.ics"',
        ]);
    }

    private function icsEscape(string $value): string
    {
        return str_replace(
            ['\\', ';', ',', "\r\n", "\n"],
            ['\\\\', '\\;', '\\,', '\\n', '\\n'],
            $value,
        );
    }

    /* ------------------------------------------------------------------ */
    /*  1:1s (Supervision — employee self-service, Phase 1) */
    /* ------------------------------------------------------------------ */

    public function one(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        // Phase 1 surfaces the existing HrSupervisionNote (employee-visible only).
        // Phase 2 (first-class shared agenda / action-item tables w/ carry-forward
        // + shared-vs-private notes) is deferred pending confirmation.
        $notes = HrSupervisionNote::forEmployee($user->id)
            ->where('is_visible_to_employee', true)
            ->with('supervisor:id,name')
            ->orderByDesc('session_date')
            ->get();

        $sessions = $notes->map(fn (HrSupervisionNote $n) => [
            'id' => $n->id,
            'session_date' => $n->session_date?->toDateString(),
            'session_type' => $n->session_type,
            'duration_minutes' => $n->duration_minutes,
            'supervisor' => $n->supervisor ? [
                'id' => $n->supervisor->id,
                'name' => $n->supervisor->name,
            ] : null,
            'topics_discussed' => $n->topics_discussed,
            'actions_agreed' => array_values($n->actions_agreed ?? []),
            'employee_comments' => $n->employee_comments,
            'employee_acknowledged' => (bool) $n->employee_acknowledged,
            'employee_acknowledged_at' => $n->employee_acknowledged_at?->toIso8601String(),
            'next_session_date' => $n->next_session_date?->toDateString(),
        ])->values();

        // Open actions = unchecked action strings from notes not yet acknowledged.
        $openActions = $notes
            ->reject(fn (HrSupervisionNote $n) => $n->employee_acknowledged)
            ->flatMap(fn (HrSupervisionNote $n) => collect($n->actions_agreed ?? [])->map(fn ($a) => [
                'note_id' => $n->id,
                'label' => $a,
                'from' => $n->supervisor?->name,
                'session_date' => $n->session_date?->toDateString(),
            ]))
            ->values();

        // Next 1:1 = soonest future next_session_date, with the most recent supervisor.
        $nextDate = $notes
            ->pluck('next_session_date')
            ->filter(fn ($d) => $d && $d->isFuture())
            ->sort()
            ->first();

        $next = $nextDate ? [
            'date' => $nextDate->toDateString(),
            'who' => $notes->firstWhere('next_session_date', $nextDate)?->supervisor?->name
                ?? $notes->first()?->supervisor?->name,
            'days_until' => (int) ceil(now()->startOfDay()->diffInDays($nextDate->startOfDay(), false)),
        ] : null;

        return Inertia::render('hr/my/one', [
            'myHr' => $this->myHrShellProps($user),
            'sessions' => $sessions,
            'openActions' => $openActions,
            'next' => $next,
        ]);
    }

    public function documents(Request $request)
    {
        $user = $this->currentMyHrUser($request);

        $profile = HrEmployeeProfile::where('user_id', $user->id)
            ->first();

        abort_unless($profile, 404, 'Employee profile not found.');

        $documents = HrDocument::where('employee_profile_id', $profile->id)
            ->where('is_restricted', false)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn ($d) => [
                'id' => $d->id,
                'title' => $d->title,
                'category' => $d->category,
                'folder' => $d->folder ?? null,
                'original_name' => $d->original_name,
                'mime_type' => $d->mime_type,
                'size_bytes' => $d->size_bytes,
                'expires_at' => $d->expires_at?->toDateString(),
                'signed_by_employee' => (bool) $d->signed_by_employee,
                'created_at' => $d->created_at?->toIso8601String(),
            ]);

        // Documents awaiting this employee's e-signature (reuses ESignature flow).
        $pendingSignatures = $this->signatureService
            ->getPendingForUser($user)
            ->map(fn (HrDocumentSignature $s) => [
                'id' => $s->id,
                'document_title' => $s->document?->title ?? 'Document',
                'document_category' => $s->document?->category,
                'requested_by' => $s->requestedBy?->name ?? 'HR team',
                'requested_at' => $s->requested_at?->toIso8601String(),
                'download_url' => route('hr.signatures.document', $s),
            ])
            ->values();

        return Inertia::render('hr/my/documents', [
            'myHr' => $this->myHrShellProps($user),
            'pendingSignatures' => $pendingSignatures,
            'documents' => $documents,
            'categories' => ['contract', 'letter', 'policy', 'certificate', 'offer', 'other'],
        ]);
    }

    /** Sign a document awaiting this employee's signature (self-service path that
     *  reuses the shared ESignatureService and stays on the My HR documents page). */
    public function signDocument(Request $request, HrDocumentSignature $signature)
    {
        $user = $this->currentMyHrUser($request);
        $signature = HrDocumentSignature::query()
            ->whereKey($signature->getKey())
            ->where('signer_user_id', $user->id)
            ->firstOrFail();
        $document = $this->documentAccess->siteDocument($user, (int) $signature->document_id);
        $signature->setRelation('document', $document);

        $validated = $request->validate([
            'signature_data' => ['required', 'string', 'max:255'],
        ]);

        try {
            $this->signatureService->sign($signature, $validated['signature_data'], $request);
        } catch (\LogicException $e) {
            return redirect()->back()->with('error', $e->getMessage());
        }

        return redirect()->back()->with('success', 'Document signed & filed.');
    }

    public function downloadDocument(Request $request, HrDocument $document)
    {
        $user = $this->currentMyHrUser($request);

        $document = $this->documentAccess->siteDocument($user, $document);
        $profileId = HrEmployeeProfile::query()->where('user_id', $user->id)->value('id');
        abort_unless($profileId && (int) $document->employee_profile_id === (int) $profileId, 404);
        abort_if($document->is_restricted && ! $user->canDo('hr.documents.manage'), 404);

        abort_unless(
            Storage::disk($document->storage_disk)->exists($document->storage_path),
            404,
            'Document file is missing from storage.',
        );

        $filename = $document->original_name ?: basename($document->storage_path);

        return Storage::disk($document->storage_disk)->download($document->storage_path, $filename);
    }

    /**
     * Month feed for the hero footer calendar. The shell seeds the current month
     * on first paint; this lets the popover page to other months on demand. Same
     * shape ({ month, events }) the shell uses, built by the shared trait.
     */
    public function calendar(Request $request): JsonResponse
    {
        $user = $this->currentMyHrUser($request);

        $monthParam = (string) $request->query('month', now()->format('Y-m'));

        try {
            $anchor = Carbon::createFromFormat('Y-m', $monthParam);
        } catch (\Throwable) {
            $anchor = null;
        }

        return response()->json(
            $this->myHrCalendarFeed($user, ($anchor ?: now())->startOfMonth()),
        );
    }
}
