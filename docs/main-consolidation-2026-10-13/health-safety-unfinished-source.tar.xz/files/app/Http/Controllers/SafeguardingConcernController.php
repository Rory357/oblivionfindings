<?php

namespace App\Http\Controllers;

use App\Domain\Governance\Services\GovernanceAuditService;
use App\Models\Client;
use App\Models\ClientIncident;
use App\Models\HsEvent;
use App\Models\SafeguardingActionPlan;
use App\Models\SafeguardingAttachment;
use App\Models\SafeguardingConcern;
use App\Models\SafeguardingDeclassificationReview;
use App\Models\SafeguardingExternalReport;
use App\Models\SafeguardingInvestigation;
use App\Models\Site;
use App\Models\User;
use App\Policies\SafeguardingConcernPolicy;
use App\Services\Safeguarding\SafeguardingLifecycle;
use App\Services\Safeguarding\SafeguardingSensitivityService;
use App\Services\Safeguarding\SafeguardingTerminalTransitionService;
use App\Services\UserSiteAccessService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class SafeguardingConcernController extends Controller
{
    public function __construct(
        private readonly SafeguardingSensitivityService $sensitivity,
        private readonly SafeguardingConcernPolicy $concernPolicy,
        private readonly UserSiteAccessService $siteAccess,
    ) {}

    /**
     * Display a listing of safeguarding concerns.
     */
    public function index(Request $request): Response
    {
        $this->authorize('viewAny', SafeguardingConcern::class);

        $user = $request->user();
        $canSensitive = $user->can('viewSensitive', SafeguardingConcern::class);

        $tab = (string) $request->get('tab', 'all');
        $filters = [
            'q' => $request->get('q') ?: null,
            'tab' => $tab,
            'severity' => $request->get('severity') ?: null,
            'category' => $request->get('category') ?: null,
            'site_id' => $request->integer('site_id') ?: null,
            'subject_id' => $request->integer('subject_id') ?: null,
            'from' => $request->get('from') ?: null,
            'to' => $request->get('to') ?: null,
        ];

        // Footer filters applied to any concern query; tab scope is layered on top.
        $applyFilters = function ($q) use ($filters) {
            if ($filters['severity']) {
                $q->where('severity', $filters['severity']);
            }
            if ($filters['category']) {
                $q->where('abuse_category', $filters['category']);
            }
            if ($filters['site_id']) {
                $q->where('site_id', $filters['site_id']);
            }
            if ($filters['subject_id']) {
                $q->where('subject_type', Client::class)->where('subject_id', $filters['subject_id']);
            }
            if ($filters['from']) {
                $q->whereDate('reported_at', '>=', $filters['from']);
            }
            if ($filters['to']) {
                $q->whereDate('reported_at', '<=', $filters['to']);
            }
            if ($filters['q']) {
                $term = $filters['q'];
                $q->where(function ($w) use ($term) {
                    $w->where('reference_number', 'like', "%{$term}%")
                        ->orWhere('description', 'like', "%{$term}%")
                        ->orWhere('subject_name', 'like', "%{$term}%");
                });
            }
        };

        $tabScopes = [
            'all' => fn ($q) => $q,
            'open' => fn ($q) => $q->open(),
            'triage' => fn ($q) => $q->where('status', 'reported'),
            'investigation' => fn ($q) => $q->where('status', 'investigating'),
            'action_plan' => fn ($q) => $q->where('status', 'action_plan'),
            'monitoring' => fn ($q) => $q->where('status', 'monitoring'),
            'referrals' => fn ($q) => $q->where(fn ($w) => $w->where('requires_external_referral', true)->orHas('externalReports')),
            'closed' => fn ($q) => $q->whereIn('status', SafeguardingConcern::TERMINAL_STATUSES),
            'mine' => fn ($q) => $q->where('assigned_to_user_id', $user->id)->whereNotIn('status', SafeguardingConcern::TERMINAL_STATUSES),
        ];

        $tabCounts = [];
        foreach ($tabScopes as $key => $scope) {
            $q = SafeguardingConcern::query();
            $applyFilters($q);
            $scope($q);
            $tabCounts[$key] = $q->count();
        }

        // Reviews worklist source (footer-filtered, non-terminal).
        $reviewBase = SafeguardingConcern::query()->whereNotIn('status', SafeguardingConcern::TERMINAL_STATUSES);
        $applyFilters($reviewBase);
        $reviewConcernIds = $reviewBase->pluck('id');
        $tabCounts['reviews'] = $this->riskReviewQuery($reviewConcernIds)->count()
            + $this->acksAwaitedQuery($reviewConcernIds)->count();

        if ($tab === 'reviews') {
            $rows = $this->reviewWorklist($reviewConcernIds, $user, $canSensitive);
            $rowsKind = 'reviews';
        } else {
            $scope = $tabScopes[$tab] ?? $tabScopes['all'];
            $query = SafeguardingConcern::query()
                ->with(['subject', 'assignedTo', 'site', 'latestRiskAssessment', 'relatedIncident:id,reference_number'])
                ->withCount([
                    'externalReports',
                    'attachments',
                    'alerts as active_alerts_count' => fn ($q) => $q->where('active', true),
                    'actionPlans as overdue_actions_count' => fn ($q) => $q->where('due_date', '<', now())->whereNotIn('status', ['completed', 'cancelled']),
                ]);
            $applyFilters($query);
            $scope($query);
            $query->orderByDesc('reported_at');

            $paginated = $query->paginate(20)->withQueryString();
            $paginated->getCollection()->transform(fn (SafeguardingConcern $c) => $this->mapConcernRow($c, $user, $canSensitive));
            $rows = $paginated;
            $rowsKind = 'concerns';
        }

        return Inertia::render('safeguarding/index', [
            'filters' => $filters,
            'tab' => $tab,
            'tabCounts' => $tabCounts,
            'rows' => $rows,
            'rowsKind' => $rowsKind,
            'hero' => [
                'openWork' => [
                    'open' => ['value' => SafeguardingConcern::open()->count()],
                    'awaitingTriage' => ['value' => SafeguardingConcern::where('status', 'reported')->count()],
                    'investigating' => ['value' => SafeguardingConcern::where('status', 'investigating')->count()],
                    'referred' => ['value' => SafeguardingConcern::where('status', 'referred_external')->count()],
                ],
                'attention' => [
                    'overdueActions' => ['value' => $this->overdueActionsCount()],
                    'reviewsDue' => ['value' => $this->riskReviewQuery($this->openConcernIds())->count()],
                    'acksAwaited' => ['value' => $this->acksAwaitedQuery($this->openConcernIds())->count()],
                    'criticalOpen' => ['value' => SafeguardingConcern::open()->where('severity', 'critical')->count()],
                ],
            ],
            'referralOverdueCount' => SafeguardingConcern::query()
                ->where('requires_external_referral', true)
                ->whereDoesntHave('externalReports')
                ->whereNotIn('status', SafeguardingConcern::TERMINAL_STATUSES)
                ->count(),
            'sites' => Site::query()->where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'subjects' => Client::query()->orderBy('last_name')->orderBy('first_name')->get(['id', 'first_name', 'last_name'])
                ->map(fn (Client $c) => ['id' => $c->id, 'name' => trim($c->first_name.' '.$c->last_name)])
                ->values(),
            'staff' => User::staff()->select('id', 'name')->orderBy('name')->get()
                ->map(fn (User $u) => ['id' => $u->id, 'name' => $u->name])->values(),
            'raise' => $request->boolean('raise'),
            'can' => ['create' => $user->can('create', SafeguardingConcern::class)],
            // Detail-over-list: only fetched (and only authorised) when ?concern={id} is present.
            'detail' => $this->resolveDetail($request, $user, $canSensitive),
        ]);
    }

    /**
     * Serialize a concern for the detail modal when ?concern={id} is present and
     * the viewer is authorised; otherwise null (the dialog stays closed).
     */
    private function resolveDetail(Request $request, User $user, bool $canSensitive): ?array
    {
        $concernId = $request->integer('concern');
        if (! $concernId) {
            return null;
        }

        $concern = SafeguardingConcern::query()->find($concernId);
        if (! $concern || ! $user->can('view', $concern)) {
            return null;
        }

        return $this->buildConcernDetail($concern, $user, $canSensitive);
    }

    /**
     * Show the form for creating a new concern.
     */
    public function create(Request $request): Response
    {
        $this->authorize('create', SafeguardingConcern::class);

        // Reporting authority does not imply permission to browse the register.
        // The intake page contains only the choices the reporter may use.
        $user = $request->user();

        return Inertia::render('safeguarding/create', [
            'clients' => $this->siteAccess->applyClientScope(Client::query(), $user)
                ->orderBy('last_name')->orderBy('first_name')->get(['id', 'first_name', 'last_name'])
                ->map(fn (Client $client) => ['id' => $client->id, 'name' => trim($client->first_name.' '.$client->last_name)])
                ->values(),
            'staff' => $this->siteAccess->applyStaffScope(User::query(), $user)
                ->orderBy('name')->get(['id', 'name']),
            'sites' => $this->siteAccess->applySiteScope(Site::query(), $user)
                ->where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'returnUrl' => $this->reportingReturnUrl($request),
        ]);
    }

    /** Keep the permitted caller's filters, never an external or nested return. */
    private function reportingReturnUrl(Request $request): string
    {
        $allowed = ['/my-day'];
        if ($request->user()->canDo('incidents.viewAny') || $request->user()->canDo('incidents.viewAssigned')) {
            $allowed[] = '/incidents';
        }
        if ($request->user()->canDo('safeguarding.viewAny')) {
            $allowed[] = '/safeguarding';
        }
        $fallback = end($allowed);
        $value = $request->input('return_to');
        if (! is_string($value) || ! str_starts_with($value, '/') || str_starts_with($value, '//')
            || str_contains($value, '\\') || preg_match('/[\x00-\x1f\x7f]/', $value)) {
            return $fallback;
        }
        $parts = parse_url($value);
        if (! is_array($parts) || isset($parts['host']) || ! in_array($parts['path'] ?? '', $allowed, true)) {
            return $fallback;
        }
        parse_str($parts['query'] ?? '', $query);
        $query = array_filter(Arr::only($query, [
            'q', 'tab', 'severity', 'category', 'site_id', 'client_id', 'subject_id', 'source', 'from', 'to', 'page',
        ]), fn ($item) => is_scalar($item));
        $encoded = http_build_query($query, '', '&', PHP_QUERY_RFC3986);

        return $parts['path'].($encoded !== '' ? '?'.$encoded : '');
    }

    /**
     * Store a newly created concern.
     */
    public function store(Request $request): RedirectResponse
    {
        $this->authorize('create', SafeguardingConcern::class);

        $validated = $request->validate([
            'subject_type' => 'nullable|in:client,staff,other',
            'subject_id' => 'nullable|integer',
            'subject_name' => 'nullable|string|max:255',
            'concern_type' => 'required|string',
            'abuse_category' => 'nullable|string',
            'severity' => 'required|in:low,medium,high,critical',
            'description' => 'required|string',
            'occurred_at' => 'nullable|date',
            'location' => 'nullable|string',
            'alleged_perpetrator_type' => 'nullable|in:client,staff,family,other',
            'alleged_perpetrator_id' => 'nullable|integer',
            'alleged_perpetrator_name' => 'nullable|string|max:255',
            'alleged_perpetrator_details' => 'nullable|string',
            'reporter_notes' => 'nullable|string',
            'witnesses' => 'nullable',
            'immediate_actions' => 'nullable|string',
            'requires_external_referral' => 'boolean',
            // Need-to-know: a raiser can mark an allegation sensitive so it is redacted
            // to everyone but the lead, the reporter and viewSensitive-cleared staff.
            'is_sensitive' => 'boolean',
            'site_id' => 'nullable|exists:sites,id',
            'related_incident_id' => 'nullable|exists:client_incidents,id',
        ]);

        $validated = $this->normalizeConcernInput($request, $validated);
        $this->reconcileCanonicalIntakeScope($request, $validated);
        $validated['is_sensitive'] = $request->boolean('is_sensitive');

        $validated['reported_by_user_id'] = auth()->id();
        $validated['reported_at'] = now();
        $validated['created_by'] = auth()->id();
        // W1: every concern starts in the explicit 'reported' (awaiting triage) stage,
        // rather than relying on the DB column default.
        $validated['status'] = 'reported';

        $concern = SafeguardingConcern::create($validated);

        // back() so the raise wizard can show its success pane (preserveState) and
        // the list refreshes in place; created_concern_id powers "Open concern".
        return back()
            ->with('success', 'Safeguarding concern raised — reference '.$concern->reference_number.'.')
            ->with('created_concern_id', $concern->id);
    }

    /**
     * Display the specified concern.
     */
    /**
     * Thin deep-link shell for /safeguarding/{id} — renders the same
     * SafeguardingConcernDialog content as the list's detail-over-list modal.
     * Stays accessible to reporters/assignees without global viewAny (policy).
     */
    public function show(Request $request, SafeguardingConcern $concern): Response
    {
        $this->authorize('view', $concern);

        $canSensitive = $request->user()->can('viewSensitive', SafeguardingConcern::class);

        return Inertia::render('safeguarding/concern', [
            'detail' => $this->buildConcernDetail($concern, $request->user(), $canSensitive),
            'returnUrl' => $this->reportingReturnUrl($request),
        ]);
    }

    /**
     * Show the form for editing the concern.
     */
    /**
     * The full-page edit form is retired — concern fields are maintained through
     * the detail modal's action panes. Redirect deep links to the concern.
     */
    public function edit(SafeguardingConcern $concern): RedirectResponse
    {
        $this->authorize('update', $concern);

        return redirect()->route('safeguarding.show', $concern);
    }

    /**
     * Update the specified concern.
     */
    public function update(Request $request, SafeguardingConcern $concern): RedirectResponse
    {
        $this->authorize('update', $concern);

        $validated = $request->validate([
            'subject_type' => 'nullable|in:client,staff,other',
            'subject_id' => 'nullable|integer',
            'subject_name' => 'nullable|string|max:255',
            'concern_type' => 'required|string',
            'abuse_category' => 'nullable|string',
            'severity' => 'required|in:low,medium,high,critical',
            'description' => 'required|string',
            'occurred_at' => 'nullable|date',
            'location' => 'nullable|string',
            'alleged_perpetrator_type' => 'nullable|in:client,staff,family,other',
            'alleged_perpetrator_id' => 'nullable|integer',
            'alleged_perpetrator_name' => 'nullable|string|max:255',
            'alleged_perpetrator_details' => 'nullable|string',
            'witnesses' => 'nullable',
            'immediate_actions' => 'nullable|string',
            'requires_external_referral' => 'boolean',
            'protective_measures' => 'nullable|string',
            'site_id' => 'nullable|exists:sites,id',
        ]);

        $validated = $this->normalizeConcernInput($request, $validated);
        $this->reconcileCanonicalIntakeScope($request, $validated, $concern);

        $validated['updated_by'] = auth()->id();

        $concern->update($validated);

        return redirect()
            ->route('safeguarding.show', $concern)
            ->with('success', 'Safeguarding concern updated successfully.');
    }

    /**
     * Assign concern to a user.
     */
    public function assign(Request $request, SafeguardingConcern $concern): RedirectResponse
    {
        $this->authorize('update', $concern);

        $request->validate([
            'assigned_to_user_id' => 'required|exists:users,id',
        ]);

        $concern->update([
            'assigned_to_user_id' => $request->assigned_to_user_id,
            'assigned_at' => now(),
            'updated_by' => auth()->id(),
        ]);

        return back()->with('success', 'Concern assigned successfully.');
    }

    /**
     * Update concern status.
     */
    public function updateStatus(Request $request, SafeguardingConcern $concern, SafeguardingLifecycle $lifecycle): RedirectResponse
    {
        $this->authorize('update', $concern);

        $validated = $request->validate([
            'status' => 'required|in:reported,triaged,investigating,action_plan,monitoring,closed,referred_external,no_action_required',
        ]);

        // Enforce the §4 state machine (W3/W6 + legal transitions). Closing and
        // leaving `reported` have their own actions (close / triage).
        $guard = $lifecycle->guardTransition($concern, $validated['status']);

        if (! $guard['allowed']) {
            return back()->withErrors(['status' => $guard['reason']]);
        }

        $concern->update([
            'status' => $validated['status'],
            'updated_by' => auth()->id(),
        ]);

        return back()->with('success', 'Status updated to '.$lifecycle->label($validated['status']).'.');
    }

    /**
     * Triage a reported concern (W4): record substantiation + initial risk +
     * lead, then act on the chosen path — investigate (opens an investigation
     * record automatically → `investigating`), refer (flags the concern for an
     * external referral, awaiting the report → stays `triaged`), or no further
     * action (`no_action_required`, terminal, rationale required).
     */
    public function triage(
        Request $request,
        SafeguardingConcern $concern,
        SafeguardingTerminalTransitionService $terminalTransitions,
    ): RedirectResponse {
        $this->authorize('update', $concern);

        if ($concern->status !== 'reported') {
            return back()->withErrors(['triage' => 'This concern has already been triaged.']);
        }

        $validated = $request->validate([
            'substantiation' => 'required|in:'.implode(',', SafeguardingLifecycle::SUBSTANTIATIONS),
            'initial_risk' => 'required|in:low,medium,high,critical',
            'lead_user_id' => 'nullable|exists:users,id',
            'path' => 'required|in:'.implode(',', SafeguardingLifecycle::TRIAGE_PATHS),
            'notes' => 'nullable|string',
            // For the "investigate" path we may capture an investigation type up front.
            'investigation_type' => 'nullable|string',
        ]);

        // "No further action" must carry a rationale.
        if ($validated['path'] === 'no_action' && blank($validated['notes'] ?? null)) {
            return back()->withErrors(['notes' => 'Record why no further action is required.']);
        }

        $attributes = [
            'triaged_at' => now(),
            'triaged_by_user_id' => auth()->id(),
            'triage_substantiation' => $validated['substantiation'],
            'triage_decision' => $validated['path'],
            'triage_notes' => $validated['notes'] ?? null,
            'current_risk_level' => $validated['initial_risk'],
            'updated_by' => auth()->id(),
        ];

        if (! empty($validated['lead_user_id'])) {
            $attributes['assigned_to_user_id'] = $validated['lead_user_id'];
            $attributes['assigned_at'] = now();
        }

        $message = 'Concern triaged.';

        switch ($validated['path']) {
            case 'investigate':
                // Opening the investigation record is what satisfies the W3 gate
                // for entering the `investigating` stage.
                SafeguardingInvestigation::create([
                    'safeguarding_concern_id' => $concern->id,
                    'investigation_type' => $validated['investigation_type'] ?? 'internal',
                    'lead_investigator_id' => $validated['lead_user_id'] ?? auth()->id(),
                    'started_at' => now(),
                    'status' => 'planned',
                    'created_by' => auth()->id(),
                ]);
                $attributes['status'] = 'investigating';
                $message = 'Concern triaged — investigation opened.';
                break;

            case 'refer':
                // Referral indicated; the concern waits at `triaged` until an
                // external report is logged (W6), which advances it to referred.
                $attributes['requires_external_referral'] = true;
                $attributes['status'] = 'triaged';
                $message = 'Concern triaged — log the external referral to continue.';
                break;

            case 'no_action':
                $attributes['status'] = 'no_action_required';
                $message = 'Concern triaged — no further safeguarding action required.';
                break;
        }

        if ($validated['path'] === 'no_action') {
            try {
                $terminalTransitions->noAction($concern, $request->user(), $attributes);
            } catch (\DomainException $exception) {
                return back()->withErrors(['triage' => $exception->getMessage()]);
            }
        } else {
            $concern->update($attributes);
        }

        return back()->with('success', $message);
    }

    /**
     * Close the concern.
     */
    public function close(
        Request $request,
        SafeguardingConcern $concern,
        SafeguardingTerminalTransitionService $terminalTransitions,
    ): RedirectResponse {
        $validated = $request->validate([
            'closure_summary' => 'required|string',
            'lessons_learned' => 'nullable|string',
            'override_reason' => 'nullable|string',
        ]);

        try {
            $terminalTransitions->close(
                $concern,
                $request->user(),
                $validated['closure_summary'],
                $validated['lessons_learned'] ?? null,
                $validated['override_reason'] ?? null,
            );
        } catch (\DomainException $exception) {
            return back()->withErrors(['close' => $exception->getMessage()]);
        }

        return back()->with('success', 'Concern closed.');
    }

    /**
     * Mark subject as informed.
     */
    public function markSubjectInformed(SafeguardingConcern $concern): RedirectResponse
    {
        $this->authorize('update', $concern);

        $concern->update([
            'subject_informed' => true,
            'subject_informed_at' => now(),
            'updated_by' => auth()->id(),
        ]);

        return back()->with('success', 'Subject marked as informed.');
    }

    /** Mark a concern need-to-know. Removal uses the governed review workflow. */
    public function setSensitivity(Request $request, SafeguardingConcern $concern): RedirectResponse
    {
        $this->concealForeignConcern($request->user(), $concern);
        $this->authorize('update', $concern);

        $validated = $request->validate(['is_sensitive' => 'required|boolean']);
        if (! $validated['is_sensitive']) {
            throw ValidationException::withMessages([
                'is_sensitive' => ['Removing need-to-know requires a recorded declassification request and independent approval.'],
            ]);
        }

        $this->sensitivity->markSensitive($concern, $request->user());

        return back()->with('success', 'Concern restricted to need-to-know.');
    }

    public function requestDeclassification(Request $request, SafeguardingConcern $concern): RedirectResponse
    {
        $this->concealForeignConcern($request->user(), $concern);
        $this->authorize('requestDeclassification', $concern);

        $validated = $request->validate([
            'reason' => 'required|string|min:20|max:2000',
            'audience_acknowledged' => 'accepted',
            'audience_preview_hash' => ['required', 'string', 'regex:/^[a-f0-9]{64}$/'],
            'expected_sensitivity_version' => 'required|integer|min:0',
            'idempotency_key' => 'required|uuid',
        ]);

        $this->sensitivity->requestDeclassification(
            $concern,
            $request->user(),
            $validated['reason'],
            $validated['audience_preview_hash'],
            (int) $validated['expected_sensitivity_version'],
            $validated['idempotency_key'],
        );

        return back()->with('success', 'Declassification request sent for independent review.');
    }

    public function approveDeclassification(
        Request $request,
        SafeguardingConcern $concern,
        string $declassificationReview,
    ): RedirectResponse {
        $this->concealForeignConcern($request->user(), $concern);
        $this->authorize('approveDeclassification', $concern);
        $review = $this->nestedDeclassificationReview($concern, $declassificationReview);

        $validated = $request->validate([
            'decision_reason' => 'required|string|min:10|max:2000',
            'idempotency_key' => 'required|uuid',
        ]);

        $this->sensitivity->approve(
            $concern,
            $review,
            $request->user(),
            $validated['decision_reason'],
            $validated['idempotency_key'],
        );

        return back()->with('success', 'Need-to-know restriction removed after independent review.');
    }

    public function rejectDeclassification(
        Request $request,
        SafeguardingConcern $concern,
        string $declassificationReview,
    ): RedirectResponse {
        $this->concealForeignConcern($request->user(), $concern);
        $this->authorize('approveDeclassification', $concern);
        $review = $this->nestedDeclassificationReview($concern, $declassificationReview);

        $validated = $request->validate([
            'decision_reason' => 'required|string|min:10|max:2000',
            'idempotency_key' => 'required|uuid',
        ]);

        $this->sensitivity->reject(
            $concern,
            $review,
            $request->user(),
            $validated['decision_reason'],
            $validated['idempotency_key'],
        );

        return back()->with('success', 'Declassification request declined.');
    }

    /* ------------------------------------------------------------------ */
    /*  Index helpers (rows, redaction, worklist, counts) */
    /* ------------------------------------------------------------------ */

    /**
     * Need-to-know: a sensitive concern is restricted for a viewer who lacks
     * `viewSensitive` and is neither the assignee nor the reporter.
     */
    private function isConcernRestricted(SafeguardingConcern $concern, User $user, bool $canSensitive): bool
    {
        if (! $concern->is_sensitive
            || $canSensitive
            || $user->can('approveDeclassification', $concern)) {
            return false;
        }

        return $concern->assigned_to_user_id !== $user->id
            && $concern->reported_by_user_id !== $user->id;
    }

    private function subjectDisplayName(SafeguardingConcern $concern): ?string
    {
        $subject = $concern->subject;

        if ($subject instanceof Client) {
            return trim($subject->first_name.' '.$subject->last_name) ?: null;
        }
        if ($subject instanceof User) {
            return $subject->name;
        }

        return $concern->subject_name;
    }

    private function mapConcernRow(SafeguardingConcern $concern, User $user, bool $canSensitive): array
    {
        $restricted = $this->isConcernRestricted($concern, $user, $canSensitive);
        $review = $concern->latestRiskAssessment;
        $reviewDue = $review && $review->next_review_date && $review->next_review_date->isPast();

        return [
            'id' => $concern->id,
            'reference_number' => $concern->reference_number,
            'occurred_at' => $concern->occurred_at?->toISOString(),
            'reported_at' => $concern->reported_at?->toISOString(),
            'concern_type' => $concern->concern_type,
            'abuse_category' => $restricted ? null : $concern->abuse_category,
            'description' => $restricted ? null : Str::limit((string) $concern->description, 120),
            'severity' => $concern->severity,
            'status' => $concern->status,
            'current_risk_level' => $concern->current_risk_level,
            'restricted' => $restricted,
            'attachments_count' => (int) ($concern->attachments_count ?? 0),
            'subject' => $restricted ? null : [
                'name' => $this->subjectDisplayName($concern),
                'site' => $concern->site?->name,
                'href' => $this->subjectHref($concern),
            ],
            'subject_informed' => (bool) $concern->subject_informed,
            'assigned_to' => $concern->assignedTo ? ['name' => $concern->assignedTo->name] : null,
            'flags' => [
                'has_alert' => ($concern->active_alerts_count ?? 0) > 0,
                'requires_referral' => (bool) $concern->requires_external_referral,
                'referral_overdue' => $concern->requires_external_referral
                    && ($concern->external_reports_count ?? 0) === 0
                    && ! in_array($concern->status, SafeguardingConcern::TERMINAL_STATUSES, true),
                'review_due' => (bool) $reviewDue,
                'action_overdue' => ($concern->overdue_actions_count ?? 0) > 0,
            ],
            'related_incident_id' => $concern->related_incident_id,
            'related_incident_ref' => $concern->relatedIncident?->reference_number,
            // The active Control Room alert id is resolved (via the linked HsEvent) on the
            // detail payload only — see buildConcernDetail — to keep the list free of a
            // per-row HsEvent lookup. The row context menu jumps to it via the detail.
            'control_room_alert_id' => null,
            // Lifecycle gates for the row's right-click menu, mirroring the detail Options bar.
            'can' => [
                'update' => $user->can('update', $concern),
                'investigate' => $user->can('investigate', $concern),
                'report_external' => $user->can('reportExternal', $concern),
            ],
        ];
    }

    /** Deep-link to a Client subject's profile (no `/care` — that route 302-redirects). */
    private function subjectHref(SafeguardingConcern $concern): ?string
    {
        $subject = $concern->subject;

        return $subject instanceof Client ? "/operations/clients/{$subject->id}" : null;
    }

    /**
     * Recent "accessed by" entries for the need-to-know access log — the read trail
     * recorded by {@see GovernanceAuditService::log('viewed', …)} above. Only ever
     * built for a non-restricted detail payload, so it is itself need-to-know aware.
     *
     * @return array<int, array{by: string, at: ?string}>
     */
    private function recentAccessLog(SafeguardingConcern $concern): array
    {
        if (! Schema::hasTable('governance_audit_log')) {
            return [];
        }

        return DB::table('governance_audit_log as a')
            ->leftJoin('users as u', 'u.id', '=', 'a.user_id')
            ->where('a.resource_type', SafeguardingConcern::class)
            ->where('a.resource_id', $concern->getKey())
            ->where('a.action', 'viewed')
            ->orderByDesc('a.created_at')
            ->limit(8)
            ->get(['u.name as by', 'a.created_at as at'])
            ->map(fn ($row) => [
                'by' => $row->by ?? 'Unknown user',
                'at' => $row->at ? Carbon::parse($row->at)->toISOString() : null,
            ])
            ->all();
    }

    /** Non-terminal concern ids — the universe for "needs attention" worklists. */
    private function openConcernIds()
    {
        return SafeguardingConcern::query()
            ->whereNotIn('status', SafeguardingConcern::TERMINAL_STATUSES)
            ->pluck('id');
    }

    /** Concerns (within $ids) whose risk review is due/overdue. */
    private function riskReviewQuery($concernIds)
    {
        return SafeguardingConcern::query()
            ->whereIn('id', $concernIds)
            ->whereHas('riskAssessments', fn ($q) => $q->whereNotNull('next_review_date')->where('next_review_date', '<=', now()));
    }

    /** External reports (for concerns within $ids) still awaiting acknowledgement. */
    private function acksAwaitedQuery($concernIds)
    {
        return SafeguardingExternalReport::query()
            ->where('acknowledgement_received', false)
            ->whereIn('safeguarding_concern_id', $concernIds);
    }

    private function overdueActionsCount(): int
    {
        return SafeguardingActionPlan::query()
            ->where('due_date', '<', now())
            ->whereNotIn('status', ['completed', 'cancelled'])
            ->whereIn('safeguarding_concern_id', $this->openConcernIds())
            ->count();
    }

    /**
     * The Reviews-due worklist: risk reviews due + external-report acknowledgements
     * awaited, each redaction-aware, shaped like a (single-page) paginator.
     */
    private function reviewWorklist($concernIds, User $user, bool $canSensitive): array
    {
        $riskItems = $this->riskReviewQuery($concernIds)
            ->with(['subject', 'assignedTo', 'riskAssessments' => fn ($q) => $q->whereNotNull('next_review_date')->orderBy('next_review_date')])
            ->get()
            ->map(function (SafeguardingConcern $c) use ($user, $canSensitive) {
                $review = $c->riskAssessments->first();
                $restricted = $this->isConcernRestricted($c, $user, $canSensitive);

                return [
                    'id' => $c->id,
                    'reference_number' => $c->reference_number,
                    'restricted' => $restricted,
                    'subject' => $restricted ? null : $this->subjectDisplayName($c),
                    'owner' => $c->assignedTo?->name,
                    'kind' => 'risk',
                    'detail' => 'Risk review',
                    'open_section' => 'risk',
                    'due_at' => $review?->next_review_date?->toISOString(),
                    'overdue' => (bool) ($review && $review->next_review_date && $review->next_review_date->isPast()),
                ];
            });

        $ackItems = $this->acksAwaitedQuery($concernIds)
            ->with(['concern.subject', 'concern.assignedTo'])
            ->get()
            ->map(function (SafeguardingExternalReport $r) use ($user, $canSensitive) {
                $c = $r->concern;
                if (! $c) {
                    return null;
                }
                $restricted = $this->isConcernRestricted($c, $user, $canSensitive);

                return [
                    'id' => $c->id,
                    'reference_number' => $c->reference_number,
                    'restricted' => $restricted,
                    'subject' => $restricted ? null : $this->subjectDisplayName($c),
                    'owner' => $c->assignedTo?->name,
                    'kind' => 'ack',
                    'detail' => 'Acknowledgement awaited · '.$r->authority_name,
                    'open_section' => 'reports',
                    'due_at' => $r->reported_at?->toISOString(),
                    'overdue' => (bool) ($r->reported_at && $r->reported_at->lt(now()->subDays(7))),
                ];
            })
            ->filter()
            ->values();

        return [
            'data' => $riskItems->concat($ackItems)->values()->all(),
            'links' => [],
            'last_page' => 1,
        ];
    }

    /** Stage tracker index per status (referred_external parallels investigating; no_action parallels triaged). */
    private const STAGE_INDEX = [
        'reported' => 0,
        'triaged' => 1,
        'investigating' => 2,
        'action_plan' => 3,
        'monitoring' => 4,
        'closed' => 5,
        'referred_external' => 2,
        'no_action_required' => 1,
    ];

    /**
     * Serialize a concern for the SafeguardingConcernDialog (read-only sections +
     * lifecycle tracker). Need-to-know: a restricted concern returns only a
     * redacted shell. Used by both the list (detail-over-list) and the
     * /safeguarding/{id} thin deep-link shell.
     */
    private function buildConcernDetail(SafeguardingConcern $concern, User $user, bool $canSensitive): array
    {
        $lifecycle = app(SafeguardingLifecycle::class);
        $restricted = $this->isConcernRestricted($concern, $user, $canSensitive);

        // Need-to-know: every access to a concern detail is recorded — this is what the
        // dialog's "Viewing is logged" cue refers to. No-ops if the audit table is absent.
        GovernanceAuditService::log('viewed', SafeguardingConcern::class, $concern->getKey(), ['restricted' => $restricted]);

        $base = [
            'id' => $concern->id,
            'reference_number' => $concern->reference_number,
            'restricted' => $restricted,
            'severity' => $concern->severity,
            'status' => $concern->status,
            'status_label' => $lifecycle->label($concern->status),
            'stage_index' => self::STAGE_INDEX[$concern->status] ?? 0,
            'occurred_at' => $concern->occurred_at?->toISOString(),
            'reported_at' => $concern->reported_at?->toISOString(),
        ];

        if ($restricted) {
            return $base; // redacted shell — the dialog renders the locked state
        }

        $concern->load([
            'subject', 'allegedPerpetrator', 'reportedBy', 'assignedTo', 'closedBy', 'triagedBy',
            'site', 'investigations.leadInvestigator', 'externalReports.reportedBy',
            'riskAssessments.assessor', 'actionPlans.assignedTo', 'alerts', 'attachments.uploader',
            'relatedIncident:id,reference_number',
        ]);

        $pendingDeclassification = null;
        $audiencePreview = null;
        if ($concern->is_sensitive) {
            $audiencePreview = $this->sensitivity->audiencePreview($concern);
            $pending = $concern->declassificationReviews()
                ->where('status', SafeguardingDeclassificationReview::STATUS_PENDING)
                ->with('requester:id,name')
                ->first();
            if ($pending) {
                $pendingDeclassification = [
                    'id' => $pending->id,
                    'reason' => $pending->reason,
                    'requested_by' => $pending->requester ? [
                        'id' => $pending->requester->id,
                        'name' => $pending->requester->name,
                    ] : null,
                    'requested_at' => $pending->requested_at?->toISOString(),
                    'audience_snapshot' => Arr::except(
                        $pending->audience_snapshot,
                        ['audience_fingerprint'],
                    ),
                    'can_approve' => $user->can('approveDeclassification', $concern)
                        && (int) $pending->requested_by_user_id !== (int) $user->id,
                ];
            }
        }

        // Linked H&S event (read-only surface), resolved via the observer's idempotency key.
        // The same event carries the Control Room alert id, so we surface both from one lookup.
        $hsEvent = null;
        $controlRoomAlertId = null;
        try {
            $key = HsEvent::buildIdempotencyKey(SafeguardingConcern::class, $concern->getKey(), HsEvent::CATEGORY_SAFEGUARDING);
            $ev = HsEvent::query()->where('idempotency_key', $key)->first();
            if ($ev) {
                $hsEvent = ['id' => $ev->id, 'reference_number' => $ev->reference_number, 'status' => $ev->status];
                $controlRoomAlertId = $ev->control_room_alert_id;
            }
        } catch (\Throwable $e) {
            // H&S link is best-effort; never block the detail on it.
        }

        return [
            ...$base,
            'concern_type' => $concern->concern_type,
            'abuse_category' => $concern->abuse_category,
            'location' => $concern->location,
            'description' => $concern->description,
            'immediate_actions' => $concern->immediate_actions,
            'subject_informed' => (bool) $concern->subject_informed,
            'subject_informed_at' => $concern->subject_informed_at?->toISOString(),
            'is_sensitive' => (bool) $concern->is_sensitive,
            'sensitivity_version' => (int) $concern->sensitivity_version,
            'declassification' => [
                'audience_preview' => $audiencePreview,
                'pending_request' => $pendingDeclassification,
                'request_replay_key' => (string) Str::uuid(),
                'decision_replay_key' => (string) Str::uuid(),
            ],
            'requires_external_referral' => (bool) $concern->requires_external_referral,
            'current_risk_level' => $concern->current_risk_level,
            'triage' => $concern->triaged_at ? [
                'at' => $concern->triaged_at?->toISOString(),
                'by' => $concern->triagedBy?->name,
                'substantiation' => $concern->triage_substantiation,
                'decision' => $concern->triage_decision,
                'notes' => $concern->triage_notes,
            ] : null,
            'closure' => $concern->closed_at ? [
                'at' => $concern->closed_at?->toISOString(),
                'by' => $concern->closedBy?->name,
                'summary' => $concern->closure_summary,
                'lessons' => $concern->lessons_learned,
            ] : null,
            'people' => [
                'subject' => $this->subjectPerson($concern),
                'reported_by' => $concern->reportedBy?->name ?? $concern->reported_by_name,
                'assigned_to' => $concern->assignedTo?->name,
                'alleged_perpetrator' => $this->perpetratorName($concern),
            ],
            'risk_assessments' => $concern->riskAssessments->map(fn ($r) => [
                'id' => $r->id,
                'assessed_at' => $r->assessed_at?->toISOString(),
                'assessor' => $r->assessor?->name,
                'risk_to_self' => $r->risk_to_self,
                'risk_to_others' => $r->risk_to_others,
                'risk_from_others' => $r->risk_from_others,
                'overall_risk_level' => $r->overall_risk_level,
                'mental_capacity' => $r->mental_capacity,
                'protective_measures' => $this->serializeList($r->protective_measures),
                'next_review_date' => $r->next_review_date?->toISOString(),
                'notes' => $r->assessment_notes,
            ])->values()->all(),
            'investigations' => $concern->investigations->map(fn ($i) => [
                'id' => $i->id,
                'type' => $i->investigation_type,
                'status' => $i->status,
                'lead' => $i->leadInvestigator?->name,
                'started_at' => $i->started_at?->toISOString(),
                'completed_at' => $i->completed_at?->toISOString(),
                'outcome' => $i->outcome,
                'findings' => $i->findings,
                'recommendations' => $i->recommendations,
            ])->values()->all(),
            'external_reports' => $concern->externalReports->map(fn ($r) => [
                'id' => $r->id,
                'authority_type' => $r->authority_type,
                'authority_name' => $r->authority_name,
                'reported_at' => $r->reported_at?->toISOString(),
                'method' => $r->report_method,
                'summary' => $r->report_summary,
                'ack_received' => (bool) $r->acknowledgement_received,
                'acknowledged_at' => $r->acknowledged_at?->toISOString(),
                'ack_reference' => $r->acknowledgement_reference,
                'authority_action' => $r->authority_action,
            ])->values()->all(),
            'action_plans' => $concern->actionPlans->map(fn ($a) => [
                'id' => $a->id,
                'description' => $a->action_description,
                'type' => $a->action_type,
                'assigned_to' => $a->assignedTo?->name,
                'due_date' => $a->due_date?->toISOString(),
                'status' => $a->status,
                'completed_at' => $a->completed_at?->toISOString(),
                'overdue' => (bool) ($a->due_date && $a->due_date->isPast() && ! in_array($a->status, ['completed', 'cancelled'], true)),
            ])->values()->all(),
            'alerts' => $concern->alerts->map(fn ($al) => [
                'id' => $al->id,
                'alert_type' => $al->alert_type,
                'summary' => $al->alert_summary,
                'severity' => $al->severity,
                'active' => (bool) $al->active,
            ])->values()->all(),
            'attachments' => $concern->attachments->map(function (SafeguardingAttachment $a) use ($concern, $canSensitive) {
                // Need-to-know: sensitive evidence is locked for viewers without viewSensitive.
                if ($a->is_sensitive && ! $canSensitive) {
                    return ['id' => $a->id, 'locked' => true, 'is_sensitive' => true];
                }

                return [
                    'id' => $a->id,
                    'locked' => false,
                    'name' => $a->original_name,
                    'mime' => $a->mime,
                    'is_image' => $a->isImage(),
                    'size' => $a->size,
                    'notes' => $a->notes,
                    'is_sensitive' => (bool) $a->is_sensitive,
                    'uploaded_by' => $a->uploader?->name,
                    'created_at' => $a->created_at?->toISOString(),
                    'download_url' => "/safeguarding/{$concern->id}/attachments/{$a->id}/download",
                ];
            })->values()->all(),
            'related_incident_id' => $concern->related_incident_id,
            'related_incident_ref' => $concern->relatedIncident?->reference_number,
            'hs_event' => $hsEvent,
            'control_room_alert_id' => $controlRoomAlertId,
            'access_log' => $this->recentAccessLog($concern),
            'can' => [
                'update' => $user->can('update', $concern),
                'investigate' => $user->can('investigate', $concern),
                'report_external' => $user->can('reportExternal', $concern),
                'request_declassification' => $user->can('requestDeclassification', $concern),
                'approve_declassification' => $user->can('approveDeclassification', $concern),
            ],
            'assignable_staff' => User::staff()->select('id', 'name')->orderBy('name')->get()
                ->map(fn (User $u) => ['id' => $u->id, 'name' => $u->name])->values()->all(),
        ];
    }

    private function concealForeignConcern(User $user, SafeguardingConcern $concern): void
    {
        abort_unless(
            $this->concernPolicy->applyVisibleScope(
                SafeguardingConcern::query()->whereKey($concern->id),
                $user,
            )->exists(),
            404,
        );
    }

    private function nestedDeclassificationReview(
        SafeguardingConcern $concern,
        string $reviewId,
    ): SafeguardingDeclassificationReview {
        return $concern->declassificationReviews()
            ->whereKey($reviewId)
            ->firstOrFail();
    }

    private function subjectPerson(SafeguardingConcern $concern): ?array
    {
        $name = $this->subjectDisplayName($concern);
        if (! $name) {
            return null;
        }

        $subject = $concern->subject;
        $type = $subject instanceof Client ? 'client' : ($subject instanceof User ? 'staff' : 'other');

        return ['name' => $name, 'href' => $this->subjectHref($concern), 'type' => $type];
    }

    private function perpetratorName(SafeguardingConcern $concern): ?string
    {
        $p = $concern->allegedPerpetrator;
        if ($p instanceof Client) {
            return trim($p->first_name.' '.$p->last_name) ?: null;
        }
        if ($p instanceof User) {
            return $p->name;
        }

        return $concern->alleged_perpetrator_name;
    }

    private function normalizeConcernInput(Request $request, array $validated): array
    {
        $subjectType = (string) $request->input('subject_type', '');
        $validated['subject_type'] = match ($subjectType) {
            'client' => Client::class,
            'staff' => User::class,
            default => null,
        };
        $validated['subject_id'] = in_array($subjectType, ['client', 'staff'], true)
            ? ($validated['subject_id'] ?? null)
            : null;
        $validated['subject_name'] = $subjectType === 'other'
            ? $this->nullableString($request->input('other_subject_name'))
            : null;

        $perpetratorType = (string) $request->input('alleged_perpetrator_type', '');
        $validated['alleged_perpetrator_type'] = match ($perpetratorType) {
            'client' => Client::class,
            'staff' => User::class,
            default => null,
        };
        $validated['alleged_perpetrator_id'] = in_array($perpetratorType, ['client', 'staff'], true)
            ? ($validated['alleged_perpetrator_id'] ?? null)
            : null;
        $validated['alleged_perpetrator_name'] = in_array($perpetratorType, ['family', 'other'], true)
            ? $this->nullableString($request->input('other_perpetrator_name'))
            : null;
        $validated['alleged_perpetrator_details'] = $this->nullableString($request->input('perpetrator_relationship'))
            ?? ($validated['alleged_perpetrator_details'] ?? null);

        $validated['immediate_actions'] = $request->boolean('immediate_action_taken')
            ? $this->nullableString($request->input('immediate_action_description'))
            : null;
        $validated['witnesses'] = $this->normalizeWitnesses($request->input('witnesses'));
        $validated['subject_informed'] = $request->boolean('subject_informed');
        $validated['requires_external_referral'] = $request->boolean('requires_external_referral');

        return $validated;
    }

    private function normalizeWitnesses(mixed $witnesses): ?array
    {
        if (is_array($witnesses)) {
            $entries = array_values(array_filter(array_map(
                fn (mixed $entry) => is_string($entry) ? trim($entry) : '',
                $witnesses,
            )));

            return $entries === [] ? null : $entries;
        }

        if (! is_string($witnesses)) {
            return null;
        }

        $entries = array_values(array_filter(array_map(
            fn (string $entry) => trim($entry),
            preg_split('/\r\n|\r|\n/', $witnesses) ?: [],
        )));

        return $entries === [] ? null : $entries;
    }

    private function serializeList(mixed $value): ?string
    {
        if (is_array($value)) {
            $entries = array_values(array_filter(array_map(
                fn (mixed $entry) => is_string($entry) ? trim($entry) : '',
                $value,
            )));

            return $entries === [] ? null : implode("\n", $entries);
        }

        return $this->nullableString($value);
    }

    private function nullableString(mixed $value): ?string
    {
        if (! is_string($value)) {
            return null;
        }

        $trimmed = trim($value);

        return $trimmed === '' ? null : $trimmed;
    }

    private function reconcileCanonicalIntakeScope(Request $request, array &$validated, ?SafeguardingConcern $existing = null): void
    {
        $user = $request->user();
        if (! $user) {
            abort(401);
        }

        $siteId = $validated['site_id'] ?? $existing?->site_id;

        // 1. Assert actor has access to site if specified
        if ($siteId) {
            $this->siteAccess->assertCanAccessSiteId($user, (int) $siteId);
        }

        // 2. Canonical Client reconciliation
        $subjectType = $validated['subject_type'] ?? $existing?->subject_type;
        $subjectId = $validated['subject_id'] ?? $existing?->subject_id;
        $isClientSubject = in_array($subjectType, ['client', Client::class], true);
        $isStaffSubject = in_array($subjectType, ['staff', User::class], true);

        if ($isClientSubject && $subjectId) {
            $client = Client::findOrFail($subjectId);
            $this->siteAccess->assertCanAccessClientId($user, (int) $client->id);

            // Reconcile client's canonical site with the concern's site
            if ($client->site_id) {
                if ($siteId && (int) $client->site_id !== (int) $siteId) {
                    throw ValidationException::withMessages([
                        'subject_id' => ['The selected client does not belong to the chosen site.'],
                    ]);
                }
                if (! $siteId) {
                    $validated['site_id'] = $client->site_id;
                    $siteId = $client->site_id;
                }
            }
        }

        // 3. Canonical Staff reconciliation
        if ($isStaffSubject && $subjectId && $siteId) {
            $this->siteAccess->assertCanUseCurrentStaffAtSite($user, (int) $subjectId, (int) $siteId);
        }

        // 4. Canonical Incident reconciliation
        $incidentId = $validated['related_incident_id'] ?? $existing?->related_incident_id;
        if ($incidentId) {
            $incident = ClientIncident::findOrFail($incidentId);

            if ($siteId) {
                $this->siteAccess->assertCanUseClientIncidentAtSite($user, $incident, (int) $siteId);
            }

            if ($isClientSubject && $subjectId) {
                if ((int) $incident->client_id !== (int) $subjectId) {
                    throw ValidationException::withMessages([
                        'related_incident_id' => ['The linked incident does not belong to the subject client.'],
                    ]);
                }
            }
        }

        // 5. Perpetrator reconciliation
        $perpType = $validated['alleged_perpetrator_type'] ?? $existing?->alleged_perpetrator_type;
        $perpId = $validated['alleged_perpetrator_id'] ?? $existing?->alleged_perpetrator_id;
        $isClientPerp = in_array($perpType, ['client', Client::class], true);
        $isStaffPerp = in_array($perpType, ['staff', User::class], true);

        if ($isStaffPerp && $perpId && $siteId) {
            $this->siteAccess->assertCanUseCurrentStaffAtSite($user, (int) $perpId, (int) $siteId);
        }
        if ($isClientPerp && $perpId) {
            $this->siteAccess->assertCanAccessClientId($user, (int) $perpId);
        }
    }
}
