<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Services\Audit\AuditLogViewService;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Symfony\Component\HttpFoundation\StreamedResponse;

class AuditLogSettingsController extends Controller
{
    public function __construct(private readonly AuditLogViewService $auditLogs) {}

    public function index(Request $request)
    {
        $this->authorizeAuditAccess($request);
        $viewer = $request->user();

        $read = $this->auditLogs->materialize($viewer, function ($current, $context) use ($request): array {
            $filters = $this->normalizeFilters($request);
            $events = $this->auditLogs->query($filters, $current, $context)
                ->paginate(50)->withQueryString()
                ->through(fn ($log): array => $this->auditLogs->present($log, $current, $context))->toArray();
            return ['filters' => $filters, 'events' => $events, 'options' => $this->auditLogs->filterOptions($current, $context),
                'stats' => $this->auditLogs->stats($filters, $current, $context)];
        });

        return inertia('settings/audit-logs', [
            'events' => Inertia::always($read['events']),
            'users' => Inertia::always($read['options']['users']),
            'filters' => $this->responseFilters($read['filters']),
            'stats' => Inertia::always($read['stats']),
        ]);
    }

    public function export(Request $request): StreamedResponse
    {
        $this->authorizeAuditAccess($request);
        $viewer = $request->user();

        $rows = $this->auditLogs->materialize($viewer, function ($current, $context) use ($request): array {
            $filters = $this->normalizeFilters($request);
            return $this->auditLogs->query($filters, $current, $context)->limit(5000)->get()
                ->map(function ($log) use ($current, $context): array {
                    $event = $this->auditLogs->present($log, $current, $context);
                    return [$event['created_at'], $event['actor']['name'] ?? 'System', $event['description'],
                        $event['action'], $event['module'] ?? '',
                        trim(($event['subject_type'] ?? '').($event['subject_id'] ? " #{$event['subject_id']}" : ''))];
                })->all();
        });

        return response()->streamDownload(function () use ($rows): void {
            $handle = fopen('php://output', 'wb');

            $this->putCsv($handle, ['Timestamp', 'User', 'Description', 'Action', 'Module', 'Subject']);

            foreach ($rows as $cells) {
                $this->putCsv($handle, $cells);
            }

            fclose($handle);
        }, 'audit-logs-'.now()->format('Y-m-d-His').'.csv', [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    private function authorizeAuditAccess(Request $request): void
    {
        abort_unless($request->user(), 403);
        // Current audit.viewAny is enforced by the complete materializing callback.
    }

    /**
     * @return array{
     *     search:?string,
     *     user_id:?int,
     *     module:?string,
     *     action:?string,
     *     date_from:?string,
     *     date_to:?string
     * }
     */
    private function normalizeFilters(Request $request): array
    {
        $validated = $request->validate([
            'search' => ['nullable', 'string', 'max:200'],
            'user' => ['nullable', 'string', 'max:40', 'regex:/^(all|[1-9][0-9]*)$/'],
            'module' => ['nullable', 'string', 'max:40'],
            'action' => ['nullable', 'string', 'max:40'],
            'date_from' => ['nullable', 'date'],
            'date_to' => ['nullable', 'date'],
        ]);

        $user = $this->nullableFilter($validated['user'] ?? null);
        $module = $this->nullableFilter($validated['module'] ?? null);
        if ($module !== null) {
            abort_unless(in_array($module, $this->auditLogs->moduleKeys(), true), 422);
        }

        return [
            'search' => $this->nullableFilter($validated['search'] ?? null),
            'user_id' => $user !== null ? (int) $user : null,
            'module' => $module,
            'action' => $this->nullableFilter($validated['action'] ?? null),
            'date_from' => $this->nullableFilter($validated['date_from'] ?? null),
            'date_to' => $this->nullableFilter($validated['date_to'] ?? null),
        ];
    }

    private function nullableFilter(?string $value): ?string
    {
        $normalized = trim((string) $value);

        if ($normalized === '' || $normalized === 'all') {
            return null;
        }

        return $normalized;
    }

    /** @param array<string, mixed> $filters */
    private function responseFilters(array $filters): array
    {
        $response = array_filter($filters, fn ($value) => $value !== null && $value !== '');
        if (isset($response['user_id'])) {
            $response['user'] = (string) $response['user_id'];
            unset($response['user_id']);
        }

        return $response;
    }
}
