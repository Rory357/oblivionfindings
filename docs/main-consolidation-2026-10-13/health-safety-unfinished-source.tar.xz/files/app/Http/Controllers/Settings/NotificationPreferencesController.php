<?php

namespace App\Http\Controllers\Settings;

use App\Http\Controllers\Controller;
use App\Models\Role;
use App\Models\RoleNotificationPreference;
use App\Models\User;
use App\Models\UserNotificationPreference;
use App\Services\AuditLogger;
use App\Services\Fleet\FleetNotificationPreferences;
use App\Services\HealthSafety\WorkerParticipationMeetingDeliveryService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class NotificationPreferencesController extends Controller
{
    public function index(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $groups = (array) config('notification_events.groups', []);

        $userPrefs = UserNotificationPreference::query()
            ->where('user_id', $user->id)
            ->get(['key', 'enabled', 'channel_inapp', 'channel_email', 'channel_push'])
            ->keyBy('key');

        // Role defaults are *display only* on the user page.
        $roleIds = $user->roles()->pluck('roles.id');
        $rolePrefs = $roleIds->isEmpty() ? collect() : RoleNotificationPreference::query()
            ->whereIn('role_id', $roleIds)
            ->get(['role_id', 'key', 'enabled', 'channel_inapp', 'channel_email', 'channel_push']);

        $fleet = app(FleetNotificationPreferences::class)->snapshot($user);
        $meetingKey = WorkerParticipationMeetingDeliveryService::EVENT_KEY;
        $meetingDefaults = $rolePrefs->where('key', $meetingKey);
        if ($roleIds->isEmpty() && filled($user->role)) {
            $meetingDefaults = RoleNotificationPreference::query()->where('key', $meetingKey)
                ->whereIn('role_id', Role::query()->where('name', $user->role)->select('id'))->get();
        }
        $meetingChannels = $meetingDefaults->isEmpty()
            ? ['enabled' => true, 'inapp' => true, 'email' => true, 'push' => false]
            : ['enabled' => $meetingDefaults->contains(fn ($p) => (bool) $p->enabled),
                'inapp' => $meetingDefaults->contains(fn ($p) => (bool) $p->enabled && (bool) $p->channel_inapp),
                'email' => $meetingDefaults->contains(fn ($p) => (bool) $p->enabled && (bool) $p->channel_email), 'push' => false];

        return inertia('settings/notifications', [
            'groups' => $groups,
            'delivery' => [
                'dnd_enabled' => (bool) $user->dnd_enabled,
                'dnd_until' => optional($user->dnd_until)->toISOString(),
                'desktop_notifications_enabled' => (bool) $user->desktop_notifications_enabled,
                'notification_sounds_enabled' => (bool) ($user->notification_sounds_enabled ?? true),
                'email_digest_frequency' => $user->email_digest_frequency ?? 'instant',
            ],
            'userPrefs' => $userPrefs->toBase()->map(fn ($p) => [
                'enabled' => (bool) $p->enabled,
                'inapp' => (bool) $p->channel_inapp,
                'email' => (bool) $p->channel_email,
                'push' => $p->key === $meetingKey ? false : (bool) $p->channel_push,
            ])->merge(collect($fleet['events'])->filter(fn ($event) => $userPrefs->has($event['key']))->mapWithKeys(fn ($event) => [$event['key'] => [
                'enabled' => $event['effective']['inapp'] || $event['effective']['email'],
                ...$event['effective'], 'push' => false,
            ]]))->all(),
            'roleDefaults' => $rolePrefs->toBase()->groupBy('key')->map(function ($items) {
                // Any role enables => enabled, otherwise disabled.
                $enabled = $items->contains(fn ($p) => (bool) $p->enabled === true);
                $inapp = $items->contains(fn ($p) => (bool) $p->channel_inapp === true);
                $email = $items->contains(fn ($p) => (bool) $p->channel_email === true);
                $push = $items->contains(fn ($p) => (bool) $p->channel_push === true);

                return [
                    'enabled' => $enabled,
                    'inapp' => $inapp,
                    'email' => $email,
                    'push' => $push,
                ];
            })->merge(collect($fleet['events'])->mapWithKeys(fn ($event) => [$event['key'] => ['enabled' => $event['defaults']['inapp'] || $event['defaults']['email'], ...$event['defaults'], 'push' => false]]))
                ->put($meetingKey, $meetingChannels)->all(),
            'canManageRoleDefaults' => (bool) ($user->canDo('settings.access.manage')),
        ]);
    }

    public function update(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $data = $request->validate([
            'prefs' => ['required', 'array'],
        ]);

        $prefs = (array) $data['prefs'];

        DB::transaction(function () use ($user, $prefs, $request) {
            User::whereKey($user->id)->lockForUpdate()->firstOrFail();
            $fleetService = app(FleetNotificationPreferences::class);
            $before = $fleetService->snapshot($user);
            foreach ($prefs as $key => $channels) {
                $channels = $this->normalizeChannels($channels, 'prefs.'.$key);
                if ($key === WorkerParticipationMeetingDeliveryService::EVENT_KEY) { $channels['push'] = false; }

                UserNotificationPreference::updateOrCreate([
                    'user_id' => $user->id,
                    'key' => (string) $key,
                ], [
                    'enabled' => $channels['enabled'],
                    'channel_inapp' => $channels['inapp'],
                    'channel_email' => $channels['email'],
                    'channel_push' => $channels['push'],
                    'channel_overrides' => null,
                ]);
            }
            $after = $fleetService->snapshot($user);
            if ($before['revision'] !== $after['revision']) {
                AuditLogger::logOrFail('fleet.settings.notifications.updated', $user, ['actor_id' => $user->id, 'before' => $before['overrides'], 'after' => $after['overrides']], $request);
            }
        });

        return redirect()->back()->with('success', 'Notification preferences updated.');
    }

    /**
     * Persist delivery-level preferences: DND, desktop notifications, sound
     * playback, and email digest frequency. Separate endpoint from the
     * per-event preferences matrix so the two UIs can save independently.
     */
    public function updateDelivery(Request $request)
    {
        $user = $request->user();
        abort_unless($user, 403);

        $data = $request->validate([
            'dnd_enabled' => ['nullable', 'boolean'],
            'dnd_until' => ['nullable', 'date'],
            'desktop_notifications_enabled' => ['nullable', 'boolean'],
            'notification_sounds_enabled' => ['nullable', 'boolean'],
            'email_digest_frequency' => ['nullable', 'string', 'in:instant,daily,weekly,off'],
        ]);

        $user->fill(array_intersect_key($data, array_flip([
            'dnd_enabled',
            'dnd_until',
            'desktop_notifications_enabled',
            'notification_sounds_enabled',
            'email_digest_frequency',
        ])))->save();

        return redirect()->back()->with('success', 'Delivery preferences updated.');
    }

    public function roles(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $user->canDo('settings.access.manage'), 403);

        $groups = (array) config('notification_events.groups', []);
        $allKeys = collect($groups)->flatten()->unique()->values();

        $roles = Role::query()->orderBy('label')->get(['id', 'name', 'label']);
        $existing = RoleNotificationPreference::query()
            ->whereIn('key', $allKeys)
            ->get(['role_id', 'key', 'enabled', 'channel_inapp', 'channel_email', 'channel_push']);

        $matrix = [];
        foreach ($roles as $role) {
            $row = [];
            foreach ($allKeys as $key) {
                $pref = $existing->firstWhere(fn ($p) => (int) $p->role_id === (int) $role->id && $p->key === $key);
                // Default true/inapp if unset.
                $row[$key] = $pref ? [
                    'enabled' => (bool) $pref->enabled,
                    'inapp' => (bool) $pref->channel_inapp && ($key !== WorkerParticipationMeetingDeliveryService::EVENT_KEY || (bool) $pref->enabled),
                    'email' => (bool) $pref->channel_email && ($key !== WorkerParticipationMeetingDeliveryService::EVENT_KEY || (bool) $pref->enabled),
                    'push' => $key === WorkerParticipationMeetingDeliveryService::EVENT_KEY ? false : (bool) $pref->channel_push,
                ] : [
                    'enabled' => true,
                    'inapp' => true,
                    'email' => $key === WorkerParticipationMeetingDeliveryService::EVENT_KEY ? true : (FleetNotificationPreferences::EVENTS[$key]['email'] ?? false),
                    'push' => false,
                ];
            }
            $matrix[$role->id] = $row;
        }

        return inertia('settings/notification-defaults', [
            'groups' => $groups,
            'roles' => $roles,
            'matrix' => $matrix,
        ]);
    }

    public function updateRoles(Request $request)
    {
        $user = $request->user();
        abort_unless($user && $user->canDo('settings.access.manage'), 403);

        $data = $request->validate([
            'matrix' => ['required', 'array'],
        ]);

        $matrix = (array) $data['matrix'];

        foreach ($matrix as $roleId => $prefs) {
            if (! is_array($prefs)) {
                continue;
            }
            foreach ($prefs as $key => $channels) {
                $channels = $this->normalizeChannels($channels, 'matrix.'.$roleId.'.'.$key);
                if ($key === WorkerParticipationMeetingDeliveryService::EVENT_KEY) { $channels['push'] = false; }

                RoleNotificationPreference::updateOrCreate([
                    'role_id' => (int) $roleId,
                    'key' => (string) $key,
                ], [
                    'enabled' => $channels['enabled'],
                    'channel_inapp' => $channels['inapp'],
                    'channel_email' => $channels['email'],
                    'channel_push' => $channels['push'],
                ]);
            }
        }

        return redirect()->back()->with('success', 'Role notification defaults updated.');
    }

    /**
     * @return array{enabled: bool, inapp: bool, email: bool, push: bool}
     */
    private function normalizeChannels(mixed $channels, string $errorKey): array
    {
        if (is_bool($channels)) {
            return [
                'enabled' => $channels,
                'inapp' => $channels,
                'email' => false,
                'push' => false,
            ];
        }

        if (! is_array($channels)) {
            throw ValidationException::withMessages([
                $errorKey => 'The notification preference must be a boolean or channel configuration.',
            ]);
        }

        $validator = Validator::make($channels, [
            'enabled' => ['required', 'boolean'],
            'inapp' => ['required', 'boolean'],
            'email' => ['required', 'boolean'],
            'push' => ['required', 'boolean'],
        ]);

        if ($validator->fails()) {
            $messages = [];
            foreach ($validator->errors()->messages() as $field => $fieldMessages) {
                $messages[$errorKey.'.'.$field] = $fieldMessages;
            }

            throw ValidationException::withMessages($messages);
        }

        return [
            'enabled' => $this->toBoolean($channels['enabled']),
            'inapp' => $this->toBoolean($channels['inapp']),
            'email' => $this->toBoolean($channels['email']),
            'push' => $this->toBoolean($channels['push']),
        ];
    }

    private function toBoolean(mixed $value): bool
    {
        return (bool) filter_var($value, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    }
}
