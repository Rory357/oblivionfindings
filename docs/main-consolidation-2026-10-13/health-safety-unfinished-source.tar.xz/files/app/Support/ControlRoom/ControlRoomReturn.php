<?php

namespace App\Support\ControlRoom;

use App\Exceptions\RecoverableTaskAuthorizationException;
use App\Models\ControlRoomAlert;

/** Navigation context only; this does not authorize an alert or a source list. */
final class ControlRoomReturn
{
    private const LIST_KEYS = [
        '/control-room' => ['q', 'search', 'status', 'severity', 'source', 'queue_id', 'assigned_to', 'escalation_level', 'date_from', 'date_to', 'sort', 'dir', 'site_id', 'period', 'page'],
        '/control-room/alerts' => ['lens', 'status', 'severity', 'source', 'queue_id', 'assigned_to', 'search', 'date_from', 'date_to', 'sort', 'dir', 'snoozed', 'handover', 'page'],
        '/control-room/integration-alerts' => ['status', 'severity', 'source', 'assigned_to', 'search', 'date_from', 'date_to', 'sort', 'dir', 'snoozed', 'page'],
        '/control-room/escalations' => ['queue_id', 'tier', 'severity', 'search', 'page'],
        '/control-room/incidents' => ['lens', 'severity', 'status', 'client_id', 'site_id', 'date_from', 'date_to', 'search', 'page'],
        '/control-room/my-tasks' => [],
    ];

    public static function sanitize(mixed $value): ?string
    {
        $parts = is_string($value) ? parse_url($value) : false;
        $path = is_array($parts) ? ($parts['path'] ?? '') : '';
        if (! array_key_exists($path, self::LIST_KEYS)) {
            // Preserve established task and other source-workspace contracts.
            return RecoverableTaskAuthorizationException::validatedReturnTo($value);
        }

        if (strlen($value) > 2048 || str_contains($value, chr(92))
            || preg_match('/[\x00-\x20\x7f]/', $value)
            || preg_match('/%(?![a-fA-F0-9]{2})/', $value)
            || isset($parts['scheme']) || isset($parts['host'])
            || isset($parts['user']) || isset($parts['pass']) || isset($parts['fragment'])) {
            return null;
        }

        $query = [];
        foreach (explode('&', $parts['query'] ?? '') as $pair) {
            if ($pair === '') {
                continue;
            }
            [$key, $item] = array_pad(explode('=', $pair, 2), 2, '');
            $key = urldecode($key);
            $item = urldecode($item);
            // Reject array syntax even on transient/unknown keys and before a
            // later duplicate scalar could hide it. Do not normalize key names.
            if (strpbrk($key, '[]') !== false || str_contains($key.$item, chr(92))
                || preg_match('/[\x00-\x1f\x7f]/', $key.$item)) {
                return null;
            }
            if (in_array($key, self::LIST_KEYS[$path], true)) {
                $query[$key] = $item;
            }
        }

        $safe = [];
        foreach (self::LIST_KEYS[$path] as $key) {
            $item = trim($query[$key] ?? '');
            if ($item !== '' && self::valid($path, $key, $item)) {
                $safe[$key] = $item;
            }
        }
        $queryString = http_build_query($safe, '', '&', PHP_QUERY_RFC3986);

        $result = $path.($queryString === '' ? '' : '?'.$queryString);

        return strlen($result) <= 2048 ? $result : null;
    }

    private static function valid(string $path, string $key, string $item): bool
    {
        return match ($key) {
            'q', 'search' => strlen($item) <= 500,
            'source' => strlen($item) <= 128,
            'queue_id', 'site_id', 'client_id', 'page' => self::positive($item),
            'assigned_to' => in_array($item, ['me', 'unassigned'], true) || self::positive($item),
            'escalation_level', 'tier' => in_array($item, ['1', '2', '3', '4', '5'], true),
            'date_from', 'date_to' => self::date($item),
            'status' => in_array($item, ControlRoomAlert::VALID_STATUSES, true)
                || ($path !== '/control-room/incidents' && $item === 'all'),
            'severity' => in_array($item, ['critical', 'high', 'medium', 'low'], true)
                || ($path === '/control-room' && $item === 'all'),
            'lens' => in_array($item, $path === '/control-room/incidents'
                ? ['attention', 'needs_incident', 'awaiting_health_safety', 'accepted_in_progress', 'operational_complete_governance_open', 'complete']
                : ['active', 'history', 'snoozed', 'my_queue', 'safety_handover'], true),
            'sort' => in_array($item, match ($path) {
                '/control-room' => ['severity', 'triggered_at'],
                '/control-room/alerts' => ['priority', 'severity', 'triggered_at', 'status', 'alert_type'],
                default => ['severity', 'triggered_at', 'status', 'alert_type'],
            }, true),
            'dir' => in_array($item, ['asc', 'desc'], true),
            'snoozed' => $item === '1',
            'handover' => $item === 'carry-forward',
            'period' => in_array($item, ['24h', '7d', '30d', '90d'], true),
            default => false,
        };
    }

    private static function positive(string $value): bool
    {
        return preg_match('/^[1-9][0-9]*$/D', $value) === 1
            && strlen($value) <= 16 && (float) $value <= min(PHP_INT_MAX, 9007199254740991);
    }

    private static function date(string $value): bool
    {
        return preg_match('/^([0-9]{4})-([0-9]{2})-([0-9]{2})$/D', $value, $parts) === 1
            && checkdate((int) $parts[2], (int) $parts[3], (int) $parts[1]);
    }
}
