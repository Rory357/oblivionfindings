<?php

namespace App\Services\ControlRoom;

use App\Models\ClientIncident;
use App\Models\ControlRoomAlert;
use App\Models\RestraintEvent;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\HealthSafety\RestraintAccessService;
use App\Services\Incidents\IncidentAccessService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Support\Arr;
use Illuminate\Support\Carbon;
use Illuminate\Support\Str;
use Symfony\Component\HttpKernel\Exception\HttpException;

/** Read-only disclosure of incident material copied into an operational record. */
final class ControlRoomSourceContentService
{
    public function __construct(private readonly IncidentAccessService $incidents) {}

    public const RESTRICTED = 'Incident details restricted';

    public const UNAVAILABLE = 'Incident details unavailable';

    /** Detached private source entry; operational response access remains independent. */
    public function restraintForAlert(ControlRoomAlert $alert, User $viewer, ?HealthSafetyReadContext $context = null): array
    {
        $raw = is_array($alert->context) ? $alert->context : [];
        if (! $this->isRestraintAlert($alert)) {
            return ['restraint_access' => 'absent', 'restraint_source' => null];
        }
        $result = ['restraint_access' => 'unavailable', 'restraint_source' => null];
        $id = $this->positiveId($raw['restraint_event_id'] ?? null);
        if ($id === null) {
            return $result;
        }
        $context?->assertViewer($viewer);
        $access = app(RestraintAccessService::class);
        try {
            $consume = function ($current, $reads, $sites) use ($access, $alert, $id): array {
                $freshAlert = $reads->query(ControlRoomAlert::query())->find($alert->id);
                $source = $reads->query(RestraintEvent::query())->find($id);
                if (! $freshAlert || ! $source || $this->positiveId($freshAlert->context['restraint_event_id'] ?? null) !== $id
                    || (int) $freshAlert->client_id !== (int) $source->client_id
                    || ($freshAlert->site_id === null ? null : (int) $freshAlert->site_id) !== ($source->site_id === null ? null : (int) $source->site_id)) {
                    return ['restraint_access' => 'unavailable', 'restraint_source' => null];
                }
                $access->assertEvent($source, $current, $reads, $sites, 'view');

                return ['restraint_access' => 'readable', 'restraint_source' => ['id' => (int) $source->id, 'href' => '/health-safety/restraints/events/'.$source->id]];
            };

            return $context ? $access->withReadContext($context, $consume) : $access->withCurrentViewer($viewer, $consume);
        } catch (HttpException $error) {
            if (! in_array($error->getStatusCode(), [403, 404], true)) {
                throw $error;
            }

            return ['restraint_access' => 'restricted', 'restraint_source' => null];
        }
    }

    private function isRestraintAlert(ControlRoomAlert $alert): bool
    {
        return $alert->alert_type === 'operations.restraint_event' || array_key_exists('restraint_event_id', is_array($alert->context) ? $alert->context : []);
    }

    /**
     * The canonical records and access states are supplied once per list by
     * ControlRoomGovernanceReadService. This projector performs no queries.
     */
    public function present(ControlRoomAlert $alert, array $governance, array $context): array
    {
        $raw = is_array($alert->context) ? $alert->context : [];
        $restraintOrigin = $this->isRestraintAlert($alert);
        if ($restraintOrigin) {
            // Retain response work; source facts and command/delivery provenance belong to its private page.
            $context = Arr::except($context, ['restraint_event_id', 'restraint_id', 'source_revision', 'creation_source_revision',
                'source_deliveries', 'delivery_id', 'source_id', 'source_type', 'provenance', 'description', 'title', 'summary',
                'trigger_description', 'restraint_description', 'de_escalation_attempted', 'person_response', 'post_incident_support',
                'injury_details', 'staff_involved', 'authorised_by', 'within_support_plan', 'behaviour_support_plan_id',
                'behaviour_support_plan_version_id', 'plan_authorization_snapshot', 'normalized_data', 'signal_payload',
                'restraint_type', 'duration_minutes', 'started_at', 'ended_at', 'occurred_at', 'review_notes', 'reviewed_by', 'reviewed_at',
                'lessons_learned', 'deviation_reason', 'injury_occurred', 'monitoring', 'observations', 'debrief', 'followups',
                'creation_key', 'creation_fingerprint', 'command_key', 'idempotency_key', 'actor_snapshot', 'staff_id', 'creator_id', 'created_by']);
            $context['restraint_content_access'] = $governance['restraint_access'] ?? 'unavailable';
            $context['restraint_source'] = ($governance['restraint_access'] ?? null) === 'readable' ? ($governance['restraint_source'] ?? null) : null;
        }
        $incidentOrigin = $alert->source === 'incident'
            || data_get($raw, 'provenance.source') === 'incident_journey'
            || ($raw['incident_source_type'] ?? null) === 'client_incident';
        $rootAccess = $this->incidentAccess($this->entryIncidentId($raw), $governance);
        if ($incidentOrigin && $rootAccess !== 'readable') {
            $context = Arr::except($context, [
                'incident_id', 'incident_type', 'type', 'shift_id', 'occurred_at',
                'description', 'title', 'summary', 'reported_by', 'reason', 'provenance',
                'incident_source_type', 'incident_source_id',
            ]);
            $context['incident_content_access'] = $rootAccess;
        }

        if (data_get($raw, 'normalized_data.incident_id') !== null
            && $this->incidentAccess(data_get($raw, 'normalized_data.incident_id'), $governance) !== 'readable') {
            unset($context['normalized_data'], $context['signal_payload']);
            $context['incident_content_access'] = $this->incidentAccess(data_get($raw, 'normalized_data.incident_id'), $governance);
        }

        foreach (['resolution', 'journey_attention'] as $key) {
            if (is_array($context[$key] ?? null) && $this->isIncidentEntry($context[$key])) {
                $context[$key] = $this->entry($context[$key], $governance);
            }
        }
        foreach (['resolution_history', 'operational_reopen_history'] as $key) {
            if (is_array($context[$key] ?? null)) {
                $context[$key] = array_map(fn ($entry) => is_array($entry) && $this->isIncidentEntry($entry)
                    ? $this->entry($entry, $governance) : $entry, $context[$key]);
            }
        }
        if (is_array($context['activity_log'] ?? null)) {
            $context['activity_log'] = array_map(function ($entry) use ($raw, $governance) {
                if (! is_array($entry) || ($entry['transition'] ?? null) !== 'incident_reopen') {
                    return $entry;
                }
                $sourceId = $entry['incident_id'] ?? null;
                if ($sourceId === null) {
                    // Older activity copies did not record the source ID. Only
                    // an exact matching source-history entry can establish it.
                    $matches = collect($raw['operational_reopen_history'] ?? [])->filter(fn ($history) => is_array($history)
                        && ($history['reason'] ?? null) === ($entry['content'] ?? null)
                        && $this->sameInstant($history['reopened_at'] ?? null, $entry['created_at'] ?? null)
                        && ($history['actor_id'] ?? null) === ($entry['user_id'] ?? null));
                    $ids = $matches->pluck('incident_id')->map(fn ($id) => $this->positiveId($id))->unique();
                    $sourceId = $ids->count() === 1 ? $ids->first() : null;
                }

                return $this->entry($entry + ['incident_id' => $sourceId], $governance);
            }, $context['activity_log']);
        }
        $context = $this->references($context, $governance);
        unset($context['notes_provenance']);

        $notesSourceIds = $this->noteSourceIds($alert);
        $notesAccess = $this->combinedAccess($notesSourceIds, $governance);
        // Canonical bridge receipts explicitly describe minimal operational provenance, never copied notes.
        if ($restraintOrigin && ! is_array($raw['source_deliveries'] ?? null) && ($governance['restraint_access'] ?? null) !== 'readable') {
            $notesAccess = $governance['restraint_access'] ?? 'unavailable';
        }
        $notes = $notesAccess === 'readable' ? $alert->notes : null;
        $candidates = [
            [$context['title'] ?? null, $incidentOrigin],
            [$context['summary'] ?? null, $incidentOrigin],
            [$context['description'] ?? null, $incidentOrigin],
            [data_get($context, 'normalized_data.title'), data_get($raw, 'normalized_data.incident_id') !== null],
            [data_get($context, 'normalized_data.description'), data_get($raw, 'normalized_data.incident_id') !== null],
            [$notes, $notesSourceIds !== []],
        ];
        if ($restraintOrigin) {
            $candidates = [];
        }
        $summary = Str::headline((string) $alert->alert_type);
        $origin = ['type' => 'alert'];
        foreach ($candidates as [$candidate, $fromIncident]) {
            if (is_string($candidate) && trim($candidate) !== '') {
                $summary = Str::limit(trim($candidate), 160);
                $origin = $fromIncident
                    ? ['type' => 'incident', 'incident_id' => ($governance['incident'] ?? null)?->id]
                    : ['type' => 'alert'];
                break;
            }
        }

        $resolverVisible = data_get($raw, 'resolution.source') !== 'incident_lifecycle_signal'
            || $this->incidentAccess(data_get($raw, 'resolution.incident_id'), $governance) === 'readable';
        $acknowledgerFromIncident = data_get($raw, 'resolution.acknowledged_from_incident')
            ?? ($alert->acknowledged_by_user_id !== null
                && $alert->acknowledged_by_user_id === ($alert->resolved_by_user_id ?? data_get($raw, 'resolution.incident_lifecycle_actor_user_id'))
                && $this->sameInstant($alert->acknowledged_at?->toIso8601String(), data_get($raw, 'resolution.resolved_at')));

        return ['context' => $context, 'notes' => $notes, 'notes_access' => $notesAccess,
            'source_creator_visible' => (! $incidentOrigin || $rootAccess === 'readable') && (! $restraintOrigin || ($governance['restraint_access'] ?? null) === 'readable'),
            'source_resolver_visible' => $resolverVisible,
            'source_acknowledger_visible' => $resolverVisible || ! $acknowledgerFromIncident,
            'summary' => $summary, 'summary_origin' => $origin];
    }

    /** Keep SQL search/count/pagination on the same side of the copied-note boundary. */
    public function applyReadableNotes(Builder $query, User $viewer): Builder
    {
        $this->applyReadableRestraintNotes($query, $viewer);
        $readable = $this->incidents->apply(ClientIncident::query(), $viewer)->select('client_incidents.id')
            ->where(function (Builder $source): void {
                $source->whereColumn('client_incidents.control_room_alert_id', 'control_room_alerts.id')
                    ->orWhere(function (Builder $legacy): void {
                        $legacy->whereNull('client_incidents.control_room_alert_id')
                            ->whereRaw("client_incidents.id = CAST(JSON_UNQUOTE(JSON_EXTRACT(control_room_alerts.context, '$.incident_id')) AS UNSIGNED)")
                            ->whereNotExists(fn (QueryBuilder $direct) => $direct->selectRaw('1')
                                ->from('client_incidents as direct_incident')
                                ->whereColumn('direct_incident.control_room_alert_id', 'control_room_alerts.id'));
                    });
            });
        $copies = <<<'SQL'
JSON_TABLE(
    JSON_MERGE_PRESERVE(
        CASE WHEN JSON_TYPE(JSON_EXTRACT(control_room_alerts.context, '$.resolution_history')) = 'ARRAY'
            THEN JSON_EXTRACT(control_room_alerts.context, '$.resolution_history') ELSE JSON_ARRAY() END,
        JSON_ARRAY(JSON_EXTRACT(control_room_alerts.context, '$.resolution'), JSON_EXTRACT(control_room_alerts.context, '$.notes_provenance'))
    ), '$[*]' COLUMNS (
        source VARCHAR(80) PATH '$.source' NULL ON EMPTY NULL ON ERROR,
        incident_id BIGINT PATH '$.incident_id' NULL ON EMPTY NULL ON ERROR,
        reason LONGTEXT PATH '$.reason' NULL ON EMPTY NULL ON ERROR,
        text_sha256 VARCHAR(64) PATH '$.text_sha256' NULL ON EMPTY NULL ON ERROR
    )
) AS copied_note
SQL;

        return $query->whereNotExists(function (QueryBuilder $hidden) use ($copies, $readable): void {
            $hidden->selectRaw('1')->fromRaw($copies)
                ->where('copied_note.source', 'incident_lifecycle_signal')
                ->where(function (QueryBuilder $matches): void {
                    $matches->where(function (QueryBuilder $reason): void {
                        $reason->whereNotNull('copied_note.reason')->where('copied_note.reason', '!=', '')
                            ->whereRaw('LOCATE(CAST(copied_note.reason AS BINARY), CAST(control_room_alerts.notes AS BINARY)) > 0');
                    })->orWhereRaw('copied_note.text_sha256 = SHA2(control_room_alerts.notes, 256)');
                })->where(fn (QueryBuilder $denied) => $denied->whereNull('copied_note.incident_id')
                ->orWhereNotIn('copied_note.incident_id', $readable->toBase()));
        })->whereNot(function (Builder $unknown): void {
            $unknown->where('control_room_alerts.source', 'compliance')
                ->where('control_room_alerts.alert_type', 'Incident Reported')
                ->where('control_room_alerts.notes', 'like', 'New incident reported - %');
        });
    }

    /** Search/count cannot reveal a copied legacy restraint note that its source read conceals. */
    private function applyReadableRestraintNotes(Builder $query, User $viewer): void
    {
        $ids = [];
        $access = app(RestraintAccessService::class);
        try {
            $ids = $access->withCurrentViewer($viewer, function ($current, $reads, $sites) use ($access): array {
                if (! $current->canDo('restraints.view')) {
                    return [];
                }
                $ids = [];
                foreach ($reads->query(RestraintEvent::query())->select(['id', 'client_id', 'site_id', 'stay_id', 'source_schema_version',
                    'recorded_client_id', 'recorded_site_id', 'recorded_stay_id', 'behaviour_support_plan_id', 'behaviour_support_plan_version_id'])->get() as $row) {
                    try {
                        $access->assertEvent($row, $current, $reads, $sites, 'view');
                        $ids[] = (int) $row->id;
                    } catch (HttpException $error) {
                        if (! in_array($error->getStatusCode(), [403, 404], true)) {
                            throw $error;
                        }
                    }
                }

                return $ids;
            });
        } catch (HttpException $error) {
            if (! in_array($error->getStatusCode(), [403, 404], true)) {
                throw $error;
            }
        }
        $query->where(function (Builder $notes) use ($ids): void {
            $notes->whereRaw("JSON_EXTRACT(control_room_alerts.context, '$.restraint_event_id') IS NULL")
                ->where('control_room_alerts.alert_type', '!=', 'operations.restraint_event')
                ->orWhereRaw("JSON_TYPE(JSON_EXTRACT(control_room_alerts.context, '$.source_deliveries')) = 'ARRAY'")
                ->orWhere(function (Builder $source) use ($ids): void {
                    $source->whereExists(function (QueryBuilder $event) use ($ids): void {
                        $event->selectRaw('1')->from('restraint_events')->whereIn('restraint_events.id', $ids)
                            ->whereRaw("restraint_events.id = CAST(JSON_UNQUOTE(JSON_EXTRACT(control_room_alerts.context, '$.restraint_event_id')) AS UNSIGNED)")
                            ->whereColumn('restraint_events.client_id', 'control_room_alerts.client_id')
                            ->whereRaw('restraint_events.site_id <=> control_room_alerts.site_id');
                    });
                });
        });
    }

    /** @return list<int|null> Empty means independently authored operational notes. */
    public function noteSourceIds(ControlRoomAlert $alert): array
    {
        if (! is_string($alert->notes) || $alert->notes === '') {
            return [];
        }
        $context = is_array($alert->context) ? $alert->context : [];
        $copies = [($context['resolution'] ?? null), ...array_values(is_array($context['resolution_history'] ?? null) ? $context['resolution_history'] : [])];
        $ids = [];
        foreach ($copies as $copy) {
            if (is_array($copy) && ($copy['source'] ?? null) === 'incident_lifecycle_signal'
                && is_string($copy['reason'] ?? null) && $copy['reason'] !== ''
                && str_contains($alert->notes, $copy['reason'])) {
                $ids[] = $this->positiveId($copy['incident_id'] ?? null);
            }
        }
        $provenance = $context['notes_provenance'] ?? null;
        if (is_array($provenance) && ($provenance['source'] ?? null) === 'incident_lifecycle_signal'
            && hash_equals((string) ($provenance['text_sha256'] ?? ''), hash('sha256', $alert->notes))) {
            $ids[] = $this->positiveId($provenance['incident_id'] ?? null);
        }
        if ($alert->source === 'compliance' && $alert->alert_type === 'Incident Reported'
            && str_starts_with($alert->notes, 'New incident reported - ')) {
            // This legacy writer accepted any Model, so a numeric ID alone
            // cannot prove that it was a ClientIncident rather than another source.
            $ids[] = null;
        }

        return array_values(array_unique($ids, SORT_REGULAR));
    }

    public function audit(array $row, array $governance, array $context = []): array
    {
        $meta = is_array($row['meta'] ?? null) ? $row['meta'] : [];
        if (array_key_exists('restraint_event_id', $meta) || ($row['action'] ?? null) === 'control_room.restraint_source_accepted') {
            $row['meta'] = Arr::only($meta, ['severity', 'new_response']);
            $row['meta']['restraint_content_access'] = $governance['restraint_access'] ?? 'unavailable';
            if (($governance['restraint_access'] ?? null) !== 'readable') {
                $row['user'] = null;
            }

            return $row;
        }
        if (! isset($meta['incident_id']) && ($meta['resolution_source'] ?? null) === 'incident_lifecycle_signal') {
            $matches = collect($context['resolution_history'] ?? [])->filter(fn ($entry) => is_array($entry)
                && ($entry['source'] ?? null) === 'incident_lifecycle_signal'
                && isset($meta['transitioned_at'])
                && $this->sameInstant($entry['resolved_at'] ?? null, $meta['transitioned_at']));
            $ids = $matches->pluck('incident_id')->map(fn ($id) => $this->positiveId($id))->unique();
            $meta['incident_id'] = $ids->count() === 1 ? $ids->first() : null;
        }
        if ($this->isIncidentEntry($meta)
            || ($meta['resolution_source'] ?? null) === 'incident_lifecycle_signal'
            || in_array($row['action'] ?? null, ['controlRoom.alert.reopenForIncident', 'controlRoom.alert.reopenFromIncidentSignal'], true)) {
            $access = $this->incidentAccess($this->entryIncidentId($meta), $governance);
            $row['meta'] = $this->entry($meta, $governance);
            if ($access !== 'readable') {
                $row['user'] = null;
            }
        } else {
            $row['meta'] = $this->references($meta, $governance);
        }

        return $row;
    }

    public function snapshotSummary(array $row, ?ControlRoomAlert $alert, array $governance): array
    {
        if (! array_key_exists('summary', $row)) {
            return $row;
        }
        if ($alert !== null && $this->isRestraintAlert($alert)) {
            $row['summary'] = Str::headline((string) $alert->alert_type);
            $row['summary_origin'] = ['type' => 'alert'];

            return $row;
        }
        $origin = $row['summary_origin'] ?? null;
        if (($origin['type'] ?? null) === 'alert' || ($origin['type'] ?? null) === 'withheld') {
            return $row;
        }
        $access = ($origin['type'] ?? null) === 'incident'
            ? $this->incidentAccess($origin['incident_id'] ?? null, $governance)
            : 'unavailable';
        if ($access === 'readable') {
            return $row;
        }
        if ($origin === null && $alert !== null
            && ($governance['incident_access'] ?? 'unavailable') === 'absent'
            && ($governance['health_safety_access'] ?? 'unavailable') === 'absent'
            && $this->noteSourceIds($alert) === [] && $alert->source !== 'incident') {
            return $row;
        }
        $row['summary'] = $access === 'restricted' ? self::RESTRICTED : 'Saved summary details unavailable';
        $row['summary_origin'] = ['type' => 'withheld'];

        return $row;
    }

    private function entry(array $entry, array $governance): array
    {
        $access = $this->incidentAccess($this->entryIncidentId($entry), $governance);
        if ($access === 'readable') {
            return $this->references($entry, $governance);
        }
        $minimal = Arr::only($entry, ['type', 'transition', 'resolved_at', 'reopened_at', 'created_at',
            'from_status', 'to_status', 'requires_operational_reopen']);
        $minimal['access'] = $access;
        foreach (['reason', 'content'] as $key) {
            if (array_key_exists($key, $entry)) {
                $minimal[$key] = $access === 'restricted' ? self::RESTRICTED : self::UNAVAILABLE;
            }
        }

        return $minimal;
    }

    private function references(array $data, array $governance): array
    {
        if ((array_key_exists('incident_id', $data) || ($data['incident_source_type'] ?? null) === 'client_incident')
            && $this->incidentAccess($this->entryIncidentId($data), $governance) !== 'readable') {
            $data = Arr::except($data, ['incident_id', 'incident_reference', 'incident_reference_number', 'incident_source_type', 'incident_source_id']);
        }
        if (array_key_exists('hs_event_id', $data)
            && (($governance['health_safety_access'] ?? null) !== 'readable'
                || $this->positiveId($data['hs_event_id']) !== ($governance['hs_event'] ?? null)?->id)) {
            $data = Arr::except($data, ['hs_event_id', 'hs_event_reference', 'health_safety_reference']);
        }

        return $data;
    }

    private function isIncidentEntry(array $entry): bool
    {
        return array_key_exists('incident_id', $entry)
            || ($entry['incident_source_type'] ?? null) === 'client_incident'
            || ($entry['source'] ?? null) === 'incident_lifecycle_signal'
            || ($entry['type'] ?? null) === 'incident_reopened';
    }

    private function combinedAccess(array $ids, array $governance): string
    {
        $access = array_map(fn ($id) => $this->incidentAccess($id, $governance), $ids);

        return in_array('unavailable', $access, true) ? 'unavailable'
            : (in_array('restricted', $access, true) ? 'restricted' : 'readable');
    }

    private function entryIncidentId(array $entry): ?int
    {
        if (($entry['incident_source_type'] ?? null) === 'client_incident') {
            $id = $this->positiveId($entry['incident_source_id'] ?? null);
            if (array_key_exists('incident_id', $entry) && $this->positiveId($entry['incident_id']) !== $id) {
                return null;
            }

            return $id;
        }

        return $this->positiveId($entry['incident_id'] ?? null);
    }

    private function incidentAccess(mixed $id, array $governance): string
    {
        $id = $this->positiveId($id);
        if ($id === null || $id !== (($governance['incident'] ?? null)?->id)) {
            return 'unavailable';
        }

        return ($governance['incident_access'] ?? null) === 'readable' ? 'readable' : 'restricted';
    }

    private function positiveId(mixed $id): ?int
    {
        return filter_var($id, FILTER_VALIDATE_INT) !== false && (int) $id > 0 ? (int) $id : null;
    }

    private function sameInstant(mixed $left, mixed $right): bool
    {
        if (! is_string($left) || trim($left) === '' || ! is_string($right) || trim($right) === '') {
            return false;
        }
        try {
            return Carbon::parse($left)->equalTo(Carbon::parse($right));
        } catch (\Throwable) {
            return false;
        }
    }
}
