<?php

namespace App\Services\ControlRoom;

use App\Models\ClientIncident;
use App\Models\ControlRoomAlert;
use App\Models\HsEvent;
use App\Models\User;
use App\Services\HealthSafety\HealthSafetyReadContext;
use App\Services\HealthSafety\HsEventAccessService;
use App\Services\Incidents\IncidentAccessService;
use App\Services\Incidents\IncidentJourneyService;
use Illuminate\Database\Eloquent\Collection as EloquentCollection;
use Illuminate\Support\Collection;

/** Request-local canonical source context. Never serialize the raw models. */
final class ControlRoomGovernanceReadService
{
    public function __construct(
        private readonly IncidentJourneyService $journeys,
        private readonly IncidentAccessService $incidents,
        private readonly HsEventAccessService $healthSafety,
        private readonly ControlRoomSourceContentService $sourceContent,
    ) {}

    /**
     * @param  iterable<ControlRoomAlert>  $alerts
     * @return Collection<int, array{incident: ?ClientIncident, hs_event: ?HsEvent, incident_access: string, health_safety_access: string}>
     */
    public function forAlerts(iterable $alerts, User $viewer, ?HealthSafetyReadContext $context = null): Collection
    {
        $alerts = new EloquentCollection(collect($alerts)->values()->all());
        if ($alerts->isEmpty()) {
            return collect();
        }
        $viewer->loadMissing(['permissionOverrides', 'roles.permissions']);
        $alerts->loadMissing([
            'site:id,name', 'client:id,first_name,last_name,site_id', 'client.site:id,name',
            'asset.client.site', 'fleetSignal.asset.client.site', 'device',
        ]);
        $records = $this->journeys->governanceRecordsForAlerts($alerts);
        $incidentIds = $records->pluck('incident.id')->filter()->unique()->values();
        $eventIds = $records->pluck('hs_event.id')->filter()->unique()->values();
        $readableIncidentIds = $incidentIds->isEmpty() ? collect() : $this->incidents
            ->apply(ClientIncident::query()->whereIn('id', $incidentIds), $viewer)
            ->pluck('id')->flip();
        $readableEventIds = $eventIds->isEmpty() ? collect() : $this->healthSafety
            ->applyReadableScope(HsEvent::query()->whereIn('id', $eventIds), $viewer, $context)
            ->pluck('id')->flip();
        $readableEvents = new EloquentCollection($records->pluck('hs_event')->filter(
            fn (?HsEvent $event): bool => $event !== null && $readableEventIds->has($event->id),
        )->unique('id')->values()->all());
        $readableEvents->loadMissing(['owner:id,name', 'acceptedBy:id,name']);

        return $records->map(function (array $record, int $id) use ($alerts, $viewer, $context, $readableIncidentIds, $readableEventIds): array {
            if (($record['integrity'] ?? null) === 'unavailable') {
                return ['incident' => null, 'hs_event' => null, 'integrity' => 'unavailable',
                    'incident_access' => 'unavailable', 'health_safety_access' => 'unavailable',
                    'restraint_access' => 'unavailable', 'restraint_source' => null];
            }

            return $record + $this->sourceContent->restraintForAlert($alerts->find($id), $viewer, $context) + [
                'incident_access' => $record['incident'] === null ? 'absent'
                    : ($readableIncidentIds->has($record['incident']->id) ? 'readable' : 'restricted'),
                'health_safety_access' => $record['hs_event'] === null ? 'absent'
                    : ($readableEventIds->has($record['hs_event']->id) ? 'readable' : 'restricted'),
            ];
        });
    }

    /**
     * Re-check saved references against the current reader and canonical source.
     * Retain historical workflow facts without replacing the saved snapshot.
     *
     * @param  array<string, mixed>  $snapshot  A validated handover snapshot.
     * @return array<string, mixed>
     */
    public function forSnapshotViewer(array $snapshot, User $viewer): array
    {
        $alerts = ControlRoomAlert::query()->whereIn('id', collect($snapshot['alerts'])->pluck('id'))->get()->keyBy('id');
        $records = $this->forAlerts($alerts, $viewer);
        $snapshot['alerts'] = collect($snapshot['alerts'])->map(function (array $row) use ($records, $alerts): array {
            $record = $records->get((int) $row['id']);
            $row = $this->sourceContent->snapshotSummary($row, $alerts->get((int) $row['id']), $record ?? []);
            foreach (['incident' => ['incident', 'INC-'], 'health_safety' => ['hs_event', 'HS-']] as $domain => [$key, $prefix]) {
                $referenceKey = $domain.'_reference';
                $accessKey = $domain.'_access';
                $savedReference = $row['journey'][$referenceKey] ?? null;
                $savedAccess = $row['journey'][$accessKey] ?? null;
                $source = $record[$key] ?? null;
                $currentAccess = $record[$accessKey] ?? 'unavailable';
                $currentReference = $source ? ($source->reference_number ?: $prefix.$source->id) : null;

                if ($savedReference !== null && $currentAccess === 'readable' && $savedReference === $currentReference) {
                    $row['journey'][$accessKey] = 'readable';

                    continue;
                }

                $row['journey'][$referenceKey] = null;
                $row['journey'][$accessKey] = match (true) {
                    $savedAccess === 'absent' && $savedReference === null => 'absent',
                    $currentAccess === 'restricted' => 'restricted',
                    default => 'unavailable',
                };
            }

            return $row;
        })->values()->all();

        return $snapshot;
    }
}
