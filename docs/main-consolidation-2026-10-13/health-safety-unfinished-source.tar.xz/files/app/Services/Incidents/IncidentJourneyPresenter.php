<?php

namespace App\Services\Incidents;

use App\Models\ClientIncident;
use App\Models\ControlRoomAlert;
use App\Models\HsCorrectiveAction;
use App\Models\HsEvent;
use App\Models\User;
use App\Services\ControlRoom\ControlRoomSourceContentService;
use App\Services\HealthSafety\HsVisibilityService;
use App\Support\Incidents\LinkedOperationalEvidencePresenter;

class IncidentJourneyPresenter
{
    public function __construct(
        private readonly LinkedOperationalEvidencePresenter $linkedEvidence,
    ) {}

    /** @return array<string, mixed> */
    public function present(IncidentJourney $journey, User $viewer): array
    {
        $incident = $journey->incident;
        $alert = $journey->alert?->fresh();
        $hsEvent = $journey->hsEvent;

        $incident->loadMissing([
            'site:id,name',
            'client:id,first_name,last_name,site_id',
            'client.site:id,name',
            'shift:id,site_id',
            'reporter:id,name',
            'attachments:id,incident_id,original_name',
            'followups:id,client_incident_id,notes,due_at,completed_at,assigned_to_user_id',
        ]);
        $incident->shift?->loadMissing('site:id,name');

        $alert?->loadMissing([
            'sla',
            'playbookRun:id,playbook_id,status,current_step,completed_steps,total_steps',
            'playbookRun.playbook:id,name,code',
            'tasks:id,alert_id,title,status,priority,due_at,assigned_to_user_id',
            'tasks.assignedTo:id,name',
            'evidencePacks:id,alert_id,title,status,item_count',
            'communications:id,alert_id,subject,status,sent_at,delivered_at',
        ]);
        $hsProjection = app(HsVisibilityService::class)->forEvent($hsEvent, $viewer, function (HsEvent $current, array $facts): array {
            $current->load(['site:id,name', 'owner:id,name', 'acceptedBy:id,name',
                'activeInvestigation.leadInvestigator:id,name']);

            return ['access' => 'readable', 'site' => $current->site ? ['id' => $current->site->id, 'name' => $current->site->name] : null,
                'event' => $this->presentHealthSafety($current, true), 'facts' => $facts];
        });
        $hsDetails = $hsProjection['event'] ?? null;
        $hsFacts = $hsProjection['facts'] ?? ['present' => $hsEvent !== null,
            'access' => $hsEvent === null ? 'absent' : (($hsProjection['status'] ?? null) === null ? 'unavailable' : 'restricted'),
            'status' => $hsProjection['status'] ?? null,
            'handover_status' => $hsProjection['handover']['status'] ?? null,
            'has_completed_action' => null, 'can_manage' => false];
        $fallbackSite = $incident->shift?->site ?? $incident->client?->site;
        $siteDetails = $incident->site ? ['id' => $incident->site->id, 'name' => $incident->site->name]
            : ($hsProjection['site'] ?? ($fallbackSite ? ['id' => $fallbackSite->id, 'name' => $fallbackSite->name] : null));
        $canOpenIncident = app(IncidentAccessService::class)->canView($viewer, $incident);
        $canOpenHs = ($hsProjection['access'] ?? null) === 'readable';
        $linkedOperationalEvidence = $alert
            ? $this->linkedEvidence->present(
                $alert,
                $viewer,
                fn ($item): string => $canOpenIncident
                    ? "/incidents/{$incident->id}/control-room-evidence/{$item->id}/download"
                    : "/control-room/alerts/{$alert->id}/evidence/{$item->evidence_pack_id}/items/{$item->id}/download",
            )
            : null;
        $canOpenAlert = data_get($linkedOperationalEvidence, 'source.href') !== null;
        $sourceContent = app(ControlRoomSourceContentService::class);
        $safeAlertContent = $alert && $canOpenAlert ? $sourceContent->present($alert,
            ['incident' => $incident, 'hs_event' => $hsEvent,
                'incident_access' => $canOpenIncident ? 'readable' : 'restricted',
                'health_safety_access' => $hsEvent === null ? 'absent' : ($canOpenHs ? 'readable' : 'restricted')]
                + $sourceContent->restraintForAlert($alert, $viewer), $alert->context ?? []) : null;

        return [
            'references' => [
                'control_room' => $canOpenAlert ? ($alert->reference_number ?: null) : null,
                'incident' => $canOpenIncident ? ($incident->reference_number ?: null) : null,
                'health_safety' => $canOpenHs ? ($hsDetails['reference_number'] ?: null) : null,
            ],
            'occurred_at' => $canOpenIncident ? $incident->occurred_at?->toIso8601String() : null,
            'linked_access' => [
                'incident' => $canOpenIncident ? 'readable' : 'restricted',
                'control_room' => $alert === null ? 'absent' : ($canOpenAlert ? 'readable' : 'restricted'),
                'health_safety' => $hsEvent === null ? 'absent' : ($canOpenHs ? 'readable' : 'restricted'),
            ],
            'incident' => $canOpenIncident ? [
                'id' => $incident->id,
                'reference_number' => $incident->reference_number ?: null,
                'status' => $incident->status,
                'severity' => $incident->severity,
                'type' => $incident->type,
                'site' => $siteDetails,
                'person' => $incident->client ? [
                    'id' => $incident->client->id,
                    'name' => trim($incident->client->first_name.' '.$incident->client->last_name),
                ] : null,
                'reporter' => $incident->reporter ? [
                    'id' => $incident->reporter->id,
                    'name' => $incident->reporter->name,
                ] : null,
                'narrative' => [
                    'title' => $incident->title,
                    'description' => $incident->description,
                    'location' => $incident->location,
                    'immediate_controls' => $incident->immediate_action_taken ?: $incident->immediate_action,
                    'witnesses' => $incident->witnesses,
                    'potential_severity' => $incident->potential_severity,
                    'potential_consequence' => $incident->potential_consequence,
                ],
                'attachments' => $incident->attachments->map(fn ($attachment) => [
                    'id' => $attachment->id,
                    'name' => $attachment->original_name,
                ])->values()->all(),
                'followups' => $incident->followups->map(fn ($followup) => [
                    'id' => $followup->id,
                    'title' => $followup->notes,
                    'status' => $followup->completed_at ? 'complete' : 'open',
                    'due_at' => $followup->due_at?->toIso8601String(),
                ])->values()->all(),
                'href' => '/incidents/'.$incident->id,
            ] : null,
            'linked_operational_evidence' => $linkedOperationalEvidence,
            'control_room' => $this->presentAlert($alert, $canOpenAlert, $safeAlertContent),
            'health_safety' => $hsDetails,
            'journey_state' => $this->journeyState($incident, $alert, null, $hsFacts),
            'lifecycle' => [
                $this->stage('control_room', 'Control Room', $canOpenAlert ? $alert->reference_number : null, $this->alertState($alert), $canOpenAlert ? '/control-room/alerts/'.$alert->id : null),
                $this->stage('incident', 'Incident report', $canOpenIncident ? $incident->reference_number : null, $this->incidentState($incident), $canOpenIncident ? '/incidents/'.$incident->id : null),
                $this->stage('health_safety', 'Health & Safety', $canOpenHs ? $hsDetails['reference_number'] : null, $this->healthSafetyState($hsFacts), $canOpenHs ? $hsDetails['href'] : null),
            ],
            'next_action' => $this->nextAction($incident, $alert, $hsDetails, $hsFacts, $viewer, $canOpenAlert, $canOpenIncident, $canOpenHs),
        ];
    }

    public function journeyState(
        ?ClientIncident $incident,
        ?ControlRoomAlert $alert,
        ?HsEvent $hsEvent,
        ?array $healthSafetyFacts = null,
    ): string {
        // Existing three-argument callers retain their canonical model behavior.
        // present() supplies a detached snapshot and never consults caller state.
        $hasHs = $healthSafetyFacts === null ? $hsEvent !== null : ($healthSafetyFacts['present'] ?? false);
        $hsStatus = $healthSafetyFacts === null ? $hsEvent?->status : ($healthSafetyFacts['status'] ?? null);
        $handoverStatus = $healthSafetyFacts === null ? $hsEvent?->handover_status : ($healthSafetyFacts['handover_status'] ?? null);
        $hsKnown = ! $hasHs || $healthSafetyFacts === null
            || (($healthSafetyFacts['access'] ?? null) === 'readable' && $this->knownHsStatus($hsStatus));
        if ($incident === null && $alert === null && ! $hasHs) {
            return 'Journey needs review';
        }
        $incidentClosed = $incident === null || $incident->status === 'closed';
        $healthSafetyClosed = ! $hasHs || ($hsKnown && $hsStatus === HsEvent::STATUS_CLOSED);
        $operationalClosed = $alert === null || in_array($alert->status, [
            ControlRoomAlert::STATUS_CLOSED,
            ControlRoomAlert::STATUS_DISMISSED,
        ], true);
        $operationalResponseEnded = $alert !== null
            && in_array($alert->status, [
                ControlRoomAlert::STATUS_RESOLVED,
                ControlRoomAlert::STATUS_CLOSED,
                ControlRoomAlert::STATUS_DISMISSED,
            ], true);

        if ($incidentClosed && $healthSafetyClosed && $operationalClosed) {
            return 'Journey closed';
        }

        if ($alert?->isActionable()) {
            return 'Operational response active';
        }

        if ($operationalResponseEnded
            && ! in_array($incident?->status, ['reviewed', 'closed'], true)
        ) {
            return 'Operationally resolved';
        }

        if ($hasHs && ! $hsKnown) {
            return 'Journey needs review';
        }

        if ($hasHs
            && in_array($handoverStatus, [
                HsEvent::HANDOVER_NOT_READY,
                HsEvent::HANDOVER_AWAITING_ACCEPTANCE,
            ], true)
        ) {
            return 'H&S acceptance pending';
        }

        if ($hsStatus === HsEvent::STATUS_CLOSED) {
            return 'Governance closed';
        }

        if ($hasHs && ($healthSafetyFacts === null
            ? $hsEvent->correctiveActions()->where('status', HsCorrectiveAction::STATUS_COMPLETED)->exists()
            : ($healthSafetyFacts['has_completed_action'] ?? false))) {
            return 'Awaiting independent verification';
        }

        if ($hasHs && ($healthSafetyFacts === null ? $hsEvent->isOpen() : $hsStatus !== HsEvent::STATUS_CLOSED)) {
            return 'H&S governance active';
        }

        if (in_array($incident?->status, ['reviewed', 'closed'], true)) {
            return 'Incident review complete';
        }

        if ($operationalResponseEnded) {
            return 'Operationally resolved';
        }

        if ($incident?->status === 'draft') {
            return 'Incident draft';
        }

        if ($incident?->status === 'submitted') {
            return 'Incident review pending';
        }

        return 'Journey needs review';
    }

    /** @return array<string, mixed>|null */
    private function presentAlert(?ControlRoomAlert $alert, bool $canOpen, ?array $sourceContent): ?array
    {
        if ($alert === null || ! $canOpen) {
            return null;
        }

        return [
            'id' => $alert->id,
            'reference_number' => $alert->reference_number ?: null,
            'status' => $alert->status,
            'severity' => $alert->severity,
            'notes' => $sourceContent['notes'] ?? null,
            'sla_status' => $alert->sla?->getStatus(),
            'playbook' => $alert->playbookRun ? [
                'name' => $alert->playbookRun->playbook?->name,
                'status' => $alert->playbookRun->status,
                'current_step' => $alert->playbookRun->current_step,
                'completed_steps' => $alert->playbookRun->completed_steps,
                'total_steps' => $alert->playbookRun->total_steps,
            ] : null,
            'tasks' => $alert->tasks->map(fn ($task) => [
                'id' => $task->id,
                'title' => $task->title,
                'status' => $task->status,
                'priority' => $task->priority,
                'due_at' => $task->due_at?->toIso8601String(),
                'owner' => $task->assignedTo ? ['id' => $task->assignedTo->id, 'name' => $task->assignedTo->name] : null,
            ])->values()->all(),
            'evidence' => $alert->evidencePacks->map(fn ($pack) => [
                'id' => $pack->id,
                'title' => $pack->title,
                'status' => $pack->status,
                'item_count' => (int) $pack->item_count,
            ])->values()->all(),
            'communications' => $alert->communications->map(fn ($communication) => [
                'id' => $communication->id,
                'subject' => $communication->subject,
                'status' => $communication->status,
                'sent_at' => $communication->sent_at?->toIso8601String(),
            ])->values()->all(),
            'href' => $canOpen ? '/control-room/alerts/'.$alert->id : null,
        ];
    }

    /** @return array<string, mixed>|null */
    private function presentHealthSafety(?HsEvent $event, bool $canOpen): ?array
    {
        if ($event === null || ! $canOpen) {
            return null;
        }

        return [
            'id' => $event->id,
            'reference_number' => $event->reference_number ?: null,
            'status' => $event->status,
            'severity' => $event->severity,
            'handover' => [
                'status' => $event->handover_status,
                'owner' => $event->owner ? ['id' => $event->owner->id, 'name' => $event->owner->name] : null,
                'accepted_by' => $event->acceptedBy ? ['id' => $event->acceptedBy->id, 'name' => $event->acceptedBy->name] : null,
                'accepted_at' => $event->accepted_at?->toIso8601String(),
                'notes' => $event->acceptance_notes,
            ],
            'worksafe' => [
                'notifiable' => (bool) $event->worksafe_notifiable,
                'status' => $event->worksafe_status,
                'reference' => $event->worksafe_reference,
                'notified_at' => $event->worksafe_notified_at?->toIso8601String(),
                'acknowledged_at' => $event->worksafe_acknowledged_at?->toIso8601String(),
            ],
            'investigation' => $event->activeInvestigation ? [
                'reference_number' => $event->activeInvestigation->reference_number,
                'status' => $event->activeInvestigation->status,
                'lead' => $event->activeInvestigation->leadInvestigator ? [
                    'id' => $event->activeInvestigation->leadInvestigator->id,
                    'name' => $event->activeInvestigation->leadInvestigator->name,
                ] : null,
                'due_at' => $event->activeInvestigation->target_completion_date?->toIso8601String(),
            ] : null,
            'href' => $canOpen ? '/health-safety/events/'.$event->id : null,
        ];
    }

    /** @return array{key: string, label: string, reference_number: ?string, state: string, href: ?string} */
    private function stage(string $key, string $label, ?string $reference, string $state, ?string $href): array
    {
        return [
            'key' => $key,
            'label' => $label,
            'reference_number' => $reference ?: null,
            'state' => $state,
            'href' => $href,
        ];
    }

    private function alertState(?ControlRoomAlert $alert): string
    {
        if ($alert === null) {
            return 'not_started';
        }

        return $alert->isTerminal() ? 'complete' : 'in_progress';
    }

    private function incidentState(ClientIncident $incident): string
    {
        return $incident->status === 'draft' ? 'in_progress' : 'complete';
    }

    private function knownHsStatus(?string $status): bool
    {
        return in_array($status, [HsEvent::STATUS_OPEN, HsEvent::STATUS_INVESTIGATING,
            HsEvent::STATUS_CORRECTIVE_ACTION, HsEvent::STATUS_MONITORING, HsEvent::STATUS_CLOSED], true);
    }

    private function healthSafetyState(array $facts): string
    {
        if (! $facts['present']) {
            return 'not_started';
        }
        if ($facts['access'] !== 'readable' || ! $this->knownHsStatus($facts['status'])) {
            return 'blocked';
        }
        if ($facts['handover_status'] === HsEvent::HANDOVER_AWAITING_ACCEPTANCE) {
            return 'waiting';
        }

        return $facts['status'] === HsEvent::STATUS_CLOSED ? 'complete' : 'in_progress';
    }

    /** @return array{label: string, href: ?string, stage: string} */
    private function nextAction(ClientIncident $incident, ?ControlRoomAlert $alert, ?array $event, array $facts, User $viewer, bool $canOpenAlert, bool $canOpenIncident, bool $canOpenHs): array
    {
        // Immediate response takes precedence over report completion and
        // governance acceptance, without offering a source the viewer cannot open.
        if ($alert?->isActionable() && $canOpenAlert && $viewer->canDo('controlRoom.alerts.manage')) {
            return ['label' => 'Continue Control Room response', 'href' => '/control-room/alerts/'.$alert->id, 'stage' => 'control_room'];
        }

        if ($incident->status === 'draft' && $canOpenIncident && $viewer->can('update', $incident)) {
            return ['label' => 'Finish incident report', 'href' => '/incidents/'.$incident->id, 'stage' => 'incident'];
        }

        if ($canOpenHs && $facts['can_manage'] && $this->knownHsStatus($facts['status'])
            && $facts['status'] !== HsEvent::STATUS_CLOSED && $facts['handover_status'] === HsEvent::HANDOVER_AWAITING_ACCEPTANCE) {
            return ['label' => 'Accept H&S handover', 'href' => $event['href'], 'stage' => 'health_safety'];
        }

        if ($canOpenHs && $facts['can_manage'] && $this->knownHsStatus($facts['status']) && $facts['status'] !== HsEvent::STATUS_CLOSED) {
            return ['label' => 'Continue H&S work', 'href' => $event['href'], 'stage' => 'health_safety'];
        }

        if ($canOpenIncident) {
            return ['label' => 'View incident', 'href' => '/incidents/'.$incident->id, 'stage' => 'incident'];
        }

        if ($alert !== null && $canOpenAlert) {
            return ['label' => 'View alert', 'href' => '/control-room/alerts/'.$alert->id, 'stage' => 'control_room'];
        }

        if ($canOpenHs) {
            return ['label' => 'View H&S event', 'href' => $event['href'], 'stage' => 'health_safety'];
        }

        if ($this->journeyState($incident, $alert, null, $facts) === 'Journey closed') {
            return ['label' => 'Journey closed', 'href' => null, 'stage' => 'complete'];
        }

        return ['label' => 'No action available for your role', 'href' => null, 'stage' => 'blocked'];
    }
}
