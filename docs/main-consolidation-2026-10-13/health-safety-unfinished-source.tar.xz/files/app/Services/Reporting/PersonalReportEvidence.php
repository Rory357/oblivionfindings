<?php

namespace App\Services\Reporting;

use App\Domain\SecurityDevices\Models\DeviceAssignment;
use App\Models\ClientGeofenceMonitor;
use App\Models\ClientGeofenceRule;
use App\Models\ClientGeofenceRuleVersion;
use App\Models\ControlRoom\Signal;
use App\Models\ControlRoom\SignalSource;
use App\Models\ControlRoomAlert;
use App\Models\FleetSignal;
use App\Models\FleetTelemetryEvent;
use App\Models\LoneWorkerSession;
use App\Services\CurrentAuthorizationReads;
use App\Services\HealthSafety\LoneWorkerSessionAccessService;
use Carbon\CarbonImmutable;
use Illuminate\Support\Facades\DB;

/** Read canonical retained evidence; never replay signal projection or start collection. */
final class PersonalReportEvidence
{
    public function clientAlert(ControlRoomAlert $alert, DeviceAssignment $assignment, CarbonImmutable $from, CarbonImmutable $to, ReportSourceEvidence $evidence): bool
    {
        $origin = $alert->originSignal;
        if (! $origin || (int) $origin->client_id !== (int) $assignment->assignable_id || (int) $origin->site_id !== (int) $assignment->custody_site_id
            || (int) data_get($alert->context, 'signal_id') !== (int) $origin->id) {
            return false;
        }
        $fleetId = data_get($origin->normalized_data, 'fleet_signal_id');
        if (! $fleetId || (int) data_get($alert->context, 'normalized_data.fleet_signal_id') !== (int) $fleetId) {
            return false;
        }
        $fleet = FleetSignal::find($fleetId);
        $event = $fleet ? $this->event($fleet, $assignment, $from, $to, $evidence) : null;
        if (! $fleet || ! $event) {
            return false;
        }
        $evidence->record($fleet);
        if (isset($fleet->payload['assignment_id']) && (int) $fleet->payload['assignment_id'] !== (int) $assignment->id) {
            return false;
        }
        if ($fleet->signal_type === 'resident.zone_breach') {
            return $this->zone($fleet, $assignment, $from, $to, $evidence) !== null;
        }
        if ($fleet->signal_type === 'resident.fall_detected') {
            return $event->event_type === 'fall_detected' && (int) data_get($fleet->payload, 'assignment_id') === (int) $assignment->id;
        }

        return in_array($fleet->signal_type, ['sos', 'panic', 'resident.sos'], true) && in_array($event->event_type, ['sos', 'panic'], true);
    }

    public function zone(FleetSignal $signal, DeviceAssignment $assignment, CarbonImmutable $from, CarbonImmutable $to, ReportSourceEvidence $evidence): ?array
    {
        $event = $this->event($signal, $assignment, $from, $to, $evidence);
        $monitor = ClientGeofenceMonitor::find(data_get($signal->payload, 'client_zone_monitor_id'));
        if (! $event || ! $monitor || (int) $monitor->assignment_id !== (int) $assignment->id || (int) $monitor->consent_id !== (int) $assignment->consent_id
            || $event->occurred_at->lt($monitor->started_at) || ($monitor->ended_at && $event->occurred_at->gte($monitor->ended_at))) {
            return null;
        }
        $rule = ClientGeofenceRule::find($monitor->rule_id);
        $version = ClientGeofenceRuleVersion::find($monitor->version_id);
        if (! $rule || ! $version || (int) $rule->client_id !== (int) $assignment->assignable_id || (int) $rule->site_id !== (int) $assignment->custody_site_id || (int) $version->rule_id !== (int) $rule->id) {
            return null;
        }

        foreach ([$signal, $monitor, $rule, $version] as $record) {
            $evidence->record($record);
        }

        return ['reference' => 'fleet_signal:'.$signal->id, 'date' => $event->occurred_at->setTimezone('Pacific/Auckland')->toDateString(),
            'resource' => $assignment->device->name, 'site' => null, 'status' => 'Reported zone breach', 'observed_at' => $event->occurred_at->toISOString(),
            'received_at' => $event->received_at?->toISOString(), 'event_type' => $signal->signal_type, 'rule_id' => (string) $rule->id,
            'geometry_version' => (string) $version->id, 'accuracy' => $event->accuracy_m];
    }

    public function staffAlert(ControlRoomAlert $alert, LoneWorkerSession $session, ReportSourceEvidence $evidence): bool
    {
        return DB::transaction(fn () => CurrentAuthorizationReads::within(function (CurrentAuthorizationReads $reads) use ($alert, $session, $evidence): bool {
            if (! app(LoneWorkerSessionAccessService::class)->alertMatchesSession($alert, $session, $reads)) {
                return false;
            }
            $origin = $reads->query(Signal::query())->findOrFail($alert->origin_signal_id);
            $source = $reads->query(SignalSource::query()->select('id', 'slug'))->findOrFail($origin->signal_source_id);
            $evidence->record($origin);
            // Heartbeat and collector counters do not change the source's identity.
            $evidence->record($source);
            $evidence->record($session);

            return true;
        }));
    }

    private function event(FleetSignal $signal, DeviceAssignment $assignment, CarbonImmutable $from, CarbonImmutable $to, ReportSourceEvidence $evidence): ?FleetTelemetryEvent
    {
        if ((int) $signal->device_id !== (int) $assignment->device_id) {
            return null;
        }
        $event = FleetTelemetryEvent::whereKey($signal->source_event_id ?: data_get($signal->payload, 'event_id'))
            ->where('device_id', $assignment->device_id)->where('consent_blocked', false)->whereBetween('occurred_at', [$from, $to])->first();
        if (! $event || (int) $event->asset_id !== (int) $signal->asset_id || ! $event->occurred_at->equalTo($signal->occurred_at)) {
            return null;
        }

        $evidence->record($event);

        return $event;
    }
}
