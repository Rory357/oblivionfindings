# Ordinary chemical exposure audit reader — R2 finite handoff

SOURCE CANDIDATE ONLY. Shared consumers and route delegation are UNAPPLIED. The owned two services and new whole suite are saved in the isolated H&S checkout. Three file-only syntax checks passed; every native/HTTP/DB behavioural check and Pint remains UNRUN. This document is neither a freeze nor runtime admission.

## Current exact unit

- Audit access: app/Services/HealthSafety/ChemicalExposureAuditAccessService.php — 7D6D8B771C64F8F3141A61ABF515F643665E4EF6687C5B3D755567372CC70250.
- Copied source projection: app/Services/HealthSafety/ChemicalExposureSourceProjectionService.php — 9AB0E5926AA6ECE64FF8D6CA9F519581DCC5095DA69F21070A7A01452D17E55D.
- New complete tests/Feature/HealthSafety/ChemicalExposureAuditReadBoundaryTest.php — F5142FEF384A669DFEA7BDF3DE54F07638BFB4F2598B09196C4921822E64D221; 23 public test declarations, not measured cases or passes.
- Four-file semantic proposal: CHEMICAL-EXPOSURE-AUDIT-CONSUMER-R2-UNAPPLIED.patch — CA798CCA55F002FFBE94FD3B60DB4600BBE0AAA4EE33DC036D82E748D23DB6F0.
- Separate three-reader route prerequisite: CHEMICAL-EXPOSURE-AUDIT-READER-ROUTES-R2-UNAPPLIED.patch — 10DD1F7F7A318850E77F7E8A139519C3DE32D1519DABDD9573332C24E8464797.

The actual current shared bases, source/proof dependencies, migration inputs, complete-suite hashes and historical pins are recorded independently in storage/logs/chemical-exposure-audit-r2-source-candidate.json. This is a selected source snapshot, not a dependency-complete runtime freeze. The former exact 5FB8123B proposal is retained as CHEMICAL-EXPOSURE-AUDIT-CONSUMER-R2-5FB8123B-SUPERSEDED.patch. A7CDDC73/81393B63 owned source and 463A6DFA18-method suite pins are explicitly superseded evidence, not relabelled as current.

## APIs and current admission

AuditAccess retains materialize(User, callable, ?HealthSafetyReadContext): mixed, scope(Builder, ?User, ?HealthSafetyReadContext): Builder, canPresent and currentForPresentation. The callback returns only detached scalar/array data. Supplied context requires matching viewer, active actual connection/lifetime and the complete prepared permissions; it never silently refreshes a missing/expired context. Legacy no-context query/presentation grants no exposure whitelist. Escaped contextual builders refuse execution outside lifetime.

Materialization independently requires freshly prepared audit.viewAny. Unrelated BoardPack/HR/IT/Security/medication auditors retain their existing authority and do not inherit internal H&S staff eligibility. Only the exposure branch consumes the canonical dual hazards.view AND hr.wellbeing.view, current internal HR/approved active Site and original source/context checks. Historical worker identity is distinct from current viewer or recorder. No self grant, retired-Site bypass or permission union capability grant is introduced.

SourceProjection retains readableHsEventIdsInContext and forHsEvent. Recorded copied HSE requires the actual immutable200300 marker matching root/event/version/revision, destination sourceProofForAuditSubject and exact current Source proof equality. Tuple resemblance alone cannot certify a factory HSE or damaged marker. Genuine unlinked legacy stays unknown; linked legacy original-context uncertainty remains sealed. It preserves the absolute recorded source instant and does not invent a civil timezone.

The additive pure isCanonicalSourceRefusal(ValidationException): bool classifies only a sole source key containing exactly one of the eleven current fixed SourceService body-admission/legacy-noop refusal messages. It conveys no authority or source token. Unknown/mixed validation rethrows. Recognised refusal withholds the affected audit row or copied projection and reasserts callback lifetime; healthy ordinary/private neighbours survive. Any future changed canonical messages need explicit review rather than a catch-all source validation fallback.

## Final query stability

Private discovery is bounded identity-only under independent caller filters; names/body search follows current canonical admission. Candidate narrowing never replaces complete known-private SQL denial. Captured private audit IDs cannot become ordinary through same-session identity declassification.

Canonical source, retained original contexts, accepted versions/receipts/intents/audits, marker and actual source/child edges are proved before their callback-local opaque fingerprints are captured and are re-proved afterwards. These hashes are stability predicates, never replacement grants, retrospective source certification or absolute database tamper-proof cryptography. Fixed current Site/Client/source predicates precede private bodies and related names.

Final count/row/name-search/options SQL binds exact audit identity types/values, byte-exact facts and admitted graph fingerprints. Anti-exists clauses reject novel owning-root origins. Additional subject_sets match SourceService's ANY retained exact exposure/review/followup/evidence kind+source-ID predicate across parents, rejecting foreign-parent ownership or novel membership at the final statement. Direct version/receipt subjects also bind their underlying actual kind+ID. No foreign retained body is hydrated to discover this conflict; metadata identity is sufficient.

The actual physical MySQL isolation, lock interaction, multi-query pagination/CSV behavior and cost remain unverified. The final per-statement predicates are designed to fail closed on observed mutation; no source-cache/global-table whitelist or query ceiling change is included.

## Shared proposal and route prerequisite

The four unchanged observed files are AuditLogViewService and AuditLogController, Settings/AuditLogSettingsController, Hr/AuditController. Pure text application of all14 hunks matches the four intended projections against the exact current bases; no shared live file was changed. This is not PHP execution or behavioural proof.

The service adds materialize delegation and optional same active context for query/present/filterOptions/stats. Independent module/action/date/subject/actor/Client filters precede discovery; name search follows it. Existing BoardPack conjunction, sanitizer, field shapes, ordinary permissions and CSV formula/header behavior remain. CSV rows become detached cell arrays inside the callback; the stream retains no model, context, builder or delayed generator.

All three controllers compute under one current callback, including validation after fresh authority. General logs/filter_options, settings events/users/stats, and HR logs/actions/modelTypes/users are Inertia::always on the already eager detached values. The HR logs wrapper at proposal405 is corrected. HR show returns currently materialized entries. This preserves current error/eager fanout and prevents auth-only partial requests from retaining old private rows/options/stats.

Actual page components are resources/js/pages/audit/index.tsx, resources/js/pages/settings/audit-logs.tsx and resources/js/pages/hr/settings/audit-log.tsx. Root independently found that they derive displayed bodies from fresh rows; settings/HR retain expanded ID sets only, rather than copied selected-log bodies.

EnsurePermission and live routes are untouched. The separate proposal delegates only duplicate audit.viewAny middleware on /audit-logs, /settings/audit-logs and /settings/audit-logs/export to the same fresh canonical materializer. Auth, enclosing policies, HR hr.settings.manage and every other permission remain. Shared route-owner allocation is still required. Warmed-false real HTTP restoration tests require that explicit route successor; no middleware suppression, skipped case or local substitute demonstrates it.

## Meaningful complete feedback

The new whole23-method suite uses the actual physically committed guarded ChemicalExposureCommandTestCase. It covers final SQL identity/body/Client/name mutation, JSON missing/null/type differences, case/trailing-space rewrites, source/root/current HR/Site/original Client withdrawal and exact restoration, accepted version damage, real no-op new origin, real destination/marker absence and damage, private/unrelated neighbours, default boundaries, current warmed audit grants, and actual general/settings/HR partial HTTP outputs.

Five successor cases cover canonical sealed refusal beside healthy neighbours and copied HSE; noncanonical/mixed validation; late foreign-root version insertion and receipt rebind; foreign child exact-kind/ID version/receipt rebind with restored healthy parity; and HR copied exposure rows on a filters-only partial after private-grant withdrawal/restoration.

The selected manifest retains all12 earlier complete audit files unchanged and adds this whole suite: 13 files,155 public methods plus4 Pest declarations =159 declarations. Counts are source declarations, not executed cases. Private source/evidence/original-context/destination/physical concurrency owning suites and unchanged query-budget feedback remain required in the combined native gate. No filter-only acceptance or threshold relaxation.

## Verification, limits and distinct held families

Actual receipt storage/logs/chemical-exposure-audit-r2-source-syntax.json records php84 -n -d memory_limit=64M -l on precisely the two owned services and new suite. All3 exited0 with exact pre/post hashes unchanged. No application bootstrap, DB, native PHPUnit, Pint, resource/process probes or other parser worker ran; peak memory was not measured.

Independent read-only reviewer first_aid_privacy_repairs checked exact7D6D8B77/9AB0E592/CA798CCA/F5142FEF. It found the prior source-refusal neighbour abort, foreign-parent retained identity gap and missing HR Always wrapper source-closed, with no further concrete defect in this finite allocation. That source review is not runtime acceptance.

NEW risk acceptance-family recognition and association-recovery picker/writer integration remain held/unmounted and outside this successor. No RiskAcceptance class/nested guard, AuditLogger/global User/lock helper or recovery selector was changed. This ordinary audit reader unit can be considered for existing identifiable exposure rows while those new writers remain unmounted; it does not certify their future audit family. Copied HSE Tasks/risk family mounting, private HTTP writer activation, physical schema/delivery acceptance and native performance gates remain separate reviewed prerequisites.
