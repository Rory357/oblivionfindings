# Private exposure destination composition — 12 October 2026

Status: ISOLATED_SOURCE_COMPOSITION / EXECUTABLE_CHECKS_UNRUN / PRIVATE_TRANSPORT_UNMOUNTED. The complete goal remains active.

The reviewed three-service proposal `CHEMICAL-EXPOSURE-DELIVERY-CONFIRMATION-UNAPPLIED-2026-10-12.patch` (C7AB36AC8110B21F0DF46E7CD44212ECFFEDC40D71DC30EEB1F79EC42AA3F1E2) is now composed in the isolated implementation. The proposal file is retained as historical review input; its filename is not the current adoption status. No routes, observer dispatcher, notification common query, Tasks provider, private aliases, MAIN checkout or private risk writer were mounted by this unit.

## Actual changes

- ChemicalExposureDeliveryService accepts optional expectedExposureId. The exact initial minimal outbox identity query constrains that root before private source/body or superseding writes. Existing callers without the optional argument retain their signature and policy.
- ChemicalExposureHsEventDeliveryService propagates the exact root and adds read-only confirmation in the caller's active CommandAccess context. It proves original source/acceptance, exact identity/time-only destination projection, immutable marker/audit and current source snapshot before reading independent response fields. An absent destination is unconfirmed; an unproved retained copy is refused. The actual severity floor and independent ownership/closure/WorkSafe decisions remain binding.
- ChemicalExposureFollowupDestinationService propagates the root and adds same-context confirmation. Its named recipient independently prepares current authority and original source context. The actual deterministic database notification identity/payload and current inbox preference are checked; presence, read flag and follow-up completion remain distinct. Existing public confirmation retains its six fields. A verified existing inbox may be reconciled despite opt-out; this does not create another message.

The delivery workspace's fresh post-commit inspection can now call these actual service methods. HSE presence still returns href:null and the separate hse_read_composition_unmounted reason. No unmounted or merely guessed usable link is exposed. Expected-root contract detection is not proof of destination presence or user access.

## Review and remaining prerequisites

Root read the concrete destination identity predicates, marker and source snapshot checks, optional-root propagation, independent recipient callback, current preferences, public six-field shape and detached UI contract. B confirmed stable proposal bases; A kept the three owner files stable during apply. These are source observations, not syntax or execution evidence.

The original-context-before-current-root-body proposal remains unapplied. Both Reader.collection and permanent Workspace.index require original-context admission before private date/body/count refinement and final source-set/root-fact checks. Root found that a final count over only previously admitted IDs misses a newly inserted in-scope source after the final identity read. A prepared a same-statement predicate proving absence of new scoped identities and equality to the exact known-fact count, including initially empty scope. Root inspected its actual query-node structure; native isolation/locking and current-client mutation behavior remain unverified. A is correcting the separate permanent Workspace.index materializer before those proposals are composed.

Legacy incident pointers with no retained original Client context must stay unconfirmed and sealed. Their explicit association reconciliation/recovery workflow remains required; today's Client tuple cannot prove the old association, and withholding cannot silently become permanent lost functionality.

The complete private HTTP composition, full HSE source-family/child/risk admission and all preparation origins, shared audit/inbox/Tasks/preference catalogue/after-commit dispatch, physical migrations/rollback, native/component/type/build/browser/role/accessibility/query-cost/provider/hardware evidence remain open. The historical124-query observation still exceeds the unchanged<100 ceiling. No performance threshold or permission grant changed.

## Permanent index availability presentation

Root's TypeScript contract and actual permanent index now accept the agreed unavailable envelope separately from restricted permission. Original association unknown, original-context access denied and damaged source history receive distinct plain-language explanations. In every unavailable state retained identities, Site choices, private dates/filters, private open actions and counts are withheld, even if old readable props are retained in memory. The meter shows Unconfirmed and focuses the in-page explanation. The independent fresh capture flag remains usable; no saved read is inferred from capture.

One whole withdrawal/restoration UI case extends the existing workspace suite to13 declarations and the eight-file private frontend footprint to52. The original assertions remain; all declarations are UNRUN. The corresponding backend Workspace envelope remains an UNAPPLIED owner proposal. Frontend source preparation is not proof of the private route or end-to-end workflow.

Automatic approval review previously rejected outgoing coordinator messaging for unverifiable human authorization and the additional private-audit guard as a possible bypass. Existing approval questions remain pending. Neither action was retried or installed indirectly; the guard and private risk writer remain unmounted. The shared runtime HOLD remains in force; this source unit launched no PHP/Pint/Node/test/database/browser/process/Git jobs.

The finite before/after owner pins and composition status are recorded in `storage/logs/hs18-delivery-service-composition-2026-10-12.json`. They are not a complete candidate freeze or acceptance result.

