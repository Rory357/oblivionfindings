# H&S command source composition: bounded preparation

Status: READ_ONLY_SOURCE_REVIEW. Product implementation rejected by automatic approval review; no product files changed. No new native test suite authored. No PHP syntax, native, application, database, storage, queue, browser, build, or process checks performed for this unit. This is neither a source freeze nor release acceptance.

Workspace: `C:/Users/steph/.codex/worktrees/health-safety-workspace/oblivionfindings`. One operating organisation, ordinary capabilities and approved Sites; no tenancy boundary added.

## Automatic review boundary

The attempted addition of `HsSourceCommandContext.php` and `HasHealthSafetyCommandSourceGuard.php` was rejected. The review reason was: "This adds complex authorization and mutation-guard infrastructure affecting security-sensitive H&S writes, but the trusted user transcript does not explicitly authorize this exact implementation or its broad side effects."

Both proposed files were confirmed absent after rejection. No alternate tool, local subclass, bulk-write replacement, global query hook, or substituted infrastructure was used. Root is seeking explicit human approval for the bounded security implementation. Coordinator allocation alone has not been treated as overriding this rejection.

## Exact intended scope and side effects

Four controllers: `HsInvestigationController`, `HsCorrectiveActionController`, `HsCorrectiveActionEvidenceController`, `HsWorksafeDecisionController` in `app/Http/Controllers/HealthSafety`.

Two request transport seams in `app/Http/Requests/HealthSafety`: `UploadHsCorrectiveActionEvidenceRequest` and `RecordHsWorksafeDecisionRequest`. Store/seed requests already authorize transport and validate scalar IDs without private existence queries; those two request files need no change.

Five reachable services in `app/Services/HealthSafety`: `HsInvestigationService`, `HsCorrectiveActionService`, `HsCorrectiveActionOwnershipService`, `HsCorrectiveActionWorkspace`, and ONLY `HsEventService::recordWorksafeDecision` plus its reachable compatibility helpers. The held protected Response/Journey/recordEvent implementation remains unchanged.

Six existing models in `app/Models`, opt-in instance changes only: `HsEvent`, `HsInvestigation`, `HsCorrectiveAction`, `HsRecommendationDisposition`, `HsCorrectiveActionOwnerChange`, `HsAttachment`. Proposed new trait: `app/Models/Concerns/HasHealthSafetyCommandSourceGuard.php`. Existing model class, table, casts, morph identity, lifecycle events, audit observers, append-only owner history, and null/default caller behavior must remain. Proposed new source-owned helper: `app/Services/HealthSafety/HsSourceCommandContext.php`.

No changes to routes/middleware, shared authorization evidence, user/role/HR rules, Intake/BindingSql, schema/migrations, CR consumers, other reporting services, or Tasks. No new permission grants. Whole command closure must preserve current lifecycle/separation, receiver eligibility, idempotency/receipts, validation/flash, rollback, and statutory WorkSafe decisions.

## Existing canonical API

`HealthSafetyReadContext::within` materializes detached results only. `consumeSourceViewer` retains ordinary source policies rather than imposing a blanket staff gate. Its complete prepared FA/Restraint/Injury vector includes the incident source's four existing keys: `incidents.viewAny`, `incidents.viewAssigned`, `hr.cases.view`, `healthSafety.viewAllSites`.

`IncidentHsEventSourceReadService` supplies `applyEventScopeInReads`, `incidentQueryForEventInReads`, `applyIncidentScopeInReads` and `childQueryInReads`. The same active context exposes `applyIncidentEventScope`, `applyIncidentSourceScope`, `incidentQueryForEvent`, and `reconsumeIncidentPredicate(actual, original)`. Reuse the earliest cached original source predicate; do not rebaseline changed roots or recapture the actor.

The source helper's original permission equality covers only those four incident keys. Current command permission/Site evidence used by the existing command must also remain unchanged on its actual body SELECT/write. Any new conjunct is evidence equality after canonical authority, never a substitute policy engine or grant.

`ROOT_COLUMNS` excludes `investigation_status` and WorkSafe compatibility fields. `EVENT_META` excludes WorkSafe mirrors too. Legitimate mirror writes therefore require no removal/replacement of original source fingerprints.

## Concrete prebody and mutation trace

`HsInvestigationController` presently resolves event outside live HSCtx, accepts implicit full models, and checks stale child FK. `HsInvestigationService::create` locks full event; `start`/`recordFindings` update supplied models; aggregate transitions requery parent and investigation. Recommendation disposition reloads children and returns eager fresh models. Parent status synchronization lazy-loads event. The incident mirror at lines 688–690 changes `investigation_status` only. All these actual SELECTs, counts, refetches, and writes need the same original predicate.

`HsCorrectiveActionController` has the same standalone source guard and implicit model binding. Complete/verify/close/rework deliberately use strict Site scope (`[]` bypass); store/start retain canonical bypass. Preserve that distinction. `HsCorrectiveActionService` rehydrates recommendation/disposition/action, legacy source task and alert, lazy-loads event/owner history, checks attachments/counts, updates models, and returns `fresh` models with eager relations. Transfer must use exact task/alert parent and retain its actual existing domain authority; the H&S source predicate is not a CR read grant.

`HsCorrectiveActionOwnershipService` reloads action before opening its own Reads, reloads event and request UUID history, and uses a standalone source query for actor/recipient eligibility. Preserve independent current recipient proof; the initiating actor's context cannot authorize another person. Its append-only owner-change schema and notification/receipt contracts stay intact. Default owner/helper behavior cannot silently change to inferred actor authority.

`HsCorrectiveActionWorkspace` eagerly loads investigation and source CR task/alert before matching the foreign FK or checking independent CR access, and subsequently loads attachments/audit/users without the original source on each SELECT. Post-presentation redaction is insufficient. Its presenter also calls `hasBeenOwnedBy`, which can issue a separate history query unless the protected history was already materialized.

`HsCorrectiveActionEvidenceController` owns upload/delete and rollback restoration, but full event/action/attachment models are already route-bound. Its fresh attachment query is ID-only before checking morph/FK. The download callback runs after the transaction ends. Actual file SELECT must constrain exact parent/FK before filename/path, participant authority must remain current, and source lifetime must cover the underlying storage stream. A new response must compare live account and exact admitted descriptor at send time; no expired proof reuse or original byte/digest certification.

`HsWorksafeDecisionController` resolves event without context, then `HsEventService::recordWorksafeDecision` full-loads incident and event, saves/refetches event repeatedly, queries released-by name, full-loads legacy notifiable rows, and quietly mirrors fields. Protect that branch only; held `recordEvent` and default/system behavior stay untouched.

Upload request currently requires `event instanceof HsEvent` and `action instanceof HsCorrectiveAction` and checks participant after implicit hydration. WorkSafe request authorizes from the warmed request actor before controller. Raw bounded positive IDs and identical current controller authority are required; route capability middleware remains unchanged and warmed-false middleware restoration remains a separate explicit transport prerequisite.

## Framework constraints verified from installed source

`CurrentAuthorizationReads::query` installs `beforeQuery -> lockTree`; it sets `FOR SHARE NOWAIT` on outer and nested wheres/unions. It does not traverse `fromSub`. Restore ONLY the command's exclusive outer mutex in a later callback, after current-read callbacks. Do not assume `lockForUpdate()` chaining preserves that mutex.

`whereIn(query)`/`fromSub` compile subqueries early. Actual outer compilation must reconsume the ORIGINAL compiler/lifetime/day guard, with every original database predicate still in SQL. Nested EXISTS retains its builder. Escaped predicates embedded in another actor's fresh query must fail their original lifetime at compilation.

`Model::save` creates an internal update builder. Existing `AuditableChanges` observers attach to exact model classes. Local subclasses risk different observer/class/morph identity; replacing model writes with bulk updates bypasses events. Proposed opt-in instance seam must guard actual `setKeysForSaveQuery`, retain canonical events, and refuse zero-row/changed-row success through an exact persisted-result proof before returning.

`SoftDeletes::runSoftDelete` also uses `setKeysForSaveQuery`, but ignores affected-row count and fires `trashed` even on zero rows. Evidence deletion needs explicit final deleted-state/source proof, not an inferred successful model result. Leave default delete/append-only history behavior unchanged.

New model INSERT must retain normal create/events, original exclusive parent mutex, and original reproof immediately before/after (including observer mutation) with transaction rollback. WHERE clauses on ordinary INSERT do not constitute a source predicate. Native concurrency and MySQL same-target materialized UPDATE behavior remain unverified.

## Whole native fixture plan (not authored; not execution evidence)

Use actual `IncidentIndependenceTestCase`/`IncidentRoutingTestCase` with UTC frozen instant, real schema, current approved profiles, permission overrides, accepted Intake commands and actual Journey source/backlinks. Do not forge source receipts, nullable Site authority or typed history. Domain assurance fixtures must use real authenticated transitions and distinct submitter/reviewer/approver. Existing Bus fake only covers the fixture's actual incident owner dispatcher.

Meaningful cases include named D05 denial versus assignment-only permission, healthy neighbour, current RBAC/HR/Site withdrawal and restoration, original policy retention, raw ID/foreign child before body, first/nested service SELECT interleaving, actual mutation interleaving, actor permission change at write, exact exclusive SQL lock shape, metadata/path rebind, complete-evidence preservation, actual storage-stream account/source withdrawal, audit/save veto rollback, expired embedded predicates, legitimate investigation_status/WorkSafe mirrors, and unchanged default/source-unrelated contracts. Observe each family's real private columns; identity-only reads must not inflate or evade hydration assertions. No middleware suppression, filtered tests or query-ceiling weakening.

Preserve all 13 existing whole selected suite files: 12 PHPUnit classes have 144 `test_` declarations; `HsCorrectiveActionSeparationTest` is an existing Pest file with one `test(...)` declaration, not absent/zero tests. Actual discovered/expanded cases and outcomes remain UNRUN. New intended `HsCommandSourceAdmissionTest` has zero authored declarations at this checkpoint.

## Observed product bases (not a freeze)

Paths below are relative to the isolated workspace. These hashes describe reads before implementation; other owner's shared dependencies may legitimately change.

- `app/Http/Controllers/HealthSafety/HsInvestigationController.php`: A067911BB49950806AF1A1AF58F23A1CA00D9CEDC25A75ED13E78AFB119DE5E1
- `app/Http/Controllers/HealthSafety/HsCorrectiveActionController.php`: 3FD564790AB12C4133AFEEE77AD4EC00BD132F02CAB586C146EC1853FCB7267C
- `app/Http/Controllers/HealthSafety/HsCorrectiveActionEvidenceController.php`: DB07999436A3EFF093FD067B637AEEA204EE1A57240B26087BECF8318A51248C
- `app/Http/Controllers/HealthSafety/HsWorksafeDecisionController.php`: 51077C85EF969B7FDC7D52FAE7C5E6428C87D6D403CAB01262BD9EDCC16F1B0B
- `app/Http/Requests/HealthSafety/UploadHsCorrectiveActionEvidenceRequest.php`: D20644228D9FFC491C44F0D11A2040E8ADF56496AB4F1FE3ABE272E612B5C5F3
- `app/Http/Requests/HealthSafety/RecordHsWorksafeDecisionRequest.php`: BC87E718430D3F631E1F2529EF19CAB89BF29B5426B21571BAD5005EE03046BC
- `app/Services/HealthSafety/HsInvestigationService.php`: 089D0B74DC06386C05AF626423A4ADF9F1F47309198F7CB69F19DC97FC49E2B0
- `app/Services/HealthSafety/HsCorrectiveActionService.php`: 5C926A358707996E3572820314365BA89B75605ED3684756D45BEBE150440167
- `app/Services/HealthSafety/HsCorrectiveActionOwnershipService.php`: 49DC69890C5BB8182F0FCDD1ADD3C8919B52C12EF6CCE0188BFE6619782911B3
- `app/Services/HealthSafety/HsCorrectiveActionWorkspace.php`: DAE123E49EC0D8961C784414043EA4EB2338388D8EC0E4EF93315D5B3D5F654E
- `app/Services/HealthSafety/HsEventService.php`: DD54CCC58CFCC05A5BA9F4F6719D1DE7DC3743A6C1C79DC2198FC3069797E610
- `app/Models/HsEvent.php`: D943BD4C77A4CFD38011E8AD8D9401D3A025611FF7512DD73100CD8F90B61C44
- `app/Models/HsInvestigation.php`: 9B03ED8DE55E132E63A3E7C36505C263C3734AE886101D64BF7171E1DB88CF32
- `app/Models/HsCorrectiveAction.php`: 495CFD84B4DCAAC9E84303934AB7764BE933782B33B44FF9007E7F99818D3C06
- `app/Models/HsRecommendationDisposition.php`: 6A7488BB6478A10AA93771A274B12586D1B4755C28AC01D7399EBBAC8AB7F0B2
- `app/Models/HsCorrectiveActionOwnerChange.php`: 64E58C6D163630AB3D4CA365BEDA8F3ABFFCD49237E9EDCDFF7F1724B132F422
- `app/Models/HsAttachment.php`: 20AB3D42943A0DC00C32BEE7E6FF790B32D95B3EBCA8880C1E1FF283F03F3E72
- `app/Services/HealthSafety/HealthSafetyReadContext.php`: FA34CF35A6F9C665D55E106576F1FDAFC833A0D0C9C2148802F63E0138A8522F
- `app/Services/HealthSafety/HsEventAccessService.php`: FF80070991AA7D7DA2CDB25011A9E97DEDDE30279D7BE0F51E91DDAA909BEA36
- `app/Services/Incidents/IncidentHsEventSourceReadService.php`: 6BC4947FE69685F132FC4781E9C07D455C4A0055A005774B9DFAF9D58DB37F10
- `app/Services/CurrentAuthorizationReads.php`: 38D31FCB8D24EB9B319045195E239E8834231F532E7BC782AB2B09E781F30413
- `app/Services/AuthorizationEvidenceLockService.php`: 1BCB05D64D5EB3112BAFDF901B4A5253D3329F7BB13D98E0C8CBD2FC76FFB3EC
- `app/Services/UserSiteAccessService.php`: 16289962A57C93E3858D3740149043F1FE3692F48F963F497BBE3D9C42E33B2E
- `app/Domain/Hr/Services/HrCurrentStaffService.php`: C8DDA69E30BE46DCEB53124B44A85BBF41CBD249A81A3D42217CB15066B31E54
- `app/Services/Incidents/IncidentIndependenceIntakeService.php`: 3AFD37C1310357BAE07EC3B3EFF2F8BE70017186B4BB43FDB5AE9FBA072A31E7
- `app/Http/Controllers/Concerns/ServesPrivateAttachments.php`: 49388C1C0CAA94A9F96C5AD30F6848E7C15B8847A9648B28B72B991266232857
- `routes/health-safety.php`: 7E9873DDC9D4558CD60CEEA88F8F49D009D2141F659A60B35CC08C24FF760BC1
- `tests/Feature/Incidents/IncidentIndependenceTestCase.php`: C45CDD4584B3F2892ABFA0D1C57260847656D475CAF6D3277D35B583321471CA
- `tests/Feature/Incidents/IncidentRoutingTestCase.php`: 754F16BA4D0A74A52F04A79E626315F9277849B0532DE4F6FC22B5025AC3808F

## Explicit remaining boundaries

The requested command implementation is unfinished. Current source admission without a live same-callback context remains fail-closed for incident-derived paths. This document does not turn a temporary admitted model into a command certificate. Independent recipient notification/current-source acceptance, CR copied-body access, stale middleware restoration, physical stream-after-headers behavior, original byte provenance, native MySQL locking/derived mutation semantics and the unchanged historical query ceiling remain open. Nothing in this checkpoint admits native work or changes shared owner files.
