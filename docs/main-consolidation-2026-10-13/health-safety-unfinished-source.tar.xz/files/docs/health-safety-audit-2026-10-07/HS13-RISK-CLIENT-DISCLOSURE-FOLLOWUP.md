# HS13b Risk Client disclosure follow-up

Status: read-only follow-on proposal, 8 October 2026. No generic Risk policy change or database verification is claimed by this document. The current First Aid-derived source-intersection candidate is separate and awaits its combined native gate.

## Retained authority

Risk assessments are source-owned safety records. Existing `hazards.view`/`hazards.manage` plus canonical approved Site provenance intentionally authorize generic Client-attached Risk content and commands. `UserSiteAccessService::effectiveHsRiskAssessmentSiteId`, `assertCanAccessHsRiskAssessment`, and `applyHsRiskAssessmentSiteScopeForSiteIds` define that boundary. `HsRiskAssessmentSiteAccessTest` explicitly tests a local Client risk with H&S permissions, without a Client profile grant.

Do not replace this with a blanket ClientPolicy requirement on every Risk row, note, history entry, evidence download, or lifecycle command. Retain source context IDs and Client filter semantics until a concrete preserve-context form/command protocol is agreed. Risk-owned narrative and uploaded evidence are not automatically copied Client clinical content. Known First Aid-derived provenance has its separate binding source-read intersection.

## Confirmed copied identity gap

- `app/Support/HealthSafety/RiskAssessmentPresenter.php::siteScopedPickers` returns every same-Site Client ID/name, regardless of independent Client permission. This is consumed by the permanent register/page, Site profile Risk partial, and Client profile management picker.
- `RiskAssessmentPresenter::attachedTo` copies Client `full_name` into register/detail identity. `formPrefill` retains the Risk-owned context ID.
- `RiskAssessmentWorkspaceConnectionsService::forViewer` already requires a Client `view` Gate before publishing a Client source link/name; it should use callback-fresh canonical evidence rather than a potentially cached actor/assignment relation.
- `HsRiskAssessmentController::assertAccessibleFilters` validates the retained Client filter against Site authority. That filter does not prove permission to read the Client profile.

## Bounded proposed repair

Inside a single transaction and `CurrentAuthorizationReads` callback, load current RBAC evidence for the actual Client policy permissions and H&S Site audience. Intersect current approved H&S Sites with `ClientPolicy::viewFromCurrentEvidence`. Materialize only authorized scalar Client choices; do not reuse the First Aid HR/module reader as a generic Client policy or cache decisions across requests.

Copy Client names and offer Client links only after the independent current policy succeeds. For a retained Risk context without that permission, show `Client details unavailable`, preserve its existing Risk context ID, and keep Risk-owned reads/commands/evidence available. New selectable Client choices require independent current Client permission. No new roles, global policy rewrite, schema, or tenant concepts are needed.

## Source continuity finding requiring separate command review

`HsRiskAssessmentService::updateDraft` preserves additional `hs_event_id` only when the submitted primary type/ID is unchanged. A permitted draft primary change, such as Site to a Client at the same Site, can clear a previously binding First Aid event pointer. Risk history keeps recorded notes/controls, while its semantic snapshots omit source context IDs. Later readers can therefore lose the prior First Aid disclosure guard. This is a traced service sequence, not an executed database result.

Review a narrow rule retaining known binding First Aid event provenance during permitted reattachment and enforcing convergent Site provenance. Do not invent missing historical source identity or broadly forbid standalone/non-First Aid reassignment.

## Verification inventory

A new complete Risk Client disclosure suite should prove actual register/show and source partial payloads exclude independently denied directory names/choices; exact assignment and existing Client-wide authority preserve positives; cached permission, assignment and Site revocation remove copied names/links; Risk-owned detail, private evidence and authorized commands remain available; retained context/filter semantics remain stable; unrelated Site/standalone/non-First Aid controls remain unchanged.

Directly affected complete existing files are `HsRiskAssessmentControllerTest` (24 methods), `HsRiskAssessmentSiteAccessTest` (5), `HsRiskAssessmentWorkspaceTest` (15), `HsRiskAssessmentLifecycleWorkspaceTest` (19), `HsRiskAssessmentTest` (18), `SiteProfilePayloadTest` (7), and `SafetySiteAccessTest` (2). These are source-method counts, not executed or expanded-case results. Re-run class inventory after the final implementation; only the team's sole native runner may execute the database gate.

The current First Aid Site-profile regression is separately saved in `FirstAidDerivedMetricsPrivacyTest`: the actual authorized Site Risk partial retains ordinary/allowed rows, omits denied First Aid rows before presenter mapping, and remains readable after independent Client permission revocation.
