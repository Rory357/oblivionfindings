# HS17 canonical HR document consumer transition — source only

Root applied the independently reviewed, compatible three-file seam to the isolated H&S checkout. The earlier HR-DOCUMENT-CANONICAL-CURRENT-READ review/proposal remains an unchanged historical preparation record. This document records the subsequent source transition, not native acceptance or shared MAIN adoption.

The changes are only the canonical HR current-read assertion and optional query helpers, the historical HR Site helper's optional final current-read argument/propagation, and InjuryAccessService::restrictionDocument/comment. The injury adapter and interface remain unbound. User, Role, current-staff rules, other Site helper methods and all 29 other injury-access methods retain their installed H&S implementation. No MAIN helper was copied whole.

## Exact applied images

| Source | SHA-256 |
|---|---|
| app/Domain/Hr/Services/HrDocumentAccessService.php | 12B5F8D9F50F8F87734EBF8202F4D68025DAB9E60E32F225939F32D5BDBEDE5D |
| app/Services/UserSiteAccessService.php | D5DF9DCE73EB23918762357AB219CCAD957BD9A094FCAE0079DDB4F94F53E022 |
| app/Services/HealthSafety/InjuryAccessService.php | 7AF9D6D8138AF6A8E95371F101B7C0FBEDC389B2442CA09A304D9309BE6F9412 |
| tests/Feature/Hr/HrDocumentCurrentAuthorizationTest.php | 9F10B868172EF07F2941C842D2FFD8F457F66C3931BD6F9E7E30990E0241482B |

All four applied file hashes match the reviewed projected images. The new whole HR suite has 16 declared methods and retains the parent-authored source. The full existing HR suites and injury adapter suite in the proposal dependency manifest remain required; no test case has executed against these new images.

The canonical void assertion consumes the same caller-supplied physical CurrentAuthorizationReads scope, freshly checks current document-view/manage and independent HR Site evidence, and constrains exact document plus retained expected-worker profiles before private hydration. H&S retains its injury/source/Site/version and wellbeing checks. A general H&S all-Sites grant cannot replace the HR boundary. Existing methods with default optional arguments retain their original behaviour.

## Remaining acceptance

Every executable check is UNRUN under the parent runtime HOLD. Syntax, formatting, the complete canonical/consumer suites, whole real bridge composition, physical connection/lock/isolation behaviour, migration/schema/bootstrap closure and query cost remain separate gates. This source transition supplies no duty activation, legal fitness decision, new grant, source freeze, deployment or release. The full H&S goal remains active.
