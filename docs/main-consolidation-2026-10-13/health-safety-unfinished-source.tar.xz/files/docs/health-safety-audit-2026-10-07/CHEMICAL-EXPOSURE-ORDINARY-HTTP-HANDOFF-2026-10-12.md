# Ordinary private chemical HTTP — finite source handoff, 2026-10-12

SOURCE ONLY, routes/header middleware/legacy alias changes UNAPPLIED. New controller is not referenced by live routes. No application/native/DB tests, runtime mount, delivery dispatch or recovery/risk integration occurred in this unit. Root owns shared routing and old alias composition.

## Authoritative authored source

- NEW app/Http/Controllers/HealthSafety/ChemicalExposureWorkspaceController.php: FB2F14A6988BB52B923FE6B60EBEBC9D001E2E9CF89BF0342E22D7EE80BF5412.
- Existing complete tests/Feature/HealthSafety/ChemicalExposureWorkspaceControllerTest.php: 7C76C5E26957CB8BAC5A8B42C3FC54E06332948A9BD4D2B79F911770683FFF49; all22 original methods retained, plus6 meaningful methods =28 declarations, all native/HTTP UNRUN.
- Selected source/dependency/suite observation: storage/logs/chemical-exposure-ordinary-http-source-candidate.json.
- Actual two-file syntax receipt: storage/logs/chemical-exposure-ordinary-http-source-syntax.json.

No duplicate request policy or new FormRequest is needed: current domain services retain actual command envelope/field/date validation and source authority; the controller validates transport selectors and raw integer bounds only. Capture remains distinct from saved medical read.

This controller is the current successor to the historical full CC2B8E03 transport and CCE472D9 focus hunk. Do NOT apply that old whole proposal additionally: it would duplicate this controller and include separately held recovery routes. Historical artifacts are unchanged.

## Actual methods and scalar contract

index(Request) calls current Workspace.index and returns its existing scalar records/count_integrity/counts/page/filters/sites/can/source_integrity/exposure_access envelope with confirmation=null. Generic safety viewers receive restricted/null private sections. Unknown original association remains unavailable rather than a fabricated empty or repair link. Independent capture capability remains separate.

show(Request, string|int exposure) bounds the raw positive ID before source SQL. It validates existing pages/section/action/followup/evidence/return/receipt selectors, then passes exact requested followup as Workspace.detail's fourth argument. The actual service resolves admitted current child/page and returns focused_followup_id plus followup_focus_state; no controller inference from query alone grants focus, completion, assignment or a foreign-child lookup. Existing fields and child/history pagination remain unchanged.

capture/captureOptions call the existing Workspace.capture under its freshly proved capture grant, current eligible staff and approved active Sites. They do not require or confer saved exposure read. commandOptions uses the actual current source/manage service. Option endpoints are direct JSON only. Capture confirmation is actor/UUID/substance-bound minimal receipt reconstruction, with no saved medical record fallback.

Receipt and ordinary source commands delegate existing Source/Evidence create/correct/review/assign/reassign/complete/upload/remove. Their persisted12-key acceptance must match actor and UUID exactly before HTTP success. HTML reconstructs an actor-bound hint once; explicit UUID lookup is direct JSON only, never a historical page field. Readable href is optional current service proof, not a grant or delivery result.

downloadEvidence bounds exact parent+file IDs, then calls actual DownloadService.download. The private internal descriptor never enters JSON; that service proves exact current parent/source/evidence, opens one checked stream, verifies the spool's size/SHA256 and emits only those checked bytes. No public storage URL or unchecked path reopening is introduced.

deliveryAttempts is existing read-only JSON metadata. It preserves reported pending state and destination_confirmation=not_checked, not receiver proof or a usable HSE href. Actual DeliveryService.sourceCommitted checks physical transactionLevel=0 and intentionally does not dispatch; Source commands stage pending outbox work before commit. This controller does not call a destination, invent acceptance or run a GET retry.

All routes use raw string|int controller arguments rather than implicit exposure/child models. Zero/overflow/array selectors are refused before private record/file hydration. Current SourceF88, Workspace491 and Evidence18BEC remain unchanged by this unit; their exact actual hashes and proof dependencies are independently recorded in the selected manifest.

## Retained-prop and response privacy

Direct JSON returns detached service arrays. HTML/X-Inertia responses wrap already eagerly recomputed props in Inertia::always, including detail/records/counts/options/confirmation, so auth-only partial responses cannot retain old private payloads. No fresh callback, delayed builder, source model or permission token escapes into a prop.

Successful responses explicitly use private no-store/no-cache and no-referrer. The separate scoped header middleware dependency covers matched private route errors without changing global exception/status behavior. Its class remains UNAPPLIED; actual authenticated403/404/422 no-store regressions are authored against that explicit dependency, not claimed as passing. Unauthenticated transport still depends on existing auth policy, with no private body returned.

## Exact unmounted composition order

1. Root reviews and authors only CHEMICAL-EXPOSURE-ORDINARY-HTTP-HEADERS-UNAPPLIED.patch:
   D74B58F8ABDF76B4EA85A4ED81B8DB030FA47ECFED1D6D7313BF79B90B4A3CE9.
   New route-local ChemicalExposureResponseHeaders class, no global registration.
2. Root applies CHEMICAL-EXPOSURE-ORDINARY-HTTP-ROUTES-UNAPPLIED.patch:
   4B62B4A43F3359F28AC4322B1728F22A979A41DC7E6E3F317CEC89ED3FB7D412.
   Two hunks against actual routes/health-safety.php base6E9F370A67845A1BA45B3C4C275AD01D5253DAFE66CDC264D2591F5D61BC806A.
   Sixteen ordinary routes under unchanged enclosing auth. Index/detail/download/capture/manage retain exactly their canonical current operation/source authority in existing services; there is no parallel stale request-actor grant.
3. Root separately reviews/applies CHEMICAL-EXPOSURE-ORDINARY-HTTP-ALIASES-UNAPPLIED.patch:
   DA8B83813B014CAAD3FF2C9C7DCE52EEB145CA2ABC4772097CD96595217089C7.
   Two hunks against the route projection AFTER step2. Exact existing /substances/{substance}/exposure-records and /exposures names/URLs remain. Only those aliases move outside the duplicate stale public-capture middleware into the same auth group, delegating the unchanged hazards.create OR hazards.manage operation to current Source.create. Other public catalogue route middleware and the old legacy controller method remain untouched.
4. Ordinary read-only GETs can be considered independently of writer activation. Writer activation requires the actual source-specific ordinary audit consuming boundary (now Root-mounted R2), strict accepted source/byte/history dependencies and their complete behavioural acceptance. This package does not itself activate writers or certify those prerequisites.

Pure text projection of the two route patches matches the intended current route sequence (2+2 hunks). Live routes, Header class and HazardousSubstanceController were not edited. All global middleware and EnsurePermission remain unchanged. The separate three audit-reader delegation remains independently UNAPPLIED; do not assume its warmed-grant HTTP tests passed.

No association-recovery selector, recovery queue/page/retry, risk command/acceptance recognition, copied HSE source-family, notification/Tasks registry or after-commit dispatch is added. They remain separate owner-reviewed units, rather than ordinary GET prerequisites by inference. Task deep links must remain unavailable until the actual guarded named focused GET is composed.

## Whole meaningful tests and limits

The existing22 HTTP methods preserve literal aliases, current receipt/capture/HR/Site denial, explicit JSON receipt behavior, HTML hints, exact fields/private read, source correction/review/named work/replay/stale drafts, foreign record/child denial, genuine read-only delivery state and reassignment.

Six added cases cover:
- capture-only current Site/HR options, no saved exposure/version SQL and no self read;
- saved private reader without capture/manage grants;
- auth-only index partial stale well-being denial and Site reassignment/restoration, with ordinary catalogue neighbor preserved;
- exact current read-only focus without completion authority;
- actual download controller wrong-parent prebody denial, current private-grant withdrawal/restoration and descriptor omission;
- raw route overflow/selection failure with source-safe no-store responses.

Existing complete FocusTest already covers26/27 children and page2, insertion/deletion at final proof, child case/trailing-space damage and moved/downgraded history. It is retained rather than duplicated here. Existing complete EvidenceTransportTest and EvidencePrebodyPrivacyTest remain owning physical stream/staging/evidence dependencies, unchanged. EvidenceTransport includes separately held recovery HTTP cases: do not filter them out or treat an ordinary mount as its full-suite acceptance.

The selected manifest lists12 complete affected suites and255 declared public methods, all UNRUN. This is an observed bounded footprint, not the final full programme/native inventory or permission to omit owning source/concurrency/audit/family suites. No query ceiling was changed or run.

The only executed checks were php84 -n -d memory_limit=64M -l on the new controller and the complete HTTP class: both exit0, exact pre/post hashes unchanged. No bootstrap, DB, native/Pint, process/resource probe, Node/browser or other worker ran. Memory was capped but not measured. Source-specific no-store/partial/focus/download/current-role behavior remains required native/browser proof.

A proposed unlinked-legacy receiver concern was explicitly withdrawn after actual491 reread: admittedRootInReads supplies incident_binding absent for null related_incident_id; commandOptions blocks only unknown linked association. No guard or Source policy was changed.
