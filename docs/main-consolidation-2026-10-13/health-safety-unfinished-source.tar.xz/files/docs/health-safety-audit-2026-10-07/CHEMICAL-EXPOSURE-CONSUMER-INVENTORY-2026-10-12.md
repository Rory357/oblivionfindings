# Chemical exposure consumer inventory — 12 October 2026

**READ-ONLY SOURCE REVIEW. All executable checks and acceptance UNRUN.** Only this document is authored. It does not authorise live code changes, source transfer, private schema/writer allocation, permission changes, runtime, freeze or release. Observed hashes are candidate bytes, not a full input freeze. Single operating organisation, current approved Sites and canonical sources.

## Human policy and actual source

Identifiable exposure requires fresh hazards.view AND hr.wellbeing.view, approved current internal staff and current canonical approved source Site. General safety receives restricted state and null private rows/counts/pages/history/filter values BEFORE private SQL. Neither user_id (affected worker), created_by (recorder), catalogue management, incident access nor Control Room response grants private read. New-report capture is separately authorised; submitting a report does not grant saved medical record access.

SubstanceExposureRecord.php:11–85 is the actual soft-deleted source. Relations: hazardousSubstance, user, site, relatedIncident(ClientIncident), creator, updater. user_id is exposed worker; created_by/updated_by are recorder/editor. forWorker/requiringMedicalAttention are filters, not authority. Migration 2026_03_28_100002:97–125 retains substance/worker/nullable Site, exposed_at/type/duration/circumstances/symptoms/first aid/medical attention/outcome, incident flag/pointer, recorder/editor/timestamps/deletion. June140000 adds medical_treatment. FKs are substances/users/Sites/client_incidents/users. There is NO original incident Client/stay/shift tuple, private review/followup/evidence/version/receipt/delivery relation. Legacy related_incident_id nonnull means unknown original association, not known-null or today's Client. Null pointer is absence of that pointer, not proof of complete historical context. Do not invent clinical/injury/first-aid/HR-document/shift FKs from medical fields.

Public chemical history migration October200100 and ChemicalCommandLedgerService/evidence staging are reference/SDS/storage work, owned by C. They do not prove exposure provenance. Private October200200 and exposure writers are NOT allocated; no October private200200 file was found. Names containing chemical_exposure in injury enums or substance_exposure in NotifiableEventClassifier are different source/type concepts.

## Live direct reads and frontline fallback (root-owned)

| Exact current path/method | Actual boundary / gap |
| --- | --- |
| routes/health-safety.php:317–349 index/show | hazards.view-only. HazardousSubstanceController::show:267 redirects to index ?substance=id; no permanent exposure GET. |
| HazardousSubstanceController::index:30,124–152 | Optional Site-only exposure-period/medical-outcome counts and exposure-category WorkSafe count execute without wellbeing/current private source scope. ?substance= invokes detail. |
| buildSubstanceDetail:458,471,540–565 | Request actor hazards.view; eager ALL exposureRecords/user names, medical fields/incident pointer, unbounded collection and exposure count; all User::staff() picker. Privacy leak includes internal SQL hydration, not just JSON. |
| storeExposureRecord:408–450; POST exposure-records and /exposures alias:342–343 | hazards.create OR hazards.manage middleware; raw exists worker/nullable Site/incident and generic date; writes private facts+recorder with no current HR/Site/incident tuple, revision or receipt. Writer unallocated; do not solve by requiring saved-read permission to capture new report. |
| HazardousSubstance::exposureRecords:73 | Ordinary HasMany with no privacy predicate. Loading/counting this relation is not medical admission. |
| substances/index.tsx:436–438; substance-detail-dialog.tsx:542,870–937,1462 onward | Actual frontline fallback: register row → same substance modal → record_exposure pane → exposure-records POST. Worker/Site choices, local nowLocal() timestamp, medical fields. Saved pane renders names/symptoms/treatment/outcome. Dashboard.tsx:318–328 opens same register/modal. |

No standalone My Day exposure query/page, exposure CSV/download or correction/review route was identified. Capture-only reader must not fetch saved exposures just to obtain a form. Existing SDS downloads are supplier reference evidence, never personal exposure evidence.

## Prepared but unmounted readers

ChemicalExposureAccessService::withCurrentViewer:23/withReadContext:29 reuses HealthSafetyReadContext, exact prepared PERMISSIONS and detached scalar arrays. canRead:40 requires both keys; assertRead:45 precedes queries; readableQuery:56 requires nonnull approved Site plus active/unarchived Site, live substance+worker. assertExposure:66 constrains exact substance parent before hydration, preserves historical worker (no inferred current employment/fitness). assertSite:51 excludes inactive/archived Site consistently with the actual canonical UserSiteAccessService::currentAccessibleSiteIds: bypass102–108 and ordinary142–148 both require active(), notArchived(), archived_at null. Parent resolved this source-policy question: retain the existing current Site checks; no retired-Site bypass is authorised. Historical worker identity does not require current employment. Null Site is never global.

ChemicalExposureReadService detail:17/detailInContext:23; index:45/indexInContext:51; forSubstance:59/forSubstanceInContext:65 use same admission. collection:73 returns restricted/null before filter normalization/private count/page queries. Allowed scoped count+medical count precede 25-row pagination; each shaped row is re-admitted in same callback. NZ timestamp projection preserves actual offset. History null/legacy_unknown, attachments null/not_recorded, delivery unconfirmed/no H&S href, write flags false. sourceTuple:87 returns class/morph/id/category/substance/Site/worker; client_id=null is accompanied by client_binding=unknown for retained incident pointer. That null cannot become proven original Client equality.

ChemicalRegisterReadService detail:24/index:55/storageForSite:131/sdsForDownload:150 is independently nonprivate, exposure rows/counts null/restricted even for an independently privileged reader. ChemicalAccess separates catalogue view/capture/manage. Existing complete ChemicalExposurePrivacyTest20 declarations and ChemicalCatalogueStoragePrivacyTest cover prepared readers only, not live mounting or execution.

## Observer and copied audit write boundaries

AppServiceProvider:517 registers SubstanceExposureRecordObserver after commit. created:19 loads TODAY's relatedIncident(id,client_id,shift_id), severityFor:50 classifies medical treatment, then HsEventService::recordEvent:66 writes exact class+sourceID/category idempotency, dates/severity, Site, staff_id=user_id, today's incident Client/shift and created_by=recorder. No source immutable revision/original tuple/durable delivery/retry outbox; observer has created only, not corrections/deletion, catches/logs failure. No direct exposure notification or CR alert bridge exists here. Severity/positive reduced classifier is not full WorkSafe signoff; recordEvent stores a WorkSafe decision only with its existing complete-authority evidence.

SubstanceExposureRecord uses AuditableChanges without exclusions. Hooks at app/Models/Concerns/AuditableChanges.php:12/25/54 persist before/after private text. SafeOperationalData::protectsRequestContext:205 does not include exposure; AuditLogger stores meta and request context. Bounded text is still private. AuditLogViewService query:81/present:132/filterOptions:177 has board-pack scope, no exposure source scope: meta/actors are hydrated and search/count/page/filter identities revealed; present sanitises values but not source existence/actor metadata. Narrow source-specific audit writer exclusions and retained-copy viewer gate require shared-owner approval. Do not rewrite all audits or silently erase history.
## H&S family and dependent consumers (root-owned)

HsEventAccessService applyReadableScope:22 validates current hazards/Site evidence in supplied context, but family chain FirstAid:50 → Restraint:83 → Injury:143 excludes exposure. canView:268 prepares existing three families only. deniedFirstAidEvents:254 and child/risk APIs:204/215 enumerate only those three: identifiable exposure rows/child investigations/actions and BOTH modern+legacy risk bindings pass as ordinary safety. Preserve independent filtered candidates, final correlation, archived-source denial and conservative incomplete-candidate SQL when adding exposure.

HealthSafetyReadContext within:42 locks fresh actor/RBAC/HR once; assertViewer:80, consumeSourceViewer:89 validates required preparation; consumeViewer:100 requires approved current internal staff+Sites; applyEventSiteScope:124 is canonical current Site discovery. Existing family methods166/201 have no exposure. Prepared union is evidence, never a grant. Supplied callbacks must error on wrong viewer/expired connection/unprepared keys, never silently refresh. No model/Builder/authority/context escape.

| Current method/path | Missing private-family consequence |
| --- | --- |
| HsEventController index/applyScope:78/260, exposureMap130–134; resolveSource:690/resolveSubstanceExposureSource:772 | Raw exposureID→substance lookup and basename source dispatch; generic label/public chemical href. client-name projection151/1119 only special-cases FirstAid. Require exact literal class/morph + source worker/Site/provenance; public substance reference is not private exposure workspace. |
| HsEventController show/detail/recent/feed/action scope:1385/1551/1629 | Once ordinary H&S read succeeds it loads findings/recommendations/owners/action narrative/evidence/audits/risk rows. Family guard must precede dependent SQL. |
| HsInvestigationController scope285; HsCorrectiveActionController scope275; HsCorrectiveActionEvidenceController193; HsCorrectiveActionWorkspace35; OwnershipService189; HsWorksafeDecisionController38 | Direct/list/evidence/current ownership/WorkSafe reads inherit incomplete chain. Assignment/manage is not wellbeing access; unrelated writer policies unchanged. |
| HsRiskAssessmentController405/425/436; HsRiskAssessmentService259; RiskAssessmentWorkspaceConnections67/141 | Preserve modern hs_event_id and legacy assessable class/morph+ID constraints together; unrelated numeric IDs/orphans must not acquire a source. |
| SafeWorkProcedureAccess assertSource206/sourceCan225/reviewRequestsForViewer242; EmergencyDrillAccess/Service canView consumers | H&S-linked review/drill work must admit private source before copied requests/action facts. |
| FirstAidConnections64; FirstAidSourceProjection sourceForReview135; EmergencyDrillConnections40/100; LoneWorkerSessionConnections67; HazardWorkspaceConnections68 | Existing supplied-context and independent-candidate paths need new family keys only when traversing H&S. No invented chemical–first aid relation; preserve exact source matching. |
| HsVisibility forEvent33/summaryWithWorkflowFacts92; IncidentController/IncidentJourneyPresenter | Summary/status/reference/owner/workflow inherit missing family. Independent incident capability remains; exposure.relatedIncident pointer is not canonical ClientIncident-source H&S identity. IncidentJourneyService strict tuple and per-record unavailable sentinel must survive. |

HsEvent relations staff/client/Site/shift/owner/investigations/correctiveActions/riskAssessments/reverse clientIncident are linkage, not medical permission. Exact current family guard must precede hydration/search/copied projection.

## Counts, reports, exports and other observers

Root aggregation paths needing complete family:

* HsDashboardService hsEventQuery628/riskAssessmentQuery558/applyRelatedSourceScope687: KPIs/worklists/critical events/site league; dashboard last-notifiable direct query is separately scoped in controller.
* HsKpiService actionsClosedOnTimePct185/leadingLagging307/applyRelatedSourceScope509.
* HsModuleSummaryService forSite40/forClient127/forAsset154/forStaff180; eventQuery197/scopedChildren209/scopedRisk218/relatedSource247. ClientController1695 optional hs_summary is an actual mounted consumer.
* HsAnalyticsService rootCauseInvestigations279/periodSummary819/exportRows876/relatedSource1077. WorkSafe NotifiableIncident model/relatedIncident analytics are a separate dataset, not an exposure table reader automatically fixed by HSE family.
* HsGovernanceService eventQuery385/investigationQuery403/correctiveActionQuery415/riskAssessmentQuery365; HsComplianceExportService WorkSafeRegister65/investigationOutcomes116/actionTraceability179/riskRegister252/eventQuery384/related helpers402–442.
* HealthSafetyDashboardController, HsGovernanceReportController/HsWorkspaceController and Governance DashboardAggregatorService compose those services.

Count/aggregate/search/filter/page/export must use the admitted private predicate BEFORE SQL, not render-time filtering; denied/unavailable is null not zero. Public chemical/SDS expiry remains independently available. Staff/Client/asset/Site refinements and actorless aggregation are not private grants.

RiskEventLink supports hs_event and retains copied event_reference/event_severity/link_rationale. Governance RiskRegisterController::presentEvent771 serialises these without H&S private-source recheck (H&S href currently null): shared Governance owner needs a narrow consumer seam. ReportHsWorksafeDecisionCounts console uses withoutGlobalScopes aggregate diagnostics; do not turn it into a general safety exposure report. ReportSourceReader/ReportSourceEvidence have CR alert datasets and inherit copied-content review, no direct exposure dataset found.

## Tasks, search, followers and notifications

No TasksQuery class or symbol was found in app/resources/routes/tests. Actual code is TaskSearch, TaskProviderAuthorization, TaskAggregator and AllTasksController; do not invent an alternate entry.

HsEventProvider authorisedTasks47/context64/nav72 has one current callback; candidate Site prefilter141 and final HsEventAccess preserve ID/search/status/order/top300. It constructs event/client/Site/owner/journey TaskItems. HsInvestigationProvider48/65/73/146 and HsCorrectiveActionProvider52/69/77 use independent child-filtered candidates then final whereHas. Missing family currently admits exposure rows. Keep cheap generic canView chooser checks separate from source row authority.

TaskAggregator findItemFor174 (optional supplied context), sourcesFor459, navigationBadgeFor506/navigationBadgeInContext512, healthSafetyProviderPasses629, feed/report and watcher methods all consume these rows. Current union is FA+Restraint+Injury+Procedure+Drill, not exposure. Chooser authority-only path must not query private rows; add family evidence only with approved mounting. TaskSearch narrows candidates and IncidentJourneyTaskContext::make20 optionally builds readable owner/narrative search terms. IncidentProvider/ControlRoomAlertProvider eager H&S relations require private source admission, independent incident/alert policies unchanged.

AllTasksController index41/reports545/exportCsv492 consume TaskItems. detail130 adds AuditLog timeline+watcher names unless restricted or destination absent156–210. Exposure Task purpose must prevent secondary source/audit/actor disclosure without actual private grant; own follow-state/unfollow remain independently usable after exact source rules, current revocation blocks new follow/open. EscalateOverdueTasks handle43 and canonical watcher delivery recheck recipients via aggregator; add family there, no mail-only alternate policy. Messages contain source title/reference, no direct exposure reminder found.

CheckOverdueInvestigationsJob handle25 reads overdue investigations+lead name; CheckOverdueCorrectiveActionsJob handle25 copies action title/assignee/H&S IDs; CheckRiskAssessmentReviewsJob handle25 copies risk title/score/both bindings. HsSignalService emit157 writes normalized title/description/context → SignalProcessingService alerts. These are actual indirect exposure-origin copies even without an exposure alert type. Background producer retains minimal operational references; human projections/delivery recheck private authority rather than invent job wellbeing grants.

## CR-owned consumers (no editing/transplant)

Operational alert response remains independently actionable when exposure source is restricted/unavailable. It never grants copied medical content.

* ControlRoomGovernanceReadService forAlerts30 obtains canonical IncidentJourney records, applies IncidentAccess+HsEventAccess48, loads readable owners. forSnapshotViewer82 rechecks saved references/summary. New exposure family must share supplied context/exact tuple, retain per-record unavailable sentinel and strict incident policy.
* ControlRoomSourceContentService present75/applyReadableNotes190/audit312/snapshotSummary347 handle incident/restraint copied content/notes/references/history; NO exposure branch. H&S access state alone does not remove arbitrary exposure title/description/normalized medical fields or legacy note copies. Original provenance distinguishes independent operational notes; unknown copies cannot silently become independent.
* AlertWorklistQuery forUser32 q77–95 searches references/type/source-aware notes/incident/H&S refs. H&S candidate is ALREADY-filtered canonical alert-ID subquery plus reference term, not global reference-only source query. Source denial must precede copied-note/search/count/page; AlertWorklistPresenter uses governance+SourceContent.
* AlertWorkspaceService build49/123/149/151 consumes HsVisibility/SourceContent for summary/workflow/context/audits. Desk/List/MyTasks/ShiftHandover snapshots/HandoverController/device/map/fleet/report consumers inherit CR boundaries. Raw IncidentJourney discovery is not serialisation authority; source projection admits identities first.
* ControlRoomNotificationService notificationSnapshot243 is minimal operational alert identity/state/severity; buildContent358 generic label except escalation reason; authorisedRecipients436 checks medication families only. Do not claim current direct exposure symptoms mail exists (none found). Future copied exposure reason/payload and recipient read/delivery need current canonical admission. Saved Communications/snapshots are not continuing medical authority.
## Proposed minimal canonical integration (no source implementation)

1. Reuse ChemicalExposureAccess current viewer/read context and exact parent/worker/Site admission; preserve canonical current active/unarchived Site policy in both bypass and ordinary paths. Candidate source IDs are bounded by already filtered actual caller and current approved Site BEFORE discovery, independent of correlated outer query. Direct missing private permission403; foreign/missing parent/source404 under canonical operation rules. Public projection restricted/null before private SQL, no self grant.
2. Proposed ChemicalExposureSourceProjectionService::readableHsEventIdsInContext(User,Builder independentCandidates,HealthSafetyReadContext):array and detached direct/copied DTOs: exact class OR registered morph, category exposure, sourceID, recorded worker staff_id=user_id (NEVER created_by), source Site and actual asset absence. Prospective original incident Client/stay/shift needs genuine retained proof before links. Legacy unknown cannot become today's tuple or null-equality. Missing/archived/moved/mismatched/damaged source fails closed.
3. Extend HsEventAccess final intersection AND complete identity-only denied child/risk family set. Preserve archived known bindings, modern+legacy source constraints, conservative incomplete candidates, unrelated/orphan rows and final correlation. Context family method reuses SAME active prepared actor/reads/Sites; no global cache, second context, authority DTO escape or silent preparation fallback.
4. Materialise source/details/Tasks/summary/search/count/export inside current callback, exact emitted facts re-proved; no warmed request model/relation fallback. Private filters/counts/page after gate and before SQL; unavailable null is not0. Preserve filters/order/top300/NZ semantics and recommendation <100 ceiling; historical124 failure remains, no performance acceptance.
5. Allocate exposure writer/private200200, retained provenance/history/evidence/UUID/receipt/recovery/durable delivery separately before claiming recorded. No automatic legacy certification/backfill. Audit writer exclusions plus retained-copy read gates require bounded owner approval; private evidence exact parent/byte proof cannot be substituted by SDS.
6. CR receives detached readable/restricted/unavailable/absent envelope, source null on denial, canonical proved tuple on success. Independent operational response remains. Public chemical reference must be labelled reference, never exposure destination. Root H&S/Tasks/controllers/UI and CR peer consumers stay separate; shared Governance/Audit/report adapters require explicit narrow allocations. No grants/seeder/framework/SQL whitelist rewrite.

## Whole-file test obligations — all UNRUN

Existing chemical privacy tests prove prepared source intent only, not live consumers or passes. Needed actual HTTP full/partial safety-only/no-privateSQL; wellbeing-only; exposed-worker-no-grant; warmed revoke/restore; current HR/Site withdrawal/restoration; null/foreign/archive/history; recorder versus worker; legacy unknown versus prospectively retained known-null/non-null Client/stay/shift; exact parent prehydrate denial; source correction/removal; count/page/search/export parity; same context no refresh, expired/wrongviewer/unprepared/connection errors; Tasks/list/nav/detail/follow/own-unfollow/delivery; H&S parent/child/risk both bindings/incomplete candidates; CR notes/search/history/audit/snapshot/notification current denial with operational response positive. Capture scope/pickers must remain independently authorised without saved medical read. SQL evidence must test BEFORE hydration, not only rendered nulls. Prospective writer/evidence/process race suites cannot be inferred from these declarations.

Below is proposed existing COMPLETE-file dependency footprint, not admitted native inventory/executed case total or exhaustive future writer acceptance. Existing files with no PHPUnit method declarations are labelled Pest/unenumbered, not absent. Exact source reference/caller enumeration is appended. No standalone absent symbol/route is treated as implemented.

## Observed source pins

| Path | SHA-256 |
| --- | --- |
| app/Models/SubstanceExposureRecord.php | F086C08B28618F4E65C666454233462586B0890989436946137BD28204633019 |
| app/Models/HazardousSubstance.php | 66465AFB3CB0D84E61FDB9DC6E289A01E21415605FDDDD65B5448B155D6E76FC |
| app/Observers/SubstanceExposureRecordObserver.php | D95B1AAB0349364F5A78174177E045F586282B13C3BB4C2B87533386DF529100 |
| app/Services/HealthSafety/ChemicalExposureAccessService.php | 4C8B3E5E85090F1E0749AECFC7B2CEE8FDDA313BA69B3B87988872E92E637721 |
| app/Services/HealthSafety/ChemicalExposureReadService.php | EFC41EE3338419C1E1601513AD56248169815CE7C57E12B8994C99C1D3DFCE68 |
| app/Services/HealthSafety/ChemicalRegisterReadService.php | 683DD68F20F4DF21EF222C4D46208A9D5AD719B3B5532D194531FA45C90D836B |
| app/Services/HealthSafety/ChemicalAccessService.php | B332BCDE5D6B58060B14B77DD6B3FB6363AA3332EA5412541CD3234CABE2C896 |
| app/Services/HealthSafety/ChemicalCommandLedgerService.php | E5707E20D138590549A1396476D81828BDF25613430341B6B07E42C48E0C6000 |
| app/Services/HealthSafety/ChemicalEvidenceStorage.php | 123D42BDE13130D0A488656003239ADE2EF93EFC501CDD4512D57A51EE251255 |
| app/Http/Controllers/HealthSafety/HazardousSubstanceController.php | F578AC42945A4D47AF148C38F821F9FC65D5F0104A2677F49FF607BEE6120C5E |
| app/Http/Controllers/HealthSafety/HsEventController.php | C9BFE71890E5805DD8DE5C8FAB9AB21CE71CEF9C21B961C163E739F7593AD83D |
| app/Services/HealthSafety/HsEventAccessService.php | 8DA9911B9DFDCF780241D71E18E40640D587AFDC1E4EE9A70006BB9E0F28FC83 |
| app/Services/HealthSafety/HealthSafetyReadContext.php | 8CC4D41263F7B22042FA17394DDE2BB3197A90877B6DA463277E01025282F0B6 |
| app/Services/HealthSafety/HsEventService.php | BE18542D46C11D587EFB3DD1A42E6CEC601A10957AF45C485853E8127B614A8C |
| app/Services/HealthSafety/HsVisibilityService.php | 8FC27E4F729DF9E7520BF6BB8005AE320D132A8E794DE91657817B4C825CD892 |
| app/Services/HealthSafety/HsDashboardService.php | 7FBD359FFF88F33B5F0585E81859D68C917637E2DAD9E14B993DBDA3A8DAD5E6 |
| app/Services/HealthSafety/HsAnalyticsService.php | 16AD63BA671CA09B4B8344395C19D64366C782C068E9B6A0A25A91B5E8AD0A09 |
| app/Services/HealthSafety/HsKpiService.php | E193BB678779E45B14B66A4707A56D0EEA23919C617276E04FD04D30F2E3FB77 |
| app/Services/HealthSafety/HsModuleSummaryService.php | B6EEAC20F4C3B76FF01803551DAF9EA5C6B1F82B2C443A2011A942A8CA0138A4 |
| app/Services/HealthSafety/HsGovernanceService.php | 0FA11BB453C9D9DB3FA41A8B3251373A4CFD9661A179D3AFBD873B97788E8658 |
| app/Services/HealthSafety/HsComplianceExportService.php | B0A66F7E1CE573B24BF9B1B1A889553C502B3717B31A11C733F1CE0D22B9BCEC |
| app/Services/HealthSafety/HsSignalService.php | AD79A247FA2F9E52EB2DB8480719E90FD557EB8426E8CCFC293DDEBEDC2F831D |
| app/Services/Tasks/TaskAggregator.php | 4D3C7D4032D82DE3252CCA8C8CAA903698E559C95BAD100FC88A4B4769718124 |
| app/Services/Tasks/TaskSearch.php | CCD36D5859689CF2CFFB8013237E4A3EF0551DEDBAFBA3B412F3EF484C748512 |
| app/Services/Tasks/IncidentJourneyTaskContext.php | 59AEA226578D74358B9397CFD6E40C4D438154C043C171E64CCC48B7A993D905 |
| app/Services/Tasks/Providers/HsEventProvider.php | 1B3404F03E6C2EE591DC3F212102F2B96C0A7F8C922DA4D76562CC604DEFD0A3 |
| app/Services/Tasks/Providers/HsInvestigationProvider.php | C02615683F963DF1537F39F8419158486FC5AE3A1F92D1F7489672B09E920278 |
| app/Services/Tasks/Providers/HsCorrectiveActionProvider.php | BB79368AFFA3098B8F5A37A57364C2AFCEF126E70B89081A51DC74694E5483BA |
| app/Services/Tasks/Providers/ControlRoomAlertProvider.php | D56F50623DC56D6BA4D7954F8FD4396AB962BD21907E2979B82D1A615AE70655 |
| app/Http/Controllers/AllTasksController.php | AEEBACA0DA2E1E1034D0B9417DB3AB1A5892D47CA28B06C787D18140CF888697 |
| app/Services/ControlRoom/ControlRoomSourceContentService.php | 9C4558062A8EFC00D335B975CB754FC6BD7EE1A08BA0B8E5E882C8DD50F16F77 |
| app/Services/ControlRoom/ControlRoomGovernanceReadService.php | 41E52C1A5C3D13B2288241447CCB1DE2E051A214A56E1058F6B0A9092678C4B9 |
| app/Services/ControlRoom/AlertWorklistQuery.php | F6907F53306B7D9D3D4A13C2885622C660399C849E9C0DB975500A0BE097DFD1 |
| app/Services/ControlRoom/AlertWorklistPresenter.php | BD3A69037D7EFF31B3010C854D7475BD44FE1DB80DE536BDD8AC1E7A75FF8E96 |
| app/Services/ControlRoom/AlertWorkspaceService.php | EC54D78E309CC06292B918660994C1FAFA669B3ACE2E526D385AB3A119011EA1 |
| app/Services/ControlRoom/ControlRoomNotificationService.php | 27499924C780B0BDE8D6DB4C24F7D01339264053E7E17088979F6BE064619374 |
| app/Services/Incidents/IncidentJourneyService.php | E76FE4B923ED1D192650BC86C25841BFAE852A324DB1A0B86D968E486C9443E1 |
| app/Services/Incidents/IncidentJourneyPresenter.php | D394964E31E3422B40B52BC3513B47122F3BA73C840B92F74B28D366D4397189 |
| app/Models/Concerns/AuditableChanges.php | 7F6CCCADBEB9A9D8EA62B42FF350922E647AB2E076AF3216343A6FAB811478BE |
| app/Support/SafeOperationalData.php | 4B6E66DA449AA897F19B9DB72FDA5154EAE8FA2ADED53B738E27433133068267 |
| app/Services/AuditLogger.php | 7065627C06A212627F12CBCCD605AF2B7F1528CD3571D006C19AFB8D927F3082 |
| app/Services/Audit/AuditLogViewService.php | C3EC60B500B9439D200D2A87E0204CF75E863C00EE3473C636EB5B758D5595B9 |
| app/Jobs/CheckOverdueInvestigationsJob.php | 7B36E784163FAAD43EA5A54706F7D4D1D2DF3CA9FAD0F2A54447AD5C0354F53D |
| app/Jobs/CheckOverdueCorrectiveActionsJob.php | 30CF9F7614CBCFDEC93DD280238FFDC9CD273CDEC8E76573B09207C4FCD367CB |
| app/Jobs/CheckRiskAssessmentReviewsJob.php | 287C9EE3607225D53542AF04356C46A0C9C85FF6D03BF2A40A7FFB60EE9E2E39 |
| app/Console/Commands/EscalateOverdueTasks.php | 5789E297C2B4AB6D5E24CA9F350A22AF203CCC189E5129A69C8FC930FAA09983 |
| app/Console/Commands/ReportHsWorksafeDecisionCounts.php | BF38918F16BECC4F5E6524BEE61BF08C6FAA4ED110E09DA8684673CC35A1E5EC |
| app/Domain/Governance/Models/RiskEventLink.php | 0735B4AEB227A8A246CFF3AB30D6DBADDD55357DE78E560AB0162307F4168212 |
| app/Domain/Governance/Http/Controllers/RiskRegisterController.php | EC05DC8312792F240B5C2D3C482BF5298C8AC743CFB8232E9056FB033F353571 |
| app/Domain/Governance/Services/DashboardAggregatorService.php | 0CE63A08D0ED85ACB3321FB494492B6D2F87487421FF013E4FB0C9943B3F1BBE |
| app/Providers/AppServiceProvider.php | 0129D143FE20F52F11034A223C370961955AEDFE679E25EE751307CB483A2A1D |
| routes/health-safety.php | 45CF40E79F754BA07F628F9DD0053BDCE1B1D827E93FDC1CDCDB8752B97B4D43 |
| resources/js/components/health-safety/substance-detail-dialog.tsx | 089B1AD4157709DBF46A94FC6FD09CE5C2F94053A1D2BD24C16211701F342C57 |
| resources/js/pages/health-safety/substances/index.tsx | 9C41C0C83A73D1516FC4026EB3249C88CD344E201CA25C601F08CC1236828FF9 |
| resources/js/pages/health-safety/dashboard.tsx | B8036069B1325F31D5680A89BF711D60A1F4C881CC163DA651CBE58C851206BB |
| database/migrations/2026_03_28_100002_create_hazardous_substance_tables.php | C825D56A88E9513669D9236A4260D36B1405BD55620B8AED8C65EAE772C45999 |
| database/migrations/2026_06_20_140000_add_medical_treatment_to_substance_exposure_records.php | 453F20822A59D40B2D502E15A25AC078D9DE05EBAB1C94994271D332EA4F51AA |
| database/migrations/2026_10_12_200100_create_chemical_public_source_history.php | 3CB41198146A706A6E5BAAD733FBC35DC95A2B4FD298E576697D5B8C25AB15BA |

## Observed whole suite pins

| Complete file | Declared methods, not cases/results | SHA-256 |
| --- | --- | --- |
| tests/Feature/HealthSafety/ChemicalExposurePrivacyTest.php | 20 | 38764431E8170F5D50A4CBF3DABDD7880B3ABC015BCE5BE4EF0D4950560FA7E7 |
| tests/Feature/HealthSafety/ChemicalCatalogueStoragePrivacyTest.php | 18 | 766AA35AE7C56935FB7709C7BD1E30ABA04024F33CBB46057129DC47B32C6416 |
| tests/Feature/HealthSafety/HazardousSubstanceControllerTest.php | 19 | 7924B6B17CDA04B397BD71699484F5EDA94DA32D197F0967132F182DFA16EB91 |
| tests/Feature/HealthSafety/SubstanceCrossModuleTest.php | 2 | 026B5E89900D339A39D32ED217B315C7089DD155A4836640C4E3E3DFEEE4153B |
| tests/Feature/HealthSafety/HsEventBackboneTest.php | 26 | DB9E0FC5180579800F138D4138A45DB9BE79B39FB1FBCFA29DE6F7E86D3F6013 |
| tests/Feature/HealthSafety/HsEventRegisterTest.php | 14 | 855B36FEEBFC99E4F199DE0BB6D3C2BB14B8349687AD866F608C5CDCFF4BD6A4 |
| tests/Feature/HealthSafety/HsEventWorkflowTest.php | 5 | 10137D8A0A4713719854F6F56456AB6BF95214B3306191BBF272B864334D98F7 |
| tests/Feature/HealthSafety/HsEventSiteIsolationTest.php | 16 | 4A1FF6FC09C2D189F2F48D3534FDE04CEF716297E5D56BB212F4C32DA236C201 |
| tests/Feature/HealthSafety/HsEventWorksafeTest.php | 23 | A9F9D82831CAD05F352E5E3A8AD7F1E09C214A5D8F5FD00B7B880AA2CD9BFDC0 |
| tests/Feature/HealthSafety/HsInvestigationTest.php | 29 | 611BD17E8866BAD9A2ED0015181358092F96814797297C322BC5E8CED9A12E42 |
| tests/Feature/HealthSafety/HsCorrectiveActionTest.php | 44 | 48CE4DB2C0E180932C04596EF4CE79DED208CC80F6E588706A5FDD3B0E8B1790 |
| tests/Feature/HealthSafety/HsCorrectiveActionsRegisterTest.php | 7 | 158A51375BEDC71F3328058041410776F6823B7305FE4218D5E6AD8852AA2726 |
| tests/Feature/HealthSafety/HsCorrectiveActionWorkspaceTest.php | 9 | CF12A727391E63920787E5C9DB6E245FA66C918E12773EF521D9DD34FDD60034 |
| tests/Feature/HealthSafety/HsCorrectiveActionEvidenceTest.php | 10 | 338279B9883A57D827931E2C295D65FEE02BA3D91C9CAD6DBF599115EFE3D6B8 |
| tests/Feature/HealthSafety/HsRiskAssessmentControllerTest.php | 24 | D2EC972F3699F1099C5AE93276C2D41CF7B86E7272A06D415BA48C391B6E2BB8 |
| tests/Feature/HealthSafety/HsRiskAssessmentSiteAccessTest.php | 5 | 43CDF314B8F2417E1E3B5AD909D4FDD87988237C2E9B711AE5D6C81B75D657F1 |
| tests/Feature/HealthSafety/HsRiskAssessmentWorkspaceTest.php | 19 | BEE2F17A8207F560D30F0843602DD616EAF2528F34130383B839FF48B3D346E6 |
| tests/Feature/HealthSafety/HsDashboardServiceTest.php | 12 | FFB12922DD71064CE5523BE82CF3A077DDB7BDCF488CB2FE724F21A2DF7E2A61 |
| tests/Feature/HealthSafety/HsDashboardWorklistTest.php | 7 | D2FEC926E4C56A59C734A2656BBA1745945AE1F9481042AB488EB6624313D1A2 |
| tests/Feature/HealthSafety/HsAnalyticsControllerTest.php | 7 | A911EABFAA36FAAB2B578560A2C73CD94BBBF396B9DC4000C4ED1EB4062B8D6C |
| tests/Feature/HealthSafety/HsKpiServiceTest.php | 14 | E06696D998CFD6C98754F053FA1C1DD8A8CD7042675228167687D2A9C37FCB21 |
| tests/Feature/HealthSafety/HsGovernanceTest.php | 18 | F092026EB7EA2F2BA1A78AD9CB4D58F4B39CD1AB8417FB584AB6AC3B5E709EB7 |
| tests/Feature/Tasks/HealthSafetyTaskContextTest.php | 23 | A4C890B6FBD5B72E704444DFBF062F179B26A5BCCAC0588C8BF6AAB0E9E6C90C |
| tests/Feature/Tasks/TaskProviderRowScopeTest.php | Pest / unenumbered existing file | 20238E78FA6B5E9A166C8AC32151E202524D369E7A05EF92D231CBFC614818F3 |
| tests/Feature/Tasks/TaskProviderAuthorizationArchitectureTest.php | Pest / unenumbered existing file | 155E07CFF36AA027909A8F99DA6A6518CACBB0B3B9DC04D3050B57DE4441C68E |
| tests/Feature/Tasks/TaskNavigationFailureIsolationTest.php | Pest / unenumbered existing file | 49AA45C3E03403DC80ED8BBCC3FD0DCD2851B8A6C4BB55C372E9464715BB2456 |
| tests/Feature/Tasks/TaskWatchersTest.php | Pest / unenumbered existing file | 173BBFB03B2F0ECA489E920D0B334150C1AA9A31ADABE17F68E4D6E834E45B12 |
| tests/Feature/Tasks/AllTasksIncidentJourneyTest.php | Pest / unenumbered existing file | EC5692C133755EF88E4BF55F016BE6002255E8516B0449A2DF7B597E7AE714D9 |
| tests/Feature/Tasks/EscalateOverdueTasksTest.php | Pest / unenumbered existing file | 41C0DA715F5308F19254448E11150765701F5D2802E8E4B27A90A56C840268B7 |
| tests/Feature/Tasks/EscalateOverdueTasksPerformanceTest.php | 1 | 9C43DCD25731B18B4DD00A5E7E0DCEB7E1F5F7573EB00D57B5583021512880D7 |
| tests/Feature/Incidents/IncidentJourneyServiceTest.php | 47 | 15B75E8AFAD9FDBD12D5302E832D1FEA20C7C2F26CDF850184FA10E6EDC77211 |
| tests/Feature/Incidents/IncidentJourneyPresenterTest.php | 12 | 274E0BBAC2B0AD1825D45D6C67722069186C27DDFC02AB5C009F13E3B71C5055 |
| tests/Feature/ControlRoom/ControlRoomSourceContentPrivacyTest.php | 12 | 93FD97599E5BA63470E9AF030BC62783E9900EB16AA90B9B4575C98305013F9B |
| tests/Feature/ControlRoom/ControlRoomLinkedSourceSearchTest.php | 5 | 803B2B2136D68D874B9C59A264646795239765B3762310E8C87AAFA704B44F86 |
| tests/Feature/ControlRoom/ControlRoomLinkedSourcePrivacyTest.php | 14 | 5F4657169A1E5CEE8F4A2492CBA2870E694B8813476172C528C8BB91FBC71557 |
| tests/Feature/ControlRoom/ControlRoomGovernanceCollectionIntegrityTest.php | 10 | 13836AB3B12DF92862D467D4F6A77210EC1845B21B0AD9E188BBD3C992162A7B |
| tests/Feature/ControlRoom/ControlRoomDeskTest.php | 6 | 04AEA145DB75A7E991FC400AC8F9A5FEC97D83D587E4FBE0640FF62910307374 |
| tests/Feature/ControlRoom/ControlRoomShiftHandoverScopeTest.php | 14 | 195B3CFBE33FB97EAC7790E52D384BEBE3DBFEE08DDF45CA1767B107C5B3AE86 |
| tests/Feature/ControlRoom/ControlRoomHandoverControllerTest.php | 4 | 1731FCD51380F669A0B824F406F9DB391839899F30C3FC9E7A05F57521449FFF |
| tests/Feature/Audit/AuditLogSurfaceTest.php | 6 | 954A300FB6AC072AB4AFFBECCCE3486BF7C763948358D4E96219164B48ED0342 |

## Exact direct source references

```text
database\factories\SubstanceExposureRecordFactory.php:6:use App\Models\SubstanceExposureRecord;
database\factories\SubstanceExposureRecordFactory.php:10:class SubstanceExposureRecordFactory extends Factory
database\factories\SubstanceExposureRecordFactory.php:12:    protected $model = SubstanceExposureRecord::class;
resources\js\components\health-safety\substance-detail-dialog.tsx:140:    exposure_records: ExposureRecord[];
resources\js\components\health-safety\substance-detail-dialog.tsx:152:    | 'record_exposure'
resources\js\components\health-safety\substance-detail-dialog.tsx:494:                    onClick={() => setAction('record_exposure')}
resources\js\components\health-safety\substance-detail-dialog.tsx:542:            ) : action === 'record_exposure' ? (
resources\js\components\health-safety\substance-detail-dialog.tsx:572:                            onAdd={() => setAction('record_exposure')}
resources\js\components\health-safety\substance-detail-dialog.tsx:1468:            {d.exposure_records.length === 0 ? (
resources\js\components\health-safety\substance-detail-dialog.tsx:1476:                    {d.exposure_records.map((rec) => (
database\migrations\2026_03_28_100002_create_hazardous_substance_tables.php:97:        Schema::create('substance_exposure_records', function (Blueprint $table) {
database\migrations\2026_03_28_100002_create_hazardous_substance_tables.php:131:        Schema::dropIfExists('substance_exposure_records');
resources\js\pages\health-safety\substances\index.tsx:438:                        openDetail(s.id, { action: 'record_exposure' }),
app\Providers\AppServiceProvider.php:139:use App\Models\SubstanceExposureRecord;
app\Providers\AppServiceProvider.php:171:use App\Observers\SubstanceExposureRecordObserver;
app\Providers\AppServiceProvider.php:517:        SubstanceExposureRecord::observe(SubstanceExposureRecordObserver::class);
resources\js\pages\health-safety\events\index.tsx:224:    SubstanceExposureRecord: { label: 'Exposure', icon: FlaskConical },
resources\js\pages\health-safety\events\index.tsx:966:    SubstanceExposureRecord: 'bg-status-warning-bg text-status-warning',
resources\js\pages\health-safety\events\index.tsx:1019:            SubstanceExposureRecord: 'EX',
app\Observers\SubstanceExposureRecordObserver.php:6:use App\Models\SubstanceExposureRecord;
app\Observers\SubstanceExposureRecordObserver.php:12:class SubstanceExposureRecordObserver implements ShouldHandleEventsAfterCommit
app\Observers\SubstanceExposureRecordObserver.php:19:    public function created(SubstanceExposureRecord $record): void
app\Observers\SubstanceExposureRecordObserver.php:43:            Log::error('SubstanceExposureRecordObserver: HsEvent creation failed', [
app\Observers\SubstanceExposureRecordObserver.php:50:    private function severityFor(SubstanceExposureRecord $record): string
app\Models\HazardousSubstance.php:73:    public function exposureRecords(): HasMany
app\Models\HazardousSubstance.php:75:        return $this->hasMany(SubstanceExposureRecord::class);
app\Models\SubstanceExposureRecord.php:11:class SubstanceExposureRecord extends Model
database\migrations\2026_06_20_140000_add_medical_treatment_to_substance_exposure_records.php:17:        Schema::table('substance_exposure_records', function (Blueprint $table) {
database\migrations\2026_06_20_140000_add_medical_treatment_to_substance_exposure_records.php:24:        Schema::table('substance_exposure_records', function (Blueprint $table) {
app\Services\HealthSafety\ChemicalExposureReadService.php:7:use App\Models\SubstanceExposureRecord;
app\Services\HealthSafety\ChemicalExposureReadService.php:106:    private function record(SubstanceExposureRecord $row, CurrentAuthorizationReads $reads): array
app\Services\HealthSafety\ChemicalExposureAccessService.php:8:use App\Models\SubstanceExposureRecord;
app\Services\HealthSafety\ChemicalExposureAccessService.php:61:        return $reads->query(SubstanceExposureRecord::query()->whereIn('site_id', $sites)
app\Services\HealthSafety\ChemicalExposureAccessService.php:66:    public function assertExposure(SubstanceExposureRecord|int $source, User $current, CurrentAuthorizationReads $reads,
app\Services\HealthSafety\ChemicalExposureAccessService.php:67:        array $sites, ?int $substanceId = null): SubstanceExposureRecord
app\Services\HealthSafety\ChemicalExposureAccessService.php:87:    public function sourceTuple(SubstanceExposureRecord|int $source, User $current, CurrentAuthorizationReads $reads, array $sites): array
app\Services\HealthSafety\ChemicalExposureAccessService.php:91:        return ['source_type' => SubstanceExposureRecord::class, 'source_morph' => $row->getMorphClass(),
app\Services\HealthSafety\ChemicalRegisterReadService.php:46:            'exposure_access' => 'restricted', 'exposure_records' => null,
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:11:use App\Models\SubstanceExposureRecord;
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:124:        $exposureBase = fn () => SubstanceExposureRecord::query()
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:185:            'initialAction' => in_array($request->get('action'), ['add_sds', 'add_storage', 'record_exposure', 'deactivate'], true)
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:433:        $substance->exposureRecords()->create([
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:471:                'exposureRecords' => fn ($q) => $q->with('user:id,name')->orderByDesc('exposed_at'),
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:540:            'exposure_records' => $substance->exposureRecords->map(fn (SubstanceExposureRecord $rec) => [
app\Http\Controllers\HealthSafety\HazardousSubstanceController.php:558:                'exposures' => $substance->exposureRecords->count(),
app\Http\Controllers\HealthSafety\HsEventController.php:25:use App\Models\SubstanceExposureRecord;
app\Http\Controllers\HealthSafety\HsEventController.php:130:        $exposureIds = $rows->where('source_type', SubstanceExposureRecord::class)->pluck('source_id');
app\Http\Controllers\HealthSafety\HsEventController.php:134:            : SubstanceExposureRecord::whereIn('id', $exposureIds)->pluck('hazardous_substance_id', 'id');
app\Http\Controllers\HealthSafety\HsEventController.php:367:            'exposure' => SubstanceExposureRecord::class,
app\Http\Controllers\HealthSafety\HsEventController.php:754:            'SubstanceExposureRecord' => $this->resolveSubstanceExposureSource($sourceId, $exposureMap),
app\Http\Controllers\HealthSafety\HsEventController.php:776:            : SubstanceExposureRecord::query()->select(['id', 'hazardous_substance_id'])->find($sourceId)?->hazardous_substance_id;
```

## Exact H&S scope caller references

```text
app\Support\Incidents\LinkedOperationalEvidencePresenter.php:11:use App\Services\HealthSafety\HsEventAccessService;
app\Support\Incidents\LinkedOperationalEvidencePresenter.php:17:        private readonly HsEventAccessService $hsAccess,
app\Services\ControlRoom\ControlRoomGovernanceReadService.php:10:use App\Services\HealthSafety\HsEventAccessService;
app\Services\ControlRoom\ControlRoomGovernanceReadService.php:22:        private readonly HsEventAccessService $healthSafety,
app\Support\HealthSafety\SafeWorkProcedurePresenter.php:17:use App\Services\HealthSafety\HsEventAccessService;
app\Support\HealthSafety\SafeWorkProcedurePresenter.php:324:                $events = app(HsEventAccessService::class)->applyReadableScope(clone $candidates, $viewer, $context, $candidates)->get()->keyBy('id');
app\Support\HealthSafety\RiskAssessmentPresenter.php:12:use App\Services\HealthSafety\HsEventAccessService;
app\Support\HealthSafety\RiskAssessmentPresenter.php:33:            abort_unless(app(HsEventAccessService::class)->applyFirstAidRiskSourceScope(HsRiskAssessment::query()->whereKey($ra->id), $viewer)->exists(), 404);
app\Support\HealthSafety\RiskAssessmentPresenter.php:68:            $ra = app(HsEventAccessService::class)->applyFirstAidRiskSourceScope(HsRiskAssessment::query()->whereKey($ra->getKey()), $viewer)->with([
app\Support\HealthSafety\RiskAssessmentPresenter.php:198:                    'events' => app(HsEventAccessService::class)->applyReadableScope(clone $candidates, $current, $context, $candidates)
app\Services\ControlRoom\AlertWorklistQuery.php:11:use App\Services\HealthSafety\HsEventAccessService;
app\Services\ControlRoom\AlertWorklistQuery.php:27:        private readonly HsEventAccessService $hsAccess,
app\Http\Controllers\ControlRoom\ControlRoomIncidentController.php:24:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\ControlRoom\ControlRoomIncidentController.php:189:                        app(HsEventAccessService::class)->applyReadableScope($event, $user, null, $candidates)
app\Http\Controllers\ClientController.php:101:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\ClientController.php:1333:                ? DB::transaction(fn () => app(HsEventAccessService::class)->applyFirstAidRiskSourceScope(
app\Services\Tasks\Providers\HsInvestigationProvider.php:11:use App\Services\HealthSafety\HsEventAccessService;
app\Services\Tasks\Providers\HsInvestigationProvider.php:160:                    return app(HsEventAccessService::class)->applyReadableScope($events, $actor, $context, $candidates);
app\Services\Tasks\Providers\HsEventProvider.php:10:use App\Services\HealthSafety\HsEventAccessService;
app\Services\Tasks\Providers\HsEventProvider.php:150:                return app(HsEventAccessService::class)->applyReadableScope($scoped, $actor, $context, $candidates);
app\Services\Tasks\Providers\HsCorrectiveActionProvider.php:13:use App\Services\HealthSafety\HsEventAccessService;
app\Services\Tasks\Providers\HsCorrectiveActionProvider.php:179:                    return app(HsEventAccessService::class)->applyReadableScope($events, $actor, $context, $candidates);
app\Http\Controllers\IncidentController.php:21:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\IncidentController.php:394:        return app(HsEventAccessService::class)->canView($event, $user);
app\Services\Tasks\IncidentJourneyTaskContext.php:11:use App\Services\HealthSafety\HsEventAccessService;
app\Services\Tasks\IncidentJourneyTaskContext.php:56:        if ($event && ! app(HsEventAccessService::class)->canView($event, $viewer, $readContext)) {
app\Services\Sites\Profile\SiteProfileSafetyPresenter.php:14:use App\Services\HealthSafety\HsEventAccessService;
app\Services\Sites\Profile\SiteProfileSafetyPresenter.php:78:            $items = app(HsEventAccessService::class)->applyFirstAidRiskSourceScope(HsRiskAssessment::forAssessable(Site::class, $site->id), $user)
app\Services\Sites\HazardWorkspaceConnectionsService.php:14:use App\Services\HealthSafety\HsEventAccessService;
app\Services\Sites\HazardWorkspaceConnectionsService.php:26:        private readonly HsEventAccessService $events,
app\Http\Requests\HealthSafety\StoreHsRiskAssessmentRequest.php:9:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Requests\HealthSafety\StoreHsRiskAssessmentRequest.php:35:            return app(HsEventAccessService::class)->applyFirstAidRiskSourceScope($query, $this->user())->exists();
app\Http\Controllers\HealthSafety\HsWorksafeDecisionController.php:8:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HsWorksafeDecisionController.php:38:        app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $request->user());
app\Http\Controllers\HealthSafety\HsRiskAssessmentController.php:19:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HsRiskAssessmentController.php:405:        return app(HsEventAccessService::class)->applyFirstAidRiskSourceScope($query, $request->user());
app\Http\Controllers\HealthSafety\HsRiskAssessmentController.php:425:            $event = app(HsEventAccessService::class)->applyFirstAidSourceScope(HsEvent::query()->whereKey($filters['hs_event_id']), $request->user())->firstOrFail();
app\Http\Controllers\HealthSafety\HsRiskAssessmentController.php:436:        abort_unless(app(HsEventAccessService::class)->applyFirstAidRiskSourceScope(
app\Http\Controllers\HealthSafety\HsInvestigationController.php:11:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HsInvestigationController.php:285:        app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $request->user());
app\Http\Controllers\HealthSafety\HsEventController.php:33:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HsEventController.php:288:        app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $request->user(), $context);
app\Http\Controllers\HealthSafety\HsEventController.php:1385:        app(HsEventAccessService::class)->applyFirstAidSourceScope($strictEventIds, $request->user());
app\Http\Controllers\HealthSafety\HsEventController.php:1551:            app(HsEventAccessService::class)->applyFirstAidSourceScope($eventQuery, $request->user(), null, $sourceCandidates);
app\Http\Controllers\HealthSafety\HsEventController.php:1629:        app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $request->user(), $context);
app\Http\Controllers\HealthSafety\HsCorrectiveActionEvidenceController.php:11:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HsCorrectiveActionEvidenceController.php:193:        app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $request->user());
app\Http\Controllers\HealthSafety\HsCorrectiveActionController.php:15:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HsCorrectiveActionController.php:275:        app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $request->user());
app\Http\Controllers\HealthSafety\HealthSafetyDashboardController.php:26:use App\Services\HealthSafety\HsEventAccessService;
app\Http\Controllers\HealthSafety\HealthSafetyDashboardController.php:141:            app(HsEventAccessService::class)->applyFirstAidSourceScope($lastNotifiableQuery, $user);
app\Services\HealthSafety\HsAnalyticsService.php:1084:        return $query->whereHas('hsEvent', fn (Builder $event) => app(HsEventAccessService::class)->applyFirstAidSourceScope($event, $viewer, null, $candidates));
app\Services\HealthSafety\HealthSafetyReadContext.php:177:                    fn ($current, $reads, $sites) => app(HsEventAccessService::class)->readFirstAidEventIds($current, $reads, $sites, $sourceTypes, $this, $sourceCandidates));
app\Services\HealthSafety\FirstAidSourceProjectionService.php:135:                if (! app(HsEventAccessService::class)->applyReadableScope(clone $query, $current, $active, $query)->exists()) {
app\Services\HealthSafety\EmergencyDrillService.php:218:                abort_unless(app(HsEventAccessService::class)->canView($event, $current), 403);
app\Services\HealthSafety\EmergencyDrillService.php:370:        abort_unless(app(HsEventAccessService::class)->canView($event, $actor) && app(TaskAggregator::class)->findItemFor($actor, 'corrective_action', $action->id, ['include_done' => true]), 403);
app\Services\HealthSafety\EmergencyDrillAccessService.php:146:                        && app(HsEventAccessService::class)->canView($event, $current)
app\Services\HealthSafety\EmergencyDrillConnectionsService.php:23:        private readonly HsEventAccessService $events,
app\Services\HealthSafety\FirstAidConnectionsService.php:27:        private readonly HsEventAccessService $events, private readonly TaskAggregator $tasks, private readonly ControlRoomAlertAccessService $alerts) {}
app\Services\HealthSafety\HsGovernanceService.php:382:        return app(HsEventAccessService::class)->applyFirstAidRiskSourceScope($query, $viewer);
app\Services\HealthSafety\HsGovernanceService.php:400:        return app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer);
app\Services\HealthSafety\HsGovernanceService.php:443:        return app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer, null, $sourceCandidates);
app\Services\HealthSafety\InjuryConnectionsService.php:27:        private readonly HsEventAccessService $events, private readonly ControlRoomAlertAccessService $alerts,
app\Services\HealthSafety\HsCorrectiveActionWorkspace.php:17:        private readonly HsEventAccessService $events,
app\Services\HealthSafety\HsVisibilityService.php:23:    public function __construct(private readonly HsEventAccessService $access) {}
app\Services\HealthSafety\HsEventAccessService.php:18:final class HsEventAccessService
app\Services\HealthSafety\HsEventAccessService.php:33:                return $this->applyFirstAidSourceScope($query, $current, $context, $sourceCandidates);
app\Services\HealthSafety\HsEventAccessService.php:46:        return $this->applyFirstAidSourceScope($query, $viewer, $context, $sourceCandidates);
app\Services\HealthSafety\HsEventAccessService.php:50:    public function applyFirstAidSourceScope(Builder $query, ?User $viewer, ?HealthSafetyReadContext $context = null, ?Builder $sourceCandidates = null): Builder
app\Services\HealthSafety\HsEventAccessService.php:204:    public function applyFirstAidChildSourceScope(Builder $query, string $eventColumn, ?User $viewer, ?HealthSafetyReadContext $context = null, ?Builder $sourceCandidates = null): Builder
app\Services\HealthSafety\HsEventAccessService.php:215:    public function applyFirstAidRiskSourceScope(Builder $query, ?User $viewer, ?HealthSafetyReadContext $context = null, ?Builder $sourceCandidates = null): Builder
app\Services\HealthSafety\HsEventAccessService.php:259:        $allowed = $this->applyFirstAidSourceScope(HsEvent::query()->whereIn('hs_events.id', clone $candidateIds), $viewer, $context, $sourceCandidates)
app\Services\HealthSafety\HsDashboardService.php:509:            $incidentsBySite = app(HsEventAccessService::class)->applyFirstAidSourceScope($incidents, $viewer)
app\Services\HealthSafety\HsDashboardService.php:577:        return app(HsEventAccessService::class)->applyFirstAidRiskSourceScope($query, $viewer, null, $candidates);
app\Services\HealthSafety\HsDashboardService.php:644:        return app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer);
app\Services\HealthSafety\HsDashboardService.php:694:        return $query->whereHas('hsEvent', fn (Builder $event) => app(HsEventAccessService::class)->applyFirstAidSourceScope($event, $viewer, null, $candidates));
app\Services\HealthSafety\HsKpiService.php:516:        return $query->whereHas('hsEvent', fn (Builder $event) => app(HsEventAccessService::class)->applyFirstAidSourceScope($event, $viewer, null, $candidates));
app\Services\HealthSafety\HsCorrectiveActionOwnershipService.php:189:            app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer);
app\Services\HealthSafety\HsRiskAssessmentService.php:259:            $event = $reads->query(app(HsEventAccessService::class)->applyFirstAidSourceScope(HsEvent::query(), $actor))->find($eventId);
app\Services\HealthSafety\HsComplianceExportService.php:199:            'hsInvestigation' => fn (BelongsTo $investigation) => app(HsEventAccessService::class)->applyFirstAidChildSourceScope($investigation->getQuery(), 'hs_investigations.hs_event_id', $viewer)->select(['id', 'hs_event_id', 'reference_number', 'investigation_type']),
app\Services\HealthSafety\HsComplianceExportService.php:284:                $event = app(HsEventAccessService::class)->applyFirstAidSourceScope(HsEvent::query()->whereKey($filters['hs_event_id']), $viewer)->firstOrFail();
app\Services\HealthSafety\HsComplianceExportService.php:311:        app(HsEventAccessService::class)->applyFirstAidRiskSourceScope($query, $viewer);
app\Services\HealthSafety\HsComplianceExportService.php:399:        return app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer);
app\Services\HealthSafety\HsComplianceExportService.php:442:        return app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer, null, $sourceCandidates);
app\Services\HealthSafety\HsModuleSummaryService.php:199:        return app(HsEventAccessService::class)->applyFirstAidSourceScope($query, $viewer);
app\Services\HealthSafety\HsModuleSummaryService.php:215:        return app(HsEventAccessService::class)->applyFirstAidChildSourceScope($query, $column, $viewer, null, $candidates);
app\Services\HealthSafety\HsModuleSummaryService.php:226:        return app(HsEventAccessService::class)->applyFirstAidRiskSourceScope($query, $viewer, null, $candidates);
app\Services\HealthSafety\HsModuleSummaryService.php:254:        return $query->whereHas('hsEvent', fn (Builder $event) => app(HsEventAccessService::class)->applyFirstAidSourceScope($event, $viewer, null, $candidates));
app\Services\HealthSafety\LoneWorkerSessionConnectionsService.php:25:        private readonly HsEventAccessService $events, private readonly TaskAggregator $tasks) {}
app\Services\HealthSafety\RestraintConnectionsService.php:97:        if ($hs && app(HsEventAccessService::class)->canView($hs, $current)) {
app\Services\HealthSafety\RiskAssessmentWorkspaceConnectionsService.php:24:        private readonly HsEventAccessService $events,
app\Services\HealthSafety\RiskAssessmentWorkspaceConnectionsService.php:141:        return $this->events->applyFirstAidRiskSourceScope($query, $viewer, $context, $candidates);
app\Services\HealthSafety\SafeWorkProcedureAccessService.php:215:        abort_unless(app(HsEventAccessService::class)->canView($event, $current, $context), 403);
```

## Parent CR operator-note provenance handoff

The received CR source seam uses context.root_note_origin version1/source=operator_note, bound to the persisted OperatorNote ID, alert, actor and SHA-256. This is a required prospective private exposure/injury source-writer and delivery integration dependency. EVERY H&S source write that takes ownership of the CR root note must atomically invalidate that operator reference or replace it with explicit source-owned provenance, INCLUDING an identical-text replacement. Text equality does not preserve operator ownership after source replacement. The current SubstanceExposureRecordObserver does not project a CR root note directly; its indirect monitoring/delivery copies and any future exposure bridge must respect this ownership seam. Legacy missing provenance remains unknown, never inferred clinical/source/operator ownership. CR consumer implementation and live injury/exposure writers remain their respective owners; this review changes neither.
## Prospective private writer contract needed by the canonical derived projection

This is a requested dependency contract, not an existing schema/API or allocation to this document's author. Private writer200200 remains separate from public chemical200100. The canonical exposure projection can already enforce fresh wellbeing+safety+HR/Site before private source SQL, reuse supplied active context, and classify literal class/morph/category/worker/Site identities. It cannot claim immutable recorded attribution, known original incident Client/stay/shift, or durable delivery from today's legacy model/observer.

The writer/read-proof owner should expose one active-callback source proof, for example sourceProof(SubstanceExposureRecord, current User, CurrentAuthorizationReads, approvedSites): detached scalar array. Required result: attribution_state recorded|legacy_unknown|repair_required; nullable source_version_id/source_revision; retained canonical exposure/substance/worker/Site identities; incident binding explicitly absent|recorded|unknown with original incident/Client/stay/shift values only when actually retained; source identity/category and exact persisted aggregate proof. Caller must not infer known-null from omitted keys. A retained typed history with downgraded/missing markers must report repair_required; true legacy remains unknown. Proof must bind emitted current facts/revision and immutable retained snapshot/digest/tuple, not certify markers alone. Prepared readers must not reinterpret public ChemicalSourceVersion as private exposure history.

The projection should offer readableHsEventIdsInContext(User, independent already-filtered HsEvent Builder, HealthSafetyReadContext):array, plus detached copied-source projection for actual CR/H&S consumers. Candidate IDs stay bounded and Site-scoped before discovering sources; final denial remains conservative/complete for known source bindings even if candidate evidence is incomplete. Supplied context must be active, same viewer/connection and completely prepared; no fallback context, no escaping model/Builder/proof handles, no global memo. Exposure source permission precedes symptom/treatment/name, count/search/page and copied text. Denied returns restricted/null; missing/archived source unavailable/null; damaged typed proof unavailable/null with repair_required; unrelated family absent/null with explicit ignored marker. Current legacy unknown incident association may retain unknown status, but cannot grant a linked Client/stay/shift destination.

Prospective command/delivery must distinguish affected worker user_id from recorder created_by, retain original Site and incident context at capture, and update/reconcile derived H&S state on real correction/removal through durable receipt/outbox proof. No-op must not certify legacy history. If a source writer or delivery replaces a CR root note, it must obey the operator root_note_origin ownership seam above atomically even for identical text. Existing observer may not be treated as successful durable delivery or original-context proof. Exact private model/version/delivery names and200200 columns must come from the writer owner before source integration is called complete; none are invented or mounted here.