# Reported-facts implementation handoff — isolated source candidate

2026-10-12. SOURCE ONLY. Optional Unknown is PROVISIONAL, not a received human answer. All PHP/Pint/unit/native/DB/worker/browser checks are UNRUN and runtime remains HOLD. No route, private alias, reader, destination classifier, risk/shared notification mount or grant was applied. No final freeze or operational acceptance.

## Actual allocated source

New `ChemicalExposureReportedFacts.php` is a closed pure helper, with legacy/capture/transition/assertContract/project/response APIs. It accepts exactly three fact fields and exact seven-key original evidence identity: intent_id,revision,actor_id,exposure_id,worker_id,site_id,substance_id. Unknown/null, explicit No/false and omission remain distinct. Snapshot fields must all exist; values/entries/identities are strictly typed, closed and representable. Source itself must separately prove current authority and original acceptance; this helper is not a permission or provenance token.

New allocated `2026_10_12_200600_add_chemical_exposure_reported_facts.php` makes the existing attention/incident flags nullable/defaultNULL, retaining historical0/1 verbatim. No new root provenance columns/model/table/backfill/tenant/index/FK. Existing Boolean casts already preserve null. Down checks all rows including soft-deleted and retained reported_facts key presence including malformed/null before any ALTER. The earlier schema-only proposal and zero-test design manifest are historical; use this implementation manifest and full composition.

New four complete suites contain53 DECLARED METHODS: pure16, nativeSource28, migration6, physicalConcurrency3. All UNRUN. These are source method declarations, not inferred datasets, native case counts or passes. Native source/migration/concurrency suites REQUIRE the Source/ledger proposal below. Guarded concurrency uses the existing unchanged ChemicalExposureCommandWorker with real2-worker start/first-claim barriers, canonical testing MySQL guards and<=1GiB per process; no worker was launched. Test fixtures use actual Source commands and actual strict Ledger acceptance for historical pre-contract captures; no synthetic typed version/receipt/permission stub. Corruption is explicit query mutation after genuine acceptance with restoration positives. The sealed linked-legacy test expects the actual composed sole source validation error before root medical-body materialisation.

## Single unapplied integration patch

`CHEMICAL-EXPOSURE-REPORTED-FACTS-SOURCE-UNAPPLIED.patch` is13 narrow semantic hunks across Source, ledger and two intentional existing whole SourceCommandTest premise repairs. Rebased against ACTUAL root-composed Source357DA1FF830200A2E0D5076EFC2CFA829C0DB67F07AD53C9609DE3DA7D5E9076, ledger9B2908CCEC844EFFFF649DB5F86AA51BA6FAE76674094474E6CF815D4E910F3A, existing whole source suite pin in manifest. Live files remain unchanged by B. Root body/lineage helper is not duplicated. Hunks have exact textual old blocks and explicit line ranges; no git/PHP patch application check or executable check occurred. Review/compose under owner control before any admission.

Create null defaults and nullable independent validator rules replace only the former category derivation. Input absence uses array_key_exists. Existing normalization preserves explicit null and strict Boolean scalars. Correct/child commands retain complete effective fixed map in private immutable version.facts; omission never attributes a field to the current command actor. Explicit same-value legacy/unanswered/prior-context confirmation is a genuine changed provenance command; same already-reported value stays the existing allowed correction no-op and original evidence. Same version/revision/UUID/global intent/fingerprint/source_tuple/audit/source_content_digest receipt contract remains. No additional audit sanitizer key, receipt key or generic medical body.

Before latest private contract/version body, currentVersion admits exact-root retained fact-history metadata using existing audit-bound admitVersionMetadata. Missing/malformed/latest-stripped contracts cannot become legacy again. Reported entries then match the original field's actual accepted version/intent/actor/worker/Site/substance/value and strict receipt/audit anchor. At most three distinct original reporting revisions are fully validated per contract; no recursively unbounded acceptance traversal. Current root revision, every child revision and existing historical before-context proofs remain independent. Root-body sealed linked-legacy lineage stays mandatory; an explicit fact does not unseal it. Genuinely unlinked legacy and pre-contract schema1 fields remain legacy_unconfirmed even after real narrative/child acceptance.

Proposed Source methods become callable ONLY AFTER patch composition:

```text
reportedFactsForSource(SubstanceExposureRecord|int source,
    User current, CurrentAuthorizationReads reads, array sites): array
reportedFactsForSnapshot(SubstanceExposureRecord presented,
    User current, CurrentAuthorizationReads reads, array sites): array
```

The first freshly admits exact current source. The second freshly compares canonical full snapshot and proves the SAME provided model immediately before its projection; use it when attaching fields to an existing admitted record DTO. It refuses later accepted or unversioned mutation rather than mixing a second model's proof with the presented medical body. Both require saved-private current dual/Site/original-context authority, return detached scalars only, and cannot be used for capture-only receipt recovery. No nested viewer refresh, current identity fallback or escaped model/read handle.

Exact detached projection:

```text
{
 medical_attention_sought: boolean|null,
 incident_reported: boolean|null,
 medical_treatment: retained category|null,
 fact_states: {
   [each of the three fixed fields]: {
     state: reported|reported_unknown|unanswered|legacy_unconfirmed|prior_context,
     recorded_value: exact private scalar|null,
     reported_at: original accepted UTC instant|null
   }
 },
 response: {
   reported_attention: yes|no|unknown,
   recorded_category: retained category|null,
   category_state: same fact-state enum,
   response_floor: low|medium|high|critical,
   basis: reported_category|reported_attention|operational_triage,
   care_review_needed: boolean,
   harm_assessment: unassessed
 }
}
```

Top-level flags are confirmed current-tuple reported answers only; unconfirmed old false is Unknown with privately retained recorded_value=false. Category stays visibly recorded for parity, but category_state is authoritative: prior_context/unconfirmed category MUST NOT be labelled currently reported or used as a current category floor. Worker/Site change preserves old evidence and marks it prior_context until explicit re-reporting; does not invent current employment for historical subject reads. Original Sites/Clients are admitted before inherited evidence bodies. Original timestamps come from accepted versions, not the current editor or clock.

## Selected response policy and limits

Pure response retains reported category floors (none Low, first_aid Medium, medical/hospitalisation High, death Critical); Yes with absent/unconfirmed category retains High operational response. Wholly Unknown/unconfirmed uses Medium operational triage pending review, never assessed harm. Separate care_review_needed covers both discordant directions: Yes+none/first_aid and No+medical/hospitalisation/death, plus Unknown/unconfirmed/prior-context. No validation rejection or automatic investigation, diagnosis, fitness, WorkSafe, closure or release is added. Root owns destination classifier adoption, independent raised severity/investigation/WorkSafe/owner/handover preservation and whole composed marker proofs; HSE source was not changed here.

Frontend root already preserves correction omission and per-field explicit confirmation; untouched capture blank omitted, explicit Unknown null, No false. Reader/collection/permanent index/counts still need this proved projection rather than raw bool casts or unchecked SQL stored-flag counts. Original create-only minimal12-key receipt remains unchanged and grants no enduring private read. No successful source acceptance is downstream delivery.

## Complete suite dependencies and concrete remaining reviews

Run no partial filtered acceptance: new4 suites plus complete existing SourceCommand (14 methods, two proposed premise changes), SourceMigration, ReplayPrivacy, Lifecycle, Concurrency, OriginalContext, HistoricalProof, RootBodyAdmission, WorkspaceRead/Controller, CollectionAdmission and root HsEventDelivery as their related owners compose actual bytes. Retain prior original124/<100 query failure and full-native46 failures as historical unresolved evidence; no new performance or green claim.

Specific existing-premise warning sent root: HistoricalProof test_historical_receipt_and_intent_require_their_original_site_even_after_later_same_site_revision expects current source proof recorded after the original Site is withdrawn. Root-composed body-lineage now admits every original receipt Site/context before root body; that case can deny independently of new reported evidence. No assertion was weakened or live historical suite edited. Legacy HazardousSubstanceController hospitalisation omission still derives attention in its unmounted old alias; root owns replacing both transports and their complete HTTP parity assertions. This new Source contract must not be claimed mounted while old aliases behave differently.

C's notification descriptor remains a separate UNAPPLIED Followup patch; B's finite review found/correctly reported an omitted closure capture, now repaired by C. Fixed current schema columns and original accepted membership/actor/recipient proof were read-reviewed; opaque fingerprints remain same-statement stability checks, not grants. Followup bytes remain36EF2B5F... unchanged by B. C's further taskRows proposal is not silently included here. All source-family, collection, sourceCommitted/destination, recovery and private HTTP prerequisites remain explicitly open until full composition and coordinator native/browser acceptance.
