# HS14 additive migration audit

Prepared helper: `tests/Support/EmergencyDrillMigrationAudit.php`. This helper has not been executed. Root must inspect the candidate and approve execution after the sole native test runner is confirmed terminal. It is separate from feature-suite migration discovery.

The helper reads table definitions only from `oblivion_hs_preview_20261007_2118`; it copies no source rows and never migrates or rolls back that database. It creates a fresh random `oblivion_hs_drillmigaudit_20261008_<8 hex>` schema, refuses an existing schema, switches the application connection only to that schema, and checks both the configured and actual database before migration or cleanup. Only final `2026_10_08_180200_add_emergency_drill_lifecycle.php` is loaded, rather than the full migrator. Cleanup may drop only the exact schema created by this invocation; bootstrap/guard failures retain it and report the failure. No file blobs, notifications, seeders or lifecycle services run.

Synthetic pre-migration rows cover scheduled, completed/failed and cancelled drills; attendance notes; open/resolved/closed/accepted legacy findings; legacy evidence metadata; and original audit history. Every original column is compared exactly across additive up and an empty-new-evidence down/up. The audit checks that the migration manufactures no command or delivery receipts.

Independent destructive rollback refusal cases cover creation key, standalone creation fingerprint, previous-drill link, cancellation time, standalone cancellation actor, standalone cancellation reason, advanced source lock version, nonempty and explicitly empty participant accommodations, canonical remedy pointer, populated and empty recorded resolution evidence, an immutable command receipt, and pending/failed/delivered/suppressed/skipped delivery receipts. Each case must preserve the new schema and all synthetic rows; fixtures are reset between cases. Existing legacy terminal statuses and history must remain exact.

Read review identified missing independent down guards for `creation_fingerprint`, `cancelled_by`, and `cancellation_reason`; these cases intentionally require refusal. Coordinate a narrowly approved migration correction after the native freeze before a successful audit can be expected.

Root-reviewed execution from the isolated worktree uses:

```powershell
& 'C:/Users/steph/.config/herd/bin/php84/php.exe' tests/Support/EmergencyDrillMigrationAudit.php --execute-approved-shadow-audit storage/logs/hs-drill-migration-audit-r1.json
```

The required switch prevents accidental execution. The numbered JSON artifact must not already exist; every attempt is retained. The report records definition/migration/baseline hashes, exact checks, refusal outcomes and cleanup result, without source rows or credentials. PHP lint/Pint alone do not connect to a database or execute this helper.
