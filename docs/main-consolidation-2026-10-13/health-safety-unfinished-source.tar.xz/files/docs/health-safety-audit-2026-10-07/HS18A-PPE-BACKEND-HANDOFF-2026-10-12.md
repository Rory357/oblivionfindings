# HS18a PPE backend source handoff — 12 October 2026

Source-only construction in the isolated H&S worktree. Runtime HOLD remains: PHP syntax, Pint, test discovery/execution, migration application, browser, database, provider and build acceptance are ALL UNRUN. This is an ownership/API handoff, not a final source freeze or release claim. No controllers/routes/access/read/UI/shared audit or external worktree files were edited by this owner.

## Lifecycle and command transport

PpeCommandService methods: createType, updateType, setTypeActive, createInventory, updateInventory, allocate, acknowledge (own=false; true selects own command), returnAllocation, inspect, condemn, dispose, uploadAttachment(parentType,parentId,actor,input), removeAttachment(parentType,parentId,attachmentId,actor,input). Existing records require original UUID and expected_version. New capture requires UUID with no expected_version. Type revisions are independent; every inventory child/evidence command advances the inventory aggregate exactly once on a real change. UUIDs are globally unique within PPE. Unknown domain fields are rejected. The HTTP owner strips explicit framing/navigation keys only.

Receipt has exactly 11 keys: accepted, actor_id, command, idempotency_key, root_type, root_id, source_type, source_id, expected_version, version, source_version_id. No replay flag, narrative, filenames, path, digest or cleanup IDs. Command names: create_type, update_type, activate_type, deactivate_type, create_inventory, update_inventory, allocate, acknowledge, acknowledge_own, return, inspect, condemn, dispose, upload_attachment, remove_attachment. Root enum type|inventory; source enum type|inventory|allocation|inspection|inventory_attachment|allocation_attachment|inspection_attachment.

Changed acceptance requires expected+1/non-null exact version. Creates require expected=null/version1/non-null version. Unchanged update_inventory/update_type/activate_type/deactivate_type/acknowledge/acknowledge_own alone may retain expected/null version; retained version identity cannot be erased to claim no-op. Replays recheck current original authority and exact actor/intent/audit/source identity before returning immutable original acceptance, even after later revisions.

Quantity is whole-record metadata. New allocation requires no active issue, available/in-date positive stock and an active, intact catalogue definition. Fail/needs_repair quarantines maintenance even while issued; passing does not auto-release. Explicit maintenance→available uses update_inventory(status=available,reason) after a governed pass after the hold, without active issues. Hold is update_inventory(status=maintenance,reason). Generic fact edits cannot forge allocated/condemned/disposed or resurrect terminal stock. Return retains quarantine/terminal stock and other active legacy issues. Existing condemned condition without new return evidence stays maintenance, with no fabricated condemnation actor/time. Initial condemned factual capture likewise enters maintenance. Fit/training true facts require actual nonfuture dates; this does not certify competence or currency.

## Current read helpers

constraints(admittedFreshInventory,uncappedActiveCount,freshType=null) returns hold/allocate/condemn/dispose/inspect/release => {allowed,blocked_reason}. The read owner intersects current capabilities; the helper grants nothing. sourceState(root,source=null) returns recorded|legacy_unknown|repair_required. currentVersion is an internal active-authority model proof only. historyProjection(root,version) returns validated bounded id/revision/command/at/actor metadata or integrity=repair_required.

evidenceProof(root,attachment) retains exactly {attribution_state,available}. evidenceReadProof additionally supplies INTERNAL byte_proof={digest,size}|null from the SAME verified byte read; never serialize it. Controller spools a single opened stream and compares that stream to this descriptor before emission. Genuine legacy stays unknown. Public-disk metadata is never private availability. Missing typed proof, marker downgrade, metadata/digest/actual-byte mismatch is unavailable/repair, not legacy.

ownSourceState(admittedNarrowInventory,admittedOwnAllocation) returns the same attribution enum using separately selected factual_content/factual_digest for current root and own_content/own_digest for exact allocation only. No private version.content, actor, command UUID, evidence or another allocation data is hydrated. Current canonical ownership/staff/Site admission remains the access owner's prerequisite. Prospective real writes commit these separate snapshots; missing earlier typed proof is repair, genuine schema0 unknown stays unknown. An unchanged child's revision remains distinct from a later aggregate revision. No-op does not newly certify legacy.

## Durable evidence recovery

Multipart/file commands explicitly refuse any existing outer transaction BEFORE reserving or writing files. Normal HTTP commands start outermost. A same-connection current-authorised reservation transaction physically commits each unique generated private path, actor, original source/root/Site, command/UUID/intent/expected revision and actual file digest/size BEFORE filesystem writes. Only new capture may have a null original root/source. Reservation identity is immutable and separately digest-bound. Acceptance freshly checks authority/revision, byte identity and exact attachment/version/receipt linkage, then binds the reservation within the domain transaction.

Staging states: staged|accepted|cleanup_pending|unknown|cleaned. A staged reservation is not acceptance or an availability claim. False storage, byte-read failure, audit/source/binding veto and crashes leave a durable inspectable attempt. Checked rollback cleanup updates delivery separately. Revocation, unreadable/different bytes or failed state persistence leaves the original reservation discoverable; no orphan is labelled cleaned. Cleanup never deletes an accepted or retained referenced path, another attempt's bytes, public files, or bytes whose identity cannot be confirmed. A changed-byte attempt remains unknown and requires repair; no automatic destructive repair is invented.

Public APIs:
- stagingAttemptsForViewer(User,afterId=0): {attempts:[{id,state,accepted:false,command,recorded_at,can_retry:true}],next_cursor}; only this actor's unresolved currently admitted sources/Sites, 25 rows, no totals/paths/UUIDs/content.
- stagingAttemptsForKey(User,UUID,afterId=0): direct JSON-only original command discovery {attempts:[{id,state,accepted:bool}],next_cursor}; UUID must stay out of navigation/history.
- stagingForViewer(User,id): {id,state,accepted:bool}; accepted=true requires exact retained acceptance/path proof.
- resumeStagingCleanup(User,id): {id,state,accepted:false}; outermost only; accepted/reference/identity mismatch protected.
- cleanupAttemptsForViewer(User,afterId=0): {attempts:[{id,state,removed_from_record:true,recorded_at,can_retry}],next_cursor}; this actor's pending|unknown removal deliveries, exact current root/parent/Site/evidence authority. Public legacy has can_retry=false.
- cleanupForViewer(User,id), resumeCleanup(User,id): {id,state,removed_from_record:true}.

Removal requires attributable reason(max2000) in intent/history, never receipt prose. Active row removal and private cleanup tombstone commit together. Receipt confirms removal from active record ONLY; physical purge happens after the real outer commit, checks exact removal receipt/audit/version/path/bytes, and persists a separately checked pending|unknown|complete outcome. Exact retry resumes delivery without another lifecycle revision or receipt mutation. No scheduler/provider endpoint is registered by this package.

## Remaining integration and acceptance

Root owns command/controller/request guards, permanent pages, direct-JSON receipt/staging lookup, protected spool download, recovery list/retry endpoints and old HTTP fixture adaptation. Access/read owner owns current canonical admission, scoped read proof, lists/export/pickers/own GET/MyDay source privacy. Historical public evidence relocation remains an actual prerequisite; schema metadata alone certifies nothing. Corrupt/unattributed bytes intentionally remain protected unknown/repair rather than being blindly purged. Cross-domain Workforce eligibility, training/fit qualification and provider delivery are excluded. Native admission must include full migration chain, existing PpeRegisterTest, all eight complete owned suites and guarded concurrency workers; no partial passing claim or resource launch has occurred.

Eight complete prepared suites below contain 84 declared test methods (filesystem count only; no inferred executable cases/assertions). Concurrency worker requires testing, exact test database and MySQL, process memory≤1GiB and bounded barriers. Physical-commit tests use guarded committed fixture cleanup. All checks are UNRUN.

## Owned source pins

| Path | SHA256 | Declared test methods |
|---|---|---:|
| app/Services/HealthSafety/PpeCommandService.php | 013A1348AAC6D202512734AEABDAD64DA0A9778F3A50D43650133C4B7090E73E | 0 |
| app/Services/HealthSafety/PpeCommandValues.php | 6665416D80A7BD2C562B2CC9C1299930552B982723501D9F33E5179AF53DAD46 | 0 |
| app/Services/HealthSafety/PpeEvidenceStorage.php | 5F0A91FC76BF931048F40387080B006DDCE897CE6EAD69D98DF147622E44C0E0 | 0 |
| database/migrations/2026_10_12_200000_create_ppe_command_history.php | DD4561AD2D116B01A9897EEBF3A7C7F498037BADFD35ED9D4DCE3A20A8014998 | 0 |
| app/Models/PpeCommandReceipt.php | 6AE3ACDCA99808B8A7BD044660CDC46A60223C4618DB4095CC2E2EFA727957E1 | 0 |
| app/Models/PpeSourceVersion.php | E97316E3660B32CF7805633B286AC13E9DD5F6AEFF1B6C0FF83F12EE752A454C | 0 |
| app/Models/PpeEvidenceCleanup.php | DA582D45F67F558F2E7A5763A935B66951BAC2BF7693A387C4380731EB5271B1 | 0 |
| app/Models/PpeEvidenceStaging.php | E6AB318DF569DE31B5E6A328E8F589D5E4000D366569177FC0FDFA37C85A13E2 | 0 |
| app/Models/PpeType.php | 06C16C8D832AC78E744288F0C10E0FF8FFD1D3DD53322F4DD57228A8A2EB51B5 | 0 |
| app/Models/PpeInventory.php | 1B07CB6AC60807E07250B1A2500C98EFE9248ADEA9AD73D51B9C770CA2CFA1C2 | 0 |
| app/Models/PpeAllocation.php | 32EFE7D289C579539817BDA16A84F9ADC5104E544774FB2C17826487B050F0FF | 0 |
| app/Models/PpeInspection.php | 274F8ECBDFA773DFED422744A23BF53306EC7897CDC215E8BD119D844B9F197C | 0 |
| app/Models/PpeAttachment.php | F366DAD3C1797495452FD9832F305EF70D0F1DD53C7A55DE0E61DC357EF4EB00 | 0 |
| app/Models/PpeAllocationAttachment.php | 3F7C19D8624F0513AE2548C7213E51516F0F3472DEE369729B531FA2A27758DB | 0 |
| app/Models/PpeInspectionAttachment.php | 1A2B0878C16D40AF3F43E59BAE338499A3E257B9EEA285B4C30CD390686DCCC4 | 0 |
| tests/Feature/HealthSafety/PpeCommandTestCase.php | B9C2B6040B4286C8F8A86CAA9E65F2276AF88415D4693CB818CE055D89E1D377 | 0 |
| tests/Feature/HealthSafety/PpeCommandLifecycleTest.php | F8D6A36D3B67E569B02CEB3F868802EDE902AB1BCD343E71637EC57BFB252E7C | 13 |
| tests/Feature/HealthSafety/PpeCommandReplayTest.php | 0FD55BBD7FF2D5BC51FEB2D829D38250C024F61E17EAF148B7D5FBE0B0E49613 | 11 |
| tests/Feature/HealthSafety/PpeCommandIntegrityTest.php | 3F1B43614901F930955E17FD3CF316BC2588BCAFD646C6BA11423F0185127A7A | 12 |
| tests/Feature/HealthSafety/PpeCommandEvidenceTest.php | 580544F9B861471BFDE2CB2632BC1564112E822D719D415BF477C59CF96F49F2 | 16 |
| tests/Feature/HealthSafety/PpeCommandConcurrencyTest.php | AE34ACE95722D2D17BD7A28D1E2124479ACC119799AAB48725F86B2576B83D19 | 3 |
| tests/Feature/HealthSafety/PpeCommandMigrationTest.php | BFCA02398ED67545F544C2D3AB73D3D645EECCC41CF2BD31285FEA4493040A55 | 4 |
| tests/Feature/HealthSafety/PpeCommandStagingTest.php | 9126D9AB6F5FDAE234BBB5B716A0D7B3D5F202D45DCF7A947B810818CC486589 | 17 |
| tests/Feature/HealthSafety/PpeCommandOwnProofTest.php | E6511C6C09F1640892F4E110F14FAEF23E4496251172C0F5CB801C48DC51E15D | 8 |
| tests/Support/PpeCommandWorker.php | 8567B6B139E34A4DA837ACE0793F82833E88DABA604AB82499DB4DC1F14030FA | 0 |

## Observed external dependency pins

These are observed dependencies, not owner edits or a cross-owner freeze. AuditLogger must retain strict logOrFail persisted acceptance; original controller/register suite pins may subsequently change under their owners.

| Path | SHA256 |
|---|---|
| app/Services/HealthSafety/PpeAccessService.php | 4A09477EC013E430B9C97CC4D0F9FE3C7252F44FF70CAA7B42FA6254CB613E66 |
| app/Services/AuditLogger.php | 7065627C06A212627F12CBCCD605AF2B7F1528CD3571D006C19AFB8D927F3082 |
| app/Http/Controllers/HealthSafety/PpeController.php | 3C204967C2422BC4C78F5B92736339BF85983C7D348206649CB22AC03D2F2978 |
| tests/Feature/HealthSafety/PpeRegisterTest.php | 2444F6036780F0859FFF3A958199A9B1F0F16004F2C467839B92B2FF910B48FE |
