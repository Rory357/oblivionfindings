# Group C source connection read closure

Source preparation only, 2026-10-12. PHP syntax, formatting, native suites, database, browser and build checks are **UNRUN**. This is an implementation handoff, not a frozen input inventory or passing acceptance claim. Work is confined to the isolated Health & Safety worktree.

## Public interfaces and current callers

Existing `forViewer(source, viewer, returnTo = null): array` signatures and scalar envelopes are retained for First Aid, Emergency Drill and Lone Worker connections. Emergency Drill `forFinding(drill, finding, viewer, returnTo = null): ?array` is retained. Each connection operation prepares one fresh union of First Aid, Restraint, Injury, Procedure, Drill and its actually used independent destination keys, then consumes its original module admission through `withReadContext`. Preparing a key grants no permission.

The actual First Aid entry method is `sourceForReview(HsEvent, User, ?HealthSafetyReadContext = null): ?array`, rather than `forHsEvent`. A supplied context must belong to that viewer and contain the required union; it is never replaced by a fresh fallback on a missing-key, foreign-viewer or expired-context error. Its existing `{type, id, label, url, unwired}` DTO remains unchanged. Standalone callers prepare a fresh complete source union. The incoming model supplies only its ID; current persisted family, category and source tuple establish admission.

Lone Worker adds only `LoneWorkerSessionAccessService::withReadContext(context, operation): mixed`, delegating to `consumeViewer(PERMISSIONS, operation)`. Existing standalone APIs and `assertRecord` semantics remain unchanged. Internal approved current staff and active approved H&S Sites remain required. The existing assertion's bounded source-read wrapper is retained; it does not hydrate another permission actor.

Current production callers:

| Caller | Connection operation |
| --- | --- |
| `app/Support/HealthSafety/FirstAidPresenter.php:39` | First Aid `forViewer` |
| `app/Support/HealthSafety/EmergencyDrillPresenter.php:40` | Drill `forFinding` |
| `app/Support/HealthSafety/EmergencyDrillPresenter.php:58` | Drill `forViewer` |
| `app/Http/Controllers/HealthSafety/EmergencyDrillController.php:177` | Drill `forViewer` |
| `app/Support/HealthSafety/LoneWorkerSessionPresenter.php:40` | Lone Worker `forViewer` |
| `app/Http/Controllers/HealthSafety/HsEventController.php:694` | First Aid `sourceForReview`, root-owned forwarding of the existing active context |

Existing source presenters retain their independent outer read wrappers. This package establishes one permission preparation within each connection operation; it does not claim one universal callback per HTTP request.

## Source and destination boundaries

Every owned H&S query constructs the independent exact candidate first and calls `applyReadableScope(clone $query, $current, $context, $query)`. Candidate filters precede source discovery and final correlation remains binding.

- First Aid: exact class/morph, source ID, Site, injury category, nullable Client and staff treatment subject. A separately readable linked Incident uses its exact source ID, Client/Site, actual reporter and production incident/near-miss category. Archived treatment remains readable under the existing source policy.
- Drill: exact class/morph, source ID, Site, drill-failure category and null Client/staff, matching actual producers. A finding is reread from its current parent before its link is consulted. Only corrective action identity is read before proving the exact parent event; full action fields follow successful proof. Previous/next drill links retain exact current same-Site rules and full list behavior.
- Lone Worker: canonical session/worker/shift/Client/Site admission, processed Signal and exact alert provenance precede the H&S candidate's retained direct alert FK/Site/nullable Client filters. No category or source-type rule is invented where no canonical producer establishes one. Independent incident/H&S visibility survives denied Control Room entry. Response identity/provenance is selected before its independent grant; response status/times/assignee are materialized only after its own readable scope.

All exact Tasks lookups use the gate-runner's additive fifth `findItemFor(..., $context)` argument. They consume the same complete prepared source union, retain exact ID/include-completed/top-300 provider behavior, and materialize only scalar connection fields before callback exit. No actor, source model, builder, context or Tasks object is returned in the connection DTO.

## Owned current pins

| File | SHA-256 |
| --- | --- |
| `app/Services/HealthSafety/FirstAidConnectionsService.php` | `0F2DE7991B6E7D90A073CA68CDB07F40CAFB74C7F438FFAFD3FB0F998D58EF82` |
| `app/Services/HealthSafety/FirstAidSourceProjectionService.php` | `3C850A8F5E9593008A50065F773F6AC9F2070ED8BD9A9E99059FBA52FB59288F` |
| `app/Services/HealthSafety/EmergencyDrillConnectionsService.php` | `D5C910180920AC2B2C1457CA9E29EF2ED542B7DC3440F49644073938FDA43C4B` |
| `app/Services/HealthSafety/LoneWorkerSessionConnectionsService.php` | `A685DB26390FA7BD79C50B78C0E2D1AB9553B61BF4815BCFF788CCB6E57D98F0` |
| `app/Services/HealthSafety/LoneWorkerSessionAccessService.php` | `3BA05E5A60D6998D6E0AD4C7F6DD3845BB84F615DF9E20C34C217D016E00CAAC` |
| `tests/Feature/HealthSafety/HsSourceConnectionContextPrivacyTest.php` | `030325B081D8E9F37E828BF97E28048D776031DD1F6E7116B2DF12F98F46AA71` |
| `tests/Feature/HealthSafety/FirstAidWorkProjectionTest.php` | `2BC1518E308B0ED87F2020B6B68643AF458B422DEF7937D400099878D538D435` |

The existing First Aid work-projection suite retains all nine methods and negatives. Its one positive Incident review fixture now records the actual production reporter and category. No query limit, grant or denied-source expectation was relaxed.

## Whole-suite feedback selection

Every filename below is complete, beneath `tests/Feature/HealthSafety/`; no selectors are proposed. Counts are declared method counts, not executed cases. These 14 files declare 213 methods, all **UNRUN** against this candidate.

| Complete suite | Methods |
| --- | ---: |
| `HsSourceConnectionContextPrivacyTest.php` (new) | 16 |
| `FirstAidWorkProjectionTest.php` (one canonical positive fixture) | 9 |
| `FirstAidEntryIntegrationTest.php` | 8 |
| `FirstAidWorkspaceTest.php` | 14 |
| `EmergencyDrillWorkspaceTest.php` | 12 |
| `EmergencyDrillWorkProjectionTest.php` | 11 |
| `EmergencyDrillLifecycleWorkspaceTest.php` | 26 |
| `LoneWorkerSessionWorkProjectionTest.php` | 15 |
| `LoneWorkerSessionWorkspaceTest.php` | 15 |
| `LoneWorkerAccessCoverageTest.php` | 21 |
| `LoneWorkerIntegrityHardeningTest.php` | 40 |
| `LoneWorkerSiteAccessTest.php` | 4 |
| `HealthSafetyReadContextTest.php` (root-owned bounded-source additions included) | 13 |
| `HsRecommendationDispositionTest.php` | 9 |

The new suite uses real source access and Tasks providers and existing approved-staff fixtures. It covers warmed permission/Site/Client/HR revocation and restoration, stale event/child links, archived treatment, foreign finding concealment before action content, complete source tuples, populated unrelated private-family SQL absence, independently denied Control Room destinations, real feed/navigation/connection parity, inactive/external staff, and missing/foreign/expired read evidence. Explicit empty independent-policy SQL remains distinguishable from private payload hydration.

Shared dependencies remain independently owned and may change before coordinator admission. At this handoff: `TaskAggregator.php` = `4D3C7D4032D82DE3252CCA8C8CAA903698E559C95BAD100FC88A4B4769718124`; `HsEventAccessService.php` = `BABBF5875C8852E07FF601B3CF7B8B7249352BAE99BF941224D770A6B0536981`; `HealthSafetyReadContext.php` = `8CC4D41263F7B22042FA17394DDE2BB3197A90877B6DA463277E01025282F0B6`; `HsEventController.php` = `C9BFE71890E5805DD8DE5C8FAB9AB21CE71CEF9C21B961C163E739F7593AD83D`; unchanged `tests/Support/FirstAidSourceFixtures.php` = `0F2BBEDB16300D884F4552EC41BCCA080043E79E19354108377ACD09F5701C78`.

The original populated Recommendation ceiling remains `<100` at lines 339–340. Historical 124-query failure evidence is untouched; this candidate has not been measured. Static syntax/Pint for the seven owned PHP files, followed by the complete feedback selection, require separate coordinator admission. The initial brittle bulk-edit command was rejected automatically without changing source; explicit reviewable patches succeeded, preserving authority checks and without grant widening.
