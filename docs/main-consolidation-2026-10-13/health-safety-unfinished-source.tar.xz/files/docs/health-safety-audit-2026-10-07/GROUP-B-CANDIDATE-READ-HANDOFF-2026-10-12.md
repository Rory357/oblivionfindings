# Group B: bounded record and connection readers — source handoff

12 October 2026. Isolated `codex/health-safety-workspace` only. This package contains five owned read services/presenters and five whole feature suites. It is separate from the previously retained HS17 domain package (21 files / 89 prepared methods), whose historical pins remain in [HS17-SOURCE-DEPENDENCY-AUDIT](HS17-SOURCE-DEPENDENCY-AUDIT.md).

## Implemented source boundaries

- Each reader prepares current actor evidence once for its bounded operation. Actual module permission and canonical record/Site/type admission precede private H&S source discovery. Prepared permission unions do not confer grants.
- Procedure review requests reload the canonical record and versions, require the current requested/result version audiences and approved source Site, and reject named action/event mismatches in a single identity batch before discovery. One source query covers the eligible exact event-ID/Site pairs. Request command and delivery projections retain their existing authority/status rules; exact action links use canonical contextual Tasks lookup.
- The risk picker intersects supplied Sites with fresh approved Sites before H&S discovery. Its existing Collection return shape is reconstructed from detached scalar rows after the read callback.
- Risk connections reload the canonical assessment and retain both modern event-ID and exact class/morph legacy event provenance. Independent candidates derive from the already scoped risk query, retaining all canonical Site/Client/event predicates. Final correlated denial remains complete. The next-version lookup reloads current supersession facts; destination Client links use the existing current-evidence Client policy and Site links retain independently prepared type/directory authority.
- Hazard connections reload the canonical hazard and preserve its actual Site/type admission. Discovery is constrained to exact hazard class/morph, source ID, canonical Site and hazard category. Local hazard controls remain separate from central actions and independent inspection/checklist sources.
- Corrective-action workspace admission uses its exact canonical action ID and approved parent Site before source discovery. The final relation remains correlated. Participant/evidence authority, source provenance privacy and independent lifecycle commands remain unchanged.
- H&S event/action task links use `TaskAggregator::findItemFor($viewer, $source, $id, ['include_done' => true], $activeContext)`. The full FA + Restraint + Injury + Procedure + Drill union is prepared before this call. Missing/wrong/expired contexts remain errors, with no alternate read fallback. The ordinary hazard task keeps its existing independent provider path.
- Scalar DTOs are materialized inside the active callback. No actor, source model, builder or authority handle is returned from the context. The risk picker's historical Collection API wraps only detached rows.

No policy, writer, role/grant, global Site shell, Control Room, route, frontend or migration is changed in Group B. One operating organisation, current roles/permissions, approved Sites and exact canonical source ownership remain the boundary.

## Prepared verification, not acceptance

The whole existing suites add loaded-grant revoke/restore, canonical Site reassignment, current hazard/Site type, stale supersession, participant/evidence and legitimate independent destination parity. The new complete suite uses actual accepted injury and First Aid source commands; it covers unrelated injury/history materialization absence, source tuple/category filtering, task parity, prefiltered procedure eligibility, bounded treatment SQL and a damaged private candidate alongside a healthy independent record. Known-private identity-only denial subqueries remain complete; they are not treated as unrelated private model materialization.

All five complete suites are **UNRUN**. PHP syntax/Pint, native DB tests, builds, browser verification and performance acceptance are **UNRUN** for this package. Only filesystem source inspection, edits and SHA256 collection were performed. The historical populated context failure of **124 queries against the unchanged `<100` assertion** remains unresolved evidence until actual rerun. Earlier full-native **46 failures** are not superseded by source preparation. No final freeze or deployment acceptance is claimed.

## Owned source pins

| File | SHA256 |
| --- | --- |
| app/Support/HealthSafety/SafeWorkProcedurePresenter.php | 575DBC048BD5889E7AC1F306D504D4E46133045E79DB00D1679AEFF7C8A7EF4B |
| app/Support/HealthSafety/RiskAssessmentPresenter.php | C1138C1F1D176A0902C8FA6983556C0F55EEAFC0FD3B8A3B349E9BD1EB8243F2 |
| app/Services/Sites/HazardWorkspaceConnectionsService.php | B00334C6A8AB86399B18FD6AFA529746C4A4FB09FCA1741323C7FE0FBA006209 |
| app/Services/HealthSafety/RiskAssessmentWorkspaceConnectionsService.php | 7F725859795A81FA2029FF0B4FBEA59230485F3473E15C21BCC4042FAC0757F5 |
| app/Services/HealthSafety/HsCorrectiveActionWorkspace.php | DAE123E49EC0D8961C784414043EA4EB2338388D8EC0E4EF93315D5B3D5F654E |

## Complete suite inventory

Declared methods are filesystem counts, not executed cases or assertion counts.

| Whole suite | Prepared methods | SHA256 |
| --- | ---: | --- |
| tests/Feature/HealthSafety/SafeWorkProcedureLifecycleWorkspaceTest.php | 38 | DE7B6A100C83BEDCC1485918AD3D79C19693364775F17910A1DE6C8E98986C32 |
| tests/Feature/HealthSafety/HsRiskAssessmentWorkspaceTest.php | 19 | BEE2F17A8207F560D30F0843602DD616EAF2528F34130383B839FF48B3D346E6 |
| tests/Feature/Sites/HazardWorkspaceConnectionsTest.php | 14 | 664222B68511D3316916FCEB93568AF0D926BD36A284507D0E6E16D14847FF02 |
| tests/Feature/HealthSafety/HsCorrectiveActionWorkspaceTest.php | 9 | CF12A727391E63920787E5C9DB6E245FA66C918E12773EF521D9DD34FDD60034 |
| tests/Feature/HealthSafety/HsRecordCandidateContextPrivacyTest.php | 8 | 54470CB2E63F7A4B273F645D3A53C069529DA1C2F2F2D117401A5DF855F1749C |

Total: 88 declared prepared methods across five whole suites, all UNRUN.

## Shared dependency pins inspected, not edited by this package

| Dependency | SHA256 |
| --- | --- |
| app/Services/HealthSafety/HsEventAccessService.php | 8DA9911B9DFDCF780241D71E18E40640D587AFDC1E4EE9A70006BB9E0F28FC83 |
| app/Services/HealthSafety/HealthSafetyReadContext.php | 8CC4D41263F7B22042FA17394DDE2BB3197A90877B6DA463277E01025282F0B6 |
| app/Services/Tasks/TaskAggregator.php | 4D3C7D4032D82DE3252CCA8C8CAA903698E559C95BAD100FC88A4B4769718124 |
| app/Services/HealthSafety/FirstAidAccessService.php | C8E60C20E1831D55DB2AEE0C49AD3B4D4C09E01FE9D4B697473D41D4D3D79D89 |
| app/Services/HealthSafety/RestraintAccessService.php | 40B6F5382780F0B90BE2D5BE75CEF09CED9154F69567F6ED4B2B00525827216E |
| app/Services/HealthSafety/InjuryAccessService.php | 20E89F4CA51D8252581054D9B3C5033665740F17AC05FD7EB2E7C6139C92DC1B |
| app/Services/HealthSafety/SafeWorkProcedureAccessService.php | 699B68907A975FAA036585DF887C7D7F39F5064B434959D2818D4BB7ADD4AA8A |
| app/Services/HealthSafety/EmergencyDrillAccessService.php | BD60EC1DEECF03730E1E0C9A3A76A8B19D1BBFA5A723A1BD41F304D948C692F2 |
| tests/Feature/HealthSafety/WorkplaceInjurySourceTestCase.php | D4F3A42E2DC347E1B6FD9C30DAA574A8E1E6E4C6B10D29E7529FAF50E8450EDD |
| tests/Feature/HealthSafety/HealthSafetyReadContextTest.php | 3DD9DE705F5B7BD922272940840C6EB0F9C3EEC235AC220A35C23BC79A497A37 |

Root owns the bounded First Aid candidate API in HsEventAccessService/HealthSafetyReadContext. The gate owner owns the optional active-context TaskAggregator lookup. If these dependencies change before admitted verification, refresh this package's dependency inventory alongside the final source manifest. The unchanged query ceiling must be included in the actual feedback gate.
