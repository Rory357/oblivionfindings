# Private follow-up registry-only alternative — 12 October 2026

SOURCE ONLY / UNAPPLIED / UNRUN / NOT FROZEN. No live registry, preparation, role, grant, caller, source service, scheduler, controller or route was changed for this unit. Text reads, literal-key extraction, declaration counts and file hashes are source evidence, not executable or behavioural acceptance. This alternative is reviewable but **not ready to mount** while the final provenance-membership gap below is unresolved.

Automatic approval review rejected the previous eight-file registry/preparation mount because it mounted private chemical Tasks and added permissions across unrelated shared consumers without sufficient boundary-composition proof. The rejected `CHEMICAL-EXPOSURE-TASK-CONSUMERS-UNAPPLIED.patch` (2657638DA22CE8A80B2078307233A422936791E02476D6594F1E84A465FF01E3) remains historical and must not be retried. This alternative changes only two lines in the existing TaskAggregator registry: comment plus registration of the already existing contextual provider. It makes no permission-vector, role, grant, import or shared-caller change. Root must review the remaining source issue and separately obtain any actual mount admission.

## Existing prepared keys, independently read from source

Each of the existing five access-service PERMISSIONS declarations is a literal array. Pure text extraction gives 37 unique keys; ChemicalExposureCommandAccess requires 13; missing keys are `[]`. Preparation is neither a grant nor admission to private records. The actual current actor must separately hold hazards.view AND hr.wellbeing.view, meet current internal approved-staff eligibility, and have approved active H&S Sites. Each original linked Incident/Client/context and retained source acceptance is still independently admitted.

Required chemical keys are already present as follows:

- hazards.view: all five existing families.
- hazards.create: FirstAid, Injury, EmergencyDrill.
- hazards.manage: FirstAid, Injury, SafeWorkProcedure, EmergencyDrill.
- hr.wellbeing.view: Injury.
- healthSafety.viewAllSites: all five.
- incidents.viewAny and incidents.viewAssigned: FirstAid, Restraint, Injury.
- hr.cases.view: FirstAid, Restraint, Injury.
- clients.viewAny and clients.viewAssigned: FirstAid, Restraint, Injury.
- clinical.accessAllSites and sites.viewAll: FirstAid, Restraint, Injury.
- respite.viewAny: Restraint.

Definition pins observed in this finite review:

- FirstAidAccessService: C8E60C20E1831D55DB2AEE0C49AD3B4D4C09E01FE9D4B697473D41D4D3D79D89.
- RestraintAccessService: 40B6F5382780F0B90BE2D5BE75CEF09CED9154F69567F6ED4B2B00525827216E.
- InjuryAccessService: 7AF9D6D8138AF6A8E95371F101B7C0FBEDC389B2442CA09A304D9309BE6F9412.
- SafeWorkProcedureAccessService: 699B68907A975FAA036585DF887C7D7F39F5064B434959D2818D4BB7ADD4AA8A.
- EmergencyDrillAccessService: BD60EC1DEECF03730E1E0C9A3A76A8B19D1BBFA5A723A1BD41F304D948C692F2.
- ChemicalExposureCommandAccess: 5C8EDE7A82A7BA314B18B21FD90D74F8478B9AD4DE1AD0E998F8DEF8FBAB2BEC.

## All actual origins and supplied contexts

TaskAggregator's three production preparation origins already spread all five existing families, with no additional chemical vector required:

- `findItemFor` 174–222, vector184–186: fresh or supplied active context; exact selected provider only; filters always add the exact source ID. Supplied context asserts the same viewer and prepared union, then consumes the existing current actor. Missing keys, foreign actor, expired reads or foreign physical connection do not trigger a fresh fallback. Exact lookups try current and completed work under the same callback. Existing corrective-action/event lookups do not enumerate chemical follow-ups merely because the registry gains an entry.
- `sourcesFor`459–495, vector465–467: fresh current actor; only provider.canView is inspected. No task, source, child or medical body is hydrated. The label is module availability, not source/HR/Site authority. Noncontextual provider policies retain their existing original-viewer path.
- `healthSafetyProviderPasses`628–705, vector638–642: requested source filtering precedes contextual dispatch; the existing callback consumes a current actor, calls canView, then the selected contextual feed/navigation method. Unrelated providers and existing pass memoization are unchanged. Contextual passes are not retained in the noncontextual provider memo (`authorizedTasksMemo`725–736).

Exhaustive production search of `findItemFor` and `navigationBadgeInContext` finds seven supplied-context preparation files, eight call locations. All already spread all five families. No consumer modification is proposed:

- `app/Http/Controllers/HealthSafety/HsEventController.php`: detail vector790–795; show callback392–399; navigation396. Canonical source detail and navigation materialize inside the same current callback. Only detached detail/navigation/event/viewer scalars are published after success. Existing closure capability keys remain prepared. Hash C9BFE71890E5805DD8DE5C8FAB9AB21CE71CEF9C21B961C163E739F7593AD83D.
- `app/Support/HealthSafety/SafeWorkProcedurePresenter.php`: vector269–275; Procedure.withReadContext277; exact corrective-action lookup390. Its own procedure/version/current review admission remains separate. Hash575DBC048BD5889E7AC1F306D504D4E46133045E79DB00D1679AEFF7C8A7EF4B.
- `app/Services/Sites/HazardWorkspaceConnectionsService.php`: vector41–49; same source callback50–51; exact event/corrective-action context helper130 (call114); existing hazard provider uses its independent noncontextual lookup. No chemical enumeration at that exact lookup. Hash B00334C6A8AB86399B18FD6AFA529746C4A4FB09FCA1741323C7FE0FBA006209.
- `app/Services/HealthSafety/RiskAssessmentWorkspaceConnectionsService.php`: vector119–121; active own preparation35 or supplied-context assertion113; exact helper146. Existing independently executable risk/event candidates and risk source scope remain unchanged. Hash7F725859795A81FA2029FF0B4FBEA59230485F3473E15C21BCC4042FAC0757F5.
- `app/Services/HealthSafety/FirstAidConnectionsService.php`: vector105–110; exact corrective-action lookup72 inside existing FirstAid.withReadContext/source callback. Current canonical treatment tuple and independent candidate precede event access. Hash0F2DE7991B6E7D90A073CA68CDB07F40CAFB74C7F438FFAFD3FB0F998D58EF82.
- `app/Services/HealthSafety/EmergencyDrillConnectionsService.php`: shared vector113–117; exact lookups49 and102 inside existing Drill.withReadContext callbacks. Canonical drill/finding/version/source tuple remains independently admitted. Hash D5C910180920AC2B2C1457CA9E29EF2ED542B7DC3440F49644073938FDA43C4B.
- `app/Services/HealthSafety/LoneWorkerSessionConnectionsService.php`: vector108–112; exact corrective-action lookup94 inside existing LoneWorker.withReadContext. Direct alert FK, actual Site and nullable Client tuple remain the source boundary; no invented HSE category/type. Hash A685DB26390FA7BD79C50B78C0E2D1AB9553B61BF4815BCFF788CCB6E57D98F0.

Other production lookups omit a supplied context and continue through the aggregator's existing fresh exact-provider origin. Registration does not require additional authority lookup or preparation in those callers.

HealthSafetyReadContext42–108 locks current actor/permission evidence, records current approved internal HR eligibility, asserts active lifetime and the supplied viewer identity, checks required keys as a subset, and derives approved Sites with supplied physical current reads. Its returned-value check224–239 rejects models, Builders, queries, contexts, reads and authority objects; TaskItem properties are recursively checked. Source/body reads and final SQL remain within that callback. Current hash8CC4D41263F7B22042FA17394DDE2BB3197A90877B6DA463277E01025282F0B6.

## Actual provider/source behavior and final statement

Provider `ChemicalExposureFollowupProvider` implements only ContextualHealthSafetyTaskProvider and SiteScopedTaskProvider; no HasModelClass, assign/split/generic completion/audit adapter. canView requires current hazards.view plus wellbeing; contextual feed and navigation delegate to taskRows using the supplied active context. Provider hash57B4AB9864F38EAFFFD7AA232FF02A7681997D65C98B1C5883C2EFD6B756A691.

Actual composed Followup hashEF18FF9BD6A84F30771959BFF808970A2B6817C5AFCF260D301CF25935CEFF13:

- taskRows336–345 admits dual read before private collection and discovers only four child identity fields for the current named recipient and scoped parent candidates.
- Root body/original association/sourceProof is current. Source.assertSourceIdentityBeforeBody350 precedes full child or version body; exact immutable version metadata is admitted353–354; own child/root/schema/revision conditional body fetch follows355–358.
- Current accepted child/version/receipt/intent/audit proof precedes facts. Guard collection includes the admitted latest root and child, every retained reported-map version/acceptance and its original Site/Incident/Client/shift/service/stay/booking graph. Opaque byte-exact SQL fingerprints are stability checks after immutable provenance, not new grants.
- Source/root/identity preflight and currentVersion repeat after fingerprint capture365–377. Root aggregate revision and child revision remain independent; unchanged child work survives unrelated accepted root advancement and superseded old outbox. There is no outbox/inbox requirement for Tasks.
- ONE final identity-only statement402–435 follows all candidate accumulation; own recipient/FK/schema/child revision, existing fingerprints, exact reported-version membership and absence of later aggregate versions must still match. Only permitted detached pending rows leave the callback. **The additional membership omission described next is not claimed closed.**

Private DTO: exact child id/source; label Private follow-ups; constant Assigned follow-up (navigation title empty); real open/completed and open/done; info severity; own proved `assignee:{id:currentRecipient,name:'You'}`; actual dueAt/createdAt instants; null reference/client/Site/description/link/displayState; restricted=true supplied by provider. No worker name, clinical prose, actor, raw audit, evidence path, UUID or private search material is copied. Actual source dates/status remain private and require dual access before inclusion.

TaskAggregator586–619 keeps source filtering, task-ID deduplication, existing filters/sort and downstream full list/count/page behavior. Badge847–852 remains existing overdue OR assigned-to-current-user eligibility over deduplicated open defaults. No count ceiling/test relaxation is proposed. This private provider has no300 cap; existing provider caps are unchanged. Proof costs across all eligible children/retained history remain unmeasured, and the existing populated recommendation<100 query gate remains unchanged/UNRUN for this candidate.

## Concrete remaining boundary issue — registration held for review

Current Source `F88C1C3A321BE7D91B169A1B88D5229CF9E390E3EE6E7468134D2D305B51BE85`, assertSourceIdentityBeforeBody346–400, admits ANY retained exact source kind/ID and refuses versions OR receipts retaining another original aggregate: root377–379 and child397–399. Those preflights protect both full-child reads in taskRows. They are not duplicated in its final consuming statement.

The final task WHERE402–430 fingerprints already admitted rows and excludes novel current-parent reported-map or higher-aggregate versions. It does not exclude a NEW retained `(source_type='followup', source_id=childID, exposure_id!=rootID)` version/receipt added after the last preflight, or the equivalent root ownership conflict. Existing row fingerprints remain unchanged; current-parent reported/version membership does not see a new foreign-parent row. This is a source-level omission, not a permission-vector problem. SQL-lock/concurrency behavior is unmeasured; no assertion that locks make this harmless is supported by source review.

Smallest owning successor to review: add final identity-only absence checks for the exact current source-family ownership conflicts already denied by the canonical preflight, plus any other original-parent receipt membership required by that existing proof. Keep root-versus-child revision semantics, current accepted rows and reported-origin guards unchanged; no outbox requirement, grant, private prose projection or standalone cached descriptor. Parent must allocate/review this repair before mount. Proposed meaningful regression: actual healthy accepted source/child; after its last source reproof while a healthy neighbour hydrates, introduce retained foreign-root same-kind/ID version then receipt separately; final feed/badge/exact pending row must withhold only the conflicting row without selecting foreign private content; restore genuine original provenance and prove normal parity. Existing pre-body foreign-row tests do not prove this later boundary.

## Watch/actions/navigation/failure parity

Actual AllTasksController130–211 uses fresh exact lookup. Restricted or null-link rows have no generic timeline/audit actors or watcher identities, no open/watch capability, no assignment/split interface. Watching true308–314 requires a fresh item with real nonnull link; this private family remains ineligible. Stopping one's existing watch288–302 keeps its existing independent removal behavior and grants no source read. Current controller hash AEEBACA0DA2E1E1034D0B9417DB3AB1A5892D47CA28B06C787D18140CF888697.

Source canView is independent from task hydration. Expected module/source/HR/Site403/404 conceal private items without denying ordinary destinations. Per-record integrity/missing-source/sole-key source ValidationException hides only the affected private row; all other validation rethrows. Unexpected DB/errors remain strict feed errors. Navigation reports degradation and preserves an already readable provider destination after its hydration fails; existing unrelated-provider view preservation is untouched. Missing/foreign/expired provided evidence does not silently create fresh authority. The source chooser can show the module label when dual grants exist but strict HR/Site admission yields no tasks; a label is not an authorised record.

Actual generic EscalateOverdueTasks70–75 now excludes this exact identity before generic dedupe/fanout/ordinary notifications. Hash63729F1197D1F1BF810EB5C1230FF825ACB9522A7EF44820F91CC7CEE23A7ABF. This prevents copied private due/source data and manager fanout; it does not implement the still-required typed private reminder/escalation workflow. Root/B routing/settings/unit allocation remains separate.

Link remains literal null until actual guarded private GET, exact focused child26+ transport, return normalization and UI integration are mounted and verified. Route existence alone is not permission/readiness proof. MyDay's separate Always/viewer binding proposal and safe null-link interaction remain independent integration gates. No historical shared notification proposal or CR adapter is mounted by this registry alternative.

## Whole feedback footprint, unchanged and UNRUN

New whole existing suites, not copied/narrowed here:

- tests/Feature/HealthSafety/ChemicalExposureTaskPrivacyTest.php —18 methods; hash4BC74962C2D3A62916296284CD26973660008A6FFBB24B840C99F68A1496E0E0.
- tests/Feature/HealthSafety/ChemicalExposureTaskHttpTest.php —9 methods; hash F2BB54DD795ADCC99607637476AB7E8C84BDC896DDA9A88067A15007C81803C4.
- tests/Feature/HealthSafety/ChemicalExposureTaskEscalationIsolationTest.php —2 methods; hash4791DE1E1E5718061B3AA3C7510E108E3F576BE176A61BBC3F924540E4DA1AC6.
- tests/Feature/HealthSafety/ChemicalExposureFollowupChildAdmissionTest.php —5 methods; hash44428F7CD19E70D50EE2ACD23E108EF0FF79F2403D9194449B1B32BD4172AA5F.

Complete dependencies remain ChemicalExposureFollowupDestinationTest25; ChemicalExposureFollowupReassignmentTest23; Tasks/HealthSafetyTaskContextTest23; Tasks/AllTasksDashboardTest16 Pest; Tasks/AllTasksPermissionRecoveryTest10 Pest; Tasks/TaskNavigationFailureIsolationTest2 Pest; Tasks/TaskProviderAuthorizationArchitectureTest5 Pest; Tasks/TaskWatchersTest14 Pest; Tasks/EscalateOverdueTasksTest4 Pest; Tasks/EscalateOverdueTasksPerformanceTest1 public; MyDayNotificationsDigestTest1 Pest.

Total15 whole suites:106 public methods plus52 Pest declarations =158 declarations, not runtime cases/passes. This unchanged footprint includes production-registry and actual HTTP integration requirements; current unregistered source cannot pass those integration assertions until a reviewed safe composition. It does not yet include the proposed late foreign-membership regression above. Retain all Source/Access/ledger/physical/body-lineage/reported-facts/privacy/native and focused-child gates; this finite footprint does not replace them. No syntax/Pint/native/browser/DB job, runtime admission, freeze or release is claimed.

Exact live TaskAggregator base for the two-line patch:4D3C7D4032D82DE3252CCA8C8CAA903698E559C95BAD100FC88A4B4769718124. Existing broader handoff/patch remains historical; this document records composed source status without rewriting prior evidence.
