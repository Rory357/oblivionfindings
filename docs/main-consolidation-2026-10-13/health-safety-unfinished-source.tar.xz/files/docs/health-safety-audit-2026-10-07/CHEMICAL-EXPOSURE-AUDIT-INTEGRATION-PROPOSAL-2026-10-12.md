# Exposure audit consuming-boundary proposal — reconciled 2026-10-12

SOURCE ONLY. The shared consuming-boundary changes remain **UNAPPLIED** in `CHEMICAL-EXPOSURE-AUDIT-CONSUMER-INTEGRATION.patch`. No actual shared audit service/controller, routes, AuditLogger, SafeOperationalData, source writer/ledger/workspace, delivery recovery or risk guard was edited. All syntax/Pint/native/DB/browser/executable checks remain **UNRUN** under HOLD. These are observed source dependencies, not a freeze, release, or ownership transfer. Safeguarding proposal files remain unchanged.

## Current source reconciliation

The earlier version()/accept() displacement and missing no-op historical-tuple issues recorded in this proposal are historical diagnoses. The current B-owned ledger now has distinct `version()` (line81) and `accept()` (line104). Versions persist the complete immutable root/child tuple, original intent and digest. Acceptance separately records exact semantic audit plus receipt. Changed commands require an accepted source version; only explicit unchanged commands retain version=null and before=after. Internal `source_tuple` and `source_tuple_digest` now bind the original before/after identity/context and are anchored by strict scalar audit metadata. The historical problems are no longer reported as present source blockers; this source reread does not prove runtime acceptance.

Current `ChemicalExposureSourceService::admitReceiptMetadata` (428) validates original tuple shape/digest and its audit anchor, original Sites and original Incident context before receipt/intent bodies. `admitVersionMetadata` (475) additionally binds historical version metadata/content digest to its retained receipt/audit before full content. `sourceProofForAuditSubject` (268) calls these paths for direct version, receipt and shared-private-intent subjects, including create-intent root discovery and null-version no-op receipts. It retains independently current source permission/Site/parent proof. Audit access is not original command ownership and does not grant recovery or mutation.

`ChemicalExposureHsEventDeliveryService::sourceProofForAuditSubject(int markerId,current,reads,sites)` (33) separately owns the actual 200300 marker/current destination/history proof. The guard delegates it rather than guessing a model, source identity or clinical grant. Evidence/staging/cleanup proof remains B's evidence-service responsibility. Their current source pins below are observations; they may change under their existing ownership before a combined gate.

## Actual helper default and private family

The saved `ChemicalExposureAuditAccessService` is not mounted into `AuditLogViewService`. Its no-context `scope(query, viewer?)` deliberately grants **no private whitelist**, even for a saved dual-authorised User. It applies complete SQL private-identity exclusion. There is no detached authority token. Contextual scope first asserts viewer/lifetime/prepared union, requires current audit.viewAny, then applies the private branch's fresh current internal staff + approved active Site + hazards.view AND hr.wellbeing.view admission. Unrelated audit readers do not inherit these private HR/Site conditions.

Current family includes literal/registered morph of the exposure root; review; followup; evidence; version; receipt; staging; cleanup; source delivery; actual H&S marker; shared ChemicalCommandIntent ONLY when backing source_type=exposure; current/soft-deleted exposure HSE bindings; corrective-action/investigation/risk descendants including modern AND legacy risk parent bindings. Exact private action prefixes and fixed top-level/before/old/previous/after/attributes/new/changes/values identity leaves are included. SQL nullable leaves are guarded so ordinary null-subject/meta rows survive. Discovery selects identity columns/leaves only in bounded chunks after private admission, with all candidate-independent final denial retained. A public chemical intent is not blanket private exposure.

All relevant copied Site/worker/Client/Incident/shift/service/stay bindings must match actual source proof; one readable parent cannot cancel another unavailable parent. Original worker is not audit actor/recorder. Legacy unlinked context stays explicitly unknown; legacy non-null Incident without original context does not become today's Client/context. Damaged/archived/missing source or historical acceptance denies. `currentForPresentation` freshly guards/reloads a candidate ID and bounded actor/Client relations inside the callback, rather than certifying preloaded prose.

These are source properties and complete tests, not query execution proof. Unidentifiable historical prose cannot be classified by guessing; known private identities/actions fail closed.

## Exact five-file consuming patch

The numeric-context unified patch is against these unchanged observed bases:

- `app/Services/Audit/AuditLogViewService.php`: `C3EC60B500B9439D200D2A87E0204CF75E863C00EE3473C636EB5B758D5595B9`
- `app/Http/Controllers/AuditLogController.php`: `9413620C62255C263CA10C24309EDD5BDBD30B8BB03C3BAF1F0FD3BDAE78367E`
- `app/Http/Controllers/Settings/AuditLogSettingsController.php`: `2B8E2E7084271392F6D207E88149988C2140F029C71B5360454E1C31D02354C3`
- `app/Http/Controllers/Hr/AuditController.php`: `C2AEC6CCC7460E3B89B713832A6AC6663E3F2E661B9133D8141CC2651CD1AA31`
- `app/Services/HealthSafety/ChemicalExposureAuditAccessService.php`: `EB4EE01665F003D0348F758A85FD7BD61E315347080688C81B6293440C3801B9` (unapplied Client-relation identity/proof hunk only)

Patch SHA256: `B4F099DDE72BF31D42BE88004255A00AE2616F1008E9AB03965B21F0CF4D63A8`. Owner must review/rebase before applying. No partial installation is represented as complete.

`AuditLogViewService` gains a materialize delegator and final optional context on query/present/filterOptions/stats. Supplied query context consumes the current actor INSIDE its callback for the unchanged BoardPack scope; no actor model is returned as an authority handle. Ordinary module/action matching, field sanitisation, date refinements, limits, options shape and BoardPack grant semantics remain unchanged. Subject type/id refinements are additive internal filters for actual HR model/history callers and precede exposure discovery. Existing grouped action/type/actor-name/Client-name search moves after exposure scope construction. Default wrappers exclude private rows; supplied-context queries can include only currently proved private rows. Present reloads the currently guarded exact ID before metadata/field map/actor relations. Outer User/Client option queries are bound to that same active context.

A source reread also identified a separate relation sink: current guard discovery omits `audit_logs.client_id`, although presentation/search/options use that relation. The fifth UNAPPLIED hunk selects only its identity, then applies existing `ClientPolicy::viewFromCurrentEvidence` with the SAME current actor/reads after exposure proof and before full audit/Client-name hydration. It has no new permission preparation or grant. Null Client relations stay null; nonnull ones require independently current actual Client authority. It does NOT invent an exposure association from the column, replace B's original recorded context, or require old historical Client identity to equal today's exposure Client. Unrelated audit rows do not enter this private branch. Root must review this finite additional seam before mounting.

All three actual callers compose the full read once:

- General index: existing route permission/validation/filter response retained; 50-row paginator passes through guarded presentation, then toArray plus existing filter options before callback exit.
- Settings index: 50-row events, options and today/week/month stats use the same callback/current actor. Partial props retain actual response keys.
- Settings export: identical filters/order/5000 cap, existing six CSV columns/header/filename/content type/formula guard. Accepted rows become scalar cells BEFORE streaming; stream captures no User/model/context/Builder/generator and performs no late source proof.
- HR index: 30-row legacyPageShape plus action/model/user options in the same callback; current viewer omission corrected. Exact model_type enters the independent query before discovery. Option collections become arrays and user query uses supplied reads. HR show: exact module/type/id filters precede guard, entries are detached before JSON response.

No new grant, source-read fallback, global authorization replacement, writer/lifecycle/reporting change or unrelated Security/BoardPack redesign is included. Existing unrelated default presentation remains possible; private legacy unscoped presentation conceals with ModelNotFound/404 rather than serializing a saved body.

## Specific held blockers and composition gates

1. **Actual shared boundary is absent.** Current query/present/options/stats never call the guard, general/settings present omit viewer, and HR query/present omit it entirely. The five-file patch plus complete affected callers is the coherent source integration unit; helper existence alone is not closure.
2. **NEW risk acceptance family is not recognised by the current guard.** `PRIVATE_MODELS`/modelForType omit `HsRiskAssessmentAcceptance`; fixed meta discovery/denial omit nested `risk_source_binding` and `risk_source_binding_before`. A historical private risk changed to an ordinary current parent can therefore evade the guard when those new bindings are its only remaining exposure identity. The prepared `RiskAssessmentAcceptanceService::auditProofInContext` is not invoked by this helper and requires its complete prepared source union. This task does not edit or install that pending family, risk writer, history adapter or rejected/pending guard. Its owner must allocate exact identity recognition and accepted historical proof before NEW risk audit/history mounting; the current five-file patch does not certify that work.
3. Public200100/private200200/destination200300 models and B current proof/recovery APIs are physical/schema/integrity dependencies of the guard. None were applied or executed here. Actual retained file/recovery and concurrency/outer-commit suites stay owning dependencies. Do not duplicate their proof or infer prior source context from current root.
4. Search, count, page/options and per-row present can repeat private proof inside one callback. Cost/performance, DB current-read/lock behavior, CSV parity and combined physical evidence acceptance remain UNRUN. No threshold relaxation or native-result claim is made.

## Whole feedback footprint, UNRUN

Owned complete suites:
- `tests/Feature/HealthSafety/ChemicalExposureAuditPrivacyTest.php`: **41 methods** (was38). Three meaningful boundary cases were added: actual default query/present/options/stats retain ordinary rows but exclude private saved-actor access; shared materializer reuses supplied callback, reloads current audit body and rejects escaped query; separately copied Client relation refuses foreign Site or warmed revoked Client access and restores with current authority, including a genuinely unlinked exposure. Existing actual general/settings/HR HTTP, partial/CSV/count/page/search, BoardPack/current-role/Site, source/typed/digest/historical/nullable cases remain.
- `tests/Feature/HealthSafety/ChemicalExposureAuditRecoveryPrivacyTest.php`: **14 methods**, unchanged. Actual physicalCommit fixture, accepted private evidence/staging/receipt/intent/removal cleanup/delivery/marker, historical auditor distinct from actor, original Site/no-op tuple/audit anchor damage and foreign body-prehydration denial. This is not a serial/fake concurrency certificate.

Existing/root whole dependencies:
- `tests/Feature/HealthSafety/ChemicalExposureAuditProtectionTest.php`:9 methods (current root source, not the historical8).
- `tests/Feature/Audit/AuditLogSurfaceTest.php`:6.
- `tests/Feature/Governance/GovernanceBoardPacksTest.php`:24.
- `tests/Feature/Governance/GovernanceBoardPackReaderTest.php`:4.
- `tests/Feature/Governance/GovernanceAuditLogPresentationTest.php`:4.
- `tests/Feature/Hr/CanonicalAuditOrganizationTest.php`:4 Pest test declarations, no public test methods.
- `tests/Feature/SecurityDevices/SettingsAuditTest.php`:25.
- `tests/Feature/Emar/MedicationPrescriberOrderAuditVisibilityTest.php`:1.
- `tests/Feature/Emar/MedicationSettingsAuditorAccessTest.php`:2.
- `tests/Feature/Emar/HistoricalMedicationAuditExportTest.php`:2.

Twelve complete files: **132 public test methods +4 Pest declarations =136 declarations**, not runtime cases or passes. No selectors/skips/query ceiling changes. Preserve B's complete private-source/evidence/recovery/context suites and root's full HSE/derived/source-family suites in the combined native gate; this finite consuming-boundary footprint is not permission to omit them. Pending risk acceptance/history suites remain separately required before their owner mounts that family.

## Observed helper/source/test dependencies

- Guard `ChemicalExposureAuditAccessService.php`: `EB4EE01665F003D0348F758A85FD7BD61E315347080688C81B6293440C3801B9` (unchanged).
- B `ChemicalExposureSourceService.php`: current observation `F9A999F11EB903D26CE97BCD7A0A52220F1515E805D92444183C2AD13E6D5664`; initial read `620FBAE2C6B5E1C42417D40254D9727C26746378FCDAF7C970F36F17F6E970E2` is historical. The owning source changed during this preparation; a bounded reread confirms the same public audit-subject/receipt/version admission signatures and original tuple-anchor paths. No full-file stability or freeze is claimed, and no B source was edited.
- B `ChemicalExposureLedger.php`: `9B2908CCEC844EFFFF649DB5F86AA51BA6FAE76674094474E6CF815D4E910F3A`.
- B `ChemicalExposureEvidenceService.php`: `A8244876FC673FC9A1F31CC53139E20C6A5DFB562363B94DBFC8F14CA7AF5DD6`.
- Root `ChemicalExposureHsEventDeliveryService.php`: `07580A93F0C3848A24D4047721E568E99D3B765276B0B8F7E280E83489AB1BF3`.
- Existing `ClientPolicy.php`: `B6EEACE3A8CD7BB809AEB1D91A0A96BA55DB9448453354537F19F247FA9616A3`; the additional UNAPPLIED relation hunk uses its actual `viewFromCurrentEvidence` without editing the policy.
- Whole privacy suite current: `4CD8DED233078ED4A0351623FA585B38C847D72BA7DDB4C7DE713787EFCC9D66`; historical38-method pin `B7AE20BE6DF55C8F85974A0883B1DB6C09C3FAB0C934CB52AA89FAE386F39481`.
- Whole recovery suite unchanged: `43710FF72764F4E08E520E35AEC71B4325D0C725447E3E572F00D3BB59B0C8ED`.

All source/text review only. Earlier historical findings and prepared suite pins are reconciled explicitly; original failed artifacts, thresholds, migrations and shared source remain untouched.
