# Private chemical exposure source candidate

Status: SOURCE ONLY, all executable checks UNRUN. Not frozen or accepted. This package is confined to the isolated H&S checkout. It does not mount controllers, routes, notifications, destination dispatch, shared source-family guards or new permission grants.

## Ownership and schema

B owns migration `2026_10_12_200200_create_chemical_exposure_source_history.php`, eight private models, six private services, the additive `SubstanceExposureRecord` casts/relations/private audit exclusions, its observer, nine whole suites, their test base and guarded two-worker helper. Exact files and hashes are in `storage/logs/chemical-exposure-private-source-candidate.json` (28 files, 117 declared test methods; declarations are not executed cases).

A owns saved-record access/read/source-family/audit projection. C owns the public chemical foundation and the actual globally unique `chemical_command_intents`. Root owns controllers/routes/frontend/shared privacy integration and the separate 200300 H&S destination consumer/marker. Public chemical tables and existing June migrations are unchanged by B.

200200 adds schema0/revision0/original_context nullable to the actual exposure root without backfill. New private versions, receipts, reviews, follow-ups, evidence, physically committed staging, cleanup and delivery tables use bounded explicit constraint names. Evidence removal timestamps retain actual microsecond precision. Down refuses retained rows or meaningful root metadata and refuses even an empty dependent 200300 schema. No rollback deletes private bytes.

## Command transport and acceptance

Source service methods:

- `create(HazardousSubstance|int, User, array): array`
- `correct(SubstanceExposureRecord|int, User, array): array`
- `review(SubstanceExposureRecord|int, User, array): array`
- `assignFollowup(SubstanceExposureRecord|int, User, array): array`
- `completeFollowup(SubstanceExposureRecord|int, int followupId, User, array): array`
- `confirmationForKey(User, string UUID, ?int exposureId = null): ?array`

Commands use canonical UUID `idempotency_key`; every existing-source write uses `expected_version` (the exposure aggregate revision). Only create omits expected_version. Strict semantic normalization rejects unknown domain fields; the HTTP owner must strip only known framing/navigation fields. Uncertainty must retain original UUID, expected revision and payload. Editing intent requires a fresh UUID after explicit current-source review.

Verbs: create_exposure, correct_exposure, review_exposure, assign_followup, complete_followup, upload_evidence, remove_evidence. Only correct_exposure permits an unchanged acceptance: changed=false, version=expected_version, source_version_id=null. It neither advances revision nor certifies a genuine legacy source.

The public acceptance whitelist remains exactly: accepted, actor_id, command, idempotency_key, root_type, root_id, source_type, source_id, expected_version, version, source_version_id, changed. root_type is exposure; source_type is exposure, review, followup or evidence. No private prose, paths, copied names, snapshots or cleanup guarantees are returned.

Internal receipts retain exact original actor/intent/source/version/semantic audit and two anchors: source_content_digest for actual changed versions and source_tuple_digest for the immutable {before,after} original identity/context binding. Each tuple contains only exposure_id, substance_id, worker_id, site_id, related_incident_id and original_context. Create before=null; unchanged before=after. Generic audit stores only the two validated scalar digests, never the tuple/context body. New tuple digests are nonnull lowercase SHA256.

## Fresh access and source proof

Capture requires current approved internal staff, hazards.create OR hazards.manage, approved active unarchived original Site, and an eligible newly selected worker at that Site. It does not grant saved medical read. Current actor-bound create recovery checks original capture authority and immutable original acceptance, selects only current root identity/markers, and never loads a later private root/version body. Rebound worker/Site or damaged markers refuse recovery.

Saved reads require hazards.view AND hr.wellbeing.view with canonical current actor/HR and approved active original Site. Saved writes additionally require hazards.manage. Historical exposed-worker employment is not a new saved-read restriction. No self, clinical fitness, qualification, restriction approval or blanket-admin grant is added.

A consumes `sourceProof(source,current,reads,sites): array` inside one active callback. Healthy output is detached original worker/substance/Site/revision/version identity with attribution_state recorded|legacy_unknown, category exposure, original incident/client/shift/service-context/stay facts and binding enums. Unknown legacy associations never acquire today's incident Client/shift. Damage returns only {attribution_state:repair_required,source_id}; actual permission/Site denials propagate.

`currentVersion(root,source,kind,reads,current,sites,purpose='read')` is an internal private model-returning helper and must not escape the admitted callback. All current root/child snapshots, immutable tuple/digest and exact accepted audit/intent anchors are checked. Older unchanged child versions remain valid after unrelated aggregate advances. Retained typed history prevents schema0 downgrade from becoming legacy.

`admitReceiptMetadata(id,current,reads,sites,purpose='read')`, `admitVersionMetadata(id,current,reads,sites,purpose='read')` and `assertAdmittedMetadata(version,metadata)` admit strict original before/after Sites and context plus acceptance-bound version digest BEFORE private receipt/intent/version bodies. Legitimate historical no-op receipts retain their original authority after later source revisions. Exact matching UUID replay uses the same admission before original intent actor snapshot hydration.

`assertOriginalContext(retained,current,reads,siteId): void` proves the exact seven keys schema_version/site_id/incident_id/client_id/shift_id/service_context_id/stay_id against current canonical services, without association fallback. Explicitly selected ClientIncident must have exact nonnull original Site; independent IncidentAccess and ClientPolicy, exact shift Site/Client, actual available service context and actual authorised respite tuple are required. Unsupported or conflicting context refuses rather than fabricating a relation.

`sourceProofForAuditSubject(classOrMorph,id,current,reads,sites): ?array` supports actual private subjects and exposure-only shared intents under the same callback. It admits historical receipt/version metadata before private bodies and validates delivery membership through its original acceptance. Read authority does not become recovery actor ownership.

## Evidence and recovery

`upload(source,actor,UploadedFile,array): array` reserves the original globally unique intent and private generated path on the same canonical connection, physically commits reservation before bytes, then freshly rechecks source/expected revision and binds acceptance transactionally. Outer-transaction multipart calls refuse before staging. No fallback connection, scheduler or provider is registered.

`remove(source,evidenceId,actor,array): array` requires a reason and exact parent FK before file metadata hydration. It confirms removal from the active record, not physical purge. Durable cleanup runs only after real root commit and protects all retained private path pointers, including soft-deleted/immutable/cross-module history. False writes, read errors, failed purge or save/audit veto retain discoverable pending evidence without false acceptance.

Recovery APIs: inspectStaging(User,id), retryStagingCleanup(User,id), stagingAttemptsForViewer(User,afterId=0), cleanupAttemptsForViewer(User,afterId=0), retryRemovalCleanup(User,id). Actor-only queues return minimal stable IDs/state/accepted or removed-from-record truth/can_retry and bounded next_cursor; no UUID/path in navigation or DTO. Accepted stage binding can be reconciled separately by bindAcceptedStage(User,id). Original staged identity/expected source version is admitted before file/UUID bodies; cleaned attempts cannot become readable after worker/Site rebinding.

`evidenceReadProof(User,exposureId,evidenceId)` is an INTERNAL detached path/name/mime plus same-read actual byte digest/size descriptor after canonical source, immutable file facts and actual bytes proof. It must never be serialized. The HTTP owner must open/spool one byte stream and compare its actual digest/size to this descriptor before emitting a download/preview.

## Durable delivery boundary and remaining integration

Every genuine accepted aggregate command stages a revision-bound H&S outbox; named follow-up assignment also stages a purpose-bound recipient delivery. `deliverForViewer(User,deliveryId,consumer)` freshly rechecks current source/original acceptance/recipient and invokes the REQUIRED concrete callback with root, proof, current actor, same CurrentAuthorizationReads, Sites, retained membership, kind and recipient. The callback must return the exact source revision/version and verified actual destination identity; stored delivered flags alone never certify destination state.

Root's 200300 H&S consumer and immutable marker are separately authored and unmounted. The source observer is deliberately non-dispatching: it neither guesses today's incident Client nor marks an outbox delivered. Destination mount/automatic dispatch, concrete named-recipient delivery, CR composition, protected download transport, permanent recovery UI and shared source-family/audit/request protection integration remain owner dependencies. Source acceptance is not delivery or deployed acceptance.

## Prepared whole verification

All suites UNRUN: ChemicalExposureSourceCommandTest (14 declarations), ChemicalExposureReplayPrivacyTest (15), ChemicalExposureOriginalContextTest (11), ChemicalExposureLifecycleTest (13), ChemicalExposureEvidenceTest (26), ChemicalExposureHistoricalProofTest (14), ChemicalExposureDeliveryContractTest (10), ChemicalExposureConcurrencyTest (6), ChemicalExposureSourceMigrationTest (7). Guarded concurrency uses real two-worker first-INSERT barriers on the sole admitted MySQL test schema, bounded memory/time and isolated generated byte roots; no worker has been launched. No PHP syntax, Pint, Node, DB, browser, migration or native acceptance is claimed.

Source-only subsequent integration refinement: assertOriginalContext now has final purpose='read'|'capture' (default read unchanged); only the prospective capture picker explicitly uses capture under actual current create/manage plus independent Incident/Client/context proof. Canonical original Client policy queries id/site_id before body. OriginalContext whole suite adds denied Client SQL regression; previous28-file manifest SHA 837D0AE87EE7EE0EBA667A11433C730D27C6E35433DC6A69F522B9CDB1577910 is historical. All execution remains UNRUN; no source freeze.
