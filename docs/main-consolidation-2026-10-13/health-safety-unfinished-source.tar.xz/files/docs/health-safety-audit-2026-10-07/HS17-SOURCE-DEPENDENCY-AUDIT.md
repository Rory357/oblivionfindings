# HS17 source dependency audit and allocated source package

12 October 2026 NZ. Sections1–7 retain the initial read-only dependency audit and its point-in-time pins. Sections8–10 record the subsequently authorised source construction and current owned source hashes. No PHP/Pint/Node/browser/database, migration application or test execution was launched. All HS17 runtime acceptance is UNRUN; this is not a complete source freeze. Follow HS17-WORKSPACE-CONTRACT.md and the single-organisation architecture.

## 1. Capacity attribution: complete executable dependency inventory

The isolated checkout's executable references to WorkCapacityAssessment / work_capacity_assessments / capacityAssessments are the model, WorkplaceInjury relation, factory, ReturnToWorkController, InjuryReviewReminders, InjuriesControllerTest, original return-to-work migration and nullable-alignment migration. The SQL schema dump additionally retains the same legacy field/FK. No other production capacity writer or actual capacity forWorker caller was found. HR EmployeeProfileController:1321 calls WorkplaceInjury::forWorker, not WorkCapacityAssessment::forWorker.

| Reader/writer | Inspected meaning and dependency |
| --- | --- |
| WorkCapacityAssessment:19,47,66–68 | fillable user_id, user relation and forWorker() imply worker. No actor/worker/assessor provenance version. |
| ReturnToWorkController:737,747–753 | posted user_id means internal assessor; null/omission silently becomes injury.user_id. created_by is actual recorder. |
| injury-detail-dialog.tsx:1466–1486,1584–1592 | user_id is labelled Internal assessor; external name is separate. Blank posts null. |
| ReturnToWorkController:366,423–433 | loads user relation and exposes it as assessor; unknown legacy value is presented as confirmed assessor. |
| InjuryReviewReminders:41–46,57–60 | selects user_id and falls back from created_by to user_id as responsible recipient. No fresh source/HR/Site recipient gate or durable dedupe ledger. |
| WorkplaceInjury:78–80; controller:114,320 | parent relation and count, not worker attribution. Counts must still obey confidential source projection. |
| WorkCapacityAssessmentFactory:19–22 | independent injury and user factories plus independent assessor name. No proof they represent the same worker or actual assessor. |
| Original migration:105–129; mysql-schema.sql:23351–23378 | user_id NOT NULL; deleting that User cascades assessment. Additive attribution must retain existing value; hard-delete/history preservation needs explicit reviewed treatment. |
| Nullable migration:40–44,61–65 | assessor_name accepts null; rollback restores NOT NULL. Do not conflate unknown with empty/verified person. |
| InjuriesControllerTest:739–755 | capacity-status persistence only; does not establish assessor or worker correctness. |

Proposed additive attribution: retain legacy user_id verbatim with legacy_attribution_state=unknown; worker_id, assessor_user_id, recorded_by and minimal immutable identity snapshots are explicit for NEW versions only. worker_id is always derived under the canonical injury lock. External assessor name/type remain attributed claims; issuer/certificate provenance is separate. Never backfill verified assessor/worker from a coincident ID or present-day parent. Reads can show canonical parent worker separately from unknown historical assessment attribution. Keep forWorker compatibility via canonical parent injury join for legacy rows while clearly marking historical attribution unknown; typed rows must match the recorded worker/parent tuple. That is a proposed change, not existing code.

## 2. Actual grants and canonical source boundaries

Existing injury routes: index/export/show/download require hazards.view OR hr.wellbeing.view; create/store require hazards.manage OR hazards.create; update/status/RTW/capacity/modified-duty/upload/delete require hazards.manage (routes/health-safety.php:410–447). Create-only GET and successful ordinary POST currently redirect to the read-gated register (controller:480,527). Permanent capture recovery must be separate.

UserSiteAccessService::applyWorkplaceInjuryScope(:330) is recorded-Site only; null-Site rows are concealed. The named H&S wide-Site permission is healthSafety.viewAllSites, not generic sites.viewAll. Existing store and changed worker/Site writes call assertCanUseCurrentStaffAtSite(:1415), requiring current approved staff with actual primary/secondary Site. Historical injury identity must remain recorded when that worker leaves; an offboarded subject must not become a current picker/recipient.

Current detail bundles safety facts, clinical capacity narrative, medical-clearance text, all evidence filenames and raw audit changes behind the same broad source read. HS17 needs distinct bounded medical projection; a generic H&S/Site grant must not imply HR medical authority. hr.wellbeing.view is currently a read grant only; there is NO hr.wellbeing.manage or explicit work-restriction approval grant found. Workforce now owns the HR-authorised operational approval contract and its exact grants. H&S will not invent or implement a new HR approval/competence policy. At this initial audit checkpoint HR wellbeing authority was proposed for private capacity/medical projection; parent subsequently approved the exact bounded gate recorded in section8. No separate approval/competence grant was introduced.

HR profile read is separately gated by hr.employees.viewAny plus profile/Site scope (:1278–1284); injury summary additionally requires hazards.view (:1314–1354). It is factual/read-only, excludes assessment narrative and evidence. HrDocumentAccessService::readableDocument/applyReadableDocumentScope exist: current/historical employee Site provenance, and restricted documents additionally require hr.documents.manage. Callers still need explicit hr.documents.view/manage route/source capability; the helper itself does not confer it. Independent medical-file evidence cannot be authorised by injury access.

Linked Client incident validation currently proves Site convergence only (ReturnToWorkController:878 -> UserSiteAccessService:307). IncidentAccessService::canView/apply additionally enforces actual incident grant, assignment and hr.cases.view privacy. Reuse that independent current authority and current Client policy before projection/linking; do not let an injury FK authorise the incident. FirstAidAccessService has current-user callbacks, exact source assertions and eligible staff; its FirstAidConnectionsService independently resolves permitted links. Reuse patterns, not a generic refactor.

## 3. Existing journey and peer Control Room producer

WorkplaceInjuryJourneyService::synchronize(WorkplaceInjury):HsEvent (:39) locks injury and projects exact staff/Site/occurrence; creates/escalates required operational response and WorkSafe projection atomically. Retain rollback and identity checks. Its alertContext(:348) copies description/body part/type; the peer ControlRoomSourceContentService currently handles incident copies, not an injury-source privacy policy. Extending copied-content reads/search/audit/notes requires peer ownership agreement; do not delete independently authored operational work.

Peer control-room-delivery AlertReportingPolicy:158–176 and AlertReportingService:155–163 implement the actual workplace_injury target {kind,label,access,href,recorded}. Reporting completion separately checks exact injury/H&S tuple; source existence does not imply submission, approval or closure. The target currently uses actual injury read grants plus Site scope. Integrate this producer and proposed fresh injury access seam; no duplicate reporting policy and no automatic Client incident requirement.

HsEventService::projectWorksafeCompatibility(:676–679) returns when no ClientIncident, so injury-only canonical decisions do not converge to the injury-linked NotifiableIncident there. Journey currently calculates occurred_at+one day (:173), discovered_at from created_at (:172); contract requires honest awareness/notification/acknowledgement facts and a separately labelled internal target, not a universal legal deadline. Existing recovered transition invents actual_return_date=now (:608–610); test:692–702 asserts it. Change that explicit old expectation only with the authorised factual-date command and regression preserving unknown dates.

## 4. Existing Workforce APIs versus missing restriction interface

Inspected peer MAIN, not copied or modified:

- ShiftStaffEligibilityService::evaluate(Shift,User,?Collection,?PreparedShiftWorkload,bool):EligibilityResult; evaluateMany(iterable,iterable):array; candidatesFor(Shift):Collection.
- AssignmentEligibilityGateway::decide(Shift,User,?PreparedShiftWorkload):AssignmentEligibilityDecision wraps the canonical stack and fails closed.
- PreparedShiftWorkload binds exact proposed worker/duty structural facts and partitions hours; not medical evidence or approval.
- WorkforceEligibilityRefresh::stage(string type,int id,string fingerprint,array scope):WorkforceEligibilityRecheck persists recheck intent within the source transaction and dispatches after commit. sourceChanged(Model,bool) uses WorkforceEligibilitySources::definitions.
- WorkforceEligibilityRefresh::process(int id,int version) evaluates CURRENT canonical inputs. WorkforceEligibilityRefreshPresenter::present(Shift,User) returns actual interval, posture/freshness and bounded retry metadata.
- WorkforceEligibilityObservation is expressly last-per-Shift display cache; canonical assignment checks do not consume it. It is NOT immutable restriction/approval/interval-bound impact receipt.

Definitions currently excludes WorkplaceInjury, WorkCapacityAssessment and ModifiedDuty; the actual eligibility stack has no recovery restriction rule. No implemented approved work-restriction projection/impact receipt was found in the inspected main source. Cross-module architecture:108 describes the intended limited reason+interval review; qualification integration explicitly leaves separate modified-duty approval outstanding. These docs are proposals/status, not callable endpoints.

## 5. Proposed public DTO and ownership agreement (NOT callable implementation)

Parent-confirmed split: H&S owns injury/assessment/evidence, explicit worker-versus-assessor/recorder attribution, recovery-source versions and permanent recovery pages. Workforce owns HR-authorised approval/effective restriction persistence, the single canonical eligibility consumer, actual interval comparison, active relief/published-duty review and revision-bound impact receipt persistence. Root owns local routes/UI integration; CompanyHub owns global files/seeders and parent reviews grants. Peer Control Room owns copied-source privacy/reporting integration. This initial numbered-migration proposal was superseded by the explicit H&S190000 and Workforce190100 allocations recorded below.

Candidate structured restriction projection:
{schema_version:1, injury_id, worker_id, site_id, source_revision, restriction_id, restriction_revision, decision_id, decision_state, effective_from_utc, effective_until_utc|null, timezone, capability_constraints:[{code,effect}], maximum_hours_per_day|null, maximum_hours_per_week|null, replaces_revision|null, revoked_at|null, coordinator_user_id|null}.
Only approved current decisions are enforceable; pending/unknown is a separately labelled review state, never fit. Agree capability codes and unknown-code handling with Workforce; no free-text parsing. Use half-open UTC instants with explicit local date conversion, inclusive clinical certificate dates separately, strict real dates and NZ DST tests. Source revision/replacement/revocation is immutable and replay bound.

Candidate Workforce impact receipt:
{injury_id,worker_id,source_revision,restriction_id,restriction_revision,decision_id,delivery_id,delivery_state,evaluated_at|null,evaluated_interval:{from_utc,until_utc},outcome:unknown|review_required|compatible|incompatible|evaluation_failed,affected_duties:[{shift_id,interval,review_state}],coordinator_user_id|null,accepted_at|null,retry_state}.
Outcome/acceptance enums are proposals to agree, not current persistence. Exact tuple, whole overlapping restriction set and current revision must bind evaluation; source-save/intent/delivery/evaluation/coordinator acceptance are distinct. No diagnosis, treatment, assessor/contact, evidence name/path/count, narrative or copied excerpt. Never cancellation/reassignment/pay mutation from H&S status.

Candidate workspace DTO:
{detail:{id,reference,source_version,worker,site,status,coordination,recovery_plans,capacity_assessments,restrictions,scheduling_impact,treatment_claim_facts,connections,evidence,history,medical_access},commands:{can:{...},expected_version},return_to,injury_confirmation}.
Each medical collection/field requires independent source authority; restricted state must not leak hidden counts. Exact actor/key/verb/source/version receipt proves acceptance; receipt UUID only direct JSON recovery, not navigation. New class API proposals: InjuryAccessService, WorkplaceInjurySourceService, WorkplaceInjuryRecoveryService, InjuryWorkspaceService, InjuryConnectionsService and InjuryReturn. H&S will not implement InjuryRestrictionService or a Workforce approval/effectiveness store. No class currently offered as callable.

## 6. Required complete suites and outstanding agreement

Retain complete InjuriesControllerTest, InjuryHrOwnershipSeamTest, HsEventBackboneTest, ControlRoomBridgeWiringTest, HealthSafetyDashboardSiteIsolationTest, TaskProviderRowScopeTest and TaskProviderAuthorizationArchitectureTest. Main relevant existing complete suites include Unit/Services/ShiftStaffEligibilityServiceTest and Workforce eligibility refresh/qualification/command suites; peer owner must name actual final integrated suite inventory. No dedicated capacity-attribution or injury reminder tests found by executable-reference search.

Add complete attribution legacy/same-ID ambiguity/offboard history; exact worker/child tuple; current permissions/HR/Site withdrawal; command receipts/unknown-save recovery/stale review; atomic audit/evidence rollback; concurrent factual/restriction decisions; amendment/supersession/revocation; actual certificate attribution; awareness/notification receipts; fresh reminder recipient/dedupe/failure; confidential derived-source/HR/Tasks/export/evidence/search; overlapping intervals/future/expiry/NZ DST; actual Workforce relief/published review/pay preservation; guarded up/down/up refusal. All UNRUN.

Before writers: parent/source coordinator confirms private medical projection authority; Workforce supplies its designated approval/structured capability/interval/receipt contract; parent allocates migration numbers and privacy read-seam owners. Human authorised full HS17; these are source implementation dependencies, not an extra permission request or deferred acceptance.

## 7. Inspected source pins

SHA256; point-in-time reads only, no freeze or acceptance.

### hs: C:/Users/steph/.codex/worktrees/health-safety-workspace/oblivionfindings

| Source | SHA256 |
| --- | --- |
| docs/health-safety-audit-2026-10-07/HS17-WORKSPACE-CONTRACT.md | 3DC086E860913952876A5D1A2D66607B5F1230F794378700229AD991A5A1F591 |
| app/Models/WorkCapacityAssessment.php | D51A86BCB1B6C9878DF81326476C0666D80AF64508F003ADE0059FB6758EE118 |
| app/Models/WorkplaceInjury.php | 139F16DF9559AB4B3AD581F82333AEAE58C26C80CEC83C0A8361C15744E8EBF4 |
| app/Models/ReturnToWorkPlan.php | D7D9110ADB8DEE94E572095CC570EFD48C6B3F8684EE5AA13730E97E8459108B |
| app/Models/ModifiedDuty.php | 54EFA1CAAE748AB2360D7C64E220A20C6387CD918DCF408C4526B37839E98ADC |
| app/Http/Controllers/HealthSafety/ReturnToWorkController.php | 6236A1B99C8424435C4A5514B8A89B26780AB26CFC94804E2BBDE0924F4766AA |
| app/Http/Controllers/Hr/EmployeeProfileController.php | 33BEDF4CCBC6392EBC1F6156F01D8799F228AF67D1734CFDD08FF7C193B7496F |
| app/Domain/Hr/Services/HrDocumentAccessService.php | D44CE21291780B9E6E660B4EE56137D33FC99632188000C75E933A40D15F12AA |
| app/Services/UserSiteAccessService.php | 06EAB2B5BA74B7D154E139DDECC6210DB3D40AE8F98126C6186CC65BA36AB67E |
| app/Services/HealthSafety/FirstAidAccessService.php | C8E60C20E1831D55DB2AEE0C49AD3B4D4C09E01FE9D4B697473D41D4D3D79D89 |
| app/Services/HealthSafety/WorkplaceInjuryJourneyService.php | E90198C18A898FE3CD6DA67F13D4AC7E6342E9D2E73D3A49A95839BB47184BCA |
| app/Services/HealthSafety/HsEventService.php | BE18542D46C11D587EFB3DD1A42E6CEC601A10957AF45C485853E8127B614A8C |
| app/Services/Incidents/IncidentAccessService.php | AD55DA9833387EC490F4BC8B37D9B49EE0CF4D3870813869A02C075E0DE6FBB9 |
| app/Console/Commands/InjuryReviewReminders.php | D3A2DA02D5EDD11FFF1704BF25A6C3CE4889A24B20CE8B5A955329639712EA26 |
| app/Notifications/HealthSafety/InjuryReviewDueNotification.php | A8FC1D973A11F6C01F503ECD81951B9B19B6565A94F5689367BD80095B7E6681 |
| app/Services/Tasks/Providers/WorkplaceInjuryProvider.php | AB1EE2514203D8886A0BD399C4C6FD25B5ECE6A3DBBE25B3DC8D13A2A236F5A0 |
| database/migrations/2026_03_28_100004_create_return_to_work_tables.php | 83768981C8DEEFCBD253F21B96E4F60C74536376637D3CA27B214CC834DFD3D5 |
| database/factories/WorkCapacityAssessmentFactory.php | 2BC807E14BD30BCACEFEFEC3362ECBA03322E2B05242E1B60E7B3A0803302916 |
| resources/js/components/health-safety/injury-detail-dialog.tsx | E50E3B8C938D244706996B708972E7FA8C32CE52C2E4335EFACCFFBAB81CA723 |
| routes/health-safety.php | 26D4020E7DC7923D4190D3ECE4F7703B14F6BE3768B35A65EC0C8DCF80EAA48B |
| tests/Feature/HealthSafety/InjuriesControllerTest.php | 612EACEE6388F2EA7CFECDFEBE8F8F0AABC0D71B2D48D11D6697C1D1E7B11F62 |
| tests/Feature/Hr/InjuryHrOwnershipSeamTest.php | E734D0C1A6B9CA1B762D6E78C48CB3953E7509E867C81997DF669ED9915853AE |

### main: C:/Users/steph/Herd/oblivionfindings

| Source | SHA256 |
| --- | --- |
| app/Services/ShiftStaffEligibilityService.php | 05663F798EA62ADA65C47ECE642C08BF92D8D29201188BD24BB7C578C2AE7B95 |
| app/Services/Eligibility/AssignmentEligibilityGateway.php | 2C8F1B9AB099515BC3495D46555123FDBA727FA0F09F7823C8811D888DA1103A |
| app/Services/Eligibility/PreparedShiftWorkload.php | 3BF0570156A0103D6AF080686B659C4D2344045EC6703572A41BD288489964F9 |
| app/Services/Eligibility/WorkforceEligibilitySources.php | 468D729B652238713315D5339A2C4B327E991D5A2E1784A80F00B24FD629C009 |
| app/Services/Eligibility/WorkforceEligibilityRefresh.php | F173470FFD366FC7CB6B9BA3109D988C0FB106F3753400679745A7EDC8B5023A |
| app/Services/Eligibility/WorkforceEligibilityRefreshPresenter.php | 926DDE8B8B66E018F03F47D52F9087A4A501ACC3E474268DDBE0B667AAB388CE |
| app/Models/WorkforceEligibilityObservation.php | E0B0EFEA0D4AB38924AB68D36C6F7CDE73BA78C0719CDED4EA3CAA5E351C9686 |
| app/Models/WorkforceEligibilityRecheck.php | CEF2AE16794FA8F387A7C6651E17A3D9EE428724CAE6D8DD8E3939D6D8A5A544 |
| docs/workforce-audit-2026-10-05/cross-module-architecture.md | C992EF533433D03BEFFE5C2B25AFE01DEE70EDFCF544CE33B8937BC242F727B0 |

### cr: C:/Users/steph/.codex/worktrees/control-room-delivery/oblivionfindings

| Source | SHA256 |
| --- | --- |
| app/Services/ControlRoom/AlertReportingPolicy.php | D472EDD5AAB58D39F271E3C471A0001566FD2BE8433FEF156ABC6300A3191F8D |
| app/Services/ControlRoom/AlertReportingService.php | 02681302E71F1D430585B5782FE3C1C44E20D47B5FA710317425993F5A55CC02 |
| app/Services/ControlRoom/ControlRoomSourceContentService.php | CB8ED37145B3D5D85F41EE8B109BED3DEE0C61E4D0133D5F5E11FFB0F784F1E0 |

## 8. Approved H&S source allocation and authority

Root authorised the H&S source package in the isolated checkout and allocated migration `2026_10_12_190000_create_workplace_injury_source_history.php`. Source construction below supersedes the earlier proposal; it is not runtime acceptance. H&S owns InjuryAccessService, WorkplaceInjurySourceService, WorkplaceInjuryRecoveryService, immutable WorkplaceInjurySourceVersion and WorkplaceInjuryCommandReceipt; additive provenance/relations in WorkplaceInjury, WorkCapacityAssessment, ReturnToWorkPlan, ModifiedDuty and the subsequently allocated WorkplaceInjuryAttachment. The presenter owns InjuryWorkspaceService/InjuryConnectionsService and ReturnToWorkController integration. The register owner owns InjuryRegisterService. Root owns local routes/frontend. Workforce owns operational restriction persistence/approval/effectiveness, the one canonical scheduling consumer and revision-bound impact receipt. CompanyHub owns global files/seeders. No H&S InjuryRestrictionService or parallel eligibility store is authorised.

Approved factual authority is fresh hazards.view OR hr.wellbeing.view plus the canonical injury and approved Site. Capture requires hazards.create OR hazards.manage and a currently eligible worker at the actual Site. All retained update/recovery/evidence commands require hazards.manage; preexisting private medical fields additionally require fresh hr.wellbeing.view plus canonical injury/Site. Historical injured-worker employment is not an enduring read requirement. There is no added historical HR employment gate for the injury/capacity record itself. HR-linked documents independently require hr.documents.view, exact historical employee/profile/Site source proof through HrDocumentAccessService, and hr.documents.manage for restricted documents. These grants neither establish clinical competence nor approve restrictions.

Create-only reporters may record their newly submitted original treatment/claim facts; they receive minimal actor/source/payload/audit-bound acceptance, without private GET authority. Generic factual updates reject explicitly submitted protected keys (including null), preserve omitted protected values, and use factual history scope. Factual view queries explicitly select InjuryAccessService::FACTUAL_COLUMNS and never restore private injury columns through the projector. Private child reads/counts/evidence/history need the separate current medical gate. Current independent destination permissions are prepared only for their actual read checks; no roles/grants were added.

Existing capacity.user_id remains verbatim for legacy rows: schema0, revision0, unknown attribution and null new identity/snapshots. New assessments derive worker_id from the locked injury and separately record actual internal assessor_user_id or attributed external name/type plus actual recorder. No default assessor claim or professional verification is invented. New RTW/duty sources require exact injury.user_id = plan.worker_id = duty.user_id. Worker OR Site correction is refused with any typed capacity/RTW/duty/evidence, including archived typed sources. Untyped historical correction keeps original version contexts rather than relabelling prior private facts as the current person.

## 9. Current source construction and exact integration contract

Source files below are saved for integration review. PHP syntax, Pint, native test discovery/execution, database application, builds and browser acceptance are all UNRUN. Source SHA/readback and explicit migration identifier inspection are filesystem checks only, not runtime proof. There is no final source freeze. Sections1–7 retain the initial inspected legacy/main/Control Room evidence and their point-in-time pins; later source changes do not erase that evidence.

Public command APIs:
- Source: create(User,array), update/transition/assign(WorkplaceInjury,User,array).
- Recovery: recordCapacity/createPlan/recordReview(WorkplaceInjury,User,array); updatePlan(WorkplaceInjury,ReturnToWorkPlan,User,array); addModifiedDuty(WorkplaceInjury,ReturnToWorkPlan,User,array); uploadEvidence(WorkplaceInjury,User,UploadedFile,array); removeEvidence(WorkplaceInjury,WorkplaceInjuryAttachment,User,array).
- Every non-create command takes idempotency_key UUID and expected_version (current aggregate source_revision, honest legacy0). Create takes UUID plus canonical worker/Site and retained injury facts. Unknown domain keys fail validation. Only known framing/navigation fields may be removed by the HTTP adapter.
- Persisted receipt command names: create, update, transition, assign, record_capacity, create_rtw_plan, update_rtw_plan, add_modified_duty, review, upload_evidence, remove_evidence.
- Exact safe acceptance keys: accepted, injury_id, source_type, source_id, actor_id, command, idempotency_key, expected_version, version, source_version_id, changed, receipt_id, replayed. No clinical narrative, filename/path or child count. UUID canonicalises lowercase; changed payload renews command identity only after explicit user action.
- confirmationForViewer(User,int injuryId,string UUID) reconstructs the actor-bound retained acceptance after current original source/command/private authority and named receiver/document/incident checks. confirmationForKey(User,string UUID) is confined to that actor's injury/create receipt; unknown, other actor and non-create keys return null. It grants no permanent read authority.
- ValidationException carries stale/field/UUID errors while preserving the draft; source mismatch conceals with404 and current grant denial uses403. Integrity failures refuse acceptance atomically. Initial acceptance and later recovery validate exact source version, actor/action/subject/UUID/fingerprint/result-bound audit and durable receipt; no guessed latest audit.
- Immutable version content.scope is factual|medical. Factual injury versions retain the complete explicit factual projection only; medical injury/child/evidence versions retain complete persisted after-state. Baselines remain labelled legacy_unknown. Recorded subjects are refreshed before snapshot so persisted precision is compared.
- recordCapacity's optional explicit hr_document_id is retained in private version.content.command_facts.hr_document_id after independent HR source checks. It is not inferred from legacy document_path, not a new document FK and not proof of original/current bytes or medical certification.

Source finish checks: identical typed RTW updates preserve the existing recorder and child/aggregate revisions while retaining a minimal exact actor-bound no-op receipt. All source writers refuse missing current aggregate version identity or a governed parent downgraded to legacy; medically authorised writers additionally prove the current injury-level digest/after-state. Exact target proof includes genuine legacy-marker validation. Untouched schema0/revision0 remains unknown; positive malformed revision or retained governed history cannot be called legacy. Archived evidence tests exercise actual worker and Site rebinding refusal. These checks are prepared source only.

withReadContext(HealthSafetyReadContext,callback) consumes the existing active context with the exact InjuryAccess PERMISSIONS union, fresh internal staff and approved Sites, then existing factual hazards.view OR hr.wellbeing.view authority. It returns detached scalar/array projections only and does not create a nested transaction or expose current actor/reads handles. Prepared regressions cover factual standalone/shared parity without private SQL, loaded permission withdrawal, capture-only no read, expired context and authority-handle rejection.

Parent subsequently approved and source construction now implements prospective immutable factual_content JSON and factual_digest64 in190000/source versions. Each genuine newly committed aggregate stores a freshly re-read strict FACTUAL_COLUMNS snapshot in the same transaction as source/version/audit/receipt. Shape: {schema_version:1,injury_id,worker_id,site_id,aggregate_revision,facts,coordinator:null|{id,name}}; facts excludes the six separately shaped id/user_id/site_id/source_revision/coordinator_user_id/coordinator_snapshot fields. No private model/child/file/arbitrary identity snapshot is copied. Legacy baseline and no-op never invent new certification. Durable readback, audit failure and version veto refuse acceptance atomically.

factualSourceProof(injury,current,reads,sites) requires active current factual hazards.view OR hr.wellbeing.view, fresh canonical approved Site and exact injury/worker tuple. It selects ONLY explicit injury factual columns and immutable factual aggregate metadata, never private version content/content_digest/source_type/source_id/command/recorder fields. Exact current snapshot/digest/schema/aggregate identity yields detached {attribution_state:recorded|legacy_unknown|repair_required,source_version_id:int|null,source_revision:int|null}. Genuine schema0/revision0 without retained governed facts is unknown; missing/tampered snapshots/digests/current fields or retained typed history downgraded to schema0 are repair, including positive retained aggregate/factual evidence even if its schema marker is corrupted. Invalid proof returns no child/version identity fallback. The optional fifth operation is INTERNAL for existing manage-only source writers (view/update/transition/assign/review/recovery/evidence, never create); it checks their original source capability without granting enduring GET. Source writes reject corrupt prospective current factual proof before accepting another command. This does not replace private own-child/WF two-level proof.

currentVersionForSource still reads private immutable version.content and remains medical-authorised; generic H&S/Tasks/Control Room MUST use the separate factualSourceProof. Actual HsEvent producer records WorkplaceInjury::class, source_id=injury.id, category=injury, staff_id=injury.user_id, site_id=injury.site_id, client_id/asset_id null. The derived projection/Tasks owner consumes factual proof; root owns HsEventAccess/HealthSafetyReadContext and Control Room consumer coordination. None is certified by source-only construction. Workspace/Register child legacy classification is separately repaired by its allocated owner; parent injury marker integrity must also consume the new factual helper before describing an attributed source. No frozen peer files were edited here.

Read APIs: withCurrentViewer(User,callback(current,CurrentAuthorizationReads,sites)) admits only detached scalar/array results; readableQuery and project enforce current factual authority. assertChild re-reads the exact canonical child and parent tuple. currentVersionForSource(injury,source,reads) is an internal medical-authorised helper: legacy0 returns null; typed sources require latest own subject version, digest, canonical worker/Site and persisted after-state. It must not be returned as a mutable authority handle.

evidenceProof(injury,attachment,current,reads,sites) returns {attribution_state:recorded|legacy_unknown|repair_required, available:boolean, source_version_id:int|null, source_revision:int|null}. Attachment schema0 is explicitly legacy. Typed missing version never downgrades to legacy; changed bytes/size/metadata/digest/current tuple suppress availability. attachmentForDownload rechecks current private authority and this proof before providing internal streaming facts. Upload stages only source-private bytes, verifies them under the locked command, cleans this command's staging after failure/replay and registers cleanup on an enclosing transaction's rollback. Soft removal retains source-owned bytes/history and supports the exact accepted archived retry. No evidence receipt claims clinical certification or operational approval.

The source-only WF adapter is canonicalSourceForViewer(User,int injuryId,array expected), with expected_injury_revision, source_type, source_id, expected_source_revision and expected_source_version_id. Detached response:
`{injury_id, injury_revision, worker_id, source_site_id, source:{type,id,revision,version_id}, attribution_state, recorded_by, recorded_at, coordinator:null|{id,name}}`.
It requires current private source authority and exact source/version proof. injury_revision is the current aggregate. source.revision/version_id are that selected injury-level/assessment/RTW/duty source's own immutable revision/version; a later unrelated coordination change does not rewrite an unchanged child. Legacy remains explicit revision0/versionnull/unknown. There is no medical prose/private file/approval inference. WF must validate both expected levels in its actual governing physical transaction and retain its own operational decision/effective restriction/impact semantics.

Read-only MAIN proposal independently matches SHA256 `2B00DDBE21E3F9C628499CBB61ABF7C55AEB2960C01ECC0EC8BEF3DFD3AC3A12` at `docs/workforce-audit-2026-10-05/HS17-WORKFORCE-INTERFACE-PROPOSAL.md`. At this checkpoint that document is a proposal, not an implemented callable operational restriction interface. No operational approval/evaluation acceptance is claimed.

Migration190000 adds only source/provenance/history/receipt fields/tables; no legacy user_id backfill or generic FK removal. Down refuses any independent versions/receipts, typed fields, coordination, snapshots or meaningful JSON evidence. All new named indexes/constraints are explicit and20–22characters at most (receipt key18); none exceeds MySQL64characters.

Prepared complete suite method inventory: eight suites,89 methods in21 owned source/test files (filesystem inspection, not native case discovery). All acceptance remains UNRUN:

| Complete suite | Prepared methods | Status |
| --- | ---: | --- |
| WorkplaceInjurySourceCommandTest.php | 20 | UNRUN |
| WorkplaceInjurySourcePrivacyTest.php | 16 | UNRUN |
| WorkplaceInjuryRecoverySourceTest.php | 11 | UNRUN |
| WorkplaceInjuryEvidenceSourceTest.php | 10 | UNRUN |
| WorkplaceInjuryOperationalSourceTest.php | 11 | UNRUN |
| WorkplaceInjurySourceMigrationTest.php | 5 | UNRUN |
| WorkplaceInjurySourceConcurrencyTest.php | 2 | UNRUN |
| WorkplaceInjuryFactualSourceProofTest.php | 14 | UNRUN |

Shared fixture: WorkplaceInjurySourceTestCase. Guarded real parallel worker: tests/Support/WorkplaceInjurySourceWorker.php; exact test environment/MySQL database and bounded temporary barriers, per-process1GiB, existing committed-fixture cleanup. Migration roundtrip is guarded and preserves original values; destructive rollback refusal is separate. These workers/tests are prepared only and have not been launched.

| Current owned source | SHA256 |
| --- | --- |
| app/Services/HealthSafety/InjuryAccessService.php | 20E89F4CA51D8252581054D9B3C5033665740F17AC05FD7EB2E7C6139C92DC1B |
| app/Services/HealthSafety/WorkplaceInjurySourceService.php | 8275187DB8887E85EA1C4B73211374F3F80C158D1001D0B99297F459F057F88F |
| app/Services/HealthSafety/WorkplaceInjuryRecoveryService.php | 6E6A9371F77353950E940D11A8A556183B2B0DB9E2FB2B931E0AAE6EC873354E |
| app/Models/WorkplaceInjury.php | 4D9CFCD79E9959194F17A67D42CB209EF107998F7E1C14E7F2807018F93950E7 |
| app/Models/WorkplaceInjuryAttachment.php | 00D0DAC4D2CE10C4AE1FFE61923022DF09AC619F6D48CC3FC2E3D7F8CF9CCC35 |
| app/Models/WorkplaceInjurySourceVersion.php | 7ACB6A911E9F61D88A6A8934643EFB182A212E01BBFD0155DF2D91DAF8477593 |
| app/Models/WorkplaceInjuryCommandReceipt.php | 40B70D6C3D60D726217353944B5F8FD9C6376C1DAF900BC67F05F1FD1454060C |
| app/Models/WorkCapacityAssessment.php | 0522257274AB00919B0F4CEACA53828B701E1D15EB25EBAF695BC59F1B0695FF |
| app/Models/ReturnToWorkPlan.php | DE6C6D3ADFBF02C9CB159325B918C17BC90338CEC1E4DCADEB1808B1E7D9AA11 |
| app/Models/ModifiedDuty.php | 6248470E29A19B07E727B88B5044A19FAF01CA76D9434A073B14CBB9B5A43601 |
| database/migrations/2026_10_12_190000_create_workplace_injury_source_history.php | 4DBA76553E0130E3AE0AAED6BAD29BCA0907C0F94EB90D6FC4576DA0A100BF28 |
| tests/Feature/HealthSafety/WorkplaceInjurySourceTestCase.php | D4F3A42E2DC347E1B6FD9C30DAA574A8E1E6E4C6B10D29E7529FAF50E8450EDD |
| tests/Feature/HealthSafety/WorkplaceInjurySourceCommandTest.php | D2322A7EF021769FEADE6C4FB26777B764BB8AFEC392D67CDAFF673D59FB1F6A |
| tests/Feature/HealthSafety/WorkplaceInjurySourcePrivacyTest.php | 156C9121A03DC6A2F87A129A33FD181C7462A9856B09DEB99BF2243D35D17150 |
| tests/Feature/HealthSafety/WorkplaceInjuryRecoverySourceTest.php | 3FCCD7F60F663155B93442B481F8677184C63F436240FB50337732F80B1AB4D4 |
| tests/Feature/HealthSafety/WorkplaceInjuryEvidenceSourceTest.php | 1D137767CFAE1D4550531ED3B0FAFC473B97B3813A5B2CCFB8285CE2E410DB1F |
| tests/Feature/HealthSafety/WorkplaceInjuryOperationalSourceTest.php | DAE32FB0DDC8FE21EA3F1EC18B383B6022D1991243ED962A2E163DDE0B369BA4 |
| tests/Feature/HealthSafety/WorkplaceInjurySourceMigrationTest.php | 43ABA0EE9B9357CF8471B5FA605CA0784B29A4DEC0C0B5D440A541E07BF12D24 |
| tests/Feature/HealthSafety/WorkplaceInjurySourceConcurrencyTest.php | 886F9564694CC283CD2AFFA8841A81F08D0D02BC7E3C9A9DBB4524330DCDD92B |
| tests/Support/WorkplaceInjurySourceWorker.php | E9F05DA29565C35F27AE2D1D1E8BE59B482178FFCACBD4B51CE8D3E00B507D5B |
| tests/Feature/HealthSafety/WorkplaceInjuryFactualSourceProofTest.php | 6A1AC53318F1DA5F13849674DF3C89832B210B5E6B6DB79AF728E719343C2650 |

Required remaining acceptance includes the actual controller/UI/entry/derived/private export/download/search/reminder integration, complete native suites and concurrency/rollback proof, Workforce approved operational store/consumer/impact receipt, and exact built-candidate browser/draft/source-return proof. Current source construction does not certify scheduling impact, clinical fitness, WorkSafe notification or full HS17 completion.

### 10. Explicit atomic Site/coordinator correction and retained provenance repair (source only)

The parent explicitly approved extending the existing update command for a genuine canonical Site correction. Transport fields are site_id plus optional coordinator_user_id (positive), reason and next_review_date (real YYYY-MM-DD), the latter three all-or-none. Receipt remains update/injury under the existing expected_version and exact actor/payload UUID. Original canonical update AND assign authority is proved before any mutation; proposed destination must be actor-approved and the canonical worker currently eligible there. The explicitly named replacement requires their own fresh current internal-staff, destination Site and injury factual-read authority, without inventing access to the original Site. Same-Site or omitted-Site transfer tuples are refused; use the existing assignment command there. Existing typed recovery/evidence history, including archived evidence and externally downgraded child markers with retained governed history, still refuses worker/Site rebinding.

If the transfer tuple is omitted, existing coordinator ID, snapshot and review date are preserved exactly; a genuine Site change requires that retained owner to be currently eligible at the destination, otherwise a precise site_id validation error preserves the source/draft. There is no implicit assignment, null clearing, fabricated review date or new grant. The newly approved explicit atomic tuple resolves the previously reported no-dual-Site-owner correction gap in source construction; controller/UI integration and actual acceptance remain UNRUN. Before/after Site and named ownership, actual reason/review date and recorder are retained in the same immutable source version, with fresh factual snapshot/digest, aggregate revision, audit and receipt transaction. Protected preexisting medical values remain omitted-preserved; an explicit protected overwrite still requires current private authority.

Exact accepted correction replay/recovery rechecks original command authority, named command dependencies and the current canonical worker/retained coordinator at the current injury Site; it never reassigns an owner from an old receipt. Later explicit assignment keeps its actual current owner when an older correction receipt is recovered. Stale draft, changed UUID payload, current actor/Site/owner withdrawal, audit refusal and storage failure do not become success or partial ownership changes. Prepared complete Command/Privacy additions exercise destination-only named owner success, retained-owner preservation/refusal, complete typed transport, same-Site assignment bypass, original-source/destination/worker authority, typed-history refusal, exact later-version receipt replay, private-field preservation and transaction rollback.

Both currentVersionForSource and evidenceProof now check ANY retained governed history for the exact source_type/source_id before admitting schema0 as unknown legacy. The check is identity-only EXISTS across retained parent ownership, never an old-parent private content query. A forged legacy node or external reparent cannot mask earlier typed ownership and re-enable evidence download. Positive revision or nonnull prospective factual proof is also governed evidence even if its schema marker is corrupted. Genuine untouched legacy remains unknown, with no retrospective certification/backfill. Whole Operational/Evidence regressions retain original governed history, create actual typed facts before external tampering, then cover a fake legacy reparent node, later fake schema0 node, unavailable bytes and identity-only SQL. All eight domain suites (89 filesystem-inspected prepared methods) and source/static/runtime acceptance remain UNRUN. There is no final freeze.
