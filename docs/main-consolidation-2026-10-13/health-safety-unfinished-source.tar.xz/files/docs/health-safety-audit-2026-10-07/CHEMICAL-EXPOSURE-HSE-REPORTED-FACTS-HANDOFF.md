# Chemical exposure destination reported-facts proposal

Source-only, UNAPPLIED, all executable/physical verification UNRUN. Unknown remains the provisional optional capture design communicated to the human, not a received human answer. No private aliases, source-family consumers, routes, dispatch, schema application or shared mounts are inferred.

## Exact proposal

`CHEMICAL-EXPOSURE-HSE-REPORTED-FACTS-UNAPPLIED.patch` has seven semantic service hunks against root-owned `ChemicalExposureHsEventDeliveryService.php` AB152766B6BA47D3C4EBCCFA65599B984CA6921D22E3DA45BE95996939CA910E and one compatibility assertion hunk in the existing complete 26-method `ChemicalExposureHsEventDeliveryTest.php` 90B0AE04DEC099D9F0B5D9D483ACE4EEDC407D10487F881F1115609CE316FC62. Neither live file was changed. Exact old-line counts/new offsets were reviewed in memory only; no parser/application execution.

The actual Source D7DE78D80568B3C64B05E4EFB3EBEC5F3D88EEC3B6CC06E14FFE007D48EE27A5 `reportedFactsForSnapshot(root,current,reads,sites)` authenticates the SAME presented model, immutable original field acceptance and historical Sites/associations. Its existing `response.response_floor` and `harm_assessment=unassessed` replace raw treatment/derived-boolean classification. Current reported categories retain none Low, first aid Medium, medical/hospitalisation High and death Critical. Current reported Yes without a current reported category stays High. Unknown/unanswered/legacy-unconfirmed/prior-context categories are Medium operational triage unless current independently reported Yes supplies High. No diagnosis, harm assessment, competence/fitness, WorkSafe, closure or new owner rule is added.

Existing High/Critical response-floor investigation behaviour remains; a separate care-review-needed indicator never raises the floor or creates an investigation. Independent higher severity, investigation, owner, status, handover, signed WorkSafe decision, closure and original event time/reference are retained.

## Delivered-attempt reconciliation

The actual `ChemicalExposureDeliveryService` 5C514FE6184F719F0E6880B5D5A476DF95C4385E32378876F2BAC026D4F2BC1F calls its consumer even for state=delivered, inside the same physical command transaction. A stored flag is not concrete destination proof.

The proposal changes read-only confirmation of a correct immutable identity/time marker but deficient response to `destination_confirmation=unconfirmed`, `can_deliver=true`, `blocked_reason=response_floor_pending`, retaining the normal null href/unmounted HSE-read limitation. Explicit current-authorised delivery raises only a deficient severity/existing investigation floor, checks every unrelated persisted attribute is unchanged, strictly audits `chemical.exposure.reconcile_health_safety_response`, verifies the sole exact audit, then lets the existing outbox write complete. Save/audit/outbox failure rolls the response back. Lost-response retry re-proves the same destination and creates no duplicate response audit once the floor is satisfied.

No immutable marker/source version/receipt is rewritten or newly certified; the existing marker proves source identity/time, never old clinical or response assessment. No marker schema change or new sanitizer key is needed. Audit uses only already accepted scalar root/source/actor/version/UUID/changed and source_content_digest/source_tuple_digest. The latter anchors fixed destination identity, operational floor/response and an actual microsecond reconciliation time; no body is copied. The existing protected root sanitizer is a hard dependency.

## Whole suites and limits

New `tests/Feature/HealthSafety/ChemicalExposureHsReportedFactsPolicyTest.php` declares 25 methods, not native cases or passes. It uses actual Source commands, real 200300 markers and guarded physical MySQL testing fixtures. The precontract case creates genuine retained ledger acceptance without a field-origin map, then a real Source narrative correction stages its outbox. Matrix and cases cover both discordance directions, omitted/Unknown answers, independent incident flags, prior-context reaffirmation, retired historical subject, current grant/Site/old-Client withdrawal, workflow preservation, no-op source receipt, concrete read confirmation, reconciliation veto/audit/outbox rollback, unexpected owner mutation, discarded actual response and marker/original field acceptance tampering.

Run the entire existing destination suite and new policy suite only after coordinator admission and composed proposal/migration. Reported-facts four suites now54 declarations plus the separately saved two-real-reader regression delta; all UNRUN. Nullable200600 DDL is still UNRUN. Original124-query/<100 failure and prior full-native46 failures remain unresolved. Destination GET/body admission, whole collection/source-family/notification/Tasks/HTTP/frontend mounts, sourceCommitted dispatch and external acceptance remain separate open integration evidence.
