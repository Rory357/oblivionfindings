# HS18 routing settings, audit and exposure HTTP composition

Source checkpoint only. The complete approved goal remains active; this is not runtime or release acceptance. Work is isolated on `codex/health-safety-workspace`. MAIN, production, peer previews and shared runtime were not changed or invoked.

## Actual composition

The ordinary chemical exposure audit projection is mounted in the audit view service and three audit controllers. Current source/private checks precede pagination, search and copied body projection. The separate three audit-route proposals remain unapplied pending allocation; source integration does not prove route-level withdrawal/restoration behaviour.

Incident routing is connected to the settings page with inline rule editing, current scoped person selection, actor-bound receipts, interruption recovery, saved draft protection and explicit Auckland daylight-saving selection. Existing setting authority remains `healthSafety.settings.manage`, checked on a current approved staff account. A dedicated current middleware preserves the persistent route boundary and the source service independently checks authority.

Sixteen ordinary chemical exposure workspace routes and two historical capture aliases use source authority and private response headers. Risk and sealed recovery endpoints are not mounted. The dashboard chemical reporting entry now opens the permanent capture page. Private task destinations remain unavailable until the focused destination is verified in the real application.

## Verification limits

Ten unique PHP files passed standalone syntax checks at 64M. Six TypeScript files passed transpilation syntax checks at 128M; semantic types and imports were not checked. Five routing/settings TypeScript files passed the scoped formatting check at 192M. The exact 22-file source pins are recorded in `storage/logs/hs18-routing-settings-audit-and-exposure-http-composition-2026-10-12.json`.

All added or extended behaviour suites remain UNRUN: routing backend 69 declarations plus 25 HTTP declarations, routing frontend 11 declarations, submission physical-commit integration 5, exposure HTTP 28 and audit boundary 23. These are selected footprints, not a unique whole-programme test count. No native application bootstrap, database migration, runtime queue, browser, role/mobile/accessibility, provider or hardware check was run for this checkpoint. Workforce remains the shared-runtime slot coordinator and has not admitted an H&S slot. Historical failures and the query-budget overrun remain unresolved.

## Decisions and review

The human selected an organisation setting for whether people named as involved are blocked from reading and notifications during independent review. The stated default assumption is `block_involved_access`, with `assignment_only` available. Each accepted report must retain its original policy snapshot, so later configuration does not silently loosen protection. D05 foundation and all downstream integration remain incomplete.

Automatic review rejected a broad removal of setting permission middleware; that removal was never applied. The distinct explicit fresh same-permission guard was independently reviewed and approved. Additional private risk audit recognition, a sealed recovery incident picker and an outgoing parent handoff remain held and unapplied.

Workforce supplied a source contract for the existing proposed `hr.workRestrictions.approve` and separate `hr.workRestrictions.manageApprovers`. H&S must reuse the owning implementation; neither broad settings access nor list maintenance supplies approval or private wellbeing authority. This checkpoint does not install or activate those grants.

## Remaining acceptance

One organisation across approved Sites remains the boundary. No tenant selector, tenant transport or tenant-based acceptance was introduced. The full HS00–HS27/S01–S21, C01–C30/O01–O16/X01–X12/R01–R10 scope is retained. Remaining work includes D05 capture/draft/replay and all direct/copied readers, incident owner filters, the five shared notification consumers, Control Room adapter and note ownership, typed reminders, private risk/recovery transport, specialist register and cross-module parity, full migrations/rollback, query-budget repair, meaningful native tests and real browser/role/responsive/accessibility and applicable provider/hardware evidence. No final release, freeze, deploy or completion claim is made.
