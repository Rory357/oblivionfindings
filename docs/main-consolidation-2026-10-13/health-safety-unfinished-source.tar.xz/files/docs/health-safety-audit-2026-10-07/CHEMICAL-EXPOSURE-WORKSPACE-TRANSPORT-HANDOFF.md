# Private chemical exposure workspace and transport candidate

12 October 2026. SOURCE ONLY. All executable, HTTP, storage and browser acceptance UNRUN. Controller, response middleware, both existing capture aliases and new routes exist only in CHEMICAL-EXPOSURE-HTTP-COMPOSITION-UNAPPLIED.patch; they are not mounted by this package. This does not release the private exposure workflow. The original private200200 foundation and root200300 destination consumer are separate moving dependencies. No migration, permission grant, public chemical command, shared reader or destination dispatch is added here.

## Owned source APIs

- ChemicalExposureWorkspaceService::index(User,array filters=[]): array. Current hazards.view is required; lacking current hr.wellbeing.view returns the existing restricted envelope before private row/count/filter SQL. Private reads require actual current staff, dual grants, original active approved Site and canonical source. Exact filters: site_id, worker_id, substance_id, from, to, page. Instants require real offset/Z timestamps; IDs/pages are positive 32-bit. All requested filters precede private source discovery. Counts mean currently readable source-proven reports, never total exposure/completeness; corruption makes counts and trusted total null. Performance and query ceilings remain unverified.
- detail(User,int,array pages=[]): array. Pages history_page, reviews_page, followups_page, evidence_page; default1/per_page25. Same canonical model is acceptance-proven immediately before shaping. Exact root/child re-fetch snapshot comparisons prevent an earlier proof authenticating another body. Immutable history is original Site/context-admitted and strict receipt/intent/audit-proven before body; the displayed version digest equals its accepted receipt anchor. A withdrawn historical Site/Client is denial, not an invented empty history or total. Damaged root returns repair_required with record/command_context/private collections null and commands false. Damaged child hides body/capabilities and trusted child total.
- capture(User,int substanceId,array filters=[]): array. Current hazards.create OR hazards.manage captures newly supplied occurrence/medical facts without saved private read. Options require current approved active Site and current eligible worker. No saved exposure SQL. The root-approved additive Source::assertOriginalContext purpose defaults to read for every historical/read/delivery consumer; only this capture picker explicitly uses capture, with current create|manage and the same independent original association policy. Original Client admission uses only id/site_id before ClientPolicy; picker names follow admission. can.create=true, can.read_saved reflects dual grants only.
- commandOptions(User,int,array filters=[]): array. Original private management and exact source proof; target Site options do not require a capture grant. Receivers remain independently private-read eligible on the ORIGINAL canonical source Site. No fitness/competence qualification is inferred.
- confirmation(User,string UUID,?int exposureId=null,?int substanceId=null): ?array. Exact original actor/current command authority, retained intent/receipt/audit/tuple; uppercase UUID normalises. Null exposureId recovers original create-only acceptance. Optional substanceId binds the original catalogue parent. No trusted session acceptance, saved medical fields or grant acquisition.
- href(User,int): ?string. Optional independent enduring private-read source proof. Capture acceptance alone returns no saved-record link.
- deliveryAttempts(User,int): array. Reports durable outbox metadata; destination_confirmation=not_checked, reported_state retains the stored state, can_retry=false. No recipient names/IDs, instruction, HSE destination URL/body or physical dispatch assertion.
- recoveryAdmission(User): array. Current private management only. Actual staging/removal recovery continues through existing ChemicalExposureEvidenceService methods, not a new ledger.
- ChemicalExposureDownloadService::download(User,int exposureId,int evidenceId): StreamedResponse. Internal canonical evidenceReadProof descriptor never becomes JSON. A single subsequently opened stream is copied to a spool, complete size/SHA checked against that descriptor before response creation, then ONLY the verified spool emits. Missing/changed/false streams refuse; no reopen at emission. Private no-store/no-referrer/sandbox headers. Explicit module download does not grant capture-only saved evidence read.

## Exact scalar page contract

Collection props: exposure_access, records, counts:{exposures,awaiting_medical_outcome}, source_integrity, page:{current_page,last_page,total,per_page,has_more}, filters, can:{capture}, chemical_exposure_confirmation:null. Generic restricted readers receive records/counts/page/filters null.

Show props: detail, return_to:null|validated path, chemical_exposure_confirmation:null|receipt. Healthy detail:

```
{
 exposure_access: 'readable', id: 18, source_integrity: 'recorded'|'legacy_unknown',
 record: {
   id, substance:{id,name}, worker:{id,name}, site:{id,name},
   exposed_at:'2026-10-12T00:00:00+00:00', exposure_type, exposure_duration,
   circumstances, symptoms, first_aid_given, medical_attention_sought,
   medical_treatment, medical_outcome, incident_reported,
   recorded_by:null|{id,name}, updated_by:null|{id,name}, created_at, updated_at,
   attribution_state, href,
   incident_connection:{state:'recorded'|'absent'|'unknown',id:null|int,href:null|path,reason:null|string}
 },
 command_context:{root_type:'exposure',root_id:18,expected_version:3,source_version_id:null|int},
 can:{correct,review,assign_followup,upload_evidence},
 reviews:{items,page,source_integrity}, followups:{items,page,source_integrity},
 attachments:{items,page,source_integrity}, history:{items,page,source_integrity},
 delivery:{state:'unconfirmed',attempts:null}
}
```

Review items: id, reviewed_at, outcome, notes, recorded_by, attribution_state.
Follow-up items: id, assigned_to, instruction, due_at, completed_at, completion_notes, recorded_by, completed_by, attribution_state, can_complete. Completion needs current named receiver AND hazards.manage; another private reader receives false.
Evidence items: id, attribution_state, available, original_name, description, mime, size, uploaded_by, source_version_id, source_revision, href, can_remove. Private path/disk/hash/content/UUID absent. Genuine legacy unproven evidence withholds metadata/link instead of asserting historical private verification. Missing known bytes are recorded/unavailable; altered bytes or metadata are repair/unavailable and copied filenames withheld.
History items: id, revision, source_type, source_id, command, recorded_at, recorded_by:{id,name} retained original actor, reason, before:null|root fact whitelist, after:root fact whitelist, attribution_state. No raw version content, actor authority, arbitrary snapshots, file paths or UUIDs. Current child facts are separately paginated. Historical evidence bytes are not resurrected.

Capture props: capture, return_to, chemical_exposure_confirmation, chemical_exposure_href (null without separate enduring read). capture:

```
{
 substance:{id,name}, sites:[{id,name}],
 staff:{items:[{id,name}],next_cursor:null|int},
 incidents:{access:'not_selected'|'restricted'|'readable',items:null|[
   {id,reference,occurred_at,client:{id,name}}
 ],page:null|pagination},
 options:{exposure_types:['inhalation','skin_contact','eye_contact','ingestion','injection','other'],
          medical_treatments:['none','first_aid','medical','hospitalisation','death']},
 can:{create:true,read_saved:boolean}
}
```

Option selectors: site_id, after_id, search, incident_search, incident_page. Search max200, cursors0..2147483647, page1..2147483647. Association picker requires independent incident AND Client view before their SQL; exact non-null original incident Site, Client/shift/service-context/stay tuple via actual source helper; no legacy fallback or caller-supplied context. Target commandOptions returns sites, staff, incidents, receivers with the same shapes.

## Commands and retained acceptance

Both original POSTs /health-safety/substances/{substance}/exposure-records and /exposures retain route names and raw numeric parameters in the UNAPPLIED patch. No pre-admission model binding. Show bookmarks also accept positive32bit navigation-only followup/evidence selectors; they do not hydrate or authorise arbitrary children and the read-only Back sanitizer strips them.

Create input: idempotency_key, user_id, site_id, exposed_at, exposure_type plus actual optional exposure_duration/circumstances/symptoms/first_aid_given/medical_attention_sought/medical_treatment/medical_outcome/incident_reported/related_incident_id. Structured medical_treatment derives medical_attention_sought; an explicit boolean must agree. Original incident association only related_incident_id; actual original Client/shift/context/stay are independently proven, never transport fields.

All other domain inputs include UUID + expected_version; omissions preserve source fields. correct_exposure requires reason plus reviewed root facts. review_exposure: reviewed_at, outcome recorded|followup_required, nonblank notes. assign_followup: assigned_to, instruction, due_at. complete_followup: completed_at, completion_notes under exact child/named receiver/current authority. upload_evidence: multipart file, optional description; outer physical transaction refusal before staging remains. remove_evidence: reason, exact canonical child; receipt confirms active record removal only and physical cleanup is separately reported.

Success exact twelve-key chemical_exposure_confirmation:
accepted, actor_id, command, idempotency_key, root_type, root_id, source_type, source_id, expected_version, version, source_version_id, changed.
Root_type exposure; source_type exposure|review|followup|evidence. Source-version null is an actual no-op; no replayed/receipt_id/body key. JSON success also chemical_exposure_href independently current-proven or null. Stale version produces existing422 expected_version validation preserving draft/UUID; exact retained retry may return the original accepted receipt after later changes only if current original authority remains. Unknown domain keys are errors; adapter strips only _token/_method/return_to/section/action and multipart file. No HTTP optimistic acceptance.

HTML capture-only fallback remains /health-safety/chemical-exposures/capture?substance_id={originalparent}&return_to={boundedorigin}, never arbitrary origin/register/saved-private source. Hint stores only UUID/rootId in session; GET reconstructs acceptance under current authority. UUID must never enter URLs/history/navigation. Direct JSON-only explicit receipt_key lookup can recover uncertainty; HTML/X-Inertia/partial requests containing it404. Session hints cannot confer source read or clear edited drafts.

## Navigation, routes and headers

URLs remain /health-safety/chemical-exposures. Inertia component names health-safety/chemical-exposure-index, chemical-exposure-show, chemical-exposure-capture and chemical-exposure-recovery.

ChemicalExposureReturn keeps public chemical register tab/q/site_id/physical_form/status/controlled/sds_state/period/page with actual enums/bounds. Public record leaf sections overview/controls/sds/storage/history/exposures. Private register exact FILTERS. Private record leaf section plus history_page/reviews_page/followups_page/evidence_page positive32bit. Strip command/action/followup/evidence/receipt_key/UUID/nested return. Reject external/host/scheme/fragments/backslash/control/array/bad-percent/oversized data; duplicate selectors cannot choose ambiguity. Source grants never follow from navigation.

New saved commands/reads use private route group dual grants plus service fresh staff/Site/source. Collection hazards.view can truthfully show restricted. Capture routes original create|manage only. Evidence/recovery requires saved private management. Recovery lists/lookup/bind/retry and delivery-attempt metadata are JSON-only; actor-bound stable IDs, no UUID/path/file bodies. Evidence staging.accepted=false is never a source receipt. Cleanup state complete/pending does not alter retained acceptance. Recovery bootstrap is a private page only.

Matched-route headers wrapper preserves installed exception handling/status/body; it does not catch/report/remap exceptions. Outer authentication/unmatched routes/version reload headers remain separately unproved. Private error body/header/browser behaviour needs admitted HTTP execution before acceptance.

## Complete prepared suites and unresolved composition

- ChemicalExposureWorkspaceReadTest:35 declarations; actual writer history, page2, genuine legacy, marker/digest/body/child/tuple interleaving, withdrawal/restoration, filters/count unknown states, exact incident choices and UTC instant.
- ChemicalExposureWorkspaceControllerTest:20 declarations against literal prospective routes, no fake mounting: both aliases, capture-only uncertainty, actor/parent/UUID, HTML/Inertia/partial, saved dual/Site/staff/current authority, real commands/replay/stale, strict selectors and outbox truth.
- ChemicalExposureEvidenceTransportTest:12 declarations, physical-commit test fixture guarded by actual admitted MySQL test schema; same descriptor/open race, false open, spool only, current source/parent admission, bytes missing/damage, upload/remove parity and current actor-bound durable recovery/reference-blocked pending truth.
- Unit/ChemicalExposureReturnTest:6 declarations, navigation only.

73 declared methods; source declaration count is not discovered cases or execution. ALL UNRUN. No PHP/Pint/Node/browser/native/helper jobs. Parent must review and adopt actual controller/middleware/two-alias/routes patch, finish permanent pages, compose source family/read audit and actual destination consumer/CR bridge, admit complete migration+suite run and physical failure/concurrency tests, then real browser/date/history/download proof. No automatic HSE/recipient dispatch, destination confirmation, root-note overwrite, export, risk writer or global audit access is invented here. The private200200 sourceCommitted hook remains intentionally non-dispatching until parent allocation. Source moving/unfrozen; this candidate is reviewable groundwork, not accepted partial release.


12 October additive index DTO: readable current dual-authorised collection now includes sites:[{id,name}] from only approved active/not-archived Sites in the same callback; restricted envelope sites:null without Site names/private discovery. Whole WorkspaceRead35 source declarations include four actual Site/current-role withdrawal and restoration cases, UNRUN. Previous69 declaration manifest is historical; refreshed73 declaration source manifest does not mount aliases/controller/routes or certify downstream dispatch.

## Subsequent source-only follow-up transfer delta

Workspace follow-up items add can_reassign for current managers/incomplete admitted work; receiver choices now require actual completion hazards.manage plus independently fresh full original-source context. The UNAPPLIED HTTP patch adds guarded PUT followups/{followup}/reassign with assigned_to/reason and unchanged twelve-key receipt. Read Back continues to strip command/child selectors. Complete HTTP suite now22 and Unit Return7; WorkspaceRead35 and EvidenceTransport12 retained, total76 source declarations UNRUN. See follow-up reassignment handoff for actual source command/history/replay/rollback semantics and separately UNAPPLIED pre-body ordering dependency. Controller/aliases/routes are still not adopted.
