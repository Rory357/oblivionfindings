# First Aid and restraint metrics: bounded read-source increment

Status: source implementation with standalone syntax checks only. All native tests, SQL behavior, query cost, UI behavior and end-to-end privacy acceptance remain UNRUN. Not a source freeze, deployment or release certificate. The rejected command-write infrastructure remains absent and was not retried.

Workspace: `C:/Users/steph/.codex/worktrees/health-safety-workspace/oblivionfindings`. One operating organisation; canonical current capabilities, staff, approved Sites and actual confidential subject authority are unchanged.

## Concrete APIs and DTOs

- `FirstAidMetricsService::forViewer(?User $viewer, CarbonInterface $from, CarbonInterface $to, int|array|null $requestedSites = null, ?HealthSafetyReadContext $context = null): array`.
- `RestraintKpiService::summary(int|array|null $siteId, CarbonInterface $from, CarbonInterface $to, ?User $viewer = null, ?HealthSafetyReadContext $context = null): array`.
- `RestraintKpiService::unreviewedWorklist(int|array|null $siteId, int $limit = 8, ?User $viewer = null, ?HealthSafetyReadContext $context = null): ?array`.
- `RestraintKpiService::breakdowns(int|array|null $siteId, CarbonInterface $from, CarbonInterface $to, ?User $viewer = null, ?HealthSafetyReadContext $context = null): array`.

Supplied context requires the same actor, active lifetime and existing complete family preparation. Missing preparation, wrong actor and expired handles remain errors; there is no fresh-context fallback. Absent context opens one current canonical source callback. No models/builders/authority objects leave these metrics callbacks.

First Aid retains `activity` (`treatments`, `ambulance`, `hospital`), `by_type` and `by_outcome`. Restraint retains its eight summary operands, three breakdown arrays and exact healthy worklist row keys. Both metric envelopes add `source_access: readable|restricted|unavailable` and `scope: current_readable_sources`. Withheld scalar operands and breakdowns are null. Worklist is null when withheld, [] only for an authorised empty queue. Explicit [] requested Sites remains an empty intersection. Null requested Sites means the current canonical approved source scope, not a global grant.

Standing restraint oversight operands retain their old independence from the period. Period endpoints remain inclusive. Worklist preserves started-at descending order, explicit ID tie break and limit. Plan status/review-date counts are factual workflow counts, not proof of current plan approval or clinical authority. `clients_no_active_bsp` compares the current readable event/plan populations; UI must not present it as organisation-wide completeness or proof that inaccessible plan history is absent.

Each metric operation uses existing `HealthSafetyReadMaterialisationProof::within`. When an outer Overview already has that proof, the actual source query receipts remain in its final barrier. Standalone operations verify before their own context closes. Expected 403/404 source refusal yields null unavailable/restricted operands; unexpected errors and scope misuse propagate. A missing First Aid table remains unavailable, never a healthy zero.

## Canonical prebody changes

FirstAidAccess subject preparation now selects Client ID/Site only before the same existing ClientPolicy. Picker label reads preserve their old shape/order, and their actual SQL is constrained to the admitted original Client ID/Site tuples. No global policy or permission changes.

RestraintAccess `assertEvent` and `assertPlan` add optional final `bool $identityOnly = false`. Metrics pass true. Canonical Client policy and source-tuple checks use Client ID/Site only; event-linked BSP and version checks also select only their actual identity tuple, without content. Default false preserves the full Client relation after admission, using exact stored source-parent and admitted Client ID/Site predicates on the actual Client body SELECT. Existing unsaved capture candidates retain current Client authority without a fabricated saved-source predicate/certificate. Existing default source operation behavior and grants remain.

Restraint metrics independently qualify source identities through the same `assertEvent`/`assertPlan` before dates, metric facts or worklist names. Final metric queries retain exact original root identity tuples and Client placement. Client worklist name SQL additionally embeds the admitted original event facts/parent query. Full `RestraintService` source commands, other writer files and shared HSE/Tasks/CR services were not edited.

## Verification actually performed

Five final owned PHP files each passed serial `php84 -n -d memory_limit=64M -l`, exit 0. No application/bootstrap, schema, native test, storage, job, browser, build, Pint or resource/process checks were run. No memory peak measurement is claimed.

New whole `tests/Feature/HealthSafety/HsSourceMetricsPrivacyTest.php`: 29 declared native test methods, no data-provider expansion inferred; actual discovered cases/outcomes UNRUN. Fixtures use actual RestraintService commands and inherited real current-staff/Site schema. Legacy fixtures are explicitly legacy; factory Site canonicalisation is accounted for before persisting the genuine null-Site fixture. Tests cover grant/HR/Site withdrawal/restoration, actorless/denied nulls versus genuine empty zero, canonical Client subset/plan counts, period/standing scope, labels/pickers/default/capture compatibility, supplied-context no extra actor hydration, wrong/missing/expired contexts, real post-projection source/name/new-membership changes, and actual beforeExecuting source rebind at the first name/body SELECT with zero private Client hydration.

Existing full `FirstAidMetricsPrivacyTest.php` remains unchanged with 8 methods. Its two historical denied/actorless healthy-zero expectations (methods at lines 128 and 140) are incompatible with truthful withheld nulls and must be explicitly reviewed before the full native gate. No cases were removed, filtered or reclassified as passing. Related full FirstAid access/entry/workspace, BSP privacy, restraint register/derived, Dashboard/Analytics and KPI suites remain required; this finite unit is not an exhaustive programme runner inventory.

## Essential remaining limitations

1. Final source-query replay is a fact/membership stability check. It is not original-role/override/HR equality. HSCtx's prepared actor/currentStaff/Site caches can outlive a same-session authority change; the actual permission-evidence prebody equality seam remains open, without new grants or a duplicated evaluator.
2. FirstAid subject IDs and picker Client admission are prepared once. A same-session membership withdrawal after preparation and before name/metric SQL is not fully covered by fact replay alone. Initial fresh/warmed-actor withdrawal is covered by the actual canonical preparation; no claim of all late-authorization closure.
3. Restraint's canonical stay/context/plan-version checks still have their own underlying queries. These metadata checks are not all registered as proof-used receipts by the shared collector. Full final supporting graph/current authority reproof and existing Respite stay prebody rules remain an explicit dependency, not silently certified by root-row replay.
4. Metadata scans and exact tuple OR predicates have unmeasured query cost. No cache, query ceiling change or performance acceptance. Native aggregate locking behavior is unverified.
5. Root dashboard already passes current actor/context to the restraint methods. Observed HsKpiService `firstAidActivity` and HsAnalyticsService `build` still omitted the final context argument in their FirstAidMetrics call at this checkpoint. Root/C own those forwarders and must preserve the outer materialization lifetime. Nullable arrays/scalars and scope labels require their actual frontend composition; no whole-dashboard acceptance here.

## Final owned pins

- `app/Services/HealthSafety/FirstAidMetricsService.php`: D4706E62A9CAE600A84D18F73CD66BDDB8BF7FE59CD1EEED95D481C0C25921F3
- `app/Services/HealthSafety/RestraintKpiService.php`: 452555D89BAADD6591867CCD471A254D9EC7F129A915C084EC83F3C42407664D
- `app/Services/HealthSafety/FirstAidAccessService.php`: F549E05BC39933DBE7E480C85B76D85C18AE68E3340DDE612B61E0F834BB2816
- `app/Services/HealthSafety/RestraintAccessService.php`: C354284BB2842B4E7823A85AB8C6A7C282D291FF6993015112500BD434B34DC1
- `tests/Feature/HealthSafety/HsSourceMetricsPrivacyTest.php`: 813E9864F346D8E59D78C4601845B485F2907EBF63A7F0BA0287CCED59D3B196

Observed canonical dependencies, not frozen shared inputs:

- HealthSafetyReadContext: FA34CF35A6F9C665D55E106576F1FDAFC833A0D0C9C2148802F63E0138A8522F
- HealthSafetyReadMaterialisationProof: 8A687EEC61D8A1FAC9DC61F8469334D3B719B8B2CA40D14F0AA40C261826B844
- CurrentAuthorizationReads: 38D31FCB8D24EB9B319045195E239E8834231F532E7BC782AB2B09E781F30413
- AuthorizationEvidenceLockService: 1BCB05D64D5EB3112BAFDF901B4A5253D3329F7BB13D98E0C8CBD2FC76FFB3EC
- UserSiteAccessService: 16289962A57C93E3858D3740149043F1FE3692F48F963F497BBE3D9C42E33B2E
- HrCurrentStaffService: C8DDA69E30BE46DCEB53124B44A85BBF41CBD249A81A3D42217CB15066B31E54
- ClientPolicy: B6EEACE3A8CD7BB809AEB1D91A0A96BA55DB9448453354537F19F247FA9616A3
- User: 6F2A380B2D42BFD1CD6446C3D8B4E359520CCAB379C8D9D4F1ACC87E9B64F395
- RestraintEvent: 30A537386DCECD8B0A5032E0DB72A4369928F017DC98AF2D6D8620B0B5018728
- BehaviourSupportPlan: 863F1598E54D404C54E9F98AAC40BAFE4C55D73986D040DE6A288B1FA919E9E9
- BehaviourSupportPlanVersion: 73639B22B75E30C074EAA8E010F1355F5C86A7240624C89A2CB1C303F663503B
- FirstAidRecord: AE72D78E05B875094CD4BE7377841F52F1D8631B549156C3ABF867499806BFB9
- RestraintService: 1B7417C8D49E3547B82CC8F0E28F9A946CCC0621B3FD12F75FA015DFE799A266
- RestraintEventCommandTestCase: B5AD5EA104026C162CF79E02C55C21F0F626F8127CF5DD3A589A16AE0D3A6CF4
- FirstAidMetricsPrivacyTest: 31D511ED2FA6724E74F6EB6AC7D4D0722FF1F23CF2DB06451A53160025D00A5A
- HsKpiService: A2646CCC7F738F0AC0DB9D7E845B3BED29F99B701D531DD7F77CE570149B87B0
- HsAnalyticsService: E5F2E09E2D9430022E97E4B9131858FF7AD779D83ED197003F07BE651D048DCF
- HealthSafetyDashboardController: E4262E0E5467399290D5E92FEEA44E26E348EE1F3C139C92FE5B7A624AACC28D
