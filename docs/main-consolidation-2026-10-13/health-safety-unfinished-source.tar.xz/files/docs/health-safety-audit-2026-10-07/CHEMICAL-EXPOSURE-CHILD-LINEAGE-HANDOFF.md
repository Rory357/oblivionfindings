# Private chemical exposure root/child lineage repair

UNAPPLIED source-only proposal; all PHP/DDL/native/browser/executable checks UNRUN. No live Source/Workspace/Evidence/Tasks/Access edits, schema/receipt/audit changes or new grants. Original124/<100 query failure and prior full-native46 failures remain unresolved.

## Canonical API

`ChemicalExposureSourceService::assertSourceIdentityBeforeBody(SubstanceExposureRecord $root, Model $identity, string $kind, CurrentAuthorizationReads $reads, User $current, array $sites, string $purpose='read'): void` is a metadata-only preflight inside the same active authorised callback. Fixed source kinds are exposure/review/followup/evidence, with exact actual persisted concrete model class and canonical physical connection. Child identity includes id, exposure_id, source_schema_version and source_revision; root includes actual BODY_ADMISSION_FIELDS. Root metadata is freshly read and compared, with current approved active Site admission. The helper returns no model, permission token or private body.

After exact current parent/child identity, identity-only ANY retained kind+source ID versions and receipts are checked for original aggregate ownership. Source0/revision0 is genuine legacy only when it has no governed retained identity. Foreign/moved/downgraded source, nonzero legacy revision or typed source with no exact retained version is repair. Evidence includes soft-deleted retained rows. Presence of a receipt cannot substitute for a missing typed child version. The helper does not itself certify full child contents or acceptance: existing currentVersion and semantic receipt/audit proof remain required.

`currentVersion` invokes this before root0/revision0 early return. Root source identity and actual source kind/class are now checked even for legacy. Genuine no-history same-root legacy children remain unknown on both legacy and later governed parents. Root capture proof preserves its original capture purpose; capture authority does not admit saved private child provenance.

Root `admitExposureIdentityBeforeBody` additionally examines ANY retained root-kind source ID and version-bearing receipt metadata before its legacy return. A missing/moved version cannot erase typed receipt evidence. Genuine null-version legacy no-op receipts do not certify facts; their exact original tuple/Site/context is independently admitted through existing admitReceiptMetadata before root body access, including after a raw current-root Site rebind.

## Seven exact Source-only hunks

The proposal contains the root legacy body check, reassign metadata preflight plus exact full-body marker predicate, complete metadata preflight plus exact full-body marker predicate, the canonical helper, currentVersion invocation before early return, and private review/followup/evidence audit-subject preflight before its full body. It preserves all existing command UUID/revision/intent/audit/rollback and completed-work semantics. Text old lines/counts/new offsets were reviewed in memory, not by running PHP or applying the patch.

## Whole regression suite

New `ChemicalExposureChildLineageTest.php` declares26 methods, not native cases/passes. It uses actual Source create/review/assignment and physically staged Evidence upload/removal under existing guarded physical testing fixtures; explicit query corruption represents damaged retained state. No FK/uniqueness constraints are disabled. Cases cover healthy accepted proof; genuine legacy; current class/kind/parent mismatch; root early-return nonzero child revision; typed missing history; all three moved/downgraded children; same-parent downgrade; old-Site withdrawal without old body; in-memory parent mutation; root-kind moved metadata; receipt-only lost version identity; lost receipt retained version; null-version genuine no-op/original Site admission; capture-only root compatibility; Source complete/reassign rollback and no new intent; Source audit-subject body concealment; soft-deleted evidence. SQL assertions distinguish SELECT EXISTS(*) identity proof from actual private body projection.

## Explicit consuming dependencies

Root owns Workspace.children and resolveFocus: pass the admitted root and exact minimal child identity to this helper BEFORE acceptedVersion/body reads; then retain existing full currentVersion/same-model proof and no false totals. Current Workspace9CA5 focus/child composition remains dependent, not certified by this Source patch.

A owns separate UNAPPLIED EvidenceService preflight proposal. Concrete loaders: remove (~115), evidenceReadProof (~266), cleanup inspection (~301), removedProof (~421) need minimal evidence identity (withTrashed where appropriate) and the same seam before metadata/path/body. Existing upload/staging replay loaders (~98/~410) already have strict original ledger reconstruction; do not erase those independent gates or call every loader an output bypass. Cleanup must preserve original receipt/stage admission before its private path.

FollowupDestination taskRows current (~183) and delivery admitAttempt (~229), plus DeliveryService followup (~47), retain existing accepted-version/membership admission and need bounded current-child identity preflight before full child model where applicable. C's TaskRows successor is separate UNAPPLIED ownership; no outbox/current aggregate equality is newly imposed on unchanged open child work. Source assertOriginalCommand completion-replay child loader (~799) also remains a separate original-receipt prebody integration point; existing ledger reconstruction is not replaced by this metadata seam.

The preceding finite C notification review is historical source-only: C has now explicitly identified historical reported-origin final SQL closure as OPEN; new Task84CFB85C successor review is pending. No shared notifications, HSE family/risk or private GET mounts are inferred.
