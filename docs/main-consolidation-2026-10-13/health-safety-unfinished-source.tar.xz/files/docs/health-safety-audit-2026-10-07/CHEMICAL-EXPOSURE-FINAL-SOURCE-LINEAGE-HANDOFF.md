# Root and follow-up final original-parent closure — 12 October 2026

SOURCE ONLY / UNAPPLIED / UNRUN / NOT FROZEN. Root explicitly allocated the canonical exposure-root ownership denial in addition to selected-child ownership. No live service, Source, descriptor, registry, vector, caller, role, grant, scheduler, controller or route was changed. All executable/native/DB/browser/process checks remain unadmitted. Textual hunk counts/hashes are not syntax, behaviour, concurrency or query acceptance.

## Successor to compose, not stack

Use ONLY `CHEMICAL-EXPOSURE-FINAL-SOURCE-LINEAGE-UNAPPLIED.patch`, SHA2561905FA4089F4E9D193CE4399EF8A787FD4F8EB1CF79EACA639D1ACDD922C8094. It replaces the historical child-only BEDD5A334EBE80420C32CC5A46620DEEA77427ADF09DD3D16853EBE423F5F90B proposal; do not stack them. Historical child handoff D040E8DF6B48821A9347841F44C79DE4BCF7138DBCBB6948E83AEF428804A759 and registry evidence D023B61C remain intact, accurately recording the then-open root gap.

Exactly two source hunks, each18 added lines, old7/new25 context counts:

- `app/Services/HealthSafety/ChemicalExposureFollowupDestinationService.php`, `taskRows` final per-candidate statement407: fixed source_versions and command_receipts NOT EXISTS. Foreign exposure_id is denied for EITHER source_type followup + selected childID OR source_type exposure + admitted rootID. This mirrors Source.assertSourceIdentityBeforeBody root377–379 and child397–399. No private body/version content is selected and no new authority object or metadata escapes.
- `app/Services/HealthSafety/ChemicalExposureNotificationAccessService.php`, `correlateAdmission` existing source/followup join170: the same two tables and two identity branches, correlated to exact notification_source.id/notification_followup.id. Existing type/five-key minimal payload/current recipient, original context, root/outbox revision/version, fingerprints, reported-origin membership and ordinary default exclusion stay intact. Count/get/read SQL now has the proposed root AND child absence checks before body selection.

Exact unchanged live bases:

- FollowupEF18FF9BD6A84F30771959BFF808970A2B6817C5AFCF260D301CF25935CEFF13, already root-composed from TaskRows84CF + descriptorDB3 + childB0F17.
- Notification helper7F2C0C6E2130CC604DDA0B110BFBFEDBA814325BFBE549AA4696D4E975933242, shared consumers still unmounted.
- SourceF88C1C3A321BE7D91B169A1B88D5229CF9E390E3EE6E7468134D2D305B51BE85; Delivery94AD7D78215E13366CE8B49E1A4123DADBCC6B1AAB01B2BD5A4C474B3B5401A6.
- TaskAggregator4D3C7D4032D82DE3252CCA8C8CAA903698E559C95BAD100FC88A4B4769718124; no provider registration or permission preparation change occurred.

Task current-root and child revisions remain independent. These denial predicates do not add an outbox prerequisite or invalidate unchanged named work because of later legitimate aggregate commands. Notification current-outbox semantics remain their existing separate policy. Actual physical connection/lifetime/current actor/original association checks continue in the active source callback; absence predicates are final stability closure, not provenance fabrication or grants.

## Whole tests, meaningful actual after-proof mutations

Only these two WHOLE suite files changed:

- `tests/Feature/HealthSafety/ChemicalExposureTaskPrivacyTest.php`:19 methods, SHA256 DC6A0DDB03F4281F26967E7537FBA157CFDFADA64DB1BEC89039A8627F1EE86B. New method at296 is `test_foreign_accepted_root_or_child_lineage_rebound_after_last_preflight_is_denied_by_final_feed_and_badge`. Actual commands produce target/healthy own work and a separately accepted foreign-root child. Its genuine followup version/receipt AND genuine exposure-root creation version/receipt are each rebound by source_id only while a later healthy child hydrates, AFTER target's last source proof and DTO accumulation. The foreign exposure_id stays retained and all existing target fingerprints stay unchanged. Feed or navigation must withhold target only; exact lookup refuses while conflicting, no foreign medical version body hydrates; original provenance restoration restores own feed/badge/exact lookup and the independent foreign recipient's real work.
- `tests/Feature/HealthSafety/ChemicalExposureNotificationPrivacyTest.php`:30 methods, SHA256 A0801D81D6F333B62453C241128992E4C12F8E0A6522F4F3BE98283F8252BFEB. New method at542 is `test_foreign_accepted_root_or_followup_lineage_rebound_after_discovery_denies_count_body_and_read_only_for_that_notice`. Actual Source/delivery fixtures produce target, healthy own private + ordinary notices and a separate foreign private acceptance. Rebind each genuine ROOT/CHILD version OR receipt AFTER constructing the canonical query/admission descriptor. Final count/get/read-update refuses only target, without selecting its body or foreign medical version content; healthy private and ordinary survive. Restoring original accepted identity returns all own notices and independent foreign notice. No source completion/read grant or mocked source proof is introduced.

The earlier child-only test hashes7D077983/2BDF5F91 remain historical; the same two new methods are extended, no old method or assertion removed. Declaration counts stay Tasks15 whole suites159 (107 public +52 Pest) and prior combined notification11 whole suites170. Those programme footprints overlap the shared5-method child suite and must not be summed as unique cases. All tests are UNRUN; no physical concurrency or cost guarantee follows from these same-session prepared regressions.

## Registry alternative and remaining gates

Separate `CHEMICAL-EXPOSURE-TASK-REGISTRY-ONLY-UNAPPLIED.patch`0EEC6C0088DD995A7E30073CFCF514F950FC610028D52AFEB53325D56956CC9A adds only comment+existing provider. Current37-key five-family union already includes Chemical13 at all3 aggregator preparation origins and all7 actual supplied-context files. No added permission vector/role/grant/import/shared caller is needed. Earlier eight-file proposal2657638D was automatically rejected for broad security-sensitive shared read expansion without sufficient boundary-composition proof; it is not retried or mounted.

This successor prepares closure of the identified root/selected-child original-parent final SQL gap, not whole-source runtime readiness. Root still reviews actual composition and any further canonical proof concerns. B read-only review was requested; no B acceptance is asserted. Protected GET/focused-child transport/returns, source-owned private reminders/escalation, shared notification/CR owner composition, whole source/privacy/physical/concurrency/native and unchanged populated recommendation<100 query gates remain open. Task links remain literal null, no generic watch/assign/split/completion/audit adapter is added, and all source/type/current staff/Site/original Client/permission denial rules remain intact. Full programme completion is not claimed.
