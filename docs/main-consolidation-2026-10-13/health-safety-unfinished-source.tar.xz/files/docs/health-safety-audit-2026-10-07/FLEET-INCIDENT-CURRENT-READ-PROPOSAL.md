# Fleet incident current read proposal — 12 October 2026

Source preparation only. Root has mounted the bounded H&S dashboard consumer in isolated source; this is not Fleet controller adoption. The extraction patch is UNAPPLIED; live Fleet routes/controller/writers, UserSiteAccess and global authorization were not edited. PHP syntax, Pint, native suites, database, browser and process checks are all UNRUN under the shared runtime HOLD. This inventory is not a freeze or release claim.

## Canonical API

`App\Services\Fleet\FleetIncidentReadScope` prepares only `fleet.viewAny`, `assets.viewAny`, `fleet.manage`. Actual read admission is approved nonexternal account plus `fleet.viewAny OR assets.viewAny`. Actual Fleet Sites come from `UserSiteAccessService::accessibleSiteIds(current, ['fleet.manage'], suppliedReads)`, including active/not-archived Site and current assigned employment where there is no Fleet manage bypass. H&S all-Sites and incident-management permissions never substitute for either independent boundary. Incident Site is its current asset's `site_id`; `home_site_id` and unsited assets do not confer access.

- `withCurrentViewer(User, callable, array additionalPermissionKeys=[]): mixed` supplies `(current, reads, admittedSites)` only inside a materializing scalar callback. Optional preparation accepts only the existing projector flags `fleet.incidents.manage`, `hr.assets.view`; it never grants them. No global auth replacement.
- `withReadContext(User, HealthSafetyReadContext, callable): mixed` consumes the same active context's core three prepared permissions/current actor and independently derives Fleet scope. Missing keys, wrong viewer, expired/foreign reads or escaped query are integrity errors with no fresh fallback. It uses `consumeSourceViewer`, preserving Fleet's actual manager bypass rather than inventing a strict H&S employment gate.
- `queryForCurrentReads(User current, CurrentAuthorizationReads, ?array selectedSiteIds=null): Builder` is usable only inside that exact invocation. Requested positive integer Sites narrow canonical scope. Builder execution remains bound to its original invocation, even inside a later consumer of the same outer context.
- `normalizeFilters(array): array` and `applyFiltersForCurrentReads(Builder, array, reads): Builder` retain `vehicle_id`, `driver_id`, `site_id`, `severity`, `incident_type`, `status`, `search`, `date_from`, `date_to`, `tab`; add only `occurred_from`, `occurred_to`. Unknown service filter keys and array/object shapes refuse explicitly; controller transport/query keys remain handled as before through `Request::only(FILTER_KEYS)`.
- `windowCount(User, ?array selectedSites, string from, string to): array` and `windowCountInContext(User, context, ?array selectedSites, string from, string to): array` return exactly `{access: readable|restricted, count: int|null}`.
- `dashboardCountsInContext(User, context, ?array selectedSites, string from, string to): array` returns exactly `{access: readable|restricted, rolling_count: int|null, open_count: int|null}`. Both measures share the same admitted Sites. Rolling count uses `[from,to)`; open count preserves the existing **unresolved now** meaning across all periods using actual model statuses `reported|investigating`. Older unresolved occurrences must not disappear behind the rolling cutoff. Root's open link retains `tab=open`; its rolling link remains the honest full register until Fleet owner adopts the proposed filters.

Counts never return Site vectors, models or authority. Null selected scope means all independently admitted Fleet Sites; a supplied array is intersected. No module grant, no Fleet-admitted Site, or selected scope with no intersection returns restricted/null before Fleet incident hydration. Genuine readable empty scope results are integer zero. Only expected 403/404 are shaped into restricted counts; validation, integrity and unexpected database errors retain their normal failure behavior.

## Time/filter contract

`occurred_from` and `occurred_to` must be supplied together as real ISO instants with explicit `Z`/offset (up to six fractional digits). Invalid/naive/reversed/equal/duplicate array shapes are field-specific validation errors. Normalization is UTC with six fractional digits; interval is **lower inclusive, upper exclusive** `[from,to)`. Root dashboard must observe one interval and use those identical instants in count and register link. Existing inclusive civil `date_from/date_to` `whereDate` meaning stays unchanged and composes with the instant interval. No fixed Auckland conversion or legal threshold is introduced.

## Deferred controller composition

`FLEET-INCIDENT-CURRENT-READ-EXTRACTION.patch` is a semantic review artifact against controller SHA `74B96EC877CD172B35123A378A5790454942AB156A14C1002D22B3BBECEE9E07`; Fleet owner must rebase and review before adoption. It changes only read/display consumers: register, lazy list/count/stat/form props, deep-link detail, show, picker search and CSV. Actual existing writers, downloads, capture helpers and routing are untouched.

Each deferred prop executes a fresh current materializing callback; no pending closure captures a prepared actor/Builder. Read projectors receive the current actor for existing flags; cloned Request is callback-local. Picker collections explicitly map selected columns to scalar arrays. Staff choices reproduce the existing current staff/date and primary/secondary Site predicates using supplied reads; this duplicated policy seam should eventually be extracted by the Fleet/HR owner, not adopted as a new grant. Selected option pinning, cap20, list25 with query strings, all tabs/hero fields, old detail keys and direct modal redirects remain. CSV preserves all 15 columns, order, existing formula guard and filename; its query and lazy iteration occur within the stream's current-read callback. Stream-time failure behavior needs Fleet owner's ordinary integration review; no new global exception handler is proposed.

The controller retains implicit Fleet model binding and its original create/write helpers. This proposal does not claim raw-ID prebinding or writer closure has been independently changed. Existing unconditional row HR holder projection (`IncidentController:647–654`) and detail Client/H&S links (`907–922`) remain an explicit separate source privacy prerequisite: Fleet incident admission is not an independent HR/Client/H&S destination grant. The narrow extraction preserves those fields and does not claim full cross-source privacy completion.

## Whole suite inventory

All declarations were counted from source text only; none executed. New HTTP suite is prospective acceptance for the unapplied extraction, not a passing claim against the current legacy controller. No selector narrowing or query ceiling relaxation.

| Full suite | Declared methods | Status |
|---|---:|---|
| `tests/Feature/FleetAssets/FleetIncidentReadScopeTest.php` | 18 | new, UNRUN |
| `tests/Feature/FleetAssets/FleetIncidentCurrentReadHttpTest.php` | 9 | new, UNRUN; extraction prerequisite |
| `tests/Feature/FleetAssets/FleetIncidentSiteAccessTest.php` | 8 | existing dependency, UNRUN in this package |
| `tests/Feature/FleetAssets/FleetIncidentTest.php` | 18 | existing lifecycle parity, UNRUN |
| `tests/Feature/FleetAssets/FleetBoundedOptionsTest.php` | 5 | existing picker parity, UNRUN |
| `tests/Feature/FleetAssets/FleetModalRouteShimTest.php` | 3 | existing entry/return parity, UNRUN |
| `tests/Feature/FleetAssets/FleetPermissionBoundaryTest.php` | 5 | existing actual module boundary, UNRUN |
| `tests/Feature/HealthSafety/HealthSafetyDashboardFleetReadTest.php` | 7 | new actual mounted dashboard integration, UNRUN |
| `tests/Feature/HealthSafety/HealthSafetyDashboardControllerTest.php` | 4 | existing dashboard contract, UNRUN |
| `tests/Feature/HealthSafety/HealthSafetyDashboardSiteIsolationTest.php` | 11 | existing dashboard isolation, UNRUN; root's two positive Fleet fixture grants now applied |

Ten complete files, 88 declared methods; new three files have 34 methods. Service coverage uses actual permission definitions/approved staff/Site/Fleet factories: warmed role and Site revoke/restore, alternative read grant, Fleet-manage vs incidents-manage vs H&S bypass, asset/home mismatch, null/foreign Sites, asset movement/archive, honest zero vs unknown with no incident SQL, exact offset/boundary/civil filter composition, source callback lifetime/actor/preparation, foreign physical connection and nested context parity. HTTP coverage adds actual response payloads, pagination/filters/modal return, counts/CSV, civil filters, malformed instant shapes, source/Site/grant withdrawal/restoration, fresh display flags, scalar pickers and formula guard. Actual H&S GET coverage proves no Fleet SQL/private echo for hazards-only, nondefault Site selection, exact independent scope, old unresolved retained outside rolling, lower/upper/future boundaries and warm revoke/restore. Rbac + SeedHrPermissions seeders supply actual definitions; no invented permission catalogue or mocked source policy.

Root corrected exactly two historical positive premises in `HealthSafetyDashboardSiteIsolationTest`: the own-Site viewer now additionally has `fleet.viewAny`; the all-Sites viewer additionally has `fleet.viewAny` and the actual `fleet.manage` Site bypass. The existing counts, assertions and 11 declared methods remain unchanged. Current source pin is `C72DB2196A0B1E0470593DA59708B16453920A5D5F4A1D2E356FF40F77D5D349`; this is a source fixture correction, not native acceptance.

One finite test-only delta occurred after the original proposal pin: `FleetIncidentReadScopeTest::reader()` now retains one service instance per test rather than resolving a new transient instance within another instance's active callback. This makes the real invocation/lifetime assertions exercise the same reader; no permission, service binding, assertion or declared-method change was made. Its previous `C0170928…` pin is historical; the current `74F0B471…` pin is recorded below. The other 16 proposal pins are not silently regenerated.

## Source pins

| File | SHA256 |
|---|---|
| `app/Services/Fleet/FleetIncidentReadScope.php` | `33DF18E00423E74183C7AC7FB12EE7C7A5405C3540E88AD3DB82D65A568445A7` |
| `tests/Feature/FleetAssets/FleetIncidentReadScopeTest.php` | `74F0B471FFEB3B3945C7AA3DD5AAC4FADC4125C67808FE1CA106D5619A30363A` (finite reader-instance fixture correction; historical pin `C0170928A593190FCA825E8E0E28D664E6DCA441F6C0515E4F0B194304012198`) |
| `tests/Feature/FleetAssets/FleetIncidentCurrentReadHttpTest.php` | `E3A90155072AACC7409EC0FD7F023E7048961AB98BF5031ABB6372393F160271` |
| `tests/Feature/HealthSafety/HealthSafetyDashboardFleetReadTest.php` | `D29CBA775B6F65302C66327FB9A1A265A4259A1C2261A8289F315A9BB1B22A44` |
| `app/Http/Controllers/HealthSafety/HealthSafetyDashboardController.php` | `4FAD60CD0C944E94F400C668683B2BD64758E860E817A2C80495396632C4319D` (root-owned consumer) |
| `FLEET-INCIDENT-CURRENT-READ-EXTRACTION.patch` | `0ADFC23075E8E6A368A993657EA5D50BDBBBC1DD934F3597A6EE674D9E80C0DF` |
| `app/Http/Controllers/FleetAssets/IncidentController.php` | `74B96EC877CD172B35123A378A5790454942AB156A14C1002D22B3BBECEE9E07` (unchanged) |
| `routes/fleet-assets.php` | `2EFBBC3015614E969220BD9C5BD9A1C3D57722FFD92AAAF988150C36C791DC59` (read only) |
| `app/Services/CurrentAuthorizationReads.php` | `38D31FCB8D24EB9B319045195E239E8834231F532E7BC782AB2B09E781F30413` |
| `app/Services/AuthorizationEvidenceLockService.php` | `1BCB05D64D5EB3112BAFDF901B4A5253D3329F7BB13D98E0C8CBD2FC76FFB3EC` |
| `app/Services/UserSiteAccessService.php` | `D5DF9DCE73EB23918762357AB219CCAD957BD9A094FCAE0079DDB4F94F53E022` |
| `app/Services/HealthSafety/HealthSafetyReadContext.php` | `8CC4D41263F7B22042FA17394DDE2BB3197A90877B6DA463277E01025282F0B6` |
| `app/Domain/Hr/Services/HrCurrentStaffService.php` | `BA764A5819557ED067954D7E081EB501B074C7E929C0A8A1AE188D4E39CBCC11` |
| `app/Models/FleetIncident.php` | `063ED73031228A9AB3122E13F4F5941BFCE29BD28AEBA0D3AC1B655132032719` |
| `database/seeders/RbacSeeder.php` | `6777D3A458A69BDD606A405B9C5D679DC6413B1A83DD1E23B68E52E806A67B7D` |
| `database/seeders/SeedHrPermissionsSeeder.php` | `4865559FB73BCB4CE2DC72E7707D92780C550658A581FF7928C2B16C95280FFF` |
| `app/Http/Controllers/Concerns/SanitizesCsvOutput.php` | `29BD69E1E6BAAFA00A303F31861D3DF090E9ED9BFDEC25834F5E80B3ADEA5D25` |

These are observed source pins, not migration/test/runtime acceptance. No scheduling/workforce persistence or Fleet ownership transfer is implied. Root's isolated dashboard prepares the H&S Site bypass + Fleet core union once, computes fresh selected H&S Sites with the same reads, then consumes the independently Fleet-narrowed scalar counts; null metrics produce no usable Fleet hero link. Live Fleet extraction remains deferred to its owner. Existing dashboard resolver/callers are not claimed generally refactored by this package.
