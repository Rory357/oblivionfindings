# Private chemical exposure follow-up transfer — source candidate

12 October 2026. SOURCE ONLY / ALL EXECUTABLE CHECKS UNRUN / UNMOUNTED / NOT FROZEN. No PHP, formatter, Node, DB, worker, browser, provider or test job was launched. Earlier source manifests are historical; this handoff does not establish delivery or programme acceptance.

## Saved command and DTO contract

`ChemicalExposureSourceService::reassignFollowup(SubstanceExposureRecord|int $source, int $followupId, User $actor, array $input): array` accepts exactly idempotency_key UUID, aggregate expected_version, positive assigned_to and nonblank reason (maximum2000). The route/root/child IDs are authoritative; unknown domain fields are rejected. Completed work and same-recipient transfer are refused. Only correction retains the existing no-op contract.

The unchanged twelve-key accepted receipt has command `reassign_followup`, root_type exposure, source_type followup, the existing child source_id, version expected_version+1, nonnull source_version_id and changed=true. One aggregate transaction retains original instruction, due time, recorder and creation time; immutable before/after captures actual old/new attribution and reason. Strict source/version/intent/audit acceptance, current original actor authority and original recipient eligibility remain required on replay. No grants, fitness or clinical competence are inferred.

Prospective original assignment and transfer require current hazards.manage plus dual private read, current staff and canonical approved Site; the independently fresh recipient callback prepares the full ChemicalExposureCommandAccess union and proves actual original Incident/Client/shift/context/stay. It does not borrow the assigning actor's authority. Historical names remain readable history without asserting current eligibility. The current source correction policy and original-context proof remain unchanged.

Pending outboxes bound to this exact child are acceptance-validated and superseded atomically. A successor outbox binds the new recipient/current revision/version. Delivered historical inbox rows are not rewritten. Old recipient cannot complete transferred work. Completion timing is compared to the retained actual assignment version (or real legacy created_at); absent legacy timing is unknown and requires a real governed transfer, never invented timing. Receipt, outbox state, database inbox presence, read flag and source completion remain separate facts.

Workspace follow-up items add can_reassign; true only for a current manager, incomplete healthy child and proven original association. can_complete remains named current manager and actual timing. Read-only historical viewers cannot complete or transfer. Receiver picker uses the same canonical eligibility gate and excludes current Incident/Client withdrawal after warmed permission caches.

UNAPPLIED HTTP proposal adds PUT /health-safety/chemical-exposures/{exposure}/followups/{followup}/reassign, name health-safety.chemical-exposures.followups.reassign. Existing private capture/saved aliases and controller remain only in the composition patch. Bookmark action=reassign_followup&followup=positive32bit is navigation only; read-only Back strips action/child selectors/UUID. Root owns inline form, routes and actual mounts.

## Prepared whole suites

ChemicalExposureFollowupReassignmentTest:23 declarations. Includes actual source and successor database inbox; exact history, completed/refusal/current actor and recipient/Site/HR withdrawal, stale/UUID payload/actor mismatch, pending/successor/audit/save veto rollback, foreign child prehydration, damaged version/membership, historical display, genuine legacy timing, and real linked Incident/Client warmed picker + actual assignment withdrawal/restore. ChemicalExposureConcurrencyTest:8 declarations includes actual guarded two-worker transfer-versus-transfer and transfer-versus-old-recipient-completion barriers. Worker is prepared, never launched.

Existing full DeliveryContract10, Destination25, WorkspaceRead35, HTTP22 and UnitReturn7 declarations were preserved/extended to current eligibility and transfer. HTTP adapter assertions require the unadopted composition patch; no route acceptance is claimed. All cases UNRUN; declarations are source counts, not discovered native cases.

## Separate pre-body ordering proposal and open scope

CHEMICAL-EXPOSURE-ROOT-BODY-ADMISSION-UNAPPLIED.patch and ChemicalExposureRootBodyAdmissionTest (10 declarations) are a separate, unapplied owner proposal. ReadAccess currently loads the private current root before proving retained original Client/context; CommandAccess does likewise before currentVersion. Proposal preserves fresh dual/Site permission, canonical NOWAIT, metadata-first historical admission and exact same-model tuple/JSON before full root body. No refreshed viewer, model-binding or today's Client fallback.

The original ReadService.collection additionally runs total/awaiting-medical count and paginate('*') before per-record original-context proof; the assertExposure proposal alone does not fix that caller. Its owner must compose candidate-first admission/count/body SQL. The prospective fail-closed legacy nonnull association branch also needs explicit association-reconciliation transport review before mounting; no legacy backfill or unproved context promotion is provided. These are open source integration dependencies, not masked output or completed privacy certification.

Shared inbox/header/count/read/update protection, TaskAggregator provider registration/full prepared unions, after-physical-commit dispatch and sourceCommitted remain UNAPPLIED. No live confirmationInContext or optional expectedExposureId delivery extraction was applied here; A owns their reviewed proposals. Current authorised manager retry remains the policy, original outbox actor is provenance. No external delivery or automatic scheduler registered.
