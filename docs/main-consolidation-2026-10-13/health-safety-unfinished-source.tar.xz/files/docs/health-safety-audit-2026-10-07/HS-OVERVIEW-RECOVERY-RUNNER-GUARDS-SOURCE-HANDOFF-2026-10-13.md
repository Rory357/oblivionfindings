# H&S overview/recovery runner guard source handoff — 2026-10-13

This is a finite source guard repair for HS-RUNNER-GUARDS-01, not a verification launch, source freeze, admission, or runtime pass. Only the existing runner and new source-check/evidence files were authored. Existing R1–R4 outputs and original R1 configuration are retained. The actual R4 84/84 result remains the accepted historical component checkpoint; it does not cover the later nullable metrics UI.

The stable runner is storage/logs/hs-overview-recovery-vitest-runner.ps1, SHA256 3EC385D65B5F01FCB0FCA2586DB0B40C5F994515162A28F2A0DE24514CDF7634. Its old SHA256 8AFDE558AF33C433FC82DEA40C7A385D019E1625C06F7BBCEA6043D2E4E9F0FF is historical. Default next revision is 5. Revisions 1–4 cannot be selected, and any pre-existing selected revision output or cache refuses overwrite.

## Reviewable protocol

- The same zero-wait Windows mutex is held through preparation, finite test execution, output drainage, and source audit. No extra admission wrapper or peer-stop action was added.
- Two independently obtained non-null CPU/memory/full-process observations require at least 4 GiB free and CPU below 85%. Unsafe, missing, stale, or unknown evidence yields HOLD. No present eligibility sample was taken during preparation.
- The unchanged pure classifier (19B90A2B70EF320A0FD639AA8752111A16E88513AC9FB98198AC84596D232DEC) sees the entire snapshot, including Codex parents. Heavy jobs are detected first. Its exact installed CUA node/entry/parent/package/launch identities are checked by five fixed hashes. Service children are classified independently. Opaque Node remains unknown; legitimate preview servers are preserved.
- During this runner's future execution, only its actual launched Process and demonstrably descended retained kernel handles can qualify as its own runtime. Exact pinned parent arguments, one Vitest 4.1.5 forks worker with the existing 512 MiB flags, and up to two exact esbuild 0.27.2 service helpers are the only permitted owned forms. Unknown or excess owned children cause HOLD and cleanup of only that owned tree.
- Parent heap remains 256 MiB; worker heap remains 512 MiB with one worker and no file parallelism. These are configured caps, not measured peak usage.
- A monotonic default 240-second deadline (maximum 600) is enforced by the main loop and an independent in-process compiled .NET timer callback holding only the actual started Process. The callback does not need a PowerShell runspace, create a helper process, or consult reusable peer PIDs. Unsafe observation stops only the launched tree. Individual CIM provider waits use one-second operation timeouts; the source sample timestamps precede observation rather than hiding hash/read latency.
- Runtime resource checks occur at five-second intervals. The exact installed identities remain required. Unknown observation, descendant identity ambiguity, unexpected fork flags or bundle helpers are never treated as permission to proceed.
- Separate stdout/stderr readers drain with finite waits; their completion, actual test exit, gate exit, cleanup, environment restoration and mutex release are recorded. Failed raw outcomes remain evidence. A zero test exit cannot pass without all selected file identities and actual assertion counts/statuses.
- Full before/after inventories enumerate all files under resources/js, resources/css, build and node_modules, not just selected tests or TS extensions. Package/lock/config/runner/classifier/generated config, the six runtime identities, five installed tool identities and existing .env* hash-only inputs are included. Additions, deletions and byte changes all invalidate acceptance. Only generated node_modules/.vite and .vite-temp caches are excluded; the per-revision cache lies outside the source tree.
- A new revision configuration imports the unchanged R1 wrapper and overrides only its isolated cache directory. Original aliases, environment, setup, React plugin, FS policy, fork/worker settings and all six complete suites remain intact. DEBUG_PRINT_LIMIT is the sole changed process environment value and its exact prior state is restored in finally.

## Source-only checks actually performed

The runner, pure-case script and reused classifier parse with zero errors. The finite invocation below completed 66/66 injected source cases:

    & ./storage/logs/hs-overview-recovery-runner-guards-source-cases.ps1 | ConvertTo-Json -Depth 6

This script extracts only explicitly named pure function ASTs and the pinned classifier; it never dot-sources or invokes the main runner. It compiles the .NET deadline delegate with a null Process constant without invoking it or creating a Timer. Cases cover null/unsafe/nonfinite evidence, both observations and stale launch time, heavy/service children, wrong parents/entries/hash drift, opaque processes, previews, owned fork flags, deadline boundaries, full path additions/removals/drift, malformed outcomes, and counts reconstructed from actual injected assertions. Resource/process probes, test children and main-runner invocations were all zero. The 11 fixed installed runtime/tool file hashes were independently read and matched; this is file identity evidence, not process eligibility.

The machine-readable finite receipt is storage/logs/hs-overview-recovery-runner-guards-source-receipt.json. The full pure outcomes are storage/logs/hs-overview-recovery-runner-guards-source-results.json. No historical input/result JSON was relabelled or replaced.

## Next runtime selection and limits

The next selected scope is six whole files: command-centre-hero, analytics-header, incident-record-action-dialog, incident-response-request-dialog, charts-source-state and first-aid-breakdowns. The final two files are justified by post-R4 nullable-state changes. The parent's expected 93 expanded cases is informational; the runner never infers actual test totals from declarations or enforces that forecast. Runtime result JSON remains authoritative.

Actual sampling, descendant kernel-handle behavior, timer scheduling/cancellation, cleanup/pipe drainage, and the real before/after full source audit have not been executed. Full node_modules hashing cost and sampling latency are unmeasured. The bounded source checks do not certify those operating-system paths. The next admitted real run must provide that evidence. No rerun was made solely for the guard repair. No native/database/application/Node/browser/build job was launched here, and no broader programme or query-budget acceptance is claimed. The separately rejected command-write infrastructure remains parked.
