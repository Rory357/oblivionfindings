# HS18 independent review settings and routing recovery

Source-only continuation checkpoint. The complete approved goal is active. Work remains isolated in `codex/health-safety-workspace`; no MAIN write, runtime/bootstrap, migration, deployment, stage, commit or push occurred in this unit. One organisation across approved Sites, current roles and canonical source/privacy remain the boundary.

## Actual settings composition

The human answered “make this a setting” for involved-person read and notification restrictions. The settings page now has an independent-review policy editor inside the existing Incident routing view. It adds no left-navigation destination and uses the existing page shell, connected rail and single six-block clickable meter row. `block_involved_access` is the stated recommended default assumption; `assignment_only` is available. The application default remains visibly unreviewed, with no invented decision-maker or review time.

Two actual routes use the existing dedicated current `healthSafety.settings.manage` guard and independently checked policy service. The shared settings controller eagerly replaces policy, history, current permission, viewer and recovered receipt on partial visits. The session carries only the accepted command UUID; receipt contents are reconstructed under current actor authority. Policy configuration does not grant private incident access, ownership, HR/wellbeing authority or professional approval.

The declaration foundation retains the first accepted policy, including when independent handling is recorded on a saved draft. The UI now says this explicitly. Later organisation settings cannot rewrite existing accepted report protection or reassign its owner. No automatic expiry or access release on incident closure was added. An explicit attributable review-resolution seam remains part of the unfinished full workflow.

## Routing review corrections

Independent review found and root corrected retained drafts crossing an account change, overwritten interrupted request envelopes and an inaccurate warning that clearing triage disabled eligible Site lead/cover routing. Panels now have actor-bound identity. Pending callbacks require an active editor, the current actor/request and current settings access; successful receipts also require matching returned actor/viewer and exact receipt identity. Uncertainty starts at dispatch, disables edits while permitting the original retry, survives access withdrawal, and clears on a definite current validation rejection so the user can correct errors. Cancelling is not presented as saving.

The existing routing HTTP suite's immutable setting audit assertion now uses the actual `audit_id` column. The suite still has 25 declarations, all UNRUN.

## Evidence and limits

Four selected PHP controller/route/test files passed standalone syntax checks at 64M. Six selected TypeScript routing/settings/independence files passed transpilation syntax checks at 128M; semantic types and imports were not checked. The scoped six-file formatting check passed at 192M, followed by successful formatting of the final policy-copy adjustment. Independent read-only review found no remaining concrete defect in this finite settings transport/editor contract.

Routing frontend has 12 panel plus two receipt declarations; independence settings have nine UI and ten whole HTTP declarations. All are UNRUN. Exact 11 selected source pins are in `storage/logs/hs18-independent-review-settings-and-routing-recovery-2026-10-12.json`. Active declaration-foundation files are intentionally not certified by that pin set. A read-only Git whitespace check could not run because Git reported “must be run in a work tree”; separate inspection confirmed the exact managed worktree path and non-bare repository. No whitespace-test acceptance is claimed.

## Continuation

D05 capture/roster, encrypted draft, draft-to-submit/replay, original-reporter receipt recovery and every direct/copied reader and notification consumer remain incomplete. The backend is authoring the foundation and meaningful whole suites. A separate backend agent is extracting the faithful incident register owner filters in one current-read callback; the Control Room hero Site seam and current scoped follow-up staff roster remain explicit gaps.

All existing shared notification, private risk/recovery, typed reminder, Control Room note ownership, specialist register, cross-module, historical native failure/query, migration/rollback, browser/role/responsive/accessibility and applicable provider/hardware gates remain. Workforce remains the shared-runtime coordinator; no H&S slot was admitted. The full HS00–HS27/S01–S21/C01–C30/O01–O16/X01–X12/R01–R10 acceptance is retained. These settings are development progress, not a partial release or completion claim.
