# Prospective risk source binding and business history — review only

State: UNAPPLIED / UNMOUNTED / ALL EXECUTABLE CHECKS AND NATIVE TESTS UNRUN. This is source preparation in the isolated H&S candidate, not an approved partial release. No app, controller, model, migration, shared audit, CR, User, lock, or permission files were changed.

This proposal follows the exact three-file RiskAssessmentPresenter / HsRiskAssessmentService / RiskAssessmentWorkspaceConnectionsService read-context draft. The earlier draft's conservative generic audit exclusion is not the final business-history implementation. The new helper patch supplies the exact private historical acceptance branch; the complete writer/history composition below is a semantic proposal, not a runnable whole-service replacement.

## Actual defects and authority

HsRiskAssessmentService::create currently calls assertContext before insertion, but command hydrates and locks the full risk row before refreshing the actor and admitting its source. updateDraft preserves hs_event_id only for modern FirstAidRecord or unchanged primary assessable; it does not protect either modern or legacy exposure provenance. assertContext accepts Site/Client primary types only, so historical legacy HsEvent morph bindings are not honestly preserved by the current writer path. supersede copies its existing tuple but creates another nested command/read origin.

Every semantic milestone routes through audit(), which writes only business snapshot, note and actor. SNAPSHOT_FIELDS omits hs_event_id / assessable_type / assessable_id. Existing presenter history hydrates meta and actor names before any per-milestone original source admission. Thus today's unrelated or detached parent cannot prove yesterday's private source. No retrospective tuple or milestone certification is proposed.

Existing risk read authority stays hazards.view plus canonical current risk Site/source authority. Existing mutations retain hazards.manage, approved/current internal staff and their independent operation/status gates. The exposure branch additionally requires hazards.view AND hr.wellbeing.view, current canonical internal staff, and original/current active approved Sites and retained linked Incident/Client context. There is no self-read grant and no audit.viewAny prerequisite. Trusted null-actor calls cannot mutate an exposure-bound risk: an identifiable private source requires an actual admitted actor, even if an ordinary old internal risk command permits null actors.

## Affected files and compatibility

1. app/Services/HealthSafety/HsRiskAssessmentService.php: prospective source admission before full risk lock/hydration; preserve modern and legacy bindings; keep one complete current context through mutation, evidence command and strict semantic audit insertion; attach exact source binding to every milestone.
2. app/Support/HealthSafety/RiskAssessmentPresenter.php: replace the earlier draft's generic audit scope with purpose-fixed business-history materialization; original-source metadata before meta/body/actor names; additive integrity envelope.
3. NEW app/Services/HealthSafety/HsRiskAssessmentExposureHistoryProof.php: the retained patch implements the exposure acceptance branch with existing B APIs, no alternative ledger proof or audit permission.
4. app/Http/Controllers/HealthSafety/HsRiskAssessmentController.php: two exact evidence command callbacks must receive and pass the active context and already admitted source binding to audit. Its attachment preflight/body/download and larger register materializers remain independently held composition work; this proposal does not release them.
5. RiskAssessmentWorkspaceConnectionsService.php: prerequisite fourth supplied-context seam from the earlier three-file draft, plus the local legacy Site predicate described below; no global UserSiteAccess edit.

Existing row/detail business fields and history item id/action/title/actor/occurred_at/note/snapshot/legacy remain. Add detail history_state = recorded|legacy_unknown|unconfirmed|restricted|repair_required and history_withheld:int|null. Add each displayed item attribution_state = recorded_business|legacy_unknown and source_binding_state = recorded|legacy_unknown. recorded_business means an existing accepted semantic business entry, NOT independently immutable certification of risk text. Return history=[] with history_withheld=null when current source scope is unavailable; do not turn unavailable private history into an apparent clean zero. For a readable risk, identity-only withheld count may be an actual count; never expose withheld row IDs, actors, timestamps, source/version IDs, notes, evidence names or synthetic milestones. No table/staff names/body snippets in failure reasons.

## Exact future milestone binding

meta.risk_source_binding has precisely schema_version:1, assessment_id:int, attachment:{hs_event_id:int|null,assessable_type:string|null,assessable_id:int|null}, primary:{type:site|client|event|standalone,id:int|null,site_id:int|null,client_id:int|null}, and events:list. An omitted key is unknown, not a known-null association. events entries retain independently role:modern|legacy and event_id; dual provenance has BOTH roles even if the IDs coincide. Class identity is literal class or the registered morph, never basename guesses.

Each event entry retains the exact safe HSE source tuple {source_type,source_id,event_category,site_id,staff_id,client_id,shift_id,asset_id}. No body, severity/status/owner/handover/WorkSafe workflow field is turned into source authority. Only actual identifiable exposure entries add exposure with the exact helper shape:

    {attribution_state:recorded|legacy_unknown,source_id:int,source_version_id:int|null,
     source_revision:int,receipt_id:int|null,source_content_digest:string|null,
     source_tuple:{exposure_id:int,substance_id:int,worker_id:int,site_id:int,
                   related_incident_id:int|null,original_context:array|null}}

For recorded exposure, source_tuple is the exact accepted receipt AFTER tuple, not a reconstruction from current incident fields. original_context is B's exact seven keys schema_version/site_id/incident_id/client_id/shift_id/service_context_id/stay_id, selected only after private authority and original Site admission. Worker is the recorded worker, not risk actor, exposure recorder or audit user. No invented stay column exists on the exposure root; stay is only the explicitly proved retained incident context.

For genuine legacy exposure absent incident, retain source revision0/version/receipt/digest null and original_context null, with legacy_unknown. The new milestone records the observation, not an immutable historical exposure acceptance. A retained nonnull legacy incident with unknown original context cannot produce a readable binding or command. Do not write today's Client/shift into it. A newly retained legacy binding can be re-admitted only while exact source worker/Site/substance and absent pointer remain genuine legacy; later conversion/correction cannot retrospectively certify it.

No source tuple is returned in page JSON; it is internal semantic acceptance metadata. Existing history snapshot whitelist remains business fields only. Snapshot must also retain attachment identity internally, separate from displayed business whitelist.

## Writer protocol — narrow semantic changes, all unapplied

create:
- Establish one fully prepared current callback, preserving independent hazards.manage/current staff gate. The existing complete read keys plus ChemicalExposureCommandAccess::PERMISSIONS are preparation only.
- Validate exact submitted type/id/event tuple. Query only independent candidate HSE identities under current canonical Site before source discovery. Inspect both modern hs_event_id and legacy assessable_type class/morph + assessable_id. Existing Site/Client policy remains independent; legacy HSE is normalized for proof only, not silently rewritten in storage.
- Prove each candidate family using the same active HSE source scope. For exposure, require private gate before source/version/receipt queries, sourceProof plus exact accepted version/receipt proof and known original context.
- Capture the detached binding, then write the draft and strict semantic milestone in the SAME transaction. Never accept a successful risk mutation without its milestone. Reference generation failure/audit failure roll back. Fill assessment_id only from the actual persisted row.

command:
- Select id,hs_event_id,assessable_type,assessable_id only from the exact candidate risk; no title/control/approval/history/evidence fields before source admission.
- Prove current Site/Client/source tuple in one callback. Lock the exact risk with predicates binding ALL original nullable tuple fields; recheck that the locked tuple matches admitted identity before hydrating/mutating business fields. A race cannot substitute a private binding or an unrelated row. A changed tuple causes reload/validation denial, not another actor refresh.
- Keep the same callback through operation and audit. No Builder/model/context is returned from the H&S read callback. Preserve service result compatibility using detached ID/result descriptors; any legacy model-result adapter is internal to the existing writer transaction and conveys no read authority. Controllers must use confirmation IDs only and canonical readers for any facts.
- Existing command closures receive (locked,current,reads,activeContext,sourceBinding); the three old arguments remain in place. Evidence callbacks explicitly accept the final two. No second context in supersede: create the successor using the already admitted tuple/context and keep predecessor and successor milestones atomic, retaining dual provenance.

updateDraft:
- Derive proposed effective tuple without treating omitted fields as a new known-null binding.
- If EITHER admitted modern OR legacy parent is exposure, a requested change to ANY nullable attachment identity is refused with a fixed validation message. Never silently overwrite input as proof of an authorised rebind. The legacy parent must not be removed while modern hs_event_id stays unchanged, or vice versa.
- Preserve existing FirstAid provenance guard and unrelated permissible draft reattachments. For ordinary authorised reattachments, admit BOTH before and after source/Client/Site, retain both acceptance bindings in the draft_updated milestone (meta.risk_source_binding_before and meta.risk_source_binding). Old private exposure cannot be detached through an apparently ordinary new source.
- Source correction is a separate source writer action; it is not a risk detach/backfill or a guessed historical tuple.

audit:
- Require supplied active callback and a validated binding captured in this command. Reject absent/mismatched assessment/tuple binding. Keep existing snapshot,note,actor_id and action/status/NZ date semantics unchanged.
- Append schema1 binding and binding_before when an actual authorised ordinary reattachment occurred, then AuditLogger::logOrFail inside the existing transaction. Actor comes from the freshly admitted command actor. No global logger modification and no generic audit body permission added.
- Apply to created,draft_updated,status_changed,residual_recorded,review_completed,evidence_added,evidence_removed, plus both supersede milestones. Automatic AuditableChanges duplicates are legacy history, not substitutes for strict semantic acceptance.

## Purpose-specific business-history materialization

Entry API proposal is the bounded presenter private history(HsRiskAssessment assessment,User current,CurrentAuthorizationReads reads,HealthSafetyReadContext active):array integrity envelope; default presenter wrapper prepares once and calls it. No additional broad history service file is inferred. No public escaping builder/ID whitelist. Supplied context must be active/same actor/complete existing family+exposure keys; absent keys/wrong viewer/expired context throw, never silently reopen.

1. Requery/admit exact current risk ID with canonical Site scope and final modern+legacy source intersection using independent candidates, before risk history discovery. Keep existing risk view authority; do not require audit.viewAny. Refuse unknown private original context.
2. Build exact auditable_type literal/morph + assessmentId + the existing fixed semantic/legacy action list. Before body/name search or eager user load, enumerate ONLY IDs/action plus fixed JSON source-binding identity metadata. The ordinary branch must use SQL family/type discrimination; a reader without private authority may not select private worker/source/version/incident tuple metadata. No arbitrary meta hydration.
3. For schema1 ordinary bindings, admit original Site/Client and every retained event tuple independently in the SAME callback. Do not use today's unrelated parent as evidence of a historical ordinary association. For an actual reattachment milestone, require both original and resulting associations before showing shared note/snapshot.
4. For exposure, consume strict private staff/Site branch, then HsRiskAssessmentExposureHistoryProof::inContext. Its existing sourceProofForAuditSubject proves the exact historical version's retained acceptance and old Site/context; admitReceiptMetadata supplies the exact original accepted tuple. The helper intentionally never treats returned current-root projection as historical facts.
5. Gate final AuditLog SQL by admitted exact IDs and exact metadata identity predicates (binding digest/fixed canonical comparison) to prevent discovery-to-hydration mutation. This same callback is not enough to assume DB isolation. Revalidate the captured original metadata after row load before displaying any body; do not certify a different persisted revision. Only THEN eager actor names/read whitelisted snapshots/evidence basenames and detached page DTOs.
6. Legacy tuple-less semantic or automatic rows are unconfirmed. If original association cannot be proved, withhold their note/snapshot/name/time; do not substitute current risk's binding. For genuinely ordinary legacy histories, showing the old existing body requires a separately truthful original-association proof; absence of identifiable private pointers in current parent is not such proof. Keep explicit withheld state, not fabricated acceptance.
7. Preserve existing semantic-created versus duplicate legacy-created suppression and exact business titles/date fields on admitted rows. Record actual withheld count only within current readable source scope. If all source scope unavailable, counts null. Existing generic audit exclusion is replaced ONLY for this business-history consumer; shared audit consumers still require their own policies and original provenance gates.

New risk_source_binding paths also need additive recognition in the unmounted ChemicalExposureAuditAccessService shared audit proposal; otherwise future general audit routes could miss historical exposure after a parent change. This is a held dependency, not an authorised edit to AuditLogger/CR/global audit policy.

## Acceptance anchor — OPEN dependency, no invented migration

Exposure version/digest/receipt/original tuple is authenticated by B's existing accepted immutable source and strict audit anchors. That does not independently authenticate the enclosing mutable risk semantic meta.snapshot or authenticate an exposure→ordinary mutation of BOTH risk binding and its local digest. Current risk audit has no second retained acceptance anchor.

The proposal therefore calls ordinary milestones recorded_business, not immutable/verified risk history. A same-meta binding digest is a race/integrity comparison, not an independent tamper-proof anchor. Independently retained risk acceptance (exact audit ID/risk ID/action/actor/business digest/binding digest/prior binding) is an OPEN schema/model/ownership decision. No migration, fake receipt table, signing key, backfill or cryptographic guarantee is inferred. A strict acceptance implementation must resolve this dependency before claiming independent immutable milestone proof. Existing programme remains unaccepted; no broader materializer mounts are authorised by this artifact.

## Complete native verification proposal — all UNRUN

Retain complete HsRiskAssessmentWorkspaceTest and HsRiskAssessmentLifecycleWorkspaceTest, each19 existing declarations at observation, with no filters/removed expectations. Add meaningful actual-source cases, not mocked predicates:
- Genuine typed exposure writer + destination projection, risk create/activate/residual/review/archive/evidence/supersede: each actual semantic milestone retains exact accepted receipt/version/worker/original Site/Client/context. Normal risk viewer without audit.viewAny can read business history when privately authorised.
- Modern-only, legacy-only class/morph, dual same-ID and dual distinct-ID bindings; wrong Client/Site/worker/category/original incident tuple, partial/incomplete candidate cannot widen child/risk denial.
- Every private detach/reattach attempt fails before draft fields/audit/files mutate; omissions do not infer null; ordinary valid reattachment retains both contexts.
- Warm actor dual grant revoke/restore, HR withdrawal/restoration, original Site/Client/incident grants revoked/restored after source advances. No private ledger/body/actor-name SQL or source IDs in general safety responses; restore shows original history only under its original permission.
- Accepted old revision then legitimate source correction: old version/receipt metadata admission uses original Sites/context before private body; today's root proof is not substituted. No-op receipts cannot be invented as typed versions.
- Legacy absent pointer stays unknown, retained nonnull legacy pointer excludes, tuple-less legacy milestone withheld. No-op/read/ordinary draft edit does not backfill source proof.
- Corrupted/missing/rewritten receipt/version/digest/binding, removed modern parent, hidden legacy parent and archived/missing source: withheld/unconfirmed or repair response, never a clean empty0 or fallback user name.
- Source changes between identity discovery and body read; exact predicates and after-load binding recheck prevent stale whitelist resurrection. Wrong actor/expired/unprepared context errors are visible.
- Risk field update/evidence storage/semantic insert failure rolls back acceptance. Future genuine two-process test proves tuple lock/rebind race; no serial fake/native run now.
- Existing unrelated ordinary lifecycle and NZ calendars, semantic creation suppression, Site/Client profile embedding/count/export/read authorities and all original business-history formatting remain full-file coverage. Source costs/pagination/query ceilings unmeasured; historical124/<100 remains unchanged.

No extra test declarations were authored or counted as executed. The proof helper patch is pure source text; PHP parser/Pint/native suite outcomes are UNRUN. B source, ledger, acceptance and evidence remain moving private dependencies until independently admitted full gates.

## Legacy Site predicate dependency found during this review

Actual UserSiteAccess::applyHsRiskAssessmentSiteScopeForSiteIds supports modern event, Site and Client tuples, but no legacy-only HsEvent assessable class/morph. The earlier Presenter::currentAssessment draft and existing Connections::readable call it before candidate discovery; both currently remove legacy-only candidates. Writer assertContext also rejects legacy HSE type. This is a concrete compatibility dependency, not a passing parity result.

Within ONLY those two existing risk-reader scope closures, add an OR legacy branch for exact registered HsEvent type + positive assessable_id whose actual nondeleted HSE Site is in the SAME freshly approved Sites. If modern hs_event_id is also nonnull, require its actual nondeleted HSE Site to equal the legacy parent Site (not merely both approved). Preserve final source intersection across BOTH independent parent identities. Do not grant null Site, resurrect missing/orphan/deleted private parents, or normalize by basename. Local fixed identity SQL shape:

    risk.assessable_type IN (literal HsEvent class, registered morph)
    AND EXISTS (SELECT 1 FROM hs_events legacy
                WHERE legacy.id = risk.assessable_id AND legacy.deleted_at IS NULL
                  AND legacy.site_id IN currentApprovedSites
                  AND (risk.hs_event_id IS NULL
                       OR EXISTS (SELECT 1 FROM hs_events modern
                                  WHERE modern.id = risk.hs_event_id AND modern.deleted_at IS NULL
                                    AND modern.site_id = legacy.site_id)))

The SQL expresses canonical parent identity scope only; it is not private source permission. Exposure/FirstAid/Restraint/Injury source discovery and final complete conservative denials remain independent and callback-bound. Both parent ID subqueries derive from the already ID/filter/Site-scoped risk query. No global helper policy expansion is part of this artifact. Include legacy-only allowed current Site and wrong-Site/dual-mismatched-parent negative cases in both whole risk suites. The protocol is held for root semantic review before any additional compatibility patch is mounted.
## Exact legacy writer branch (same callback, unapplied)

Extend assertContext's proposed signature with REQUIRED HealthSafetyReadContext active, threading that exact object through create/command/updateDraft/supersede and both evidence command audits. No default or alternate fresh resolver is permitted in this writer branch:

    elseif (in_array($type, array_unique([HsEvent::class, (new HsEvent)->getMorphClass()]), true)) {
        $assessableSite = $this->sourceEventSite($actor, $id, $active);
    }

sourceEventSite is the earlier draft's scalar exact-ID resolver using the supplied context and current approved Site prefilter BEFORE source discovery. Modern hs_event_id resolves through the SAME method with the SAME active object; both parent Site values must match when nonnull. Literal/registered-morph assessable_type and its actual ID are retained exactly as persisted. This branch is part of the complete writer protocol above; it cannot be mounted alone while old three-argument origins or nested supersede still remain.

Actual whole-suite extensions must use genuine retained legacy assessable_type=HsEvent class/morph with no modern pointer, and dual pointers to actual distinct HSE records. Do not forge null Site or infer a Client tuple from a related incident. Cover approved same Site positive, Site withdrawal/restoration, dual different Sites (even both approved) denied, modern or legacy exact parent/source missing/archived, dual source-type/category/worker tuple conflict, partial supplied candidates and HSE permission/private withdrawal. Every denial is before full risk fields, audit meta, names, counts and evidence bytes; every restore uses current source proof and original immutable private acceptance. Existing legacy identity remains unchanged after allowed lifecycle commands.