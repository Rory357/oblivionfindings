# Chemical exposure reported facts — unapplied source proposal

2026-10-12. SOURCE ONLY / UNAPPLIED. The product choice between optional Unknown and required Yes/No is pending. Unknown is the provisional recommendation. No application, migration, test, browser, worker, provider or other runtime check was run. No live PHP/TypeScript, old migration, HSE/risk/body-lineage/shared audit/notification source was changed. This is a complete change proposal, not a ready or partially accepted runtime package.

## Current evidence and actual contradictions

- `ChemicalExposureSourceService.php:48` explicitly defaults both flags to false on capture; values693–694 reject null. Values704–709 overwrite the attention flag from a submitted treatment category, including when that flag was omitted. Thus treatment-only first_aid/none correction can replace retained Yes with No. Boolean-only Yes correction on a retained first_aid category currently passes backend validation because only submitted fields are compared; the frontend rejects that same combination.
- The March source migration108/110 defaults both columns to false. The June treatment migration comment describes the legacy attention flag as derived. Historical 0/1 cannot prove explicit user input. Current source schema1 proves acceptance of a source snapshot, not that every field was explicitly reported. Neither the original UUID fingerprint nor the receipt reconstructs input-key presence. No backfill should guess it.
- `HS18-SOURCE-CONTINUATION-2026-10-12.md:119` states: "An unanswered Boolean is not a recorded No." The capture form currently starts both fields blank but forces Yes/No; treatment selection also sets attention. The private readers cast both flags with `(bool)`, which would turn a future null back into No.
- Installed `HasAttributes.php:848–855` preserves null for primitive casts. Existing Boolean casts need no replacement. `ChemicalExposureLedger::snapshot` covers every model attribute except timestamps; adding root provenance columns/defaults would make existing accepted root snapshots differ. Avoid that unnecessary compatibility break.
- `ChemicalExposureHsEventDeliveryService.php:337–344` prioritises category: death Critical; hospitalisation/medical High; first_aid Medium; none Low; absent category attention Yes High, otherwise Medium. An independent Yes plus first_aid/none therefore has a materially different existing response than Yes with no category. High also sets investigation_required. This is a response-policy decision, not a Boolean validation problem.
- `ReadService.php:91` and `WorkspaceService.php:67` count raw attention=true with outcome SQL NULL. Those raw values include historical derivation. Blank/whitespace outcomes are another existing inconsistency; this proposal does not silently rewrite them or change outcome-completion rules.

All statements above describe repo behaviour. The June migration's legal comment is not treated as an independently verified legal threshold, and this proposal makes no legal, diagnostic, treatment, competence, fitness or WorkSafe determination.

## Smallest schema and immutable storage

Reserve, subject to review, `2026_10_12_200600_add_chemical_exposure_reported_facts.php`. Filesystem observation found no 2006* migration and this exact path absent. That observation is not an allocation lock or an applied migration.

The candidate schema changes only the existing medical_attention_sought and incident_reported columns to nullable/default NULL. Retain every existing 0/1 verbatim. No root provenance columns, tenant context, new fact ledger, retrospective certification or data migration. Existing nullable medical_treatment category stays unchanged. Down refuses before any ALTER when either flag is null on any row including soft-deleted rows, or any retained source version contains the reported_facts key, even if its value is null/malformed. If meaningful new contract evidence exists it must not revert to the old implicit-No schema. A companion unapplied schema patch contains this candidate only; it MUST NOT be adopted separately from validators, provenance and projections.

Use the existing immutable `ChemicalExposureSourceVersion.content.facts.reported_facts` with exactly these keys:

```text
{
  schema_version: 1,
  medical_attention_sought: Entry<boolean|null>,
  incident_reported: Entry<boolean|null>,
  medical_treatment: Entry<none|first_aid|medical|hospitalisation|death|null>
}
Entry = {
  value: exact stored scalar,
  origin: reported|reported_unknown|unanswered|legacy_unconfirmed,
  reported_in: null | {
    intent_id: positive integer,
    revision: positive aggregate revision,
    actor_id: positive integer,
    worker_id: positive integer,
    site_id: positive integer,
    substance_id: positive integer
  }
}
```

The type/list/object shape is closed. No arbitrary snapshots, IDs inferred from names, medical narrative, copied Client/file content or current actor substitutions. reported requires a nonnull correctly typed value and reported_in. reported_unknown requires null and reported_in; it means an explicitly submitted Unknown, not a recorded negative. unanswered requires null and no reported_in. legacy_unconfirmed retains the old scalar privately with no reported_in. These entries are never put in the generic audit body, notifications or public chemical register. Existing source_content_digest and strict accepted audit bind the complete private version contract; no additional generic audit metadata key is needed.

## Prospective transitions and proof API

Proposed pure helper `ChemicalExposureReportedFacts` owns closed-shape/type validation and transitions only; it confers no permission and does not query models. Its concrete public design is:

```text
capture(storedFacts, providedFacts, acceptedIdentity): array contract
transition(priorContract, beforeFacts, afterFacts, providedFacts, acceptedIdentity):
  {contract: array, provenance_changed: boolean}
project(contract, currentTuple):
  {medical_attention_sought: boolean|null, incident_reported: boolean|null,
   medical_treatment: category|null, fact_states: fixed three-field scalar map}
```

Only the three reviewed keys enter providedFacts, using array_key_exists, not isset. acceptedIdentity is the already current-authorised claimed intent + new aggregate revision + actual actor and canonical worker/Site/substance tuple; the helper cannot invent it. Raw storedFacts are the same accepted model snapshot. A missing old contract is legacy_unconfirmed for each existing scalar regardless root source_schema_version; a present null/malformed contract is repair, never a legacy fallback.

Capture uses null defaults. Every supplied independent answer is stored exactly: Yes, No, or provisional Unknown. Treatment-only capture records the category and leaves omitted attention Unknown. Incident-report flag never comes from related_incident_id or an HSE destination. Future timestamps/clinical authority behaviour do not change.

Correction omission preserves both exact scalar and original entry, including Unknown and origin. Explicit category updates never update the attention flag. Explicit Unknown clears only the named scalar and keeps its former value in immutable before history. Supplying a same-value formerly unconfirmed answer is a genuine provenance correction: aggregate advances once, new version/strict audit/receipt/delivery are required. Repeating the same already reported answer without another changed fact remains the existing allowed correction no-op with null source_version_id. It retains the original field actor/evidence and does not certify anything new. A no-op on legacy narrative never creates a reported_facts contract.

Every genuine later child write carries the effective unchanged fact contract into the next aggregate version; the reviewing/assigning/uploading actor cannot become the historical reporter of inherited fields. Central command() must compare source dirtiness OR provenance_changed before deciding no-op, then save once and append the contract in the same existing transaction. Create() supplies its contract to ledger.version. Only correct_exposure receives input presence for these fields; review/follow-up/evidence cannot manufacture it. Input presence remains inside the immutable fixed contract, not new transport or receipt fields.

Proposed same-active-callback method on Source:

```text
reportedFactsForSource(root, current, reads, sites): detached projection
```

It must independently admit the exact root/current original context, prove the SAME root snapshot with currentVersion, and validate the version contract against root_after. It admits each referenced original intent/revision's existing acceptance metadata BEFORE any historical version/receipt body, verifies exact receipt/audit source_content_digest + command/actor/tuple/field evidence, and derives recorded_at only from that original accepted version. It cannot reinterpret a current root proof as historical permission. No nested fresh viewer, escaped models/reads/builders, loose current Site fallback or metadata-only admission as body permission. An identity-only search for any earlier contract prevents stripping the latest contract and returning to legacy_unconfirmed. A contract inheriting a reported entry must match the originally accepted entry; entry deletion or swapped evidence is repair_required.

Worker/Site/substance correction does not relabel inherited field evidence. Preserve the original private entry; projection reports prior_context and current answer Unknown until the user explicitly re-reports that fact against the corrected canonical tuple. An explicit same-value reaffirmation then constitutes provenance_changed. This conservative correction rule requires parent review; it avoids attributing old reports to a different worker without an action. It does not unblock forbidden rebinding when retained child/evidence exists.

The already prepared original-body lineage guard remains mandatory: a known linked legacy-before origin with unknown original context stays sealed even after a later acceptance supplies current association, fact confirmation or destination marker. This fact contract cannot be an ordinary correct() recovery bypass. Genuine unlinked legacy facts remain readable with unconfirmed attribution. A's separate200500 later-review case remains distinct.

## Validators, transport and frontend

Under provisional Unknown, use sometimes+nullable+boolean for the two fields; ChemicalCommandValues already strictly normalises Boolean scalars and preserves null. Remove only the category-to-attention derivation/conflict block. Keep exact category enum, all privacy, original association, current staff/Site, instant, strict unknown-key, UUID/revision and audit/save rules. With required Yes/No product selection instead, only new-capture validation changes to required+boolean; historical Unknown still exists and correction omission must remain possible. It cannot validate historical unconfirmed values into No.

Create payloads contain explicit selected answers or omitted/null Unknown. Correction transport must include a flag/category only after the user changes or explicitly confirms it. Prefilling an old value and serialising every field is not evidence of re-reporting. Keep unchanged timestamp omitted as root's current fix does. Stale/current refresh retains drafts and confirmation choices; it must not automatically resubmit displayed historical values under a new UUID. Remove frontend mutual-agreement validation and treatment selection's attention assignment. UI labels distinguish care sought, recorded treatment/outcome category, separate incident reported and Unknown/unconfirmed. No diagnosis or professional validation claim.

Public acceptance remains the existing twelve-key receipt; no flags, clinical facts, provenance, names or additional accepted field enters it. Original capture-only receipt recovery keeps minimal actor/source/intent/audit-bound acceptance under original current capture authority. It does not invoke saved-private reportedFactsForSource, expose a saved DTO, or expand a reporter's grants.

## Private DTO and counts

New saved-private record fields: medical_attention_sought:boolean|null; incident_reported:boolean|null. The top-level values are only current-context explicitly reported answers. medical_treatment remains the historical recorded category or null for parity, accompanied by provenance; it is not described as independently assessed harm.

Add a fixed fact_states map for the same three fields. Each read entry is `{state: reported|reported_unknown|unanswered|legacy_unconfirmed|prior_context, recorded_value: scalar|null, reported_at: UTC instant|null}`. recorded_value preserves the old private data visibly labelled unconfirmed. No per-field reporter ID/name is needed in this bounded DTO; existing accepted history independently owns admitted actor attribution. Repair yields the existing unavailable/repair envelope rather than unknown answers or fake zero. The map is available only after complete saved-private source/original-context proof. Index, detail, current-check JSON and old safe aliases must use the same same-model projection; no second unproved root fetch.

Existing awaiting_medical_outcome retains a narrow meaning: explicitly reported current-context attention Yes AND the existing outcome-null condition. It excludes Unknown/unconfirmed/prior_context without pretending those records have a No. Add attention_unknown only if parent approves a separately labelled count; all such aggregates require exact eligible original-context/fact proof before their private predicates and final count query. No private global scan, unchecked SQL root booleans or page-only proof may certify a full collection count. Any proof damage makes affected aggregate unavailable/null, not zero. A's collection proposal and the permanent index both need this helper/predicate integration; their existing unknown-ID same-statement guard and filters/pagination remain. The raw model requiringMedicalAttention scope can remain a legacy stored-fact utility, but cannot supply an accepted reported-answer count.

No new diagnosis/outcome is inferred from reviews, treatment category, flags, completed tasks, notification read or incident association. Pending medical outcome is a recording state, not a care instruction. Empty/whitespace outcome counting is a separate concrete decision; preserve the current NULL rule until reviewed.

## Response classifier: required parent decision

Treatment category and attention answer must be independent inputs. A Yes+first_aid report is possible: attention was sought while only first aid is recorded so far. Yes+none is also a legitimate reported pair requiring review, not automatic treatment or harm. A reporter may not know whether attention was sought even when another record states hospitalisation. Preserve those submitted facts rather than force agreement.

Recommended prospective classifier returns scalar purpose-fixed `{reported_attention:yes|no|unknown, recorded_category:category|null, category_state:reported|unconfirmed|unknown|prior_context, response_floor:low|medium|high|critical|null, basis, needs_review}`. It is a response review aid; reported category is not an assessed diagnosis/degree-of-harm certificate. Nonexistent category/Unknown cannot become assessed no harm. Existing category priorities can remain reported operational floors only when their field has valid current-context reporting evidence. Existing raised HSE severity, investigation history, WorkSafe, owner/handover and closure must never be lowered or overwritten by this helper.

Two concrete decisions are unavoidable before root changes its destination classifier:

1. For Yes+first_aid/none, either keep category Medium/Low and separately flag care-response review, or give a High review floor. High currently also requires investigation_required. The proposal recommends preserving the existing category floor and a clearly separate review-needed state rather than silently introducing a new investigation rule. Attention Yes with absent category currently gives High; changing that case requires a deliberate reviewed policy too.
2. When both category and attention are Unknown/unconfirmed, no harm-based response floor is known. A newly created HSE still needs its actual nonnullable severity. Retaining the existing Medium default must be labelled operational triage pending review, not known Medium harm. Never invent Low/no harm or WorkSafe acceptance. A marker bound to an earlier default/category must not be rewritten into a clinical assertion; future destination changes need exact revision/digest and existing marker proof.

No classifier or HSE model/service change is part of this proposal artifact. Root owns that source and decides the operational rule; the source fact repair does not grant closure, release, clinical approval or eligibility authority.

## Complete verification package to author after policy/API review

These are required real cases, not created test methods or executed case counts. No new source test file has been declared by this proposal.

- Actual capture Yes+first_aid, Yes+none, No+medical and Unknown+hospitalisation preserve independent inputs; omitted flags remain null, explicit No remains false, category omission stays unknown.
- Current create-only actor submitted medical details/Unknown receipt and uppercase-key replay remain exact/minimal; enduring saved read/correction/evidence denied; current capture/Site withdrawal denies recovery.
- Actual correction treatment-only preserves prior Yes/evidence; omitted attention/incident/category preserve exact values; explicit Unknown changes only its named fact; invalid arrays/text/unknown keys refuse before any write.
- Actual legacy 0/1 and pre-contract schema1 capture/typed narrative correction remain legacy_unconfirmed. Later child command does not certify them. Known linked-unknown original lineage stays sealed despite explicit reporting.
- Same-value explicit legacy confirmation makes one changed revision/anchored version; same reported value with identical intent is no-op; genuine narrative no-op creates no contract; repeated exact UUID is one acceptance; changed Unknown/No intent under old UUID refuses.
- Original reporter field evidence survives another actor's review/follow-up/evidence/medical-outcome command; unchanged aggregate child facts cannot copy child recorder as reporter.
- Worker/Site correction keeps original evidence private and reports prior_context; explicit reaffirmation against new tuple binds new evidence. Original Site/Client withdrawal refuses historical-body/provenance loading before private SQL. Existing typed child rebind refusal remains.
- Actual audit/save/version/receipt veto atomically rolls back field confirmation, root revision, intent/version/outbox; no second revision after retry; concurrent independent fact corrections produce one winner/stale loser under existing lock and intent rules.
- Corrupt field type/map/entry/evidence, stripped latest contract, swapped intent/actor/tuple, locally rewritten map+digest without original audit anchor and lost accepted version all repair; restoration proves real positive path.
- Private index/detail/current JSON show Unknown/unconfirmed and raw recorded values truthfully; absent wellbeing/HR/source/Site permission triggers no private fact SQL/labels/counts. Medical counts include actual reported Yes only, and unknown/repair do not mint No/zero; off-page damage and post-discovery changes remain final-query guarded.
- Migration preserves 0/1 and accepted old snapshot proof; future raw insert defaults NULL; empty revert succeeds only with no meaningful new fact evidence; null flag or present malformed contract refuses destructive down before any ALTER, including soft-deleted sources.
- Root-owned whole destination suite covers all response pairs under the explicitly chosen policy, raised severity/investigation/WorkSafe/closure preservation, unknown triage and marker/audit tampering. Never assert delivered from source acceptance/outbox state.

Existing complete suites requiring review, not partial filtering: ChemicalExposureSourceCommandTest (especially23 and83–86), ChemicalExposureSourceMigrationTest, ChemicalExposureReplayPrivacyTest, ChemicalExposureLifecycleTest, ChemicalExposureConcurrencyTest, ChemicalExposureWorkspaceReadTest, ChemicalExposureCollectionAdmissionTest, ChemicalExposureRootBodyAdmissionTest, ChemicalExposureHsEventDeliveryTest, ChemicalExposureWorkspaceControllerTest and HazardousSubstanceControllerTest hospitalisation assertion285. All remain UNRUN under hold. Old assertion failures/legacy public alias behaviour must not be silently reported green.

## Ownership and open integration

Backend owner can implement the helper/Source/prospective migration/whole source tests after this proposal is reviewed; A owns reader/collection/projection and recovery, root owns UI/transport mounts/HSE classifier/shared origin consumers. No live mounts, grants, default seed, shared AuditLogger/risk rule, MAIN/Workforce or source-family HSE patch was changed. Body-lineage/HSE proposals stay source-stable; their dependencies and genuine linked-legacy repair workflow remain open.

The accompanying schema patch is only the exact conditional DDL candidate. It is not sufficient to apply the behaviour and must remain unapplied until the whole provenance/DTO/validator/count/frontend/classifier package is coherent. Latest source hashes are recorded separately as observations, not a final freeze or runtime acceptance.
