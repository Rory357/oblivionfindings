# HS18 exact follow-up service and care-review UI — R2 source delta

This additive source delta follows [the reported-read composition](HS18-REPORTED-READS-AND-FOCUS-COMPOSITION-2026-10-12.md). It preserves that observation and supersedes only affected current pins; neither document is a freeze or runtime result.

Root reviewed A's complete focused-child proposal and composed its seven Workspace hunks. Actual Workspace bytes now match the pure projected SHA 9CA5CFCED9D6CB0F2D88511D21A4EB6ED35B7F2343777C4D1B39052711DF1D7F. Its additive detail selector resolves an accepted exact child to the actual descending-ID page. Final selection uses one statement tying the exact child's raw facts and its current page interval together; no separate final rank/count observation supplies focus. The original whole 19-method suite includes actual insertion/deletion and case/trailing-space changes at the final query boundary. Every test remains UNRUN.

The frontend uses that server-confirmed returned child and page. A missing confirmation focuses the plain unavailable-selection explanation, rather than selecting another row. Read-only entry opens no command automatically. Completion/transfer entry keeps the returned page and independently bounded Back. Selection never creates action authority.

The proved response DTO now supplies a visible Care answers need review message on the recorded-facts section. An authorised current reviewer can enter the existing inline review directly. A write-permission withdrawal disables the retained draft while private reading remains independently permitted; private-source withdrawal withholds it. This does not change the reported answers or certify a medical outcome, and a recorded review does not clear unknown facts automatically. Shared semantic status, type and button primitives are retained.

The companion JSON records nine exact files, including the complete focus suite and complete frontend panel/workspace/overview suites with 8/20/6 declarations. Declaration counts are not executed cases or passes. The earlier delivery and reported-reader unit observations remain historical and unchanged by this delta.

Canonical root/child metadata lineage is still a hard prerequisite: a typed child rebound and downgraded to zero markers must not look like genuine unversioned legacy work. B is preparing the canonical Source guard including retained receipts; root will compose narrow Workspace preflight calls after reviewing that API. A is preparing the corresponding Evidence removal/download/replay consumers. Until those checks and guarded HTTP are composed, the focused method's existence does not enable task links or certify the journey.

C's finite Tasks/combined notification proposals remain UNAPPLIED; historical reported-origin acceptance/graph guards and their same-statement membership closure remain prerequisites to those consumers. The CR adapter extraction belongs to its owner review. Typed private overdue reminders, the rejected private risk/recovery seams, all existing full-scope integration and test gates remain open. No source-only change is being offered as a complete release; the approved goal remains active.

