# Source checkpoint: submission routing and private follow-up Tasks

Status: SOURCE_ONLY_UNRUN_NOT_FROZEN. One organisation across approved Sites. This checkpoint preserves the complete release scope; it is not acceptance or release evidence. MAIN, peer previews and shared runtimes were not changed.

The latest coordinator correction permits reversible owned integration and bounded file-only syntax checks. Workforce still coordinates the next shared native/runtime slot. Historical blanket hold wording is superseded by that correction. No native tests, database/migrations, browser journeys, production deployment, commit or push occurred in this unit.

## Actual source composition

- The incident journey stages routing for newly created submitted models, explicit draft submission and new/draft reports submitted from an existing alert. The routing intent belongs to the report transaction; consumption runs after the physical outer commit. A failed routing consumer reports the error and retains the committed report/intent. Fresh historical models used for repair/closure do not imply a new submission. Both report submission and standalone draft submission pass the explicit transition flag.
- The submission hook depends on the backend's initial-only staging successor. Named and previously assigned records must not consult recipient/configuration eligibility or create replacement work in the source transaction. Replacement recovery is separate postcommit work. Scheduler/settings/UI/filter integration remains required.
- Owner editing now retains a stable request key for unchanged retries, creates a fresh key after changed payload, and confirms saves only from the exact incident/request/revision/person history receipt. Access withdrawal disables nomination/submission and restoration requires fresh eligibility and explicit selection. Rory typography, focus and touch patterns are used. Nine authored UI tests remain unrun.
- Private follow-up destination and delivery admission check source identity before body. The final Task and notification admission SQL excludes late foreign root and child version/receipt bindings, matching canonical source lineage. Current consumer paths are pinned in the companion JSON.
- The approved Tasks mount is only the existing provider registry entry plus its explanatory comment. All existing permission vectors stay unchanged; their current 37-key union already includes the chemical family's 13 keys. Generic Tasks cannot complete or modify these private source records; links remain unavailable until focused private transport is mounted and verified. The generic overdue command excludes this family so that typed source reminders can be implemented with their own immutable acceptance and preferences.

## Verification and honest limits

Exactly three root submission files passed standalone PHP syntax checks with a 64 MiB ceiling and no bootstrap. The new complete submission suite has five authored physical-commit cases: commit timing, rollback, historical repair, absent configuration and quiet draft submission/replay. These cases are UNRUN and require the explicitly admitted isolated MySQL test schema. Syntax checks do not prove container resolution, SQL semantics, locking, authorization, migration safety, query cost or browser behaviour.

The broader eight-file Tasks permission-vector proposal was rejected by automatic review. It was not retried or mounted. Independent review proved those additions unnecessary; the distinct two-line registry-only alternative was subsequently approved and mounted. This resolution does not grant authority for the held extra private risk/audit recognition or sealed recovery-picker proposals.

The ordinary audit R2 successor remains unmounted. Independent review found an omitted Always wrapper for HR log rows, canonical source validation aborting healthy neighbouring rows, and incomplete final exclusion of newly foreign-parent retained identities. The backend agent is preparing bounded corrections before composition. The separately proposed three audit route delegations still need owning allocation. Existing audit grants and independent HR authority must remain enforced on current evidence.

## Required continuation

Finish and review initial-only routing staging, owner replacement recovery, durable scheduler hooks, scoped settings/cover/triage UI, current owner filters and the explicit independent-manager concern workflow. Complete ordinary private HTTP and audit integration, typed reminder policy/preferences, the five shared notification consumers and Control Room owner review. Keep all remaining specialist, cross-module, provider/hardware, native failure/query, migration/rollback and actual browser/role/mobile/accessibility gates visible. There is no partial release or silent deferral.

Companion pins: storage/logs/hs18-routing-submission-and-private-task-composition-2026-10-12.json. Earlier checkpoints remain historical and unchanged. Active backend agent files are deliberately not certified by this root pin set.
