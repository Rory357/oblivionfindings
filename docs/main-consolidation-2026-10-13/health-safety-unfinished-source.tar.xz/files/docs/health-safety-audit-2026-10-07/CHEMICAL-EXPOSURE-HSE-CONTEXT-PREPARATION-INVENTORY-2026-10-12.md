# Exposure H&S current-context preparation inventory — 2026-10-12

SOURCE READ/HASH ONLY. No production/test source edits from this inventory. No PHP, syntax, Pint, native, database, process/resource or browser checks. No freeze or admission. Root owns mounting; CR consumer files require their owner's allocation. Current private writer200200/no-op receipt seam and destination200300 remain unfrozen dependencies.

## Required prepared capability contract

The saved source projection prepares `ChemicalExposureCommandAccess::PERMISSIONS`, not only ChemicalExposureAccess's narrow private reader keys. The actual current union is hazards.view/create/manage, hr.wellbeing.view, healthSafety.viewAllSites, incidents.viewAny/viewAssigned, hr.cases.view, clients.viewAny/viewAssigned, clinical.accessAllSites, sites.viewAll, respite.viewAny. It is preparation, not a grant or a new operation permission. Linked sourceProof consumes fresh incident/Client/original-context evidence; the public audit service additionally prepares audit.viewAny and the two existing BoardPack keys. No self, creator, recorder or clinical fallback is admitted.

The proposed family intersection reaches every supplied HSE read scope even when a particular independent candidate contains no exposure. Existing contexts therefore need the complete source union before first materialization, or an explicit family intersection must independently prove absence without querying private rows. Do not silently create another callback on missing preparation. Wrong viewer, inactive physical connection, expired context and intentionally insufficient preparation remain errors. Use the same current actor/reads/context and independent already-filtered Site-scoped candidates, keep final complete identity denial (including withTrashed, modern and legacy risk bindings) and materialize before callback exit.

## Existing HSE-capable context origins requiring additive preparation

For each row, the minimal source proposal is import/reference ChemicalExposureCommandAccess and spread its PERMISSIONS into the named EXISTING preparation union. Retain every original key and every source/module check; no policy or grant edits. The last column names the actual downstream consumption, not inferred authority from method names.

| Current file / source location | Existing origin | Required downstream context |
|---|---|---|
| app/Services/HealthSafety/HsEventAccessService.php:272 | public canView absent-context union | Exact-ID canonical current HSE scope, all source families. Root-owned family patch must include this origin, not just scope methods. |
| app/Services/Tasks/TaskAggregator.php:183,464,637 | findItemFor / sourcesFor / healthSafetyProviderPasses unions | Exact contextual lookup, feed/search and navigation. sourcesFor itself stays permission-only, no task/child/source loads; matching preparation remains consistent. Supplied context must satisfy the full union; no refresh fallback. |
| app/Services/Tasks/Providers/HsEventProvider.php:50 | standalone authorizedTasks union | Existing current canonical Site-prefiltered candidate, exact ID/search/include_done and final source scope. |
| app/Services/Tasks/Providers/HsInvestigationProvider.php:51 | standalone authorizedTasks union | Independently child-filtered parent candidate, source scope before child prose. |
| app/Services/Tasks/Providers/HsCorrectiveActionProvider.php:55 | standalone authorizedTasks union | Independently child-filtered parent candidate, source scope before child prose. |
| app/Http/Controllers/HealthSafety/HsEventController.php:790 | detailReadPermissionKeys | Origin consumers at220(index detail),392(show detail+same-context nav),1466(action detail). Preserve all procedure/drill/closure keys. Same supplied context reaches sourceForReview and task navigation; do not add separate actors. |
| app/Services/HealthSafety/HsVisibilityService.php:42 | forEvent preparation | Fresh readable summary/detail/action callbacks, IncidentJourneyPresenter and AlertWorkspace wrapper composition. Keep compliance.view separate operation proof. |
| app/Services/HealthSafety/HsDashboardService.php:504 | siteComparison preparation | Readable HSE count candidate at527 inside current callback. No change to independent public hazard scope. |
| app/Support/HealthSafety/SafeWorkProcedurePresenter.php:269 | reviewRequests preparation | Requested-version/audience proof, independent exact source event and Tasks exact-action lookup in same callback. |
| app/Support/HealthSafety/RiskAssessmentPresenter.php:172 | siteScopedPickers preparation | Current approved Sites+bounded event picker scope at198, scalar projection then existing collection wrapper. |
| app/Services/HealthSafety/HsCorrectiveActionWorkspace.php:27 | forViewer preparation | Exact action current approved parent scope at35 before eager action/event/owner fields. |
| app/Services/HealthSafety/RiskAssessmentWorkspaceConnectionsService.php:117 | permissions(), origins35 and114 | Current readable risk scope141 includes both candidate bindings; exact event scope67 and exact Tasks lookup146. |
| app/Services/Sites/HazardWorkspaceConnectionsService.php:41 | forViewer preparation | Current hazard/module/Site proof, event candidate scope68 and same-context Tasks. |
| app/Services/HealthSafety/FirstAidSourceProjectionService.php:146 | sourceForReview standalone preparation | Exact canonical FA parent/subject tuple then HSE scope135. Supplied parent is HSEController's detailReadPermissionKeys; both origins require preparation. |
| app/Services/HealthSafety/FirstAidConnectionsService.php:103 | readPermissions(), origin31 | Existing canonical FA read then HSE scope64 and exact Tasks72. Retain independent incident/CR/medication keys. |
| app/Services/HealthSafety/EmergencyDrillConnectionsService.php:111 | readPermissions(), origins30 and90 | Drill HSE scopes40/100 and exact finding action Tasks102; no change to drill's NZ due semantics. |
| app/Services/HealthSafety/LoneWorkerSessionConnectionsService.php:106 | readPermissions(), origin29 | Canonical session/alert proof, HSE scope67, exact Tasks94. Retain all existing independent destination keys. |

This is 17 distinct existing production source files with HSE-capable preparation origins, including the already root-owned HSE family file. Current contextual provider methods do not create another context; their original prepared caller obligations must remain visible.

## Supplied-only and indirect consumers (no new local context inferred)

- app/Services/Tasks/IncidentJourneyTaskContext.php:56 passes its optional supplied context into canonical HSE canView. Actual three HSE task providers supply their existing current context. Unrelated incident/CR viewers keep original independent policies. No union belongs inside this projector; fix its actual origins above.
- app/Services/HealthSafety/SafeWorkProcedureAccessService.php:215 assertSource and236 sourceCan pass optional context to HSE canView. ProcedureReviewRequestProvider contextual execution receives the TaskAggregator context; SafeWorkProcedurePresenter has its own origin above. The standalone Access wrapper uses raw CurrentAuthorizationReads; default HSE canView creates its own current callback. No blanket addition to every procedure-only read is justified.
- RiskAssessmentWorkspaceConnectionsService::nextForViewer(:97) can receive the existing context from forViewer or creates the permissions() context. RiskAssessmentPresenter::toArray(:56) takes the public path. Both use the same named preparation seam above.
- ControlRoomGovernanceReadService::forAlerts(:30/48) accepts optional context but creates none, and current AlertWorklistPresenter(:23) invokes it without context. CR owner must allocate its actual materializing caller/creator and pass the canonical full union. Updating an unused optional union inside this service alone cannot protect its current public path. Do not change the CR raw-model collection contract under this inventory.
- ControlRoomSourceContentService::restraintForAlert(:29/56) only consumes restraint source proof today. An exposure addition is a separate CR-owned source consumer; it must pass the same correctly prepared callback and materialize a detached disclosure envelope before copying/search/history.

## Actual standalone/default-builder consumers requiring mounted-family compatibility

These current consumers do not supply HealthSafetyReadContext. Adding a local permission union is insufficient because there is no local origin. The minimum shared family patch must preserve null-viewer conservative denial, current module/Site proof, independently executable candidates and final SQL correlation for every existing public scope path. For one-callback end-to-end freshness, allocation must cover the actual count/list/export/materializing caller, not a returned Builder or a body sanitizer after hydration. Preserve existing module route policies and genuine command authority.

- HsDashboardService:588 risk source scope,655 event scope,705 child whereHas; HsAnalyticsService:1084 child whereHas; HsKpiService:516 child whereHas; HsModuleSummaryService:199 event,215 child,226 risk,254 child whereHas. The last four already pass independent candidates from their filtered rows. No global private model scan or correlation stripping.
- HsGovernanceService:382 risk,400 event,443 correlated child; HsComplianceExportService:199 eager investigation relation,284 exact event filter,311 risk,399 event,442 correlated child. Preserve BelongsTo->getQuery(), complete export filters/rows/counts and exact predicate order. Returned query helpers need materializing caller coordination before a new active-context parameter is used.
- HsEventController:288/1629 source scopes have optional contexts;1385 notifiable count and1551 correlated action source path currently omit context. The detail origins are covered above; register/count/action list scope alone must not leak source IDs from a finished callback.
- HealthSafetyDashboardController:141 last notifiable source; HsInvestigationController:285; HsCorrectiveActionController:275; HsCorrectiveActionEvidenceController:193; HsRiskAssessmentController:405/425/436; HsWorksafeDecisionController:38. Keep record/module policies, exact filters/IDs and evidence current parent proof before body; these are root/shared controller allocations, not this subagent's files.
- SiteProfileSafetyPresenter:78 current Site risk list; ClientController:1333 canonical Client profile risk list. Preserve current Site/Client policy and modern/legacy identity binding. Ordinary profile or Client authority is not private wellbeing authority.
- StoreHsRiskAssessmentRequest:35 duplicate/read source check; HsRiskAssessmentService:259 selected source event. The latter currently starts HSE scope from HsEvent::query() then applies find(eventId): independent exact-ID candidate must precede materialized private discovery. Do not rewrite approved command/writer policies as a read inventory fix.
- HsCorrectiveActionOwnershipService:189 canonical standalone parent scope. EmergencyDrillAccessService:146 and EmergencyDrillService:218/370 call default HSE canView; root HSE fresh public wrapper handles preparation, while service's own command transaction/actor remains independent.
- InjuryConnectionsService:45 and RestraintConnectionsService:97 invoke default canView from their existing source CurrentAuthorizationReads callbacks. They do not supply HealthSafetyReadContext. A same-read integration requires explicit source-Access/caller allocation; do not blindly expand Injury/Restraint-only APIs to authorize exposure or start an escaped context.
- LinkedOperationalEvidencePresenter:155 default HSE canView; IncidentJourneyTaskContext public null-context path as above. Module/alert visibility does not prove private source body.

CR-owned standalone/correlated files: AlertWorklistQuery:94 (bounded filtered canonical alert-ID candidate plus actual reference term); ControlRoomIncidentController:189 (same independent correlated discipline); ControlRoomGovernanceReadService:48 and AlertWorklistPresenter:23. CR-owned IncidentJourneyService governance record discovery must continue identity-only/conservative per-record unavailable state BEFORE private family proof. Root-owned HsVisibility/IncidentJourneyPresenter/AlertWorkspace composition are related display boundaries; they are not new permission preparation origins. No CR edits have been made.

## Deliberately narrow contexts that must NOT receive a blanket family union

- ClinicalDashboardService::getRestraintLens:630/632 reads a bounded clinical restraint projection and source-safe entry; no HSE intersection in its callback.
- RestraintRegisterService:147 and RespiteRestraintReadService:93 are restraint-only Access reads; their source facts/pickers do not traverse HSE family scope.
- IncidentController:526 unlinked Incident-only canRaiseCorrectiveAction callback prepares incidents.viewAny/compliance.view/hazards.view and intentionally does not resolve a linked HSE. Linked detail uses HsVisibility's origin. Do not broaden the unlinked branch.
- ChemicalAccessService public catalogue context; ChemicalExposureAccessService/CommandAccess/SourceProjection/Audit materializer own family contexts; InjuryAccess/SourceProjection, FirstAidAccess, EmergencyDrillAccess, LoneWorkerSessionAccess, SafeWorkProcedureAccess and RestraintAccess callbacks that read only their own source do not need exposure keys. Direct sourceProjection readableHsEventIdsInContext consumes only its purpose-specific source proof; it is not the composed HSE family intersection.
- Ppe read/command contexts do not read the HSE source family and are unrelated.

## Whole-test preparation changes needed after root's mount (no edits here)

All paths below are complete files, UNRUN. Add the same exposure prepared union ONLY to positive HSE/aggregator supplied-context origins; keep intentionally missing preparation, wrong-viewer, expired-context and source-only tests intact.

- tests/Feature/HealthSafety/HealthSafetyReadContextTest.php::keys(:53); its :321 FirstAid-only insufficient-preparation regression stays deliberately narrow.
- tests/Feature/Tasks/HealthSafetyTaskContextTest.php positive context origins:113,294,358,470,577,615(full keys),703; :617 missing FirstAid-only branch remains negative. EmergencyDrill-only :216 navigation remains family-only.
- tests/Feature/HealthSafety/HsDerivedSourceCandidatePrivacyTest.php:232 full composed scope.
- tests/Feature/HealthSafety/HsSourceConnectionContextPrivacyTest.php::permissions(:488), the :338/339 source-only HR/Site bridge inherits that helper but does not itself traverse HSE; negative :164 FirstAid-only branch, :377 missing-preparation and :384 LoneWorker-only lifetime stay unchanged.
- tests/Feature/HealthSafety/InjuryDerivedWorkspacePrivacyTest.php::keys(:509), positive composed scope; preserve :394 deliberate FirstAid-only/wrong-viewer branches.
- tests/Feature/HealthSafety/RestraintDerivedSourcePrivacyTest.php positive composed keys:76,93,115; restraintForAlert-only:193 stays family-only.
- ChemicalExposureDerivedSourcePrivacyTest::inFamily(:503/505) already includes exposure SourceProjection PERMISSIONS. Its exposure-only direct projection helpers and :244 deliberately insufficient preparation stay unchanged. New AuditPrivacy materializer prepares full current union by its own constant; :179 audit-only is deliberately insufficient.
- InjurySourceProjectionPrivacyTest supplied Injury-only adapter/task methods, WorkplaceInjurySourcePrivacyTest, WorkplaceInjuryFactualSourceProofTest, RestraintReviewTaskContextTest and chemical public/direct source Access tests do not enter composed HSE source scope; preserve their actual minimal contracts.

## Required acceptance before release

Complete prior five feedback files remain complete with unchanged recommendation ceiling <100 and historical124 failure retained. Run all current affected Tasks/HSE/record/connection/clinical/Client/Site/CR/general audit/settings/HR/private exposure/destination suites after a dependency-complete source freeze and fresh runtime admission. Prepared declaration counts are not execution cases or passes. New source-family tests must include supplied-context no-refresh, every existing family parity, strict dual current authority, current HR/active Site, recorded worker versus recorder, original typed/legacy incident Client/context, malformed/corrupt/rebound source, both modern/legacy child/risk conservative incomplete candidate denial, and no private SQL/body/count/name-search before proof. Full counts/search/page/export/native races/storage/performance remain unproved under HOLD.

## Observed file pins

The accompanying source inventory pins below are observations at read time only, not a full app freeze. Private writer and root destination are still changing. This document does not grant source ownership or runtime admission.

| Source/test path | SHA256 | Declarations (UNRUN only) |
|---|---|---|
| app/Domain/Clinical/Services/ClinicalDashboardService.php | B3E25C88685E739DE658002DE94841B9B51C50C63FCD23E0E229D2229B079262 |  |
| app/Http/Controllers/ClientController.php | 4E6D1D6F4D6277D724ECA71145202B1458ABC788FCEC2A9B0D7BE0F07454E842 |  |
| app/Http/Controllers/ControlRoom/ControlRoomIncidentController.php | D1A142DCD38C514F33046F0B6F4FA42307909B2937D592280D0F557A5A51A169 |  |
| app/Http/Controllers/HealthSafety/HealthSafetyDashboardController.php | 41739BD02D407AC1F9C7E6BCE9CE427C9BA440D435FD31367D62024F504D714C |  |
| app/Http/Controllers/HealthSafety/HsCorrectiveActionController.php | 3FD564790AB12C4133AFEEE77AD4EC00BD132F02CAB586C146EC1853FCB7267C |  |
| app/Http/Controllers/HealthSafety/HsCorrectiveActionEvidenceController.php | DB07999436A3EFF093FD067B637AEEA204EE1A57240B26087BECF8318A51248C |  |
| app/Http/Controllers/HealthSafety/HsEventController.php | C9BFE71890E5805DD8DE5C8FAB9AB21CE71CEF9C21B961C163E739F7593AD83D |  |
| app/Http/Controllers/HealthSafety/HsInvestigationController.php | A067911BB49950806AF1A1AF58F23A1CA00D9CEDC25A75ED13E78AFB119DE5E1 |  |
| app/Http/Controllers/HealthSafety/HsRiskAssessmentController.php | 459B2DE720EE6628CB52C78C281E73259CFBD191E6F1F864D1DC4C72B5E7ECC2 |  |
| app/Http/Controllers/HealthSafety/HsWorksafeDecisionController.php | 51077C85EF969B7FDC7D52FAE7C5E6428C87D6D403CAB01262BD9EDCC16F1B0B |  |
| app/Http/Controllers/IncidentController.php | C2F6D5AD4285472E46039D6B43F973C51D4ABD2844AF9AAE12D8677D576F97B3 |  |
| app/Http/Requests/HealthSafety/StoreHsRiskAssessmentRequest.php | EE6781C43F293F794EE6B6E5C7FCD5DD7BCAF37470E6142808D480C5041713C7 |  |
| app/Services/ControlRoom/AlertWorklistQuery.php | F6907F53306B7D9D3D4A13C2885622C660399C849E9C0DB975500A0BE097DFD1 |  |
| app/Services/ControlRoom/ControlRoomGovernanceReadService.php | 41E52C1A5C3D13B2288241447CCB1DE2E051A214A56E1058F6B0A9092678C4B9 |  |
| app/Services/HealthSafety/ChemicalExposureAccessService.php | 4C8B3E5E85090F1E0749AECFC7B2CEE8FDDA313BA69B3B87988872E92E637721 |  |
| app/Services/HealthSafety/ChemicalExposureAuditAccessService.php | EB4EE01665F003D0348F758A85FD7BD61E315347080688C81B6293440C3801B9 |  |
| app/Services/HealthSafety/ChemicalExposureCommandAccess.php | E358F3CDE84832E6F6665514FCD1E52EDF357BE20F0A78FF14BDA432DD5F5577 |  |
| app/Services/HealthSafety/ChemicalExposureEvidenceService.php | 13DA6516E411A4AFCBF1A1023C58A8C7F80595F72C2FDD182B8CDAC0B22CCA06 |  |
| app/Services/HealthSafety/ChemicalExposureHsEventDeliveryService.php | C38A820B714D00EE1E7DC7049D738D29120EAE539C8A00C9419E20E3A15B7ED0 |  |
| app/Services/HealthSafety/ChemicalExposureLedger.php | AEFDA0DD7CB5C8297A0A46F7DEDA1C7C593759B08F5D6B71450EB60CD9550F5C |  |
| app/Services/HealthSafety/ChemicalExposureSourceProjectionService.php | D5D831E173C396B56FB06251B3AE5D4D074EE79D04CAA7C7C30FB49D7CC1ECF3 |  |
| app/Services/HealthSafety/ChemicalExposureSourceService.php | 89E61584AEAA8E60FC560F6668D1B3DB91253C5CBD10E6D65E79F75CB1B1EEDE |  |
| app/Services/HealthSafety/EmergencyDrillAccessService.php | BD60EC1DEECF03730E1E0C9A3A76A8B19D1BBFA5A723A1BD41F304D948C692F2 |  |
| app/Services/HealthSafety/EmergencyDrillConnectionsService.php | D5C910180920AC2B2C1457CA9E29EF2ED542B7DC3440F49644073938FDA43C4B |  |
| app/Services/HealthSafety/EmergencyDrillService.php | B56DBCF5AB8CEA052A63DA35F5D75094B0D925891883F5CC4A2FA48FEC656285 |  |
| app/Services/HealthSafety/FirstAidConnectionsService.php | 0F2DE7991B6E7D90A073CA68CDB07F40CAFB74C7F438FFAFD3FB0F998D58EF82 |  |
| app/Services/HealthSafety/FirstAidSourceProjectionService.php | 3C850A8F5E9593008A50065F773F6AC9F2070ED8BD9A9E99059FBA52FB59288F |  |
| app/Services/HealthSafety/HealthSafetyReadContext.php | 8CC4D41263F7B22042FA17394DDE2BB3197A90877B6DA463277E01025282F0B6 |  |
| app/Services/HealthSafety/HsAnalyticsService.php | 16AD63BA671CA09B4B8344395C19D64366C782C068E9B6A0A25A91B5E8AD0A09 |  |
| app/Services/HealthSafety/HsComplianceExportService.php | B0A66F7E1CE573B24BF9B1B1A889553C502B3717B31A11C733F1CE0D22B9BCEC |  |
| app/Services/HealthSafety/HsCorrectiveActionOwnershipService.php | 49DC69890C5BB8182F0FCDD1ADD3C8919B52C12EF6CCE0188BFE6619782911B3 |  |
| app/Services/HealthSafety/HsCorrectiveActionWorkspace.php | DAE123E49EC0D8961C784414043EA4EB2338388D8EC0E4EF93315D5B3D5F654E |  |
| app/Services/HealthSafety/HsDashboardService.php | A48D81D954EF556F5CB7DCEBFCE6401FA53FE2AC03BF9E10AF3CAA3B188460ED |  |
| app/Services/HealthSafety/HsEventAccessService.php | 8DA9911B9DFDCF780241D71E18E40640D587AFDC1E4EE9A70006BB9E0F28FC83 |  |
| app/Services/HealthSafety/HsGovernanceService.php | 0FA11BB453C9D9DB3FA41A8B3251373A4CFD9661A179D3AFBD873B97788E8658 |  |
| app/Services/HealthSafety/HsKpiService.php | E193BB678779E45B14B66A4707A56D0EEA23919C617276E04FD04D30F2E3FB77 |  |
| app/Services/HealthSafety/HsModuleSummaryService.php | B6EEAC20F4C3B76FF01803551DAF9EA5C6B1F82B2C443A2011A942A8CA0138A4 |  |
| app/Services/HealthSafety/HsRiskAssessmentService.php | 436110AC4343DAC48F550FA55824393E4E9EF427A596C040652ECD661E676ADC |  |
| app/Services/HealthSafety/HsVisibilityService.php | 8FC27E4F729DF9E7520BF6BB8005AE320D132A8E794DE91657817B4C825CD892 |  |
| app/Services/HealthSafety/InjuryConnectionsService.php | 95787B6C01DEC7636FEDE9887D655D34F65FBE9BF4CC195A36A138B32249C3B7 |  |
| app/Services/HealthSafety/LoneWorkerSessionConnectionsService.php | A685DB26390FA7BD79C50B78C0E2D1AB9553B61BF4815BCFF788CCB6E57D98F0 |  |
| app/Services/HealthSafety/RestraintConnectionsService.php | 8AA718D4DC5CB41990682B0D3D79F7F67693994480D481BBD940854CFF097BEC |  |
| app/Services/HealthSafety/RestraintRegisterService.php | 96B82BA1DAAE45D3FF419F6932BEC055727C1D9AC077047F9AFC3ACD4506F1BD |  |
| app/Services/HealthSafety/RiskAssessmentWorkspaceConnectionsService.php | 7F725859795A81FA2029FF0B4FBEA59230485F3473E15C21BCC4042FAC0757F5 |  |
| app/Services/HealthSafety/SafeWorkProcedureAccessService.php | 699B68907A975FAA036585DF887C7D7F39F5064B434959D2818D4BB7ADD4AA8A |  |
| app/Services/Respite/RespiteRestraintReadService.php | 6EDED48A5D5EDA8B080F3BEC15F13BA2AF218BCDC6668A1F56F2BF82ED45AD34 |  |
| app/Services/Sites/HazardWorkspaceConnectionsService.php | B00334C6A8AB86399B18FD6AFA529746C4A4FB09FCA1741323C7FE0FBA006209 |  |
| app/Services/Sites/Profile/SiteProfileSafetyPresenter.php | B471DE91A12ECD7C795AF82E3EDE1E429426DD80F9A0F183E9EA19A2388DD24B |  |
| app/Services/Tasks/IncidentJourneyTaskContext.php | 59AEA226578D74358B9397CFD6E40C4D438154C043C171E64CCC48B7A993D905 |  |
| app/Services/Tasks/Providers/HsCorrectiveActionProvider.php | BB79368AFFA3098B8F5A37A57364C2AFCEF126E70B89081A51DC74694E5483BA |  |
| app/Services/Tasks/Providers/HsEventProvider.php | 1B3404F03E6C2EE591DC3F212102F2B96C0A7F8C922DA4D76562CC604DEFD0A3 |  |
| app/Services/Tasks/Providers/HsInvestigationProvider.php | C02615683F963DF1537F39F8419158486FC5AE3A1F92D1F7489672B09E920278 |  |
| app/Services/Tasks/TaskAggregator.php | 4D3C7D4032D82DE3252CCA8C8CAA903698E559C95BAD100FC88A4B4769718124 |  |
| app/Support/HealthSafety/RiskAssessmentPresenter.php | C1138C1F1D176A0902C8FA6983556C0F55EEAFC0FD3B8A3B349E9BD1EB8243F2 |  |
| app/Support/HealthSafety/SafeWorkProcedurePresenter.php | 575DBC048BD5889E7AC1F306D504D4E46133045E79DB00D1679AEFF7C8A7EF4B |  |
| app/Support/Incidents/LinkedOperationalEvidencePresenter.php | CE1C942A4F5764E9B7DEE2066B8E72292B6F576CF6447EA703BDBDAB9AFE891C |  |
| tests/Feature/HealthSafety/ChemicalExposureAuditPrivacyTest.php | B7AE20BE6DF55C8F85974A0883B1DB6C09C3FAB0C934CB52AA89FAE386F39481 | 38 |
| tests/Feature/HealthSafety/ChemicalExposureAuditRecoveryPrivacyTest.php | 43710FF72764F4E08E520E35AEC71B4325D0C725447E3E572F00D3BB59B0C8ED | 14 |
| tests/Feature/HealthSafety/ChemicalExposureDerivedSourcePrivacyTest.php | 57ECCE534F5C8326A0D7641E6D69086C343E2852C0117B3721CCAA4E9B841147 | 30 |
| tests/Feature/HealthSafety/HealthSafetyReadContextTest.php | 3DD9DE705F5B7BD922272940840C6EB0F9C3EEC235AC220A35C23BC79A497A37 | 13 |
| tests/Feature/HealthSafety/HsDerivedSourceCandidatePrivacyTest.php | E7A181D3063461C4560743152D0410CF09ACE911B82205763AAE2D763EBEC3F8 | 15 |
| tests/Feature/HealthSafety/HsSourceConnectionContextPrivacyTest.php | 030325B081D8E9F37E828BF97E28048D776031DD1F6E7116B2DF12F98F46AA71 | 16 |
| tests/Feature/HealthSafety/InjuryDerivedWorkspacePrivacyTest.php | B6591F928921D7648A2ACA1D82960B3C373C8200855FB3F02594FB6ABDE4C2C4 | 26 |
| tests/Feature/HealthSafety/RestraintDerivedSourcePrivacyTest.php | B67F35F4448DC35EBBB69E6DADAD40F0AE0D3D570AD59B5CAAC9E7388FF33C33 | 10 |
| tests/Feature/Tasks/HealthSafetyTaskContextTest.php | A4C890B6FBD5B72E704444DFBF062F179B26A5BCCAC0588C8BF6AAB0E9E6C90C | 23 |
