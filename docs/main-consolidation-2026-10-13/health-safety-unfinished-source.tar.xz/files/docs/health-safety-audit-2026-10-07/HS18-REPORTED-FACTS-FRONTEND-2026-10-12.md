# HS18 reported answers and correction preservation

Source checkpoint only, 12 October 2026. The complete H&S goal remains active. Private exposure HTTP aliases, source-family consumers and recovery composition remain unmounted. No native, browser, migration or runtime checks were performed; the shared runtime hold remains in force. This is not a release gate or candidate freeze.

## User choice and provisional behaviour

The human chose wellbeing access for identifiable worker exposure records; general safety users see restricted access. Capture remains independently authorised. The optional question about Unknown is still pending. Following the already stated provisional assumption, the form allows Unknown so staff can report promptly. This assumption is not a received answer or a clinical policy decision.

Treatment, care sought and separate incident reporting are independent answers. Untouched blank capture fields are omitted: the prospective backend records them as unanswered. Explicit Unknown sends null, No sends false and Yes sends true. Selecting treatment no longer changes care sought. All three answers appear separately during review, including unanswered Unknown. Category enums and other input checks remain.

## Implemented frontend behaviour

Corrections send changed factual fields only. An untouched occurrence stays omitted, preserving the accepted instant rather than reconstructing it from the display. Unchanged medical answers, worker/Site references, narrative and outcome are also omitted. Reviewing and adopting a fresh revision retains the user's entries without replacing newer, untouched facts with the original displayed values.

A separate per-field confirmation lets staff explicitly re-report an unchanged care, treatment or incident answer. These choices participate in the draft state, survive an explicitly reviewed revision and are hidden with the private form when current access is withdrawn. Submitted Unknown and confirmations retain the existing exact original-command retry behaviour after a lost response. The backend remains responsible for immutable provenance, actual acceptance and detecting genuine no-op versus confirmation.

The saved overview and current-record review distinguish reported Yes/No, explicitly reported Unknown, unanswered Unknown, earlier unconfirmed recorded values and answers from a prior worker/Site. Missing fact_states cannot certify a pre-contract Boolean as explicitly reported. The fixed optional frontend fact_states contract is prepared for the backend projection; existing old fixtures remain representable. Earlier recorded values are visible only inside an admitted saved-private record, and are withheld on source repair/access denial.

Source revision now participates in the detached command-choice request identity, even for an unchanged actor and Site. A revision change withholds stale choices and starts a fresh request. No new server query parameter or local eligibility grant was added.

Shared Field, SelectInput, Checkbox, WizardShell and review primitives remain in use. Confirmation controls use the existing compact checkbox with a frontline hit area, semantic typography and visible text. Saved work stays inline on the permanent record page. Mobile, keyboard, zoom and real browser verification remain required.

## Backend dependency and response decision

B owns the prospective nullable/default-null flag migration, closed immutable reported-facts helper and narrow Source integration proposal. Old 0/1 data is preserved; treatment must no longer derive care sought; correction omission must preserve original answers and evidence. A owns the reader/collection and separate sealed legacy review foundation. Those dependencies must be coherently composed before mounting the private interfaces. The existing backend still rejects null and derives attention: this frontend is not independently adoptable.

Root's operational direction for the destination classifier is to preserve valid reported category floors; Yes with first aid/none gets a separate review-needed indication, rather than a new automatic investigation rule. Preserve the existing Yes-without-category High response. Wholly Unknown/unconfirmed stays Medium for operational triage pending review, never as known harm. Existing higher severity, investigations, WorkSafe decisions, ownership and closure must not be lowered or replaced. This direction has been allocated to backend planning; the root destination classifier has not yet changed or been verified.

Original-body lineage admission remains mandatory. Confirming facts or choosing a new incident cannot unseal medical history whose original association is unknown. The separately retained later-review case must not copy old medical facts or claim that later evidence was contemporaneous.

## Source checks and remaining acceptance

Pure source reads confirmed all three prepare/submit/review calls use the same baseline and explicit confirmation set, and that treatment no longer assigns the attention field. These are source observations only.

The finite changed-unit whole suites declare form 8, choices 5, workspace 16 and overview 5 cases: 34 declarations, all UNRUN. Across the eight existing private frontend suites there are 59 declarations, all UNRUN; this is not a test result. Meaningful new cases cover independent Yes plus unchanged treatment, explicit Unknown and exact retry, unchanged legacy confirmation, access withdrawal, unknown/prior-context presentation, untouched facts across an actual fresh-revision response, and same-Site revision choice invalidation. Existing historical manifests remain historical; they are not silently repinned as a whole accepted package.

Required before completion: coherent backend/provenance/read/count/destination composition; accepted-source historical privacy and same-statement consumer proof; complete native/DDL checks; real browser/role/responsive/accessibility journeys; unchanged query-budget acceptance; and every remaining HS00–HS27 and cross-module requirement. No partial release or deferral is authorised.

Automatic approval review rejected the agent's proposed recovery incident-options API because a new private incident metadata/pagination reader exceeded the sealed recovery allocation. That API is absent; no retry or substitute was made. Picker composition remains an explicit dependency for later review. Earlier outgoing parent-report and extra private-risk guard rejections remain unresolved; their pending human questions were not treated as permission and those actions were not retried.
