# Private exposure delivery recovery workspace — source-only handoff

Status: SOURCE_ONLY_UNRUN_UNMOUNTED_NOT_FROZEN. New service/tests are authored, all consumer/transport hunks remain UNAPPLIED. No PHP/Pint/parser/DB/native/Node/browser/process/resource jobs, delivery, notification, Tasks, observer, after-commit dispatch, permission grant, or shared consumer mount occurred. The rejected extra risk guard and its source hashes remain untouched.

## Concrete service and response contract

`ChemicalExposureDeliveryWorkspaceService::index(User,int exposureId,array filters=[],?HealthSafetyReadContext=null):array` accepts page only (25 per page). Envelope: `{source_integrity,attempts:array|null,page:{current_page,per_page,total:int|null,last_page:int|null,has_more:bool|null}}`. Totals are actual admitted outbox attempts, NOT number of exposures or confirmed destinations. Original source/acceptance proof is applied before totals; any corrupt acceptance makes total/last_page/has_more null. Withdrawn original authority or unavailable source withholds the collection. Every page remains discoverable; there is no silent25-row history truncation. The current implementation scans all independently root-filtered attempt identities and validates them, then paginates detached items. This is a correctness candidate, potentially expensive (source/chain checks repeated). Populated native performance/memory and proper pagination workload remain unmeasured; no global cache or query ceiling change.

`detail(User,int exposureId,int deliveryId,?HealthSafetyReadContext=null):array` first selects ONLY the exact root+delivery identity pair after the fresh private gate, before source or delivery body. It returns:

```text
id,kind:health_safety|followup|null,
attempt_state:pending|delivered|superseded|unconfirmed,
currency:current|superseded|unknown,
source_revision:int|null,attempts:int|null,
acceptance_integrity:recorded|repair_required,
destination:{state,channel:health_safety|database|null,
 external_delivery:not_attempted,href:null,href_reason:string|null,
 read:bool|null,actioned:false,notification_preference:enabled|disabled|null,
 can_deliver:bool,blocked_reason:string|null},
can:{retry:bool},blocked_reason:string|null
```

The child attempts field is the observed stored counter; the existing writer increments it after successful concrete confirmation, and failed/rolled-back tries are not a complete execution ledger. It is not proof of dispatch/history. The page total counts proved outbox work records, not retry attempts or messages. Destination state is separate from the stored attempt flag: hs_event_present, inbox_present, unconfirmed, superseded, restricted, unavailable, or repair_required. No delivered flag certifies a destination. No root medical prose, worker/recipient names/IDs, source-version IDs, acceptance UUID, membership/context, notification ID, file path, or body enters the DTO. A read inbox item is not an actioned/completed source follow-up. External mail/push/SMS delivery is never claimed.

`retry(User,int exposureId,int deliveryId):array` requires transactionLevel0 BEFORE any work. It accepts no new source command payload/UUID or user callback. A current manager can retry; this preserves the existing policy and does not add original-actor ownership. Original immutable acceptance actor/receipt/membership is proved independently. The response `{retry_requested_by:current_request_actor_id,inspection:detailDTO}` identifies the request actor, not a fabricated retained acceptance actor or user source receipt.

Retry preflight is advisory and ends before concrete dispatch. The actual destination transaction must independently constrain exposure_id in its initial minimal delivery identity query. Only exact concrete HSE or named-followup consumers execute. Source acceptance remains committed; destination/outbox failure does not undo it. After destination execution physically commits, a NEW authorized read re-proves actual destination presence instead of trusting returned delivered flags. Source grants/Site/context withdrawal, opt-out, stale membership, corruption and unknown dependencies block dispatch. A lost response is inspectable without sending from GET; explicit retry uses the same canonical destination identity.

## Exact evidence lifetime and root snapshot

Both default and supplied readers consume the same current prepared ChemicalExposureCommandAccess permission union; supplied wrong viewer, incomplete keys, expired callback or connection is an error. Private dual hazards.view + hr.wellbeing.view, current internal staff and approved active Site precede private source/outbox SQL. Preparing keys grants nothing and there is no self-access fallback. Historical worker is distinct from recorder. Original version/receipt/audit/actor proof delegates to B's source service; no local ledger certificate is invented.

The initial root now follows B Workspace's actual exact-model `currentVersion` + ledger snapshot/reload pattern. A separately refreshed sourceProof cannot bless an earlier loaded model. Exact context and accepted version identity are bound to the model used for membership comparison. Root is rechecked before/after attempt/source/destination proof and before final counts. Final conditional source SQL compares the same raw persisted fields (timestamps excluded exactly like ledger snapshots, original_context compared as retained database JSON text), and does not hydrate another model that could have a retrieval-listener gap. This is source design, not a tested guarantee about database isolation. Real same-callback model retrieval/query mutation tests are prepared; actor/RBAC locks are not assumed to certify a changed source snapshot. B's acknowledged original Client/context-before-initial-private-root-body ordering proposal remains a separate prerequisite, not solved or silently claimed here.

Stored attempt state remains visible, but currency is independently derived from current accepted source version/membership, not from a mutable superseded flag. Genuine old work stays superseded without GET writes or dispatch. Damaged membership/original actor/version/purpose is repair, not a legitimate stale delivery.

## Concrete UNAPPLIED destination seams

`CHEMICAL-EXPOSURE-DELIVERY-CONFIRMATION-UNAPPLIED-2026-10-12.patch` contains only bounded hunks in three owner files:

1. HSE service: additive `confirmationInContext(User,int exposureId,int deliveryId,HealthSafetyReadContext):array`. It proves exact admitted source/attempt, actual acceptedHistory, current immutable marker/audit, exact retained event identity/time, and the existing response severity floor. It performs no write/dispatch. It rejects an unproved legacy copy, conflicting/missing/rebound/archived destination, and reused/corrupt source acceptance. Old valid marker requiring current source projection is honestly unconfirmed, still deliverable by the existing consumer. Exact-root model/conditional rechecks surround presence outputs.
2. Followup service: additive `confirmationInContext(User,int deliveryId,HealthSafetyReadContext):array` and shared private confirmationInReads extraction. It preserves the original public confirmationForViewer six-key shape. Named recipient independently prepares its own DIFFERENT current authority/original-context proof; caller authority is never reused as recipient permission. Actual deterministic database notification identity/type/payload is checked. Missing item is unconfirmed; opt-out blocks new creation, while an already proven existing item can be reconciled without new sending. Read/actioned remain separate. The actual underlying admitAttempt/assertNotification/inboxEnabled helpers remain canonical.
3. Add optional final `expectedExposureId` to underlying DeliveryService::deliverForViewer and propagate it through HSE::deliver and Followup::deliverForViewer. The actual initial identity query adds exact exposure_id BEFORE any source/body/superseding write. Default callers remain compatible; destination callback signatures/purpose checks are unchanged. Workspace refuses retry eligibility if either wrapper or underlying expected-root contract is absent; this checks an unmounted method contract, not destination presence or access readiness.

### Presence is not a usable HSE link

The proposed HSE confirmation intentionally returns hs_event_present with href:null and href_reason=hse_read_composition_unmounted. No current canView success or method-exists flag is used as proof of the unmounted chemical family/GET controller composition. Actual existing API is `HsEventAccessService::canView(HsEvent,User,?HealthSafetyReadContext)`. A later reviewed usable-link seam must prepare FA + Restraint + Injury + ChemicalExposure source keys in the SAME callback, apply canonical current Site and exact ID, and consume the FULL mounted exposure source intersection plus actual permanent GET read path. The all17 preparation origins and source-family/default materializers remain UNAPPLIED prerequisites. Source marker presence alone never produces a clickable private HSE link. Root can still display proven presence separately from the open action.

## Exact UNAPPLIED HTTP composition

`CHEMICAL-EXPOSURE-DELIVERY-HTTP-UNAPPLIED-2026-10-12.patch` creates a narrowly scoped controller proposal and inserts three routes into the actual health-safety auth group:

- GET `/health-safety/chemical-exposures/{exposure}/deliveries` → index envelope.
- GET `/health-safety/chemical-exposures/{exposure}/deliveries/{delivery}` → `{inspection}`.
- POST `/health-safety/chemical-exposures/{exposure}/deliveries/{delivery}/retry` → `{retry_requested_by,inspection}`.

All use raw numeric route IDs, actual ChemicalResponseHeaders no-store/no-referrer middleware, JSON-only transport and no Inertia/HTML/partial props. Unknown query selectors or nonempty actual JSON/form/file retry payload is rejected; no new intent UUID is accepted. Canonical fresh service read/manage proof is decisive inside the existing auth boundary, avoiding a stale request actor's redundant precheck on these NEW routes. Existing route policies/grants are not changed. B's separate exposure workspace/capture/recovery proposal and its delivery-attempts alias remain untouched; root may adapt that legacy reader only after review, without creating a second delivery policy. No frontend component or shared notification/Tasks entry is mounted here.

## Complete prepared native tests and dependencies

New complete `ChemicalExposureDeliveryWorkspaceTest.php` has31 declared methods; `ChemicalExposureDeliveryWorkspaceHttpTest.php` has13. These44 declarations are NOT an executed-case/pass count and are separate from the historical5-file44-declaration recommendation feedback package. Both inherit the actual ChemicalExposureCommandTestCase with physicalCommits=true, native MySQL testing guard, committed-fixture restoration and UTC frozen instant. No SQLite, local test route registration, delivered-boolean mock, alternate callback, readiness stub or case filter certifies privacy.

Actual commands create substance/exposure/assignment and source outbox; tests use the actual HSE/inbox consumers. Whole regressions include pending GET/no dispatch, physical retry + subsequent proof, lost response, idempotent destination identity, delivered flag with absent event, immutable marker/payload/severity damage, independent closure/WorkSafe preservation, original/current actor distinction, wrong route root within otherwise allowed Site, actual destination expected-root admission, original actor corruption, grant/HR/Site/Client/recipient withdrawal+restore, opt-out, notification-read versus completion, missing/tampered inbox, genuine aggregate advance, paginated27 real source revisions, save veto rollback/retry, supplied-context parity without caller authorization refresh, lifetime/preparation/viewer denial, exact-model root interleavings, JSON/HTML/Inertia/partial/header denials, POST-only recovery, generic safety/self denial, and unknown payload/file/query rejection.

These whole files require the real confirmation/root-binding and HTTP proposals to be reviewed/mounted before runtime admission. Keep complete existing ChemicalExposureDeliveryContractTest, ChemicalExposureHsEventDeliveryTest, ChemicalExposureFollowupDestinationTest, source Historical/Lifecycle/Privacy suites and private Workspace tests in the affected gate. Dependencies include current B200200 source/ledger/history/membership, root200300 HSE marker/service, independent recipient source proof/preferences, actual routes/header policy and the full source-family integration before usable links. No public/private schema, policy, logger, shared helper or authoring owner source was copied or altered. Syntax/Pint/native/static execution and full populated resource/performance checks remain UNRUN.

Current source hashes and pure-text patch context/count projections are retained in storage/logs/chemical-exposure-delivery-workspace-source-candidate.json; ownership inputs remain moving candidates, not freeze/admission. Historical risk manifests and the rejected extra guard review remain exact and pending.

B source follow-up: the separate root-body ordering patch remains UNAPPLIED. B also identified the existing ChemicalExposureReadService collection awaiting-medical count and paginate(['*']) before per-row original-context proof. This new delivery service does not call that collection, but the overall private consumer composition cannot be accepted until that independently owned materializer is repaired. B's newly stable reassignment/current recipient union is consulted only; no owner helper changes were applied here.
