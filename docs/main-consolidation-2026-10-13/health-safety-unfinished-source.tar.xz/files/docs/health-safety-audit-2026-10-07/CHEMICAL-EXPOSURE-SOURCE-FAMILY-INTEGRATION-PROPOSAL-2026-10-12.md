# Chemical exposure source-family integration proposal

SOURCE ONLY, UNMOUNTED, UNRUN. This document is a semantic patch proposal, not a portable whole-file transplant or admission. Only the new projection and dedicated complete suite are authored by this owner. Existing HealthSafetyReadContext/HsEventAccessService/Tasks/Audit/Governance/CR files remain root or peer owned. Private200200 writer, proof and delivery are separately owned and not yet source-ready.

## Concrete service and hard dependency

ChemicalExposureSourceProjectionService::readableHsEventIdsInContext(User $viewer, Builder $independentCandidates, HealthSafetyReadContext $context):array returns detached readable H&S IDs only. The candidate clone preserves WHERE bindings, clears eager loading/order/limit/offset, applies literal class/actual morph/category/current approved Site/asset-null before source discovery and chunks200. It selects H&S identity columns only. Private dual grant precedes source/version/dependency SQL. No name or narrative lookup is used to prove IDs, no global whitelist or cache. The caller's original Builder remains unchanged.

forHsEvent(int $id, User $viewer, ?HealthSafetyReadContext $context=null):array returns {access: readable|restricted|unavailable|absent,source: null|detached private minimal projection, ignored?:true,integrity?:repair_required|unknown_context}. Readable is an exposure-source decision, not operational H&S/CR command authority. Source includes exact worker/substance/Site identities and names, exposed_at absolute UTC ISO instant (downstream canonical civil-date presentation), exposure_type, attribution/context/incident states, nullable current source version/revision and href=null until a real protected permanent route is mounted. It excludes symptoms/treatment/circumstances/outcome/recorder/evidence/counts. The affected worker is user_id, never created_by. Same active supplied context is reused; wrong viewer/preparation/lifetime/physical connection remains a LogicException, never a silent fresh callback.

Hard dependency proposed and confirmed by private writer owner: ChemicalExposureSourceService::sourceProof(SubstanceExposureRecord|int,User current,CurrentAuthorizationReads,array approvedSites):array inside active ChemicalExposureAccess callback. No fallback, marker-only proof, dummy model, invented private version table or duplicate proof is implemented. Constructor currently depends on that forthcoming class. All mounting waits its stable actual source/schema and proof review. It returns minimal repair {attribution_state:repair_required,source_id}; projection branches before reading other tuple keys. Recorded/legacy proof returns current canonical substance/worker/Site/category/asset-null, version/revision and explicit incident/client/shift/context binding.

Writer-owner binding proposal: new no incident => incident/client/shift absent IDs null and context recorded (known-null association, not universal external-context completeness). New validated incident => original incident/client recorded, shift recorded if actually nonnull otherwise absent, context recorded. Legacy null incident => incident absent but client/shift/context unknown; an H&S copy is permissible only Client/shift null plus exact source/worker/Site/category. Legacy retained incident => incident/client/shift/context unknown, original IDs withheld, no today's-incident fallback; all derived copies fail closed. Missing/archived/moved/damaged source cannot preserve old copied readability. The parent is reviewing the exact current incident rule; no stay field exists and none is guessed.

## Minimal HealthSafetyReadContext semantic hunk — root review only

Add SubstanceExposureRecord import and one applyChemicalExposureEventScope(Builder $query, ?Builder $sourceCandidates=null):Builder method adjacent to injury. Use the same existing active context, not a second authority handle:

```php
$this->assertActive();
$types = array_values(array_unique([SubstanceExposureRecord::class, (new SubstanceExposureRecord)->getMorphClass()]));
$candidates = (clone ($sourceCandidates ?? $query))->setEagerLoads([])->reorder()->limit(null)->offset(0);
// Current H&S Site scope precedes source discovery; method names never imply authorization.
$this->applyEventSiteScope($candidates, UserSiteAccessService::HEALTH_SAFETY_SITE_BYPASS_PERMISSIONS);
$ids = [];
try {
    $ids = $this->consumeSourceViewer(ChemicalExposureSourceProjectionService::PERMISSIONS,
        fn (User $current): array => app(ChemicalExposureSourceProjectionService::class)
            ->readableHsEventIdsInContext($current, $candidates, $this));
} catch (HttpException $denial) {
    if (! in_array($denial->getStatusCode(), [403, 404], true)) { throw $denial; }
}
$query->where(fn (Builder $sources) => $sources->whereNull('hs_events.source_type')
    ->orWhereNotIn('hs_events.source_type', $types)->orWhereIn('hs_events.id', $ids));
return $this->query($query);
```

The actual applyEventSiteScope(Builder,array):Builder signature was inspected; this is a semantic recipe, not an applied patch. Empty/incomplete discovery never widens final source correlation. No exposure memo is introduced, including empty or global candidate paths. Context factories traversing the full HSE intersection must prepare ChemicalExposureSourceProjectionService::PERMISSIONS in addition to the existing FirstAid/Restraint/Injury (and operation-specific Procedure/Drill/read) union; union preparation is not a grant. Purposeful missing-preparation/lifetime tests remain unchanged.

## Minimal HsEventAccessService semantic hunks — root review only

1. Add the actual exposure model import. Add applyChemicalExposureSourceScope(Builder,?User,?HealthSafetyReadContext=null,?Builder independentCandidates=null):Builder using the same injury pattern: supplied context asserts viewer and invokes the new context family method; fresh wrapper starts one correctly prepared ChemicalExposure context only when no caller context exists; absent viewer excludes known exposure types. Catch only real403/404 denial, leave LogicException/integration errors visible. Returned query always keeps exact final type OR readable-ID correlation.
2. Chain the new final family intersection after injury in both provided-context and standalone return paths. Do not move filters/order/top300 or bypass ordinary H&S module/Site checks. No existing family is removed.
3. Add literal/actual morph exposure types to deniedFirstAidEvents' known-confidential identity set. Discovery uses the caller's independent, already-filtered candidates only. FINAL denial remains HsEvent::withTrashed()->whereIn(known types)->whereNotIn(id, allowed)->select(id), not candidate-restricted. Existing child null/orphan/unrelated handling and both modern hs_event_id plus retained legacy assessable_type/assessable_id risk bindings remain exactly binding. SQL may inspect global identities, never materialise unrelated exposure backlogs.
4. Update existing fresh canView and full source-family context origins to prepare exposure keys. Do not weaken a cheap canView gate, add a worker self grant or widen incident/CR response permissions. Root coordinates actual mounted controller/Tasks/Governance/Audit consumers separately; CR three read seams remain CR owned.

## Whole-suite obligations and actual preparation

NEW complete ChemicalExposureDerivedSourcePrivacyTest presently30 declarations, all UNRUN, actual quiet legacy sources (not fabricated governed receipts) and actual existing HSE/action/risk APIs. It covers exact worker-not-recorder, restricted no-private-SQL, self/catalogue denial, wellbeing-only denial, bounded hydration/disjoint/empty candidate isolation, unchanged caller query/current callback, wrong literal/category/worker/Site/asset/Client/shift, legacy incident unknown, missing/archive/move, warmed grant revoke/restore, current HR/Site withdrawal, inactive/archive/nullSite under bypass, wrongviewer/preparation/lifetime/connection, unrelated HSE parity, complete incomplete-candidate child denial, both modern+legacy risk links/orphans, archived event bindings and count/list parity without foreign hydration. The actual HSE-family cases require the proposed mounting and are prepared acceptance, not green tests.

Seven additional cases now use the actual saved ChemicalExposureSourceService::create API and actual receipt root_id/source_version_id to prepare recorded no-incident context, corrupted current medical facts, damaged retained digest, marker downgrade, known-null Client denial, recorded incident Client/incident permission withdrawal/restoration and current incident Client correction. Positives are genuinely command-created; corruption uses deliberate persisted mutation after acceptance, never forged immutable certification. These tests are source-only and still wait complete stable writer/proof/schema integration; no pass is inferred. Retain whole existing ChemicalExposurePrivacyTest and HsDerivedSourceCandidatePrivacyTest plus all existing FirstAid/Restraint/Injury/context/Tasks source suites. Original recommendation historical124 queries and strict<100 ceiling remain unchanged. Bounded source scans/proof count/performance, DB isolation and real HTTP consumers remain required native evidence, not source claims.

CR source ownership dependency: context.root_note_origin v1/source=operator_note binds persisted OperatorNote/alert/actor/SHA256. Every source write/delivery taking root-note ownership atomically invalidates that reference or replaces it with explicit source-owned provenance, including identical-text replacement. Legacy provenance stays unknown. This projection never rewrites root notes or operational response.

## Actual private proof composition update

The writer owner has now source-saved actual ChemicalExposureSourceService::create and sourceProof plus private200200 classes; integration remains held for its final stable reviewed pins. The source proof result also carries service_context_id/stay_id from the prospectively retained original_context JSON, using actual ClientIncident fields and canonical source access (no invented direct exposure stay column). The projection does not serialize those IDs or guess completeness. Current linked-context proof now revalidates original incident through IncidentAccess/current ClientPolicy and exact stored Client/shift/context/stay tuple; a correction cannot supply today's tuple as a fallback. Damaged immutable proof returns only attribution/source identity and is concealed before tuple/name projection.

ChemicalExposureSourceProjectionService::PERMISSIONS aliases the ACTUAL ChemicalExposureCommandAccess prepared union because sourceProof consumes current incident/Client/stay keys. This is prepared read evidence only, not command authority. Provided context explicitly consumes that complete union before invoking the existing private Access callback; missing keys remain an error even on an empty candidate. Public wrappers create one complete fresh context and the same private callback. Review exact final writer union/consumer dependencies before mounting; the simple three-key private read union alone is insufficient for linked proof. The integration snippets above now use the projection's complete prepared union.

forHsEvent first queries only literal H&S id/source_type for unrelated-family classification, without source/worker/Client/shift IDs or copied narrative; denied dual authority returns restricted/null before private SQL. After admission, its exact tuple query is constrained to current approved Sites before hydration. All success scalars are detached before callback exit. The absolute ISO timestamp avoids a hardcoded civil timezone; no date policy, invalid-config fallback, Source helper or frontend formatter is duplicated here.
Two further actual regressions distinguish historical worker employment from current viewer eligibility and prove warmed hazards.view plus secondary Site withdrawal/restoration independently. Whole suite now30 method declarations, no data providers; actual discovered cases/assertions remain UNRUN.
