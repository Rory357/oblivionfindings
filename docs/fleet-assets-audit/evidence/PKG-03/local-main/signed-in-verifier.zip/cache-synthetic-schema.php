<?php
require __DIR__.'/browser-environment.php';
$binary='C:/Program Files/MySQL/MySQL Server 8.0/bin/mysqldump.exe';
if(!is_file($binary)) $binary='C:/Program Files/MySQL/MySQL Server 8.4/bin/mysqldump.exe';
$common=[$binary,'--host='.getenv('DB_HOST'),'--port='.getenv('DB_PORT'),'--user='.getenv('DB_USERNAME'),'--password='.getenv('DB_PASSWORD'),'--skip-comments','--skip-lock-tables','--set-gtid-purged=OFF'];
$file=fopen(__DIR__.'/current-schema.sql','wb');
foreach([['--no-data',getenv('DB_DATABASE')],['--no-create-info',getenv('DB_DATABASE'),'migrations']] as $args){
    $process=new Symfony\Component\Process\Process([...$common,...$args]);$process->setTimeout(180);
    $process->run(function($type,$text)use($file){if($type===Symfony\Component\Process\Process::OUT)fwrite($file,$text);});
    if(!$process->isSuccessful())throw new RuntimeException('Synthetic schema cache failed');
}
fclose($file);
echo "Cached structure and migration ledger only; synthetic user and Finance rows excluded.\n";
