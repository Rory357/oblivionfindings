<?php
require __DIR__.'/browser-environment.php';
$app=require $root.'/bootstrap/app.php';$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$ids=json_decode(file_get_contents(__DIR__.'/browser-records.json'),true);
$bill=App\Domain\Finance\Models\FinBill::findOrFail($ids['bill']);
$journal=$bill->journal;
$work=App\Models\FleetWorkOrder::findOrFail($ids['work']);
echo json_encode(['host'=>'http://127.0.0.1:8772','sourceRoot'=>$root,'database'=>getenv('DB_DATABASE'),'migrations'=>Illuminate\Support\Facades\DB::table('migrations')->count(),'billId'=>$bill->id,'billStatus'=>$bill->status,'journalId'=>$journal?->id,'journalStatus'=>$journal?->status,'approvalReceipts'=>App\Domain\Finance\Models\FinBillApprovalReceipt::where('bill_id',$bill->id)->count(),'paidAmount'=>$bill->amount_paid,'workStatus'=>$work->status,'estimate'=>$work->estimated_cost,'savedNote'=>Illuminate\Support\Facades\DB::table('fleet_maintenance_actions')->where('work_order_id',$work->id)->where('action_type','note')->exists(),'reviewStatus'=>App\Models\FleetFinanceReviewRequest::findOrFail($ids['review'])->status,'privateQuoteExists'=>Illuminate\Support\Facades\Storage::disk('local')->exists('pkg03-verification/quote.pdf'),'scannerConfigured'=>false,'operationalRecordsUsed'=>false],JSON_PRETTY_PRINT);
