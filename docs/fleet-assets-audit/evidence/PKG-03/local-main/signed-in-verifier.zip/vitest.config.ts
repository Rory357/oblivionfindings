import {defineConfig,mergeConfig} from 'vitest/config';
import base from '../vitest.config';
import path from 'node:path';
export default mergeConfig(base,defineConfig({resolve:{alias:{'pdfjs-dist':path.resolve('.pkg03-fullpage-tools/runtime/node_modules/pdfjs-dist')}}}));
