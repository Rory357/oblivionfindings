<?php
require __DIR__.'/browser-environment.php';
$path = rawurldecode(parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH));
$assetPath = str_starts_with($path,'/pkg03-verification-build/') ? substr($path,strlen('/pkg03-verification-build/')) : ltrim($path,'/');
if (str_starts_with($assetPath,'assets/') || str_starts_with($assetPath,'pdfjs/')) {
    $builtRoot=realpath(__DIR__.'/production');
    $builtFile=realpath($builtRoot.DIRECTORY_SEPARATOR.$assetPath);
    if ($builtFile && str_starts_with($builtFile,$builtRoot.DIRECTORY_SEPARATOR) && is_file($builtFile)) {
        $extension=pathinfo($builtFile,PATHINFO_EXTENSION);
        header('Content-Type: '.match($extension){'js','mjs'=>'text/javascript','css'=>'text/css','wasm'=>'application/wasm',default=>'application/octet-stream'});
        readfile($builtFile); return true;
    }
    http_response_code(404); return true;
}
$public = realpath($root.'/public');
$file = realpath($public.$path);
if ($file && str_starts_with($file,$public.DIRECTORY_SEPARATOR) && is_file($file)) return false;
define('LARAVEL_START',microtime(true));
$app=require $root.'/bootstrap/app.php';
$app->make(Illuminate\Contracts\Http\Kernel::class)->bootstrap();
Illuminate\Support\Facades\Vite::useHotFile(__DIR__.'/disabled.hot')->useBuildDirectory('pkg03-verification-build');
header('X-PKG03-Verification-Source: dcf0-7afb83403-synthetic-db');
$request=Illuminate\Http\Request::capture();
$kernel=$app->make(Illuminate\Contracts\Http\Kernel::class);
$response=$kernel->handle($request);
file_put_contents(__DIR__.'/real-http.jsonl',json_encode(['method'=>$request->method(),'path'=>$request->getRequestUri(),'status'=>$response->getStatusCode(),'location'=>$response->headers->get('Location')]).PHP_EOL,FILE_APPEND);
$response->send();
$kernel->terminate($request,$response);
