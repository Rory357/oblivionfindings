<?php
// Disposable synthetic browser verification only. Never loaded by application source.
$root = dirname(__DIR__);
$xml = simplexml_load_file($root.'/phpunit.xml');
foreach ($xml->php->env as $entry) {
    $name = (string) $entry['name'];
    $value = (string) $entry['value'];
    putenv($name.'='.$value); $_ENV[$name] = $_SERVER[$name] = $value;
}
foreach (['APP_ENV'=>'local','APP_URL'=>'http://127.0.0.1:8772','DB_DATABASE'=>'oblivion_findings_pkg03_browser_dcf0_20260927','SESSION_DRIVER'=>'file','SESSION_COOKIE'=>'pkg03_verification_session','SESSION_SECURE_COOKIE'=>'false','SESSION_DOMAIN'=>'','QUEUE_CONNECTION'=>'database','BROADCAST_CONNECTION'=>'null','MAIL_MAILER'=>'array','CACHE_STORE'=>'array','LOG_CHANNEL'=>'single','MYSQL_TEST_SCHEMA_TIMEOUT'=>'1800'] as $name=>$value) {
    putenv($name.'='.$value); $_ENV[$name] = $_SERVER[$name] = $value;
}
require_once $root.'/vendor/autoload.php';

