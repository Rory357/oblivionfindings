import {defineConfig,mergeConfig} from 'vite';
import base from '../vite.config';
import path from 'node:path';
// Use the production React compiler, Tailwind, chunks and PDF assets. Only the
// PHP route generation / hot-file plugins are omitted from this isolated build.
export default mergeConfig({...base,plugins:(base.plugins ?? []).flat().filter((p:any)=>p && !String(p.name).match(/laravel|wayfinder/))},defineConfig({
 resolve:{alias:{'pdfjs-dist':path.resolve('.pkg03-fullpage-tools/runtime/node_modules/pdfjs-dist')}},
 build:{outDir:'.pkg03-fullpage-tools/production',rollupOptions:{input:'resources/js/app.tsx'}}
}));
