<?php
require __DIR__.'/browser-environment.php';
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use App\Models\{User,Site,Asset,Permission,FleetWorkOrder,AssetDocument};
use App\Domain\Finance\Models\{FinAccount,FinBill,FinFiscalPeriod,FinVendor};
use App\Services\Fleet\{MaintenanceFinanceService,MaintenanceTransitionService,VehicleFinanceService};

$db = getenv('DB_DATABASE');
if ($db !== 'oblivion_findings_pkg03_browser_dcf0_20260927') throw new RuntimeException('Unexpected browser database');
$pdo = new PDO('mysql:host='.getenv('DB_HOST').';port='.getenv('DB_PORT'),getenv('DB_USERNAME'),getenv('DB_PASSWORD'),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION]);
if ($pdo->query('SHOW DATABASES LIKE '.$pdo->quote($db))->fetchColumn()) throw new RuntimeException('Browser database already exists; refusing replacement');
$pdo->exec('CREATE DATABASE `'.$db.'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
echo "Created isolated synthetic browser database.\n";
$mysql = 'C:/Program Files/MySQL/MySQL Server 8.0/bin/mysql.exe';
if (!is_file($mysql)) $mysql = 'C:/Program Files/MySQL/MySQL Server 8.4/bin/mysql.exe';
$process = new Symfony\Component\Process\Process([$mysql,'--host='.getenv('DB_HOST'),'--port='.getenv('DB_PORT'),'--user='.getenv('DB_USERNAME'),'--password='.getenv('DB_PASSWORD'),$db]);
$process->setInput(file_get_contents($root.'/database/schema/mysql-schema.sql'));
$process->setTimeout(1800); $process->run();
if (!$process->isSuccessful()) throw new RuntimeException('Synthetic schema import failed: '.$process->getErrorOutput());
echo "Imported repository schema.\n";
$app = require $root.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class); $kernel->bootstrap();
if ($kernel->call('migrate',['--force'=>true,'--no-interaction'=>true]) !== 0) throw new RuntimeException($kernel->output());
$kernel->call('db:seed',['--class'=>Database\Seeders\RbacSeeder::class,'--force'=>true]);
$site=Site::factory()->create(['name'=>'PKG-03 synthetic North site','is_active'=>true,'archived'=>false]);
$user=User::factory()->withoutTwoFactor()->create(['name'=>'Synthetic Finance reviewer','email'=>'pkg03.reviewer@example.test','password'=>bcrypt('Local-PKG03-Review-Only!'),'approved_at'=>now(),'email_verified_at'=>now(),'role'=>'manager','theme'=>'light']);
foreach (['fleet.viewAny','fleet.manage','fleet.maintenance.manage','fleet.maintenance.view','assets.viewAny','sites.viewAll','finance.assets.view','finance.ap.view','finance.ap.manage','finance.ledger.view','finance.payments.manageAllSites','finance.settings.view'] as $key) {
    $p=Permission::firstOrCreate(['key'=>$key],['description'=>$key,'group'=>'finance','module'=>'finance']);
    $user->permissionOverrides()->syncWithoutDetaching([$p->id=>['allowed'=>true]]);
}
App\Domain\Hr\Models\HrEmployeeProfile::factory()->create(['user_id'=>$user->id,'employee_number'=>'PKG03-LOCAL','work_email'=>$user->email,'position_role'=>'manager','primary_site_id'=>$site->id,'secondary_site_ids'=>[],'start_date'=>today()->subYear(),'end_date'=>null,'is_active'=>true]);
$user=$user->fresh();
$asset=Asset::factory()->create(['name'=>'PKG-03 synthetic community van','site_id'=>$site->id,'category'=>'vehicle']);
$work=FleetWorkOrder::create(['asset_id'=>$asset->id,'reported_by_user_id'=>$user->id,'title'=>'PKG-03 synthetic brake service','description'=>'Local integration acceptance record only','category'=>'vehicle','priority'=>'medium','status'=>'open','version'=>0]);
$expense=FinAccount::factory()->create(['organization_id'=>1,'code'=>'6000','type'=>'expense','is_active'=>true]);
FinAccount::factory()->create(['organization_id'=>1,'code'=>'2000','type'=>'liability','is_active'=>true]);
FinFiscalPeriod::create(['organization_id'=>1,'name'=>'Synthetic current year','start_date'=>now()->startOfYear(),'end_date'=>now()->endOfYear(),'status'=>'open']);
$vendor=FinVendor::factory()->create(['name'=>'Synthetic workshop','is_active'=>true]);
$bill=FinBill::factory()->create(['vendor_id'=>$vendor->id,'site_id'=>$site->id,'asset_id'=>$asset->id,'status'=>'draft','bill_date'=>today(),'due_date'=>today()->addDays(14),'subtotal'=>575,'gst_amount'=>0,'total_amount'=>575,'created_by'=>$user->id]);
$bill->lines()->create(['description'=>'Synthetic brake inspection and service','quantity'=>1,'unit_price'=>575,'gst_rate'=>0,'gst_amount'=>0,'line_total'=>575,'account_id'=>$expense->id]);
app(MaintenanceFinanceService::class)->linkBill($user,$work->id,$bill->id);
Storage::disk('local')->put('pkg03-verification/quote.pdf',file_get_contents(__DIR__.'/quote.pdf'));
$file=AssetDocument::create(['asset_id'=>$asset->id,'uploaded_by_user_id'=>$user->id,'title'=>'Synthetic quote','category'=>'Maintenance quote','storage_disk'=>'local','storage_path'=>'pkg03-verification/quote.pdf','original_name'=>'synthetic-quote.pdf','mime_type'=>'application/pdf','size_bytes'=>filesize(__DIR__.'/quote.pdf'),'state'=>'available','scan_disposition'=>'clean']);
app(MaintenanceTransitionService::class)->execute($user,$work->id,'record_cost_estimate',0,'pkg03-browser-estimate',['vendor_id'=>$vendor->id,'quote_reference'=>'QUOTE-LOCAL-01','amount'=>'575.00','document_ids'=>[$file->id],'reason'=>'Synthetic local acceptance quote']);
$review=app(VehicleFinanceService::class)->createRequest($user,$asset->id,['request_type'=>'supplier_invoice_review','source'=>'bill:'.$bill->id,'amount'=>'575.00','note'=>'Review synthetic invoice against its recorded quote','expected_file_count'=>0],'pkg03-browser-review');
file_put_contents(__DIR__.'/browser-records.json',json_encode(['database'=>$db,'user'=>$user->id,'asset'=>$asset->id,'work'=>$work->id,'bill'=>$bill->id,'review'=>$review->id],JSON_PRETTY_PRINT));
echo "Synthetic canonical records ready.\n";

