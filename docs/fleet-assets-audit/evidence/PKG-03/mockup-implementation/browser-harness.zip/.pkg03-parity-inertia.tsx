import {forwardRef,useState} from 'react';
export function useForm(initial:any){const [data,set]=useState(initial);return {data,setData:(key:any,value:any)=>typeof key==='string'?set((previous:any)=>({...previous,[key]:value})):set(key),errors:{},processing:false,hasErrors:false,clearErrors:()=>{},reset:()=>set(initial),post:()=>{},put:()=>{},patch:()=>{},delete:()=>{},transform:()=>{},progress:null};}
export const Head=()=>null;
export const Link=forwardRef(function Link({children,href,...props}:any,ref:any){return <a {...props} ref={ref} href={href}>{children}</a>});
export const usePage=()=>({url:'/finance/bills/42',props:{auth:{user:{id:9,name:'Synthetic reviewer',permissions:['finance.ap.manage','finance.assets.manage','fleet.manage']}},permissions:['finance.ap.manage','finance.assets.manage','fleet.manage'],errors:{}}});
export const router={reload:()=>{},visit:()=>{},get:()=>{},post:()=>{},on:()=>()=>{}};
