export default function Layout({children}:any){return <main className="mx-auto max-w-[1500px] p-5">{children}</main>}
