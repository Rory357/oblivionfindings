<?php
require __DIR__.'/vendor/autoload.php';
require __DIR__.'/.pkg03-parity-TestCase.reusable.php';
require __DIR__.'/vendor/pestphp/pest/bin/pest';
