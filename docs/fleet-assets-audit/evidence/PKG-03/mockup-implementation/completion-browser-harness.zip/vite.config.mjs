import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';
import {pdfjsAssets} from '../build/pdfjs-assets.ts';
import {work,reviews,bill,data,context} from './fixtures.mjs';
import {pdf} from './pdf.mjs';

data.summary={committed:'575.00',invoice:'575.00',posted:'0.00',paid:'0.00',incomplete:false};
const shared={name:'Oblivion Findings',auth:{user:{id:999991,name:'Synthetic reviewer',email:'reviewer@example.test',role:'admin'},can:{assets:{viewAny:true,update:true},fleet:{view:true,manage:true},finance:{dashboard:true,ap:{view:true,manage:true},assets:{view:true,manage:true},ledger:{view:true}},tasks:{viewAny:true}}},sidebarOpen:true,branding:{name:'Oblivion Care'},flash:{},errors:{},permissions:['finance.ap.manage','finance.assets.manage','fleet.manage']};
const pages={
 '/fleet-assets/maintenance/work-orders/31':{component:'fleet-assets/maintenance/work-orders/show',props:{work_order:{...work,priority:'medium',waiting_reason:null,next_action:'Review the supplier invoice',due_at:'2026-09-29T01:00:00Z',created_at:'2026-09-24T02:00:00Z',reported_by:{id:12,name:'Alex'},asset:{...work.asset,asset_tag:'TEST01'}},actions:[{id:9,type:'note',payload:{note:'Workshop quote received. Finance review requested.'},actor_id:12,actor_name:'Alex',occurred_at:'2026-09-25T02:00:00Z',version:3}],checks:[],reports:[],restrictions:[{id:7,restriction_kind:'maintenance',state:'active'}],asset_active_restriction_ids:[7],booking_impacts:[],attachments:[],finance:[],release_policy:null,repair_policy:null,retest_policy:null,check_policy:null,hold_policy:null,release_readiness:{repair_attested:false,repair_evidence_saved:false,repair_rule_current:true,retest_outcome:null,retest_coverage_current:false},retest_template:null,check_template:null,task_link:null,task_scope_message:null,current_user_id:999991,can:{manage:true,review:true,custody:true,details:true,calendar:true,finance_view:true,finance_link:true},cost_workspace:data}},
 '/finance/bills/42':{component:'finance/bills/Show',props:{bill,approvalSnapshot:'a'.repeat(64),canManage:true,workContext:context,sites:[{id:1,name:'North site'}],vendors:[bill.vendor],accounts:[],costCentres:[],fundingStreams:[],purchaseOrders:[],spendApprovals:[]}},
 '/finance/vehicle-reviews':{component:'finance/vehicle-reviews/index',props:{requests:reviews,focus:null,total:3,pagination:{current_page:1,last_page:1,from:1,to:3,links:[]},filters:{status:'ready',search:'',sort:'oldest'},summary:{open:3,decided_30:8,oldest_open_at:'2026-09-25T02:00:00Z'},can:{decide:true}}},
 '/finance/journals/81':{component:'finance/journals/Show',props:{journal:{id:81,journal_number:'JNL-0081',journal_date:'2026-09-25',type:'standard',reference:'BILL-0042',description:'Supplier invoice · Brake service',status:'posted',total_amount:'575.00',posted_at:'2026-09-25T04:00:00Z',posted_by:{id:999991,name:'Morgan'},created_by:{id:999991,name:'Morgan'},fiscal_period:{id:1,name:'September 2026',start_date:'2026-09-01',end_date:'2026-09-30'},reversed_by_journal:null,lines:[{id:1,account:{id:1,code:'6200',name:'Vehicle maintenance'},description:'Brake service',debit:'575.00',credit:'0.00',cost_centre:{id:4,code:'FLEET',name:'Fleet operations'},funding_stream:null,tax_rate:null,tax_amount:'0.00'},{id:2,account:{id:2,code:'2000',name:'Accounts payable'},description:'North Workshop',debit:'0.00',credit:'575.00',cost_centre:null,funding_stream:null,tax_rate:null,tax_amount:'0.00'}]},sourceBill:{id:42,reference:'BILL-0042',status:'approved',total:'575.00',paid:'0.00',work:context.work},can:{post:false,reverse:true}}}
};
export default defineConfig({
 cacheDir:'.pkg03-fullpage-tools/runtime/node_modules/.vite',
 plugins:[react(),tailwindcss(),pdfjsAssets(path.resolve('.pkg03-fullpage-tools/runtime/node_modules/pdfjs-dist')),{name:'synthetic-inertia-pages',configureServer(server){server.middlewares.use(async(req,res,next)=>{
 const url=new URL(req.url,'http://127.0.0.1:8766');
 if(url.pathname==='/fixture/quote.pdf'){res.setHeader('Content-Type','application/pdf');res.end(pdf());return;}
 if(req.method!=='GET'&&req.method!=='HEAD'){res.statusCode=422;res.setHeader('Content-Type','application/json');res.end(JSON.stringify({errors:{verification:['Synthetic verification mode: no records were changed.']}}));return;}
 const match=pages[url.pathname]; if(!match)return next();
 const page={...match,props:{...shared,...match.props,appearance:{theme:url.searchParams.get('theme')==='dark'?'dark':'light'}},url:req.url,version:'pkg03-fullpage-verification',clearHistory:false,encryptHistory:false};
 if(req.headers['x-inertia']){res.setHeader('X-Inertia','true');res.setHeader('Content-Type','application/json');res.end(JSON.stringify(page));return;}
 const encoded=JSON.stringify(page).replaceAll('&','&amp;').replaceAll("'",'&#39;').replaceAll('<','&lt;');
 const html=`<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="synthetic-only"><title>PKG-03 full application verification</title></head><body><div id="app" data-page='${encoded}'></div><script type="module" src="/resources/js/app.tsx"></script></body></html>`;
 res.setHeader('Content-Type','text/html');res.end(await server.transformIndexHtml(req.url,html));
 });}}],
 resolve:{alias:{'@':path.resolve('resources/js'),'pdfjs-dist':path.resolve('.pkg03-fullpage-tools/runtime/node_modules/pdfjs-dist')}},
 server:{host:'127.0.0.1',port:8766,strictPort:true},optimizeDeps:{exclude:['pdfjs-dist']}
});
