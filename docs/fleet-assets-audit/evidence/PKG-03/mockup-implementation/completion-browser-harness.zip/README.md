# PKG-03 full application visual verifier

Restore this archive into `.pkg03-fullpage-tools` in the repository root. Install `pdfjs-dist@6.3.289` into `.pkg03-fullpage-tools/runtime` with npm's `--prefix`, `--no-package-lock` and `--ignore-scripts` options. Use the repository's existing dependencies for Vite, React and Tailwind.

Run `node node_modules/vite/bin/vite.js --config .pkg03-fullpage-tools/vite.config.mjs` from the repository root. This binds only to `127.0.0.1:8766` and renders `resources/js/app.tsx`, the real application layouts and the real Inertia library. The middleware supplies synthetic records and refuses write requests. It does not connect to a database, impersonate a real account or approve/pay real bills.

Pages: `/fleet-assets/maintenance/work-orders/31?tab=finance`, `/finance/bills/42`, `/finance/vehicle-reviews`, `/finance/journals/81`. Add `theme=dark` to a direct page load for the dark-theme fixture.

The build config retains production React compilation, Tailwind, manual chunks and PDF assets. Its output is isolated; PHP route generation and Laravel hot-file handling are omitted. Set NODE_PATH to the isolated runtime/node_modules before loading this config, so the production PDF plugin resolves the pinned dependency. The TypeScript and Vitest configs also resolve that isolated dependency.

Capture ordinary viewport screenshots: this browser's full-page stitching produced unreliable off-screen/compressed captures. Check DOM viewport/scroll widths separately. This harness verifies application UI with fixture server responses, not signed-in service acceptance.
