import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { shared, pages } from './fixture/pages.mjs';
import { pdf } from './fixture/pdf.mjs';

// Render the current compiled application with explicit synthetic Inertia data.
// No Laravel session, database, or write operation is represented by this server.
const root = path.resolve('.pkg03-final-tools/production');
const manifest = JSON.parse(fs.readFileSync(path.join(root, 'manifest.json'), 'utf8'));
const entry = manifest['resources/js/app.tsx'];
const css = [...new Set([manifest['resources/css/app.css']?.file, ...(entry.css ?? [])].filter(Boolean))];
const queue = pages['/finance/vehicle-reviews'].props;
queue.requests = queue.requests.map((review, index) => index ? review : ({ ...review, can_request_changes: false,
    vehicle: { ...review.vehicle, name: 'Synthetic equipment', registration: null, url: '/fleet-assets/assets/8#view=overview&section=finance' },
}));
const types = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.css': 'text/css', '.json': 'application/json', '.svg': 'image/svg+xml', '.wasm': 'application/wasm', '.woff2': 'font/woff2' };
http.createServer((req, res) => {
    const url = new URL(req.url, 'http://127.0.0.1:8773');
    if (!['GET', 'HEAD'].includes(req.method)) { res.writeHead(422, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ message: 'Synthetic visual verification: writes are disabled.' })); return; }
    if (url.pathname === '/fixture/quote.pdf') { res.writeHead(200, { 'Content-Type': 'application/pdf' }); res.end(pdf()); return; }
    if (url.pathname.startsWith('/build/')) {
        const file = path.resolve(root, decodeURIComponent(url.pathname.slice('/build/'.length)));
        if (file.startsWith(root + path.sep) && fs.existsSync(file) && fs.statSync(file).isFile()) {
            res.writeHead(200, { 'Content-Type': types[path.extname(file)] ?? 'application/octet-stream' }); fs.createReadStream(file).pipe(res); return;
        }
    }
    const match = pages[url.pathname];
    if (!match) { res.writeHead(404); res.end('Synthetic verifier has no fixture for this route.'); return; }
    const page = { ...match, props: { ...shared, ...match.props, appearance: { theme: 'light' } }, url: req.url, version: 'pkg03-programme-integration' };
    if (req.headers['x-inertia']) { res.writeHead(200, { 'X-Inertia': 'true', 'Content-Type': 'application/json' }); res.end(JSON.stringify(page)); return; }
    const encoded = JSON.stringify(page).replaceAll('&', '&amp;').replaceAll("'", '&#39;').replaceAll('<', '&lt;');
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(`<!doctype html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="csrf-token" content="synthetic"><title>PKG-03 compiled visual verification</title>${css.map(file => `<link rel="stylesheet" href="/build/${file}">`).join('')}</head><body><div id="app" data-page='${encoded}'></div><script type="module" src="/build/${entry.file}"></script></body></html>`);
}).listen(8773, '127.0.0.1', () => console.log('Compiled fixture verifier on 127.0.0.1:8773; writes disabled.'));
