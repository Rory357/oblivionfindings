import { defineConfig, mergeConfig } from 'vitest/config';
import path from 'node:path';
import base from '../vitest.config';

// Worktree node_modules is a shared junction. Keep PDF worker URL loading
// inside this worktree for Vite's test-server filesystem boundary.
export default mergeConfig(base, defineConfig({ resolve: { alias: {
    'pdfjs-dist': path.resolve('.pkg03-final-tools/runtime/node_modules/pdfjs-dist'),
} } }));
