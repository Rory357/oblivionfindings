# Reproduce the final PKG-03 visual check

Extract this archive into `.pkg03-final-tools` under the repository root. Use the dependencies declared by the current package and lockfile. Build from the root with Herd PHP on PATH and `APP_ENV=testing`:

`node node_modules/vite/bin/vite.js build --outDir .pkg03-final-tools/production`

Then run `node .pkg03-final-tools/preview.mjs`. It binds only to 127.0.0.1:8773, serves those actual compiled assets and synthetic Inertia page data, and rejects every write. The pages are `/finance/vehicle-reviews`, `/finance/bills/42` and `/fleet-assets/maintenance/work-orders/31?tab=finance`. There is no authentication, database, scanner or operational processing in this visual verifier.

For Vitest in a worktree with a shared node_modules junction, copy the installed `pdfjs-dist` package to `.pkg03-final-tools/runtime/node_modules/pdfjs-dist` and use the included `vitest.config.ts`. This avoids Vite's test-server filesystem rejection of the PDF worker URL. It changes no production package or test behavior.

Measured browser widths were 1440 and 1280 CSS pixels. At this machine's devicePixelRatio 1.25, the browser viewport capability required physical sizes 1800×1125 and 1600×1125. This resizing is not actual browser zoom. The attempted zoom shortcuts caused no measured change; genuine 125% zoom remains unverified.

Stop this verifier and remove its task-local runtime/build output when finished. Never remove the repository's `build/` source plugin directory or the shared node_modules junction.
